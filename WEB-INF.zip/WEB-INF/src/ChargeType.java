
public class ChargeType {

}
