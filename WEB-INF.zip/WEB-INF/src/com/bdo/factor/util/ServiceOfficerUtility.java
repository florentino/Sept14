package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Group;
import com.bdo.factor.beans.ServiceOfficer;

public class ServiceOfficerUtility {
private static ServiceOfficerUtility serviceOffUtilInstance = new ServiceOfficerUtility(); 
	
	private ServiceOfficerUtility() {}
	
	public static ServiceOfficerUtility getInstance() {
		return serviceOffUtilInstance;
	}
	
	public ServiceOfficer toObject(Map map) {	
		ServiceOfficer sOfficer = new ServiceOfficer();		
		sOfficer.setC_BranchCode((String) map.get("C_BRANCHCODE"));		                           
		sOfficer.setC_ServiceOfficerCode((String) map.get("C_SERVICEOFFICERCODE"));
		sOfficer.setC_Name((String) map.get("C_NAME"));				
		return sOfficer;		
	}
	
	public Map toMap(ServiceOfficer sOfficer){
		Map map = new HashMap();
		map.put("C_BRANCHCODE", sOfficer.getC_BranchCode());		
		map.put("C_NAME", sOfficer.getC_Name());
		map.put("C_SERVICEOFFICERCODE", sOfficer.getC_ServiceOfficerCode());
		
		
		return map;
	}	
}

