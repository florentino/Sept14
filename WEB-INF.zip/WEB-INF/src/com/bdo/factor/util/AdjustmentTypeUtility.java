package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.AdjustmentType;

public final class AdjustmentTypeUtility {
	
	public static Map toMap(AdjustmentType adjustmentType){
		Map map = new HashMap();
		map.put("C_ADJCODE", adjustmentType.getC_AdjCode());
		map.put("C_ADJDESC", adjustmentType.getC_AdjCode());
		
		
		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static AdjustmentType toObject(Map map) {
		
		AdjustmentType adjustmentType = new AdjustmentType();
		
		adjustmentType.setC_AdjCode((String) map.get("C_ADJCODE"));
		adjustmentType.setC_AdjDesc((String) map.get("C_ADJDESC"));
				
		return adjustmentType;		
	}
}
