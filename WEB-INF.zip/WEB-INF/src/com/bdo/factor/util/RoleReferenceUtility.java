package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.RoleReference;

public final class RoleReferenceUtility {
	
	public static Map toMap(RoleReference b){
		Map map = new HashMap();
		map.put("ROLE", b.getROLE());
		map.put("ROLE_DESC", b.getROLE_DESC());

		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static RoleReference toObject(Map map) {		
		RoleReference b = new RoleReference();
		
		b.setROLE((String) map.get("ROLE"));
		b.setROLE_DESC((String) map.get("ROLE_DESC"));
		
		return b;		
	}
}
