package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Group;
import com.bdo.factor.beans.Holiday;

public final class HolidayUtility {
	private static HolidayUtility holidayUtilInstance = new HolidayUtility(); 
	
	private HolidayUtility (){}
	
	public static HolidayUtility getInstance() {
		return holidayUtilInstance;
	}
	
	public Holiday toObject(Map map) {	
        Holiday holiday = new Holiday();
		holiday.setC_BranchCode((String)map.get("C_BRANCHCODE"));
		String dhDate = map.get("D_HOLIDAYDATE").toString();
		holiday.setD_HolidayDate(DateHelper.parse(dhDate));
		holiday.setB_StdHoliday(Boolean.parseBoolean(map.get("B_STDHOLIDAY").toString()));
		holiday.setC_Description((String)map.get("C_DESC"));
		
		return holiday;	
	}
	
	public Map toMap(Holiday g){
		Map map = new HashMap();
		map.put("C_BRANCHCODE", g.getC_BranchCode());
		map.put("D_HOLIDAYDATE", g.getD_HolidayDate());
		map.put("B_STDHOLIDAY", g.isB_StdHoliday());
		map.put("C_DESCRIPTION", g.getC_Description());
	

		return map;
	}
	
	public boolean isDuplicate(String c_BranchCode, String c_HolidayCode) {
		
		return false;
	}
	
}
