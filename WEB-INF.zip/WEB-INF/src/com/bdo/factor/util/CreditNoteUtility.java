package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.CreditNote;

public class CreditNoteUtility {
private static CreditNoteUtility cnInstance = new CreditNoteUtility();
	
	private CreditNoteUtility() {}
	
	public static CreditNoteUtility getInstance() {
		return cnInstance;
	}
	
	
	public CreditNote toObject(Map m) {
		
		HashMap map = (HashMap) m;
		CreditNote cn = new CreditNote();
		cn.setN_REFNO(map.get("N_REFNO") != null && map.get("N_REFNO").toString().trim().length() > 0 ? Long.parseLong(map.get("N_REFNO").toString()):0);
		cn.setC_BRANCHCODE((String) map.get("C_BRANCHCODE"));
		cn.setC_CLNTCODE((String) map.get("C_CLNTCODE"));
		cn.setC_CNTYPECODE((String) map.get("C_CNTYPE"));
		cn.setC_CUSTCODE((String) map.get("C_CUSTCODE"));
		cn.setC_INVOICENO((String) map.get("C_INVOICENO"));
		cn.setC_RECEIPTNO((String) map.get("C_RECEIPTNO"));
		cn.setC_STATUS((String) map.get("C_STATUS"));
		cn.setD_APPLICATIONDATE(DateHelper.parse((String) map.get("D_APPLICATIONDATE")));
		cn.setD_INVOICEDATE(DateHelper.parse((String) map.get("D_INVOICEDATE")));
		cn.setD_TRANSACTIONDATE(DateHelper.parse((String) map.get("D_TRANSACTIONDATE")));
		cn.setN_AMOUNT(Double.parseDouble(((String) map.get("N_AMOUNT")).replaceAll(",", "")));
		cn.setC_RECEIPTNO((String) map.get("C_RECEIPTNO"));
		
		return cn;
		
	}
}
