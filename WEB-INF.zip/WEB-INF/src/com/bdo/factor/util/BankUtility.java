package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Bank;

public final class BankUtility {
	
	public static Map toMap(Bank b){
		Map map = new HashMap();
		map.put("C_BANKCODE", b.getC_BANKCODE());
		map.put("C_BANKNAME", b.getC_BANKNAME());
		map.put("C_ADDRESS", b.getC_ADDRESS());
		map.put("C_TELNO", b.getC_TELNO());
		map.put("C_FAXNO", b.getC_FAXNO());

		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static Bank toObject(Map map) {		
		Bank b = new Bank();
		
		b.setC_BANKCODE((String) map.get("C_BANKCODE"));
		b.setC_BANKNAME((String) map.get("C_BANKNAME"));
		b.setC_ADDRESS((String) map.get("C_ADDRESS"));
		b.setC_TELNO((String) map.get("C_TELNO"));
		b.setC_FAXNO((String) map.get("C_FAXNO"));
		
		return b;		
	}
}
