package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.AccountOfficer;

public final class AccountOfficerUtility {
	
	public static Map toMap(AccountOfficer accOfficer){
		Map map = new HashMap();
		map.put("C_BRANCHCODE", accOfficer.getC_BranchCode());
		map.put("C_ACCTOFFICERCODE", accOfficer.getC_AccountOfficerCode());
		map.put("C_NAME", accOfficer.getC_Name());
		
		return map;
	}
	
	public static AccountOfficer toObject(Map m) {
		
		HashMap map = (HashMap) m;
		AccountOfficer accOfficer = new AccountOfficer();
		accOfficer.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		accOfficer.setC_AccountOfficerCode((String) map.get("C_ACCTOFFICERCODE"));
		accOfficer.setC_Name((String) map.get("C_NAME"));
		
		return accOfficer;
		
	}
	
}
