package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.CnType;

public final class CNTypeUtility {
	private static CNTypeUtility CNTypeUtilityInstance = new CNTypeUtility(); 
	
	private CNTypeUtility() {}
	
	public static CNTypeUtility getInstance() {
		return CNTypeUtilityInstance;
	}
	
	public Map toMap(CnType cnType) {
		Map map = new HashMap();
		map.put("C_CNTYPECODE", cnType.getC_CnTypeCode());
		map.put("C_DESCRIPTION", cnType.getC_Description());
		
		return map;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public CnType toObject(Map map) {		
		CnType cnType = new CnType();

		cnType.setC_CnTypeCode((String) map.get("C_CNTYPECODE"));
		cnType.setC_Description((String) map.get("C_DESCRIPTION"));
		
		return cnType;

	}
}
