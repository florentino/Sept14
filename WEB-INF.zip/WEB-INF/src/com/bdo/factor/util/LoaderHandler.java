package com.bdo.factor.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bdo.factor.beans.PDODelinquent;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dataSource.PDODelinquentDAO2;

public class LoaderHandler {

	private static List<Object> listObject = new ArrayList();
	private static List indexList = new ArrayList();
	private Integer index = 0;
	private static Integer indexCount=0 ;
	private Boolean isProcessing;
	private Boolean isDone;
	private Double rownumber;
	private Double rowcount;
	private ApplicationContext context;
	
	public LoaderHandler(){}
	

	
	public LoaderHandler(String sessionID){
		context = new ClassPathXmlApplicationContext("xml-config/applicationContext.xml");
		//PDODelinquentDAO2 pod = (PDODelinquentDAO2)Persistence.getDAO("PDODelinquentDAO2");
		PDODelinquentDAO2 pod = (PDODelinquentDAO2)context.getBean("PDODelinquentDAO2");
		LoaderHandler.indexList.add(indexCount,sessionID);
		LoaderHandler.listObject.add(indexCount,pod);
		LoaderHandler.indexCount++;
	}
	
	
	public synchronized PDODelinquentDAO2 getInstance(String sessionId){
		//String sessionId= "ds";//
		index =	LoaderHandler.indexList.indexOf(sessionId);
		System.out.print(sessionId);
		PDODelinquentDAO2 pdo = (PDODelinquentDAO2) LoaderHandler.listObject.get(index);
		return pdo;
	}
	
	public Map getUpdate(PDODelinquentDAO2 pdo){
		Map map = new HashMap();
		try{
		System.out.println("REMAINING>>>>>"+pdo.getRemaining());
		 if(pdo.getProcess()){
			map.put("newValue", pdo.getRemaining());
		 }
		 else
			 map.put("started", pdo.getProcess());
		}catch(Exception e){
			e.printStackTrace();
		}
		return map;
	};
	
	
	//GENERIC
	
	public synchronized <E> void LoaderHandler(String sessionId, String daoName){
		context = new ClassPathXmlApplicationContext("xml-config/applicationContext.xml");
		E pod = (E)context.getBean(daoName);
		LoaderHandler.indexList.add(indexCount,sessionId);
		LoaderHandler.listObject.add(indexCount,pod);
		LoaderHandler.indexCount++;
	}
	
	public synchronized Object getInstance2(String sessionId){
		index =	LoaderHandler.indexList.indexOf(sessionId);		
		return LoaderHandler.listObject.get(index);
	}
	
	
	public  Map  getUpdate(Object dao){
		Method m1;
		Map records = new HashMap();
		Map returnMap = new HashMap();
		//dao.getClass().getMethod(name, parameterTypes); 
		try {
			m1 = dao.getClass().getMethod("getUpdate");
			records = (Map)m1.invoke(dao);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		
		if((Boolean)records.get("process")){
			returnMap.put("newValue", records.get("newValue"));
		}
		else
			returnMap.put("started", (Boolean)records.get("process"));
		
		return returnMap;
	}
	
	public <E>Map update2(E ds){
		
		return null;
	}
	
	
	
}
