package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.CheckType;

public final class CheckTypeUtility {
	
	public static Map toMap(CheckType cType){
		Map map = new HashMap();
		map.put("C_CHECKTYPECODE", cType.getC_CheckTypeCode());
		map.put("C_DESCRIPTION", cType.getC_Description());
		map.put("N_NOOFDAYS", cType.getN_NoOfDays());
		
		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static CheckType toObject(Map map) {
		CheckType cType = new CheckType();
		
		cType.setC_CheckTypeCode((String) map.get("C_CHECKTYPECODE"));
		cType.setC_Description((String) map.get("C_DESCRIPTION"));
		cType.setN_NoOfDays(Integer.parseInt((String) map.get("N_NOOFDAYS")));
				
		return cType;		
	}
}
