package com.bdo.factor.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Invoice;

public final class InvoiceUtility {
	private static InvoiceUtility InvoiceUtilityInstance = new InvoiceUtility(); 
	
	private InvoiceUtility() {}
	
	public static InvoiceUtility getInstance() {
		return InvoiceUtilityInstance;
	}
	
	public Map toMap(Invoice invoiceType) {
		Map map = new HashMap();
		map.put("C_BRANCHCODE", invoiceType.getC_BRANCHCODE());
		map.put("C_CLNTCODE", invoiceType.getC_CLNTCODE());
		map.put("C_CUSTCODE", invoiceType.getC_CUSTCODE());
		map.put("C_NAME", invoiceType.getC_NAME());
		map.put("C_CUSTNAME", invoiceType.getC_CUSTNAME());
		map.put("C_INVOICENO", invoiceType.getC_INVOICENO());
		map.put("D_INVOICEDATE", invoiceType.getD_INVOICEDATE());
		map.put("D_INVOICEDUEDATE", invoiceType.getD_INVOICEDUEDATE());
		map.put("D_TRANSACTIONDATE", invoiceType.getD_TRANSACTIONDATE());
		map.put("N_ORIGINVOICEAMT", invoiceType.getN_ORIGINVOICEAMT());
		map.put("N_INVOICEAMT", invoiceType.getN_INVOICEAMT());
		map.put("N_TERM", invoiceType.getN_TERM());
		map.put("CCTERM", invoiceType.getCCTERM());
		map.put("N_DUNNINGDAYS", invoiceType.getN_DUNNINGDAYS());
		map.put("C_STATUS", invoiceType.getC_STATUS());
		
		return map;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Invoice toObject(Map map) {		
		Invoice invoiceType = new Invoice();

		invoiceType.setC_BRANCHCODE((String) map.get("C_BRANCHCODE"));
		invoiceType.setC_CLNTCODE(map.get("C_CLNTCODE").toString());
		invoiceType.setC_CUSTCODE( map.get("C_CUSTCODE").toString());
		invoiceType.setC_NAME((String) map.get("C_NAME"));
		invoiceType.setC_CUSTNAME((String) map.get("C_CUSTNAME"));
		invoiceType.setC_INVOICENO((String) map.get("C_INVOICENO"));
		invoiceType.setD_INVOICEDATE(new Date(map.get("D_INVOICEDATE").toString()));
		invoiceType.setD_INVOICEDUEDATE(new Date(map.get("D_INVOICEDUEDATE").toString()));
		invoiceType.setD_TRANSACTIONDATE(new Date(map.get("D_TRANSACTIONDATE").toString()));
		invoiceType.setN_ORIGINVOICEAMT(new Double (map.get("N_ORIGINVOICEAMT").toString()));
		invoiceType.setN_INVOICEAMT((Double) map.get("N_INVOICEAMT"));
		invoiceType.setN_TERM((Long) map.get("N_TERM"));
		invoiceType.setCCTERM((Long) map.get("CCTERM"));
		invoiceType.setN_DUNNINGDAYS((Long) map.get("N_DUNNINGDAYS"));
		invoiceType.setC_STATUS((String) map.get("C_STATUS"));

		
		return invoiceType;

	}
}
