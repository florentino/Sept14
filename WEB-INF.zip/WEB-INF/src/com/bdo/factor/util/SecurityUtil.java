package com.bdo.factor.util;

import java.io.IOException;
import java.io.PrintWriter;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletResponse;

import org.jfree.util.Log;

import sun.util.logging.resources.logging;

public class SecurityUtil {
	
	public static void main(String[] args) throws SecurityException, NoSuchMethodException, ParseException, SQLException, ClassNotFoundException{
		Pattern s = Pattern.compile("[^a-z A-Z 0-9]");
		Matcher m = s.matcher("Aa4$9ds");
		System.out.println(m.find());
	}
	
	public void checkDate(){
		
	}
		
	public static String encode(String str) {
		if (str == null)
			return null;
		StringBuffer s = new StringBuffer();
		for (short i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			switch (c) {
				case '<':
					s.append("&lt;");break;
				case '>':
					s.append("&gt;");break;
				case '(':
					s.append("&#40;");break;
				case ')':
					s.append("&#41;");break;
				case '#':
					s.append("&#35;");break;
				case '&':
					s.append("&amp;");break;
				case '"':
					s.append("&quot;");break;
				case '\'':
					s.append("&apos;");break;
				case '%':
					s.append("&#37;");break;
				case '+':
					s.append("&#43;");break;
				case '-':
					s.append("&#45;");break;
				default:
					s.append(c);
			}
		}
		return s.toString();
		}

	public static void throwMessage(HttpServletResponse response, String message){
		PrintWriter out;
		try {
			out = response.getWriter();
			String html ="<HTML> <BODY onload=\"alert('"+message+"')\">"+
					"</body> </html>";
			out.print(html);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static SecureRandom prng;
 
		
	private static String hexEncode(byte[] aInput){
		StringBuilder result = new StringBuilder();
		char[] digits = {'0', '1', '2', '3', '4','5','6','7','8','9','a','b','c','d','e','f'};
		for (int idx = 0; idx < aInput.length; ++idx) {
			byte b = aInput[idx];
			result.append(digits[ (b&0xf0) >> 4 ]);
			result.append(digits[ b&0x0f]);
		}
		return result.toString();
	  }
	  
	private synchronized static String generateId(){
		MessageDigest sha = null;
			byte[] result = null;
			try {
				prng = SecureRandom.getInstance("SHA1PRNG");
			  
				String randomNum = new Long(prng.nextLong()).toString();

				sha = MessageDigest.getInstance("SHA-1");
				result =  sha.digest(randomNum.getBytes());
		    }
			catch (NoSuchAlgorithmException ex) {
				System.err.println(ex);
			}
			return hexEncode(result);
	}

	public static String getID(){
		return generateId();
	}
	
}
