 package com.bdo.factor.util;

import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;


public class DateHelper {
	
	private static Logger log = Logger.getLogger(DateHelper.class);

///////////////////////////////////////////////////////////////////////////////////////////////////////
	
    private static SimpleDateFormat simpleFormatter = new SimpleDateFormat("MM/dd/yyyy");

///////////////////////////////////////////////////////////////////////////////////////////////////////

	//Don't let anyone instantiate this class...
	private DateHelper() { }    

///////////////////////////////////////////////////////////////////////////////////////////////////////
	
    /**
     * Converts String date to Date object
     * @param strDate Date to be converted
     * @return Date object
     */
    public static Date parse(String strDate) {
        try {
            Date d = simpleFormatter.parse(strDate, new ParsePosition(0));
            return d;
        } catch ( Exception ex ) {
            return null;
        }
    }
 
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /**
     * Converts Date object to String
     * @param d Date to be converted
     * @return String date
     */
    public static String format(Date d) {
        if ( d == null ) return "";
        try {
            return simpleFormatter.format(d);
        } catch (Exception e) {
            return "";
        }
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////
   
    /**
     * Checks if it is greater than to compare
     * @param it The base date
     * @param compare Date compared to by it
     * @return
     */
    public static boolean after(Date it, Date compare) {
    	return it.after(compare);
    }
 
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /**
     * Checks if it is less than compare
     * @param it The base date
     * @param compare Date compared to by it
     * @return
     */
    public static boolean before(Date it, Date compare) {
    	return it.before(compare);
    }
 
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /**
     * Compares it date if it is between start and end dates
     * @param it The base date
     * @param start Start Date
     * @param end End Date
     * @return
     */
    public static boolean between(Date it, Date start, Date end) {
    	return (it.after(start) && it.before(end));
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public static boolean isDate(String date){
    	try {
            Date d = simpleFormatter.parse(date, new ParsePosition(0));
            return true;
        } catch ( Exception ex ) {
            return false;
        }
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////

    public static Date getDateInFirstDay(String date){
    	String[] str = date.split("/");
    	FactorsDateDAO factorsDate = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
    	int mm = Integer.parseInt(str[0]);
    	//int dd = Integer.parseInt(str[1]);
    	int yyyy = Integer.parseInt(str[2]);
    	Date retVal= factorsDate.newDate(); //before: new date()
        try {
            retVal = simpleFormatter.parse(mm+"/01/"+yyyy, new ParsePosition(0));
        } catch ( Exception ex ) {
            return null;
        }
    	return retVal;
    }
    
	public static int getDayPerTransaction(String date1,String date2){
		int retVal=0;
		String[] str1 = date1.split("/");
		int dd1=Integer.parseInt(str1[1]);
		String[] str2 = date2.split("/");
		int dd2=Integer.parseInt(str2[1]);
		//return retVal= dd2-dd1+1; //rdc08062010
		return retVal= dd2-dd1;
	}   

	public static int getDayInMonth(String date){
		String[] str = date.split("/");
		return Integer.parseInt(str[1]);
	} 
	
	public static int getYear(String date){
		String[] str = date.split("/");
		return Integer.parseInt(str[2]);
	} 
	
	public static int getLastYear(String date){
		String[] str = date.split("/");
		return Integer.parseInt(str[2])-1;
	}
	public static String getLastYearDate(String date){
		String[] str = date.split("/");
		String lastYear=str[0]+"/"+str[1]+"/"+(Integer.parseInt(str[2])-1);
		return lastYear;
	} 	
    
	public static String getLastDateOfTheMonth(String theDate)
	{
		String[] dateOfTheYear = theDate.split("/");
		Calendar c = Calendar.getInstance();			
		c.set(Integer.parseInt(dateOfTheYear[2]), (Integer.parseInt(dateOfTheYear[0]) - 1), Integer.parseInt(dateOfTheYear[1]));
		c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));		    
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		return sdf.format(c.getTime());
	}
	
	public static Date getMonthEndDate (String asOfDate) {
		String DATE_FORMAT = "MM/dd/yyyy";
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT); 
		Calendar c1 = Calendar.getInstance(); // today 
		
		String strCurrent = sdf.format(date.newDate()); //before: c1.getTime()
		String lastAsOF = DateHelper.getLastDateOfTheMonth(asOfDate);
		String lastCurr = DateHelper.getLastDateOfTheMonth(strCurrent);
		log.info("strAsOfDate:" + asOfDate);
		log.info("strCurrent:" + strCurrent);
		log.info("strAsOfDate last date:" + lastAsOF);
		log.info("strCurrent last date:" + lastCurr);
		
		Date dteToUse;
		if (lastAsOF.equals(lastCurr)) {
			dteToUse = DateHelper.parse(asOfDate);
			log.info("Use As of date for month end:");
		} else {
			dteToUse = DateHelper.parse(strCurrent);
			log.info("Use Current date  for month end:");
		}
		
		return dteToUse;
	}
	
	public static String getMonthName(Date date){
		
		Map pd = new HashMap();
		GregorianCalendar gc = new GregorianCalendar();	
		gc.setTime(date);
		//gc.add(GregorianCalendar.DAY_OF_MONTH, -1);	
		//gc.add(GregorianCalendar.DAY_OF_WEEK, 1);
		//gc.add(GregorianCalendar.DAY_OF_YEAR,1);
		DateFormat sdf = new SimpleDateFormat("MMM");
		return sdf.format(date);
	}	
	public static String getDayOrdinalNumber(int day){
		if (day>=11 && day <=13){
			return "th";
		}
		switch (day % 10){
		case 1: return "st";
		case 2: return "nd";
		case 3: return "rd";
		default: return "th";
		}
	}
	
	
    public static void main(String[] args){    	
    	//System.out.println("first date: "+getDateInFirstDay("12/8/2009"));
    	Calendar c = Calendar.getInstance();
    	c.setTime(new java.util.Date());
    	//System.out.println("-->"+c.getTimeZone().toString().trim());
    	//System.out.println("-->"+new java.util.Date().toString().trim());
    	System.out.println(getMonthName(new Date("10/04/2010")));
    	
    }
    
}
