package com.bdo.factor.util;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.export.*;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bdo.factor.beans.SystemSettings;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.SystemSettingsDAO;
import com.bdo.factor.dataSource.AuditLogsField;
import com.bdo.factor.dataSource.UtilDAO;
import com.bdo.factor.dataSource.WeeklyBookingFields;
import com.bdo.factor.dataSource.WeeklyBookingSummaryField;


public class ReportXLS extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			performTask(request, response);
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		try {
			performTask(request, response);
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void performTask(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException, JRException {
		
		String jasper = null;
		String reportFileName = null;
		JRDataSource ds = null;
		Map param = null;
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");		
		String operation = request.getParameter("operation")!=null?(String)request.getParameter("operation"):"";
		System.out.println("operation: " + operation);
				
		if (operation != null && operation.trim().equalsIgnoreCase("weeklyBooking")) {
			String monthYear = (request.getParameter("monthYear") !=null ? request.getParameter("monthYear") : "01/01/1900");
			String branchCode = (request.getSession().getAttribute("branchCode") !=null ? (String)request.getSession().getAttribute("branchCode") : "");
			String userName    	= request.getSession().getAttribute("userName")!=null?(String)request.getSession().getAttribute("userName"):"JeffPogi";
						
			jasper = request.getAttribute("jasper")!=null?(String)request.getAttribute("jasper"):"/report/weeklyBooking.jasper";
								
			UtilDAO utilDao    = (UtilDAO)Persistence.getDAO("utilDao");						
			//String monthName                    = utilDao.getMonthName(utilDao.getCurrentMonth(monthYear));
			Calendar cal = Calendar.getInstance();
			cal.setTime(DateHelper.parse(monthYear));
			int month = cal.get(Calendar.MONTH) + 1;
			String monthName = utilDao.getMonthName(month);
			String monthAndYear                 = monthName + " " + utilDao.getCurrentYear(monthYear);
			System.out.println("monthName: " + monthName);
		
			reportFileName = getServletContext().getRealPath(jasper);		
		
			ds = new WeeklyBookingFields(monthYear, branchCode);
		
			param =request.getAttribute("map")!=null ?(Map)request.getAttribute("map") : new HashMap();
			SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
			SystemSettings systemSettings = systemSettingDao.getSystemSettings();
		
			param.put("systemName", systemSettings.getC_SYSTEMNAME());
			param.put("currencyCode", systemSettings.getC_CURRENCYCODE());
			param.put("bankCode", systemSettings.getC_BANKCODE());		
			param.put("monthAndYear", monthAndYear);
			param.put("userName",userName);
			System.out.println("jasper->"+jasper);
			System.out.println("reportFileName	->"+reportFileName);
		}
		else if (operation != null && operation.trim().equalsIgnoreCase("weeklyBookingSummary")) {
			System.out.println("Weekly Booking!!!");
			String monthYear = (request.getParameter("monthYear") !=null ? request.getParameter("monthYear") : "01/01/1900");
			String branchCode = (request.getSession().getAttribute("branchCode") !=null ? (String)request.getSession().getAttribute("branchCode") : "");
			String userName    	= request.getSession().getAttribute("userName")!=null?(String)request.getSession().getAttribute("userName"):"JeffPogi";
						
			jasper = request.getAttribute("jasper")!=null?(String)request.getAttribute("jasper"):"/report/weeklyBookingSummary.jasper";
								
			UtilDAO utilDao    = (UtilDAO)Persistence.getDAO("utilDao");						
			//String monthName                    = utilDao.getMonthName(utilDao.getCurrentMonth(monthYear));
			Calendar cal = Calendar.getInstance();
			cal.setTime(DateHelper.parse(monthYear));
			int month = cal.get(Calendar.MONTH) + 1;
			String monthName = utilDao.getMonthName(month);
			String monthAndYear                 = monthName + " " + utilDao.getCurrentYear(monthYear);
			System.out.println("monthName: " + monthName);
		
			System.out.println("monthName: " + monthYear);
			reportFileName = getServletContext().getRealPath(jasper);		
		
			ds = new WeeklyBookingSummaryField(monthYear, branchCode);
		
			param =request.getAttribute("map")!=null ?(Map)request.getAttribute("map") : new HashMap();
			SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
			SystemSettings systemSettings = systemSettingDao.getSystemSettings();
		
			param.put("systemName", systemSettings.getC_SYSTEMNAME());
			param.put("currencyCode", systemSettings.getC_CURRENCYCODE());
			param.put("bankCode", systemSettings.getC_BANKCODE());		
			param.put("monthAndYear", monthAndYear);
			param.put("userName",userName);
			System.out.println("jasper->"+jasper);
			System.out.println("reportFileName	->"+reportFileName);
		}
		else if (operation != null && operation.trim().equalsIgnoreCase("userReport")) 
		{			
			String userName    	= request.getSession().getAttribute("userName")!=null?(String)request.getSession().getAttribute("userName"):"";
			
			param =request.getAttribute("map")!=null ?(Map)request.getAttribute("map") : new HashMap();
			SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
			SystemSettings systemSettings = systemSettingDao.getSystemSettings();
			if (systemSettings.getC_SYSTEMNAME() == null) {
				System.out.println("none");
			}
			System.out.println("sysname: " + systemSettings.getC_SYSTEMNAME());
			param.put("systemName", systemSettings.getC_SYSTEMNAME());			
			param.put("userName",userName);
			param.put("currentDate", DateHelper.format(date.newDate())); //before: new java.util.Date
			param.put("userFilter",Integer.parseInt(request.getParameter("userReportFilter")));
			jasper="/report/userList.jasper";
			reportFileName = getServletContext().getRealPath(jasper);
		}
		
		else if (operation != null && operation.trim().equalsIgnoreCase("roleMatrix")) 
		{			
			String userName    	= request.getSession().getAttribute("userName")!=null?(String)request.getSession().getAttribute("userName"):"";
			String role    	= request.getParameter("role")!=null?(String)request.getParameter("role"):"";
			
			param =request.getAttribute("map")!=null ?(Map)request.getAttribute("map") : new HashMap();
			SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
			SystemSettings systemSettings = systemSettingDao.getSystemSettings();
		
			param.put("systemName", systemSettings.getC_SYSTEMNAME());			
			param.put("userName",userName);
			param.put("role", role);
			param.put("currentDate", DateHelper.format(date.newDate())); //before: new java.util.Date
			
			if (role.trim() == "" || role.equalsIgnoreCase("ALL")) {
				jasper="/report/roleListingAll.jasper";
			}
			else {
				jasper="/report/roleListing.jasper";
			}
			reportFileName = getServletContext().getRealPath(jasper);
		}
		else 
		{
			String branchCode = (request.getParameter("branchCode") !=null ? (String)request.getParameter("branchCode") : "");
			String userID    	= request.getParameter("userID")!=null?(String)request.getParameter("userID"):"";
			String startDate = request.getParameter("startDate")!=null?(String)request.getParameter("startDate"):DateHelper.format(date.newDate()); //before: new java.util.Date
			String endDate = request.getParameter("endDate")!=null?(String)request.getParameter("endDate"):DateHelper.format(date.newDate()); //before: new java.util.Date
			String userName    	= request.getSession().getAttribute("userName")!=null?(String)request.getSession().getAttribute("userName"):"";
			
			System.out.println("branchCode: " + branchCode + "user:" + userID + "startDate: " + startDate);
			System.out.println("startDate:" + request.getParameter("startDate").toString()); 
			
			jasper = request.getAttribute("jasper")!=null?(String)request.getAttribute("jasper"):"/report/auditLogs.jasper";
			reportFileName = getServletContext().getRealPath(jasper);
			
			ds = new AuditLogsField(startDate, endDate, branchCode, userID);
			
			param =request.getAttribute("map")!=null ?(Map)request.getAttribute("map") : new HashMap();
			SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
			SystemSettings systemSettings = systemSettingDao.getSystemSettings();
		
			param.put("systemName", systemSettings.getC_SYSTEMNAME());			
			param.put("userName",userName);
			param.put("currentDate", DateHelper.format(date.newDate())); ////before: new java.util.Date
			param.put("dateRange", startDate + "-" + endDate);
			
			System.out.println("jasper->"+jasper);
			System.out.println("reportFileName	->"+reportFileName);			
		}
		
		JasperPrint jasperPrint=null;		
		
		File reportFile = new File(reportFileName);
		if (!reportFile.exists()) {
			System.out.println("No source File");
			throw new JRRuntimeException("File WebappReport.jasper not found. The report design must be compiled first.");
		}		
		
		OutputStream outputStream = response.getOutputStream();
		
		if (operation.equalsIgnoreCase("userReport") || operation.equalsIgnoreCase("roleMatrix")){			
			FactorConnection factor= new FactorConnection();
			jasperPrint = JasperFillManager.fillReport(reportFileName,param,factor.getConnection());
		}
		else {
			jasperPrint = JasperFillManager.fillReport(reportFileName,param,ds);
		}
		
		try
		{			
			response.setContentType("application/ms-excel");
			JRXlsExporter exporterXLS = new JRXlsExporter();
			exporterXLS.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			exporterXLS.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
	        exporterXLS.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.FALSE);
	        exporterXLS.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.TRUE);               
			exporterXLS.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
			exporterXLS.exportReport();
			outputStream.close();
		}
		catch(JRException e)
		{
			if (outputStream != null )outputStream.close();
		}
		finally 
		{
			if (outputStream != null )outputStream.close();
		}
		
		/*response.setContentType("application/pdf");
		response.addHeader("Content-Disposition", "attachment; filename=" + jasper);
		response.setContentLength((int) pdfFile.length());

		FileInputStream fileInputStream = new FileInputStream(pdfFile);
		OutputStream responseOutputStream = response.getOutputStream();
		int bytes;
		while ((bytes = fileInputStream.read()) != -1) {
			responseOutputStream.write(bytes);
		}*/
	}

}
