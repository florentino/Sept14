package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.PDC;

public class PdcUtility {
private static PdcUtility pdcInstance = new PdcUtility();
	
	private PdcUtility() {}
	
	public static PdcUtility getInstance() {
		return pdcInstance;
	}
	
	
	public PDC toObject(Map m) {
		
		HashMap map = (HashMap) m;
		PDC pdc = new PDC();
		System.out.println("size!!!>>>>" + map.get("N_REFNO").toString().trim().length());
		pdc.setN_RefNo(map.get("N_REFNO") != null && map.get("N_REFNO").toString().trim().length() > 0 ? Integer.parseInt(map.get("N_REFNO").toString()) : 0);
		pdc.setB_Processed((String) map.get("B_PROCESSED") != null ? ((String) map.get("B_PROCESSED")).trim() : "0");
		pdc.setC_BankCode((String) map.get("C_BANKCODE") != null ? ((String) map.get("C_BANKCODE")).trim() : "");
		pdc.setC_CheckTypeCode((String) map.get("C_CHECKTYPCODE") != null ? ((String) map.get("C_CHECKTYPCODE")).trim() : "");
		pdc.setC_ClntCode((String) map.get("C_CLNTCODE") != null ? ((String) map.get("C_CLNTCODE")).trim() : "");
		pdc.setC_CustCode((String) map.get("C_CUSTCODE") != null ? ((String) map.get("C_CUSTCODE")).trim() : "");
		pdc.setC_Receiver((String) map.get("C_RECEIVER") != null ? ((String) map.get("C_RECEIVER")).trim() : "");
		pdc.setD_CheckedDate(map.get("D_CHECKEDDATE") != null ? DateHelper.parse((String) map.get("D_CHECKEDDATE")) : null);
		pdc.setD_DateBounced(map.get("D_DATEBOUNCED") != null ? DateHelper.parse((String) map.get("D_DATEBOUNCED")) : null);
		pdc.setD_DepositDate(map.get("D_DEPOSITDATE") != null ? DateHelper.parse((String) map.get("D_DEPOSITDATE")) : null);
		pdc.setD_ReceivedDate(map.get("D_RECEIVEDDATE") != null ? DateHelper.parse((String) map.get("D_RECEIVEDDATE")) : null);
		pdc.setN_CheckAmount(map.get("N_CHECKAMOUNT") != null ? Double.parseDouble(((String) map.get("N_CHECKAMOUNT")).replaceAll(",","")) : 0);
		pdc.setN_CheckNo((String) map.get("N_CHECKNO") != null ? ((String) map.get("N_CHECKNO")).trim() : "");
		pdc.setC_BranchCode((String) map.get("C_BRANCHCODE") != null ? map.get("C_BRANCHCODE").toString().trim() : null);
		return pdc;
	}
}
