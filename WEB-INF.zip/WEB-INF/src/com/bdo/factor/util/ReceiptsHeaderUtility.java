package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.ReceiptsHeader;

public class ReceiptsHeaderUtility {
	
	public static ReceiptsHeader toObject(Map m) {
		
		HashMap map = (HashMap) m;
		ReceiptsHeader rHeader = new ReceiptsHeader();
		
		rHeader.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		rHeader.setC_Ams((String) map.get("C_AMS"));
		rHeader.setC_BankCode((String) map.get("C_BANKCODE"));
		rHeader.setC_CheckNo((String) map.get("C_CHECKNO"));
		rHeader.setC_CheckType((String) map.get("C_CHECKTYPE"));
		rHeader.setC_ClntCode(Long.parseLong(map.get("C_CLNTCODE").toString()));
		rHeader.setC_ReceiptType((String) map.get("C_RECEIPTTYPEVAL"));
		rHeader.setC_CustCode(Long.parseLong(map.get("C_CUSTCODE").toString().trim()));
		rHeader.setC_Status((String) map.get("C_STATUS"));
		rHeader.setB_FromPDC(map.get("B_FROMPDC") != null ? map.get("B_FROMPDC").toString() : "0");
		rHeader.setD_CheckDate(DateHelper.parse((String) map.get("D_CHECKDATE")));
		rHeader.setD_ClearingDate(DateHelper.parse((String) map.get("D_CLEARINGDATE")));
		rHeader.setD_TransactionDate(DateHelper.parse((String) map.get("D_TRANSACTIONDATE")));
		rHeader.setN_Amount(Double.parseDouble(map.get("N_AMOUNT").toString().replaceAll(",", "")));		
		rHeader.setN_OrigAmount(map.get("N_ORIGAMOUNT") != null ? Double.parseDouble(map.get("N_ORIGAMOUNT").toString().replaceAll(",", "")) : 0);
		rHeader.setC_CurrencyCode(map.get("C_CURRENCYCODE") != null ? map.get("C_CURRENCYCODE").toString() : "");
		//rHeader.setN_ExchangeRate(map.get("N_EXCHANGERATE") != null ? Double.parseDouble(map.get("N_EXCHANGERATE").toString()) : 0);		
		rHeader.setN_CashDelay(map.get("C_NOOFDAYS")!= null && map.get("C_NOOFDAYS").toString().trim() != "" ? Double.parseDouble(map.get("C_NOOFDAYS").toString()) : 0);
		rHeader.setN_RefundDays(map.get("N_REFUNDDAYS") != null && map.get("N_REFUNDDAYS").toString().trim() != "" ? Integer.parseInt(map.get("N_REFUNDDAYS").toString()): 0);
				
		return rHeader;
	}
}
