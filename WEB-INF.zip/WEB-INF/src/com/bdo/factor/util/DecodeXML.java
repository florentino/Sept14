package com.bdo.factor.util;


import com.bdo.factor.service.SecurityService;
import com.bdo.factor.util.XMLParser;







import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLDecoder;

import javax.servlet.ServletContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DecodeXML {
	private static ServletContext context;
	public  String xmlDecoder(String tagName){
		
		try {
			 String path = getClass().getProtectionDomain().getCodeSource().getLocation().toString().replace("/WEB-INF/classes", "").replace("file:/", "").replace("%20", " ") + "xml-config/wservice-account.xml";

		File xmlFile = new File(path);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		
		Document doc =  dBuilder.parse(xmlFile);			
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName(tagName);
		if (nList!=null &&nList.getLength()>0){
			NodeList subList = nList.item(0).getChildNodes();
			
			if(subList!=null&&subList.getLength()>0){
				return subList.item(0).getNodeValue();
			}
			
		}
		
		
		
		} catch (SAXException | IOException | ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	

}
