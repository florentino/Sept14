package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.BLRFile;
import com.bdo.factor.beans.CheckType;

public class BLRFileUtility {
	public static Map toMap(BLRFile blrFile){
		Map map = new HashMap();
		
		map.put("C_BLRTYPECODE", blrFile.getC_BlrTypeCode());
		map.put("N_BLR1", blrFile.getN_Blr1());
		map.put("D_EFFDT1", blrFile.getD_EffDt1());
		map.put("D_EXPDT1", blrFile.getD_ExpDt1());
		map.put("N_BLR2", blrFile.getN_Blr2());
		map.put("D_EFFDT2", blrFile.getD_EffDt2());
		map.put("D_EXPDT2", blrFile.getD_ExpDt2());
		map.put("N_BLR3", blrFile.getN_Blr3());
		map.put("D_EFFDT3", blrFile.getD_EffDt3());
		map.put("D_EXPDT3", blrFile.getD_ExpDt3());
		map.put("N_BLR4", blrFile.getN_Blr4());
		map.put("D_EFFDT4", blrFile.getD_EffDt4());
		map.put("D_EXPDT4", blrFile.getD_ExpDt4());
		map.put("N_BLR5", blrFile.getN_Blr5());
		map.put("D_EFFDT5", blrFile.getD_EffDt5());
		map.put("D_EXPDT5", blrFile.getD_ExpDt5());
		
		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static BLRFile toObject(Map m) {		
		BLRFile blrFile = new BLRFile();
		
		blrFile.setC_BlrTypeCode((String) m.get("C_BLRTYPECODE"));		
		blrFile.setN_Blr1(Double.parseDouble(m.get("N_BLR1").toString()));
		blrFile.setD_EffDt1(DateHelper.parse(m.get("D_EFFDT1").toString()));
		blrFile.setD_ExpDt1(DateHelper.parse(m.get("D_EXPDT1").toString()));
		blrFile.setN_Blr2(Double.parseDouble(m.get("N_BLR2").toString()));
		blrFile.setD_EffDt2(DateHelper.parse(m.get("D_EFFDT2").toString()));
		blrFile.setD_ExpDt2(DateHelper.parse(m.get("D_EXPDT2").toString()));
		blrFile.setN_Blr3(Double.parseDouble(m.get("N_BLR3").toString()));
		blrFile.setD_EffDt3(DateHelper.parse(m.get("D_EFFDT3").toString()));
		blrFile.setD_ExpDt3(DateHelper.parse(m.get("D_EXPDT3").toString()));
		blrFile.setN_Blr4(Double.parseDouble(m.get("N_BLR4").toString()));
		blrFile.setD_EffDt4(DateHelper.parse(m.get("D_EFFDT4").toString()));
		blrFile.setD_ExpDt4(DateHelper.parse(m.get("D_EXPDT4").toString()));
		blrFile.setN_Blr5(Double.parseDouble(m.get("N_BLR5").toString()));
		blrFile.setD_EffDt5(DateHelper.parse(m.get("D_EFFDT5").toString()));
		blrFile.setD_ExpDt5(DateHelper.parse(m.get("D_EXPDT5").toString()));
		
		return blrFile;		
	}	
}
