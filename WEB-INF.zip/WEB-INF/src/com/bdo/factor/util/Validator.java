package com.bdo.factor.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator 
{
	private final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	
	public boolean isValidDateFormat(String date){
		Calendar s = Calendar.getInstance();
		dateFormat.setLenient(false);
		if(date.isEmpty())
			return false;
		try{
			s.setTime(dateFormat.parse(date));
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	return true;
	}
	
	final Pattern whiteList = Pattern.compile("[^a-z A-Z 0-9]");
	public boolean validString(String str){
		Matcher s = whiteList.matcher(str);
		//if false, invalid character found
		return !s.find();//negate so it will output true all character is within list
	}
	
	public boolean validBranchCode(String s){
		try{
			if(s.length()==2)
				Integer.parseInt(s);
			else
				return false;
		}catch(NumberFormatException nfe){
			return false;
		}
		return true;
	}
	
	public boolean validClientCode(String s){
		try{
		 
				Long.parseLong(s);
			 
		}catch(NumberFormatException nfe){
			return false;
		}
		return true;
	}
	
	public boolean validReportType(String reportType){
		if (reportType.contentEquals("XLS")){
			return true;
		}
		else if(reportType.contentEquals("PDF")){
			return true;
		}
		else
			return false;
	}
	
	public boolean stringIsValid(String str)
    {
		boolean b = true;
        if(str != null)
        {
            Pattern p = Pattern.compile("[!@#$%^&*()-+=]");
            Matcher m = p.matcher(str);
            if (m.find())
            {
            	b = false;
            }
        }
        return b;
    }
	
	private static final Pattern numeric = Pattern.compile("[^0-9]");
	public boolean isValidGLCode(String glCode){
		boolean b = true;
        if(glCode != null)
        {
            Matcher m = numeric.matcher(glCode);
            if (m.find())
            {
            	b = false;
            }
        }
		return b;
	}
	
	public boolean stringIsValid2(String str)
    {
        boolean OK = str != null && !str.equals("") && str.indexOf('&') == -1 && str.length() > 0 && str.indexOf('\'') == -1;
        return OK;
    }
	
	public boolean nameIsValid(String str)
    {
        return stringIsValid(str) && str.length() >= 0;
    }
	
	public boolean nameIsValid2(String str)
    {
        return stringIsValid(str) && str.length() >= 2 && str.indexOf(" ") < 0;
    }
	
	public boolean emailIsValid(String str)
    {
        boolean OK = str != null && !str.equals("") && str.indexOf('&') == -1 && str.indexOf(',') == -1 && str.indexOf('\'') == -1;
        if(OK)
        {
            StringTokenizer st = new StringTokenizer(str, "@");
            if(st == null || st.countTokens() != 2)
            {
                OK = false;
            } else
            {
                String user = st.nextToken();
                String host = st.nextToken();
                OK = user.length() >= 2 && host.length() >= 2 && host.indexOf('.') >= 0;
            }
        }
        return OK;
    }
	
	public boolean passwordIsValid(String str)
    {
		boolean b = false;
		
		b = (this.isNumberFoundInStr(str) && !this.stringIsValid(str) && this.isUpperCaseFoundInStr(str) && this.isLowerCaseFoundInStr(str));
		
		return b;
    }
	
	private boolean isNumberFoundInStr(String str)
    {
		boolean b = false;
        if(str != null)
        {
            Pattern p = Pattern.compile("[1234567890]");
            Matcher m = p.matcher(str);
            if (m.find())
            {
            	b = true;
            }
        }
        return b;
    }
	
	private boolean isUpperCaseFoundInStr(String str)
    {
		boolean b = false;
        if(str != null)
        {
            Pattern p = Pattern.compile("[ABCDEFGHIJKLMN�OPQRSTUVWXYZ]");
            Matcher m = p.matcher(str);
            if (m.find())
            {
            	b = true;
            }
        }
        return b;
    }
	
	private boolean isLowerCaseFoundInStr(String str)
    {
		boolean b = false;
        if(str != null)
        {
            Pattern p = Pattern.compile("[abcdefghijklmn�opqrstuvwxyz]");
            Matcher m = p.matcher(str);
            if (m.find())
            {
            	b = true;
            }
        }
        return b;
    }
	
	@SuppressWarnings("unused")
	public boolean isNumeric(String str)
	{
		boolean retval = false;
		try
		{
			Integer.parseInt(str);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	
	public static void main (String[] args)
	{
		Validator v = new Validator();
		System.out.println(v.isNumeric("100a"));		
	}
}
