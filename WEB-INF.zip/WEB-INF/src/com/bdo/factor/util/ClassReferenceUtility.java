package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.ClassReference;

public final class ClassReferenceUtility {
	
	public static Map toMap(ClassReference b){
		Map map = new HashMap();
		map.put("CLASS_NAME", b.getCLASS_NAME());
		map.put("CLASS_DESC", b.getCLASS_DESC());
		map.put("URL", b.getURL());

		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static ClassReference toObject(Map map) {		
		ClassReference b = new ClassReference();
		
		b.setCLASS_NAME((String) map.get("CLASS_NAME"));
		b.setCLASS_DESC((String) map.get("CLASS_DESC"));
		b.setURL((String) map.get("URL"));
		
		return b;		
	}
}
