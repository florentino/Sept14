package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Branch;

public final class BranchUtility {
	
	public static Map toMap(Branch branch){
		Map map = new HashMap();
		map.put("C_BRANCHCODE", branch.getC_BrCode());
		map.put("C_BRANCHNAME", branch.getC_BrName());
		
		
		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static Branch toObject(Map map) {
		
		Branch branch= new Branch();
		
		branch.setC_BrCode((String) map.get("C_BRANCHCODE"));
		branch.setC_BrName((String) map.get("C_BRANCHNAME"));
				
		return branch;		
	}
}
