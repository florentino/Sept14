package com.bdo.factor.util;

import java.security.*;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang.ArrayUtils;



public class EncryptorUtil 
{	

	public String getEncryptedPassword(String passWord)
	{
		String retval = "";
		
		byte[] defaultBytes = passWord.getBytes();
		
		try 
		{			
			MessageDigest algorithm = MessageDigest.getInstance("MD5");
			algorithm.reset();
		    algorithm.update(defaultBytes);
		    byte messageDigest[] = algorithm.digest();
		    
		    StringBuffer hexString = new StringBuffer();
		    for (int i=0;i<messageDigest.length;i++) 
		    {
		        hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
		    }		    
		    
		    retval = hexString.toString();
		    
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retval;
	}
	
	//AES Encryptor CVG 041017
	public  byte[] encryptText(String plainText, SecretKey secKey)throws Exception{
		Cipher aesCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		aesCipher.init(Cipher.ENCRYPT_MODE, secKey);
		
		byte[] byteCipherText = aesCipher.doFinal(plainText.getBytes());
		return byteCipherText;
	} //end
	
	//WebServiceEncryptor
	public  String encryptText2(String plainText, String encryptionKey,String keySpecs, String algorithm)throws Exception{
		SecretKey secKey = new SecretKeySpec(encryptionKey.getBytes(), keySpecs);
		
		Cipher aesCipher = Cipher.getInstance(algorithm);
		aesCipher.init(Cipher.ENCRYPT_MODE, secKey);
		
		byte[] byteCipherText = aesCipher.doFinal(plainText.getBytes());
		byte[] iv = aesCipher.getIV();
		byte[] combine = ArrayUtils.addAll(iv, byteCipherText);
		String encrypted = Base64.getEncoder().encodeToString(combine);
		return encrypted;
	} 
	public SecretKeySpec generateSecretKey(String key) throws Exception{		
		return new SecretKeySpec(key.getBytes(), "AES");
	}
	public static void main(String[] args)
	{
		EncryptorUtil enc = new EncryptorUtil();
		String pass = "madman";
		if (enc.getEncryptedPassword("madman").equals(enc.getEncryptedPassword(pass)))
		{
			System.out.println("Password correct...");
			System.out.println("0-->" + enc.getEncryptedPassword("0"));
			System.out.println(enc.getEncryptedPassword(enc.getEncryptedPassword(pass)));
		}
		else
		{
			System.out.println("Invalid password...");
		}
	}
	
}
