package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Currency;

public final class CurrencyUtility {
	
	private static CurrencyUtility currencyUtilityInstance = new CurrencyUtility();
	
	private CurrencyUtility() {}
	
	public static CurrencyUtility getInstance() {
		return currencyUtilityInstance;
	}
	
	
	public Map toMap(Currency currency) {
		Map map = new HashMap();
		map.put("C_CURRENCYCODE", currency.getC_CurrencyCode());
		map.put("D_RATEDATE", currency.getD_RateDate());
		map.put("C_DESCRIPTION", currency.getC_Description());
		map.put("N_EXCHANGERATE", currency.getN_ExchangeRate());

		return map;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////

	public Currency toObject(Map map) {
		Currency currency = new Currency();

		currency.setC_CurrencyCode((String) map.get("C_CURRENCYCODE"));
		currency.setD_RateDate(DateHelper.parse(map.get("D_RATEDATE").toString()));
		currency.setC_Description((String) map.get("C_DESCRIPTION"));
		currency.setN_ExchangeRate(Double.parseDouble(map.get("N_EXCHANGERATE").toString()));

		return currency;

	}
}
