package com.bdo.factor.util;


import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bdo.factor.beans.User;


public class LogonValidator implements Validator {

   public boolean supports(Class clazz) {
        return clazz.equals(User.class);
    }

    public void validate(Object obj, Errors errors) {
        User user = (User) obj;
        if (user == null) {
            errors.rejectValue("username", "error.login.not-specified", null,
                    "Value required.");
        } else {
            System.out.println("Validating user credentials for: "
                    + user.getC_UserName());
            
            if (user.getC_UserName().equals("guest") == false) {
                errors.rejectValue("username", "error.login.invalid-user",
                        null, "Incorrect Username.");
            } else {
                if (user.getC_PassW().equals("guest") == false) {
                    errors.rejectValue("password", "error.login.invalid-pass",
                            null, "Incorrect Password.");
                }
            }

        }
    }

}
