package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.RoleModule;

public final class RoleModuleUtility {
	
	public static Map toMap(RoleModule b){
		Map map = new HashMap();
		map.put("ROLE", b.getROLE());
		map.put("MOD_NAME", b.getMOD_NAME());

		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static RoleModule toObject(Map map) {		
		RoleModule b = new RoleModule();
		
		b.setROLE((String) map.get("ROLE"));
		b.setMOD_NAME((String) map.get("MOD_NAME"));
		
		return b;		
	}
}
