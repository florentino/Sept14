package com.bdo.factor.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jfree.util.Log;
import org.apache.log4j.Logger;

import com.bdo.factor.service.BankService;
import com.bdo.factor.service.SecurityService;



public final class JQGridJSONFormatter {

///////////////////////////////////////////////////////////////////////////////////////////////////////

	//Don't let anyone instantiate this class...
	private JQGridJSONFormatter() { }
	private static Logger log = Logger.getLogger(JQGridJSONFormatter.class);
///////////////////////////////////////////////////////////////////////////////////////////////////////
	                
	public static Map formatDataToJSON(List dataParam,String totalRecordsParam,String currentPageParam,String totalPagesParam){
		
		HashMap ibatisHashMap = new HashMap();
		List<String> rowData = new ArrayList<String>();
		HashMap singleRow = new HashMap();
		List allRows = new ArrayList();
		HashMap jqGridData = new HashMap();
		
		allRows = new ArrayList();
	    HashMap s = new HashMap();
	    Iterator iterator;
	    String keyName;
	    for(int outerCnt=0;outerCnt<dataParam.size();outerCnt++){
	    	
	    	s= (HashMap)dataParam.get(outerCnt);
	    	iterator = s.keySet().iterator();
	    	while(iterator.hasNext()){
	    		keyName = iterator.next().toString();
	    		//removed SecurityUtil.encode, shows xml characters to user by Cherrie Garcia
	    		s.put(keyName, (s.get(keyName)!=null?s.get(keyName).toString():""));
	    	}
	    	
	    	//rowData = new ArrayList<String>();
	    	//singleRow = new HashMap();
	    	//ibatisHashMap = new HashMap();
	    	//ibatisHashMap = (HashMap)dataParam.get(outerCnt);
	    	
		    s.put("id",""+(outerCnt+1));
		    //ibatisHashMap.put("C_NAME", SecurityUtil.encode(((HashMap)dataParam.get(outerCnt)).get("C_NAME").toString()));
		    
		    
		    
		    allRows.add(s);
	    
	    }
	    	    
	    jqGridData.put("total", totalPagesParam);
	    jqGridData.put("page", currentPageParam);
	    	    	    
	    if(dataParam.size()>0){
	    	jqGridData.put("status", "success");
	    }else{
	    	jqGridData.put("status", "zero records");
	    }
	    
	    jqGridData.put("records",totalRecordsParam);
	    jqGridData.put("rows", allRows);
	
	    System.out.println("--->>> allRows SIZE: "+allRows.size());
	    
	    return jqGridData;		
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static ArrayList formatListToJSON(List dataParam){
		
		HashMap ibatisHashMap = (HashMap)dataParam.get(0);
		ArrayList<String> rowData = new ArrayList<String>();
		
		Object[] columnsHeaders = null;
		
		columnsHeaders = ibatisHashMap.keySet().toArray();
		
	    for(int outerCnt=0;outerCnt<dataParam.size();outerCnt++){
	    	//put all data in array//
	    	ibatisHashMap = new HashMap();
	    	ibatisHashMap = (HashMap)dataParam.get(outerCnt);
	    	
		   	rowData.add((String)(ibatisHashMap.get(columnsHeaders[0])));
		   	
		 	System.out.println("++ "+(String)(ibatisHashMap.get(columnsHeaders[0])));
		    
	    }
	    
	    return rowData;		
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static String formatListToString(List dataParam){
		
		HashMap ibatisHashMap = null;
		String rowData = "";
		
		try{
			
			ibatisHashMap = (HashMap)dataParam.get(0);
			Object[] columnsHeaders = null;
			columnsHeaders = ibatisHashMap.keySet().toArray();
			
		    for(int outerCnt=0;outerCnt<dataParam.size();outerCnt++){
		    	//put all data in array//
		    	ibatisHashMap = new HashMap();
		    	ibatisHashMap = (HashMap)dataParam.get(outerCnt);
		    	//removed SecurityUtil.encode, shows xml characters to user by Cherrie Garcia
			   	rowData = rowData + (((String)(ibatisHashMap.get(columnsHeaders[0])))) + "\n";
		    }
		    
		}catch(Throwable x){
			rowData = "";
		}
		
	    return rowData;		
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////
public static String formatListToString2(List dataParam){
		
		HashMap ibatisHashMap = null;
		String rowData = "";
		
		try{
			
			ibatisHashMap = (HashMap)dataParam.get(0);
			Object[] columnsHeaders = null;
			columnsHeaders = ibatisHashMap.keySet().toArray();
			
		    for(int outerCnt=0;outerCnt<dataParam.size();outerCnt++){
		    	
		    	ibatisHashMap = new HashMap();
		    	ibatisHashMap = (HashMap)dataParam.get(outerCnt);
		    	
			   	rowData = rowData + (((String)(ibatisHashMap.get(columnsHeaders[0])))) + ",split,"; //just change '\n' to ','
		    }
		    
		}catch(Throwable x){
			rowData = "";
		}
		
	    return rowData;		
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////
	public static String formatListToJSONSelect(List dataParam,String columnParam,String customerCodeParam){
		
		HashMap ibatisHashMap = new HashMap();
		
		
		String rowData = "{";		
	    for(int outerCnt=0;outerCnt<dataParam.size();outerCnt++){
	    	
	    	ibatisHashMap = new HashMap();
	    	ibatisHashMap = (HashMap)dataParam.get(outerCnt);
	    	
	    	if(ibatisHashMap!=null){
	    	
			    	if(ibatisHashMap.get(columnParam)!=null && ibatisHashMap.get(columnParam).toString().trim().length()!=0 && ibatisHashMap.get(customerCodeParam) !=null && ibatisHashMap.get(customerCodeParam).toString().trim().length()!=0){
			    	
				    	if(outerCnt==(dataParam.size()-1)){
				    		rowData = rowData + "\"" + (ibatisHashMap.get(columnParam).toString().trim()) + "\":" + "\"" + (ibatisHashMap.get(customerCodeParam).toString().trim().replace('"',' '))+ "\"";
				    	}else{
				    		rowData = rowData + "\"" + (ibatisHashMap.get(columnParam).toString().trim()) + "\":" + "\"" + (ibatisHashMap.get(customerCodeParam).toString().trim().replace('"',' '))+ "\",";
				    		
				    	}
			    	}
	    	}
	    	
	    }
	   
	    if(rowData.charAt(rowData.length()-1)==','){
	    	 rowData = rowData.substring(0,rowData.length()-1) + rowData.substring((rowData.length()-1)+1);
	    	
	    }
	    
	    rowData = rowData + "}";
	 

	    return rowData;		
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static String formatDataToXML(List dataParam,String firstColumn,String secondColumn,String thirdColumn,String level,boolean isLeaf,boolean parentId){
		
		String data;
		HashMap ibatisHashMap = new HashMap();
		//List<String> rowData = new ArrayList<String>();
		//HashMap singleRow = new HashMap();
		//List allRows = new ArrayList();
		String jqGridData = "<rows><page>1</page><total>1</total><records>1</records>";
		 
		for(int cnt=0;cnt<dataParam.size();cnt++){	
	    	    
			ibatisHashMap = new HashMap();
			ibatisHashMap = (HashMap)dataParam.get(cnt);
 
			jqGridData = jqGridData + "<row>";
			
			if(ibatisHashMap.containsKey(firstColumn)){
				jqGridData = jqGridData + "<cell>"+ ibatisHashMap.get(firstColumn).toString() +"</cell>";
			}else{
				jqGridData = jqGridData + "<cell>"+""+"</cell>";
			}
			data = (String)ibatisHashMap.get(secondColumn).toString().replaceAll("\\W", " ");
			jqGridData = jqGridData + "<cell>"+data+"</cell>";
			jqGridData = jqGridData + "<cell>"+level+"</cell>";
	
			if(thirdColumn!=null && thirdColumn.trim().length()>0){
				//System.out.println("-->>> 1");
				jqGridData = jqGridData + "<cell>"+ibatisHashMap.get(thirdColumn).toString()+"</cell>";
			}else{
				System.out.println("-->>> 2");
				jqGridData = jqGridData + "<cell>"+"NULL"+"</cell>";
			}
			
			jqGridData = jqGridData + "<cell>"+isLeaf+"</cell>";
			jqGridData = jqGridData + "<cell>false</cell>";
			jqGridData = jqGridData + "</row>";
			
		}
		
		jqGridData = jqGridData + "</rows>";
	    
	    //System.out.println("--->>> allRows SIZE: "+allRows.size());
	    
	    return jqGridData;		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	
	
	
}
