package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Industry;

public class IndustryUtility {
	
	private static IndustryUtility indUtilityInstance = new IndustryUtility();
	
	private IndustryUtility() { }
	
	public static IndustryUtility getInstance() {
		return indUtilityInstance;
	}

	public Map toMap(Industry ind) {
		Map map = new HashMap();
		map.put("C_INDCODE", ind.getC_IndCode());
		map.put("C_INDNAME", ind.getC_IndName());

		return map;
	}

	// /////////////////////////////////////////////////////////////////////////////////////////////

	public Industry toObject(Map map) {
		Industry ind = new Industry();
		ind.setC_IndCode((String) map.get("C_INDCODE"));
		ind.setC_IndName((String) map.get("C_INDNAME"));
		
		return ind;
	}
}
