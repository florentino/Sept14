package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.ModuleClass;

public final class ModuleClassUtility {
	
	public static Map toMap(ModuleClass b){
		Map map = new HashMap();
		map.put("MOD_NAME", b.getMOD_NAME());
		map.put("CLASS_NAME", b.getCLASS_NAME());

		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static ModuleClass toObject(Map map) {		
		ModuleClass b = new ModuleClass();
		
		b.setMOD_NAME((String) map.get("MOD_NAME"));
		b.setCLASS_NAME((String) map.get("CLASS_NAME"));
		
		return b;		
	}
}
