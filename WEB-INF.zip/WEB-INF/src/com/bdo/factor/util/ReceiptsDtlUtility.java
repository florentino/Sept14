package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.ReceiptsDtl;

public class ReceiptsDtlUtility {
	private static ReceiptsDtlUtility receiptsDtlInstance = new ReceiptsDtlUtility();
	
	private ReceiptsDtlUtility() {}
	
	public static ReceiptsDtlUtility getInstance() {
		return receiptsDtlInstance;
	}
	
	
	public ReceiptsDtl toObject(Map m) {
		
		HashMap map = (HashMap) m;
		ReceiptsDtl rDetail = new ReceiptsDtl();
		
		rDetail.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		rDetail.setC_InvoiceNo((String) map.get("C_INVOICENO"));
		rDetail.setN_InvNo(Integer.parseInt(map.get("N_INVNO").toString()));
		rDetail.setC_Type((String) map.get("C_TYPE"));
		rDetail.setD_InvoiceDate(DateHelper.parse((String) map.get("D_INVOICEDATE")));
		rDetail.setN_AmtInv(Double.parseDouble(map.get("N_ORIGINVOICEAMT").toString()));
		rDetail.setN_ReceiptAmt(Double.parseDouble(map.get("N_RECEIPTAMT").toString()));
		rDetail.setN_RefNo(Integer.parseInt(map.get("N_REFNO").toString()));
					
		return rDetail;
	}
}
