package com.bdo.factor.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.ReportField;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.service.HolidayService;

public class DateUtils
{
	private static final DateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyyy-MMM-dd");
	
	private static final Logger log = Logger.getLogger(DateUtils.class);
	private final static DateUtils dateUtilInstance = new DateUtils();

	private static final DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private DateUtils() { }

	public static DateUtils getInstance() {
		return dateUtilInstance;
	}

	/*
   public static void main(String[] args) {
	   DateUtils d = new DateUtils();
	   Date beg = DateHelper.parse("04/29/2009");
	   System.out.println(d.addBusinessDay(beg,21, "01"));
   }
	 */

	public Date addBusinessDay(Date start, int days, String branchCode)
	{    	
		Calendar cal = Calendar.getInstance();
		cal.setTime(start);

		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(start);    	  
		cal2.add(Calendar.DATE, days-1);
		System.out.println("cal: " + cal2.getTime());
		Date end = cal2.getTime();

		HolidayService holidaySvc = HolidayService.getInstance();
		int holidayDays = holidaySvc.getHolidayCountByDate(start, end, branchCode);
		System.out.println("holidayDays: " + holidayDays);

		cal2.add(Calendar.DATE, holidayDays);
		end = cal2.getTime();

		System.out.println("beg: " + DEFAULT_DATE_FORMAT.format(start));
		System.out.println("end: " + DEFAULT_DATE_FORMAT.format(end));
		System.out.println("# days between: " + interval(start, end, new IncludeAllDateRule(), Calendar.DATE));
		System.out.println("# weekdays between: " + interval(start, end, new ExcludeWeekendDateRule(), Calendar.DATE));

		int totalDays = interval(start, end, new IncludeAllDateRule(), Calendar.DATE);        
		int noWeekend = countWeekend(start, end);

		cal.add(Calendar.DATE, totalDays);
		start = cal.getTime();

		while (noWeekend != 0) {
			start = end;
			//System.out.println("weekend #: " + noWeekend);
			cal2.add(Calendar.DATE, noWeekend);
			//System.out.println("end partial: " + cal2.getTime());
			end = cal2.getTime();
			noWeekend = countWeekend(start, end);
		}

		System.out.println("final date: " + end);
		return end;        
	}

	public static int interval(Date beg, Date end, DateRule dateRule, int intervalType)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(beg);

		int count = 0;
		Date now = calendar.getTime();
		while (now.before(end))
		{
			calendar.add(intervalType, 1);
			now = calendar.getTime();
			if (dateRule.include(now))
			{
				++count;
			}
		}

		return count;
	}

	public static int countWeekend(Date beg, Date end)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(beg);

		int count = 0;
		Date now = calendar.getTime();
		while (now.before(end))
		{
			calendar.add(Calendar.DATE, 1);
			now = calendar.getTime();
			int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
			if ((dayOfWeek == Calendar.SATURDAY) || (dayOfWeek == Calendar.SUNDAY))
			{
				++count;
			}
		}

		return count;
	}

	public Date getPreviousBusinessDay(Date processingDate, String branchCode) {
		Date previousDate = null;

		Calendar cal = Calendar.getInstance();
		cal.setTime(processingDate);
		int dayOfWeek = 0;
		boolean isHoliday = false;

		do {
			cal.add(Calendar.DATE, -1);
			previousDate = cal.getTime();
			dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
			HolidayService holidaySvc = HolidayService.getInstance();
			if (dayOfWeek != Calendar.SATURDAY || dayOfWeek != Calendar.SUNDAY) {
				isHoliday = holidaySvc.isHoliday(previousDate, branchCode);
			}
		} while (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY || isHoliday);

		return previousDate;
	}
	
	public boolean isBusinessDay(Date processingDate, String branchCode) {
		Date previousDate = null;

		Calendar cal = Calendar.getInstance();
		cal.setTime(processingDate);
		int dayOfWeek = 0;
		boolean isHoliday = false;
		previousDate = cal.getTime();
		dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		HolidayService holidaySvc = HolidayService.getInstance();
		isHoliday = holidaySvc.isHoliday(previousDate, branchCode);
		
		if(dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY || isHoliday) {
			return false;
		}		

		return true;
	}
	
	public Date getMonthEnd(Date processingDate, String branchCode) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(processingDate);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(cal.DAY_OF_MONTH));
		cal.add(Calendar.DATE, 1);
		return this.getPreviousBusinessDay(cal.getTime(), branchCode);
	}
	
	public Date getNextBusinessDay(Date date1, String branchCode) {
		Date nextDate = null;

		Calendar cal = Calendar.getInstance();
		cal.setTime(date1);
		int dayOfWeek = 0;
		boolean isHoliday = false;

		do {
			cal.add(Calendar.DATE, 1);
			log.info(cal.getTime());
			nextDate = cal.getTime();
			dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
			HolidayService holidaySvc = HolidayService.getInstance();
			if (dayOfWeek != Calendar.SATURDAY || dayOfWeek != Calendar.SUNDAY) {
				isHoliday = holidaySvc.isHoliday(nextDate, branchCode);
			}
		} while (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY || isHoliday);
		log.info("getNextBusinessDay "+nextDate);
		return nextDate;
	}	
	public static void main(String[] args){
		
		//Date d = DateHelper.parse("06/11/2009");
		//DateUtils.getInstance().getNextBusinessDay(d,"02");
		getLastMonthMMM("12/01/2010");
	}	
	
	
	public static Calendar getMonthEndDate(Map map){
		Calendar cal = new GregorianCalendar(); 
		cal.set(Calendar.YEAR, Integer.parseInt(map.get("year").toString()));
		cal.set(Calendar.MONTH, Integer.parseInt(map.get("month").toString()));
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(cal.DAY_OF_MONTH));
		log.info(cal);
		//log.info("calendar "+cal.get(Calendar.MONTH)+"/"+cal.get(Calendar.DAY_OF_MONTH)+"/"+cal.get(Calendar.YEAR));
		return cal;		
	}	
			
	/*
	public static String getMonthName(int month){
		String monthName="";
		switch(month)
		{
			case 0:monthName="January";
			case 1:monthName="February";
			case 2:monthName="March";
			case 3:monthName="April";
			case 4:monthName="May";
			case 5:monthName="June";
			case 6:monthName="July";
			case 7:monthName="August";
			case 8:monthName="September";
			case 9:monthName="October";
			case 10:monthName="November";
			case 11:monthName="December";
		}
		return monthName;
	}
	*/
	
	public static String getMonthName(Date date){
		DateFormat sdf = new SimpleDateFormat("MMMM yyyy");
		return sdf.format(date);
	}	
	
	public static ReportField getFirstAndLastDayOfMonth(String asOfDate){
		
		String[] splitDate = asOfDate.split("/");
		Calendar first = new GregorianCalendar();
		first.set(Calendar.YEAR, Integer.parseInt(splitDate[2]));
		first.set(Calendar.MONTH, Integer.parseInt(splitDate[0])-1);
		log.info("first"+first.getTime());
		first.set(Calendar.DAY_OF_MONTH, first.getActualMinimum(first.DAY_OF_MONTH));		
		Calendar last = new GregorianCalendar();
		last.set(Calendar.YEAR, Integer.parseInt(splitDate[2]));
		last.set(Calendar.MONTH, Integer.parseInt(splitDate[0])-1);
		last.set(Calendar.DAY_OF_MONTH, last.getActualMaximum(last.DAY_OF_MONTH));

		ReportField rf = new ReportField(sdf.format(first.getTime()),sdf.format(last.getTime()));
		return rf;		
	}
	
	//test as of date if latest or last year
	public static boolean isLastYear(String asOfDate){		 
		GregorianCalendar gcAsOfDate = new GregorianCalendar();
		Date date = DateHelper.parse(asOfDate);
		gcAsOfDate.setTime(date);
		FactorsDateDAO factorsDate = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		GregorianCalendar dateToday = new GregorianCalendar();
		
		SimpleDateFormat sdfYear = new SimpleDateFormat("YYYY");
		int newDateToday = Integer.parseInt(sdfYear.format(factorsDate.newDate()));
		
		boolean isLastYear=(newDateToday-1)==gcAsOfDate.get(GregorianCalendar.YEAR); //before: dateToday.get(GregorianCalendar.YEAR)
		return isLastYear;
	}
	
	public static String getLastMonthMMM(String asOfDate){
		Date date = DateHelper.parse(asOfDate); 
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(date);
		boolean isLastYear=isLastYear(asOfDate);
		gc.add(GregorianCalendar.MONTH, -1);		
		log.info("as of date minus 1 month => "+gc.getTime());
		SimpleDateFormat sdf = new SimpleDateFormat("MMM");
		Date month = gc.getTime();			
		String mmm=sdf.format(month).toUpperCase();
		if(mmm.equalsIgnoreCase("DEC")){
			mmm=isLastYear?"PREVYRTWO":"PREVYR";
		}
		else{
			mmm=isLastYear?"PREV"+mmm:mmm;
		}		
		log.info(mmm);
	
		return mmm;
	}
	
	public static Integer getDateMonth(Date date){
		Calendar dateInput = Calendar.getInstance();
		dateInput.setTime(date);
		return dateInput.get(2);
	}
	public static Integer getDateMonth(Date date,Integer noDays){
		Calendar dateInput = Calendar.getInstance();
		dateInput.setTime(date);
		dateInput.add(Calendar.MONTH, noDays);
		return dateInput.get(2);
	}

}


interface DateRule
{
	boolean include(Date d);
}

class ExcludeWeekendDateRule implements DateRule
{
	public boolean include(Date d)
	{
		boolean include = true;

		Calendar calendar = Calendar.getInstance();

		calendar.setTime(d);

		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

		if ((dayOfWeek == Calendar.SATURDAY) || (dayOfWeek == Calendar.SUNDAY))
			include = false;

		return include;
	}
}

class IncludeAllDateRule implements DateRule
{
	public boolean include(Date d)
	{
		return true;
	}
}
