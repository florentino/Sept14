package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.DocStamp;

public final class DocStampUtility {
	
	public static Map toMap(DocStamp b){
		Map map = new HashMap();
		map.put("N_DOCSTAMP", b.getN_DOCSTAMP());
		map.put("D_TRANSACTIONDATE", b.getD_TRANSACTIONDATE());
		map.put("C_USERID", b.getC_USERID());
		map.put("C_BRANCHCODE", b.getC_BRANCHCODE());

		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static DocStamp toObject(Map map) {		
		DocStamp b = new DocStamp();
		
		b.setN_DOCSTAMP((String) map.get("N_DOCSTAMP"));
		b.setD_TRANSACTIONDATE((String) map.get("D_TRANSACTIONDATE"));
		b.setC_USERID((String) map.get("C_USERID"));
		b.setC_BRANCHCODE((String) map.get("C_BRANCHCODE"));
		
		return b;		
	}
}
