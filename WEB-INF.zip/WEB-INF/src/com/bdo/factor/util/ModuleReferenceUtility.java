package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.ModuleReference;

public final class ModuleReferenceUtility {
	
	public static Map toMap(ModuleReference b){
		Map map = new HashMap();
		map.put("MOD_NAME", b.getMOD_NAME());
		map.put("MOD_DESC", b.getMOD_DESC());
		map.put("PARENT_MOD_NAME", b.getPARENT_MOD_NAME());
		map.put("CLASS_ORDER", b.getCLASS_ORDER());
		map.put("SUB_ORDER", b.getSUB_ORDER());
		
		return map;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public static ModuleReference toObject(Map map) {		
		ModuleReference b = new ModuleReference();
		
		b.setMOD_NAME((String) map.get("MOD_NAME"));
		b.setMOD_DESC((String) map.get("MOD_DESC"));
		b.setPARENT_MOD_NAME((String) map.get("PARENT_MOD_NAME"));
		b.setCLASS_ORDER((String) map.get("CLASS_ORDER"));
		b.setSUB_ORDER((String) map.get("SUB_ORDER"));
		
		return b;		
	}
}
