package com.bdo.factor.util;

import java.io.ByteArrayOutputStream;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

public class DecryptorUtil {
	
	//AES Decryptor
	public  String decryptText (byte[] byteCipherText, SecretKey secKey) throws Exception{
		Cipher aesCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		aesCipher.init(Cipher.DECRYPT_MODE, secKey);
		
		byte[] bytePlainText = aesCipher.doFinal(byteCipherText);
		return new String (bytePlainText);
		
	}
	
	//encrypt
	public  String bytesToHex(byte[] hash){
		return DatatypeConverter.printHexBinary(hash);
	}
	
	//decrypt
	public  byte[] HextoByte(String hex){
		ByteArrayOutputStream byteA = new ByteArrayOutputStream(hex.length() / 2);
		
		for ( int i = 0; i < hex.length(); i+=2){
			String output = hex.substring (i,i+2);
			int decimal = Integer.parseInt(output, 16);
			byteA.write(decimal);
		}
		return byteA.toByteArray();
	}
	
	//SecretKey
	public SecretKeySpec generateSecretKey() throws Exception{
		MessageDigest shahash = MessageDigest.getInstance("SHA-1");
		byte[] key = shahash.digest();
		key = Arrays.copyOf(key, 16);
		return new SecretKeySpec(key, "AES");
	}

}
