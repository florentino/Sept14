/**
 *	Added by: Roldan Somontina
 *	Date	: July 4, 2009
 *  Usage	: Number Conversion to Word
 *  Version	: 1.0
 */
package com.bdo.factor.util;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

public class Money {
	
	private static Logger log = Logger.getLogger(Money.class);
	
	public String getSingleDigitWord(long digit){
		String word=(digit==1)?"One":(digit==2)?"Two":(digit==3)?"Three":(digit==4)?"Four":(digit==5)?"Five":
			  (digit==6)?"Six":(digit==7)?"Seven":(digit==8)?"Eight":(digit==9)?"Nine":"";
		return word;
	}
	
	public String getTwoDigitWord(long digit){
		String word=(digit==1)?"Ten":(digit==2)?"Twenty":(digit==3)?"Thirty":(digit==4)?"Forty":(digit==5)?"Fifty":
			  (digit==6)?"Sixty":(digit==7)?"Seventy":(digit==8)?"Eighty":(digit==9)?"Ninety":"";
		return word;
	}	
	
	public String getTeens(long digit){
		String word=(digit==1)?"Eleven":(digit==2)?"Twelve":(digit==3)?"Thirteen":(digit==4)?"Fourteen":(digit==5)?"Fifteen":
			  (digit==6)?"Sixteen":(digit==7)?"Seventeen":(digit==8)?"Eighteen":(digit==9)?"Nineteen":"Ten";		
		return word;
	}
	
	public String getThreeDigitInWord(long digit){
		log.info(digit);
		long hundreds=digit/100;
		long tens=(digit%100)/10;
		long ones =(digit%100)%10;
		String onesWord="";
		String tensWord="";
		String hundredsWord="";
		if(hundreds>0){
			hundredsWord=getSingleDigitWord(hundreds)+" Hundred ";
			
		}
		if(tens>1){
			tensWord=getTwoDigitWord(tens)+" "+getSingleDigitWord(ones);
		}
		else if(tens==1){
			tensWord=getTeens(ones);				
		}
		else{
			onesWord=(ones!=0)?getSingleDigitWord(ones):"Zero";			
		}
		log.info(hundreds);
		log.info(tens);
		log.info(ones);	
		String retVal=hundredsWord+tensWord+onesWord;
		return retVal;
	}
	
	
	
	public String getMoneyInWord(double money){
		
		BigDecimal bg = new BigDecimal(money);
		String retVal="";
		String str = ((Object)bg.setScale(2, BigDecimal.ROUND_HALF_UP)).toString();
		String[] splt = str.split("\\.");
		log.info("whole number: "+splt[0]);
		log.info("whole number length: "+splt[0].length());
		log.info("decimal value: "+(splt[1]+"/"+100));
		int lng=splt[0].length();

		long digit= (money<0)?Math.abs(Long.parseLong(splt[0])):Long.parseLong(splt[0]);
		if(lng<4){
			retVal=getThreeDigitInWord(digit);
		}
		else if(lng<7){
			if(digit%1000!=0){
				retVal=getThreeDigitInWord(digit/1000)+" Thousand "
				+getThreeDigitInWord(digit%1000);				
			}
			else{
				retVal=getThreeDigitInWord(digit/1000)+" Thousand";				
			}

		}
		else if(lng<10){
			if(((digit%1000000)/1000!=0) && ((digit%1000000)%1000!=0)){
				retVal=getThreeDigitInWord((digit%1000000000)/1000000)+" Million "
				+getThreeDigitInWord((digit%1000000)/1000)+" Thousand "
				+getThreeDigitInWord((digit%1000000)%1000);				
			}
			else if(((digit%1000000)/1000!=0) && ((digit%1000000)%1000==0)){
				retVal=getThreeDigitInWord((digit%1000000000)/1000000)+" Million "
				+getThreeDigitInWord((digit%1000000)/1000)+" Thousand";				
			}
			else if(((digit%1000000)/1000==0) && ((digit%1000000)%1000==0)){
				retVal=getThreeDigitInWord((digit%1000000000)/1000000)+" Million";				
			}			

		}
		else if(lng<13){
			if((((digit%1000000000)%1000000)%1000!=0) && ((digit%1000000)/1000!=0) && ((digit%1000000000)/1000000!=0)){
				retVal=getThreeDigitInWord((digit%Long.parseLong("1000000000000"))/1000000000)+" Billion "
						+getThreeDigitInWord((digit%1000000000)/1000000)+" Million "
						+getThreeDigitInWord((digit%1000000)/1000)+" Thousand "
						+getThreeDigitInWord(((digit%1000000000)%1000000)%1000);			
			}
			else if((((digit%1000000000)%1000000)%1000==0) && ((digit%1000000)/1000!=0) && ((digit%1000000000)/1000000!=0)){
				retVal=getThreeDigitInWord((digit%Long.parseLong("1000000000000"))/1000000000)+" Billion "
				+getThreeDigitInWord((digit%1000000000)/1000000)+" Million "
				+getThreeDigitInWord((digit%1000000)/1000)+" Thousand";			
			}
			else if((((digit%1000000000)%1000000)%1000==0) && ((digit%1000000)/1000==0) && ((digit%1000000000)/1000000!=0)){
				retVal=getThreeDigitInWord((digit%Long.parseLong("1000000000000"))/1000000000)+" Billion "
				+getThreeDigitInWord((digit%1000000000)/1000000)+" Million";			
			}
			else if((((digit%1000000000)%1000000)%1000==0) && ((digit%1000000)/1000==0) && ((digit%1000000000)/1000000==0)){
				retVal=getThreeDigitInWord((digit%Long.parseLong("1000000000000"))/1000000000)+" Billion";			
			}				
		}
		retVal+=" and "+(splt[1]+"/"+100);
		retVal=(money<0)?"Negative "+retVal:retVal;
		return retVal;
	}
	
	public static void main(String[] args){
		Money m = new Money();
		//log.info(m.getThreeDigitInWord(509));	
		//log.info(m.getThreeDigitInWord(0));
		
		
		
		//log.info("getting hundred of million "+(999888541%1000000)%1000);
		//log.info("getting thousand of million "+(999888541%1000000)/1000);
		//log.info("getting million of million "+(999888541%1000000000)/1000000);
		
		//log.info("getting hundred of billion "+((Long.parseLong("777999888541")%1000000000)%1000000)%1000);
		//log.info("getting thousand of billion "+(Long.parseLong("777999888541")%1000000)/1000);
		//log.info("getting million of billion "+(Long.parseLong("777999888541")%1000000000)/1000000);
		//log.info("getting billion of billion "+(Long.parseLong("777999888541")%Long.parseLong("1000000000000"))/1000000000);
		
		//log.info("getting hundred "+777888500/1000);
		//log.info(888500000%1000000);
		//log.info(888500000/1000000);		
		log.info(m.getMoneyInWord(-54879699.97));
		
		log.info(m.doRoundOff(50999999.18999));
		log.info(m.doRoundOff(56955.33));
		log.info(m.doRoundOff(198682.40));
		log.info(m.doRoundOff(2123546.18));
		log.info(m.doRoundOff(260152.87));
		log.info(m.doRoundOff(380075.76));
		log.info(m.doRoundOff(980021.27));
		log.info(m.doRoundOff(56955.33)+m.doRoundOff(198682.40)+m.doRoundOff(2123546.18)+m.doRoundOff(260152.87)+m.doRoundOff(380075.76)+m.doRoundOff(980021.27));
	}

	
/*	public static double doRoundOff(double num){
		int r = (int)(1000 * num) % 10;
		int realNum = (int)(100 * num) % 10;
		int temp =(int)(100 * num);
		//log.info("r"+r);
		double result = (double)temp ;
		//log.info("result: "+result);
		if((r>=5 && r<=9)){//||(r==5&& realNum%2!=0)){
        	result += 1;
        }
		result /= 100;
		return result;
	}*/	
	
public static double doRoundOff(double num){
		
		BigDecimal bd = new BigDecimal(Double.toString(num));
	    bd = bd.setScale(2,BigDecimal.ROUND_HALF_UP);
	    return bd.doubleValue();
	}
	
/* Ronel   public static void main(String[] args) {
			double db = 358888000000.1254567890;
	
			System.out.println(" Double = "+ db );
			BigDecimal big = new BigDecimal( db );
			System.out.println(" big = "+big);
			System.out.println(" rounded big = "+big.setScale (2,
			BigDecimal.ROUND_HALF_UP));
			System.out.println(" back to double = " + new Double(
			big.doubleValue() ));
	
		}*/
}
