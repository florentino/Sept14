package com.bdo.factor.util;

import javax.crypto.SecretKey;

import org.apache.commons.dbcp.BasicDataSource;

public class DataSourceWrapper extends BasicDataSource{
	
	public DataSourceWrapper(){
		super();
	}

	@Override
	public synchronized void setPassword(String password) {
		
			//this.password = "P@ssword2";
		System.out.println("Setting password");
		super.setPassword(decode(password));
	}
	
	private String decode(String password) {
	
			DecryptorUtil decrypt = new DecryptorUtil();
			String decryptedText = null;
			try {
				SecretKey secKey = decrypt.generateSecretKey();
				byte[] cipherd = decrypt.HextoByte(password);	
				 decryptedText = decrypt.decryptText(cipherd, secKey);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		return decryptedText;
		
		
	}
	
}
