package com.bdo.factor.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.crypto.SecretKey;

import org.apache.log4j.Logger;

public class FactorConnection {
	
	private static final Logger log = Logger.getLogger(FactorConnection.class);
	
	ResourceBundle rb = ResourceBundle.getBundle("/_properties/jdbc");
	private String driverClassName = rb.getString("jdbc.driverClassName");
	/**
	 * Added by: Roldan Somontina
	 * JDBC Connection for dbFactors
	 * Date: July 4, 2009
	 */
	
	private String dbFactorsUser = rb.getString("jdbc.username");
	private String dbFactorsPassword =  rb.getString("jdbc.password"); 
	private String dbFactorsPasswordDecrypt = FactorConnection.decryptPassword(dbFactorsPassword);
	private String dbFactorsURL=rb.getString("jdbc.url");
	private String dbFactorsConnection = dbFactorsURL+";user="+dbFactorsUser+";password="+dbFactorsPasswordDecrypt; 
	
	/**
	 * Added by: Roldan Somontina
	 * JDBC Connection for dbCIF
	 * Date: July 4, 2009
	 */
	private String dbCIFUser = rb.getString("jdbcCIF.username");
	private String dbCIFPassword =  rb.getString("jdbcCIF.password"); 
	private String dbCIFPasswordDecrypt = FactorConnection.decryptPassword(dbCIFPassword);
	private String dbCIFURL=rb.getString("jdbcCIF.url");
	private String dbCIFConnection = dbCIFURL+";user="+dbCIFUser+";password="+dbCIFPasswordDecrypt; 		
	
	//CVG 020917
	private static String decryptPassword(String pass){
		DecryptorUtil decrypt = new DecryptorUtil();
		//EncryptorUtil encrypt = new EncryptorUtil(); -- for encryption
		//byte[] cipherText = encrypt.encryptText(pass, secKey);-- for encryption
		//String encrypted = decrypt.bytesToHex(cipherText); --getEncrypt in Hexaform
	
		String decryptedText = null;
		try {
		SecretKey secKey = decrypt.generateSecretKey();

		byte[] cipherd = decrypt.HextoByte(pass);
		decryptedText = decrypt.decryptText(cipherd, secKey);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return decryptedText;	
	}
	
	
	public FactorConnection(){
		if(rb==null){
			driverClassName="net.sourceforge.jtds.jdbc.Driver";
			dbFactorsConnection="jdbc:jtds:sqlserver://xxx:1433/dbFACTORS;user=sa;password=password";
			dbFactorsConnection="jdbc:jtds:sqlserver://xxx:1433/dbCIF;user=sa;password=password";
		}
	}
	
	
	public Connection getConnection()
	{
		Connection conn=null;
		try{
			
//			net.sourceforge.jtds.jdbcx.JtdsDataSource ds = new net.sourceforge.jtds.jdbcx.JtdsDataSource(); 
//						  ds.setDatabaseName ("dbFactors"); 
//						  ds.setServerName ("172.31.200.8");  
//						 ds.setUser (dbFactorsUser); 
//						 ds.setPassword (dbFactorsPassword); 
//						 //MiniConnectionPoolManager poolMgr = new MiniConnectionPoolManager(ds, 100); 
//						conn= ds.getConnection(); //.poolMgr.getConnection();  
			
			Class.forName(driverClassName);
			conn= DriverManager.getConnection(dbFactorsConnection);
			//log.info("dbFactorsConnection=> "+dbFactorsConnection);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	
	public Connection getConnectionCIF()
	{
		Connection conn=null;
		try{
//			net.sourceforge.jtds.jdbcx.JtdsDataSource ds = new net.sourceforge.jtds.jdbcx.JtdsDataSource(); 
//			  ds.setDatabaseName ("dbCIF"); 
//			  ds.setServerName ("172.31.200.8");  
//			 ds.setUser (dbFactorsUser); 
//			 ds.setPassword (dbFactorsPassword); 
//			// MiniConnectionPoolManager poolMgr = new MiniConnectionPoolManager(ds, 100); 
//			 conn= ds.getConnection(); //.poolMgr.getConnection();  
			
			Class.forName(driverClassName);
			conn= DriverManager.getConnection(dbCIFConnection);
			//log.info("dbCIFConnection=> "+dbCIFConnection);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}	
	
}
