package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.CCLink;

public final class CCLinkUtility {
	
	public static Map toMap(CCLink ccLink) {
		Map map = new HashMap();
		map.put("C_BRANCHCODE", ccLink.getC_BranchCode());
		map.put("B_TERMINATED", ccLink.getB_Terminated());
		map.put("C_CLNTCODE", ccLink.getC_ClntCode());
		map.put("C_CURRENCY", ccLink.getC_Currency());
		map.put("C_TERMCODE", ccLink.getC_TermCode());
		map.put("N_CCLIMIT1", ccLink.getN_CcLimit1());
		map.put("N_CLLIMIT", ccLink.getN_ClLimit());
		map.put("N_CURINV", ccLink.getN_CurInv());
		map.put("N_OVER120DAY", ccLink.getN_Over120Day());
		map.put("N_OVER150DAY", ccLink.getN_Over150Day());
		map.put("N_OVER180DAY", ccLink.getN_Over180Day());
		map.put("N_OVER210DAY", ccLink.getN_Over210Day());
		map.put("N_OVER30DAY", ccLink.getN_Over30Day());
		map.put("N_OVER60DAY", ccLink.getN_Over60Day());
		map.put("N_OVER90DAY", ccLink.getN_Over90Day());
		
		return map;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////
		
	public static CCLink toObject(Map map) {
		CCLink ccLink = new CCLink();

		ccLink.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		ccLink.setB_Terminated(Byte.parseByte(map.get("B_TERMINATED").toString()));
		ccLink.setC_ClntCode(map.get("C_CLNTCODE").toString());
		ccLink.setC_Currency(map.get("C_CURRENCY").toString());
		ccLink.setC_TermCode(map.get("C_TERMCODE").toString());
		ccLink.setN_CcLimit1(Double.parseDouble(map.get("N_CCLIMIT1").toString()));
		ccLink.setN_ClLimit(Double.parseDouble(map.get("N_CLLIMIT").toString()));
		ccLink.setN_CurInv(Double.parseDouble(map.get("N_CURINV").toString()));
		ccLink.setN_Over120Day(Double.parseDouble(map.get("N_OVER120DAY").toString()));
		ccLink.setN_Over150Day(Double.parseDouble(map.get("N_OVER150DAY").toString()));
		ccLink.setN_Over180Day(Double.parseDouble(map.get("N_OVER180DAY").toString()));
		ccLink.setN_Over210Day(Double.parseDouble(map.get("N_OVER210DAY").toString()));
		ccLink.setN_Over30Day(Double.parseDouble(map.get("N_OVER30DAY").toString()));
		ccLink.setN_Over60Day(Double.parseDouble(map.get("N_OVER60DAY").toString()));
		ccLink.setN_Over90Day(Double.parseDouble(map.get("N_OVER90DAY").toString()));
		
		return ccLink;

	}

}
