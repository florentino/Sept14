package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Customer;

public class CustomerUtility {
	private static CustomerUtility groupUtilInstance = new CustomerUtility();

	private CustomerUtility() {
	}

	public static CustomerUtility getInstance() {
		return groupUtilInstance;
	}

	public Customer toObject(Map map) {
		Customer cust = new Customer();
		cust.setC_Address((String) map.get("C_ADDRESS"));
		cust.setC_BankAcct((String) map.get("C_BANKACCT"));
		cust.setC_BankCode((String) map.get("C_BANKCODE"));
		cust.setC_Contact((String) map.get("C_CONTACT"));
		cust.setC_CustCode((String) map.get("C_CUSTCODE"));
		cust.setC_CustName((String) map.get("C_CUSTNAME"));
		cust.setC_Group((String) map.get("C_GROUP"));
		cust.setC_IndCode((String) map.get("C_INDCODE"));
		cust.setC_RocNo((String) map.get("C_BREGNO"));
		cust.setC_TelNo((String) map.get("C_TELNO"));
		
		if(map.get("N_CULIMIT")!=null && map.get("N_CULIMIT").toString().trim().length()>0){
			cust.setN_CuLimit(Integer.parseInt(map.get("N_CULIMIT").toString()));
		}
		
		return cust;
	}

	public Map toMap(Customer cust) {
		Map map = new HashMap();
		map.put("C_ADDRESS", cust.getC_Address());
		map.put("C_BANKACCT", cust.getC_BankAcct());
		map.put("C_BANKCODE", cust.getC_BankCode());
		map.put("C_CONTACT", cust.getC_Contact());
		map.put("C_CUSTCODE", cust.getC_CustCode());
		map.put("C_CUSTNAME", cust.getC_CustName());
		map.put("C_GROUP", cust.getC_Group());
		map.put("C_INDCODE", cust.getC_IndCode());
		map.put("C_BREGNO", cust.getC_RocNo());
		map.put("C_TELNO", cust.getC_TelNo());
		map.put("N_CULIMIT", cust.getN_CuLimit());		

		return map;
	}
}
