package com.bdo.factor.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringWriter;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.collections.bag.SynchronizedBag;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.metadata.SybaseCallMetaDataProvider;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

 
 
public class XMLParser {
	
	
	
	//GLOBAL VARIABLE DECLARATION
	Document dom;
	private String[][] methods =new String[100][4];
	private String header="";	
	private Map tempMap;	
	private int counter =0;
	private int counter2 =0;
	private Boolean methodOnly = false;
	private Boolean updated = false;
	
	//FOR VALIDATION
	private StringBuilder exString;
	private String glXmlCode;
	private Integer type=1;
	
	//CLASS VARIABLE DECLARATION
	private static Map<String,Map> COAMap;
	private static HttpServletRequest request;
	private static ServletContext context;
	
	//ENUM DECLARATION
	private enum operation{ADD,EDIT,DELETE,EXIST,GLEXIST};
	
	//SINGLETON
	private static Logger log = Logger.getLogger(XMLParser.class);

	private static XMLParser XMLParserInstance = new XMLParser();
	
		private XMLParser() {}

		public static XMLParser getInstance() {
			return XMLParserInstance;
		}
		
		
	//GETTER AND SETTER
	public static HttpServletRequest getRequest() {
		return request;
	}

	public static void setRequest(HttpServletRequest request) {
			XMLParser.request = request;
		}

	public String[][] getMethods() {
		return methods;
	}

	public static Map<String, Map> getCOAMap() {
		if(COAMap ==null || COAMap.size()==0 )
			new XMLParser().parseCOAMap();
		return COAMap;
	}

	private void setMethods(String[][] methods) {
		this.methods = methods;
	}
	
	public static ServletContext getContext() {
		return context;
	}

	public static void setContext(ServletContext context) {
		XMLParser.context = context;
	}
	//END GETTER AND SETTER
	
	
	
	
	public StringBuilder getExString() {
		return exString;
	}

	public void setExString(StringBuilder exString) {
		this.exString = exString;
	}

	public void parseCOAMap(){
		COAMap = new HashMap();
	    parseXmlFile();
		parseDocument("");
	}	
	
	//METHODS
	public synchronized String[][] getMyMethods(String module){
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		setMethods(new String[100][4]);
		try {
			DocumentBuilder db = dbf.newDocumentBuilder();
			//System.out.println(request.getSession().getServletContext().getRealPath("/xml-config/JournalConf.xml"));
			dom =db.parse(new File(context.getRealPath("/xml-config/JournalConf.xml")));
			//dom = db.parse( "C:/Program Files/Apache Software Foundation/Tomcat 6.0/webapps/factors_v2r5.1_06232011/xml-config/JournalConf.xml");
		}catch(ParserConfigurationException pce) {
			pce.printStackTrace();
		}catch(SAXException se) {
			se.printStackTrace();
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}
		parseDocument(module);
		return getMethods();
	}
	
	private void parseXmlFile(){

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		
		try {
			
			DocumentBuilder db = dbf.newDocumentBuilder();
			//System.out.println();
			dom = db.parse(new File(context.getRealPath("/xml-config/COA.xml")));
			 

		}catch(ParserConfigurationException pce) {
			pce.printStackTrace();
		}catch(SAXException se) {
			se.printStackTrace();
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}

	private void parseDocument2(NodeList n){
		
		int x=0;
		while(x<n.getLength()){
			if(!n.item(x).getNodeName().contentEquals("#text")){
			
			if(n.item(x).getNodeName().matches("[[CostCenter]+,[GLCode]+.[GLName]+,[Description]+,[field]+,[loop]+]+")  ){
			createDetail(n.item(x).getFirstChild().getNodeValue(),n.item(x).getNodeName());
			}
			
			parseDocument2(n.item(x).getChildNodes());}
			x++;
		}
		
	}
	
	private void createDetail(String s,String nodeName){
		if (methodOnly){
			if(header.contentEquals(""))
				header=s;
			else{
				methods[counter][counter2] = s;
				 if(counter2>=3){
					 counter2=0;
					 counter++;
				 }
				 else
					 counter2++;
			}
		}
		else{
			if(header.contentEquals("")){
				header = s;
				tempMap = new HashMap();
				//System.out.println("Header: "+ s);
			}
			else{
				tempMap.put(nodeName,s);
				//System.out.println("Element: "+ s);
				}
		}
	}
	
	private void createMap(){
		COAMap.put(header, tempMap);
	}
	
	private void parseDocument(String module){

		Element docEle = dom.getDocumentElement();
		counter =0 ;
		counter2=0;
 		methodOnly = module.contentEquals("")?false:true;
		
		int x=0;
		
		NodeList nl =docEle.getChildNodes();
		
		while(x<docEle.getChildNodes().getLength()){
		 
			if(module.contentEquals("")?!nl.item(x).getNodeName().contentEquals("#text"):!nl.item(x).getNodeName().contentEquals("#text")&&nl.item(x).getNodeName().contentEquals(module)){
				
				createDetail(nl.item(x).getNodeName(),"");
			
				NodeList nl2 = nl.item(x).getChildNodes();
				
				parseDocument2(nl2);
				if(!methodOnly)
				createMap();
				
				header="";	
			}
			
			x++;
		}
		if(methodOnly){
			setMethods(methods);
		}
		//else 
			//setCOAMap(tempMap);
	}

 	public static void main(String[] args) throws TransformerException{
		//create an instance
 		 String key = "CASH";
		Map m = new HashMap();
 		m.put("GLCode", "q");
 		/*m.put("GLName", "a");
 		m.put("Description", "s");
 		m.put("CostCenter", "f");
 		
		m.put("field", "a");
		m.put("mapname", "s");
		m.put("loop", "f");*/
 	/*	XMLParser.getInstance().exString= new StringBuilder("");
		m.put("operation", "GLEXIST");
		XMLParser.getInstance().type=1;
		XMLParser.getInstance().startUpdate("110601101000",m);
		//log.info(XMLParser.getInstance().glXmlCode);
		if(XMLParser.getInstance().glXmlCode!=null&&!XMLParser.getInstance().glXmlCode.contentEquals("")){
		 m.put("operation", "EXIST");
		 XMLParser.getInstance().type=2;
		 XMLParser.getInstance().startUpdate(XMLParser.getInstance().glXmlCode,m); 
		}
		 System.out.println(XMLParser.getInstance().exString); */
 		XMLParser.getInstance().getMyMethods("Advances");
 		System.out.println(XMLParser.getInstance().getMethods()[0][0]);
 		System.out.println(XMLParser.getInstance().getMethods()[1][0]);
	} 
	
	public void startUpdate(String key,Map updateMap) throws TransformerException{
		//key = "110601101000";
		//type = 1;
		parseXmlFile(type);
		if(operation.valueOf(updateMap.get("operation").toString()).ordinal()==0)
			createNewAccount(updateMap);
		else
			parseDocument(key,updateMap,"",type==1?"COA":"JournalConf");
		
		if(updated)
			updateXMLFile(type==1?"COA":"JournalConf");
	}	
	
	private void parseXmlFile(Integer type){
		//get the factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		type =type ;
		try {
			
			DocumentBuilder db = dbf.newDocumentBuilder();
			
			String document = type==1?"COA":"JournalConf";
			
			dom = db.parse(new File(context.getRealPath("/xml-config/"+document+".xml")));
			//dom = db.parse( "C:/Program Files/Apache Software Foundation/Tomcat 6.0/webapps/factors_v2r5.1_06232011/xml-config/"+document+".xml");

		}catch(ParserConfigurationException pce) {
			pce.printStackTrace();
		}catch(SAXException se) {
			se.printStackTrace();
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	private void parseDocument(String key,Map m,String module,String Document) throws TransformerException{
		
		Element docEle = dom.getDocumentElement();
			
		int x=0;
		
		NodeList nl =docEle.getChildNodes();
		
		while(x<docEle.getChildNodes().getLength()){
			if(module.contentEquals("")?!nl.item(x).getNodeName().contentEquals("#text"):!nl.item(x).getNodeName().contentEquals("#text")&&nl.item(x).getNodeName().contentEquals(module)){
				NodeList nl2 = nl.item(x).getChildNodes();		
				parseDocument2(nl2,key,m);
			}
			x++;
		}
		 
	}
	
	private void parseDocument2(NodeList n,String key,Map updateMap){
		int x=0;
		while(x<n.getLength()){
			if(!n.item(x).getNodeName().contentEquals("#text")&&!n.item(x).getNodeName().contentEquals("#comment")){
				if(n.item(x).getFirstChild().getNodeValue().contentEquals(key)){
					
			 		switch(operation.valueOf(updateMap.get("operation").toString()).ordinal()){
			 		case 1:
			 				editor(n,updateMap);
			 				break;			 				
			 		case 2:
			 				dom.getFirstChild().removeChild(n.item(x).getParentNode());
			 				updated=true;
			 				break;
			 		case 3:
			 				System.out.println(n.item(x).getParentNode().getParentNode().getNodeName());
			 				exString = new StringBuilder(exString.toString().replace(n.item(x).getParentNode().getParentNode().getNodeName()+",", ""));
			 				exString.append(n.item(x).getParentNode().getParentNode().getNodeName()+", ");
			 				updated=false;
			 				break;
			 		
					case 4:
							glXmlCode=n.item(x).getParentNode().getNodeName();
							updated=false;
							System.out.println("GLXmlCode = " +glXmlCode);
							break;
			 		}
			 	
				break;
			 	}
			parseDocument2(n.item(x).getChildNodes(),key,updateMap);
			}
			x++;
		}	
	}
	
	private void editor(NodeList n,Map updateMap){
		int x=0;
		while(x<n.getLength()){
			
			if(!n.item(x).getNodeName().contentEquals("#text")){
				 		
				Iterator l = updateMap.keySet().iterator();
				while(l.hasNext()){
					String name = l.next().toString();
					if(n.item(x).getNodeName().contentEquals(name)){
						System.out.println("FOUND!");
						updated=true;
						n.item(x).getFirstChild().setNodeValue((String) updateMap.get(name));
						System.out.println(n.item(x).getNodeName() +"   "+n.item(x).getFirstChild().getNodeValue());
					}
				}
				 
					
			editor(n.item(x).getChildNodes(),updateMap);
			}
			x++;
		}
	}
	
	private void createNewAccount(Map m){
		
		String s =m.get("GLName").toString();
		s=s.replaceAll("\\W", "FACTORS");
		s=	s.replaceAll("[0-9]", "SYSTEM");
		String codeName = s.charAt(((int)(Math.random()*s.length())))+" "+s.charAt((int)(Math.random()*s.length()))+" "+s.charAt((int)(Math.random()*s.length()))+" "+s.charAt((int)(Math.random()*s.length()));
		codeName=  codeName.replaceAll("\\W", "").trim();
		log.info(codeName);
		Node code = dom.createElement(codeName);
		Node GLCode = dom.createElement("GLCode");
		Node GLName= dom.createElement("GLName");
		Node Description= dom.createElement("Description");
		Node CostCenter= dom.createElement("CostCenter");
		Node NBalance= dom.createElement("NBalance");
		
		GLCode.setTextContent(m.get("GLCode").toString());
		GLName.setTextContent(m.get("GLName").toString());
		Description.setTextContent(m.get("Description").toString());
		CostCenter.setTextContent(m.get("CostCenter").toString());
		NBalance.setTextContent(m.get("NBalance").toString());
		
		code.appendChild(GLCode);
		code.appendChild(GLName);
		code.appendChild(Description);
		code.appendChild(CostCenter);
		code.appendChild(NBalance);
		
		dom.getFirstChild().appendChild(code);
		updated=true;
	}
	
	private Boolean updateXMLFile(String Document){
		PrintStream printStream = null;
		try {
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		 transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
		 transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		 transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		 transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

		StreamResult result = new StreamResult(new StringWriter());
		DOMSource source = new DOMSource(dom);
		transformer.transform(source, result);

		String xmlString = result.getWriter().toString();
		System.out.println(xmlString);
		
		
		
		 printStream = new PrintStream(context.getRealPath("/xml-config/"+Document+".xml"));
			printStream.print(xmlString);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}catch (TransformerException e) {
			e.printStackTrace();
			return false;
		}
		
		finally{
			if(printStream!=null){
			printStream.flush();
			printStream.close();
			}
		}
		return true;
	}
	
	public synchronized String searchJournalChartEntry(String d) throws TransformerException{
		Map m =  new HashMap();
		glXmlCode = "";
		exString= new StringBuilder("");
		m.put("operation", "GLEXIST");
		type=1;
		startUpdate(d,m);
		
		if(glXmlCode!=null&&!glXmlCode.contentEquals("")){
			m.put("operation", "EXIST");
			type=2;
			startUpdate(XMLParser.getInstance().glXmlCode,m); 
		}
		type=1;
		System.out.println(XMLParser.getInstance().exString); 
		
		return exString.toString();
	}
}
