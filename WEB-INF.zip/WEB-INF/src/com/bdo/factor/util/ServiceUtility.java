package com.bdo.factor.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Date;
import java.util.Set;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.DateFormat;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.PdoDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dataSource.InvoiceDAO;
import com.bdo.factor.service.PDOService;

public class ServiceUtility {
	
	private static Logger log = Logger.getLogger(ServiceUtility.class);
	
//////////////////////////////////////////////////////////////////////////////////////////////////////
	
	//Don't let anyone instantiate this class...
	private ServiceUtility() { }
	
	private static ServiceUtility ServiceUtilityInstance = new ServiceUtility();			
//////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static ServiceUtility getInstance() {
		return ServiceUtilityInstance;
	}
	
////////////////////////////////////////////////////////////////////
	
	public static String encypher(String message)
	{
		StringBuilder encryptedMessage = new StringBuilder();
		
		for ( int i=0; i<message.length(); i++ )
		{
			int shift = (i+1)*2;
			// get the character from the plain message
			char unencryptedChar = message.charAt(i);
			// get appropriate list
			String alphabet = "";
			if ( ((unencryptedChar >= 'a') && (unencryptedChar <= 'z')) )
			{
				alphabet = "cijgkanopqrsemtbuvwdxfyhzl";
			}else if ( ((unencryptedChar >= 'A') && (unencryptedChar <= 'Z')) )
			{
				alphabet = "SCEFHIKLAOPQRTGUVNWJXDYZBM";
			}
			

			// convert to string format
			String unencryptedString = (new Character(unencryptedChar)).toString();
			// get the position of this character in the list
			int initialPosition = 0;
			for ( int k=0; k<alphabet.length(); k++ )
			{
				String val = (new Character( alphabet.charAt(k) )).toString();
				if ( val.equals(unencryptedString))
				{
					initialPosition = k;
					break;
				}
			}
			
			// get the shifted character
			if ( alphabet.length() > 0 )
			{
				int shiftedPosition = 0;
				int modular = shift % alphabet.length();
				int temp1 = ((alphabet.length()-1)-initialPosition);
				
				if ( (alphabet.length()-initialPosition) <= shift )
				{
					shiftedPosition = (initialPosition + shift) - alphabet.length();
				}
				else shiftedPosition = initialPosition + shift;
				
				// get the character at the shifted position
				String encrypted = (new Character( alphabet.charAt(shiftedPosition))).toString();
				if ( encrypted != null )
					encryptedMessage.append( encrypted );
				else encryptedMessage.append( unencryptedString );
			}
			else encryptedMessage.append( unencryptedString );
		}
		
		return encryptedMessage.toString();
	}
	////////////////////////////////////////////////////////////////////////

	public static void viewUserParameters(Map bankForm){
		
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("--->> viewUserParameters SERVICE ...");
		
		Iterator iterator = bankForm.entrySet().iterator();
    
		while (iterator.hasNext()) {
			Map.Entry entry = (Map.Entry) iterator.next();
			System.out.println( "(" + entry.getKey() + ": " + entry.getValue() + "), " );
		}
		System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++");
	}
	
	public static boolean validateDate(String dt){
		try{
			DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
			df.setLenient(false);  // this is important!
			@SuppressWarnings("unused")
			Date dt2 = df.parse(dt);
			return true;
		}catch (ParseException e){
			return false;
		}catch (IllegalArgumentException e){
			return false;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static String ValidateForm(Map myForm){
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("--->> ValidateForm SERVICE ...");
		
		Iterator iterator = myForm.entrySet().iterator();
		String svc = myForm.get("classname").toString();
		InvoiceDAO inv = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		
		while (iterator.hasNext()) {
			Map.Entry entry = (Map.Entry) iterator.next();
			String ek = entry.getKey().toString();
			String tbl=inv.getField("TableName", "Validation", "ServiceName='"+svc+"' and FieldName='"+ek+"'");
			if (tbl != "No Data Found"){
				String fv = entry.getValue().toString();
				int ValidationType = Integer.parseInt(inv.getField("ValidationType", "Validation", "ServiceName='"+svc+"' and FieldName='"+ek+"'"));
				String msg = inv.getField("msg", "Validation", "ServiceName='"+svc+"' and FieldName='"+ek+"'");
				System.out.println("****validationtype="+ValidationType);
				switch(ValidationType){
				case 1:
					if (ek.contains("NAME")){
						fv = fv.replaceAll("'", "''");
					}
					String fldval=inv.getField("TOP 1 "+ek,tbl,ek+"='"+fv+"'");
					if (fldval.equals("No Data Found")){
						System.out.println(fldval+","+fv+","+ek+","+tbl);
						return msg;
					}
					break;
				case 2:
					if (validateDate(fv)==false){
						return msg;
					}
					break;
				case 3:
					if (fv.length()==0){
						return msg;
					}
					break;
				case 4:
					try {
						if (fv.length()==0 || Double.parseDouble(fv.toString()) == 0){
							return msg;
						}
					} catch (Exception e) {
						return msg;
					}
					break;
				case 5:
					fldval=inv.getField(ek,tbl,"C_NAME='"+myForm.get("C_NAME").toString().replaceAll("'", "''")+"' and C_CUSTNAME='"+myForm.get("C_CUSTNAME").toString().replaceAll("'", "''")+"' and C_BRANCHCODE='"+myForm.get("C_BRANCHCODE").toString()+"'");
					try {
						if (fv.toString() == "" || Integer.parseInt(fldval)<Integer.parseInt(fv)){
							return msg;
						}
					} catch (Exception e) {
						return msg;
					}
					break;
				}
			}
		}
		return "";
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	public static void viewDataBaseRecords(List records){
		
		
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("--->> viewDataBaseRecords SERVICE ...");
			
		for(int cnt=0;cnt<records.size();cnt++){
		
			HashMap tmp = new HashMap();
			tmp = (HashMap)records.get(cnt);
			Iterator iterator = tmp.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry entry = (Map.Entry) iterator.next();
				System.out.println( "(" + entry.getKey() + ": " + entry.getValue() + "),\n" );
			}
		}
		System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++");
	}
	
////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	public static HashMap addPaging(Map recordsParam,String totalRecordsParam){
		
		HashMap records = (HashMap)recordsParam;
		
		String page = (String)records.get("page");
		String pageRows = (String)records.get("rows");
		String totalPages = "0";
		String start = "0";
		
		if(page == null || page.trim().length()==0){
			page = "0";
		}
		
		if(pageRows == null || pageRows.trim().length()==0){
			pageRows = "0";
		}
			
		try{
		
			if((Integer.parseInt(totalRecordsParam)) > 0){
				totalPages = ""+(int)Math.ceil((Double.parseDouble(totalRecordsParam))/(Double.parseDouble(pageRows)));
			}else{
				totalPages = "0";
			}
		
		}catch(Throwable x){
			totalPages = "0";
		}
		
		records.put("total", totalPages);
		
		if((Integer.parseInt(page)) > (Integer.parseInt(totalPages))){
			records.put("page", totalPages);
    	}
		
		try{
			start = ""+(1+((Integer.parseInt(pageRows))*(Integer.parseInt(page)))-(Integer.parseInt(pageRows)));
		}catch(Throwable x){
			start = "0";
		}
		
		if(Integer.parseInt(start) < 0){
			start = "1";
		}
		
		records.put("records", totalRecordsParam);
		
		try{
			pageRows = ""+(Integer.parseInt(page)*Integer.parseInt(pageRows));	
		}catch(Throwable x){
			pageRows = "0";
		}
		
		records.put("start", start);
		records.put("end", pageRows);
		
		return records;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	public static HashMap removeNulls(Map recordsParam){
		
		HashMap newRecords = (HashMap)recordsParam;
		
		Iterator iterator = newRecords.entrySet().iterator();
	    
		while (iterator.hasNext()) {
			
			Map.Entry entry = (Map.Entry) iterator.next();
			
			try{
				if(entry.getValue()==null || entry.getValue().toString().trim().length()==0 || entry.getValue().toString().trim().equals("null")){
					newRecords.put((String)entry.getKey(),"");
				}
			}
			catch(Throwable x){
				newRecords.put((String)entry.getKey(),"");
			}
			
		}
		

		return newRecords;
	}
	
    @SuppressWarnings("unchecked")
	public static Map toJQGrid(Object m,String countMethod,String getRecordMethod, Map data){
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
 
		Method m1;
		
		try {
			
			
			ServiceUtility.viewUserParameters(data);
			log.info("--->> SEARCH");
			
			m1 = m.getClass().getMethod(countMethod, new Class[] {Map.class});
			
			totalRecords = (String)m1.invoke(m, data);
		
			data = ServiceUtility.addPaging(data,totalRecords);
			
			m1 = m.getClass().getMethod(getRecordMethod, new Class[] {Map.class});
			
			records = (List)m1.invoke(m, data);
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)data.get("records")),((String)data.get("page")),((String)data.get("total")));
			}else{
				jsondata.put("status","search Failed ... ");
			}
			
		} catch(Exception e){
			e.printStackTrace();
		}		
		
		
		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////	
    @SuppressWarnings("unchecked")
   	public static Map toJQGrid2(Object m,String getRecordMethod, Map data){
   		Map jsondata = new HashMap();
   		List records = new ArrayList();
   		String totalRecords = "";
    
   		Method m1;
   		
   		try {
   			
   			ServiceUtility.viewUserParameters(data);
   			log.info("--->> SEARCH");
   			
   			m1 = m.getClass().getMethod(getRecordMethod, new Class[] {Map.class});
   			
   			records = (List)m1.invoke(m, data);
   		
   			data = ServiceUtility.addPaging(data,String.valueOf(records.size()));
   			
   			if((records!=null) && (records.size()>0)){						
   				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)data.get("records")),((String)data.get("page")),((String)data.get("total")));
   			}else{
   				jsondata.put("status","search Failed ... ");
   			}
   			
   		} catch(Exception e){
   			e.printStackTrace();
   		}		
   		
   		
   		return jsondata;
   	}
    
    /////////////////////////////////////////////////////////////////////////////////////////
    public static String stringClientNameFilter(String resultString){ //clientName Filter CVG 06132017
    	
    	ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
    	 // convert to list! //ok
		 
			List <String>stringList = new ArrayList<String>(Arrays.asList(resultString.split(",split,"))); // ok
			ListIterator i = stringList.listIterator();
			Set newSet = new HashSet();
			String a = " ";
			
			while(i.hasNext()){
				 a =  i.next().toString();
				 a.trim().replaceFirst("^\\s*","");
				if (a.split(" ").length !=1){ // ignore if word is single in a string
					String v = a.substring(0, a.lastIndexOf(" "));
					int checker = clientDAO.checkIfClientNameExist(v);
						if(checker!=0){
							newSet.add(v);
						}else{
							newSet.add(a);
						}
				}else{
					newSet.add(a);
				}
			}
			
			List filteredList = new LinkedList();
			filteredList.addAll(newSet); 
			
			String stringToJson = String.join("\n", newSet);
    	
		return stringToJson;
    }


    
    
    
    
    
	
}
