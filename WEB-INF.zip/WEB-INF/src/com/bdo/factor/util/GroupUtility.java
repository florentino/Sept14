package com.bdo.factor.util;

import java.util.HashMap;
import java.util.Map;

import com.bdo.factor.beans.Group;

public final class GroupUtility {
	private static GroupUtility groupUtilInstance = new GroupUtility(); 
	
	private GroupUtility (){}
	
	public static GroupUtility getInstance() {
		return groupUtilInstance;
	}
	
	public Group toObject(Map map) {	
		Group g = new Group();
		String nAmount = map.get("N_ACCAMT").toString();
		String nGrpLimit = map.get("N_GRPLIMIT").toString();
		nAmount = nAmount.replace(",", "");
		nGrpLimit = nGrpLimit.replaceAll("\\s","");
		System.out.println("N_GRPLIMIT = " + map.get("N_GRPLIMIT"));
		System.out.println("C_BRANCHCODE = " + map.get("C_BRANCHCODE"));
		g.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		g.setC_GroupCode((String) map.get("C_GROUPCODE"));
		g.setN_GrpLimit(Integer.parseInt(nGrpLimit));
		g.setN_AccAmt(Double.parseDouble(nAmount));
		g.setC_GroupName((String) map.get("C_GROUPNAME"));
		
		return g;		
	} 
	
	public Map toMap(Group g){
		Map map = new HashMap();
		map.put("C_BRANCHCODE", g.getC_BranchCode());
		map.put("C_GROUPCODE", g.getC_GroupCode());
		map.put("N_GRPLIMIT", g.getN_GrpLimit());
		map.put("N_ACCAMT", g.getN_AccAmt());
		map.put("C_GROUPNAME", g.getC_GroupName());
		return map;
	}	
}
