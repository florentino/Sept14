package com.bdo.factor.util;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.engine.xml.JRXmlWriter;
public class JasperToXml
{
   public static String sourcePath,
                        destinationPath,
                        xml;
   public static JasperDesign jd  = new JasperDesign();
   
   public static void main(String [] args) 
   {
	   String file = "clientsoa";
	   
      // Paths
      //String sourcePath = "C://Program Files//Apache Software Foundation//Tomcat 6.0//webapps//factors2_edit//report//"+file+".jasper";
	   String sourcePath = "C:\\apache-tomcat-8.5.14\\webapps\\factors3\\report\\"+file+".jasper";
	   //C:\Program Files\Apache Software Foundation\Tomcat 6.0\webapps\factors2_edit\report
	   String outputPath = "C:\\Users\\mogs\\Documents\\Jasper Reports\\"+file+".jrxml";   
      try
      {
    	  JasperReport report = (JasperReport) JRLoader.loadObject(sourcePath);
    	  JRXmlWriter.writeReport(report, outputPath, "UTF-8");
         // for converting a JasperReport object (compiled .jasper file) to a JasperDesign object
         jd  = JRXmlLoader.load(sourcePath);
         // is this the right way to do it???
      }
      catch(JRException e)
      {
         e.printStackTrace();
      }
      JRXmlWriter.writeReport(jd, outputPath); //
   }
}