package com.bdo.factor.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.CISABusinessBean;
import com.bdo.factor.beans.CISAContract;
import com.bdo.factor.beans.CISAContractReference;
import com.bdo.factor.beans.CISAIndividualBean;
import com.bdo.factor.beans.CISALink;
import com.bdo.factor.beans.CisaCustomerReference;

public class CISADAO  extends SqlMapClientDaoSupport {
	 

	public void AddCISAIndividualBean(CISAIndividualBean _CISAIndividualBean){
		getSqlMapClientTemplate().insert("AddCISAIndividualBean", _CISAIndividualBean);
	}
	
	public void AddCISABusinessBean(CISABusinessBean _CISABusinessBean){
		getSqlMapClientTemplate().insert("AddCISABusinessBean", _CISABusinessBean);
	}
	
	public void AddCISALink(CISALink _CISALink){
		getSqlMapClientTemplate().insert("AddCISALink", _CISALink);
	}
	
	public void AddCISALinkList(Map<String,List<CISALink>> _CISALink){
		getSqlMapClientTemplate().insert("AddCISALinkList", _CISALink);
	}
	
	public void AddContract(CISAContract _CISAContract){
		getSqlMapClientTemplate().insert("AddCISAContract", _CISAContract);
	}

	public void AddLinkListReferenceClient(Map<String,List<CISAContractReference>> _CISAContractReferenceList){
		getSqlMapClientTemplate().insert("AddLinkListReferenceClient", _CISAContractReferenceList);
	}
	
	public void AddLinkListReferenceCustomer(Map<String,List<CisaCustomerReference>> _CisaCustomerReference){
		getSqlMapClientTemplate().insert("AddLinkListReferenceCustomer", _CisaCustomerReference);
	}
	//added by CVG 09-12-16
	@SuppressWarnings("unchecked")
	public void addAAFUser(String C_USERID, String C_USERNAME,String role )
	{		
		HashMap m = new HashMap();
		m.put("c_userid", C_USERID);		
		m.put("c_userName", C_USERNAME);	
		m.put("role", role);	
		getSqlMapClientTemplate().insert("addAAFUser", m); 
		
	}
	
	public void deleteAAFUser(String c_UserID)
	{			
		 getSqlMapClientTemplate().delete("deleteAAFUser", c_UserID);
	}
	
	public int checkIfUserExist(String c_UserID)
	{		
		return (Integer)getSqlMapClientTemplate().queryForObject("checkIfUserExist", c_UserID);
	}
	
	public int checkIfClientExist(int clientCode)
	{		
		return (Integer)getSqlMapClientTemplate().queryForObject("checkIfClientExist", clientCode);
	}
	
	public int checkIfCustomerExist(int customerCode)
	{		
		return (Integer)getSqlMapClientTemplate().queryForObject("checkIfCustomerExist", customerCode);
	}
	
	public int getRefID(String clientCode)
	{		
		return (Integer)getSqlMapClientTemplate().queryForObject("getRefID", clientCode);
	}
	
	public int getCustRefID(String customerCode)
	{		
		return (Integer)getSqlMapClientTemplate().queryForObject("getCustRefID", customerCode);
	}
	
	@SuppressWarnings("unchecked")
	public void updateAAFUser (String C_USERID, String C_USERNAME,String role){
		HashMap m = new HashMap();
		m.put("c_userid", C_USERID);		
		m.put("c_userName", C_USERNAME);	
		m.put("role", role);	
		getSqlMapClientTemplate().update("updateAAFUser", m); 
	}
	
	 // end
}
