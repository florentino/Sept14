package com.bdo.factor.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.User;
import com.bdo.factor.util.ServiceUtility;

public class UserDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(UserDAO.class);
	@SuppressWarnings("unchecked")
	public User searchUser (String c_UserID, String c_PassW) {
		try {
		log.info("-->> getUser DAO CORRECT ....");
		HashMap m = new HashMap();
		m.put("c_UserID", c_UserID);
		m.put("c_PassW", c_PassW);
				
		User u = (User) getSqlMapClientTemplate().queryForObject("searchUser", m);		
		//log.info(u.toString());
		return u;
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public boolean changeUserPassword(String c_UserID, String c_PassW, String userPassExpire)
	{
		HashMap m = new HashMap();
		m.put("c_UserID", c_UserID);
		m.put("c_PassW", c_PassW);
	/*	m.put("C_PasswordHistory1", C_PasswordHistory1);
		m.put("C_PasswordHistory2", C_PasswordHistory2);
		m.put("C_PasswordHistory3", C_PasswordHistory3);
		m.put("C_PasswordHistory4", C_PasswordHistory4);
		m.put("C_PasswordHistory5", C_PasswordHistory5);*/
		m.put("PWDEXPIRE", userPassExpire);
		boolean retval = false;
				
		retval = (getSqlMapClientTemplate().update("changeUserPassword", m) > 0) ? true : false;
				
		return retval;
	}
	
	public boolean updatePasswordHistory(String c_userid,String oldpassword,String method){
		Map o = new HashMap();
		o.put("c_UserID", c_userid);
		o.put("oldPass", oldpassword);
		o.put("method",method);
		
		return getSqlMapClientTemplate().update("updatePassHistory",o)>0;
	}
	
	public Boolean updatePasswordHistoryCount(String passCount){
		List<String> users = new ArrayList<String>();
		users = getSqlMapClientTemplate().queryForList("getUserNamesFromHistory");
		Map data = new HashMap();
		data.put("userList", users);
		data.put("passCount", passCount);
		getSqlMapClientTemplate().update("updatePasswordHistoryCount",data);
		return null;
	}
	
	public boolean changeUserPassword1(String c_UserID, String c_PassW)
		{
		Map<String,String> m = new HashMap<String,String>();
		m.put("c_UserID", c_UserID);
		m.put("c_PassW", c_PassW);
		
		try{
			getSqlMapClientTemplate().insert("changeUserPassword", m);
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
		}
	
	@SuppressWarnings("unchecked")
	public int getUserCountByUserIdAndPass(String c_UserID, String oldPass)
	{		
		HashMap m = new HashMap();
		m.put("c_UserID", c_UserID);
		m.put("oldPass", oldPass);
		return (Integer)getSqlMapClientTemplate().queryForObject("searchCountUser", m);
	}
	@SuppressWarnings("unchecked")
	public int countAllUser(Map user)
	{		
		return (Integer)getSqlMapClientTemplate().queryForObject("CountAllUser", user);
	}		
	
	@SuppressWarnings("unchecked")
	public List getUserList(Map user)
	{				
		ServiceUtility.viewUserParameters(user);
		log.debug("--->getUserList Correct--->....");
		return getSqlMapClientTemplate().queryForList("userList", user);		
	}
	@SuppressWarnings("unchecked")
	public int getUserCountByUserIdOrUserName(String C_USERID, String C_USERNAME)
	{
		HashMap m = new HashMap();
		m.put("C_USERID", C_USERID);
		m.put("C_USERNAME", C_USERNAME);
		return (Integer)getSqlMapClientTemplate().queryForObject("countUserByUserIdOrUserName", m);
	}
	
	@SuppressWarnings("unchecked")
	public boolean createUser(Map user)
	{		
		boolean retval = false;			
		retval = (getSqlMapClientTemplate().update("createUserProfile", user) > 0) ? true : false;				
		return retval;
	}
	
	@SuppressWarnings("unchecked")
	public List getUserByUserId(Map user)
	{
		ServiceUtility.viewUserParameters(user);
		log.debug("--->getUserList Correct--->....");
		return getSqlMapClientTemplate().queryForList("searchUserByUserID", user);
	}
	
	@SuppressWarnings("unchecked")
	public boolean updateUserProfile(Map user)
	{
		if (user.get("C_PASSW").toString().trim().length() > 0)
		{
			return (getSqlMapClientTemplate().update("udpdateUserProfileWithPassWrd", user) > 0) ? true : false;
		}
		else
		{
			return (getSqlMapClientTemplate().update("udpdateUserProfile", user) > 0) ? true : false;
		}		
	}
	
	@SuppressWarnings("unchecked")
	public int getUserCountByUserNameAndNotUserId(String C_USERID, String C_USERNAME)
	{
		HashMap m = new HashMap();
		m.put("C_USERID", C_USERID);
		m.put("C_USERNAME", C_USERNAME);
		return (Integer)getSqlMapClientTemplate().queryForObject("countUserByUserNameAndNotUserId", m);
	}
	
	@SuppressWarnings("unchecked")
	public boolean setUserLoggedStatus(String c_UserID, String c_PassW)
	{
		HashMap user = new HashMap();
		user.put("c_UserID", c_UserID);
		user.put("c_PassW", c_PassW);
				
		return (getSqlMapClientTemplate().update("setUserIsLogged", user) > 0) ? true : false;
	}
	public boolean setUserLoggedStatusLDAPS(String c_UserID)
	{
		HashMap user = new HashMap();
		user.put("c_UserID", c_UserID);
				
		return (getSqlMapClientTemplate().update("setUserIsLoggedLDAPS", user) > 0) ? true : false;
	}
	
	
	@SuppressWarnings("unchecked")
	public boolean setUserLoggedStatusAsOut(String c_UserID)
	{
		HashMap user = new HashMap();
		user.put("c_UserID", c_UserID);		
		
		return (getSqlMapClientTemplate().update("setUserIsLoggedStatusAsOut", user) > 0) ? true : false;
	}
		
	@SuppressWarnings("unchecked")
	public User getUserPasswordHistory(String c_UserId)
	{
		HashMap m = new HashMap();
		m.put("C_USERID", c_UserId);	
		User user = (User) getSqlMapClientTemplate().queryForObject("getPasswordHistory", m);		
		return user;
	}
	
	public List<String> getUserPasswordHistoryList(String c_userID){
		
		return getSqlMapClientTemplate().queryForList("getPasswordHistory",c_userID);
	}
	
	@SuppressWarnings("unchecked")
	public boolean passwordInHistory(String UserId, String Password)
	{
		HashMap m = new HashMap();
		m.put("C_USERID", UserId);
		m.put("C_PASSWORD", Password);
		return ((Integer)getSqlMapClientTemplate().queryForObject("checkPasswordHistory", m) > 0 ? true : false);
	}
	
	@SuppressWarnings("unchecked")
	public List<Map> getRoleList(Map role)
	{				
		ServiceUtility.viewUserParameters(role);
		log.debug("--->getRoleList Correct--->....");
		return getSqlMapClientTemplate().queryForList("listRole", role);		
	}
	
	@SuppressWarnings("unchecked")
	public List getUserAccess(String userID)
	{
		//ServiceUtility.viewUserParameters(user);
		log.debug("--->getUserAccess Correct--->....");
		log.debug("--->getUserAcc5ess userID--->...." + userID);
		return (List) getSqlMapClientTemplate().queryForList("userAccess", userID);
	}
		
	public boolean suspendUser(String c_UserID, boolean lockedUser, String n_try)
	{			
		HashMap m = new HashMap();
		m.put("c_UserID", c_UserID);		
		m.put("N_TRY", n_try);	
		return ((Integer)getSqlMapClientTemplate().update((lockedUser ? "lockedUser" : "unLockedUser") , m) > 0 ? true : false);
	}
	
	@SuppressWarnings("unchecked")
	public int getUserCountIfSuspended(String C_USERID, String n_try)
	{
		HashMap m = new HashMap();
		m.put("C_USERID", C_USERID);		
		m.put("N_TRY", n_try);		
		return (Integer)getSqlMapClientTemplate().queryForObject("isSuspended", m);
	}
	
	@SuppressWarnings("unchecked")
	public boolean deleteUser(String c_UserID)
	{			
		HashMap m = new HashMap();
		m.put("c_UserID", c_UserID);
		return (getSqlMapClientTemplate().delete("deleteUser", m) > 0 ? true : false);
	}
	
	@SuppressWarnings("unchecked")
	public int countAllUserByBranch(String c_BranchCode)
	{
		HashMap m = new HashMap();
		m.put("c_BranchCode", c_BranchCode);
		return (Integer)getSqlMapClientTemplate().queryForObject("CountAllUserByBranch", m);
	}
	
	public int countAllLockedUser()
	{		
		return (Integer)getSqlMapClientTemplate().queryForObject("CountAllLockedUser");
	}
	
	public boolean unLockedAllUser()
	{					
		return (getSqlMapClientTemplate().update("unLockedAllUser") > 0 ? true : false);
	}
	
	
	public boolean setNTry(String c_UserID)
	{		
		return (getSqlMapClientTemplate().update("setNtry", c_UserID) > 0 ? true : false);
	}
	
	public boolean resetNTry(String c_UserID)
	{		
		return (getSqlMapClientTemplate().update("resetNtry", c_UserID) > 0 ? true : false);
	}
	
	@SuppressWarnings("unchecked")
	public byte isPasswordExpired(String c_UserID)
	{
		HashMap user = new HashMap();
		user.put("c_UserID", c_UserID);
		try
		{
			return (Byte)getSqlMapClientTemplate().queryForObject("isPasswordExpired", user);
		}
		catch(Exception e)
		{
			return 0;
		}
	}
	
	public void setLockedUser2(String c_UserID)
	{
		getSqlMapClientTemplate().update("lockedUser2", c_UserID);
	}
	
	@SuppressWarnings("unchecked")
	public byte isPasswordExpiredAndLocked(String c_UserID)
	{
		HashMap user = new HashMap();
		user.put("c_UserID", c_UserID);
		try
		{
			return (Byte)getSqlMapClientTemplate().queryForObject("isPasswordExpiredAndLocked", user);
		}
		catch(Exception e)
		{
			return 0;
		}
	}
	
	@SuppressWarnings("unchecked")
	public int getPasswordExpirationCtr(String c_UserID)
	{
		HashMap user = new HashMap();
		user.put("c_UserID", c_UserID);
		try
		{
			return (Integer)getSqlMapClientTemplate().queryForObject("isPasswordExpiredCtr", user);
		}
		catch(Exception e)
		{
			return 0;
		}
	}
	
	public void setUserDateLastLogin(String c_UserID)
	{
		getSqlMapClientTemplate().update("setUserLastLogin", c_UserID);
	}
	
	@SuppressWarnings("unchecked")
	public byte getIsUserActive(String c_UserID)
	{		
		HashMap user = new HashMap();
		user.put("c_UserID", c_UserID);
		try
		{
			return (Byte)getSqlMapClientTemplate().queryForObject("getIsUserActive", user);
		}
		catch(Exception e)
		{
			return 0;
		}
	}
		
	public String getSystemDefaultPassword()
	{		
		return (String)getSqlMapClientTemplate().queryForObject("getSystemDefaultPassword");	
	}
	
	public boolean updateStatus(Map user){
		return getSqlMapClientTemplate().update("updateStatus",user)>0;
	}		
	
	public boolean activateUser(Map user){
		return getSqlMapClientTemplate().update("activateUser",user)>0;
	}
	
	public List<User> getAllUser()
	{
				return (List<User>) getSqlMapClientTemplate().queryForList("getAllUser");
	}
	public User getUser(String userID){
		return (User) getSqlMapClientTemplate().queryForObject("getUser",userID);
	}
	//added by CVG
		@SuppressWarnings("unchecked")
		public int checkUserRole(String role)
		{		
			return (Integer)getSqlMapClientTemplate().queryForObject("checkUserRole", role);
		}
		
	public String GetUserRole(String role){
		 
		return (String)getSqlMapClientTemplate().queryForObject("GetUserRole", role);
	}
	
	@SuppressWarnings("unchecked")
	public User searchUserOnly (String c_UserID) {
		try {
		log.info("-->> getUser DAO CORRECT ....");
	
		User u = (User) getSqlMapClientTemplate().queryForObject("searchUserOnly", c_UserID);		
		//log.info(u.toString());
		return u;
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
	
	
}
