package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class CreditNoteDAO extends SqlMapClientDaoSupport {
	private static Logger log = Logger.getLogger(CreditNoteDAO.class);
	
	public int addCreditNote(Map creditNoteForm){
		return (Integer) getSqlMapClientTemplate().insert("addCreditNote",creditNoteForm);
	}
	
	public boolean updateCreditNote(Map creditNoteForm){
		return getSqlMapClientTemplate().update("updateCreditNote",creditNoteForm)>0;
	}
	
	public boolean updateCreditNoteStatus(Map creditNoteForm){
		return getSqlMapClientTemplate().update("updateCreditNoteStatus",creditNoteForm)>0;
	}
	
	public boolean updateCreditNoteStatusByBatch(Map creditNoteForm){
		return getSqlMapClientTemplate().update("updateCreditNoteStatusByBatch",creditNoteForm)>0;
	}
	
	public boolean updateCreditNoteStatus3ByBatch(Map creditNoteForm){
		return getSqlMapClientTemplate().update("updateCreditNoteStatus3ByBatch",creditNoteForm)>0;
	}
	
	public boolean updateCreditNoteStatusAndDateByBatch(Map creditNoteForm) {
		return getSqlMapClientTemplate().update("updateCreditNoteStatusAndDateByBatch", creditNoteForm) > 0;
	}
	
	public String getTotalCreditNoteRecords(String n_RefNo){
		log.debug("-->> getTotalCreditNoteRecords DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalCreditNoteRecords", n_RefNo);
	}
	
	public String getTotalCreditNoteRecordsByBranch(Map map){
		log.debug("-->> getTotalCreditNoteRecordsByBranch DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalCreditNoteRecordsByBranch", map);
	}
	
	public List searchCreditNoteByBranch(Map creditNoteForm){
		
		log.debug("-->> searchCreditNoteByBranch DAO ....");
		return getSqlMapClientTemplate().queryForList("searchCreditNoteByBranch",creditNoteForm);
	}
	
	public int searchCreditNoteCountByInvoice(Map creditNoteForm){
				
		log.debug("-->> searchCreditNoteByRefNo DAO ....");
		return Integer.parseInt((String) getSqlMapClientTemplate().queryForObject("searchCreditNoteCountByInvoice",creditNoteForm));
	}
	
	public int searchCreditNoteCountByReceipts(Map creditNoteForm){
		
		log.debug("-->> searchCreditNoteByRefNo DAO ....");
		return Integer.parseInt((String) getSqlMapClientTemplate().queryForObject("searchCreditNoteCountByReceipts",creditNoteForm));
	}
	
	public List searchCreditNoteByRefNo(Map creditNoteForm){
		
		log.debug("-->> searchCreditNoteByRefNo DAO ....");
		return getSqlMapClientTemplate().queryForList("searchCreditNoteByRefNo",creditNoteForm);
	}
	
	public List searchCreditNoteByReceiptNo(Map creditNoteForm){
		
		log.debug("-->> searchCreditNoteByReceiptNo DAO ....");
		return getSqlMapClientTemplate().queryForList("searchCreditNoteByReceiptNo",creditNoteForm);
	}


	
	/// added by: m.gonzalez ///
	
	public List searchScheduleCreditNote(Map creditNoteForm){
		
		if(creditNoteForm.get("start")==null || creditNoteForm.get("start").toString().trim().length()==0){
			creditNoteForm.put("start","1");
			creditNoteForm.put("end","10");
			
		}
		
		log.debug("-->> searchScheduleCreditNote DAO ....");
		return getSqlMapClientTemplate().queryForList("searchScheduleCreditNote",creditNoteForm);
	}
	
	public Boolean creditNoteFromTransaction(Map m){
		return getSqlMapClientTemplate().update("creditNoteFromTransaction", m)>0;
	}

}
