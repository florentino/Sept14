/*@ Added by	:	Roldan Somontina
 *  Date added	:	May 27, 2009
 * */ 
package com.bdo.factor.dao;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.Advances;
import com.bdo.factor.beans.ReportField;
import com.bdo.factor.dataSource.InvoiceDAO;
import com.bdo.factor.service.AccountingMaintenanceService;
import com.bdo.factor.service.AdjustmentTypeService;
import com.bdo.factor.service.AuditService;
import com.bdo.factor.service.ReceiptsHeaderService;
import com.bdo.factor.service.SubHeaderService;
import com.bdo.factor.util.ServiceUtility;
import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class AdvancesDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(AdvancesDAO.class);
	private JdbcTemplate jdbcTemplate;
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	private String returnmsg;
	
	public String getReturnmsg() {
		return returnmsg;
	}
 
	public void setReturnmsg(String returnmsg) {
		this.returnmsg = returnmsg;
	}

	public AdvancesDAO(){		
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public boolean  checkHasAdvances(Map m){	
		boolean notEmpty=getSqlMapClientTemplate().queryForObject("getAllAdvances", m)!=null?true:false;
		return notEmpty;
	}
///////////////////////////////////////////////////////////////////////////////////

	public  List  getAllAdvances(Map m){	
		return getSqlMapClientTemplate().queryForList("getAllAdvances", m);
	}	

///////////////////////////////////////////////////////////////////////////////////

	public  List  getPerClient(Map m){	
		List list =getSqlMapClientTemplate().queryForList("getPerClient", m);
		log.info("getPerClient list size: "+list.size());
		return list; 
	}
	
///////////////////////////////////////////////////////////////////////////////////

	public  double  getClientAdvances(Map m){
		return (Double)getSqlMapClientTemplate().queryForObject("getClientAdvances", m);
	}
	
	public String getTotalRecordsAdvances(Map map){
		
		//System.out.println("-->> getTotalRecordsAdvances DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsAdvances",map);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchAdvances(Map map){
		log.info("-->> searchAdvances DAO ....");
		return getSqlMapClientTemplate().queryForList("searchAdvances",map);
	}
	
	public int addAdvance(Map map){
		double sc = Double.parseDouble(map.get("N_SVCCHG") !=null ? map.get("N_SVCCHG").toString() : "0");
		map.put("N_SVCCHG", sc);
		String C_TYPE = (String) map.get("C_TYPE");
		String C_CLNTCODE = (String) map.get("C_CLNTCODE");
		
		InvoiceDAO inv = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		
		
		
		//update invoice status - insert here
		if (C_TYPE.equals("2")){
			
			//double n_advamt = Double.parseDouble(map.get("N_ADVAMT").toString());
			//map.put("N_DISCCHG1", inv.getField("(dbo.getblr(C_CLNTCODE,getdate())+N_DCR/100)*"+n_advamt+"/360","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE));
		}
		/*else{
			Double	getPenalty = (Double) getJdbcTemplate().queryForObject("select sum(N_PENALTYAMOUNT) from dbo.PenCharge("+C_CLNTCODE+",'01','PC') ", Double.class);
			map.put("N_PENALTYCHG", getPenalty);
			Double	getPDInterest = (Double) getJdbcTemplate().queryForObject("select sum(N_PENALTYAMOUNT) from dbo.PenCharge("+C_CLNTCODE+",'01','PDI') ", Double.class);
			map.put("N_PDINTEREST", getPDInterest);
			}*/
		 
		boolean rv = getSqlMapClientTemplate().update("addAdvance",map)>0;
		AuditService as = AuditService.getInstance();
		int N_REFNO =0;
		log.info(map.get("C_USERID").toString());
		log.info("addAdvance>>>"+rv);
		if (rv==false){
			setReturnmsg("Add Advance Failed");
			return 0;
		}
		
		log.info("C_TYPE>>>>"+C_TYPE);
		if (C_TYPE.equals("1")){
			
		
			
			String sSQL="SELECT IDENT_CURRENT('Advances')";
			 N_REFNO = getJdbcTemplate().queryForInt(sSQL);
			if (N_REFNO==0){
				setReturnmsg("Add Advance Failed");
				return 0;
			}
			//sSQL="update Advances set N_ADVREFNO="+N_REFNO+",C_STATUS='2',N_DISCCHG1=dbo.GetDC('"+C_CLNTCODE+"',GETDATE(),0) where C_STATUS='1' and C_TYPE='2' and C_CLNTCODE="+C_CLNTCODE;
			sSQL="update Advances set N_ADVREFNO="+N_REFNO+",C_STATUS='2',N_DISCCHG1=0 where C_STATUS='1' and C_TYPE='2' and C_CLNTCODE="+C_CLNTCODE;
			rv = getJdbcTemplate().update(sSQL)>0; 
			
		
			
			
			if (rv){
				as.addAudit(map.get("C_USERID").toString(),"U","Advances","C_CLNTCODE="+C_CLNTCODE+";N_DISCCHG1="+inv.getField("top 1 N_DISCCHG1","Advances","C_STATUS='1' and C_TYPE='2' and C_CLNTCODE="+C_CLNTCODE));
			}
			log.info(sSQL + ">>>" + rv);
		}else
			return 1;
		return N_REFNO;
	}
	
	public boolean updateAdvance(Map map){
		return getSqlMapClientTemplate().update("updateAdvance",map)>0;
	}
	
	public boolean updateAdvanceStatus(Map map) throws IOException, SQLException{
		
		ServiceUtility.viewUserParameters(map);
		
		InvoiceDAO inv = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		AuditService as = AuditService.getInstance();
		AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
		boolean update=false;
		String UserId = map.get("C_USERID").toString();
		String C_CLNTCODE = (String) map.get("C_CLNTCODE");
		String C_STATUS = (String) map.get("C_STATUS");
		String C_BRANCHCODE = (String) map.get("C_BRANCHCODE");
		String C_TYPE = (String) map.get("C_TYPE");
		String sSQL;
		String N_REFNO = map.get("N_REFNO").toString();
		String D_TRANSACTIONDATE = map.get("D_TRANSACTIONDATE").toString();
		String serviceChg = getServiceCharge(N_REFNO).trim()!=null?getServiceCharge(N_REFNO):"2";
				
		/*if (serviceChg.isEmpty() || serviceChg.equals("2") ){
			serviceChg = "2";
		}else if (serviceChg.equals("1")) {
			serviceChg = "1";
		}else if (serviceChg.equals("3")){
			serviceChg = "3";
		}*/
		
	
		//AdjustmentTypeDAO.updateAdjustmentIRefnoAdvances(N_REFNO,C_CLNTCODE);
		
		if(map.get("B_CLNTRELEASE").toString().equals("true")){
			map.put("B_CLNTRELEASE", "1");
		} else {
			map.put("B_CLNTRELEASE", "0");
		}
		log.info("C_STATUS>>>>>"+C_STATUS);
		log.info("C_TYPE>>>>>"+C_TYPE);
		String whr = "C_CLNTCODE="+C_CLNTCODE+" AND C_STATUS IN ('2','3','4','5') AND B_ADVANCES=0";
		
		if (C_STATUS.equals("2")){ //pending to approved
		
			update = createLedger(map,D_TRANSACTIONDATE,C_CLNTCODE,N_REFNO);
			ReceiptsHeaderService RS =  ReceiptsHeaderService.getInstance();
			try{
				map.put("N_ADVPAYMENTNO", N_REFNO);
				map.put("transType", "N_ADVPAYMENTNO");
				map.put("C_RECEIPTTYPE", 3);
				map.put("Particular","COLLECTION FROM ADVANCE "+N_REFNO);
				RS.createReceiptPayment(new HashMap(map));
			}catch(Exception e){
				e.printStackTrace();
			}
			
			boolean updateREF = AdjustmentTypeDAO.updateAdjustmentIRefnoAdvances(N_REFNO,C_CLNTCODE,D_TRANSACTIONDATE); //CVG 05092017
			if (!updateREF){
				log.info("REFNO did not update" + updateREF );
			}
			 
			if (C_TYPE.equals("1")){
				//sSQL = "insert into discdtl (n_reference,c_type,n_advancerefno,n_discchg,d_transactiondate)	select n_invno,'R',"+N_REFNO+",N_DISCCHG,D_TRANSACTIONDATE	from InvoiceAmt where c_clntcode="+C_CLNTCODE;
//				sSQL = "exec dbo.sp_discdtl 'A',"+N_REFNO+","+C_CLNTCODE;
//				log.info(sSQL);
//				update = getJdbcTemplate().update(sSQL)>0?true:false;
//				log.info(">>"+update);
				
				sSQL = "UPDATE Invoice SET C_STATUS=CASE WHEN C_STATUS='2' THEN '3' ELSE C_STATUS END,N_ADVREFNO="+N_REFNO+",B_ADVANCES=1, N_SVCCHGTYPE="+serviceChg +" WHERE "+whr;
				log.info(sSQL);
				update = getJdbcTemplate().update(sSQL)>0?true:false;
				if (!update){
					setReturnmsg("No Invoices for this client");
					return false;
				}
			}
			
			if (C_TYPE.equals("3") || C_TYPE.equals("1")){
				sSQL = "UPDATE advances SET B_RELEASED=1,N_ADVREFNO="+N_REFNO+" WHERE c_clntcode="+C_CLNTCODE+" and B_RELEASED=0 and C_TYPE='1' and C_STATUS='2'";
				log.info(sSQL);
				update = getJdbcTemplate().update(sSQL)>0?true:false;
				if (C_TYPE.equals("3") && !update){
					setReturnmsg("No Advances for this client");
					return false;
				}
			}

			String nIR = inv.getField("n_ineligiblerec", "advances", "n_refno="+N_REFNO);
			log.info("n_ineligiblerec"+nIR);
			if (!nIR.equals("0.00")){
				sSQL = "UPDATE advances SET B_RELEASED=0 where n_refno="+N_REFNO;
				log.info(sSQL);
				update = getJdbcTemplate().update(sSQL)>0?true:false;
			}
			
			//whr = "C_CLNTCODE="+C_CLNTCODE+" AND C_STATUS IN ('3','4','5') AND B_ADVANCES=0";
			//sSQL = "UPDATE Invoice SET N_ADVREFNO="+N_REFNO+",B_ADVANCES=1 WHERE D_TRANSACTIONDATE BETWEEN dbo.GetDateRange('"+D_TRANSACTIONDATE+"') AND '"+D_TRANSACTIONDATE+"' AND "+whr;
			//log.info(sSQL);
			//boolean update2 = getJdbcTemplate().update(sSQL)>0?true:false;
			//if (update==false && update2==false){
			//	setReturnmsg("No Invoices for this client");
			//	return false;
			//}
			
			//String AdvAmt = inv.getField("SUM(N_ADVAMT)", "Advances", "N_REFNO="+N_REFNO+" OR N_ADVREFNO="+N_REFNO);
			String AdvAmt = inv.getField("SUM(N_ADVAMT)", "Advances", "N_REFNO="+N_REFNO);
			log.info("AdvAmt>>>>"+AdvAmt);
			if (AdvAmt.equals("No Data")){
				AdvAmt = "0";
			}
			//String IR = inv.getField("N_INELIGIBLEREC", "dbCIF.dbo.Client", "C_CLNTCODE="+C_CLNTCODE);
			//log.info("IR==>"+IR);
			String IA = inv.getField("ROUND(N_INELIGIBLEADV+(N_INELIGIBLEREC * N_ADVANCEDRATIO / 100 - N_INELIGIBLEADV),2)", "dbCIF.dbo.Client", "C_CLNTCODE="+C_CLNTCODE);
			log.info("ineligible adv>>>"+IA);
			if (Double.parseDouble(IA)<=0){
				IA = inv.getField("N_INELIGIBLEADV", "dbCIF.dbo.Client", "C_CLNTCODE="+C_CLNTCODE);
			}
			/*
			sSQL = "UPDATE dbCIF.dbo.Client SET "+
			"N_RESERVES=N_RESERVES-("+AdvAmt+"),N_FIUTRAN=N_FIUTRAN+("+AdvAmt+
			"),N_INELIGIBLEREC=0,N_INELIGIBLEADV="+IA+" WHERE C_CLNTCODE="+C_CLNTCODE;
			*/
			sSQL = "UPDATE dbCIF.dbo.Client SET "+
				"N_RESERVES=N_RESERVES-("+AdvAmt+"),N_FIUTRAN=N_FIUTRAN+("+AdvAmt+
				"),N_INELIGIBLEADV="+IA+" WHERE C_CLNTCODE="+C_CLNTCODE;
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			if (update){
				sSQL="N_RESERVES="+inv.getField("N_RESERVES","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
				";N_FIUTRAN="+inv.getField("N_FIUTRAN","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
				";N_INELIGIBLEADV="+IA+
				";C_CLNTCODE="+C_CLNTCODE;
				as.addAudit(UserId,"U","Client",sSQL);
			}
			log.info("update...."+update);
			
			/*sSQL = "INSERT INTO AMS (D_TRANSACTIONDATE, C_CLIENTCODE, N_AMOUNT, C_TYPE, C_BRANCHCODE, N_REFNO) values ('"+
			D_TRANSACTIONDATE+"',"+C_CLNTCODE+","+AdvAmt+",'A','"+C_BRANCHCODE+"',"+N_REFNO+")";
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			if (update){
				as.addAudit(UserId,"I","AMS",sSQL);
			}
			log.info("update...."+update);*/
			
			
			
			//update the advance
			//
			sSQL = "UPDATE Advances SET C_APPROVER='"+UserId+"',C_STATUS='2',IR=(select dbo.getCustIR(Advances.C_CLNTCODE)),N_INVOICEAMT=(select sum(N_INVOICEAMT)*(select n_advancedratio/100 from dbcif.dbo.client where c_clntcode=advances.c_clntcode) from invoice where N_ADVREFNO="+N_REFNO+") WHERE (N_REFNO="+N_REFNO+")";
			//sSQL = "UPDATE Advances SET C_STATUS='2',IR=(select dbo.getCustIR(Advances.C_CLNTCODE)) WHERE (N_REFNO="+N_REFNO+")";
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			if (update){
				as.addAudit(UserId,"U","Advances","C_STATUS='2',IR="+inv.getField("IR", "Advances", "N_REFNO="+N_REFNO));
			}
			
			//sSQL = "UPDATE cclink SET N_INELIGIBLEREC=0 WHERE C_CLNTCODE="+C_CLNTCODE;
			//log.info(sSQL);
			//update = getJdbcTemplate().update(sSQL)>0?true:false;
			//if (update){
			//	as.addAudit(UserId,"U","cclink","N_INELIGIBLEREC=0(C_CLNTCODE"+C_CLNTCODE+")");
			//}
		    
			
			 
		} else if (C_STATUS.equals("3")){ //cancel from pending
			/*
			String IR = inv.getField("IR", "Advances", "N_REFNO="+N_REFNO);
			if (IR != "No Data"){
				String[] rec=IR.split(";");
				for (int i=0;i<rec.length;i++){
					String[] val=rec[i].split("=");
					sSQL = "UPDATE cclink SET N_INELIGIBLEREC=N_INELIGIBLEREC+"+val[1]+" WHERE C_CUSTCODE="+val[0]+" AND C_CLNTCODE="+C_CLNTCODE;
					log.info(sSQL);
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					sSQL = "UPDATE dbCIF.dbo.Client SET N_INELIGIBLEREC=N_INELIGIBLEREC+"+val[1]+" WHERE C_CLNTCODE="+C_CLNTCODE;
					log.info(sSQL);
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					if (update){
						IR = inv.getField("N_INELIGIBLEREC", "cclink", "C_CUSTCODE="+val[0]+" AND C_CLNTCODE="+C_CLNTCODE);;
						as.addAudit(UserId,"U","cclink","N_INELIGIBLEREC="+IR+"+"+val[1]+"(CANCEL Advances.N_REFNO"+N_REFNO+",C_CLNTCODE"+C_CLNTCODE+",C_CUSTCODE"+val[0]+")");
					}
				}
			}
			*/
			/*INVOICEDAO ID = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			
			List<Map> invoiceList = new ArrayList<Map>();
			try{ 
				invoiceList =ID.getInvoiceForCancel(N_REFNO);
			}catch(Exception e)
			{e.printStackTrace();}*/
			
			try{
				ReceiptsHeaderService RHS = ReceiptsHeaderService.getInstance();
				RHS.cancelFromTransaction(N_REFNO,"N_ADVPAYMENTNO");
			}catch(Exception e){
				e.printStackTrace();
			}
			//update the setting up fee
			sSQL = "UPDATE Advances SET C_STATUS='1',N_ADVREFNO=null WHERE N_ADVREFNO="+N_REFNO;
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			
			//update the advance
			sSQL = "UPDATE Advances SET C_STATUS='3',D_CANCELLEDDATE=(select [currentdate] FROM [factorsGetDate]) WHERE (N_REFNO="+N_REFNO+")"; //before: getDate()
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			
			boolean cancelRefNo = AdjustmentTypeDAO.cancelAdjustmentIRefno(map); //CVG 05092017
			if (!cancelRefNo){
				log.info("REF_NO not deleted");
			}
			
			
		/*	
			int receiptRefNo = (Integer) getJdbcTemplate().queryForObject("SELECT n_refno from receiptshdr where n_advpaymentno = "+N_REFNO, Integer.class);

			
			log.info("asd");
			getJdbcTemplate().update("UPDATE receiptsHdr set d_datebounced=convert(nvarchar,getdate(),101), c_status=3 where n_advpaymentno="+N_REFNO);
			getJdbcTemplate().update("UPDATE creditNote set c_status=3,d_cancelleddate=convert(nvarchar,getdate(),101) where c_receiptno= "+receiptRefNo);
			try{
				if(invoiceList.size()!=0){
					for (int x =0; x<invoiceList.size();x++){
						getJdbcTemplate().update("UPDATE invoice SET c_status="+invoiceList.get(x).get("c_status")+", " +
								"d_fullypaiddate = null WHERE n_invno ="+invoiceList.get(x).get("n_invno"));
					}
				}
			}catch(Exception e){
				e.printStackTrace();
			}*/
			
			
			
			
		} else if (C_STATUS.equals("4")){ //cancel from approved		
			try{
				ReceiptsHeaderService RHS = ReceiptsHeaderService.getInstance();
				RHS.cancelFromTransaction(N_REFNO,"N_ADVPAYMENTNO");
			}catch(Exception e){
				e.printStackTrace();
			}
			C_STATUS = "3";
			map.put("C_STATUS", C_STATUS);
			boolean cancelRefNo = AdjustmentTypeDAO.cancelAdjustmentIRefno(map); //CVG 05092017
			if (!cancelRefNo){
				log.info("REF_NO not deleted");
			}
			sSQL = "delete from discdtl where C_TYPE='A' and N_ADVANCEREFNO="+N_REFNO;
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			log.info(sSQL+">>"+update);
			//added N_SVCCHGTYPE 09182018
			sSQL = "UPDATE Invoice SET C_STATUS='2',N_ADVREFNO=null,B_ADVANCES=0,N_SVCCHGTYPE=null WHERE C_STATUS='3' AND N_ADVREFNO="+N_REFNO;
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			log.info(update);
			
			sSQL = "UPDATE Invoice SET N_ADVREFNO=null,B_ADVANCES=0,N_SVCCHGTYPE=null WHERE C_STATUS > '3' AND N_ADVREFNO="+N_REFNO;
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			log.info(update);

//			sSQL = "DELETE FROM AMS WHERE C_TYPE='A' AND N_REFNO="+N_REFNO;
//			log.info(sSQL);
//			update = getJdbcTemplate().update(sSQL)>0?true:false;
//			log.info("update...."+update);
			map.put("C_TRANSACTIONTYPE", "A");
			SubHeaderService.getInstance().cancelSubHeaderEntry(map);
			
			
			String AdvAmt = inv.getField("SUM(N_ADVAMT)", "Advances", "N_REFNO="+N_REFNO+" OR N_ADVREFNO="+N_REFNO);
			log.info("AdvAmt>>>>"+AdvAmt);
			if (AdvAmt.equals("No Data")){
				AdvAmt = "0";
			}
			String IR = inv.getField("N_INELIGIBLEREC", "Advances", "N_REFNO="+N_REFNO);
			log.info("ineligible recls>>>"+IR);
			if (IR.equals("No Data")){
				IR = "0";
			}
			String IA = inv.getField("ROUND(N_INELIGIBLEADV+(N_INELIGIBLEREC * N_ADVANCEDRATIO / 100 - N_INELIGIBLEADV),2)", "dbCIF.dbo.Client", "C_CLNTCODE="+C_CLNTCODE);
			log.info("ineligible adv>>>"+IA);
			
			/*
			sSQL = "UPDATE dbCIF.dbo.Client SET "+
				"N_RESERVES=N_RESERVES+("+AdvAmt+"),N_FIUTRAN=N_FIUTRAN-("+AdvAmt+
				"),N_INELIGIBLEADV=N_INELIGIBLEADV-("+IA+"),N_INELIGIBLEREC=N_INELIGIBLEREC+(select (N_INELIGIBLEREC/(N_ADVANCEDRATIO/100)) from advances where n_refno="+N_REFNO+") WHERE C_CLNTCODE="+C_CLNTCODE;
			*/
			sSQL = "UPDATE dbCIF.dbo.Client SET "+
			"N_RESERVES=N_RESERVES+("+AdvAmt+"),N_FIUTRAN=N_FIUTRAN-("+AdvAmt+
			"),N_INELIGIBLEADV=N_INELIGIBLEADV-("+IA+") WHERE C_CLNTCODE="+C_CLNTCODE;
			log.info("CLIENT IR..."+sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			if (update){
				sSQL="N_RESERVES="+inv.getField("N_RESERVES","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
				";N_FIUTRAN="+inv.getField("N_FIUTRAN","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
				";N_INELIGIBLEADV="+inv.getField("N_INELIGIBLEADV","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
				";C_CLNTCODE="+C_CLNTCODE;
				as.addAudit(map.get("C_USERID").toString(),"U","Client",sSQL);
			}
			log.info("update...."+update);
			
			/*
			IR = inv.getField("IR", "Advances", "N_REFNO="+N_REFNO);
			log.info("@@@"+IR);
			if (IR != "No Data"){
				String[] rec=IR.split(";");
				for (int i=0;i<rec.length;i++){
					String[] val=rec[i].split("=");
					sSQL = "UPDATE cclink SET N_INELIGIBLEREC=N_INELIGIBLEREC+"+val[1]+" WHERE C_CUSTCODE="+val[0]+" AND C_CLNTCODE="+C_CLNTCODE;
					log.info(sSQL);
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					sSQL = "UPDATE dbCIF.dbo.Client SET N_INELIGIBLEREC=N_INELIGIBLEREC+"+val[1]+" WHERE C_CLNTCODE="+C_CLNTCODE;
					log.info(sSQL);
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					if (update){
						IR = inv.getField("N_INELIGIBLEREC", "cclink", "C_CUSTCODE="+val[0]+" AND C_CLNTCODE="+C_CLNTCODE);;
						as.addAudit(UserId,"U","cclink","N_INELIGIBLEREC="+IR+"+"+val[1]+"(CANCEL Advances.N_REFNO"+N_REFNO+",C_CLNTCODE"+C_CLNTCODE+",C_CUSTCODE"+val[0]+")");
					}
				}
			}
			*/
			//update the setting up fee
			sSQL = "UPDATE Advances SET C_STATUS='1',N_ADVREFNO=null WHERE C_TYPE='2' AND N_ADVREFNO="+N_REFNO;
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
			
			log.info("C_TYPE>>>>>"+C_TYPE);
			if (C_TYPE.equals("3")){
				sSQL = "UPDATE advances SET B_RELEASED=0,N_ADVREFNO=0 WHERE c_clntcode="+C_CLNTCODE+" and C_TYPE='1' and N_ADVREFNO="+N_REFNO;
				log.info(sSQL);
				update = getJdbcTemplate().update(sSQL)>0?true:false;
			}
			
			//update the advance
			sSQL = "UPDATE Advances SET C_STATUS='3',D_CANCELLEDDATE=(select [currentdate] FROM [factorsGetDate]) WHERE (N_REFNO="+N_REFNO+")"; //before:getDate()
			log.info(sSQL);
			update = getJdbcTemplate().update(sSQL)>0?true:false;
		}
		//update=getSqlMapClientTemplate().update("updateAdvanceStatus",map)>0?true:false;
		//log.info("UPDATE>>>>>"+update);
		return update;
	}
	
	
	public double getTotalAdvanceByDateRange(Map map) {
		return (Double)getSqlMapClientTemplate().queryForObject("getTotalAdvanceByDateRange", map);
	}
	
	public int getAdvancesSettingUpRefNo(int n_refNo) {
		Integer i = (Integer)getSqlMapClientTemplate().queryForObject("getAdvancesSettingUpRefNo", new Integer(n_refNo));
		if (i == null) {
			i = 0;
		}
		return i;
	}
	
	public int getAdvancesReportSize(int n_refNo) {
		Integer i = (Integer)getSqlMapClientTemplate().queryForObject("getAdvancesReportSize", new Integer(n_refNo));
		if (i == null) {
			i = 0;
		}
		return i;
	}
	
	public void taggingPrepaymentAdviceReport(Map map){
		getSqlMapClientTemplate().update("taggingPrepaymentAdviceReport",map);
		log.info("taggingPrepaymentAdviceReport inside AdvancesDAO" );
	}	
	
	public static void main(String[] args){
		AdvancesDAO advanceDao =(AdvancesDAO)Persistence.getDAO("advanceDao");
		Map m =new HashMap();
		m.put("C_CLNTCODE", "1");
		m.put("D_TRANDATE", "6/5/2009");
		System.out.println("trial for advanceDao.getClientAdvances(m)=> "+advanceDao.getClientAdvances(m));		
	}
	
	public boolean updateReceiptAdvanceStatus(Map map){
		boolean update=getSqlMapClientTemplate().update("updateReceiptAdvanceStatus",map)>0?true:false;
		return update;
	}
	
	public List<ReportField> getMonthlyChargesReport(Map map){
		return getSqlMapClientTemplate().queryForList("getMonthlyChargesReport", map);
	}
	
	public List<ReportField> getScheduleOfAdvances(String whereClause){
		return getSqlMapClientTemplate().queryForList("getScheduleOfAdvances", whereClause);
	}	
	

	public List searchClientAvailability(Map map){
		
		System.out.println("-->> searchClientAvailability DAO ....");
		return getSqlMapClientTemplate().queryForList("searchClientAvailability",map);
	}
	
	public Boolean createLedger(Map map, String D_TRANSACTIONDATE, String C_CLNTCODE, String N_REFNO)  {
		try{
		Boolean successFunction = false;
		Map svccharge = new HashMap();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
		AccountingMaintenanceService AMS = AccountingMaintenanceService.getInstance();
		//log.info(">>>>>>>>>>>>>>>>"+getSqlMapClientTemplate().queryForObject("transactionRateAdv",map));
		successFunction = AMS.saveTransactionRate((Map) getSqlMapClientTemplate().queryForObject("transactionRateAdv",map));
		
		SubHeaderService SHS = SubHeaderService.getInstance();
		
		Map adv =  (Map) getSqlMapClientTemplate().queryForObject("getAdvance",map);
		List<String> invoices = getJdbcTemplate().queryForList("SELECT n_invno FROM invoice where c_status=2 AND c_clntcode="+C_CLNTCODE);
		adv.put("D_TRANSACTIONDATE", SDF.format(date.newDate())); //before: new Date()
		adv.put("C_Type","D");
		adv.put("C_TransactionType", "A");
		adv.put("C_USERID",map.get("C_USERID")!=null?map.get("C_USERID"):null);
		adv.put("invoices", invoices.toString());
		Long success = new Long(0);
		if(successFunction)
		success = SHS.createSubHeader(adv, "ADVANCES", D_TRANSACTIONDATE,  "ADVANCES");
	
	if(success!=0){	
		try{		     
			 svccharge =  getJdbcTemplate().queryForMap("select n_computedamt,n_discchg1 from advances where n_advrefno ="+N_REFNO);
		    }
		    catch(EmptyResultDataAccessException e){
		    	System.out.println("No Service Charge");
		    }
		    catch(Exception e){
		    	e.printStackTrace();
		    	return false;
		    }
		Double ratio = (Double) getJdbcTemplate().queryForObject("select  (100-n_advancedratio)/100  from dbcif..Client where c_clntcode="+C_CLNTCODE, Double.class);
		 
		if(adv.get("C_TYPE")!=null &&! adv.get("C_TYPE").toString().contentEquals("2")){
			Double FacRec = (Double) getJdbcTemplate().queryForObject("SELECT ISNULL(SUM(n_invoiceamt),0) FROM invoices WHERE c_clntcode ="+C_CLNTCODE+" AND c_status=2",Double.class);
			adv.put("FacRec",FacRec);
			Double ClEq = (Double)(FacRec*ratio);
			adv.put("ClEq",ClEq);
			adv.put("serviceCharge",adv.get("N_SVCCHG"));
			adv.put("interest",adv.get("Proceeds"));
			adv.put("n_discchg1",svccharge.get("n_discchg1")!=null?svccharge.get("n_discchg1"):0);
			adv.put("setupFee",svccharge.get("n_computedamt")!=null?svccharge.get("n_computedamt"):0);
			adv.put("penalty",adv.get("N_PENALTYCHG"));
			adv.put("n_amount",adv.get("N_Amount"));
			adv.put("DST",adv.get("N_DISCCHG2"));
			adv.put("pd_interest",adv.get("N_PDINTEREST"));
			adv.put("n_dcreversal",adv.get("N_DCREVERSAL"));
			adv.put("C_USERID", map.get("C_USERID").toString());
			adv.put("n_notarial", map.get("N_NOTARIAL"));
			successFunction = SubHeaderService.getInstance().createLedgerEntry2(adv, "Advances", success);
			successFunction = SubHeaderService.getInstance().createAdjustmentEntry(map, success);
			if (!successFunction){
				log.info("createAdjustmentEntry unsuccessful");
			}
		
		}
		else{
			log.info("No Journal Entry Created");
			return true;
			}
	}
		return successFunction;
		}catch(Exception e)
		{e.printStackTrace();}return true;
	}
	
	//rr 04172012
	public Integer insertDiscountDetail(Map map){
		System.out.println("-->> insertDiscountDetail"); 
	    return (Integer) getSqlMapClientTemplate().update("insertDiscountDetail", map);	
	}
	
	public Integer insertPenaltyDetail(Map map){
		System.out.println("-->> insertPenaltyDetail"); 
	    return (Integer) getSqlMapClientTemplate().update("insertPenaltyDetail", map);	
	}
	//--
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public double getFinanceAmount(String clntcode, String asOfDate){
		Map finAmt = new HashMap();
		finAmt.put("asOfDate", asOfDate);
		finAmt.put("clntcode", clntcode);
		return (Double)getSqlMapClientTemplate().queryForObject("getFinanceAmount", finAmt);
	}
	
	public String getServiceCharge(String refno){
	
		return (String) getSqlMapClientTemplate().queryForObject("getServiceCharge", refno);
	}
	public  double  GetDocStampAmount(Map m){
		return (Double)getSqlMapClientTemplate().queryForObject("GetDocStampAmount", m);
	}
	
 
}
