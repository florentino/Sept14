package com.bdo.factor.dao;

import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class ChartOfAccountDAO extends SqlMapClientDaoSupport{
	
	public Map getGL(String m){
		return (Map)getSqlMapClientTemplate().queryForObject("getGL", m);
	}

}
