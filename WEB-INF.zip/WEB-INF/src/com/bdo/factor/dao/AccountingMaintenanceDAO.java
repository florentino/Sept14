package com.bdo.factor.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class AccountingMaintenanceDAO extends SqlMapClientDaoSupport implements AccountingMaintenanceDAOInterface {
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	
	
//CHART		OF		ACCOUNT		METHODS
	@Override
	public String countChartOfAccount(Map m) {
		 return (String) getSqlMapClientTemplate().queryForObject("countChartOfAccount",m);
	}

	@Override
	public List getChartOfAccount(Map m) {
		return  getSqlMapClientTemplate().queryForList("getChartOfAccount",m);
	}

	@Override
	public Boolean addChartOfAccount(Map m) {	
		return getSqlMapClientTemplate().update("addChartOfAccount",m)>0;
	}
	
	@Override
	public Map getChart(String m) {
		return (Map)getSqlMapClientTemplate().queryForObject("getChart", m);
	}

	@Override
	public Boolean deleteChartOfAccount(Map m) {
		return getSqlMapClientTemplate().update("deleteChartOfAccount",m)>0;
	}

	@Override
	public Boolean editChartOfAccount(Map m) {
		return getSqlMapClientTemplate().update("editChartOfAccount",m)>0;
	}
	
	public List<Map> getChartList(){
		return (List<Map>) getSqlMapClientTemplate().queryForList("getChartList");
	}
	
	@Override
	public List getGLList(){
		return getSqlMapClientTemplate().queryForList("getGLList");
	}

	public Double getAmount(String GLCode){
		return (Double) getSqlMapClientTemplate().queryForObject("getAmount",GLCode);
	}
	
	public Boolean checkGLDuplicate(String glcode){
		return   getSqlMapClientTemplate().queryForList("checkGLDuplicate",glcode).size()==0;
	}
	
	//COST		CENTER		METHODS
	@Override
	public String countCostCenter(Map m) {
		 return (String) getSqlMapClientTemplate().queryForObject("countCostCenter",m);
	}

	@Override
	public List getCostCenter(Map m) {
		return getSqlMapClientTemplate().queryForList("getCostCenter",m);
	}

	@Override
	public Boolean addCostCenter(Map m) {
		return getSqlMapClientTemplate().update("addCostCenter",m)>0;
	}

	@Override
	public Boolean editCostCenter(Map m) { 
		return getSqlMapClientTemplate().update("editCostCenter",m)>0;
	}

	@Override
	public Boolean deleteCostCenter(Map m) { 
		return getSqlMapClientTemplate().update("deleteCostCenter",m)>0;
	}

	//removed the Map value List<Map>
	public List<Map> getCostCenterList(){
		return getSqlMapClientTemplate().queryForList("getCostCenterList");
	}

	public Boolean checkCostCenterDuplicate(String N_CODE){
		return   getSqlMapClientTemplate().queryForList("checkCostCenterDuplicate",N_CODE).size()==0;
	}
//PENALTY	CHARGES		METHODS	
	@Override
	public String countPenaltyCharge(Map m) {
		return (String) getSqlMapClientTemplate().queryForObject("countPenaltyCharge",m);
	}

	@Override
	public List getPenaltyCharge(Map m) {
		return getSqlMapClientTemplate().queryForList("getPenaltyCharge",m);
	}

	@Override
	public Boolean addPenalty(Map m) {
		return getSqlMapClientTemplate().update("addPenalty", m)>0;
	}

//OTHER METHODS
	@Override
	public Long getClientCode(Map m){
		return (Long) getSqlMapClientTemplate().queryForObject("getClientCode", m);
	}

	@Override
	public Boolean saveTransactionRate(Map m){
		return getSqlMapClientTemplate().update("saveTransactionRate",m)>0;
		
	}
	
	@Override
	public Object queryForObject(String sql){
		return	getJdbcTemplate().queryForObject(sql, Object.class);
	}
	 
}
