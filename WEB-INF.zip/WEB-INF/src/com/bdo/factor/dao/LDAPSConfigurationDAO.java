package com.bdo.factor.dao;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.LDAPSConfiguration;

public class LDAPSConfigurationDAO extends SqlMapClientDaoSupport {
	
	public LDAPSConfiguration getLDAPSConfiguration(){
		return (LDAPSConfiguration) getSqlMapClientTemplate().queryForObject("getLDAPSConfiguration");
	}
	

}
