package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class BLRFileDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(BLRFileDAO.class);


//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchBLRFile(Map map){
		
		log.debug("-->> searchBLRFile DAO ....");
		return getSqlMapClientTemplate().queryForList("searchBLRFile",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public List searchBLRFileByTypeCode(Map map){
		
		log.debug("-->> searchBLRFileByTypeCode DAO ....");
		return getSqlMapClientTemplate().queryForList("searchBLRFileByTypeCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean addBLRFile(Map map){
		
		if(map.containsKey("N_BLR1") && (map.get("N_BLR1")==null || map.get("N_BLR1").toString().trim().length()==0)){
			map.put("N_BLR1","0");
		}
		
		if(map.containsKey("N_BLR2") && (map.get("N_BLR2")==null || map.get("N_BLR2").toString().trim().length()==0)){
			map.put("N_BLR2","0");
		}
		
		if(map.containsKey("N_BLR3") && (map.get("N_BLR3")==null || map.get("N_BLR3").toString().trim().length()==0)){
			map.put("N_BLR3","0");
		}
		
		if(map.containsKey("N_BLR4") && (map.get("N_BLR4")==null || map.get("N_BLR4").toString().trim().length()==0)){
			map.put("N_BLR4","0");
		}
		
		if(map.containsKey("N_BLR5") && (map.get("N_BLR5")==null || map.get("N_BLR5").toString().trim().length()==0)){
			map.put("N_BLR5","0");
		}
		
		//////////////////////////////
		
		if(map.containsKey("D_EFFDT1") && (map.get("D_EFFDT1")==null || map.get("D_EFFDT1").toString().trim().length()==0)){
			map.put("D_EFFDT1",null);
		}
		if(map.containsKey("D_EXPDT1") && (map.get("D_EXPDT1")==null || map.get("D_EXPDT1").toString().trim().length()==0)){
			map.put("D_EXPDT1",null);
		}
		if(map.containsKey("D_EFFDT2") && (map.get("D_EFFDT2")==null || map.get("D_EFFDT2").toString().trim().length()==0)){
			map.put("D_EFFDT2",null);
		}
		if(map.containsKey("D_EXPDT2") && (map.get("D_EXPDT2")==null || map.get("D_EXPDT2").toString().trim().length()==0)){
			map.put("D_EXPDT2",null);
		}
		if(map.containsKey("D_EFFDT3") && (map.get("D_EFFDT3")==null || map.get("D_EFFDT3").toString().trim().length()==0)){
			map.put("D_EFFDT3",null);
		}
		if(map.containsKey("D_EXPDT3") && (map.get("D_EXPDT3")==null || map.get("D_EXPDT3").toString().trim().length()==0)){
			map.put("D_EXPDT3",null);
		}
		if(map.containsKey("D_EFFDT4") && (map.get("D_EFFDT4")==null || map.get("D_EFFDT4").toString().trim().length()==0)){
			map.put("D_EFFDT4",null);
		}
		if(map.containsKey("D_EXPDT4") && (map.get("D_EXPDT4")==null || map.get("D_EXPDT4").toString().trim().length()==0)){
			map.put("D_EXPDT4",null);
		}
		if(map.containsKey("D_EFFDT5") && (map.get("D_EFFDT5")==null || map.get("D_EFFDT5").toString().trim().length()==0)){
			map.put("D_EFFDT5",null);
		}
		if(map.containsKey("D_EXPDT5") && (map.get("D_EXPDT5")==null || map.get("D_EXPDT5").toString().trim().length()==0)){
			map.put("D_EXPDT5",null);
		}
		
		return getSqlMapClientTemplate().update("addBLRFile",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateBLRFile(Map map){
		
		if(map.containsKey("N_BLR1") && (map.get("N_BLR1")==null || map.get("N_BLR1").toString().trim().length()==0)){
			map.put("N_BLR1","0");
		}
		
		if(map.containsKey("N_BLR2") && (map.get("N_BLR2")==null || map.get("N_BLR2").toString().trim().length()==0)){
			map.put("N_BLR2","0");
		}
		
		if(map.containsKey("N_BLR3") && (map.get("N_BLR3")==null || map.get("N_BLR3").toString().trim().length()==0)){
			map.put("N_BLR3","0");
		}
		
		if(map.containsKey("N_BLR4") && (map.get("N_BLR4")==null || map.get("N_BLR4").toString().trim().length()==0)){
			map.put("N_BLR4","0");
		}
		
		if(map.containsKey("N_BLR5") && (map.get("N_BLR5")==null || map.get("N_BLR5").toString().trim().length()==0)){
			map.put("N_BLR5","0");
		}
		
		//////////////////////////////
		
		if(map.containsKey("D_EFFDT1") && (map.get("D_EFFDT1")==null || map.get("D_EFFDT1").toString().trim().length()==0)){
			map.put("D_EFFDT1",null);
		}
		if(map.containsKey("D_EXPDT1") && (map.get("D_EXPDT1")==null || map.get("D_EXPDT1").toString().trim().length()==0)){
			map.put("D_EXPDT1",null);
		}
		if(map.containsKey("D_EFFDT2") && (map.get("D_EFFDT2")==null || map.get("D_EFFDT2").toString().trim().length()==0)){
			map.put("D_EFFDT2",null);
		}
		if(map.containsKey("D_EXPDT2") && (map.get("D_EXPDT2")==null || map.get("D_EXPDT2").toString().trim().length()==0)){
			map.put("D_EXPDT2",null);
		}
		if(map.containsKey("D_EFFDT3") && (map.get("D_EFFDT3")==null || map.get("D_EFFDT3").toString().trim().length()==0)){
			map.put("D_EFFDT3",null);
		}
		if(map.containsKey("D_EXPDT3") && (map.get("D_EXPDT3")==null || map.get("D_EXPDT3").toString().trim().length()==0)){
			map.put("D_EXPDT3",null);
		}
		if(map.containsKey("D_EFFDT4") && (map.get("D_EFFDT4")==null || map.get("D_EFFDT4").toString().trim().length()==0)){
			map.put("D_EFFDT4",null);
		}
		if(map.containsKey("D_EXPDT4") && (map.get("D_EXPDT4")==null || map.get("D_EXPDT4").toString().trim().length()==0)){
			map.put("D_EXPDT4",null);
		}
		if(map.containsKey("D_EFFDT5") && (map.get("D_EFFDT5")==null || map.get("D_EFFDT5").toString().trim().length()==0)){
			map.put("D_EFFDT5",null);
		}
		if(map.containsKey("D_EXPDT5") && (map.get("D_EXPDT5")==null || map.get("D_EXPDT5").toString().trim().length()==0)){
			map.put("D_EXPDT5",null);
		}
		
		return getSqlMapClientTemplate().update("updateBLRFile",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteBLRFile(Map map){
		return getSqlMapClientTemplate().delete("deleteBLRFile",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsBLRFile(){
		
		log.debug("-->> getTotalRecordsBLRFile DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsBLRFile");
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchDiscountChargeBLRFile(Map map){
		
		log.debug("-->> searchDiscountChargeBLRFile DAO ....");
		return getSqlMapClientTemplate().queryForList("searchDiscountChargeBLRFile",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	
	public List searchBLRInquiry(Map map){
		
		log.debug("-->> searchBLRInquiry DAO ....");
		return getSqlMapClientTemplate().queryForList("searchBLRInquiry",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	
};