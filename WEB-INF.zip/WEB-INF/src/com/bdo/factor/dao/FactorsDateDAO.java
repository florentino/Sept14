package com.bdo.factor.dao;

import java.util.Date;
import java.lang.Integer;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import org.apache.log4j.Logger;

public class FactorsDateDAO extends SqlMapClientDaoSupport {
	private static Logger log = Logger.getLogger(FactorsDateDAO.class);
	
	public Date newDate(){
		return (Date)getSqlMapClientTemplate().queryForObject("getNewDate");	
	}
	
	public String getDayOrdinalNumber(int day){
		if (day>=11 && day <=13){
			return "th";
		}
		switch (day % 10){
		case 1: return "st";
		case 2: return "nd";
		case 3: return "rd";
		default: return "th";
		}
	}
	
/*	public int month(){
		log .info("---------------------------> new month Dao");
		return (Integer)getSqlMapClientTemplate().queryForObject("getMonth");	
	}
	
	public int year(){
		log .info("---------------------------> new year Dao");
		return (Integer)getSqlMapClientTemplate().queryForObject("getYear");	
	} */

	
}
