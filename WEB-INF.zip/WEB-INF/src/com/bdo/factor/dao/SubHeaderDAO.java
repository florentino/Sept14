package com.bdo.factor.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class SubHeaderDAO extends SqlMapClientDaoSupport{
	private JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public Boolean addLedger(Map map){
		return getSqlMapClientTemplate().update("addLedger", map)>0;
	}
	
	public Long createSubHeader(Map m){
		return (Long) getSqlMapClientTemplate().insert("createSubHeader",m);
	}
	
	public Boolean updateParticulars(Map m){
		return getSqlMapClientTemplate().update("updateParticulars",m)>0;
	}
	
	
	public Integer addNumberSeries(Map map){
		return getSqlMapClientTemplate().update("addNumberSeries", map);
	}
	
	public Long getNumberSeries() throws SQLException{
		Map m = new HashedMap();
		m.put("N_TRANSACTIONNO",(Integer)getSqlMapClientTemplate().queryForObject("getNumberSeries"));
		return (Long) getSqlMapClient().insert("addNumberSeries",m);
	}
	
	public Map getDetails(Map m){
		return (Map)getSqlMapClientTemplate().queryForObject("getDetails", m);
	}

	public Boolean cancelSubHeaderEntry(Map m){
	return 	getSqlMapClientTemplate().update("cancelSubHeaderEntry",m)>0;
	}
	
	public String countSubHeader(Map m){
		return (String) getSqlMapClientTemplate().queryForObject("countSubheader",m);
	}
	
	public List getSubHeader(Map m){
		return getSqlMapClientTemplate().queryForList("getSubHeader",m);
	}
	
	public String countSubLedger(Map m){
		return (String) getSqlMapClientTemplate().queryForObject("countSubLedger",m);
	}
	
	public List getSubLedger(Map m){
		return getSqlMapClientTemplate().queryForList("getSubLedger",m);
	}
	
	public Map getInfoByTransactionNo(Map m){
		return (Map) getSqlMapClientTemplate().queryForObject("getInfoByTransactionNo",m);
	}
	
	public Boolean updateForCN(Map m){
		return getSqlMapClientTemplate().update("updateForCN",m)>0;
	}
	
	public String getParticular(Map m){
		return (String) getSqlMapClientTemplate().queryForObject("getParticular",m);
	}
	
	
	
	
	//////ADVANCES
	public List<Map> getQueryMap(String sql){
		return getJdbcTemplate().queryForList(sql);
	}
	
	public List<String> getQueryString(String sql){
		return getJdbcTemplate().queryForList(sql);
	}
	
	public String[] getQueryArray(String sql){
		return (String[]) getJdbcTemplate().queryForObject(sql, String[].class);
		
	}
	
	
	//////REFUND
	
	//////COLLECTION
	public Map getCollectionRefHeader(int n_RefNo){
		return (Map) getSqlMapClientTemplate().queryForObject("getCollectionRefHeader",n_RefNo);
	}
	
	public List<Map> getCollectionRefLedger(int n_RefNo){
		return (List<Map>) getSqlMapClientTemplate().queryForObject("getCollectionRefLedger",n_RefNo);
	}
	
	public List<Map> getCreditNotes(int n_RefNo){
		 return getSqlMapClientTemplate().queryForList("getCreditNotes", n_RefNo);
	}
	
	public List<Map> getReceipsDtl(int n_RefNo){
		return getSqlMapClientTemplate().queryForList("getReceipsDtl", n_RefNo);
	}

	public Boolean editEntry(Map map){
		return getSqlMapClientTemplate().update("editEntry",map)>0;
	}
	
	public Boolean deleteEntry(Map map){
		return getSqlMapClientTemplate().delete("deleteEntry",map)>0;
	}

	public Boolean addManualheader(Map headerMap){
		return getSqlMapClientTemplate().update("addManualheader",headerMap)>0;
	}
	
	public Boolean updateHeader(Map headerMap){
		return getSqlMapClientTemplate().update("updateHeader",headerMap)>0;
	}
	
	public Boolean deleteHeader(Map headerMap){
		try{
			getSqlMapClientTemplate().delete("deleteHeader",headerMap);
			return true;
		}catch(Exception e){
			return false;
		}
		
	}
	
	//ADDED BY CVG AS OF 05/31/16
	public Boolean updateLedgerForCN(Map map){
		if ((Integer)getSqlMapClientTemplate().queryForObject("countSubledgerGLCode", map)>0){
			return getSqlMapClientTemplate().update("updateLedgerForCN", map)>0;
		}else{
			return getSqlMapClientTemplate().update("addLedger", map)>0;
		}
		
		//return getSqlMapClientTemplate().update("updateLedgerForCN", map)>0;
	}
	
	
}
