package com.bdo.factor.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.Group;


public class GroupDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(GroupDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchGroup(Map groupMap){
		
		log.debug("-->> getGroup DAO CORRECT ....");		
		return getSqlMapClientTemplate().queryForList("searchGroup", groupMap);
	}


//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchGroupByGCode(String c_BranchCode, String c_GroupCode){
		
		log.debug("-->> getGroupCode DAO CORRECT SEARCHGROUPBYGCODE....");
		
		Map m = new HashMap();
		m.put("C_BRANCHCODE", c_BranchCode);
		m.put("C_GROUPCODE", c_GroupCode);
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchGroupByGCode",m);
		log.debug("l: " + l.size());
		return l;
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addGroup(Map group){
		try {
			getSqlMapClientTemplate().insert("addGroup",group);
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateGroup(Map group){
		return getSqlMapClientTemplate().update("updateGroup",group)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteGroup(Map group){
		return getSqlMapClientTemplate().delete("deleteGroup",group)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsGroup(String c_BranchCode){
		
		log.debug("-->> getTotalRecordsGroup DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsGroup", c_BranchCode);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public List searchGroupServiceAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchGroupServiceAutoComplete",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchGroupResolveToCode(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchGroupResolveToCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////		
	
	public String searchGroupResolveToDesc(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchGroupResolveToDesc",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
		
}
