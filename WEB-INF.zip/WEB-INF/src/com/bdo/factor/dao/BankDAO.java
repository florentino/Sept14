package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class BankDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(BankDAO.class);

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchBank(Map map){
		
		logger.debug("-->> searchBank DAO ....");
		return getSqlMapClientTemplate().queryForList("searchBank",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public List searchBankByCode(String c_BankCode){
		
		logger.debug("-->> getBankCode DAO CORRECT SEARCHBANKBYCODE....");
		
		Map m = new HashMap();
		m.put("C_BANKCODE", c_BankCode);		
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchBankByBCode",m);
		logger.debug("l: " + l.size());
		return l;
	}
	
	public List searchBankList(){
		
		logger.debug("-->> getCheckType DAO CORRECT ....");	
		
		return getSqlMapClientTemplate().queryForList("searchBankList");
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addBank(Map map){
		return getSqlMapClientTemplate().update("addBank",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateBank(Map map){
		return getSqlMapClientTemplate().update("updateBank",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteBank(Map map){
		return getSqlMapClientTemplate().delete("deleteBank",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsBank(){
		
		logger.debug("-->> getTotalRecordsBank DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsBank");
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchBankAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchBankAutoComplete",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchBankResolveToCode(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchBankResolveToCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public String searchBankResolveToDesc(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchBankResolveToDesc",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	public List<Map> getBank(){
		return getSqlMapClientTemplate().queryForList("getBank");
	}
	

};