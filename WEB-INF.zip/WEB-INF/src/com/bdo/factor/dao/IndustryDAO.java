package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class IndustryDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(IndustryDAO.class);

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchIND(Map map){
		
		log.info("-->> searchIND DAO ....");
		return getSqlMapClientTemplate().queryForList("searchIND",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchINDByCode(String c_INDCode){
		
		log.info("-->> getINDUSTRY DAO CORRECT ....");
		Map m = new HashMap();
		m.put("C_INDCODE", c_INDCode);		
		
		return getSqlMapClientTemplate().queryForList("searchINDByCode",m);
	}
	
////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addIND(Map map){
		return getSqlMapClientTemplate().update("addIND",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateIND(Map map){
		return getSqlMapClientTemplate().update("updateIND",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteIND(Map map){
		return getSqlMapClientTemplate().delete("deleteIND",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsIND(){
		
		log.info("-->> getTotalRecordsIND DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsIND");
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public List searchIndustryAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchIndustryAutoComplete",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchIndustryResolveToCode(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchIndustryResolveToCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchIndustryResolveToDesc(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchIndustryResolveToDesc",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
public List searchIndustryList(Map map){
		
		log.debug("-->> searchIndustryList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchIndustryList",map);
	}
public List searchIndustryList2(){
	
	log.debug("-->> searchIndustryList2 DAO ....");
	return getSqlMapClientTemplate().queryForList("searchIndustryList2");
}

public String searchIndustryResolveToCode2(Map map){
	
	return (String)getSqlMapClientTemplate().queryForObject("searchIndustryResolveToCode2",map);
}

public String searchIndustryResolveToDesc2(Map map){
	
	return (String)getSqlMapClientTemplate().queryForObject("searchIndustryResolveToDesc2",map);
}

	
};