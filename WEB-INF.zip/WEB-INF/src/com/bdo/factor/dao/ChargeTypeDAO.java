package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.ChargeTypeBean;


public class ChargeTypeDAO extends SqlMapClientDaoSupport{

	public List<ChargeTypeBean> getAllChargeType(){
		return getSqlMapClientTemplate().queryForList("getAllChargeType", ChargeTypeBean.class);
	}
	
	public void addChargeType(){
		 
	}
	public void updateChargeType(){
		 
	}
	public List<HashMap> getChargeTypeSelection(){
		return getSqlMapClientTemplate().queryForList("getChargeTypeSelection");
	}
}
