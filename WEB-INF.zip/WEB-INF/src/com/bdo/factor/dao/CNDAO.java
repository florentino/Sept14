package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class CNDAO extends SqlMapClientDaoSupport{

	private static Logger log = Logger.getLogger(CNDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCN(Map map){
		
		log.debug("-->> searchCN DAO ....");
		return getSqlMapClientTemplate().queryForList("searchCN",map);
	}
	
	public List searchCNTypeByCode(String c_CNTypeCode){
		
		log.debug("-->> getCheckType DAO CORRECT ....");
		Map m = new HashMap();
		m.put("C_CNTYPECODE", c_CNTypeCode);	
		
		return getSqlMapClientTemplate().queryForList("searchCNTypeByCode",m);
	}
	
	public String searchCNTypeDescByCode(String c_CNTypeCode){
		
		log.debug("-->> getCheckType DAO CORRECT ....");			
		
		return (String) getSqlMapClientTemplate().queryForObject("searchCNTypeDescByCode",c_CNTypeCode);
	}
	
	public List searchCNTypeList(){
		
		log.debug("-->> getCheckType DAO CORRECT ....");	
		
		return getSqlMapClientTemplate().queryForList("searchCNTypeList");
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addCN(Map map){
		return getSqlMapClientTemplate().update("addCN",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateCN(Map map){
		return getSqlMapClientTemplate().update("updateCN",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteCN(Map map){
		return getSqlMapClientTemplate().delete("deleteCN",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsCN(){
		
		log.debug("-->> getTotalRecordsCN DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsCN");
	}

//////////////////////////////////////////////////////////////////////////////////////////////

};