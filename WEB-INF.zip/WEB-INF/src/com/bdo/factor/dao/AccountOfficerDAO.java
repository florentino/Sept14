package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.AccountOfficer;

public class AccountOfficerDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(AccountOfficerDAO.class);

//////////////////////////////////////////////////////////////////////////////////////////////	

	public List searchAccountOfficer(Map map){
		
		log.debug("-->> getAccountOfficer DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchAccountOfficer", map);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	@SuppressWarnings("unchecked")
	public List searchAccountOfficerByAOCode(String c_AccountOfficerCode){
		
		log.debug("-->> getAOCode DAO CORRECT SEARCHGROUPBYGCODE....");
		
		Map m = new HashMap();		
		m.put("C_ACCTOFFICERCODE", c_AccountOfficerCode);
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchAccountOfficerByAOCode",m);
		log.debug("l: " + l.size());
		return l;
	}
	
	public List searchAccountOfficerByCode(Map map){
		
		log.debug("-->> getAOCode DAO CORRECT SEARCHGROUPBYGCODE....");
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchAccountOfficerByCode",map);
		log.debug("l: " + l.size());
		return l;
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addAccountOfficer(Map map){
		return getSqlMapClientTemplate().update("addAccountOfficer",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateAccountOfficer(Map map){
		return getSqlMapClientTemplate().update("updateAccountOfficer",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteAccountOfficer(Map map){
		return getSqlMapClientTemplate().delete("deleteAccountOfficer",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsAccountOfficer(String c_BranchCode){
		
		log.debug("-->> getTotalRecordsAccountOfficer DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsAccountOfficer", c_BranchCode);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchAccountOfficerAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchAccountOfficerAutoComplete",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchAccountOfficerResolveToCode(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchAccountOfficerResolveToCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchAccountOfficerResolveToBranchCode(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchAccountOfficerResolveToBranchCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchAccountOfficerResolveToDesc(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchAccountOfficerResolveToDesc",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public AccountOfficer getAccountOfficerByCode(String C_ACCTOFFICERCODE){
		return (AccountOfficer)getSqlMapClientTemplate().queryForObject("getAccountOfficerByCode",C_ACCTOFFICERCODE);
	}
	
	
};