package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.util.DateHelper;

public class ReportsDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(ReportsDAO.class);

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchReports(Map map){
		
		log.info("-->> searchReports DAO ....");
		return getSqlMapClientTemplate().queryForList("searchReports",map);
	}
	
	public String getTotalReports(String c_BranchCode){
		
		log.debug("-->> getTotalReports DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalReports",c_BranchCode);
	}


}
