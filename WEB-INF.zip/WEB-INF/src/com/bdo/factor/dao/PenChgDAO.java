package com.bdo.factor.dao;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class PenChgDAO extends SqlMapClientDaoSupport {

	public String countPenaltyCharge(Map m){
		return (String) getSqlMapClientTemplate().queryForObject("countPenaltyCharge",m);
	}
	
	public List getPenaltyCharge(Map m){	
		return getSqlMapClientTemplate().queryForList("getPenaltyCharge",m);
	}
	
	public Boolean addPenalty(Map m){
		return getSqlMapClientTemplate().update("addPenalty", m)>0;
	}
}
