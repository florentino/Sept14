package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.AdjustmentType;


public class AdjustmentTypeDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(INVOICEDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchAdjustmentType(Map map){
		
		log.debug("-->> getAdjustmentType DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchAdjustmentType", map);
	}


//////////////////////////////////////////////////////////////////////////////////////////////	
	public List searchAdjustment(Map map){
		
		log.debug("-->> [bin10] getAdjustment DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchAdjustment", map);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	public List searchAdjustmentCode(Map map){
		
		log.debug("-->> [bin10] getAdjustment DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchAdjustmentCode", map);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchAdjustmentTypeByCode(String c_AdjustmentTypeCode){
		
		log.debug("-->> getAdjustmentType DAO CORRECT ....");
		Map m = new HashMap();
		m.put("C_ADJCODE", c_AdjustmentTypeCode);	
		
		return getSqlMapClientTemplate().queryForList("searchAdjustmentTypeByCode",m);
	}
	
	public List searchAdjustmentTypeList(Map m){
		
		log.debug("-->> getAdjustmentType DAO CORRECT ....");	
		
		return getSqlMapClientTemplate().queryForList("searchAdjustmentTypeList", m);
	}
	
	public String searchAtypeCodeByName(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchAtypeCodeByName",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addAdjustmentType(Map adjustmentType){
		return getSqlMapClientTemplate().update("addAdjustmentType",adjustmentType)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public boolean addAdjustment(Map adjustment){
		return getSqlMapClientTemplate().update("addAdjustment",adjustment)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateAdjustmentType(Map adjustmentType){
		return getSqlMapClientTemplate().update("updateAdjustmentType",adjustmentType)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public boolean updateAdjustment(Map adjustment){
		return getSqlMapClientTemplate().update("updateAdjustment",adjustment)>0;
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////
	public boolean updateAdjustmentStatus(Map adjustmentStatus){
		return getSqlMapClientTemplate().update("updateAdjustmentStatus",adjustmentStatus)>0;
	}

///////////////////////////////////////////////////////////////////////////////////////////////
	public boolean updateAdjustmentToCancel(Map adjustmentToCancel){
		return getSqlMapClientTemplate().update("updateAdjustmentToCancel",adjustmentToCancel)>0;
	}

	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteAdjustmentType(Map adjustmentType){
		return getSqlMapClientTemplate().delete("deleteAdjustmentType",adjustmentType)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsAdjustmentType(){
		
		log.debug("-->> getTotalRecordsAdjustmentType DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsAdjustmentType");
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
public String getTotalRecordsAdjustment(){
		
		log.debug("-->>[bin10] getTotalRecordsAdjustment DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsAdjustment");
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
public List searchAdjustmentTypeAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchAdjustmentTypeAutoComplete",map);
	}
	
///////////////////////////////////////////////////////////////////////////////////////////////	
public List searchInvoiceAuto(Map map){
		
	return getSqlMapClientTemplate().queryForList("searchInvoiceAutoComplete",map);
}
public List invoiceValidation(Map map){	
	return getSqlMapClientTemplate().queryForList("invoiceValidation",map);
}


public List<Map> getAdjustmentList(Map m){
	return getSqlMapClientTemplate().queryForList("getAdjustmentList",m);
	
}

/////////////////////////

//CVG 05092017
public boolean updateAdjustmentIRefnoAdvances(String N_REFNO, String C_CLNTCODE, String D_TRANSACTIONDATE){
	Map<String,String> adjustDetail = new HashMap<String,String>();
	adjustDetail.put("N_REFNO", N_REFNO);
	adjustDetail.put("C_CLNTCODE", C_CLNTCODE);
	adjustDetail.put("D_TRANSACTIONDATE", D_TRANSACTIONDATE);
	return getSqlMapClientTemplate().update("updateAdjustmentIRefnoAdvances",adjustDetail)>0;
}

public boolean updateAdjustmentIRefnoRefund(Map adjustDetail){
	return getSqlMapClientTemplate().update("updateAdjustmentIRefnoRefund",adjustDetail)>0;
}

public boolean cancelAdjustmentIRefno(Map adjustDetail){
	return getSqlMapClientTemplate().update("cancelAdjustmentIRefno",adjustDetail)>0;
}
//end

public Integer tester(String C_CLNTCODE){
	
	return (Integer)getSqlMapClientTemplate().queryForObject("tester", C_CLNTCODE);
}

}
