package com.bdo.factor.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.service.GroupService;

public class ServiceOfficerDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(ServiceOfficerDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public List searchServiceOfficer(Map serviceMap){
		
		log.info("-->> getServiceOfficer DAO CORRECT ....");		
		return getSqlMapClientTemplate().queryForList("searchServiceOfficer", serviceMap);
	}


//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchServiceOfficerByCode(String c_ServiceOfficerCode){
		
		log.info("-->> getServiceCode DAO CORRECT");
		
		Map m = new HashMap();
		m.put("C_SERVICEOFFICERCODE", c_ServiceOfficerCode);		
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchServiceOfficerByCode",m);
		log.info("l: " + l.size());
		return l;
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addServiceOfficer(Map sOfficer){
		try {
			getSqlMapClientTemplate().insert("addServiceOfficer",sOfficer);
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateServiceOfficer(Map sOfficer){
		return getSqlMapClientTemplate().update("updateServiceOfficer",sOfficer)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteServiceOfficer(Map sOfficer){
		return getSqlMapClientTemplate().delete("deleteServiceOfficer",sOfficer)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsServiceOfficer(String c_BranchCode){
		
		log.info("-->> getTotalRecordsServiceOfficer DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsServiceOfficer", c_BranchCode);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchServiceOfficerServiceAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchServiceOfficerServiceAutoComplete",map);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchServiceOfficerServiceResolveToCode(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchServiceOfficerServiceResolveToCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////		

	public String searchServiceOfficerServiceResolveToDesc(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchServiceOfficerServiceResolveToDesc",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	
}
