package com.bdo.factor.dao;
 
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.User;
import com.bdo.factor.util.ServiceUtility;

public class MiscCodeDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(MiscCodeDAO.class);
	
	@SuppressWarnings("unchecked")
	public List getClientClassificationToDescription(Map role)
	{				
		ServiceUtility.viewUserParameters(role);
		log.debug("--->Passing through getClientClassificationToDescription (MiscCode.java) Correct--->....");
		return getSqlMapClientTemplate().queryForList("getClientClassificationToDescription", role);		
	}
	 
	public String getClientClassificationToCode(Map role)
	{				
		ServiceUtility.viewUserParameters(role);
		log.debug("--->Passing through getClientClassificationToCode (MiscCode.java) Correct--->....");
		return (String) getSqlMapClientTemplate().queryForObject("getClientClassificationToCode", role) ;
		 
	}
	
	
	//@@ 
	@SuppressWarnings("unchecked")
	public List getBusinessClassification(Map role)
	{				
		ServiceUtility.viewUserParameters(role);
		log.debug("--->Passing through getBusinessClassification (MiscCode.java) Correct--->....");
		return getSqlMapClientTemplate().queryForList("businessClassification", role);		
	}
	
	@SuppressWarnings("unchecked")
	public List getBusinessIndustry(Map role)
	{				
		ServiceUtility.viewUserParameters(role);
		log.debug("--->Passing through getBusinessIndustry (MiscCode.java) Correct--->....");
		return getSqlMapClientTemplate().queryForList("businessIndustry", role);		
	}
}
