package com.bdo.factor.dao;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.Customer;

public class CustomerDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(CustomerDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCustomer(Map map){
		
		log.debug("-->> getCustomer DAO CORRECT XXX....");
		return getSqlMapClientTemplate().queryForList("searchCustomer",map);
	}


//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCustomerByCode(Map map){
			
			log.debug("-->> searchCustomerByCode DAO ....");
			return getSqlMapClientTemplate().queryForList("searchCustomerByCode",map);
	}
	
	public String searchCustomerCodeByName(Map map){
		
		log.debug("-->> searchCustomerByCode DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("searchCustomerCodeByName",map);
}


//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchCustomerServiceList(Map map){
		
		log.debug("-->> searchCustomerServiceList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchCustomerServiceList",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchAllCustomerService(Map map){
		
		log.debug("-->> searchAllCustomerService DAO ....");
		return getSqlMapClientTemplate().queryForList("searchAllCustomerService",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCustomerServiceAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchCustomerServiceAutoComplete",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public List searchCustomerNameByClient(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchCustomerNameByClient",map);
	}
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public int addCustomer(Map map){
		
		log.debug("-->> addCustomer DAO CORRECT ....");
		
		if(map.containsKey("N_CULIMIT") && (map.get("N_CULIMIT")==null || map.get("N_CULIMIT").toString().trim().length()==0)){
			map.put("N_CULIMIT","0");
		}
		
		return (Integer)getSqlMapClientTemplate().insert("addCustomer",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateCustomer(Map map){
		
		if(map.containsKey("N_CULIMIT") && (map.get("N_CULIMIT")==null || map.get("N_CULIMIT").toString().trim().length()==0)){
			map.put("N_CULIMIT","0");
		}
		
		if(map.containsKey("C_STATUS") && map.get("C_STATUS")!=null && map.get("C_STATUS").toString().trim().startsWith("on")){
			map.put("C_STATUS","1");
		}
		
		return getSqlMapClientTemplate().update("updateCustomer",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteCustomer(Map customer){
		return getSqlMapClientTemplate().delete("deleteCustomer",customer)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public String getTotalRecordsCustomer(Map customer){		
		log.debug("-->> getTotalRecordsCustomer DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsCustomer",customer);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List checkCustomerExists(Map map){
		
		return getSqlMapClientTemplate().queryForList("checkCustomerExists",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public String searchCustomerCodeByClientName(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchCustomerNameByClientCode",map);
	}
	
	public String searchCustomerNameByCustomerCode(String c_CustCode){
		String result = (String) getSqlMapClientTemplate().queryForObject("searchCustomerNameByCustomerCode",c_CustCode);
		System.out.println("result: " + result);
		return result;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List getCompleteCustNameByName(Map map){	
		log.debug("-->> getCompleteCustNameByName DAO ....");
		return getSqlMapClientTemplate().queryForList("getCompleteCustNameByName",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	

	public List getCustomerCodeByBranchAndName(Map map){
		
		log.debug("-->> getCustomerCodeByBranchAndName DAO ....");
		return getSqlMapClientTemplate().queryForList("getCustomerCodeByBranchAndName",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchPaymentSchedule(){
		return getSqlMapClientTemplate().queryForList("searchPaymentSchedule");
		
	}
	
	public List searchCustomerPaymentSchedule(Map clientForm){
		return getSqlMapClientTemplate().queryForList("searchCustomerPaymentSchedule",clientForm);
		
	}
////////////////////////////////////////////////////////////////////////////////////////////////	
	public List searchCustomerWithDelinquent(Map clientForm){
		return getSqlMapClientTemplate().queryForList("searchCustomerWithDelinquent",clientForm);
	}

}
