package com.bdo.factor.dao;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class AmsDAO extends SqlMapClientDaoSupport {
	private static Logger log = Logger.getLogger(AmsDAO.class);
	
	public boolean addAMS(Map AMSForm){
		return getSqlMapClientTemplate().update("addAMS",AMSForm) > 0;
	}

}
