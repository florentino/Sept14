package com.bdo.factor.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.ReportField;
import com.bdo.factor.dataSource.InvoiceDAO;
import com.bdo.factor.service.AccountingMaintenanceService;
import com.bdo.factor.service.AuditService;
import com.bdo.factor.service.ReceiptsHeaderService;
import com.bdo.factor.service.SubHeaderService;

public class RefundDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(RefundDAO.class);
	private JdbcTemplate jdbcTemplate;
	
	public RefundDAO(){		
	}
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public List searchRefund(Map map){
		log.info("-->> searchRefund DAO ....");
		return getSqlMapClientTemplate().queryForList("searchRefund",map);
	}
	
	public List searchReceipts(Map map){
		log.info("-->> searchReceipts DAO ....");
		return getSqlMapClientTemplate().queryForList("searchReceipts",map);
	}
	
	public List getRefund(Map map){
		log.info("-->> getRefund DAO ....");
		return getSqlMapClientTemplate().queryForList("getRefund",map);
	}
	
	public int addRefund(Map map){
		log.info("addRefund DAO>>>");
		int n_refno = 0;
		if( getSqlMapClientTemplate().update("addRefund",map)>0){
			String sSQL="SELECT IDENT_CURRENT('Refund')";
			n_refno = getJdbcTemplate().queryForInt(sSQL);
		}
		return n_refno;
	}
	
	public boolean editRefund(Map map){
		log.info("editRefund DAO>>>");
		return getSqlMapClientTemplate().update("editRefund",map)>0;
	}
		
	public boolean updateRefundStatus(Map map){
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO"); //CVG 05092017
		SimpleDateFormat SDF = new SimpleDateFormat ("yyyy/MM/dd");
		map.put("D_TRANSACTIONDATE",SDF.format(date.newDate())); //before:new Date()
		boolean update =false;
		
		if(map.containsKey("mode") && map.get("mode")!=null) {
			InvoiceDAO inv = (InvoiceDAO)Persistence.getDAO("invoiceDao");
			AuditService as = AuditService.getInstance();
			
			if(map.get("C_STATUS").toString().contentEquals("2")){
				update = true;
			}
			else
			 update=getSqlMapClientTemplate().update("updateRefundStatus",map)>0?true:false;
			 
			log.info("UPDATE>>>>>"+update);
			
			
			
			
			if (update){
				String N_REFAMT = (String) map.get("N_REFAMT");
				String C_CLNTCODE = (String) map.get("C_CLNTCODE");
				String C_STATUS = (String) map.get("C_STATUS");
				String C_RCPTREFNO = (String) map.get("C_RCPTREFNO");
				String C_BRANCHCODE = (String) map.get("C_BRANCHCODE");
				String N_INELIGIBLEREF = (String) map.get("N_INELIGIBLEREF");
				String sSQL;
				String N_REFNO = map.get("N_REFNO").toString();
				String mode = map.get("mode").toString();
				log.info("C_STATUS>>>>>"+C_STATUS);
				if (C_STATUS.equals("2")){
					//update = getSqlMapClientTemplate().update("addDiscDtlRef",map)>0?true:false;
					//sSQL = "insert into discdtl (n_reference,c_type,n_advancerefno,n_discchg,d_transactiondate)	select n_invno,'R',"+N_REFNO+",N_DISCCHG,D_TRANSACTIONDATE	from InvoiceAmt where c_clntcode="+C_CLNTCODE;
					//sSQL = "exec dbo.sp_discdtl 'R',"+N_REFNO+","+C_CLNTCODE;
					//log.info(sSQL);
					//getJdbcTemplate().execute(sSQL);
					//update = getJdbcTemplate().update(sSQL)>0?true:false;
					//log.info(">>"+update);
					ReceiptsHeaderService RS = ReceiptsHeaderService.getInstance();
					
					
					List<String> invoices = getSqlMapClientTemplate().queryForList("getInvoices",map);
					Map refMap = (Map) getSqlMapClientTemplate().queryForObject("getRefundInfo",map);
					List<String> CNMap = getSqlMapClientTemplate().queryForList("getRefundCN",map);
					List<String[]> CNList = new ArrayList();
				 
					
					for (int loop=0;loop<CNMap.size();loop++){
						String[] cn = CNMap.get(loop).toString().split(",");
						CNList.add(cn);
					}
					
					Double ClEq = (Double) getSqlMapClientTemplate().queryForObject("getClientsEquity",map);
					Double ClEqCharges = (Double) getSqlMapClientTemplate().queryForObject("getClientsEquityCharges",map);
					ClEqCharges = ClEqCharges+ (refMap.get("N_USCHG")!=null?Double.parseDouble(refMap.get("N_USCHG").toString()):0.00);
					//Double opa = (Double) getSqlMapClientTemplate().queryForObject("getCEOverpayment",map);
					log.info(CNList.isEmpty());
					//Double computedAmt = Double.parseDouble(refMap.get("N_COMPUTEDAMT").toString())-ClEqCharges;
					map.put("N_Amount",refMap.get("N_COMPUTEDAMT"));
					//map.put("N_Amount",computedAmt);
					
					map.put("ClEq", ClEq);
					map.put("ClEqCharges", ClEqCharges);
					//map.put("ClEq", ClEq+opa);
					map.put("interest", refMap.get("Interest"));
					//CN
					map.put("CNList", CNList);
					map.put("penalty", refMap.get("Penalty")==null?0:refMap.get("Penalty"));
					map.put("pd_interest", refMap.get("PD_INTEREST")==null?0:refMap.get("PD_INTEREST")); 
					//map.put("n_amount", refMap.get("N_COMPUTEDAMT"));
					map.put("C_Type", "D");
					map.put("C_TransactionType", "R");
					map.put("N_DCREVERSAL", refMap.get("N_DCREVERSAL"));
					map.put("C_USERID", map.get("C_USERID"));
					AccountingMaintenanceService AMS = AccountingMaintenanceService.getInstance();
					AMS.saveTransactionRate((Map) getSqlMapClientTemplate().queryForObject("transactionRateRef",map));
					
					SimpleDateFormat UDF = new SimpleDateFormat ("MM/dd/yyyy");
					
					SubHeaderService SHS = SubHeaderService.getInstance();
					Long success =	SHS.createSubHeader(map, CNList.size()==0?"REFUND":"REFUND with Credit Note", UDF.format(date.newDate()), "REFUND"); //before:new Date()
					
					SHS.createLedgerEntry2(map, "Refund", success);
					Boolean successAdjustment = SubHeaderService.getInstance().createAdjustmentEntry(map, success);
					if(!successAdjustment){
						log.info("adjusment entry not added");
					}else{
						log.info(successAdjustment);
					}
					
					
					update=getSqlMapClientTemplate().update("updateRefundStatus",map)>0;
					
					sSQL = "UPDATE dbCIF.dbo.Client SET N_FIUTRAN=N_FIUTRAN+"+N_REFAMT+",N_RESERVES=N_RESERVES-"+N_REFAMT+",N_INELIGIBLEREF=N_INELIGIBLEREF+"+N_INELIGIBLEREF+" WHERE C_CLNTCODE="+C_CLNTCODE;
					log.info(sSQL);
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					log.info(">>"+update);
					if (update){
						sSQL="N_FIUTRAN="+inv.getField("N_FIUTRAN","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
						";N_RESERVES="+inv.getField("N_RESERVES","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
						";N_INELIGIBLEREF="+inv.getField("N_INELIGIBLEREF","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
						";C_CLNTCODE="+C_CLNTCODE;
						as.addAudit(map.get("C_USERID").toString(),"U","Client",sSQL);
						
						sSQL = "update advances set N_REFUNDREFNO="+N_REFNO+",B_RELEASED=1 where C_TYPE='1' and C_STATUS='2' and B_RELEASED=0 and C_CLNTCODE="+C_CLNTCODE;
						log.info(sSQL);
						update = getJdbcTemplate().update(sSQL)>0?true:false;
						//sSQL = "UPDATE ReceiptsHdr SET C_STATUS='4',N_REFUNDREFNO="+N_REFNO+" WHERE N_REFUNDREFNO IS NULL AND C_STATUS='2'";
						
						sSQL = "UPDATE ReceiptsHdr SET C_STATUS='4',N_REFUNDREFNO="+N_REFNO+" WHERE N_REFUNDREFNO IS NULL AND C_STATUS='2' and c_receipttype<>'3' and C_CLNTCODE="+C_CLNTCODE;
						log.info(sSQL);
						update = getJdbcTemplate().update(sSQL)>0?true:false;
						
						try{
							map.put("N_REFPAYMENTNO", N_REFNO);
							map.put("transType", "N_REFPAYMENTNO");
							map.put("C_RECEIPTTYPE", 4);
							map.put("Particular","COLLECTION FROM REFUND "+N_REFNO);
							RS.createReceiptPayment(new HashMap(map));
						}catch(Exception e){
							e.printStackTrace();
						}
						
						sSQL = "UPDATE Invoice SET C_STATUS='6' WHERE C_STATUS='5' AND N_INVNO IN (SELECT N_INVNO FROM ReceiptsDtl WHERE N_REFNO IN (select N_REFNO from ReceiptsHdr where N_REFUNDREFNO="+N_REFNO+"))";
						log.info(sSQL);
						
						try{
							getJdbcTemplate().update(sSQL) ;
							update = true; 
						}catch(Exception e){
							update = false;
						}
						
						boolean updateRefNo  = AdjustmentTypeDAO.updateAdjustmentIRefnoRefund(map); //CVG 05092017
						if (!updateRefNo){
							log.info("REFNO did not update");
						}
						
//						sSQL = "INSERT INTO AMS (D_TRANSACTIONDATE, C_CLIENTCODE, N_AMOUNT, C_TYPE, C_BRANCHCODE, N_REFNO) values (convert(nvarchar,getdate(),101),"+
//						C_CLNTCODE+","+N_REFAMT+",'R','"+C_BRANCHCODE+"',"+N_REFNO+")";
//						log.info(sSQL);
//						update = getJdbcTemplate().update(sSQL)>0?true:false;
//						log.info("update...."+update);
//						
						return update;
					} else {
						return false;
					}
				} else if (C_STATUS.equals("3") && mode.equals("2")){//APPROVED TO CANCEL
					try{
						ReceiptsHeaderService RHS = ReceiptsHeaderService.getInstance();
						RHS.cancelFromTransaction(N_REFNO,"N_REFPAYMENTNO");
					}catch(Exception e){
						e.printStackTrace();
					}
					
					sSQL = "UPDATE refund set d_cancelleddate=(select [currentdate] FROM [factorsGetDate]) where n_refno="+N_REFNO; //before: getDate()
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					log.info(sSQL+">>"+update);
					
					sSQL = "UPDATE dbCIF.dbo.Client SET N_FIUTRAN=N_FIUTRAN-"+N_REFAMT+",N_RESERVES=N_RESERVES+"+N_REFAMT+",N_INELIGIBLEREF=N_INELIGIBLEREF-"+N_INELIGIBLEREF+" WHERE C_CLNTCODE="+C_CLNTCODE;
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					log.info(sSQL+">>"+update);
					
					sSQL = "update advances set N_REFUNDREFNO=0,B_RELEASED=0 where N_REFUNDREFNO="+N_REFNO;
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					log.info(sSQL+">>"+update);
					//if (update){
					sSQL="N_FIUTRAN="+inv.getField("N_FIUTRAN","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
					";N_RESERVES="+inv.getField("N_RESERVES","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
					";N_INELIGIBLEREF="+inv.getField("N_INELIGIBLEREF","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+
					";C_CLNTCODE="+C_CLNTCODE;
					as.addAudit(map.get("C_USERID").toString(),"U","Client",sSQL);
					
					//sSQL = "delete from discdtl where C_TYPE='R' and n_reference in (SELECT N_INVNO FROM ReceiptsDtl WHERE N_REFNO IN (select n_refno from ReceiptsHdr where N_REFUNDREFNO="+N_REFNO+"))";
					sSQL = "delete from discdtl where C_TYPE='R' and N_ADVANCEREFNO="+N_REFNO;
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					log.info(sSQL+">>"+update);
						
					sSQL = "UPDATE Invoice SET C_STATUS='5' WHERE D_FULLYPAIDDATE IS NOT NULL AND N_INVNO IN (SELECT N_INVNO FROM ReceiptsDtl WHERE N_REFNO IN (select n_refno from ReceiptsHdr where N_REFUNDREFNO="+N_REFNO+"))";
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					log.info(sSQL+">>"+update);
					
					sSQL = "UPDATE Invoice SET C_STATUS='4' WHERE D_FULLYPAIDDATE IS NULL AND N_INVNO IN (SELECT N_INVNO FROM ReceiptsDtl WHERE N_REFNO IN (select n_refno from ReceiptsHdr where N_REFUNDREFNO="+N_REFNO+"))";
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					log.info(sSQL+">>"+update);
						
					sSQL = "UPDATE ReceiptsHdr SET C_STATUS='2',N_REFUNDREFNO=null WHERE C_STATUS <> '3' AND N_REFUNDREFNO="+N_REFNO;
					update = getJdbcTemplate().update(sSQL)>0?true:false;
					log.info(sSQL+">>"+update);
						
//					sSQL = "DELETE FROM AMS WHERE C_TYPE='R' AND N_REFNO="+N_REFNO;
//					update = getJdbcTemplate().update(sSQL)>0?true:false;
//					log.info(sSQL+">>"+update);
					boolean cancelRefNo = AdjustmentTypeDAO.cancelAdjustmentIRefno(map); //CVG 05092017
					if (!cancelRefNo){
						log.info("REF_NO not deleted");
					}
					
					map.put("C_TRANSACTIONTYPE", "R");
					update = SubHeaderService.getInstance().cancelSubHeaderEntry(map);
	
					return update;
	//				} else {
	//					return false;
	//				}
				} else if (C_STATUS.equals("3") && mode.equals("1")){//UPDATE FROM PENDING TO CANCELLED
					try{
						ReceiptsHeaderService RHS = ReceiptsHeaderService.getInstance();
						RHS.cancelFromTransaction(N_REFNO,"N_REFPAYMENTNO");
					}catch(Exception e){
						e.printStackTrace();
					}
					return true;
				}
			}
		} else {
			 update=getSqlMapClientTemplate().update("updateRefundStatus",map)>0?true:false;
			 return update;
		}
		return false;
	}
	
	public String getTotalRecordsRefund(Map map){
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsRefund",map);
	}
	
	public String getTotalRecordsReceipts(Map map){
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsReceipts",map);
	}
	
	public double searchRefundAmountByRefNo(int n_RefNo) {
		Map map = new HashMap();
		map.put("N_REFNO", n_RefNo);
		log.info("n_refNo:" + map.get("N_REFNO"));
		String strAmount = (String)getSqlMapClientTemplate().queryForObject("searchRefundAmountByRefNo",map);
		return Double.parseDouble(strAmount);
	}
	
	public boolean updateRefundStat(Map map){
		log.info("updateRefund DAO>>>");
		return getSqlMapClientTemplate().update("updateRefundStatus",map)>0;
	}
	
	public List<ReportField> getRefundToClientReport(Map map){
		return getSqlMapClientTemplate().queryForList("getRefundToClientReport", map);
	}
	//rr 04172012
	public Integer insertDiscountDetailRefund(Map map){
		System.out.println("-->> insertDiscountDetailRefund"); 
	    return (Integer) getSqlMapClientTemplate().update("insertDiscountDetailRefund", map);	
	}
	
	public Integer insertPenaltyDetailRefund(Map map){
		System.out.println("-->> insertPenaltyDetailRefund"); 
	    return (Integer) getSqlMapClientTemplate().update("insertPenaltyDetailRefund", map);	
	}
	//--
}
