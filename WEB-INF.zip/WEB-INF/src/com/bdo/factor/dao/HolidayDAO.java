package com.bdo.factor.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.Holiday;


public class HolidayDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(HolidayDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchHoliday(Map holidayMap){
		
		log.info("-->> getHoliday DAO CORRECT ....");		
		return getSqlMapClientTemplate().queryForList("searchHoliday", holidayMap);
	}


//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchHolidayByGCode(String c_BranchCode, String d_HolidayDate){
		
		log.info("-->> getHolidayCode DAO CORRECT SEARCHGROUPBYGCODE....");
		
		Map m = new HashMap();
		m.put("C_BRANCHCODE", c_BranchCode);
		m.put("D_HOLIDAYDATE", d_HolidayDate);
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchHolidayByDate",m);
		log.debug("l: " + l.size());
		return l;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List getHolidayCountByDate(java.util.Date start, java.util.Date end, String branchCode){		
		log.info("-->> getHolidayCountByDate");
		
		Map m = new HashMap();
		m.put("start", start);
		m.put("end", end);
		m.put("branchCode", branchCode);
		
		ArrayList lCount = (ArrayList) getSqlMapClientTemplate().queryForList("getHolidayCountByDate",m);
		log.debug("l: " + lCount.size());
		
		return lCount;
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addHoliday(Map holiday){
		try {
			getSqlMapClientTemplate().insert("addHoliday",holiday);
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateHoliday(Map holiday){
		return getSqlMapClientTemplate().update("updateHoliday",holiday)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteHoliday(Map holiday){
		return getSqlMapClientTemplate().delete("deleteHoliday",holiday)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsHoliday(String c_BranchCode){
		
		log.debug("-->> getTotalRecordsHoliday DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsHoliday", c_BranchCode);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

}
