package com.bdo.factor.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.ReceiptsHeader;
import com.bdo.factor.beans.DiscountChargeOnCashDelay;
import com.bdo.factor.service.SubHeaderService;

public class ReceiptsHeaderDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(ReceiptsHeaderDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	
	public int addReceiptsHeader(Map receiptsHdr){
		return (Integer) getSqlMapClientTemplate().insert("addReceiptsHeader",receiptsHdr);
	}
	
	public int addReceiptsHeaderStatus2(Map receiptsHdr){
		return (Integer) getSqlMapClientTemplate().insert("addReceiptsHeaderStatus2",receiptsHdr);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateReceiptsHeader(Map map){
		return getSqlMapClientTemplate().update("updateReceiptsHeader",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteReceiptsHeader(Map map){
		return getSqlMapClientTemplate().delete("deleteReceiptsHeader",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public int searchNRefNo(Map receiptsHeaderForm) {
		
		return Integer.parseInt((String)getSqlMapClientTemplate().queryForObject("searchNRefNo",receiptsHeaderForm));
	}
	
	public int searchNRefNoStatus2(Map receiptsHeaderForm) {
		return Integer.parseInt((String)getSqlMapClientTemplate().queryForObject("searchNRefNoStatus2",receiptsHeaderForm));
	}
	
	public int searchCheckNo(Map receiptsHeaderForm) {
		return Integer.parseInt((String)getSqlMapClientTemplate().queryForObject("searchCheckNo",receiptsHeaderForm));
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchScheduleReceiptsHeader(Map map){
		
		log.info("-->> searchScheduleReceiptsHeader DAO ....");
		return getSqlMapClientTemplate().queryForList("searchScheduleReceiptsHeader",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchScheduleReceiptsDetail(Map map){
		
		log.info("-->> searchScheduleReceiptsDetail DAO ....");
		return getSqlMapClientTemplate().queryForList("searchScheduleReceiptsDetail",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchDiscountChargeReceiptsDetail(Map map){
		
		System.out.println("-->> searchDiscountChargeReceiptsDetail DAO ....");
		return getSqlMapClientTemplate().queryForList("searchDiscountChargeReceiptsDetail",map);
	}
	
	public List searchReceiptsHdrByCustomer(Map map){
		
		System.out.println("-->> searchReceiptsHdrByCustomer DAO ....");
		return getSqlMapClientTemplate().queryForList("searchReceiptsHdrByCustomer",map);
	}
	
	public String getTotalReceiptsHdrByBranch(Map map){
		System.out.println("-->> getTotalReceiptsHdrByBranch DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalReceiptsHdrByBranch", map);
	}
	
	public String getTotalReceiptsForRefund(Map map){
		System.out.println("-->> getTotalReceiptsHdrByBranch DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalReceiptsForRefund", map);
	}
	
	public String getTotalReceiptsHdrByCustomer(Map map){
		
		System.out.println("-->> getTotalReceiptsHdrByCustomer DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalReceiptsHdrByCustomer", map);
	}
	
	public boolean updateReceiptsBouncedCheck(Map map){
		return getSqlMapClientTemplate().update("updateReceiptsBouncedCheck",map)>0;
		 
	}

	public String getReceiptsDCReversal(Integer n_RefNo){
		System.out.println("-->> getReceiptsDCReversal"); 
	    return (String) getSqlMapClientTemplate().queryForObject("getReceiptsDCReversal", n_RefNo);		
	}
		
	public List searchReceiptsForClearing(Map map){
		
		System.out.println("-->> searchReceiptsForClearing DAO ....");
		return getSqlMapClientTemplate().queryForList("searchReceiptsForClearing",map);
	}
	
	public boolean updateReceiptsStatusByBatch(String c_Status, String n_RefNo) {
		
		Map map = new HashMap();
		map.put("C_STATUS", c_Status);
		map.put("N_REFNO", n_RefNo);
		return getSqlMapClientTemplate().update("updateReceiptsStatusByBatch", map) > 0;
	}
	
	public boolean updateReceiptsStatusByRefund(String c_Status, String n_RefundRefNo, String n_RefNo) {
		
		Map map = new HashMap();
		map.put("C_STATUS", c_Status);
		map.put("N_REFNO", n_RefNo);
		map.put("N_REFUNDREFNO", n_RefundRefNo);
		return getSqlMapClientTemplate().update("updateReceiptsStatusByRefund", map) > 0;
	}
	//rdc07302010 - cancel CA Refund
	public boolean updateReceiptsStatusByCARefund(String c_Status, String n_RefundRefNo, String n_RefNo) {
		
		Map map = new HashMap();
		map.put("C_STATUS", c_Status);
		map.put("N_REFNO", n_RefNo);
		map.put("N_REFUNDREFNO", n_RefundRefNo);
		return getSqlMapClientTemplate().update("updateReceiptsStatusByCARefund", map) > 0;
	}
	
	public boolean updateBClearedByBatch(String b_Cleared, String n_RefNo) {
		
		Map map = new HashMap();
		map.put("B_CLEARED", b_Cleared);
		map.put("N_REFNO", n_RefNo);
		return getSqlMapClientTemplate().update("updateBClearedByBatch", map) > 0;
	}
	
	public boolean updateReceiptsStatusBCleared(String c_Status, String bCleared, int n_RefNo) {
		
		Map map = new HashMap();
		map.put("C_STATUS", c_Status);
		map.put("B_CLEARED", bCleared);
		map.put("N_REFNO", n_RefNo);
		return getSqlMapClientTemplate().update("updateReceiptsStatusBCleared", map) > 0;
	}

	public boolean updateReceiptsTotalInvAmount(Map map){
		log.info("updateReceiptsTotalInvAmount");
		return getSqlMapClientTemplate().update("updateReceiptsTotalInvAmount",map)>0;
	}
	
	public boolean updateReceiptsAmount(Map map){
		log.info("updateReceiptsTotalInvAmount");
		return getSqlMapClientTemplate().update("updateReceiptsAmount",map)>0;
	}
	
	public List searchReceiptsByBranch(Map map) {
		return getSqlMapClientTemplate().queryForList("searchReceiptsByBranch", map);
	}
	public List searchReceiptsForRefund(Map map) {
		return getSqlMapClientTemplate().queryForList("searchReceiptsForRefund", map);
	}
	public int getReceiptsDueForRefundSize(Map map) {
		return Integer.parseInt((String) getSqlMapClientTemplate().queryForObject("getReceiptsDueForRefundCount", map));
	}
	
	public double searchReceiptsOPByRefNo(int n_RefNo) {
		String s = (String) getSqlMapClientTemplate().queryForObject("searchReceiptsOPByRefNo", new Integer(n_RefNo));
		log.info("result: " + s);
		return Double.parseDouble(s);
	}
	
	public List searchReceiptsByNRefNo(int n_RefNo){		
		log.info("-->> searchReceiptsByNRefNo DAO ....");
		Map map = new HashMap();
		map.put("N_REFNO", n_RefNo);
		return getSqlMapClientTemplate().queryForList("searchReceiptsByNRefNo",map);
	}
	
	public List searchCDByNRefNo(int n_RefNo){		
		log.info("-->> searchReceiptsByNRefNo DAO ....");
		Map map = new HashMap();
		map.put("N_REFNO", n_RefNo);
		return getSqlMapClientTemplate().queryForList("searchCDByNRefNo",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	/*
	 * added by Jefferson Francisco Jr. 
	 *
	 * */
	
	@SuppressWarnings("unchecked")
	public List<DiscountChargeOnCashDelay> getDiscountChargeOnCashDelay(String startDate, String endDate, String branchCode)
	{
		Map discountChargeOnCashDelay = new HashMap();				
		discountChargeOnCashDelay.put("startDate", startDate);
		discountChargeOnCashDelay.put("endDate", endDate);
		discountChargeOnCashDelay.put("branchCode", branchCode);				
		return getSqlMapClientTemplate().queryForList("getDiscountChargeOnCashDelay",discountChargeOnCashDelay);
	}
	
	
	@SuppressWarnings("unchecked")
	public int getDiscountChargeOnCashDelayCount(String startDate, String endDate, String branchCode)
	{
		Map discountChargeOnCashDelay = new HashMap();				
		discountChargeOnCashDelay.put("startDate", startDate);
		discountChargeOnCashDelay.put("endDate", endDate);
		discountChargeOnCashDelay.put("branchCode", branchCode);
		return (Integer)getSqlMapClientTemplate().queryForObject("getDiscountChargeOnCashDelayCount", discountChargeOnCashDelay);
	}
	
	public boolean updateReceiptsIneligible(Map map){
		log.info("updateReceiptsIneligible");
		return getSqlMapClientTemplate().update("updateReceiptsIneligible",map)>0;
	}
	
	public boolean updateReceiptsCancelIneligible(Map map){
		log.info("updateReceiptsCancelIneligible");
		return getSqlMapClientTemplate().update("updateReceiptsCancelIneligible",map)>0;
	}
	public String getTotalReceiptsFromRefunds(Map map){
		System.out.println("-->> getTotalReceiptsFromRefunds DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalReceiptsFromRefunds", map);
	}
	public List searchReceiptsFromRefunds(Map map) {
		return getSqlMapClientTemplate().queryForList("searchReceiptsFromRefunds", map);
	}
	public String getTotalReceiptsFromAdvances(Map map){
		System.out.println("-->> getTotalReceiptsFromAdvances DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalReceiptsFromAdvances", map);
	}
	public List searchReceiptsFromAdvances(Map map) {
		return getSqlMapClientTemplate().queryForList("searchReceiptsFromAdvances", map);
	}
	/*
	 * end 
	 * */
	public Map getReceiptsHdrMap(Map m){
		return (Map) getSqlMapClientTemplate().queryForObject("getReceiptsHdrMap", m);
	}
	
	public int receiptsFromTransaction(Map m){
		return  (Integer) getSqlMapClientTemplate().insert("createHeader", m) ;
	}
	
	public void cancelFromTransaction(String N_REFNO, String transactionType){
		INVOICEDAO ID = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
		
		Map dataMap = new HashMap();
		dataMap.put("N_REFNO", N_REFNO);
		dataMap.put(transactionType, transactionType);
		List<Map> invoiceList = new ArrayList<Map>();
		List tempInvoice = new ArrayList<Map>();
		try{ 
			invoiceList =ID.getInvoiceForCancel(dataMap);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		if(invoiceList.size()==0){
			tempInvoice = getJdbcTemplate().queryForList("select n_invno from receipts_bak where n_refno = "+N_REFNO,String.class);
		}
		
		List<Integer> receiptRefNo =  getJdbcTemplate().queryForList("SELECT n_refno from receiptshdr where "+transactionType+" = "+N_REFNO, Integer.class);

		
		//CANCEL RECEIPTS HEADER AND CREDIT NOTE AND SUBHEADER
		getJdbcTemplate().update("UPDATE receiptsHdr SET d_datebounced=convert(nvarchar,(select [currentdate] FROM [factorsGetDate]),101), c_status=3 WHERE "+transactionType+" = "+N_REFNO); //before: getDate()
		for (int loop=0;loop<receiptRefNo.size();loop++){
			getJdbcTemplate().update("UPDATE creditNote SET c_status=3,d_cancelleddate=CONVERT(nvarchar,(select [currentdate] FROM [factorsGetDate]),101) WHERE c_receiptno= "+receiptRefNo.get(loop)); //before: getDate()
			getJdbcTemplate().update("UPDATE subheader SET b_cancelled = 1, d_cancelledDate=CONVERT(nvarchar,(select [currentdate] FROM [factorsGetDate]),101) WHERE n_referenceNo = "+receiptRefNo.get(loop)+" AND c_type = 'P' AND c_transactionType = 'P'"); //before: getDate()
			
		}
		
		try{
			if(invoiceList.size()!=0){
				for (int x =0; x<invoiceList.size();x++){
					if(Integer.parseInt(invoiceList.get(x).get("status").toString())==4){
						getJdbcTemplate().update("UPDATE invoice SET b_fromtransaction = 0,c_status="+invoiceList.get(x).get("status")+", " +
								"d_fullypaiddate = null, d_partialpaiddate='"+invoiceList.get(x).get("lastPayment")+"',n_partialreference = "+ invoiceList.get(x).get("lastrefno")+" WHERE n_invno ="+invoiceList.get(x).get("n_invno"));
					}else
					getJdbcTemplate().update("UPDATE invoice SET b_fromtransaction = 0,c_status="+invoiceList.get(x).get("c_status")+", " +
							"d_fullypaiddate = null, d_partialpaiddate=null, n_partialreference = null WHERE n_invno ="+invoiceList.get(x).get("n_invno"));
				}
			}else if(invoiceList.size()==0&&tempInvoice.size()!=0){
				for(int index =0; index<tempInvoice.size();index++){
					getJdbcTemplate().update("UPDATE INVOICE set b_fromtransaction = 0  where n_invno=" +tempInvoice.get(index));
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public Boolean createTempReceipt(Map map){
		getSqlMapClientTemplate().insert("createTempReceipt",map);
		return true;
	}
	
	public Boolean createReceiptsHeader(Map map){
		Map dataMap = new HashMap();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		
		List c_custcodes = getJdbcTemplate().queryForList("select  distinct(c_custcode) from receipts_bak where n_refno = "+map.get("N_REFNO"),String.class);
		String N_REFNO = map.get("N_REFNO").toString();
		dataMap.put("C_CLNTCODE", map.get("C_CLNTCODE"));
		dataMap.put("C_BRANCHCODE", map.get("C_BRANCHCODE"));
		dataMap.put("C_USERID", map.get("C_USERID"));
		dataMap.put("C_CURRENCYCODE", "PHP");
		dataMap.put("N_EXCHANGERATE", 1.0);
		dataMap.put(map.get("transType").toString(), N_REFNO);
		String type = map.get("C_RECEIPTTYPE").toString();
		dataMap.put("C_RECEIPTTYPE", map.get("C_RECEIPTTYPE"));
		SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
		dataMap.put("D_TRANSACTIONDATE", SDF.format(date.newDate())); //before:new Date()
		String sql = "";
		String description = map.get("Particular").toString();
		double total = 0.0;
		double CNAmount = 0.0;
		long headerRef = 0; 
		ReceiptsDtlDAO RD = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
		CreditNoteDAO CD = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
		String[] invoiceArray;
		List invoices2 =  new ArrayList();
		List<String[]> invoicess= new ArrayList<String[]>();
		if(c_custcodes.size()!=0){
			for(int customerLoop=0;customerLoop<c_custcodes.size();customerLoop++){
				dataMap.put("C_CUSTCODE", c_custcodes.get(customerLoop));
				sql = "SELECT * FROM receipts_bak WHERE c_custcode = "+c_custcodes.get(customerLoop)+" AND n_refno  = "+map.get("N_REFNO")+"AND c_receipttype = "+type;
			
				List<Map> invoices = getJdbcTemplate().queryForList(sql);
				invoices2.clear();
				invoicess.clear();
				total = 0.0;
				CNAmount = 0.0;
				for(int invoiceLoop =0;invoiceLoop<invoices.size();invoiceLoop++ ){
					total += Double.parseDouble(invoices.get(invoiceLoop).get("N_COLLECTED").toString());
					CNAmount+= Double.parseDouble(invoices.get(invoiceLoop).get("N_CREDITNOTEAMT").toString());
					invoiceArray = new String[4];
					invoiceArray[0]=invoices.get(invoiceLoop).get("N_INVNO").toString();
					invoiceArray[1]=invoices.get(invoiceLoop).get("N_COLLECTED").toString();
					invoiceArray[2]="0";
					invoiceArray[3]="0";
					invoicess.add(invoiceArray);
					invoices2.add(invoices.get(invoiceLoop).get("N_INVNO").toString());
				}
				
				dataMap.put("N_AMOUNT", total);
				dataMap.put("N_TOTINVAMT", total);
				dataMap.put("N_ORIGAMOUNT", total);
				dataMap.put("C_STATUS", CNAmount!=0?4:2);
				
				int TransRef = receiptsFromTransaction(dataMap);
				dataMap.put("N_REFNO",TransRef);
				dataMap.put("invoices",invoices);
				
				dataMap.put("N_Amount", total);
				
				dataMap.put("C_Type","P");
				dataMap.put("C_TransactionType","P");
				dataMap.put("invoices2", invoices2);
				SubHeaderService JS = SubHeaderService.getInstance();
				headerRef= JS.createSubHeader(dataMap, description, SDF.format(date.newDate()),"COLLECTION"); //before:new Date()
				dataMap.put("invoicess", invoicess);
				JS.createLedgerEntry2(dataMap, "Collection", headerRef);
				if(CNAmount!=0){
					dataMap.put("CNAmount2",CNAmount);
					JS.createLedgerEntry2(dataMap, "ReceiptsFromTransaction", headerRef);
				}
				for(int invoiceLoop =0;invoiceLoop<invoices.size();invoiceLoop++ ){
					
					if(Double.parseDouble(invoices.get(invoiceLoop).get("N_CREDITNOTEAMT").toString())!=0){
						dataMap.put("CNAmount", invoices.get(invoiceLoop).get("N_CREDITNOTEAMT"));
						JS.createLedgerEntry2(dataMap, "Credit-Note",headerRef);
						getJdbcTemplate().update("UPDATE invoice SET b_fromtransaction = 0, c_status=6, d_fullypaiddate = convert(nvarchar,(select [currentdate] FROM [factorsGetDate]),101) WHERE n_invno ="+invoices.get(invoiceLoop).get("N_INVNO")); //before: getDate()
					}else
							getJdbcTemplate().update("UPDATE invoice SET b_fromtransaction = 0, c_status=4, n_partialreference = "+invoices.get(invoiceLoop).get("N_REFNO")+", d_partialpaiddate = convert(nvarchar,(select [currentdate] FROM [factorsGetDate]),101) WHERE n_invno ="+invoices.get(invoiceLoop).get("N_INVNO")); //before:getDate()
				}
				RD.receiptsDetailFromTransaction(dataMap);
				CD.creditNoteFromTransaction(dataMap);
			}
		}
		
		return true;
	}
	
	//----------------------added by CVG as of 06-07-16
	public Integer insertDiscountDetailReceipt(Map map){
		System.out.println("-->> insertDiscountDetailReceipt"); 
	    return (Integer) getSqlMapClientTemplate().update("insertDiscountDetailReceipt", map);	
	}
	
	public Integer insertPenaltyDetailReceipt(Map map){
		System.out.println("-->> insertPenaltyDetailReceipt"); 
	    return (Integer) getSqlMapClientTemplate().update("insertPenaltyDetailReceipt", map);	
	}
	//----------------------end
	public Map getTransactionRateReceipts(Map map){
		
		return (Map) getSqlMapClientTemplate().queryForObject("transactionRateReceipts",map);
	}
	
	public Map getReceiptsPenalty(Map map){
		
		return (Map) getSqlMapClientTemplate().queryForObject("getReceiptsPenalty",map);
	}
}
