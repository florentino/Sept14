package com.bdo.factor.dao;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.ActualDunningBean;

public class ActualDunningDAO extends SqlMapClientDaoSupport{

	/**
	 * @param args
	 */
	 public List<ActualDunningBean> getFields(Map data){
		 return (List<ActualDunningBean>)getSqlMapClientTemplate().queryForList("getFields",data);
	 }

}
