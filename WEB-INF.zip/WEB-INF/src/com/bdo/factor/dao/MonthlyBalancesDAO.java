package com.bdo.factor.dao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.util.DateUtils;

public class MonthlyBalancesDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(MonthlyBalancesDAO.class);

	public MonthlyBalancesDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public void updateMonthlyBalancesByClntCodeAndBranchCode(ClientActivities ca){
		try{
			getSqlMapClient().update("updateMonthlyBalancesByClntCodeAndBranchCode",ca); //>0?true:false;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public static String getMonthEndDateDummy(Map map){
		Calendar cal = new GregorianCalendar(); 
		cal.set(Calendar.YEAR, Integer.parseInt(map.get("year").toString()));
		cal.set(Calendar.MONTH, Integer.parseInt(map.get("month").toString()));
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(cal.DAY_OF_MONTH));
		log.info("calendar "+cal.get(Calendar.MONTH)+"/"+cal.get(Calendar.DAY_OF_MONTH)+"/"+cal.get(Calendar.YEAR));
		return null;		
	}
	
	
	
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*
		Calendar cal = new GregorianCalendar(); 
		cal.set(Calendar.YEAR, 2008);
		// Get the number of days in that month 
		cal.set(Calendar.MONTH, 1); 
		//cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)-1);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(cal.DAY_OF_MONTH));
		//int days = cal.getActualMaximum(cal.DAY_OF_MONTH);
		//Date.parse();
		Date d= new Date();
		;
		log.info("cal.getTime() = "+cal.getTime());
		cal.add(Calendar.DATE, 1);
		log.info("cal.getTime() = "+cal.getTime());
		Calendar cal2 = new GregorianCalendar(2010, 0, 1); 
		log.info("max = "+days); 
		String lastDate=String.valueOf(cal.getActualMaximum(cal.DAY_OF_MONTH));
		Date date = new Date();
		//date.setDate(arg0)
		log.info(lastDate);
		//log.info(gc);
		 * 
		 */
		
		Map map = new HashMap();
		map.put("month", 1);
		map.put("year", 2009);
		Calendar c = DateUtils.getMonthEndDate(map);
		log.info(" date "+c.getTime());
		c.add(Calendar.DATE, -c.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date date = c.getTime();
		Date monthEnd = DateUtils.getInstance().getPreviousBusinessDay(date, "02");
		
		log.info(" date "+monthEnd);
	}

}
