package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class CurrencyDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(CurrencyDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCurrency(Map map){
		
		log.debug("-->> searchCurrency DAO ....");
		return getSqlMapClientTemplate().queryForList("searchCurrency",map);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchCurrencyByCode(String c_CurrencyCode, String d_RateDate){
		
		log.debug("-->> searchCurrencyByCode DAO....");
		
		Map m = new HashMap();		
		m.put("C_CURRENCYCODE", c_CurrencyCode);
		m.put("D_RATEDATE", d_RateDate);
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchCurrencyByCode",m);		
		return l;
	}
	
	public List searchCurrencyByCurrencyCode(String c_CurrencyCode){
		
		log.debug("-->> searchCurrencyByCode DAO....");
		
		Map m = new HashMap();		
		m.put("C_CURRENCYCODE", c_CurrencyCode);
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchCurrencyByCurrencyCode",m);
		log.info("list size:" + l.size());
		return l;
	}
	
	public String searchCurrencyCode(String c_CurrencyCode){
		
		log.debug("-->> searchCurrencyCode DAO....");
		
		Map m = new HashMap();		
		m.put("C_CURRENCYCODE", c_CurrencyCode);		
		
		String currencyCode = (String) getSqlMapClientTemplate().queryForObject("searchCurrencyCode",m);		
		return currencyCode;
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addCurrency(Map map){
		return getSqlMapClientTemplate().update("addCurrency",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateCurrency(Map map){
		return getSqlMapClientTemplate().update("updateCurrency",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteCurrency(Map map){
		return getSqlMapClientTemplate().delete("deleteCurrency",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsCurrency(){
		
		log.debug("-->> getTotalRecordsCurrency DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsCurrency");
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchCurrencyAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchCurrencyAutoComplete",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchCurrencyResolveToCode(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchCurrencyResolveToCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchCurrencyResolveToDesc(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchCurrencyResolveToDesc",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchCurrencyResolveToRateDate(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchCurrencyResolveToRateDate",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public List searchCurrencyList(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchCurrencyList",map);
	}
	
	public String searchData(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchData",map);
	}
	
	public Map getSystemCurrency(){
		return (Map) getSqlMapClientTemplate().queryForObject("getSystemCurrency" );
		
	}
	
};