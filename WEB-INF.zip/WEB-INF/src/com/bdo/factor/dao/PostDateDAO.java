package com.bdo.factor.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import java.util.Date;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.PostDate;
import com.sun.org.apache.bcel.internal.generic.GETSTATIC;

public class PostDateDAO extends SqlMapClientDaoSupport{	
	
	private static Logger log = Logger.getLogger(PostDateDAO.class);

	public Date searchDayEnd(String c_BranchCode){		
		log.info("-->> searchDayEnd... ");
		return (Date) getSqlMapClientTemplate().queryForObject("searchDayEnd",c_BranchCode);
	}
	
	public Date searchDInitialize(String c_BranchCode){		
		log.info("-->> searchDInitialize... ");
		return (Date) getSqlMapClientTemplate().queryForObject("searchDInitialize",c_BranchCode);
	}
	
	public PostDate searchProcessingDates(String c_BranchCode) {
		log.info("-->> searchProcessingDates... ");
		return (PostDate) getSqlMapClientTemplate().queryForObject("searchProcessingDates",c_BranchCode);
	}
	
	public boolean updateDInitialize(Map receiptsDetailForm) {
		return getSqlMapClientTemplate().update("updateDInitialize",receiptsDetailForm)>0;
	}
	
	public List getPostDateByBranchCode(Map map) {
		List list = getSqlMapClientTemplate().queryForList("getPostDateByBranchCode",map);
		log.info("getPostDateByBranchCode => "+list.size());
		return list;
	}	
	
	public boolean updateMonthEnd(Map map) {
		return getSqlMapClientTemplate().update("updateMonthEnd",map)>0;
	}	
	
	public boolean updateYearEnd(Map map) {
		return getSqlMapClientTemplate().update("updateYearEnd",map)>0;
	}		
	
	public List<CC> getAllClientFromCC(Map map) {
		List<CC> list = new ArrayList<CC>();
		list = getSqlMapClientTemplate().queryForList("getAllClientFromCC",map);
		log.info("getAllClientFromCC => "+list.size());
		return list;
	}
	
	public boolean updateDayEnd(Map map) {
		return getSqlMapClientTemplate().update("updateDayEnd",map)>0;
	}		
	
	public boolean insertPostDate(Map map) {
		return getSqlMapClientTemplate().update("insertPostDate",map) > 0;
	}
	
	public boolean insertPostDateFromBranch(Map map) {
		return getSqlMapClientTemplate().update("insertPostDateFromBranch",map) > 0;
	}
	
	public Date searchMonthEnd(String c_BranchCode){		
		log.info("-->> searchMonthEnd... ");
		return (Date) getSqlMapClientTemplate().queryForObject("searchMonthEnd",c_BranchCode);
	}
	
	public List<Map> getClientProceeds(Map m){
		return getSqlMapClientTemplate().queryForList("getClientProceeds",m);
	}
	
	public List<Map> getClientProceedsMonthEnd(Map m){
		return getSqlMapClientTemplate().queryForList("getClientProceedsMonthEnd",m);
	}
	
	public Boolean setAccrualLedger(Map m){
		return getSqlMapClientTemplate().update("setAccrualLedger",m)>0;
	}
	
	public Double getPDInterest(Map m){
		return (Double) getSqlMapClientTemplate().queryForObject("getPDInterest",m);
	}
	
	public Boolean saveAccountBalance(Map m){
		return getSqlMapClientTemplate().update("saveAccountBalance",m)>0;
	}
	
	public Integer isProcessed(Map m){
		return	(Integer) getSqlMapClientTemplate().queryForObject("isProcessed",m); 
	}
	
	public Integer isInitialized(Map m){
		return	(Integer) getSqlMapClientTemplate().queryForObject("isInitialized",m); 
	}
	
	public Boolean deleteInitializedEntry(Map m){
			 if(getSqlMapClientTemplate().update("deleteInitializedLedger",m)>0)
				 return getSqlMapClientTemplate().update("deleteInitializedHeader",m)>0;
		return false;
	}
	
	public Boolean deleteAccountBalance(Map m){
			if(getSqlMapClientTemplate().update("deleteAccountBalance",m)>0)
				 if(getSqlMapClientTemplate().update("deleteMonthlySubLedger",m)>0)
					 return getSqlMapClientTemplate().update("deleteMonthlySubHeader",m)>0;
			return false;	
	}

	public Integer getLastWorkingDay(){
		return (Integer) getSqlMapClientTemplate().queryForObject("getLastWorkingDay");
	}
}
