package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.ClassReference;
import com.bdo.factor.beans.ModuleClass;
import com.bdo.factor.beans.ModuleReference;
import com.bdo.factor.beans.RoleModule;
import com.bdo.factor.beans.RoleReference;
import com.bdo.factor.beans.User;

public class SecurityDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(SecurityDAO.class);

	public List searchClasses(Map map){
		log.debug("-->> getSearchClasses DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchClasses", map);
	}

	public boolean addClasses(Map map){
		return getSqlMapClientTemplate().update("addClasses",map)>0;
	}

	public boolean updateClasses(Map map){
		return getSqlMapClientTemplate().update("updateClasses",map)>0;
	}

	public String getTotalRecordsClasses(){
		
		log.debug("-->> getTotalRecordsClasses DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsClasses");
	}
	
public String getTotalRecordsModuleClasses(){
		
		log.debug("-->> getTotalRecordsClasses DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsModuleClasses");
	}

	public List searchClassesByCode(Map map){
		
		log.debug("-->> getClassName DAO CORRECT searchClassesByCode....");
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchClassesByCode",map);
		log.debug("l: " + l.size());
		return l;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public List searchModules(Map map){
		log.debug("-->> getSearchModules DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchModules", map);
	}
	
	public List searchAvailModule(Map role){
		log.debug("-->> getSearchModules DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchAvailModule",role);
	}

	public boolean addModules(Map map){
		return getSqlMapClientTemplate().update("addModules",map)>0;
	}

	public boolean updateModules(Map map){
		return getSqlMapClientTemplate().update("updateModules",map)>0;
	}

	public String getTotalRecordsModules(){
		
		log.debug("-->> getTotalRecordsModules DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsModules");
	}

	public List searchModulesByCode(Map map){
		
		log.debug("-->> getClassName DAO CORRECT searchModulesByCode....");
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchModulesByCode",map);
		log.debug("l: " + l.size());
		return l;
	}

	public List searchAvailClasses(Map map){
		log.debug("-->> searchAvailClasses DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchAvailClasses", map);
	}
	
	public List searchAssignedClasses(Map map){
		log.debug("-->> searchAssignedClasses DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchAssignedClasses", map);
	}
	
	public List searchModuleClasses(Map map){
		log.debug("-->> searchModuleClasses DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchModuleClasses", map);
	}
	
	public List searchModuleList(Map map){
		return getSqlMapClientTemplate().queryForList("searchModuleList", map);
	}
	
	public boolean addModuleClass(Map map){
		return getSqlMapClientTemplate().update("addModuleClass",map)>0;
	}
	
	public boolean deleteModuleClass(Map map){
		log.debug("-->> deleteModuleClass DAO CORRECT ....");
		return getSqlMapClientTemplate().delete("deleteModuleClass",map)>0;
	}
	
	public boolean updateModuleClass(Map map){
		log.debug("-->> updateModuleClass DAO CORRECT ....");
		return getSqlMapClientTemplate().delete("updateModuleClass",map)>0;
	}
	
	public List searchRole(Map map){
		log.debug("-->> getSearchRole DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchRole", map);
	}

	public boolean addRole(Map map){
		return getSqlMapClientTemplate().update("addRole",map)>0;
	}

	public boolean updateRole(Map map){
		return getSqlMapClientTemplate().update("updateRole",map)>0;
	}

	public String getTotalRecordsRole(){
		
		log.debug("-->> getTotalRecordsRole DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsRole");
	}

	public List searchRoleByCode(Map map){
		
		log.debug("-->> getRole DAO CORRECT searchRoleByCode....");
		
		ArrayList l = (ArrayList) getSqlMapClientTemplate().queryForList("searchRoleByCode",map);
		log.debug("l: " + l.size());
		return l;
	}
	
	public List searchRoleModule(Map map){
		log.debug("-->> searchRoleModule DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchRoleModule", map);
	}
	
	public List searchRoleList(Map map){
		return getSqlMapClientTemplate().queryForList("searchRoleList", map);
	}
	
	public boolean addRoleModule(Map map){
		return getSqlMapClientTemplate().update("addRoleModule",map)>0;
	}
	
	public boolean deleteRoleModule(Map map){
		log.debug("-->> deleteRoleModule DAO CORRECT ....");
		return getSqlMapClientTemplate().delete("deleteRoleModule",map)>0;
	}
	
	public Integer getRoleDependency(String data){
		return (Integer) getSqlMapClientTemplate().queryForObject("getRoleDependency", data, Integer.class);
	}
	public boolean deleteRole(String role){
		return getSqlMapClientTemplate().delete("deleteRole",role)>0;
	}
	
	public Integer getModuleDependency(String data){
		return (Integer) getSqlMapClientTemplate().queryForObject("getModuleDependency", data, Integer.class);
	}
	public boolean deleteModule(String module){
		return getSqlMapClientTemplate().delete("deleteModule",module)>0;
	}
	
	public Integer getClassReferenceDependency(String data){
		return (Integer) getSqlMapClientTemplate().queryForObject("getClassReferenceDependency", data, Integer.class);
	}
	public boolean deleteClassReferecene(String module){
		return getSqlMapClientTemplate().delete("deleteClassReferecene",module)>0;
	}
	
	public ClassReference getClassReference(String CLASS_NAME){
		return (ClassReference) getSqlMapClientTemplate().queryForObject("getClassReference",CLASS_NAME);
	}
	public ModuleClass getModuleClass(Map data){
		return (ModuleClass) getSqlMapClientTemplate().queryForObject("getModuleClass",data);
	}
	public ModuleReference getModuleReference(String MOD_NAME){
		return (ModuleReference) getSqlMapClientTemplate().queryForObject("getModuleReference",MOD_NAME);
	}
	public RoleModule getRoleModule(Map data){
		return (RoleModule) getSqlMapClientTemplate().queryForObject("getRoleModule",data);
	}
	public RoleReference getRoleReference(String ROLE){
		return (RoleReference) getSqlMapClientTemplate().queryForObject("getRoleReference",ROLE);
	}
	
	
	
	
	
	
}