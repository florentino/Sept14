package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.CheckType;


public class CheckTypeDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(INVOICEDAO.class);
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCheckType(Map map){
		
		log.debug("-->> getCheckType DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchCheckType", map);
	}


//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCheckTypeByCode(String c_CheckTypeCode){
		
		log.debug("-->> getCheckType DAO CORRECT ....");
		Map m = new HashMap();
		m.put("C_CHECKTYPECODE", c_CheckTypeCode);	
		
		return getSqlMapClientTemplate().queryForList("searchCheckTypeByCode",m);
	}
	
	public List searchCheckTypeList(Map m){
		
		log.debug("-->> getCheckType DAO CORRECT ....");	
		
		return getSqlMapClientTemplate().queryForList("searchCheckTypeByCode", m);
	}
	
	public String searchCtypeCodeByName(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchCtypeCodeByName",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addCheckType(Map checkType){
		return getSqlMapClientTemplate().update("addCheckType",checkType)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateCheckType(Map checkType){
		return getSqlMapClientTemplate().update("updateCheckType",checkType)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteCheckType(Map checkType){
		return getSqlMapClientTemplate().delete("deleteCheckType",checkType)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsCheckType(){
		
		log.debug("-->> getTotalRecordsCheckType DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsCheckType");
	}
	
	public String searchDaysByCode(Map checkTypeForm) {
		return (String)getSqlMapClientTemplate().queryForObject("searchDaysByCode", checkTypeForm);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchCheckTypeAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchCheckTypeAutoComplete",map);
	}
}
