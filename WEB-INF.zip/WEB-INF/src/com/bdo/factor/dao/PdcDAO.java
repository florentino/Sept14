package com.bdo.factor.dao;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class PdcDAO extends SqlMapClientDaoSupport {
	private static Logger log = Logger.getLogger(PdcDAO.class);
	
	public int addPDC(Map pdcForm){
		return (Integer) getSqlMapClientTemplate().insert("addPDC",pdcForm);
	}
	
	public boolean updatePDC(Map pdcForm){
		return getSqlMapClientTemplate().update("updatePDC",pdcForm)>0;
	}
	
	public boolean updatePDCStatus(Map pdcForm){
		return getSqlMapClientTemplate().update("updatePDCStatus",pdcForm)>0;
	}
	
	public boolean deletePDC(Map pdcForm){
		return getSqlMapClientTemplate().delete("deletePDC",pdcForm)>0;
	}
	
	public String getTotalPDCRecords(String c_BranchCode){
		log.debug("-->> getTotalPDCRecords DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalPDCRecords", c_BranchCode);
	}
	
	public String getTotalPDCRecordsByCustomer(Map pdcMap){
		log.debug("-->> getTotalPDCRecords DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalPDCRecordsByCustomer", pdcMap);
	}
	
	public List searchPDC(Map pdcForm){		
		log.debug("-->> searchPDCByBranch DAO ....");
		return getSqlMapClientTemplate().queryForList("searchPDC",pdcForm);
	}
	
	public List searchPDCByCustomer(Map pdcForm){		
		log.debug("-->> searchPDCByCustomer DAO ....");
		return getSqlMapClientTemplate().queryForList("searchPDCByCustomer",pdcForm);
	}
	
	public boolean updatePDCBouncedDate(Map pdcForm){		
		log.debug("-->> searchPDCByCustomer DAO ....");		
		return getSqlMapClientTemplate().update("updatePDCBouncedDate",pdcForm) > 0;
	}

}
