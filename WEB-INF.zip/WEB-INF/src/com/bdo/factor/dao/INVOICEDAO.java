package com.bdo.factor.dao;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.AdjustmentType;
import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.beans.PDODelinquent;
import com.bdo.factor.beans.PDOInvoice;
import com.bdo.factor.service.AuditService;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.ServiceUtility;

public class INVOICEDAO extends SqlMapClientDaoSupport{
	
	private static Logger log = Logger.getLogger(INVOICEDAO.class);

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchInvoice(Map map){
		
		log.info("-->> searchInvoice DAO ....");
		return getSqlMapClientTemplate().queryForList("searchInvoice",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addInvoice(Map map){
		return getSqlMapClientTemplate().update("addInvoice",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateInvoice(Map map){
		return getSqlMapClientTemplate().update("updateInvoice",map)>0;
	}
	
	public boolean updateInvoice2(Map map){
		return getSqlMapClientTemplate().update("updateInvoice2",map)>0;
	}
	
	public boolean updateInvoiceStatusByCode(String invoices, String c_Status){
		Map map = new HashMap();
		map.put("invoices", invoices);		
		map.put("C_STATUS", c_Status);
		return getSqlMapClientTemplate().update("updateInvoiceStatusByCode",map)>0;
	}
	
	public boolean updateInvoiceStatusByInvNo(String invNos, String c_Status, String nRefNo,Date tranDate){
		Map map = new HashMap();
		map.put("invNos", invNos);		
		map.put("C_STATUS", c_Status);
		map.put("N_REFNO", nRefNo);
		map.put("D_TRANSACTIONDATE", tranDate);
	
		return getSqlMapClientTemplate().update("updateInvoiceStatusByInvNo",map)>0;
	}
	
	public boolean updateInvoiceFullyPaid(String invNos, String c_Status,Date fullyPaidDate){
		Map map = new HashMap();
		map.put("invNos", invNos);		
		map.put("C_STATUS", c_Status);
		map.put("D_FULLYPAIDDATE", fullyPaidDate);
		return getSqlMapClientTemplate().update("updateInvoiceFullyPaid",map)>0;
	}
	
	public boolean updateInvoiceFullyPaidDateByCode(String invoices, Date fullyPaidDate){
		Map map = new HashMap();
		map.put("invoices", invoices);		
		map.put("D_FULLYPAIDDATE", fullyPaidDate);
		return getSqlMapClientTemplate().update("updateInvoiceFullyPaidDateByCode",map)>0;
	}
	

	// added BY CVG as of 04-14-16 for Invoice Status (C_status / C_type) bug-------------------------
	public boolean updateInvoiceFullyPaidDateByCodeNew(String invoices, Date fullyPaidDate){
		Map map = new HashMap();
		map.put("invoices", invoices);		
		map.put("D_FULLYPAIDDATE", fullyPaidDate);
		return getSqlMapClientTemplate().update("updateInvoiceFullyPaidDateByCodeNew",map)>0;
	}
	
	public boolean updateInvoiceStatusByInvNoNew(String invNos, String c_Status, String nRefNo,Date tranDate){
		Map map = new HashMap();
		map.put("invNos", invNos);		
		map.put("C_STATUS", c_Status);
		map.put("N_REFNO", nRefNo);
		map.put("D_TRANSACTIONDATE", tranDate);
	
		return getSqlMapClientTemplate().update("updateInvoiceStatusByInvNoNew",map)>0;
	}
	
	
	public boolean updateInvoiceFullyPaidNew(String invNos, String c_Status,Date fullyPaidDate){
		Map map = new HashMap();
		map.put("invNos", invNos);		
		map.put("C_STATUS", c_Status);
		map.put("D_FULLYPAIDDATE", fullyPaidDate);
		return getSqlMapClientTemplate().update("updateInvoiceFullyPaidNew",map)>0;
	}
// -------------------------------------------------------------------------------end	
	
	
	
	public boolean updateInvoiceStatusAndDateByCode(String invoices, String c_Status, Date fullyPaidDate){
		Map map = new HashMap();
		map.put("invoices", invoices);		
		map.put("C_STATUS", c_Status);
		map.put("D_FULLYPAIDDATE", fullyPaidDate);
				
		return getSqlMapClientTemplate().update("updateInvoiceStatusAndDateByCode",map)>0;
	}
	
	public boolean updateInvoiceStatusByInvoiceOnly(String invoices, String c_Status, Date fullyPaidDate){
		Map map = new HashMap();
		map.put("C_INVOICENO", invoices);		
		map.put("C_STATUS", c_Status);
		map.put("D_FULLYPAIDDATE", fullyPaidDate);
				
		return getSqlMapClientTemplate().update("updateInvoiceStatusByInvoiceOnly",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteInvoice(Map map){
		return getSqlMapClientTemplate().delete("deleteInvoice",map)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsInvoice(Map map){
		
		System.out.println("-->> getTotalRecordsInvoice DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsInvoice",map);
		//log.info("-->> getTotalRecordsInvoice DAO ....");
		//return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsInvoice");
	}
	
	public String getTotalRecordsInvoiceByStatus(Map invoiceForm){
		
		log.info("-->> getTotalRecordsInvoice DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsInvoiceByStatus", invoiceForm);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchInvoiceByStatus(Map map){
		
		log.info("-->> searchInvoiceByStatus DAO ....");
		return getSqlMapClientTemplate().queryForList("searchInvoiceByStatus",map);
	}

	public List getDueInvoiceForReport(Map map){
		
		log.info("-->> getDueInvoice DAO ....");
		return getSqlMapClientTemplate().queryForList("getDueInvoiceForReport",map);
	}
	
	public List getUniqueClientCode(Map map){
		
		log.info("-->> getDueInvoice DAO ....");
		return getSqlMapClientTemplate().queryForList("getUniqueClientCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List getTotalRecordsScheduleInvoice(Map map){
		
		if(map.get("start")==null || map.get("start").toString().trim().length()==0){
			map.put("start","1");
			map.put("end","10");
			
		}		
		
		System.out.println("-->> getTotalRecordsScheduleInvoice DAO ....");
		return getSqlMapClientTemplate().queryForList("searchScheduleInvoice",map);
	}
	
	public String getScheduleOfInvoicesCount(Map map){
		
		System.out.println("-->> getScheduleOfInvoicesCount DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getScheduleOfInvoicesCount", map);
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchScheduleInvoice(Map map){
		
		if(map.get("start")==null || map.get("start").toString().trim().length()==0){
			map.put("start","1");
			map.put("end","10");
			
		}
		
		System.out.println("-->> searchScheduleInvoice DAO ....");
		return getSqlMapClientTemplate().queryForList("searchScheduleInvoice",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////		
	

	/*
	 * added by Jefferson Francisco Jr. 
	 *
	 * */
		
	
	@SuppressWarnings("unchecked")
	public Map<String,List<PDODelinquent>> getPDOInvoiceList(String asOfDate, String branchCode)
	{
		Map<String,List<PDODelinquent>> returnMap = new HashMap();
		Map pdoInvoice = new HashMap();
		String c_clntcodenew="";
		String c_clntcodeold="";
		String c_oldClntName="";
		Double sum1_30 = 0.0;
		Double sum31_60 = 0.0;
		Double sum61_90 = 0.0;
		Double sumgt90 = 0.0;
		
		 
		Integer index =0;
		PDODelinquent summaryPDO;
		PDODelinquent fm = null;
		
		pdoInvoice.put("asOfDate", asOfDate);
		pdoInvoice.put("branchCode", branchCode);				
		
		List<PDODelinquent> pdoList=  getSqlMapClientTemplate().queryForList("getPDOInvoice",pdoInvoice);
		List<PDODelinquent> pdoListSummaryDelinquents = new ArrayList<PDODelinquent>();
		
		while(index<pdoList.size()){
			fm = pdoList.get(index);
			c_clntcodenew = fm.getC_clntcode();
			
			
			
			if(c_clntcodeold.contentEquals("")){
				c_clntcodeold = fm.getC_clntcode();
				c_oldClntName = fm.getC_clntName();
			}
			
			if(!c_clntcodeold.contentEquals(c_clntcodenew)){
				summaryPDO = new PDODelinquent();
				summaryPDO.setC_clntName(c_oldClntName);
				summaryPDO.setNetBal1_30(sum1_30);
				summaryPDO.setNetBal31_60(sum31_60);
				summaryPDO.setNetBal61_90(sum61_90);
				summaryPDO.setNetBalgt90(sumgt90);
				pdoListSummaryDelinquents.add(summaryPDO);
				sum1_30=0.0;
				sum31_60=0.0;
				sum61_90=0.0;
				sumgt90=0.0;
				c_clntcodeold = c_clntcodenew;
				c_oldClntName = fm.getC_clntName();
			}
			sum1_30+=fm.getNetBal1_30();
			sum31_60+=fm.getNetBal31_60();
			sum61_90+=fm.getNetBal61_90();
			sumgt90+=fm.getNetBalgt90();
			
			index++;
		}
		
		if(!c_clntcodeold.contentEquals("")&&c_clntcodeold.contentEquals(c_clntcodenew)){
			summaryPDO = new PDODelinquent();
			summaryPDO.setC_clntName(fm.getC_clntName());
			summaryPDO.setNetBal1_30(sum1_30);
			summaryPDO.setNetBal31_60(sum31_60);
			summaryPDO.setNetBal61_90(sum61_90);
			summaryPDO.setNetBalgt90(sumgt90);
			pdoListSummaryDelinquents.add(summaryPDO);
			sum1_30 = 0.0;
			sum31_60 = 0.0;
			sum61_90 = 0.0;
			sumgt90 = 0.0;
		}
		
		 
		returnMap.put("pdoList", pdoList);
		returnMap.put("pdoListSummaryDelinquents", pdoListSummaryDelinquents);
		return returnMap;
	}
	
	
	@SuppressWarnings("unchecked")
	public int getPDOInvoiceCount(String asOfDate, String branchCode)
	{
		Map pdoInvoice = new HashMap();
		pdoInvoice.put("asOfDate", asOfDate);
		pdoInvoice.put("branchCode", branchCode);
		return (Integer)getSqlMapClientTemplate().queryForObject("getPDOInvoiceCnt", pdoInvoice);
	}
	
	@SuppressWarnings("unchecked")
	public double getInvoiceAccruals(Map map){
		System.out.println("-->> getClientAccruals  ....");
		return (Double) getSqlMapClientTemplate().queryForObject("getInvoiceAccruals", map);
	}
	@SuppressWarnings("unchecked")
	public double getInvoiceAccrualsToday(Map map){
		System.out.println("-->> getClientAccrualsToday  ....");
		return (Double) getSqlMapClientTemplate().queryForObject("getInvoiceAccrualsToday", map);
	}
	@SuppressWarnings("unchecked")
	public List getAdjustType(Map map){
		System.out.println("-->> getAdjustType  ....");
		return getSqlMapClientTemplate().queryForList("getAdjustType",map);
	}
	@SuppressWarnings("unchecked")
	public double getLastAccrual(Map map){
		System.out.println("-->> getLastAccrual  ....");
		Double var1 =(Double) getSqlMapClientTemplate().queryForObject("getLastAccrual", map);
		return var1!=null?var1:0 ;
	}
	@SuppressWarnings("unchecked")
	public double getDCAccrual(Map map){
		System.out.println("-->> getDCAccrual  ....");
		return (Double) getSqlMapClientTemplate().queryForObject("getRefundDC", map);
	}
	public double getDCAccrual2(Map map){
		System.out.println("-->> getDCAccrual  ....");
		SimpleDateFormat SDF = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
		SimpleDateFormat SDF2 = new SimpleDateFormat("MM/dd/yyyy");
		String StringAsOfDate = map.get("asOfDate").toString();
		Date DeploymentDate;
		Date asOfDate;
		Double accrual = 0.00;
		try{
			asOfDate = SDF2.parse(StringAsOfDate);
			DeploymentDate = SDF2.parse("04/30/2012");
			if(asOfDate.compareTo(DeploymentDate)>=1){
				accrual = (Double) getSqlMapClientTemplate().queryForObject("getDCAccrual", map); 
			}
			else
				accrual = (Double) getSqlMapClientTemplate().queryForObject("getDCAccrualPrev", map);
		}catch(Exception e){
			log.info("ERROR PARSING DATES, USING DEFAULT");
			e.printStackTrace();
			accrual =(Double) getSqlMapClientTemplate().queryForObject("getDCAccrual", map);
		}
		
		return accrual;
	}
	/*
	 * end... 
	 * */
//////////////////////////////////////////////////////////////////////////////////////////////	
	public static void main (String[] args){
		String i="";
		Map param = new HashMap();
		param.put("startDate", "05/01/2009");
		param.put("endDate", "05/31/2009");
		INVOICEDAO inv = (INVOICEDAO) Persistence.getDAO("INVOICEDAO");
		Iterator iter=inv.getUniqueClientCode(param).iterator();
		log.info("inv.getUniqueClientCode(param)=>"+inv.getUniqueClientCode(param).size());
		while(iter.hasNext()){
			String m = (String)iter.next();
			i+=m+"\n";
			log.info("i.getC_CUSTCODE()=> "+i);
		}
	}
	
//////added October 03, 2012//////
		public String getTotalDelinquent(Map map){
		//System.out.println("-->> getTotalRecordsAdvances DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalDelinquent",map);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		public List searchDelinquent(Map map){
		//System.out.println("-->> getTotalRecordsAdvances DAO ....");
		return getSqlMapClientTemplate().queryForList("searchDelinquent",map);
		}

		public String getAmountDelinquent(Map map){
			return (String) getSqlMapClientTemplate().queryForObject("getAmountDelinquent",map);
		}
		
///////added October 05,2012
		public boolean updateInvoiceFromTransaction(Map map){
			return getSqlMapClientTemplate().update("updateInvoiceFromTransaction",map)>0;
		}

//////
		public List<Map> getInvoiceForCancel(Map dataMap){
			return getSqlMapClientTemplate().queryForList("getInvoiceForCancel",dataMap);
		}
/////////
		public List getDelinquentForEdit(Map dataMap){
			return getSqlMapClientTemplate().queryForList("getDelinquentInvoice", dataMap);
		}
		public boolean updateInvoiceTransaction(Map dataMap){
			return getSqlMapClientTemplate().update("updateInvoiceTransaction", dataMap)>0;
		}
		
		public double getInvoiceAmount(String clntcode,String asOfDate){
			Map invoiceAmt = new HashMap();
			invoiceAmt.put("asOfDate", asOfDate);
			invoiceAmt.put("clntcode", clntcode);
			return (Double) getSqlMapClientTemplate().queryForObject("getInvoiceAmount", invoiceAmt);
		}
		
		public int getOutstandingPaymentNumber(String clntcode,String asOfDate){
			Map outPayNum = new HashMap();
			outPayNum.put("asOfDate", asOfDate);
			outPayNum.put("clntcode", clntcode);
			return (Integer)getSqlMapClientTemplate().queryForObject("getOutstandingPaymentNumber", outPayNum);
		}
		
		public Date getInvoiceDuedate(String clntcode,String asOfDate){
			Map invDueDate = new HashMap();
			invDueDate.put("asOfDate", asOfDate);
			invDueDate.put("clntcode", clntcode);
			return (Date)getSqlMapClientTemplate().queryForObject("getInvoiceDuedate", invDueDate);
		}
		
		@SuppressWarnings("unchecked")
		public int checkClientInvoice(String clntcode)
		{		
			return (Integer)getSqlMapClientTemplate().queryForObject("checkClientInvoice", clntcode);
		}
		
		public void updateInvoiceSC(String clntcode, int advrefno, String serviceChg){
			Map invSC= new HashMap();
			invSC.put("clntcode", clntcode);
			invSC.put("advrefno", advrefno);
			invSC.put("serviceChg", serviceChg);
			getSqlMapClientTemplate().queryForObject("updateInvoiceSC", invSC);
		}
		
		public String getFullyPaidDate (Map m){
			
			return (String)getSqlMapClientTemplate().queryForObject("getFullyPaidDate", m);
		}
		
		public int getInvoiceCount (Map m){
			
			return (Integer)getSqlMapClientTemplate().queryForObject("getInvoiceCount",  m);
		}
		
		
		
}
