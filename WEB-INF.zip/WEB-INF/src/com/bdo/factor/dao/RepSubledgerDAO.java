package com.bdo.factor.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//  iBatis
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.AccountForReview;
import com.bdo.factor.beans.Branch;
import com.bdo.factor.beans.User;


public class RepSubledgerDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(RepSubledgerDAO.class);
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List<Map> searchGLCodeAutoComplete(Map map){
		return getSqlMapClientTemplate().queryForList("searchGLCodeAutoComplete",map);
	}
	public List searchGLDescriptionToGLCode(Map map){
		return getSqlMapClientTemplate().queryForList("searchGLDescriptionToGLCode",map);
	}

}
  