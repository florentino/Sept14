package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.Bank;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.ClientBean;
import com.bdo.factor.beans.ClientConcentration;

public class ClientDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(ClientDAO.class);

	//////////////////////////////////////////////////////////////////////////////////////////////

	public List searchClient(Map map) {

		log.debug("-->> getClient DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchClient",map);
	}
	//@@
	public List searchClientClassificationList(Map map){
		
		log.debug("-->> @@ searchClientClassificationList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchClientClassificationList",map);
	}
	//@@#
	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsClient(){
		
		logger.debug("-->> getTotalRecordsClient DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsClient");
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchClientWithPaging(Map map) {
		
		if(map.get("start")==null || map.get("start").toString().trim().length()==0){
			map.put("start","1");
			map.put("end","10");
			
		}

		log.debug("-->> searchClientWithPaging DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchClientWithPaging",map);
	}
	
	public String searchClientCountForPaging(Map map) {
	
		log.debug("-->> searchClientCountForPaging DAO CORRECT ....");
		return (String) getSqlMapClientTemplate().queryForObject("searchClientCountForPaging", map);		
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////

	public List searchClientByCode(Map map){
		
		log.debug("-->> searchClientByCode DAO ....");
		return getSqlMapClientTemplate().queryForList("searchClientByCode",map);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchClientCodeByBranchAndName(Map map){
		
		log.debug("-->> searchClientCodeByBranchAndName DAO ....");
		return getSqlMapClientTemplate().queryForList("searchClientCodeByBranchAndName",map);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchClientServiceAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchClientServiceAutoComplete",map);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchClientClassificationServiceAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchClientClassificationServiceAutoComplete",map);
	}
	public List searchBusinessClassificationServiceAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchBusinessClassificationServiceAutoComplete",map);
	}
	public List searchIndustrialTypeServiceAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchIndustrialTypeServiceAutoComplete",map);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	

	public boolean addClient(Map map){
		
		log.debug("-->> addClient DAO CORRECT ....");

		if(map.containsKey("N_CREDITLIMIT") && (map.get("N_CREDITLIMIT")==null || map.get("N_CREDITLIMIT").toString().trim().length()==0)){
			map.put("N_CREDITLIMIT","0");
		}
		
		if(map.containsKey("N_FIU") && (map.get("N_FIU")==null || map.get("N_FIU").toString().trim().length()==0)){
			map.put("N_FIU","0");
		}
		
		if(map.containsKey("N_FIUTRAN") && (map.get("N_FIUTRAN")==null || map.get("N_FIUTRAN").toString().trim().length()==0)){
			map.put("N_FIUTRAN","0");
		}
		
		if(map.containsKey("N_RECEIVABLES") && (map.get("N_RECEIVABLES")==null || map.get("N_RECEIVABLES").toString().trim().length()==0)){
			map.put("N_RECEIVABLES","0");
		}
		
		if(map.containsKey("N_INELIGIBLEREC") && (map.get("N_INELIGIBLEREC")==null || map.get("N_INELIGIBLEREC").toString().trim().length()==0)){
			map.put("N_INELIGIBLEREC","0");
		}
		
		if(map.containsKey("N_FORCLEARING") && (map.get("N_FORCLEARING")==null || map.get("N_FORCLEARING").toString().trim().length()==0)){
			map.put("N_FORCLEARING","0");
		}
		
		if(map.containsKey("N_RESERVES") && (map.get("N_RESERVES")==null || map.get("N_RESERVES").toString().trim().length()==0)){
			map.put("N_RESERVES","0");
		}
				
//		if(map.containsKey("N_INVESTMENTLIMIT") && (map.get("N_INVESTMENTLIMIT")==null || map.get("N_INVESTMENTLIMIT").toString().trim().length()==0)){
//			map.put("N_INVESTMENTLIMIT","0");
//		}
//		
//		if(map.containsKey("N_SCR") && (map.get("N_SCR")==null || map.get("N_SCR").toString().trim().length()==0)){
//			map.put("N_SCR","0");
//		}
//		
//		if(map.containsKey("N_DCR") && (map.get("N_DCR")==null || map.get("N_DCR").toString().trim().length()==0)){
//			map.put("N_DCR","0");
//		}
//		
//		if(map.containsKey("N_HCR") && (map.get("N_HCR")==null || map.get("N_HCR").toString().trim().length()==0)){
//			map.put("N_HCR","0");
//		}
//		
//		if(map.containsKey("N_SETTLEMENT") && (map.get("N_SETTLEMENT")==null || map.get("N_SETTLEMENT").toString().trim().length()==0)){
//			map.put("N_SETTLEMENT","0");
//		}
//		
//		if(map.containsKey("B_ACBANK") && (map.get("B_ACBANK")==null || map.get("B_ACBANK").toString().trim().length()==0)){
//			map.put("B_ACBANK","0");
//		}
//		
//		if(map.containsKey("N_ADVANCEDRATIO") && (map.get("N_ADVANCEDRATIO")==null || map.get("N_ADVANCEDRATIO").toString().trim().length()==0)){
//			map.put("N_ADVANCEDRATIO","0");
//		}
//		
//		if(map.containsKey("N_EFFYIELD") && (map.get("N_EFFYIELD")==null || map.get("N_EFFYIELD").toString().trim().length()==0)){
//			map.put("N_EFFYIELD","0");
//		}
//		
//		
//		if(map.containsKey("D_EFFDATE") && (map.get("D_EFFDATE")==null || map.get("D_EFFDATE").toString().trim().length()==0)){
//			map.put("D_EFFDATE",null);
//		}
//		
//		if(map.containsKey("D_CPDATE") && (map.get("D_CPDATE")==null || map.get("D_CPDATE").toString().trim().length()==0)){
//			map.put("D_CPDATE",null);
//		}
//		
//		if(map.containsKey("D_REVIEWDATE") && (map.get("D_REVIEWDATE")==null || map.get("D_REVIEWDATE").toString().trim().length()==0)){
//			map.put("D_REVIEWDATE",null);
//		}
//		
//		if(map.containsKey("D_AUDITEDDATE") && (map.get("D_AUDITEDDATE")==null || map.get("D_AUDITEDDATE").toString().trim().length()==0)){
//			map.put("D_AUDITEDDATE",null);
//		}
//		
//		if(map.containsKey("D_INHOUSEDATE") && (map.get("D_INHOUSEDATE")==null || map.get("D_INHOUSEDATE").toString().trim().length()==0)){
//			map.put("D_INHOUSEDATE",null);
//		}
		
		
		return getSqlMapClientTemplate().update("addClient",map)>0;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addClientInMonthlyBalances(Map map){
		
		return getSqlMapClientTemplate().update("addClientInMonthlyBalances",map)>0;
		
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateClient(Map map){
		
		if(map.containsKey("N_CREDITLIMIT") && (map.get("N_CREDITLIMIT")==null || map.get("N_CREDITLIMIT").toString().trim().length()==0)){
			map.put("N_CREDITLIMIT","0");
		}
		
		if(map.containsKey("N_FIU") && (map.get("N_FIU")==null || map.get("N_FIU").toString().trim().length()==0)){
			map.put("N_FIU","0");
		}
		
		if(map.containsKey("N_FIUTRAN") && (map.get("N_FIUTRAN")==null || map.get("N_FIUTRAN").toString().trim().length()==0)){
			map.put("N_FIUTRAN","0");
		}
		
		if(map.containsKey("N_RECEIVABLES") && (map.get("N_RECEIVABLES")==null || map.get("N_RECEIVABLES").toString().trim().length()==0)){
			map.put("N_RECEIVABLES","0");
		}
		
		if(map.containsKey("N_INELIGIBLEREC") && (map.get("N_INELIGIBLEREC")==null || map.get("N_INELIGIBLEREC").toString().trim().length()==0)){
			map.put("N_INELIGIBLEREC","0");
		}
		
		if(map.containsKey("N_FORCLEARING") && (map.get("N_FORCLEARING")==null || map.get("N_FORCLEARING").toString().trim().length()==0)){
			map.put("N_FORCLEARING","0");
		}
		
		if(map.containsKey("N_RESERVES") && (map.get("N_RESERVES")==null || map.get("N_RESERVES").toString().trim().length()==0)){
			map.put("N_RESERVES","0");
		}
		
		if(map.containsKey("C_STATUS") && map.get("C_STATUS")!=null && map.get("C_STATUS").toString().trim().startsWith("on")){
			map.put("C_STATUS","1");
		}
		
		return getSqlMapClientTemplate().update("updateClient",map)>0;
	}
	
	public boolean updateClientTCInfo(Map map){

		if(map.containsKey("N_INVESTMENTLIMIT") && (map.get("N_INVESTMENTLIMIT")==null || map.get("N_INVESTMENTLIMIT").toString().trim().length()==0)){
			map.put("N_INVESTMENTLIMIT","0");
		}
		
		if(map.containsKey("N_SCR") && (map.get("N_SCR")==null || map.get("N_SCR").toString().trim().length()==0)){
			map.put("N_SCR","0");
		}
		
		if(map.containsKey("N_DCR") && (map.get("N_DCR")==null || map.get("N_DCR").toString().trim().length()==0)){
			map.put("N_DCR","0");
		}
		
		if(map.containsKey("N_HCR") && (map.get("N_HCR")==null || map.get("N_HCR").toString().trim().length()==0)){
			map.put("N_HCR","0");
		}
	
		if(map.containsKey("N_SETTLEMENT") && (map.get("N_SETTLEMENT")==null || map.get("N_SETTLEMENT").toString().trim().length()==0)){
			map.put("N_SETTLEMENT","0");
		}
		
		if(map.containsKey("N_ADVANCEDRATIO") && (map.get("N_ADVANCEDRATIO")==null || map.get("N_ADVANCEDRATIO").toString().trim().length()==0)){
			map.put("N_ADVANCEDRATIO","0");
		}
		
		if(map.containsKey("N_EFFYIELD") && (map.get("N_EFFYIELD")==null || map.get("N_EFFYIELD").toString().trim().length()==0)){
			map.put("N_EFFYIELD","0");
		}
		if(map.containsKey("N_USCR") && (map.get("N_USCR")==null || map.get("N_USCR").toString().trim().length()==0)){
			map.put("N_USCR","0");
		}
		
		//added by CVG as of 03-18-16
		
		if(map.containsKey("N_NOTARIAL") && (map.get("N_NOTARIAL")==null || map.get("N_NOTARIAL").toString().trim().length()==0)){
			map.put("N_NOTARIAL","0");
		}
		
		if(map.containsKey("N_EXTENSION") && (map.get("N_EXTENSION")==null || map.get("N_EXTENSION").toString().trim().length()==0)){
			map.put("N_EXTENSION","0");
		}
		
		return getSqlMapClientTemplate().update("updateClientTCInfo",map)>0;
	}
	
	public boolean updateClientFinanceInfo(Map map){

		if(map.containsKey("D_EFFDATE") && (map.get("D_EFFDATE")==null || map.get("D_EFFDATE").toString().trim().length()==0)){
			map.put("D_EFFDATE",null);
		}
		
		if(map.containsKey("D_CPDATE") && (map.get("D_CPDATE")==null || map.get("D_CPDATE").toString().trim().length()==0)){
			map.put("D_CPDATE",null);
		}
		
		if(map.containsKey("D_REVIEWDATE") && (map.get("D_REVIEWDATE")==null || map.get("D_REVIEWDATE").toString().trim().length()==0)){
			map.put("D_REVIEWDATE",null);
		}
		
		if(map.containsKey("D_AUDITEDDATE") && (map.get("D_AUDITEDDATE")==null || map.get("D_AUDITEDDATE").toString().trim().length()==0)){
			map.put("D_AUDITEDDATE",null);
		}
		
		if(map.containsKey("D_INHOUSEDATE") && (map.get("D_INHOUSEDATE")==null || map.get("D_INHOUSEDATE").toString().trim().length()==0)){
			map.put("D_INHOUSEDATE",null);
		}
		
		if(map.containsKey("N_LIABILITIES") && (map.get("N_LIABILITIES")==null || map.get("N_LIABILITIES").toString().trim().length()==0)){
			map.put("N_LIABILITIES",null);
		}
		if(map.containsKey("N_EQUITY") && (map.get("N_EQUITY")==null || map.get("N_EQUITY").toString().trim().length()==0)){
			map.put("N_EQUITY",null);
		}
		if(map.containsKey("N_GROSSINCOME") && (map.get("N_GROSSINCOME")==null || map.get("N_GROSSINCOME").toString().trim().length()==0)){
			map.put("N_GROSSINCOME",null);
		}
		if(map.containsKey("N_EXPENSES") && (map.get("N_EXPENSES")==null || map.get("N_EXPENSES").toString().trim().length()==0)){
			map.put("N_EXPENSES",null);
		}
		if(map.containsKey("N_NETINCOME") && (map.get("N_NETINCOME")==null || map.get("N_NETINCOME").toString().trim().length()==0)){
			map.put("N_NETINCOME",null);
		}
		if(map.containsKey("N_ASSETS") && (map.get("N_ASSETS")==null || map.get("N_ASSETS").toString().trim().length()==0)){
			map.put("N_ASSETS",null);
		}
		
		return getSqlMapClientTemplate().update("updateClientFinanceInfo",map)>0;
	}
	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateClientTransAmount(Map map){
		return getSqlMapClientTemplate().update("updateClientTransAmount",map)>0;
	}
	
	public boolean updateFIUTransAmount(Map map){
		return getSqlMapClientTemplate().update("updateFIUTransAmount",map)>0;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean deleteClient(String c_ClntCode) {
		return getSqlMapClientTemplate().delete("deleteClient", c_ClntCode) > 0;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////

	public List searchClientAutoComplete(Map map){		
		return getSqlMapClientTemplate().queryForList("searchClientAutoComplete",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public String searchClientResolveToCode(Map map){		
		return (String)getSqlMapClientTemplate().queryForObject("searchClientResolveToCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List checkClientExists(Map map){
		
		return getSqlMapClientTemplate().queryForList("checkClientExists",map);
	}

////////////////////////////////////////////////////////////////////////////////////////////// b_debit
	
	public String searchLastClientCode(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchLastClientCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchAccountClassificationList(Map map){
		
		log.debug("-->> searchAccountClassificationList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchAccountClassificationList",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchBorrowerTypeList(Map map){
		
		log.debug("-->> searchBorrowerTypeList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchBorrowerTypeList",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchAssetSizeList(Map map){
		
		log.debug("-->> searchAssetSizeList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchAssetSizeList",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchIndustryList(Map map){
		
		log.debug("-->> searchIndustryList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchIndustryList",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCurrencyListAjax(Map map){
		
		log.debug("-->> searchCurrencyListAjax DAO ....");
		return getSqlMapClientTemplate().queryForList("searchCurrencyListAjax",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchAccountOfficerList(Map map){
		
		log.debug("-->> searchAccountOfficerList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchAccountOfficerList",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchServiceOfficerList(Map map){
		
		log.debug("-->> searchServiceOfficerList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchServiceOfficerList",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	

	public List searchGroupList(Map map){
		
		log.debug("-->> searchGroupList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchGroupList",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	public List searchBankCustomerList(Map map){
		
		log.debug("-->> searchBankList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchBankCustomerList",map);
	}
	
	
	public List searchClientTransAmount(String c_ClntCode){	
		log.debug("searchClientTransAmount... ");
		return getSqlMapClientTemplate().queryForList("searchClientTransAmount",c_ClntCode);
	}
	
	public List searchClientNameByCode(String c_ClntCode){	
		log.debug("searchClientTransAmount... ");
		return getSqlMapClientTemplate().queryForList("searchClientNameByCode",c_ClntCode);
	}

	
	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsClientMasterList(String c_BranchCode){
		
		log.debug("-->> getTotalRecordsClientMasterList DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsClientMasterList", c_BranchCode);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchClientMasterList(Map map){
		
		log.debug("-->> searchClientMasterList DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchClientMasterList", map);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////		
		
	public List searchClientACStatus(Map map){
		
		log.debug("-->> searchClientACStatus DAO ....");
		return getSqlMapClientTemplate().queryForList("searchClientACStatus",map);
	}
	
	public String searchClientCurrency(String c_ClntCode) {
		return (String) getSqlMapClientTemplate().queryForObject("searchClientCurrency", c_ClntCode);
	}
	
	public double searchCALimit(Map map) {		
		return Double.parseDouble(getSqlMapClientTemplate().queryForObject("searchCALimit", map).toString());
	}
	
	public boolean updateIneligibleRecByClient(Map map) {
		return getSqlMapClientTemplate().update("updateIneligibleRecByClient", map) > 0;
	}
	
	public boolean updateDiscountCharge(Map map){
		return getSqlMapClientTemplate().update("updateDiscountCharge", map) > 0;
	}
	
	public boolean updateRateHistory(Map map){
		if(map.containsKey("N_PREVDC")&&map.get("N_PREVDC").toString().contentEquals("")){
			map.put("N_PREVDC", null);
		}
		if(map.containsKey("d_PrevBLRFrom")&&map.get("d_PrevBLRFrom").toString().contentEquals("")){
			map.put("d_PrevBLRFrom", null);
		}
		if(map.containsKey("d_PrevBLRTo")&&map.get("d_PrevBLRTo").toString().contentEquals("")){
			map.put("d_PrevBLRTo", null);
		}
		if(map.containsKey("n_BLRNo")&&map.get("n_BLRNo").toString().contentEquals("")){
			map.put("n_BLRNo", null);
		}
		if(map.containsKey("n_PrevValue")&&map.get("n_PrevValue").toString().contentEquals("")){
			map.put("n_PrevValue", null);
		}
		if(map.containsKey("n_CurValue")&&map.get("n_CurValue").toString().contentEquals("")){
			map.put("n_CurValue", null);
		}
		if(map.containsKey("d_CurBLRFrom")&&map.get("d_CurBLRFrom").toString().contentEquals("")){
			map.put("d_CurBLRFrom", null);
		}
		if(map.containsKey("d_CurBLRTo")&&map.get("d_CurBLRTo").toString().contentEquals("")){
			map.put("d_CurBLRTo", null);
		}

			
		return getSqlMapClientTemplate().update("updateRateHistory", map) > 0;
	}
	
	
	public double searchIneligibleRecByClient(String C_CLNTCODE){		
		log.debug("-->> searchRunningBalByClient DAO ....");		
		Map m = new HashMap();
		m.put("C_CLNTCODE", C_CLNTCODE);		
		String runningBalStr = (String) getSqlMapClientTemplate().queryForObject("searchIneligibleRecByClient",m);
		double ineligibleRec = runningBalStr != null ? Double.parseDouble(runningBalStr) : 0; 
		return ineligibleRec;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	/*
	 * Added by Jefferson M. Francisco Jr.
	 * 
	 * */
	
	@SuppressWarnings("unchecked")
	public List<ClientConcentration> getClientConcentration(String branchCode)
	{
		Map m = new HashMap();
		m.put("branchCode", branchCode);
		return getSqlMapClientTemplate().queryForList("getClientConcentration",m);
	}	
	
	@SuppressWarnings("unchecked")
	public int getClientConcentrationCount(String branchCode)
	{
		Map m = new HashMap();
		m.put("branchCode", branchCode);
		return (Integer)getSqlMapClientTemplate().queryForObject("getClientConcentrationCount", m);
	}
	/*
	 * end...
	 * */
	
	public boolean addClientInMonthlyDC(Map map){
		
		return getSqlMapClientTemplate().update("addClientInMonthlyDC",map)>0;
		
	}

	public List<Map> getClientSelect(){
		return (List<Map>)getSqlMapClientTemplate().queryForList("getClientSelect");
	}
	
	public ClientBean getClientByID(long  id){
		return (ClientBean)getSqlMapClientTemplate().queryForObject("getClientById",id);
	}
	
	public int checkIfClientNameExist(String clientName)
	{		
		return (Integer)getSqlMapClientTemplate().queryForObject("checkIfClientNameExist", clientName);
	}
	

public void TagClientRMU(Map data){
		getSqlMapClientTemplate().update("TagClientRMUUpdate",data);
	}
	
	public boolean GetClientStatus(String data){
		return (Boolean)getSqlMapClientTemplate().queryForObject("GetClientStatus",data);
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	// added 07182017 CVG 
	public List searchClientServiceFilteredAutoComplete(Map map){
	
	return getSqlMapClientTemplate().queryForList("searchClientServiceFilteredAutoComplete",map);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	public List searchClientRiskRatingList(Map map){
		log.info("-->> searchClientRiskRatingList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchClientRiskRatingList",map);
	}
	public List searchRPTClassificationList(Map map){
		log.info("-->> searchRPTClassificationList DAO ....");
		return getSqlMapClientTemplate().queryForList("searchRPTClassificationList",map);
	}
	public List getAllClient(String branchCode){
		Map m = new HashMap();
		m.put("branchcode", branchCode);
		log.info("-->> getAllClient DAO ...." + m.values());
		return getSqlMapClientTemplate().queryForList("getAllClient",m);
	}
	public String  searchClientNameByCodeString(String c_ClntCode){	
		log.debug("searchClientNameByCodeString... ");
		return (String) getSqlMapClientTemplate().queryForObject("searchClientNameByCodeString",c_ClntCode);
	}
}
