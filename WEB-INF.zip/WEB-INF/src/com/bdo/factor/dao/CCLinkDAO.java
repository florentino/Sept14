package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.CCLinkBean;


public class CCLinkDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(CCLinkDAO.class);
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCCLink(Map map){
		
		log.debug("-->> getCCLink DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchCCLink",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public List searchCCLinkByCode(Map map){
		
		log.debug("-->> searchCCLinkByCode DAO ....");
		return getSqlMapClientTemplate().queryForList("searchCCLinkByCode",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
public List searchClntCodeByCCLink(Map map){
		
		log.debug("-->> searchClntCodeByCCLink DAO ....");
		return getSqlMapClientTemplate().queryForList("searchClntCodeByCCLink",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addCCLink(Map map){
		log.debug("-->> addCCLink DAO CORRECT ....");
		
		
		if(map.containsKey("N_CLLIMIT") && (map.get("N_CLLIMIT")==null || map.get("N_CLLIMIT").toString().trim().length()==0)){
			map.put("N_CLLIMIT","0");
		}
		
		if(map.containsKey("N_DUNNING") && (map.get("N_DUNNING")==null || map.get("N_DUNNING").toString().trim().length()==0)){
			map.put("N_DUNNING","0");
		}
		
		if(map.containsKey("N_TERM") && (map.get("N_TERM")==null || map.get("N_TERM").toString().trim().length()==0)){
			map.put("N_TERM","0");
		}
		
		if(map.containsKey("N_CURINV") && (map.get("N_CURINV")==null || map.get("N_CURINV").toString().trim().length()==0)){
			map.put("N_CURINV","0");
		}
		
		if(map.containsKey("N_OVER30DAY") && (map.get("N_OVER30DAY")==null || map.get("N_OVER30DAY").toString().trim().length()==0)){
			map.put("N_OVER30DAY","0");
		}
		
		if(map.containsKey("N_OVER60DAY") && (map.get("N_OVER60DAY")==null || map.get("N_OVER60DAY").toString().trim().length()==0)){
			map.put("N_OVER60DAY","0");
		}
		
		if(map.containsKey("N_OVER90DAY") && (map.get("N_OVER90DAY")==null || map.get("N_OVER90DAY").toString().trim().length()==0)){
			map.put("N_OVER90DAY","0");
		}
		
		if(map.containsKey("N_OVER120DAY") && (map.get("N_OVER120DAY")==null || map.get("N_OVER120DAY").toString().trim().length()==0)){
			map.put("N_OVER120DAY","0");
		}
		
		if(map.containsKey("N_OVER150DAY") && (map.get("N_OVER150DAY")==null || map.get("N_OVER150DAY").toString().trim().length()==0)){
			map.put("N_OVER150DAY","0");
		}
		
		if(map.containsKey("N_OVER180DAY") && (map.get("N_OVER180DAY")==null || map.get("N_OVER180DAY").toString().trim().length()==0)){
			map.put("N_OVER180DAY","0");
		}
		
		
		if(map.containsKey("N_OVER210DAY") && (map.get("N_OVER210DAY")==null || map.get("N_OVER210DAY").toString().trim().length()==0)){
			map.put("N_OVER210DAY","0");
		}
		
		
		if(map.containsKey("N_CLLIMIT1") && (map.get("N_CLLIMIT1")==null || map.get("N_CLLIMIT1").toString().trim().length()==0)){
			map.put("N_CLLIMIT1","0");
		}
		
		if(map.containsKey("N_CCLIMIT") && (map.get("N_CCLIMIT")==null || map.get("N_CCLIMIT").toString().trim().length()==0)){
			map.put("N_CCLIMIT","0");
		}
		
		if(map.containsKey("N_CCLIMIT1") && (map.get("N_CCLIMIT1")==null || map.get("N_CCLIMIT1").toString().trim().length()==0)){
			map.put("N_CCLIMIT1","0");
		}
		
		if(map.containsKey("B_NLACT") && (map.get("B_NLACT")==null || map.get("B_NLACT").toString().trim().length()==0)){
			map.put("B_NLACT","0");
		}
		
		if(map.containsKey("B_TERMINATED") && (map.get("B_TERMINATED")==null || map.get("B_TERMINATED").toString().trim().length()==0)){
			map.put("B_TERMINATED","0");
		}
		
		if(map.containsKey("D_EXDATE") && (map.get("D_EXDATE")==null || map.get("D_EXDATE").toString().trim().length()==0)){
			map.put("D_EXDATE",null);
		}
		
		if(map.containsKey("D_CCAPDATE") && (map.get("D_CCAPDATE")==null || map.get("D_CCAPDATE").toString().trim().length()==0)){
			map.put("D_CCAPDATE",null);
		}
		
		if(map.containsKey("D_CCEXDATE") && (map.get("D_CCEXDATE")==null || map.get("D_CCEXDATE").toString().trim().length()==0)){
			map.put("D_CCEXDATE",null);
		}
		
		if(map.containsKey("D_CCAPDATE1") && (map.get("D_CCAPDATE1")==null || map.get("D_CCAPDATE1").toString().trim().length()==0)){
			map.put("D_CCAPDATE1",null);
		}	
		
		if(map.containsKey("D_CCEXDATE1") && (map.get("D_CCEXDATE1")==null || map.get("D_CCEXDATE1").toString().trim().length()==0)){
			map.put("D_CCEXDATE1",null);
		}
		
		if(map.containsKey("D_CREATEDATE") && (map.get("D_CREATEDATE")==null || map.get("D_CREATEDATE").toString().trim().length()==0)){
			map.put("D_CREATEDATE",null);
		}		
		
		if(map.containsKey("D_LASTUPDATEDATE") && (map.get("D_LASTUPDATEDATE")==null || map.get("D_LASTUPDATEDATE").toString().trim().length()==0)){
			map.put("D_LASTUPDATEDATE",null);
		}		
		
		return getSqlMapClientTemplate().update("addCCLink",map)>0;
	}
//////////////////////////////////////////////////////////////////////////////////////////////
	public boolean updatePaymentSchedule(Map map){
		
		
		return getSqlMapClientTemplate().update("updatePaymentSchedule",map)>0;
	}
	//////////////////////////////////////////////////////////////////////////////////////////
public boolean updateCollectionDetails(Map map){
		
		
		return getSqlMapClientTemplate().update("updateCollectionDetails",map)>0;
	}
//////////////////////////////////////////////////////////////////////////////////////////////
public boolean removePaymentSchedule(Map map){
		
		
		return getSqlMapClientTemplate().update("removeCustomerPaymentSchedule",map)>0;
	}
//////////////////////////////////////////////////////////////////////////////////////////////	
	public boolean updateCCLink(Map map){
		
		if(map.containsKey("N_CLLIMIT") && (map.get("N_CLLIMIT")==null || map.get("N_CLLIMIT").toString().trim().length()==0)){
			map.put("N_CLLIMIT","0");
		}
		
		if(map.containsKey("N_DUNNING") && (map.get("N_DUNNING")==null || map.get("N_DUNNING").toString().trim().length()==0)){
			map.put("N_DUNNING","0");
		}
		
		if(map.containsKey("N_TERM") && (map.get("N_TERM")==null || map.get("N_TERM").toString().trim().length()==0)){
			map.put("N_TERM","0");
		}
		
		if(map.containsKey("N_CURINV") && (map.get("N_CURINV")==null || map.get("N_CURINV").toString().trim().length()==0)){
			map.put("N_CURINV","0");
		}
		
		if(map.containsKey("N_OVER30DAY") && (map.get("N_OVER30DAY")==null || map.get("N_OVER30DAY").toString().trim().length()==0)){
			map.put("N_OVER30DAY","0");
		}
		
		if(map.containsKey("N_OVER60DAY") && (map.get("N_OVER60DAY")==null || map.get("N_OVER60DAY").toString().trim().length()==0)){
			map.put("N_OVER60DAY","0");
		}
		
		if(map.containsKey("N_OVER90DAY") && (map.get("N_OVER90DAY")==null || map.get("N_OVER90DAY").toString().trim().length()==0)){
			map.put("N_OVER90DAY","0");
		}
		
		if(map.containsKey("N_OVER120DAY") && (map.get("N_OVER120DAY")==null || map.get("N_OVER120DAY").toString().trim().length()==0)){
			map.put("N_OVER120DAY","0");
		}
		
		if(map.containsKey("N_OVER150DAY") && (map.get("N_OVER150DAY")==null || map.get("N_OVER150DAY").toString().trim().length()==0)){
			map.put("N_OVER150DAY","0");
		}
		
		if(map.containsKey("N_OVER180DAY") && (map.get("N_OVER180DAY")==null || map.get("N_OVER180DAY").toString().trim().length()==0)){
			map.put("N_OVER180DAY","0");
		}
		
		
		if(map.containsKey("N_OVER210DAY") && (map.get("N_OVER210DAY")==null || map.get("N_OVER210DAY").toString().trim().length()==0)){
			map.put("N_OVER210DAY","0");
		}
		
		
		if(map.containsKey("N_CLLIMIT1") && (map.get("N_CLLIMIT1")==null || map.get("N_CLLIMIT1").toString().trim().length()==0)){
			map.put("N_CLLIMIT1","0");
		}
		
		if(map.containsKey("N_CCLIMIT") && (map.get("N_CCLIMIT")==null || map.get("N_CCLIMIT").toString().trim().length()==0)){
			map.put("N_CCLIMIT","0");
		}
		
		if(map.containsKey("N_CCLIMIT1") && (map.get("N_CCLIMIT1")==null || map.get("N_CCLIMIT1").toString().trim().length()==0)){
			map.put("N_CCLIMIT1","0");
		}
		
		if(map.containsKey("B_NLACT") && (map.get("B_NLACT")==null || map.get("B_NLACT").toString().trim().length()==0)){
			map.put("B_NLACT","0");
		}
		
		if(map.containsKey("B_TERMINATED") && (map.get("B_TERMINATED")==null || map.get("B_TERMINATED").toString().trim().length()==0)){
			map.put("B_TERMINATED","0");
		}
		
		
		if(map.containsKey("D_EXDATE") && (map.get("D_EXDATE")==null || map.get("D_EXDATE").toString().trim().length()==0)){
			map.put("D_EXDATE",null);
		}
		
		if(map.containsKey("D_CCAPDATE") && (map.get("D_CCAPDATE")==null || map.get("D_CCAPDATE").toString().trim().length()==0)){
			map.put("D_CCAPDATE",null);
		}
		
		if(map.containsKey("D_CCEXDATE") && (map.get("D_CCEXDATE")==null || map.get("D_CCEXDATE").toString().trim().length()==0)){
			map.put("D_CCEXDATE",null);
		}
		
		if(map.containsKey("D_CCAPDATE1") && (map.get("D_CCAPDATE1")==null || map.get("D_CCAPDATE1").toString().trim().length()==0)){
			map.put("D_CCAPDATE1",null);
		}	
		
		if(map.containsKey("D_CCEXDATE1") && (map.get("D_CCEXDATE1")==null || map.get("D_CCEXDATE1").toString().trim().length()==0)){
			map.put("D_CCEXDATE1",null);
		}	
		
		if(map.containsKey("D_CREATEDATE") && (map.get("D_CREATEDATE")==null || map.get("D_CREATEDATE").toString().trim().length()==0)){
			map.put("D_CREATEDATE",null);
		}		
		
		if(map.containsKey("D_LASTUPDATEDATE") && (map.get("D_LASTUPDATEDATE")==null || map.get("D_LASTUPDATEDATE").toString().trim().length()==0)){
			map.put("D_LASTUPDATEDATE",null);
		}		
		
		return getSqlMapClientTemplate().update("updateCCLink",map)>0;
	}
	
	public double searchRunningBalByCustomer(String C_CLNTCODE, String C_CUSTCODE){		
		log.debug("-->> searchRunningBalByClient DAO ....");		
		Map m = new HashMap();
		m.put("C_CLNTCODE", C_CLNTCODE);
		m.put("C_CUSTCODE", C_CUSTCODE);
		String runningBalStr = (String) getSqlMapClientTemplate().queryForObject("searchRunningBalByClient",m);
		double runningBalance = runningBalStr != null ? Double.parseDouble(runningBalStr) : 0; 
		return runningBalance;
	}
	
	public boolean updateRunningBalByClient(Map map) {
		return getSqlMapClientTemplate().update("updateRunningBalByClient", map) > 0;
	}
	
	public boolean updateCustIneligible(Map map) {
		return getSqlMapClientTemplate().update("updateCustIneligible", map) > 0;
	}
	
	public boolean updateClientIneligible(Map map) {
		return getSqlMapClientTemplate().update("updateClientIneligible", map) > 0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
/*	
	public boolean deleteCCLink(String c_CCLinkCode){
		return getSqlMapClientTemplate().delete("deletCCLink",c_CCLinkCode)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
*/
	public double searchIneligibleByClient(Map m){		
		log.debug("-->> searchIneligibleByClient DAO ....");		
		//Map m = new HashMap();
		//m.put("C_CLNTCODE", C_CLNTCODE);		
		String runningBalStr = (String) getSqlMapClientTemplate().queryForObject("searchIneligibleByClient",m);
		double ineligibleRec = runningBalStr != null ? Double.parseDouble(runningBalStr) : 0; 
		return ineligibleRec;
	}
	
	public List<CCLinkBean> getCCLinkByClientCode(long id){
		return (List<CCLinkBean>) getSqlMapClientTemplate().queryForList("getCCLinkByClientId", id);
		
	}

}
