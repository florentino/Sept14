package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.SystemSettings;
import com.bdo.factor.service.AuditService;
import com.bdo.factor.util.ServiceUtility;

public class SystemSettingsDAO extends SqlMapClientDaoSupport
{
	private static Logger log = Logger.getLogger(SystemSettingsDAO.class);
	public SystemSettings getSystemSettings()
	{
		log.info("-->> get System Settings Correct....");
		SystemSettings s = (SystemSettings) getSqlMapClientTemplate().queryForObject("getSystemSettings");		
		return s;
	}
	
	public int getSystemSettingsCount()
	{		
		return (Integer) getSqlMapClientTemplate().queryForObject("getSystemSettingsCount");	
		
	}
	
	public List getSystemSetting()
	{
		log.debug("-->> getSystemSetting DAO ....");
		return getSqlMapClientTemplate().queryForList("getSystemSetting");
	}
	
	public String getSystemSettingsCurrency()
	{
		log.debug("-->> getSystemSettingCurrency DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getSystemSettingsCurrency");		
	}
	
	public boolean updateSystemSettings(Map systemSettings)
	{
		boolean retval = false;
		Map newData = new HashMap();
					
		if (getSystemSettingsCount() > 0)
		{
			retval = (getSqlMapClientTemplate().update("editSystemSettings", systemSettings) > 0);
			
			if(retval){
			
				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(systemSettings);
					SystemSettings st = new SystemSettings(newData);
					as.addAudit(newData.get("C_USERID").toString(),"U","SYSTEM-SETTINGS",st.toString());
	
				}catch(Throwable x){
					x.printStackTrace();
				}
			}
			
		}
		else
		{
			retval = (getSqlMapClientTemplate().update("addSystemSettings", systemSettings) > 0);
			
			if(retval){
				
				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(systemSettings);
					SystemSettings st = new SystemSettings(newData);
					as.addAudit(newData.get("C_USERID").toString(),"I","SYSTEM-SETTINGS",st.toString());
	
				}catch(Throwable x){
					x.printStackTrace();
				}
			}			
		}
		
		return  retval;
	}
	public boolean updateDefPassId(Map map)
	{
		boolean retval = false;
		retval = (getSqlMapClientTemplate().update("updateDefPassId", map) > 0);	
		return  retval;
	}
	
	public Boolean getIsCISAEnabled(){
		return (Boolean) getSqlMapClientTemplate().queryForObject("getIsCISAEnabled");
	}
}
