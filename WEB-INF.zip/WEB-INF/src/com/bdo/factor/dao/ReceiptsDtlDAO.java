package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class ReceiptsDtlDAO extends SqlMapClientDaoSupport{	
	
	private static Logger log = Logger.getLogger(ReceiptsDtlDAO.class);

	public boolean addReceiptsDtl(Map receiptsDtlForm){
		return getSqlMapClientTemplate().update("addReceiptsDetail",receiptsDtlForm)>0;
	}
	
	public String getTotalRecordsReceiptDetail(String n_RefNo){
		log.info("-->> searchReceiptsDetailByCode DAO ....");
		return (String) getSqlMapClientTemplate().queryForObject("getTotalRecordsReceiptDetail", n_RefNo);
	}
	
	public List searchReceiptsDetailByCode(Map map){
		
		log.info("-->> searchReceiptsDetailByCode DAO ....");
		return getSqlMapClientTemplate().queryForList("searchReceiptsDetailByCode",map);
	}
	
	public List searchReceiptsDetailByInvNo(Map map){	
		return getSqlMapClientTemplate().queryForList("searchReceiptsDetailByInvNo",map);
	}
	
	public int searchReceiptsDetailByInvoice(int n_RefNo, String c_InvoiceNo){
		Map map = new HashMap();
		map.put("N_REFNO", n_RefNo);
		map.put("C_INVOICENO", c_InvoiceNo);
		
		log.info("-->> searchReceiptsDetailByInvoice DAO ....");
		return Integer.parseInt((String) getSqlMapClientTemplate().queryForObject("searchReceiptsDetailByInvoice",map));
	}

	public int searchReceiptsDetailByInvoiceOnly(String c_InvoiceNo){
		Map map = new HashMap();
		map.put("C_INVOICENO", c_InvoiceNo);
		
		log.info("-->> searchReceiptsDetailByInvoiceOnly DAO ....");
		return Integer.parseInt((String) getSqlMapClientTemplate().queryForObject("searchReceiptsDetailByInvoiceOnly",map));
	}
	
	public boolean updateReceiptsDetail(Map receiptsDetailForm) {
		return getSqlMapClientTemplate().update("updateReceiptsDetail",receiptsDetailForm)>0;
	}
	
	public boolean updateCheckTypeByInvoiceNo(Map receiptsDetailForm) {
		return getSqlMapClientTemplate().update("updateCheckTypeByInvoiceNo",receiptsDetailForm)>0;
	}
	
	// added BY CVG as of 04-14-16 for Invoice Status (C_status / C_type) bug-------------------------
	public boolean updateStatusByInvoice(Map receiptsDetailForm) {
		return getSqlMapClientTemplate().update("updateStatusByInvoice",receiptsDetailForm)>0;
	}
	
	
	public boolean updateCheckTypeByInvoiceNoFullyPaidNew(Map receiptsDetailForm) {
		return getSqlMapClientTemplate().update("updateCheckTypeByInvoiceNoFullyPaidNew",receiptsDetailForm)>0;
	}

	//----------------------------------------------------------------------------------------------end
	
	
	public boolean updateCheckTypePartial(Map receiptsDetailForm) {
		return getSqlMapClientTemplate().update("updateCheckTypePartial",receiptsDetailForm)>0;
	}
	
	public boolean updateCheckTypeByInvoiceNoFullyPaid(Map receiptsDetailForm) {
		return getSqlMapClientTemplate().update("updateCheckTypeByInvoiceNoFullyPaid",receiptsDetailForm)>0;
	}
	
	public List searchReceiptsDetailByBatch(String n_RefNo){
		log.info("-->> searchReceiptsDetailByBatch DAO ....");
		return getSqlMapClientTemplate().queryForList("searchReceiptsDetailByBatch",n_RefNo);
	}
	
	public boolean updateReceiptDetailAmount(Map receiptDetailForm) {
		return getSqlMapClientTemplate().update("updateReceiptsDetailAmt", receiptDetailForm)>0;
	}
	
	public double getTotalReceiptAmount(Map receiptDetailForm) {
		return Double.parseDouble((String) getSqlMapClientTemplate().queryForObject("getTotalReceiptAmount", receiptDetailForm));
	}
	
	public double getTotalReceiptAmountWithCN(Map receiptDetailForm) {
		return Double.parseDouble((String) getSqlMapClientTemplate().queryForObject("getTotalReceiptAmountWithCN", receiptDetailForm));
	}
	
	public Boolean receiptsDetailFromTransaction(Map m){
		return getSqlMapClientTemplate().update("receiptsDetailFromTransaction", m)>0;
	}
	
	public double getLastPaymentAmount(String clntcode, String asOfDate ) {
		Map lastPayAmt = new HashMap();
		lastPayAmt.put("asOfDate", asOfDate);
		lastPayAmt.put("clntcode", clntcode);
		return (Double)getSqlMapClientTemplate().queryForObject("getLastPaymentAmount",lastPayAmt);
	}
	
}
