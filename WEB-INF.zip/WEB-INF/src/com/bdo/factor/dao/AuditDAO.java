package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.Audit;

public class AuditDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(AuditDAO.class);
	
	public List searchAudit(Map map){
		
		log.debug("-->> getAudit DAO CORRECT ....");		
		return getSqlMapClientTemplate().queryForList("searchAudit", map);
	}


//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public boolean addAudit(Audit audit){
		try {		
			getSqlMapClientTemplate().insert("addAudit",audit);
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateAudit(Audit audit){
		return getSqlMapClientTemplate().update("updateAudit",audit)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteAudit(Audit audit){
		return getSqlMapClientTemplate().delete("deleteAudit",audit)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsAudit(Map map){
		
		log.debug("-->> getTotalRecordsAudit DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsAudit",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
}
