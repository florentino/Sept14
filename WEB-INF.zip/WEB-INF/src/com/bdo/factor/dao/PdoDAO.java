package com.bdo.factor.dao;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class PdoDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(ActivityLogDAO.class);

	public String countPDO(Map map){
		return (String)getSqlMapClientTemplate().queryForObject("countPDO");
	}
	
	public List getPDO(Map map){
		return getSqlMapClientTemplate().queryForList("getPDO",map);
	}		
}
