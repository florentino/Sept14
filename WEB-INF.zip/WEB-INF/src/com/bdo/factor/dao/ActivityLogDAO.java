package com.bdo.factor.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class ActivityLogDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(ActivityLogDAO.class);


//////////////////////////////////////////////////////////////////////////////////////////////

	public List getListActivityLog(Map map){
		return getSqlMapClientTemplate().queryForList("getListActivityLog",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean doInsertActivityLog(Map map){
		return getSqlMapClientTemplate().update("doInsertActivityLog",map)>0;
	}
//////////////////////////////////////////////////////////////////////////////////////////////
	
}