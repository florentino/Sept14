package com.bdo.factor.dao;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.BLR;

public class BLRDAO  extends SqlMapClientDaoSupport{
	
	public String countBLRGrid(Map m) {
		 return (String) getSqlMapClientTemplate().queryForObject("countBLRGrid",m);
	}

	 
	public List getBLRGrid(Map m) {
		return  getSqlMapClientTemplate().queryForList("getBLRGrid",m);
	}
	public Long createBLR(BLR m) {
		try{
			return (Long) getSqlMapClientTemplate().insert("createBLR",m);
		}
		catch(Exception e){
			e.printStackTrace();
			return  (long) 0;
		}
		
	}
	
	public BLR readBLR(Long refNo){
		return (BLR)getSqlMapClientTemplate().queryForObject("readBLRByRefNo", refNo);
	}
	
	public Boolean updateBLR(BLR blr){
		try{
			getSqlMapClientTemplate().update("editBLR",blr);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	public BLR getPreviousRate(BLR blr){
		return (BLR)getSqlMapClientTemplate().queryForObject("getPreviousRate", blr);
	}
	 
	
	public List<BLR> readBLRGeneric(Map blrData){
		return getSqlMapClientTemplate().queryForList("readBLRGeneric", blrData);
	}
	
	public Integer getBLRConflict(BLR blr){
		Integer conflictCount = 0;
		conflictCount =   (Integer) getSqlMapClientTemplate().queryForObject("getBLRConflict",blr,Integer.class); 
		if(conflictCount==null || conflictCount==0){
			return 0;
		}else
			return conflictCount;
		
	}
	
}
