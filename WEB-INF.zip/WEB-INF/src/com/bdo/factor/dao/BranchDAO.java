package com.bdo.factor.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.Branch;
import com.bdo.factor.beans.User;

public class BranchDAO extends SqlMapClientDaoSupport{
	private static Logger log = Logger.getLogger(BranchDAO.class);
	
	
	public List searchBranch(Map map){
		
		log.debug("-->> getBank DAO CORRECT ....");
		return getSqlMapClientTemplate().queryForList("searchBranch", map);
	}

	
	
	public String searchBranchByCode(String c_BrCode){
		
		log.debug("-->> getBranch DAO CORRECT ....");
		HashMap m = new HashMap();
		m.put("brcode", c_BrCode);		
				
		String branch = (String) getSqlMapClientTemplate().queryForObject("searchBranchByCode", m);
		return branch;
	}
	
	public List searchBranchByCodeAComplete(String c_BrCode){
		
		log.debug("-->> getBranch DAO CORRECT ....");
		HashMap m = new HashMap();
		m.put("brcode", c_BrCode);		
				
		List branch = (List) getSqlMapClientTemplate().queryForObject("searchBranchByCodeAComplete", m);
		return branch;
	}

public List searchBranchList(Map m){
		
		log.debug("-->> getBranch DAO CORRECT ....");	
		
		return getSqlMapClientTemplate().queryForList("searchBranchList", m);
	}
	
	public String searchBranchCodeByName(Map map){
		
		return (String)getSqlMapClientTemplate().queryForObject("searchBranchCodeByName",map);
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean addBranch(Map branch){
		return getSqlMapClientTemplate().update("addBranch",branch)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean updateBranch(Map branch){
		return getSqlMapClientTemplate().update("updateBranch",branch)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean deleteBranch(Map branch){
		return getSqlMapClientTemplate().delete("deleteBranch",branch)>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getTotalRecordsBranch(){
		
		log.debug("-->> getTotalRecordsBranch DAO ....");
		return (String)getSqlMapClientTemplate().queryForObject("getTotalRecordsBranch");
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchBranchAutoComplete(Map map){
		
		return getSqlMapClientTemplate().queryForList("searchBranchAutoComplete",map);
	}
	
	public List getListBranch(Map map)
	{
		return getSqlMapClientTemplate().queryForList("listBranch", map);
	}
}



