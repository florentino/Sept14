package com.bdo.factor.dao;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.ReceiptsDtlOther;
import com.bdo.factor.beans.SystemSettings;

public class ReceiptsDtlOtherDAO extends SqlMapClientDaoSupport
{
	private static Logger log = Logger.getLogger(ReceiptsDtlOtherDAO.class);
	 
	public String insertReceiptsDtlOther(ReceiptsDtlOther m) {
		 return (String) getSqlMapClientTemplate().insert("insertReceiptsDtlOther",m);
	}
	
	public Double sumAllDtlOther(Long refNo){
		Double sum = (Double)getSqlMapClientTemplate().queryForObject("sumAllDtlOther",refNo);
		return sum!=null?sum:0.00;
	}
	
	public Double sumAllDtlOtherDC(Long refNo){
		Double sum = (Double)getSqlMapClientTemplate().queryForObject("sumAllDtlOtherDC",refNo);
		return sum!=null?sum:0.00;
	}
	public Double sumAllDtlOtherPenalty(Long refNo){
		Double sum = (Double)getSqlMapClientTemplate().queryForObject("sumAllDtlOtherPenalty",refNo);
		return sum!=null?sum:0.00;
	}
}
