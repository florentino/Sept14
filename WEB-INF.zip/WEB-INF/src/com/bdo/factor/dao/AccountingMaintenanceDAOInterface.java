package com.bdo.factor.dao;

import java.util.List;
import java.util.Map;

public interface AccountingMaintenanceDAOInterface {
	
	//CHART OF ACCOUNTS 
	public String countChartOfAccount(Map m);
	public List getChartOfAccount(Map m);
	public Boolean addChartOfAccount(Map m);
	public Boolean deleteChartOfAccount(Map m);
	public Boolean editChartOfAccount(Map m);
	public Map getChart(String m);
	public List<Map> getChartList();
	public List getGLList();
	public Double getAmount(String GLCode);
	public Boolean checkGLDuplicate(String GLCode);
	
	//COST CENTER
	public String countCostCenter(Map m);
	public List getCostCenter(Map m);
	public Boolean addCostCenter(Map m);
	public Boolean editCostCenter(Map m);
	public Boolean deleteCostCenter(Map m);
	//removed the map in List<Map>
	public List<Map> getCostCenterList();
	public Boolean checkCostCenterDuplicate(String N_CODE);
	
	//PENALTY CHARGE
	public String countPenaltyCharge(Map m);
	public List getPenaltyCharge(Map m);
	public Boolean addPenalty(Map m);
	
	//ACCOUNTING UTILS
	public Long getClientCode(Map m);
	public Boolean saveTransactionRate(Map m);
	public Object queryForObject(String sql);
}
