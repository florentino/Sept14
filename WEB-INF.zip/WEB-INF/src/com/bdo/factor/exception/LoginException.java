package com.bdo.factor.exception;

public class LoginException {

}
