package com.bdo.factor.exception;

public class FactorsFormatException extends Exception{

	public FactorsFormatException (String message){
		super(message);
	}
}
