package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.AccountForReview;
import com.bdo.factor.beans.ClientDebtTurn;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

public class AccountForReviewDAO extends JdbcDaoSupport{
	private Logger log = Logger.getLogger(AccountForReviewDAO.class);

	
	public List<AccountForReview> getAccountForReview(String startDate, String endDate, String branchCode){
		List<AccountForReview> lResult = new ArrayList<AccountForReview>();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		String sSQL = "select cc.c_name, cc.d_reviewdate, cc.n_investmentlimit, cc.n_receivables, " +
				"cc.c_custname, ao.c_name as aoName, cr.creditRiskDes " +
				"from cc left join accountofficer ao " +
				"on ao.c_acctofficercode = cc.c_acctofficercode " +
				"left join CREDITRISK cr " +
				"on cr.CreditRiskCd = cc.creditriskcd " +
				"where cc.d_reviewdate between '" + startDate + "' and '" + endDate + "' " +
				"and cc.c_branchcode = '" + branchCode + "' order by cc.c_name, cc.d_reviewdate";
		
		log.info(sSQL);
		
		lResult =getJdbcTemplate().query(sSQL, new RowMapper(){
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				AccountForReview afr = new AccountForReview();
				afr.setAccountOfficer(rs.getString("aoName"));
				afr.setClientName(rs.getString("c_name"));
				afr.setCpsClassification(rs.getString("creditRiskDes"));
				afr.setCustomerName(rs.getString("c_custname"));
				afr.setInvestmentLimit(rs.getDouble("n_investmentlimit"));
				afr.setOutstandingAR(rs.getDouble("n_receivables"));
				afr.setReviewDate(rs.getDate("d_reviewDate"));
				afr.setCurrentDate(date.newDate()); //added by CVG 10/05/2016
				
				return afr;
			}			
		});
		
		return lResult;
	}
}
