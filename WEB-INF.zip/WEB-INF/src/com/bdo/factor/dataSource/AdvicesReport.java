package com.bdo.factor.dataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CC;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.util.Money;

public class AdvicesReport {
	
	private Date transactionDate;
	private String clientName;
	private String serviceOfficer;
	private String bankAccountNo; 
	private double amount;
	private double totalAmount;
	private String description;
	
	private String C_BANKACCOUNT;
	private String C_APPROVER;
	private String C_COMPANYNAME;
	private String C_BANKNAME;
	private String C_ADDRESS;
	private String C_CURRENCYCODE;
	
	private static Logger log = Logger.getLogger(AdvicesReport.class);

	public AdvicesReport(){
		
	}
	
	public AdvicesReport(Date transactionDate,String clientName,String serviceOfficer,String bankAccountNo,double amount) {
		this.transactionDate	=	transactionDate;
		this.clientName 		= 	clientName;
		this.serviceOfficer 	=	serviceOfficer;
		this.bankAccountNo 		= 	bankAccountNo;
		this.amount				=	amount;
	}
	
	
	
	public List<AdvicesReport> getAllAdvices(CC cc,String option){
		List<AdvicesReport> list = new ArrayList<AdvicesReport>();
		String sSQL="";
		if(option.equalsIgnoreCase("Advances")){
				sSQL=	" SELECT DISTINCT " +
						"					  Advances.N_REFNO, Advances.C_CLNTCODE, dbCIF.dbo.Client.C_NAME AS clientName, Advances.N_ADVAMT AS amount, " + 
						"					  dbCIF.dbo.Client.C_BNKACTNO AS bankAccountNo, ServiceOfficer.C_NAME AS serviceOfficer, dbCIF.dbo.Client.C_BRANCHCODE, " + 
						"					  Advances.D_TRANSACTIONDATE AS transactionDate, Advances.C_TYPE, Advances.C_STATUS,'Advances' AS description " +
						" FROM         Advances INNER JOIN " +
						"					  Invoice ON Invoice.C_BRANCHCODE = Advances.C_BRANCHCODE AND Invoice.N_ADVREFNO = Advances.N_REFNO LEFT OUTER JOIN " +
						"					  dbCIF.dbo.Client ON Advances.C_BRANCHCODE = dbCIF.dbo.Client.C_BRANCHCODE AND " + 
						"					  Advances.C_CLNTCODE = dbCIF.dbo.Client.C_CLNTCODE LEFT OUTER JOIN " +
						"					  ServiceOfficer ON dbCIF.dbo.Client.C_SERVICEOFFICERCODE = ServiceOfficer.C_SERVICEOFFICERCODE " +
						" WHERE     (Advances.C_TYPE = '1') AND (Advances.C_STATUS = '2') AND (Advances.C_BRANCHCODE = '"+cc.getBranchCode()+"') AND " + 
						"					  (Advances.D_TRANSACTIONDATE BETWEEN '"+cc.getStartDate()+"' AND '"+cc.getEndDate()+"') AND (ISNULL(Advances.B_PRINTED, 0) = 0) " +
						" GROUP BY Advances.N_REFNO, Advances.C_CLNTCODE, dbCIF.dbo.Client.C_NAME, Advances.N_ADVAMT, dbCIF.dbo.Client.C_BNKACTNO, " + 
						"					  ServiceOfficer.C_NAME, dbCIF.dbo.Client.C_BRANCHCODE, Advances.D_TRANSACTIONDATE, Advances.C_TYPE, Advances.C_STATUS " +

						" ORDER BY clientName, transactionDate ";
		}
		else if(option.equalsIgnoreCase("Refund")){
				sSQL=	" SELECT DISTINCT       Refund.N_REFNO, Refund.C_CLNTCODE, dbCIF.dbo.Client.C_NAME AS clientName, Refund.N_REFAMT AS amount, " + 
						" 					  dbCIF.dbo.Client.C_BNKACTNO AS bankAccountNo, ServiceOfficer.C_NAME AS serviceOfficer, dbCIF.dbo.Client.C_BRANCHCODE, " +  
						" 					  Refund.D_TRANSACTIONDATE AS transactionDate, Refund.C_TYPE, Refund.C_STATUS,'Refund' AS description " + 
						" FROM          	      Refund " + 
						"			  LEFT OUTER JOIN " + 
						"					  dbCIF.dbo.Client ON Refund.C_BRANCHCODE = dbCIF.dbo.Client.C_BRANCHCODE AND " +  
						"					  Refund.C_CLNTCODE = dbCIF.dbo.Client.C_CLNTCODE " +  
						"			  LEFT OUTER JOIN " + 
						"					  ServiceOfficer ON dbCIF.dbo.Client.C_SERVICEOFFICERCODE = ServiceOfficer.C_SERVICEOFFICERCODE " + 
						" WHERE     (Refund.C_STATUS = '2') AND (Refund.C_BRANCHCODE = '"+cc.getBranchCode()+"') AND (Refund.D_TRANSACTIONDATE BETWEEN " +  
						"					  '"+cc.getStartDate()+"' AND '"+cc.getEndDate()+"') AND (ISNULL(Refund.B_PRINTED, 0) = 0) " + 
						" GROUP BY Refund.N_REFNO, Refund.C_CLNTCODE, dbCIF.dbo.Client.C_NAME, Refund.N_REFAMT, dbCIF.dbo.Client.C_BNKACTNO, " +  
						"					  ServiceOfficer.C_NAME, dbCIF.dbo.Client.C_BRANCHCODE, Refund.D_TRANSACTIONDATE, Refund.C_TYPE, Refund.C_STATUS " + 
						" ORDER BY clientName, transactionDate ";			
		}
		else if(option.equalsIgnoreCase("Advances and Refunds")){
			sSQL=		" SELECT DISTINCT " +
						"					  Advances.N_REFNO, Advances.C_CLNTCODE, dbCIF.dbo.Client.C_NAME AS clientName, Advances.N_ADVAMT AS amount, " + 
						"					  dbCIF.dbo.Client.C_BNKACTNO AS bankAccountNo, ServiceOfficer.C_NAME AS serviceOfficer, dbCIF.dbo.Client.C_BRANCHCODE, " + 
						"					  Advances.D_TRANSACTIONDATE AS transactionDate, Advances.C_TYPE, Advances.C_STATUS, 'Advances' AS description " +
						" FROM         Advances INNER JOIN " +
						"					  Invoice ON Invoice.C_BRANCHCODE = Advances.C_BRANCHCODE AND Invoice.N_ADVREFNO = Advances.N_REFNO LEFT OUTER JOIN " +
						"					  dbCIF.dbo.Client ON Advances.C_BRANCHCODE = dbCIF.dbo.Client.C_BRANCHCODE AND " + 
						"					  Advances.C_CLNTCODE = dbCIF.dbo.Client.C_CLNTCODE LEFT OUTER JOIN " +
						"					  ServiceOfficer ON dbCIF.dbo.Client.C_SERVICEOFFICERCODE = ServiceOfficer.C_SERVICEOFFICERCODE " +
						" WHERE     (Advances.C_TYPE = '1') AND (Advances.C_STATUS = '2') AND (Advances.C_BRANCHCODE = '"+cc.getBranchCode()+"') AND (Advances.D_TRANSACTIONDATE BETWEEN " + 
						"					  '"+cc.getStartDate()+"' AND '"+cc.getEndDate()+"') AND (ISNULL(Advances.B_PRINTED, 0) = 0) " +
						" UNION " +
						" SELECT DISTINCT       Refund.N_REFNO, Refund.C_CLNTCODE, dbCIF.dbo.Client.C_NAME AS clientName, Refund.N_REFAMT AS amount, " + 
						"					  dbCIF.dbo.Client.C_BNKACTNO AS bankAccountNo, ServiceOfficer.C_NAME AS serviceOfficer, dbCIF.dbo.Client.C_BRANCHCODE, " + 
						"					  Refund.D_TRANSACTIONDATE AS transactionDate, Refund.C_TYPE, Refund.C_STATUS, 'Refund' AS description " +
						" FROM          	      Refund " +
						"			  LEFT OUTER JOIN " +
						"					  dbCIF.dbo.Client ON Refund.C_BRANCHCODE = dbCIF.dbo.Client.C_BRANCHCODE AND " + 
						"					  Refund.C_CLNTCODE = dbCIF.dbo.Client.C_CLNTCODE " + 
						"			  LEFT OUTER JOIN " +
						"					  ServiceOfficer ON dbCIF.dbo.Client.C_SERVICEOFFICERCODE = ServiceOfficer.C_SERVICEOFFICERCODE " +
						" WHERE     (Refund.C_STATUS = '2') AND (Refund.C_BRANCHCODE = '"+cc.getBranchCode()+"') AND (Refund.D_TRANSACTIONDATE BETWEEN " + 
						"					  '"+cc.getStartDate()+"' AND '"+cc.getEndDate()+"') AND (ISNULL(Refund.B_PRINTED, 0) = 0) " +
						" ORDER BY transactionDate,clientName ";			
		}		
		
		log.info("getAllAdvices operation("+option+") with SQL: " +sSQL);
		PreparedStatement pstmt=null;
		PreparedStatement pstmt2=null;
		Connection conn = null;
		FactorConnection factor = new FactorConnection();
		conn = factor.getConnection();
		try{
			pstmt = new FactorConnection().getConnection().prepareStatement(sSQL);
			ResultSet rs = pstmt.executeQuery();
			double total = 0;
			String key = "";
			int ctr =0;
			String sSQL2="";
			while(rs.next()){
				AdvicesReport ar = new AdvicesReport();
				ar.setTransactionDate(rs.getDate("transactionDate"));
				ar.setClientName(rs.getString("clientName"));
				ar.setServiceOfficer(rs.getString("serviceOfficer"));
				ar.setBankAccountNo(rs.getString("bankAccountNo"));
				ar.setAmount(rs.getDouble("amount"));
				//ar.setAmount(rs.getDouble("amount"));
				log.info("Advances Amount" + rs.getDouble("amount"));
				ar.setDescription(rs.getString("description"));
				total +=ar.getAmount();
				log.info("Total: " + total);
				
				list.add(ar);
				if(option.equalsIgnoreCase("Advances and Refunds")){
					log.info("updating b_printed=> "+"UPDATE "+rs.getString("description").trim()+" SET B_PRINTED=1 WHERE N_REFNO = "+rs.getString(1)+"");
					pstmt2 = conn.prepareStatement("UPDATE "+rs.getString("description").trim()+" SET B_PRINTED=1 WHERE N_REFNO = "+rs.getString(1)+"");
					pstmt2.executeUpdate();					
				}
				else{
					if(ctr==0){
						key+=rs.getString(1);
					}
					else{
						key+=","+rs.getString(1);
					}
					ctr=ctr+1;
				}
			}
			if(ctr!=0 && !option.equalsIgnoreCase("Advances and Refunds")){
				log.info("Primary keys of "+option+" table to be update ("+key+") setting B_PRINTED=1");
				sSQL2="UPDATE "+option+" SET B_PRINTED=1 WHERE N_REFNO IN ("+key+")";
				log.info("sSQL2 of Advances and Refunds: "+sSQL2);
				pstmt2 = conn.prepareStatement(sSQL2);
				pstmt2.executeUpdate();
			}
			this.totalAmount=total;
			//this.totalAmount=Money.doRoundOff(total);
		}
		catch(Exception e){
			e.printStackTrace();
		}	
		
		return list;
	}




	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		CC cc = new CC();
		cc.setBranchCode("99");
		cc.setStartDate("01/01/2009");
		cc.setEndDate("12/01/2009");
		ListIterator li = new AdvicesReport().getAllAdvices(cc,"Advances and Refunds").listIterator();
		while(li.hasNext()){
			AdvicesReport ar = (AdvicesReport)li.next();
			log.info("Transaction Date: "+ar.getTransactionDate());
			log.info("Client Name: "+ar.getClientName());
			log.info("Service Officer: "+ar.getServiceOfficer());
			log.info("Bank Account: "+ar.getBankAccountNo());
			log.info("Bank Account: "+ar.getC_BANKACCOUNT());
			log.info("getC_BANKNAME: "+ar.getC_BANKNAME());
			log.info("ar.getDescription(): "+ar.getDescription());
		}
		// TODO Auto-generated method stub

	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setServiceOfficer(String serviceOfficer) {
		this.serviceOfficer = serviceOfficer;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public void setC_BANKACCOUNT(String c_bankaccount) {
		C_BANKACCOUNT = c_bankaccount;
	}

	public void setC_APPROVER(String c_approver) {
		C_APPROVER = c_approver;
	}

	public void setC_COMPANYNAME(String c_companyname) {
		C_COMPANYNAME = c_companyname;
	}

	public void setC_BANKNAME(String c_bankname) {
		C_BANKNAME = c_bankname;
	}

	public void setC_ADDRESS(String c_address) {
		C_ADDRESS = c_address;
	}

	public void setC_CURRENCYCODE(String c_currencycode) {
		C_CURRENCYCODE = c_currencycode;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public String getClientName() {
		return clientName;
	}

	public String getServiceOfficer() {
		return serviceOfficer;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public double getAmount() {
		return amount;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public String getC_BANKACCOUNT() {
		return C_BANKACCOUNT;
	}

	public String getC_APPROVER() {
		return C_APPROVER;
	}

	public String getC_COMPANYNAME() {
		return C_COMPANYNAME;
	}

	public String getC_BANKNAME() {
		return C_BANKNAME;
	}

	public String getC_ADDRESS() {
		return C_ADDRESS;
	}

	public String getC_CURRENCYCODE() {
		return C_CURRENCYCODE;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
