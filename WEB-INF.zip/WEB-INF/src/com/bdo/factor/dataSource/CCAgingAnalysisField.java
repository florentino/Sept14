/*@ Added by	: Roldan Somontina
 * 	Java Name	: VerifyInvoiceField.java
 * 	Date Added	: May 19, 2009
 *  Source Code for Invoice Due Report
 */ 

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dataSource.CCLinkDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

public class CCAgingAnalysisField extends CCLinkDAO implements JRDataSource{
	private static Logger log = Logger.getLogger(CCAgingAnalysisField.class);

	List cCLinkList= new ArrayList();	
	private int index =-1;
	private int lastIndex = 0;
	private double overallCurrent=0.00;
	private double overall1to30=0.00;
	private double overall31to60=0.00;
	private double overall61to90=0.00;
	private double overall91to120=0.00;
	private double overall121to150=0.00;
	private double overall151to180=0.00;
	private double overallOver180=0.00;
	private double overallTotalOS=0.00;
	

	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	//CCLinkDAO ccLinkDao = (CCLinkDAO)Persistence.getDAO("ccLinkDao");

	public CCAgingAnalysisField(CCLink ccLink,String operation){
		cCLinkList= getCustAgingAnalysis(ccLink,operation);
		lastIndex= cCLinkList.size()-1;
		log.info("(CCAgingAnalysisField)lastIndex=> "+lastIndex);
	}
	

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		CCLink cCLink = (CCLink)cCLinkList.get(index);
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		if(cCLinkList.size()>0 && index <lastIndex){
			if("clientName".equals(field)){   			
				value=cCLink.getClientName();
			}
			if("customerName".equals(field)){   			
				value=cCLink.getCustomerName();
			}
			if("fundLimit".equals(field)){   			
				value=cCLink.getFundLimit();
			}
			if("expiryDate".equals(field)){   			
				value=cCLink.getD_ExDate();
			}
			if("bNLAct".equals(field)){   			
				value=cCLink.getB_NLAct()==0?"y":"n";
			}
			if("nTerm".equals(field)){   			
				value=cCLink.getN_Term();
			}
			if("cDunning".equals(field)){   			
				value=cCLink.getC_Dunning();
			}			
			if("nCurrent".equals(field)){   			
				value=cCLink.getN_Current();
			}			
			if("n1to30".equals(field)){   			
				value=cCLink.getN_1to30();
			}
			if("n31to60".equals(field)){   			
				value=cCLink.getN_31to60();
			}
			if("n61to90".equals(field)){   			
				value=cCLink.getN_61to90();
			}
			if("n91to120".equals(field)){   			
				value=cCLink.getN_91to120();
			}
			if("n121to150".equals(field)){   			
				value=cCLink.getN_121to150();
			}
			if("n151to180".equals(field)){   			
				value=cCLink.getN_151to180();
			}
			if("nOver180".equals(field)){   			
				value=cCLink.getN_Over180();
			}
			if("nTotalOS".equals(field)){   			
				value=cCLink.getN_TotalOS();
			}
			if("unapprovedRec".equals(field)){   			
				value=cCLink.getUnapprovedReceivables();
			}			
		}
		if("currentDate".equals(field)){   			
			value=date.newDate();
		}	
		boolean test = index<lastIndex;
		String strArray = (String)cCLinkList.get(lastIndex);
		String[] str = strArray.split("@");
		if(test){			
			if("overallCurrent".equals(field)){   			
				value=str[0];
			}
			if("overall1to30".equals(field)){   			
				value=str[1];
			}
			if("overall31to60".equals(field)){   			
				value=str[2];
			}
			if("overall61to90".equals(field)){   			
				value=str[3];
			}			
			if("overall91to120".equals(field)){   			
				value=str[4];
			}
			if("overall121to150".equals(field)){   			
				value=str[5];
			}	
			if("overall151to180".equals(field)){   			
				value=str[6];
			}
			if("overallOver180".equals(field)){   			
				value=str[7];
			}
			if("overallTotalOS".equals(field)){   			
				value=str[8];
			}			
		}
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
