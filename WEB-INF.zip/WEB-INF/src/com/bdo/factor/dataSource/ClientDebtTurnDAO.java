package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.Audit;
import com.bdo.factor.beans.ClientDebtTurn;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

public class ClientDebtTurnDAO extends JdbcDaoSupport {
	private Logger log = Logger.getLogger(ClientDebtTurnDAO.class);
	
	public List<ClientDebtTurn> getClientDebtTurn(String clientCode, String customerCode, String status, String startDate, String endDate){
		List<ClientDebtTurn> list= new ArrayList<ClientDebtTurn>();
		List<ClientDebtTurn> lResult = new ArrayList<ClientDebtTurn>();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");		
		double totalAverage = 0;
		double totalInvoice = 0;
		double dunning = 0;
		
		String sSQL = "select 	Invoice.C_INVOICENO, sum(Invoice.n_invoiceAmt) as n_invoiceAmt," +
				"Invoice.D_INVOICEDATE, Invoice.D_FULLYPAIDDATE, (datediff(dd,invoice.d_invoicedate, invoice.d_fullypaiddate) + 1) as speedpaid," +
				"datename(mm,invoice.d_fullypaiddate) as monthpaid, (invoice.n_invoiceamt * (datediff(dd,invoice.d_invoicedate, invoice.d_fullypaiddate) + 1)) as averageAmount," +
				"(invoice.n_invoiceamt - IsNull(SUM(CreditNote.N_AMOUNT),0)) as amountCollected, " +
				"AccountOfficer.C_NAME as aoName, CC.C_NAME, CC.C_CUSTNAME, Isnull(sum(creditnote.n_amount),0) as cnamount " +
				"from Invoice " +
				"inner JOIN CC ON Invoice.C_BRANCHCODE = CC.C_BRANCHCODE " +
				"AND Invoice.C_CUSTCODE = CC.C_CUSTCODE " +
				"AND Invoice.C_CLNTCODE = CC.C_CLNTCODE " +
				"inner JOIN AccountOfficer ON Invoice.C_BRANCHCODE = AccountOfficer.C_BRANCHCODE " +
				"and CC.C_ACCTOFFICERCODE = AccountOfficer.C_ACCTOFFICERCODE " +
				"left join creditnote on Invoice.C_BRANCHCODE = CreditNote.C_BRANCHCODE " +
				"AND Invoice.C_CLNTCODE = CreditNote.C_CLNTCODE " +
				"AND Invoice.C_CUSTCODE = CreditNote.C_CUSTCODE AND CreditNote.C_INVOICENO = Invoice.C_INVOICENO " +
				"where (Invoice.C_STATUS IN ('5', '6')) AND (invoice.c_custcode = '" + customerCode + "') " +
				"AND (invoice.c_clntcode = '" + clientCode + "') AND (invoice.d_invoicedate between '" + startDate + "' and '" + endDate + "') " +
				"group by invoice.c_invoiceno, invoice.d_invoicedate, invoice.d_fullypaiddate, invoice.n_invoiceamt," +
				"accountofficer.c_name, cc.c_name, cc.c_custname " +
				"ORDER BY invoice.d_fullypaiddate";
		
		log.info(sSQL);
		list =getJdbcTemplate().query(sSQL, new RowMapper(){
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				ClientDebtTurn cbt = new ClientDebtTurn();
				cbt.setAccountOfficer(rs.getString("aoName"));
				cbt.setAmount(rs.getDouble("n_invoiceAmt"));
				cbt.setAmountCollected(rs.getDouble("amountCollected"));
				cbt.setAverage(rs.getDouble("averageAmount"));
				cbt.setClientName(rs.getString("C_Name"));
				cbt.setCustomerName(rs.getString("C_CUSTNAME"));
				cbt.setDatePaid(rs.getDate("D_FullyPaidDate"));
				cbt.setInvoiceDate(rs.getDate("D_InvoiceDate"));
				cbt.setInvoiceNo(rs.getString("C_invoiceNo"));
				cbt.setMonthPaid(rs.getString("monthpaid"));
				cbt.setSpeedPaid(rs.getInt("speedpaid"));				
				cbt.setCurrentDate(date.newDate());
				return cbt;
			}			
		});
		
		for (Iterator<ClientDebtTurn> i = list.iterator( ); i.hasNext( ); ) {
			ClientDebtTurn cbt = i.next();
			log.info("CBT:" + cbt.toString());
			totalAverage = cbt.getAverage() + totalAverage;
			totalInvoice = cbt.getAmount() + totalInvoice;
		}		
		
		dunning = totalAverage / totalInvoice;
				
		for (Iterator<ClientDebtTurn> i = list.iterator( ); i.hasNext( ); ) {
			ClientDebtTurn cbt = i.next();
			cbt.setTotalAverage(totalAverage);
			cbt.setTotalInv(totalInvoice);
			cbt.setDunning(dunning);
			lResult.add(cbt);
			log.info("CBT2:" + cbt.toString()); 
		}
		
		return lResult;
	}
		
}
