package com.bdo.factor.dataSource;

import com.bdo.factor.beans.FactoringStatistics;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRException;

import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

public class FactoringStatsFields implements JRDataSource 
{
	
	List<FactoringStatistics> factoringStatsList = new ArrayList<FactoringStatistics>();
	private int index                            = -1;
	private int lastIndex                        = 0;	
	private String userId                        = "";
	private String branchName                    = "";
	private Date asOfMonth                     = null;
	public FactoringStatsFields(String branchCode, String clientCode, String monthYear) 
	{
		this.setAsOfMonth(monthYear);
		FactoringStatsDAO factoringStatsDAO = (FactoringStatsDAO)Persistence.getDAO("factoringStatsDao");
		factoringStatsList = factoringStatsDAO.getFactoringStatsDao(branchCode, clientCode, monthYear);
		setLastIndex(factoringStatsList.size());
	}

	@Override
	public Object getFieldValue(JRField jrField) throws JRException 
	{
		Object value = null; 
		String field = jrField.getName();
		FactoringStatistics factoringStats = (FactoringStatistics)factoringStatsList.get(index);
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		//MonthName,currInvoice,prevInvoice,prevCollection,currCollection,currFIU,prevFIU,clientName,SystemName
		if (getLastIndex() > 0)
		{
			if ("MonthName".equals(field))
			{
				value = factoringStats.getMonthName();
			}
			if ("currInvoice".equals(field))
			{
				value = factoringStats.getCurrInvoiceAmt();
			}
			if ("prevInvoice".equals(field))
			{
				value = factoringStats.getPrevInvoiceAmt();
			}
			if ("prevCollection".equals(field))
			{
				value = factoringStats.getPrevCollection();
			}
			if ("currCollection".equals(field))
			{
				value = factoringStats.getCurrCollection();
			}
			if ("currFIU".equals(field))
			{
				value = factoringStats.getCurrFIU();
			}
			if ("prevFIU".equals(field))
			{
				value = factoringStats.getPrevFIU();
			}
			if ("serviceOfficerName".equals(field))
			{
				value = factoringStats.getServiceOfficerName();
			}
		}
		
		if ("clientName".equals(field))
		{
			value = factoringStats.getClientName();
		}		
		if ("userName".equals(field))
		{
			value = this.getUserId();
		}
		if ("branchName".equals(field))
		{
			value = this.getBranchName();
		}
		if ("monthYear".equals(field))
		{
			value = "as of " + this.getAsOfMonth();
		}
		
		if("currentDate".equals(field)){
			value = date.newDate();
		}
		return value;
	}

	private int getLastIndex() {
		return lastIndex;
	}

	private void setLastIndex(int lastIndex) {
		this.lastIndex = lastIndex;
	}

	@Override
	public boolean next() throws JRException 
	{		
		index ++;
        if(index<lastIndex)
        {
            return true;
        }
        return false;
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	private void setAsOfMonth(String asofmonth)
	{
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		sdf.setLenient(false);
		//Date dateToParse = null;
		try 
		{
			this.asOfMonth = sdf.parse(asofmonth);
		} catch (ParseException e) 
		{		
			e.printStackTrace();
		}		
	}
	private String getAsOfMonth()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("MMMMM yyyy");
		sdf.setLenient(false);		
		return sdf.format(this.asOfMonth);
	}
	
}
