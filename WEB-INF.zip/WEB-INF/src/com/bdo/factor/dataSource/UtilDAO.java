
package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.util.FactorConnection;
public class UtilDAO extends JdbcDaoSupport 
{
	private static Logger log = Logger.getLogger(UtilDAO.class);

	public int getDailyReceiptsCount(String branchCode, String whereClause)//(String branchCode, String clientCodeClause)
	{
		int retval = 0;
		// redd 11/23/2010 - optimize use of string object in query, remove cross join  and change method arguments
		StringBuilder sSQL = new StringBuilder();
		sSQL.append(" SELECT COUNT(ReceiptsHdr.N_REFNO) AS cnt ")
			.append(" FROM ReceiptsHdr, ReceiptsDtl WHERE ")
			.append(" ReceiptsHdr.C_BRANCHCODE = '").append(branchCode).append("' ")
			.append(whereClause);
		log.info("[UtilDAO]->[methodName:getDailyReceiptsCount][param1: "+branchCode+", param2:" +whereClause+"] " +sSQL.toString());
		log.info(sSQL.toString());
		/*
		 * jeff code
		String sSQL =    "SELECT COUNT(ReceiptsHdr.N_REFNO) AS cnt " +
						  "FROM ReceiptsHdr CROSS JOIN ReceiptsDtl " + 
						  "ReceiptsHdr.C_BRANCHCODE = ReceiptsDtl.C_BRANCHCODE AND " +
						  "ReceiptsHdr.C_BRANCHCODE = '"+branchCode+"' " +
						  "AND ReceiptsHdr.D_TRANSACTIONDATE BETWEEN '"+startDate+"' " + 
						  "AND '"+endDate+"' " + clientCodeClause;
		System.out.println("[UtilDAO]->[getDailyReceiptsCount][args1: "+branchCode+", args2:" +startDate+", args3: " + endDate + "][debug]: " +sSQL);				  
		*/
		retval = (Integer)getJdbcTemplate().queryForObject(sSQL.toString(), new RowMapper(){
					@Override 
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException{							
						return rs.getInt("cnt");							
					}
				}
			);
		return retval;
	}
	
	public int getTableRowCount(String sSQL, Map values)
	{
		int retval = 0;
		Iterator val = values.keySet().iterator();
		PreparedStatement ps = null;
		
		try {
			ps = new FactorConnection().getConnection().prepareStatement(sSQL);
			int index =1;
			while(val.hasNext()){
				ps.setObject(index, values.get(val.next()));
			}
			ResultSet rs = null;
			rs = ps.executeQuery();
			rs.next();
			retval = rs.getInt(1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//System.out.println("[UtilDAO]->[getTableRowCount][debug]: "+sSQL);
		
		
		
		/*retval = (Integer)getJdbcTemplate().queryForObject(sSQL, 
				new RowMapper()
				{
					@Override 
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{							
						return rs.getInt(1);							
					}
				}
			);	*/	
		
		return retval;
	}
	
	public int getDayDateDiff(String minDate,String maxDate){
		int returnValue=0;
		String sSQL = "SELECT DATEDIFF(DAY,'"+minDate+"','"+maxDate+"')";
		Statement stmt=null;
		ResultSet rs = null;
		try{
			stmt=new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			while(rs.next()){
				returnValue=rs.getInt(1);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return returnValue;
	}

	public int getCurrentYear(String dateEntered)
	{
		int retval = 0;
		
		String sSQL = "SELECT " +
					  "CASE WHEN (select month([currentdate]) FROM [factorsGetDate]) = MONTH('"+dateEntered+"') AND MONTH('"+dateEntered+"') = 1 THEN " + //before: month(getDate())
					  "		YEAR('"+dateEntered+"') - 1 " +
					  "ELSE " +
					  "		YEAR('"+dateEntered+"') " +
					  "END AS retval" ;
		Statement stmt;
		
		try 
		{
			stmt = new FactorConnection().getConnection().createStatement();
			ResultSet rs   = stmt.executeQuery(sSQL);
			if (rs.next())
			{
				retval = rs.getInt(1);
			}
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		return retval;
	}
	
	public int getCurrentMonth(String dateEntered)
	{
		String sSQL = "SELECT " + 
		
				      "CASE WHEN (select month([currentdate]) FROM [factorsGetDate]) = MONTH('"+dateEntered+"') THEN " +  //month(getdate())
		
				      "CASE WHEN MONTH('"+dateEntered+"') = 1 THEN " +
				      
				      "12 " +
				      
				      "WHEN MONTH('"+dateEntered+"') = 2 THEN " +
				      
				      "1 " +
				      
					  "WHEN MONTH('"+dateEntered+"') = 3 THEN " +
					  
					  "	2 " +
					  
					  "WHEN MONTH('"+dateEntered+"') = 4 THEN " +
					  
					  "	3 " +
					  
					  "WHEN MONTH('"+dateEntered+"') = 5 THEN " +
					  
					  "	4 " +
					  
					  "WHEN MONTH('"+dateEntered+"') = 6 THEN " +
					  
					  "	5 " +
					  
					  "WHEN MONTH('"+dateEntered+"') = 7 THEN " +
					  
					  "	6 " +
					  
					  "WHEN MONTH('"+dateEntered+"') = 8 THEN " +
					  
					  "	7 " +
					  
					  "WHEN MONTH('"+dateEntered+"') = 9 THEN " +
					  
					  "	8 " +
					  
					  "WHEN MONTH('"+dateEntered+"') = 10 THEN " +
					  
					  "	9 " +	
					  
					  "WHEN MONTH('"+dateEntered+"') = 11 THEN " +
					  
					  "	10 " +
					  
					  "WHEN MONTH('"+dateEntered+"') = 12 THEN " +
					  
					  "	11 " +		
					  
					  " END " +		
				 
					  "ELSE " + 
					  
					  "	MONTH('"+dateEntered+"') " + 
					  
					  "END AS retval " ;
		
		Statement stmt;
		
		try 
		{
			stmt = new FactorConnection().getConnection().createStatement();
			ResultSet rs   = stmt.executeQuery(sSQL);
			if (rs.next())
			{
				return rs.getInt(1);
			}
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		return 0;
	}
	
	public String getMonthName(int monthCode)
	{
		String retval = null;
		
		switch (monthCode)
		{
			case 1: retval = "January";
			break;
			
			case 2: retval = "February";
			break;
			
			case 3: retval = "March";
			break;
			
			case 4: retval = "April";
			break;
			
			case 5: retval = "May";
			break;
			
			case 6: retval = "June";
			break;
			
			case 7: retval = "July";
			break;
			
			case 8: retval = "August";
			break;
			
			case 9: retval = "September";
			break;
			
			case 10: retval = "October";
			break;
			
			case 11: retval = "November";
			break;
			
			case 12: retval = "December";
			break;			
		}
		
		return retval;
	}
	

	
	public static int getMonth(String date){
		int returnValue=0;
		String sSQL = "SELECT MONTH('"+date+"')";
		//Statement stmt=null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try{
			//stmt=new FactorConnection().getConnection().createStatement();
			pstmt=new FactorConnection().getConnection().prepareStatement(sSQL);
			rs = pstmt.executeQuery();
			while(rs.next()){
				returnValue=rs.getInt(1);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				//if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return returnValue;
	}
	
	public static int getListSize(String sSQL){
		int size=0;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try{
			pstmt=new FactorConnection().getConnection().prepareStatement(sSQL);
			rs = pstmt.executeQuery();
			while(rs.next()){
				size++;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				//if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return size;
	}	
	
	public static void main(String[] args){
		//UtilDAO util =(UtilDAO)Persistence.getDAO("utilDao");
		//log.info("datediff trial "+util.getDayDateDiff("01/01/2004", "02/01/2004"));
		//log.info("datediff trial "+getDayDateDiff("01/01/2004", "02/01/2004"));
		//log.info("month date trial "+getMonth("07/01/2004"));
		long l = 10;
		Double da = Double.parseDouble(new Long(l).toString());
		System.out.println("result da: " + da);
		
		
			double d = 14.4578;
			d = Math.round(d * 100);
			BigDecimal a = new BigDecimal(d);
			a= a.divide(new BigDecimal(100));
			double e = a.doubleValue();
			
			System.out.println("result a: " + a);
			d = d / 100;
			System.out.println("result: " + d);
		
	}
}
