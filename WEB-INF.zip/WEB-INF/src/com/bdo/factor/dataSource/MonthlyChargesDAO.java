package com.bdo.factor.dataSource;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.MonthlyCharges;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.FactorConnection;

public class MonthlyChargesDAO extends JdbcDaoSupport
{	
		
	@SuppressWarnings("unchecked")
	
	public List<MonthlyCharges> getMonthlyCharges(String branchCode, final String monthYear)
	{
		int asOfMonth = Integer.parseInt(monthYear.substring(0, 2));
		
		String sSQL = "SELECT I.C_CLNTCODE, C.C_NAME, C.C_CUSTNAME, AO.C_NAME as AO, ISNULL(SUM(D.N_DISCCHG),0) AS DCCOLLECTED, .00 AS DCACCRUAL, " +
		"SUM((I.N_INVOICEAMT * (C.N_SCR/100))) AS SERVICECHARGE " +
		"FROM INVOICE I " +
		"LEFT JOIN DISCDTL D ON I.N_INVNO = D.N_REFERENCE " + 
		"AND (D.D_TRANSACTIONDATE BETWEEN CONVERT(VARCHAR, CAST(MONTH('" + monthYear +"') AS NVARCHAR) " + 
		"+ '/01/' + CAST(YEAR('" + monthYear +"') AS NVARCHAR), 101) AND '" + monthYear +"') " +
		"INNER JOIN CC C ON I.C_CLNTCODE = C.C_CLNTCODE AND CLIENTSTATUS =1 " +
		"INNER JOIN ACCOUNTOFFICER AO ON C.C_ACCTOFFICERCODE = AO.C_ACCTOFFICERCODE " +
		" WHERE	(I.D_TRANSACTIONDATE BETWEEN CONVERT(VARCHAR, CAST(MONTH('" + monthYear +"') AS NVARCHAR) " + 
		" + '/01/' + CAST(YEAR('" + monthYear +"') AS NVARCHAR), 101) AND '" + monthYear +"')  " +
		" AND I.C_STATUS BETWEEN 2 AND 6 " +
		" GROUP BY I.C_CLNTCODE, C.C_NAME, C.C_CUSTNAME,AO.C_NAME ORDER BY C.C_NAME " ;

		
//		//modified 07/20/2010 
//		String sSQL = "SELECT " +  
//		  " ROUND(SUM(Case When MonthlyCharges.CashDelay IS NULL Then 0 Else MonthlyCharges.CashDelay End), 3) AS SumOfCashDelay, " +
//		  " ROUND(SUM(Case When MonthlyCharges.ServiceCharge IS NULL Then 0 Else MonthlyCharges.ServiceCharge End), 3) AS SumOfServiceCharge, " +
//		  " ROUND((SUM(Case When MonthlyCharges.CashDelay IS NULL Then 0 Else MonthlyCharges.CashDelay End) +  " + 
//		  " SUM(Case When MonthlyCharges.ServiceCharge IS NULL Then 0 Else MonthlyCharges.ServiceCharge End)), 3) AS TotalCharges, " + 
//		  " CC.C_CLNTCODE " +  
//
//		  " FROM (select c_clntcode, c_status as clientstatus from dbcif.dbo.client) as CC left JOIN ( " +
//		  			" SELECT " +
//		  			" r.C_CLNTCODE, " +
//		  			"CASE WHEN r.N_AMOUNT < r.N_TOTINVAMT THEN "+  
//		  			 
//		            "r.N_AMOUNT " + 
//		            "* " + 
//		            "((((dbo.GetBLR(r.C_CLNTCODE, '"+monthYear+"') " + 
//		            "+ "+  
//		            "(c.N_DCR/100))) / 360) * r.N_CASHDELAY) " +  
//
//		        //"	WHEN r.N_AMOUNT > r.N_TOTINVAMT THEN " +  
//		        "	WHEN r.N_AMOUNT >= r.N_TOTINVAMT THEN " +  	
//		        "    r.N_TOTINVAMT " + 
//		        "    * " + 
//		        "  ((((dbo.GetBLR(r.C_CLNTCODE, '"+monthYear+"') " + 
//		        "   + " + 
//		        "   (c.N_DCR/100))) / 360) * r.N_CASHDELAY) " + 
//
//		        " ELSE " + 
//		        "   0.00 " +  
//		        "END AS CashDelay, " + 
//		  			" 0 AS ServiceCharge " + 
//		  			" FROM " + 
//		  			" ReceiptsHdr AS r CROSS JOIN CC AS c " +
//		  			" WHERE " +
//		  			" CAST(MONTH(r.D_TRANSACTIONDATE) as varchar) + '-' + CAST (YEAR(r.D_TRANSACTIONDATE) as varchar) " +  
//		  			" = " +
//		  			" CAST(MONTH('"+monthYear+"') as varchar) + '-' + CAST (YEAR('"+monthYear+"') as varchar) " +
//		  			" AND " +
//		  			" r.C_BRANCHCODE = '"+branchCode+"'" +
//		  			" AND " +
//		  			" r.C_STATUS IN (1,2,4)" +
//		  			//" r.C_STATUS IN (1,2,3,4)" +
//		  			" AND " +
//		  			" r.C_RECEIPTTYPE = 1 " +
//		  			" AND  " +
//		  			" r.N_CASHDELAY > 0 " +
//		  			" AND" +
//		  			" c.C_CLNTCODE = r.C_CLNTCODE " +
//		  			" AND " +
//		  			" c.C_BRANCHCODE = r.C_BRANCHCODE " +
//		  			" AND " +
//		  			" c.C_CUSTCODE = r.C_CUSTCODE " +																	
//		  "			UNION ALL " +
//		  " 		SELECT " +
//		  " 			i.C_CLNTCODE," +
//		  " 			0 AS C_CASHDELAY," +
//		  " 			(SUM(i.N_INVOICEAMT) * (c.N_SCR/100)) AS sCharge " +
//		  " 		FROM " +
//		  " 			Invoice AS i CROSS JOIN CC AS C " +
//		  "			WHERE " +
//		  " 		CAST(MONTH(i.D_TRANSACTIONDATE) as varchar) + '-' + CAST (YEAR(i.D_TRANSACTIONDATE) as varchar) " + 
//		  " 		= " +
//		  "			CAST(MONTH('"+monthYear+"') as varchar) + '-' + CAST (YEAR('"+monthYear+"') as varchar) " +
//		  "			AND i.C_CLNTCODE = c.C_CLNTCODE " + 
//		  "			AND i.C_BRANCHCODE = '"+branchCode+"' " +
//		  "			AND " +
//		  " 		c.C_CLNTCODE = i.C_CLNTCODE " +
//		  " 		AND " + 
//		  " 		c.C_CUSTCODE = i.C_CUSTCODE " + 
//		  " 		AND i.C_STATUS BETWEEN 2 AND 6 " + 
//		  //" 		AND i.C_STATUS BETWEEN 2 AND 5 " + 
//		  " 		GROUP BY " +
//		  " 		i.C_CLNTCODE, c.N_SCR " +	
//		  "     ) MonthlyCharges on MonthlyCharges.C_CLNTCODE = CC.C_CLNTCODE " +
//		  " WHERE  CC.ClientStatus = 1 " +
//		  " GROUP BY CC.C_CLNTCODE ORDER BY CC.C_CLNTCODE " ;		
//		
		
//remarks 07/20/2010		
//		String sSQL = "SELECT " +  
//					  " ROUND(SUM(DISTINCT(MonthlyCharges.CashDelay)), 3) AS SumOfCashDelay, " +
//					  " ROUND(SUM(DISTINCT(MonthlyCharges.ServiceCharge)), 3) AS SumOfServiceCharge, " +
//					  " ROUND((SUM(DISTINCT(MonthlyCharges.CashDelay)) + SUM(DISTINCT(MonthlyCharges.ServiceCharge))), 3) AS TotalCharges, " + 
//					  "MonthlyCharges.C_CLNTCODE " +  
//
//					  " FROM( " +
//					  			" SELECT " +
//					  			" r.C_CLNTCODE, " +
//					  			"CASE WHEN r.N_AMOUNT < r.N_TOTINVAMT THEN "+  
//					  			 
//					            "r.N_AMOUNT " + 
//					            "* " + 
//					            "((((dbo.GetBLR(r.C_CLNTCODE, '"+monthYear+"') " + 
//					            "+ "+  
//					            "(c.N_DCR/100))) / 360) * r.N_CASHDELAY) " +  
//
//					        //"	WHEN r.N_AMOUNT > r.N_TOTINVAMT THEN " +  
//					        "	WHEN r.N_AMOUNT >= r.N_TOTINVAMT THEN " +  	
//					        "    r.N_TOTINVAMT " + 
//					        "    * " + 
//					        "  ((((dbo.GetBLR(r.C_CLNTCODE, '"+monthYear+"') " + 
//					        "   + " + 
//					        "   (c.N_DCR/100))) / 360) * r.N_CASHDELAY) " + 
//
//					        " ELSE " + 
//					        "   0.00 " +  
//					        "END AS CashDelay, " + 
//					  			" 0 AS ServiceCharge " + 
//					  			" FROM " + 
//					  			" ReceiptsHdr AS r CROSS JOIN CC AS c " +
//					  			" WHERE " +
//					  			" CAST(MONTH(r.D_TRANSACTIONDATE) as varchar) + '-' + CAST (YEAR(r.D_TRANSACTIONDATE) as varchar) " +  
//					  			" = " +
//					  			" CAST(MONTH('"+monthYear+"') as varchar) + '-' + CAST (YEAR('"+monthYear+"') as varchar) " +
//					  			" AND " +
//					  			" r.C_BRANCHCODE = '"+branchCode+"'" +
//					  			" AND " +
//					  			" r.C_STATUS IN (1,2,4)" +
//					  			//" r.C_STATUS IN (1,2,3,4)" +
//					  			" AND " +
//					  			" r.C_RECEIPTTYPE = 1 " +
//					  			" AND  " +
//					  			" r.N_CASHDELAY > 0 " +
//					  			" AND" +
//					  			" c.C_CLNTCODE = r.C_CLNTCODE " +
//					  			" AND " +
//					  			" c.C_BRANCHCODE = r.C_BRANCHCODE " +
//					  			" AND " +
//					  			" c.C_CUSTCODE = r.C_CUSTCODE " +																	
//					  "			UNION " +
//					  " 		SELECT " +
//					  " 			i.C_CLNTCODE," +
//					  " 			0 AS C_CASHDELAY," +
//					  " 			(SUM(i.N_INVOICEAMT) * (c.N_SCR/100)) AS sCharge " +
//					  " 		FROM " +
//					  " 			Invoice AS i CROSS JOIN CC AS C " +
//					  "			WHERE " +
//					  " 		CAST(MONTH(i.D_TRANSACTIONDATE) as varchar) + '-' + CAST (YEAR(i.D_TRANSACTIONDATE) as varchar) " + 
//					  " 		= " +
//					  "			CAST(MONTH('"+monthYear+"') as varchar) + '-' + CAST (YEAR('"+monthYear+"') as varchar) " +
//					  "			AND i.C_CLNTCODE = c.C_CLNTCODE " + 
//					  "			AND i.C_BRANCHCODE = '"+branchCode+"' " +
//					  "			AND " +
//					  " 		c.C_CLNTCODE = i.C_CLNTCODE " +
//					  " 		AND " + 
//					  " 		c.C_CUSTCODE = i.C_CUSTCODE " + 
//					  //" 		AND i.C_STATUS BETWEEN 2 AND 6 " + 
//					  " 		AND i.C_STATUS BETWEEN 2 AND 5 " + 
//					  " 		GROUP BY " +
//					  " 		i.C_CLNTCODE, c.N_SCR " +	
//					  "     ) AS MonthlyCharges, CC " +
//					  " WHERE  MonthlyCharges.C_CLNTCODE = CC.C_CLNTCODE AND CC.ClientStatus = 1 " +
//					  " GROUP BY MonthlyCharges.C_CLNTCODE ORDER BY MonthlyCharges.C_CLNTCODE " ;

		
		System.out.println("[MonthlyChargesDAO]->[getMonthlyCharges][args1:" +monthYear+"][debug]: " +sSQL);
		
		List<MonthlyCharges> monthlyChargesList = new ArrayList<MonthlyCharges>();
		
		monthlyChargesList = getJdbcTemplate().query
						   (
								sSQL, new RowMapper()
								{					
									@Override					
									public Object mapRow(ResultSet rs, int rowNum) throws SQLException
									{
										MonthlyCharges monthlyCharges = new MonthlyCharges();
										monthlyCharges.setClientName(rs.getString("C_NAME"));
										monthlyCharges.setCustomerName(rs.getString("C_CUSTNAME"));
										monthlyCharges.setN_dcCollected(rs.getDouble("DCCOLLECTED"));
										monthlyCharges.setN_dcAccrual(rs.getDouble("DCACCRUAL"));
										monthlyCharges.setServiceCharge(rs.getDouble("SERVICECHARGE"));
										monthlyCharges.setClientCode(rs.getString("C_CLNTCODE"));
										monthlyCharges.setAccountOfficer(rs.getString("AO"));
										//monthlyCharges.setDiscountCharge(getDiscountChargePerClient(monthYear, rs.getLong("C_CLNTCODE")));
										//monthlyCharges.setCashDelay(rs.getDouble("SumOfCashDelay"));
										//monthlyCharges.setServiceCharge(rs.getDouble("SumOfServiceCharge"));
										//monthlyCharges.setTotalCharges(rs.getDouble("TotalCharges") + monthlyCharges.getDiscountCharge());	
										
										return monthlyCharges;
									}
								}
						   );
		
		return monthlyChargesList;
	}

	
	public double getDiscountChargePerClient(String asOfMonth, long clientCode)
	{
		double retval = 0.00;
		String asOfDate = DateHelper.getLastDateOfTheMonth(asOfMonth);
		String sSQL =	" SELECT " +
						" SUM(discountCharge) as subTotal " +
						" FROM " +
						"(	" + 
							" SELECT " +     
							" DISTINCT(CAST(Invoice.C_INVOICENO AS VARCHAR)) as ref," +
							" (ISNULL(Invoice.N_INVOICEAMT,0) * (CC.N_SCR/100)) " +
							" * (dbo.GetBLR(Invoice.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100))" +
							" * (DATEDIFF(Day, " + 
							" Invoice.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360 AS discountCharge " +
							" FROM Invoice CROSS JOIN CC " +							
							" WHERE     CAST(MONTH(Invoice.D_TRANSACTIONDATE) AS varchar) + '-' + CAST(YEAR(Invoice.D_TRANSACTIONDATE) AS varchar) " + 
							" = CAST(MONTH('"+asOfDate+"') AS varchar) + '-' + CAST(YEAR('"+asOfDate+"') AS varchar) AND Invoice.C_CLNTCODE = "+clientCode+" AND " + 
							" Invoice.C_STATUS IN (2,3,4,5) AND CC.C_CLNTCODE = Invoice.C_CLNTCODE " +
							" UNION " +										
							" SELECT " + 
							" DISTINCT(CAST(Advances.N_REFNO AS VARCHAR)) AS ref, " +
							" ISNULL(Advances.N_ADVAMT,0) " +
							" * (dbo.GetBLR(Advances.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100)) " +
							" * (DATEDIFF(Day,Advances.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360 AS discountCharge " +
							" FROM " +
							" Advances CROSS JOIN CC" +	 		
							" WHERE " +     
							" CAST(MONTH(Advances.D_TRANSACTIONDATE) AS varchar) " +
							" + '-' + CAST(YEAR(Advances.D_TRANSACTIONDATE) AS varchar) " +
							" = CAST(MONTH('"+asOfDate+"') AS varchar) + '-' + CAST(YEAR('"+asOfDate+"') AS varchar) " +
							" AND Advances.C_CLNTCODE = "+clientCode+" AND " +
							" Advances.C_STATUS = 2 " + 	
							" AND Advances.C_TYPE IN ('1','2','3') " +
							//07/20/2010
							//" AND Advances.C_TYPE IN ('1','2') " +
							" AND CC.C_CLNTCODE = Advances.C_CLNTCODE  " +

							" UNION " + 
							" SELECT " + 
							" DISTINCT(CAST(ReceiptsHdr.N_REFNO AS VARCHAR)) AS ref, " +
 
							" CASE WHEN N_TOTINVAMT < N_AMOUNT THEN " +
	
							" (ISNULL(ReceiptsHdr.N_TOTINVAMT, 0) " +  
							" * " + 
							" (dbo.GetBLR(ReceiptsHdr.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100)) * (DATEDIFF(Day, " + 
							" ReceiptsHdr.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360) * -1 " +
							" ELSE " +
							" (ISNULL(ReceiptsHdr.N_AMOUNT, 0) " + 
							" * " + 
							" (dbo.GetBLR(ReceiptsHdr.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100)) * (DATEDIFF(Day, " + 
							" ReceiptsHdr.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360) * - 1 " +
							" END " +
							" AS discountCharge " +
							" FROM " + 
							" ReceiptsHdr " +
							" CROSS JOIN CC " +							
							" WHERE " +     
							" CAST(MONTH(ReceiptsHdr.D_TRANSACTIONDATE) AS varchar) + '-' + CAST(YEAR(ReceiptsHdr.D_TRANSACTIONDATE) AS varchar) " + 
							" = " +
							" CAST(MONTH('"+asOfDate+"') AS varchar) + '-' + CAST(YEAR('"+asOfDate+"') AS varchar) " + 
							" AND ReceiptsHdr.C_CLNTCODE = "+clientCode+" AND " + 
							" ReceiptsHdr.C_STATUS IN (1,2,4) " +  
							" AND ReceiptsHdr.C_RECEIPTTYPE IN (1,2,3) " +
							" AND CC.C_CLNTCODE = ReceiptsHdr.C_CLNTCODE " +
							"UNION " +
							"SELECT " +
							"DISTINCT(CAST(Refund.N_REFNO AS VARCHAR)) AS ref, " + 
							"(ISNULL(Refund.N_INELIGIBLEREC , 0) " +
							"* " +
							" (dbo.GetBLR(Refund.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100)) * (DATEDIFF(Day," + 
							"Refund.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360) AS discountCharge " +
							"FROM " + 
							"Refund CROSS JOIN CC " +
							"WHERE " +
							"Refund.C_STATUS = 2 " +
							"AND " + 
							"Refund.C_CLNTCODE= " + clientCode + 
							" AND " +
							"CAST(MONTH(Refund.D_TRANSACTIONDATE) AS varchar) + '-' + CAST(YEAR(Refund.D_TRANSACTIONDATE) AS varchar) " + 
							"= " + 
							"CAST(MONTH('"+asOfDate+"') AS varchar) + '-' + CAST(YEAR('"+asOfDate+"') AS varchar) " +
							" UNION" +
							this.getMonthlyBalancesPrevFiu(asOfDate, clientCode) + 
						") AS discCharge " ;
		
		System.out.println("[MonthlyChargesDAO]->[getMonthlyCharges][args1:" +asOfMonth+"][args2:" +clientCode+"][debug]: " +sSQL);
		try
		{
			retval = Double.parseDouble(getJdbcTemplate().queryForObject(sSQL, new RowMapper()
			{
	
				@Override 
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException {				
					return rs.getDouble("subTotal");
				}
				
			}
			
			).toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			retval = 0;
		}				
		return retval;
	}
	
	
	
	public String getMonthlyBalancesPrevFiu(String asOfDate, long clientCode)
	{
		
		String fiu = "";
		int monthNumber = Integer.parseInt(asOfDate.substring(0, 2));		
		if (monthNumber == 1)
		{						
			fiu =  " ROUND(ISNULL(N_PREVYRFIU, 0), 3) ";				   		
		}
		else if (monthNumber == 2)
		{					
			fiu = " ROUND(ISNULL(N_JANFIU, 0), 3) ";		}
		else if (monthNumber == 3)
		{		
			fiu = " ROUND(ISNULL(N_FEBFIU, 0), 3) "; 
		}
		else if (monthNumber == 4)
		{					
			fiu = " ROUND(ISNULL(N_MARFIU, 0), 3) ";			
		}
		else if (monthNumber == 5)
		{						
			fiu = " ROUND(ISNULL(N_APRFIU, 0), 3) ";
		}
		else if (monthNumber == 6)
		{		
			fiu = " ROUND(ISNULL(N_MAYFIU, 0), 3) ";				  
		}
		else if (monthNumber == 7)
		{		
			fiu = " ROUND(ISNULL(N_JUNFIU, 0), 3) ";
		}
		else if (monthNumber == 8)
		{		
			fiu = " ROUND(ISNULL(N_JULFIU, 0), 3) ";
		}
		else if (monthNumber == 9)
		{
			fiu = " ROUND(ISNULL(N_AUGFIU, 0), 3) ";
		}
		else if (monthNumber == 10)
		{			
			fiu = " ROUND(ISNULL(N_SEPFIU, 0), 3) ";
		}
		else if (monthNumber == 11)
		{			
			fiu = " ROUND(ISNULL(N_OCTFIU, 0), 3) ";
		}
		else if (monthNumber == 12)
		{								
			fiu = " ROUND(ISNULL(N_NOVFIU, 0), 3) ";
		}			
		
		String sqlString = " SELECT '0' AS ref, ROUND(" +
						   fiu + " * (dbo.GetBLR("+clientCode+", '"+asOfDate+"') + (CC.N_DCR / 100)) " +
						   " * " +
						   " Day(DateAdd(Month, 1, '"+asOfDate+"') - Day(DateAdd(Month, 1, '"+asOfDate+"'))) " +
						   "/  360 " +
						   ", 3) AS discountCharge  " +
						   " FROM" +
						   " monthlyBalances CROSS JOIN CC " +
						   " WHERE " +
						   " monthlyBalances.C_CLNTCODE = "+clientCode+" " +
						   " AND CC.C_CLNTCODE = monthlyBalances.C_CLNTCODE " ;
				
		return sqlString;
	}
	
	
	
	
	/*
	 * 
	 * SELECT DISTINCT (CC.C_CLNTCODE) ref,  
			ISNULL(N_JULFIU, 0) * (dbo.GetBLR(4, '08/05/2009') + (CC.N_DCR / 100))
			* 
			Day(DateAdd(Month, 1, '08/05/2009') - Day(DateAdd(Month, 1, '08/05/2009')))
			/  360
			AS discountCharge 
			FROM monthlyBalances, CC  
			WHERE  
			monthlyBalances.C_CLNTCODE = 4
			AND monthlyBalances.C_CLNTCODE = CC.C_CLNTCODE
	 * */
	public static void main (String[] args)
	{
		int monthNumber = Integer.parseInt("08/05/2009".substring(0, 2));
		System.out.println(monthNumber);		
	}
}
