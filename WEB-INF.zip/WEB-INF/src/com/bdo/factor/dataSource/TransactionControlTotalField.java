package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.ClientStatistics;
import com.bdo.factor.beans.TransactionControlTotal;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class TransactionControlTotalField implements JRDataSource{	
	private Logger log = Logger.getLogger(TransactionControlTotalField.class);
	
	private int index =-1;
	private int lastIndex = 0;
	private String startDate;
	private String endDate;
	private String branchCode;
	
	TransactionControlTotalDAO tctDao = (TransactionControlTotalDAO)Persistence.getDAO("transactionControlTotalDAO");
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	DecimalFormat df2 = new DecimalFormat("###,###,###,###,###,##0");
	
	TransactionControlTotal tct = new TransactionControlTotal();	
	
	public TransactionControlTotalField(String startDate, String endDate, String branchCode){
		Map param = new HashMap();
		param.put("startDate", startDate);	
		param.put("endDate", endDate);
		param.put("branchCode", branchCode);
		
		this.startDate = startDate;
		this.endDate = endDate;
		
		tct = tctDao.getTransactionControlTotal(startDate, endDate, branchCode);
		lastIndex = 1;
		
	}

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Object value = null;
		String field = jRField.getName();
		TransactionControlTotal transct = tct;
		
		if("invCount".equals(field)){
			value=df2.format(tct.getInvCount());			
		}  
		if("invAmount".equals(field)){
			value=df.format(tct.getInvAmount());			
		}
		if("invCancelledAmount".equals(field)){
			value=df.format(tct.getInvCancelledAmount());			
		}
		if("invCancelledCount".equals(field)){
			value=df2.format(tct.getInvCancelledCount());			
		}
		if("svcChgAmount".equals(field)){
			value=df.format(tct.getSvcChargeAmount());			
		}
		if("svcChgCount".equals(field)){
			value=df2.format(tct.getSvcChargeCount());			
		}
		if("discChgAmount".equals(field)){
			value=df.format(tct.getDiscChargeAmount());			
		}
		if("discChgCount".equals(field)){
			value=df2.format(tct.getDiscChargeCount());			
		}
		if("cnAmount".equals(field)){
			value=df.format(tct.getCnAmount());			
		}
		if("cnCount".equals(field)){
			value=df2.format(tct.getCnCount());			
		}
		if("cnCancelledAmount".equals(field)){
			value=df.format(tct.getCnCancelledAmount());			
		}
		if("cnCancelledCount".equals(field)){
			value=df2.format(tct.getCnCancelledCount());			
		}
		if("rCAAmount".equals(field)){
			value=df.format(tct.getReceiptsCAAmount());		
			log.info("RCAAMOUNT>>>>>>>>>>>>>>>" + tct.getReceiptsCAAmount() + ":::" + tct.getReceiptsCACount());
		}
		if("rCACount".equals(field)){
			value=df2.format(tct.getReceiptsCACount());			
		}
		if("rCHKAmount".equals(field)){
			value=df.format(tct.getReceiptsChkAmount());			
		}
		if("rCHKCount".equals(field)){
			value=df2.format(tct.getReceiptsChkCount());			
		}
		if("rCSHAmount".equals(field)){
			value=df.format(tct.getReceiptsCashAmount());			
		}
		if("rCSHCount".equals(field)){
			value=df2.format(tct.getReceiptsCashCount());			
		}
		if("dishonoredAmount".equals(field)){
			value=df.format(tct.getDishonoredCheckAmount());			
		}
		if("dishonoredCount".equals(field)){
			value=df2.format(tct.getDishonoredCheckCount());			
		}
		if("cancelledRCSH".equals(field)) {
			value=df.format(tct.getCancelledReceiptsCSH());
		}
		if("cancelledRCA".equals(field)) {
			value=df.format(tct.getCancelledReceiptsCA());
		}
		if("cancelledRCSHCount".equals(field)) {
			value=df2.format(tct.getCancelledReceiptsCSHCount());
		}
		if("cancelledRCACount".equals(field)) {
			value=df2.format(tct.getCancelledReceiptsCACount());
		}
		if("refund1Amount".equals(field)){
			value=df.format(tct.getRefund1Amount());			
		}
		if("refund1Count".equals(field)){
			value=df2.format(tct.getRefund1Count());			
		}
		if("refund2Amount".equals(field)){
			value=df.format(tct.getRefund2Amount());			
		}
		if("refund2Count".equals(field)){
			value=df2.format(tct.getRefund2Count());			
		}
		if("refund3Amount".equals(field)){
			value=df.format(tct.getRefund3Amount());			
		}
		if("refund3Count".equals(field)){
			value=df2.format(tct.getRefund3Count());			
		}
		if("refund4Amount".equals(field)){
			value=df.format(tct.getRefund4Amount());			
		}
		if("refund4Count".equals(field)){
			value=df2.format(tct.getRefund4Count());			
		}
		if("refundCancelled".equals(field)){
			value=df.format(tct.getRefundCancelledAmount());			
		}
		if("refundCancelledCount".equals(field)){
			value=df2.format(tct.getRefundCancelledCount());			
		}
		if("cdCount".equals(field)){
			value=df2.format(tct.getCashDelayCount());			
		}
		if("cdAmount".equals(field)){
			value=df.format(tct.getCashDelayAmount());			
		}
		if("advCount".equals(field)) {
			value=df2.format(tct.getAdvancesCount());
		}
		if ("advAmount".equals(field)) {
			value=df.format(tct.getAdvancesAmount());
		}
		if ("advSettingUpFee".equals(field)) {
			value=df.format(tct.getAdvancesSettingUpFee());
		}
		if ("advSettingUpFeeCount".equals(field)) {
			value=df2.format(tct.getAdvancesSettingUpFeeCount());
		}
		if ("cancelledAdv".equals(field)) {
			value=df.format(tct.getCancelledAdvances());
		}
		if("cancelledAdvCount".equals(field)) {
			value=df2.format(tct.getCancelledAdvancesCount());			
		}
		if("dateRange".equals(field)){
			value=startDate + "-" + endDate;			
		}
		if("currentDate".equals(field)){
			value=date.newDate();			
		}
		
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}