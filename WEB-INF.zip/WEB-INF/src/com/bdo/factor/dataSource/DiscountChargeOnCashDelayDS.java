package com.bdo.factor.dataSource;

import java.util.List;
import java.util.ArrayList;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRException;

import com.bdo.factor.beans.DiscountChargeOnCashDelay;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.ReceiptsHeaderDAO;
import com.bdo.factor.dao.Persistence;

public class DiscountChargeOnCashDelayDS implements JRDataSource
{
	private List<DiscountChargeOnCashDelay> discountChargeOnCashDelayList = new ArrayList<DiscountChargeOnCashDelay>();
	private int index          = -1;
	private int lastIndex      = 0;
	private String displayDate = "";
	
	public DiscountChargeOnCashDelayDS(String startDate, String endDate, String branchCode)
	{
		ReceiptsHeaderDAO receiptsHdrDao = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		discountChargeOnCashDelayList = receiptsHdrDao.getDiscountChargeOnCashDelay(startDate, endDate, branchCode);
		lastIndex = discountChargeOnCashDelayList.size();
		displayDate = "From " + startDate + " to " + endDate;				
	}
	
	@Override
	public Object getFieldValue(JRField jrFields) throws JRException {			
		Object value = null;
		String fields = jrFields.getName();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");		
		DiscountChargeOnCashDelay discountChargeOnCashDelay = (DiscountChargeOnCashDelay) discountChargeOnCashDelayList.get(index);
		
		if (this.lastIndex > 0)
		{
			if ("C_NAME".equals(fields))
			{
				System.out.println("C_Name:"+discountChargeOnCashDelay.getCName());
				value = discountChargeOnCashDelay.getCName();
			}
			
			if ("C_CUSTNAME".equals(fields))
			{
				System.out.println("C_CUSTNAME:"+discountChargeOnCashDelay.getCCustName());
				value = discountChargeOnCashDelay.getCCustName();				
			}
			
			if ("D_TRANSACTIONDATE".equals(fields))
			{
				System.out.println("D_TRANSACTIONDATE:"+discountChargeOnCashDelay.getDTransactionDate());
				value = discountChargeOnCashDelay.getDTransactionDate();
			}
			
			if ("N_REFNO".equals(fields))
			{
				value = discountChargeOnCashDelay.getRefno();
			}
			
			if ("totalAmount".equals(fields))
			{
				value = discountChargeOnCashDelay.getTotalAmount();
			}
			
			if ("N_CASHDELAY".equals(fields))
			{
				value = discountChargeOnCashDelay.getNCashDelay();
			}
			
			if ("D_CHARGE".equals(fields))
			{
				value = discountChargeOnCashDelay.getDCharge();
			}
			
			if("currentDate".equals(fields)){
				value = date.newDate();
			}
		}
		
		if ("dateRange".equals(fields))
		{
			value = displayDate;
		}
		
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
        if(index<lastIndex){
            return true;
        }
        return false;
	}
	
}
