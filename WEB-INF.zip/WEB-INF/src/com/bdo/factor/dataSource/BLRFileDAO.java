package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.ListIterator;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.BLRFile;
import com.bdo.factor.beans.MonthlyBalances;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.FactorConnection;

public class BLRFileDAO {
	
	private static Logger log = Logger.getLogger(BLRFileDAO.class);
	private static String delim="@";
	private static SimpleDateFormat  sdf = new SimpleDateFormat ("MM/dd/yyyy");	
	private static DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");

	public BLRFileDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public List<BLRFile> getBLRFile(String clientCode,String asOfDate){
		List<BLRFile> list = new ArrayList<BLRFile>();
		String sSQL1="SELECT ISNULL(N_BLR1 , 0.00)AS N_BLR1 ,ISNULL(D_EFFDT1 , '') AS D_EFFDT1 , ISNULL(D_EXPDT1 , '') AS D_EXPDT1 FROM BLRFile WHERE C_BLRTYPECODE='"+clientCode+"' AND '"+asOfDate+"' BETWEEN D_EFFDT1 AND D_EXPDT1";
		String sSQL2="SELECT ISNULL(N_BLR2 , 0.00)AS N_BLR2 ,ISNULL(D_EFFDT2 , '') AS D_EFFDT2 , ISNULL(D_EXPDT2 , '') AS D_EXPDT2 FROM BLRFile WHERE C_BLRTYPECODE='"+clientCode+"' AND '"+asOfDate+"' BETWEEN D_EFFDT2 AND D_EXPDT2";
		String sSQL3="SELECT ISNULL(N_BLR3 , 0.00)AS N_BLR3 ,ISNULL(D_EFFDT3 , '') AS D_EFFDT3 , ISNULL(D_EXPDT3 , '') AS D_EXPDT3 FROM BLRFile WHERE C_BLRTYPECODE='"+clientCode+"' AND '"+asOfDate+"' BETWEEN D_EFFDT3 AND D_EXPDT3";
		String sSQL4="SELECT ISNULL(N_BLR4 , 0.00)AS N_BLR4 ,ISNULL(D_EFFDT4 , '') AS D_EFFDT4 , ISNULL(D_EXPDT4 , '') AS D_EXPDT4 FROM BLRFile WHERE C_BLRTYPECODE='"+clientCode+"' AND '"+asOfDate+"' BETWEEN D_EFFDT4 AND D_EXPDT4";
		String sSQL5="SELECT ISNULL(N_BLR5 , 0.00)AS N_BLR5 ,ISNULL(D_EFFDT5 , '') AS D_EFFDT5 , ISNULL(D_EXPDT5 , '') AS D_EXPDT5 FROM BLRFile WHERE C_BLRTYPECODE='"+clientCode+"' AND '"+asOfDate+"' BETWEEN D_EFFDT5 AND D_EXPDT5";
		//
		
		
		Statement stmt=null;
		ResultSet rs=null;
		try{

			stmt = new FactorConnection().getConnection().createStatement();
			boolean rset = false;
			rs = stmt.executeQuery(sSQL1);
			rset =  rs.next();
			log.info("rset SLQ1:" + rset);
			if(rset){
				log.info("BLRFileDAO - getBLRFile (sSQL1) "+sSQL1);
				while(rset){	
					BLRFile blr = new BLRFile();
					blr.setBlr(rs.getDouble(1));
					blr.setEffectiveDate(rs.getDate(2));
					blr.setExpiryDate(rs.getDate(3));
					list.add(blr);
					rset=rs.next();
				}
			}
			else{
				rs = stmt.executeQuery(sSQL2);
				rset = rs.next();
				log.info("rset SLQ2:" + rset);
				if(rset){
					log.info("BLRFileDAO - getBLRFile (sSQL2) "+sSQL2);
					while(rset){	
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(1));
						blr.setEffectiveDate(rs.getDate(2));
						blr.setExpiryDate(rs.getDate(3));
						list.add(blr);
						rset=rs.next();
					}
				}
				else{
					rs = stmt.executeQuery(sSQL3);
					rset = rs.next();
					log.info("rset SLQ3:" + rset);
					if(rset){
						//while(rs.next()){	
						while(rset){	
							BLRFile blr = new BLRFile();
							log.info("rs.getDouble(1):"+rs.getDouble(1));
							blr.setBlr(rs.getDouble(1));
							blr.setEffectiveDate(rs.getDate(2));
							blr.setExpiryDate(rs.getDate(3));
							list.add(blr);
							rset=rs.next();
						}
					}
					else{
						rs = stmt.executeQuery(sSQL4);
						rset = rs.next();
						log.info("rset SLQ4:" + rset);
						if(rset){
							log.info("BLRFileDAO - getBLRFile (sSQL4) "+sSQL4);
							//while(rs.next()){
							while(rset){	
								BLRFile blr = new BLRFile();
								blr.setBlr(rs.getDouble(1));
								blr.setEffectiveDate(rs.getDate(2));
								blr.setExpiryDate(rs.getDate(3));
								list.add(blr);
								rset = rs.next();
							}
						}
						else{
							rs = stmt.executeQuery(sSQL5);
							rset = rs.next();
							log.info("rset SLQ5:" + rset);
							if(rset){
								log.info("BLRFileDAO - getBLRFile (sSQL5) "+sSQL5);
								while(rset){	
									BLRFile blr = new BLRFile();
									blr.setBlr(rs.getDouble(1));
									blr.setEffectiveDate(rs.getDate(2));
									blr.setExpiryDate(rs.getDate(3));
									list.add(blr);
									rset = rs.next();
								}
							}							
						}
					}
				}
			}

			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return list;
	}
	
	public static List<BLRFile> getAllBLRFile(String clientCode){
		List<BLRFile> list = new ArrayList<BLRFile>();
		String sSQL1="SELECT ISNULL(N_BLR1 , 0.00)AS N_BLR1 ,ISNULL(D_EFFDT1 , '') AS D_EFFDT1 , ISNULL(D_EXPDT1 , '') AS D_EXPDT1,ISNULL(N_BLR2 , 0.00)AS N_BLR2 ,ISNULL(D_EFFDT2 , '') AS D_EFFDT2 , ISNULL(D_EXPDT2 , '') AS D_EXPDT2, ISNULL(N_BLR3 , 0.00)AS N_BLR3 ,ISNULL(D_EFFDT3 , '') AS D_EFFDT3 , ISNULL(D_EXPDT3 , '') AS D_EXPDT3, ISNULL(N_BLR4 , 0.00)AS N_BLR4 ,ISNULL(D_EFFDT4 , '') AS D_EFFDT4 , ISNULL(D_EXPDT4 , '') AS D_EXPDT4,ISNULL(N_BLR5 , 0.00)AS N_BLR5 ,ISNULL(D_EFFDT5 , '') AS D_EFFDT5 , ISNULL(D_EXPDT5 , '') AS D_EXPDT5,ISNULL(dbCIF.dbo.Client.N_DCR,0.00) AS discountCharge   FROM BLRFile,dbCIF.dbo.Client WHERE BLRFile.C_BLRTYPECODE='"+clientCode+"' AND dbCIF.dbo.Client.C_CLNTCODE=BLRFile.C_BLRTYPECODE";
		//
		
		
		Statement stmt=null;
		ResultSet rs=null;
		try{

			stmt = new FactorConnection().getConnection().createStatement();
			boolean rset = false;
			rs = stmt.executeQuery(sSQL1);
			rset = rs.next();
			if(rset){
				log.info("BLRFileDAO - getBLRFile (sSQL) "+sSQL1);
				while(rset){	
					if(rs.getString(2)!=""&&rs.getString(3)!=""){
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(1));
						blr.setEffectiveDate(rs.getDate(2));
						blr.setExpiryDate(rs.getDate(3));
						blr.setDiscountCharge(rs.getDouble(1)+rs.getDouble(16));
						list.add(blr);						
					}
					if(rs.getString(5)!=""&&rs.getString(6)!=""){
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(4));
						blr.setEffectiveDate(rs.getDate(5));
						blr.setExpiryDate(rs.getDate(6));
						blr.setDiscountCharge(rs.getDouble(4)+rs.getDouble(16));
						list.add(blr);						
					}
					if(rs.getString(8)!=""&&rs.getString(9)!=""){
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(7));
						blr.setEffectiveDate(rs.getDate(8));
						blr.setExpiryDate(rs.getDate(9));
						blr.setDiscountCharge(rs.getDouble(7)+rs.getDouble(16));
						list.add(blr);						
					}
					if(rs.getString(11)!=""&&rs.getString(12)!=""){
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(10));
						blr.setEffectiveDate(rs.getDate(11));
						blr.setExpiryDate(rs.getDate(12));
						blr.setDiscountCharge(rs.getDouble(10)+rs.getDouble(16));
						list.add(blr);						
					}
					if(rs.getString(14)!=""&&rs.getString(15)!=""){
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(13));
						blr.setEffectiveDate(rs.getDate(14));
						blr.setExpiryDate(rs.getDate(15));
						blr.setDiscountCharge(rs.getDouble(13)+rs.getDouble(16));
						list.add(blr);						
					}
					rset=rs.next();
				}
			}


			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return list;
	}	
	
	
	
	public static String getBLRFileWithDiscountCharge(String clientCode){
		String returnString="";
		String sSQL1="SELECT ISNULL(N_BLR1 , 0.00)AS N_BLR1 ,ISNULL(D_EFFDT1 , '') AS D_EFFDT1 , ISNULL(D_EXPDT1 , '') AS D_EXPDT1,ISNULL(N_BLR2 , 0.00)AS N_BLR2 ,ISNULL(D_EFFDT2 , '') AS D_EFFDT2 , ISNULL(D_EXPDT2 , '') AS D_EXPDT2, ISNULL(N_BLR3 , 0.00)AS N_BLR3 ,ISNULL(D_EFFDT3 , '') AS D_EFFDT3 , ISNULL(D_EXPDT3 , '') AS D_EXPDT3, ISNULL(N_BLR4 , 0.00)AS N_BLR4 ,ISNULL(D_EFFDT4 , '') AS D_EFFDT4 , ISNULL(D_EXPDT4 , '') AS D_EXPDT4,ISNULL(N_BLR5 , 0.00)AS N_BLR5 ,ISNULL(D_EFFDT5 , '') AS D_EFFDT5 , ISNULL(D_EXPDT5 , '') AS D_EXPDT5,ISNULL(dbCIF.dbo.Client.N_DCR,0.00) AS discountCharge   FROM BLRFile,dbCIF.dbo.Client WHERE BLRFile.C_BLRTYPECODE='"+clientCode+"' AND dbCIF.dbo.Client.C_CLNTCODE=BLRFile.C_BLRTYPECODE";
		//
		
		
		Statement stmt=null;
		ResultSet rs=null;
		try{

			stmt = new FactorConnection().getConnection().createStatement();
			boolean rset = false;
			rs = stmt.executeQuery(sSQL1);
			rset = rs.next();
			if(rset){
				log.info("BLRFileDAO - getBLRFile (sSQL) "+sSQL1);
				while(rset){	
					if((rs.getString(2)!=""&&rs.getString(3)!="")&&(!DateHelper.format(rs.getDate(2)).trim().equals("01/01/1900")&&!DateHelper.format(rs.getDate(3)).trim().equals("01/01/1900"))){
						log.info("DateHelper.format(rs.getDate(11) "+DateHelper.format(rs.getDate(2)));
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(1));
						blr.setEffectiveDate(rs.getDate(2));
						blr.setExpiryDate(rs.getDate(3));
						blr.setDiscountCharge(rs.getDouble(1)+rs.getDouble(16));
						returnString+=sdf.format(rs.getDate(2))+"      "+sdf.format(rs.getDate(3))+"         "+df.format(blr.getDiscountCharge())+"% p.a. \n";					
					}
					if((rs.getString(5)!=""&&rs.getString(6)!="")&&(!DateHelper.format(rs.getDate(5)).trim().equals("01/01/1900")&&!DateHelper.format(rs.getDate(6)).trim().equals("01/01/1900"))){
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(4));
						blr.setEffectiveDate(rs.getDate(5));
						blr.setExpiryDate(rs.getDate(6));
						blr.setDiscountCharge(rs.getDouble(4)+rs.getDouble(16));
						returnString+=sdf.format(rs.getDate(5))+"      "+sdf.format(rs.getDate(6))+"         "+df.format(blr.getDiscountCharge())+"% p.a. \n";						
					}
					if((rs.getString(8)!=""&&rs.getString(9)!="")&&(!DateHelper.format(rs.getDate(8)).trim().equals("01/01/1900")&&!DateHelper.format(rs.getDate(9)).trim().equals("01/01/1900"))){
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(7));
						blr.setEffectiveDate(rs.getDate(8));
						blr.setExpiryDate(rs.getDate(9));
						blr.setDiscountCharge(rs.getDouble(7)+rs.getDouble(16));
						returnString+=sdf.format(rs.getDate(8))+"      "+sdf.format(rs.getDate(9))+"         "+df.format(blr.getDiscountCharge())+"% p.a. \n";											
					}
					if((rs.getString(11)!=""&&rs.getString(12)!="")&&(!DateHelper.format(rs.getDate(11)).trim().equals("01/01/1900")&&!DateHelper.format(rs.getDate(12)).trim().equals("01/01/1900"))){
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(10));
						blr.setEffectiveDate(rs.getDate(11));
						blr.setExpiryDate(rs.getDate(12));
						blr.setDiscountCharge(rs.getDouble(10)+rs.getDouble(16));
						returnString+=sdf.format(rs.getDate(11))+"      "+sdf.format(rs.getDate(12))+"         "+df.format(blr.getDiscountCharge())+"% p.a. \n";						
					}
					if((rs.getString(14)!=""&&rs.getString(15)!="")&&(!DateHelper.format(rs.getDate(14)).trim().equals("01/01/1900")&&!DateHelper.format(rs.getDate(15)).trim().equals("01/01/1900"))){					
						BLRFile blr = new BLRFile();
						blr.setBlr(rs.getDouble(13));
						blr.setEffectiveDate(rs.getDate(14));
						blr.setExpiryDate(rs.getDate(15));
						blr.setDiscountCharge(rs.getDouble(13)+rs.getDouble(16));
						returnString+=sdf.format(rs.getDate(14))+"      "+sdf.format(rs.getDate(15))+"         "+df.format(blr.getDiscountCharge())+"% p.a. \n";						
					}
					rset=rs.next();
				}
			}


			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return returnString;
	}		

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BLRFileDAO blrDao = new BLRFileDAO();
		ListIterator li = blrDao.getAllBLRFile("99").listIterator();
		while(li.hasNext()){
			BLRFile blr = (BLRFile) li.next();
			log.info("BLR: "+blr.getBlr());
			log.info("Effectivity Date: "+blr.getEffectiveDate());
			log.info("Expiry Date: "+blr.getExpiryDate());
			log.info("DiscountCharge: "+blr.getDiscountCharge());
		}
		log.info("getBLRFileWithDiscountCharge('99') \n"+getBLRFileWithDiscountCharge("99"));
		// TODO Auto-generated method stub

	}

}
