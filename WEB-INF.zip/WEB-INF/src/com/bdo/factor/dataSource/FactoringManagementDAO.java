package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.FactoringManagement;
import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;

public class FactoringManagementDAO extends JdbcDaoSupport{
	private Logger log = Logger.getLogger(FactoringManagementDAO.class);

	//CREDEX
	@SuppressWarnings("unchecked")
	public List<FactoringManagement> getFactoringManagement(String asOfDate, String branchCode,Boolean filter)  {
		List<FactoringManagement> lFm = new ArrayList<FactoringManagement>();

		final String strAsOfDate = asOfDate;
		Date dAsOfDate = DateHelper.parse(asOfDate);

		SimpleDateFormat sdfMo = new SimpleDateFormat("MM");		

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(dAsOfDate);

		String firstDayMo = sdfMo.format(dAsOfDate) + "/01/" + gc.get(GregorianCalendar.YEAR);

		String sSQL = "" +
				"SELECT	"+
				"CASE WHEN sum(distinct(a.status)) = 1 THEN 'CURRENT'	"+
				"WHEN sum(distinct(a.status)) = 2 THEN 'DELINQUENT'	"+
				"WHEN sum(distinct(a.status)) = 3 THEN 'CURRENT AND DELINQUENT'	"+
				"WHEN sum(distinct(a.status)) = 4 THEN 'PAST DUE'	"+
				"WHEN sum(distinct(a.status)) = 5 THEN 'CURRENT AND PAST DUE'	"+
				"WHEN sum(distinct(a.status)) = 6 THEN 'DELINQUENT AND PASTDUE'	"+
				"WHEN sum(distinct(a.status)) = 7 THEN 'CURRENT AND DELINQUENT AND PASTDUE'	"+
				"END AS c_Status,	"+
				"cc.c_clntcode AS c_ClntCode,	"+ 
				"cc.c_name,	"+ 
				"ao.c_name AS aoName,	"+
				"ISNULL(cc.N_ADVANCEDRATIO,0.00)/100 AS advancedRatio,	"+ 
				"ISNULL((100-cc.N_ADVANCEDRATIO),0.00)/100 AS n_CERatio,	"+
				//"(ISNULL(sum(rd.n_receiptamt),0))*((100-ISNULL(cc.N_ADVANCEDRATIO,0.00))/100) as n_ClntEquity,	"+
				"ISNULL(rh.CN_N_AMOUNT,0) as n_CreditNote,	"+
				"ISNULL(rh.N_AMOUNT,0) as n_receipts,	"+
				"ISNULL(rh.N_OVERPAYMENT,0) as n_overpayment,	"+
				"cc.c_currencycode,	"+ 
				"ISNULL(cc.n_investmentlimit,0) AS n_investmentlimit,	"+
				"cc.d_effdate,	"+
				"ISNULL(SUM(a.n_invoiceamt),0) AS factoredInvoice,	"+
				"ISNULL(mb.N_AUGFIU,0) AS n_fiutran,	"+	
				"ISNULL(mb.N_AUGREC,0) AS n_receivables, 	"+
				"ISNULL(mb.N_AUGRES,0) AS n_reserves,	"+
				//"ISNULL(blr.blrVal,0)+ISNULL(n_scr,0)/100	 AS n_DCRate,	"+
				"ISNULL(n_scr,0) AS n_scr,	"+
				"ISNULL(n_dcr,0) AS n_dcr,	"+
				/*"blr.effDate AS d_BlrFrom,	"+
				"blr.expDate AS d_BlrTo ,	"+*/
				"cc.n_settlement AS n_Term,	"+
				"cc.d_reviewDate,	"+
				"CASE WHEN ISNULL(cc.IndCd,0)='' THEN NULL ELSE ISNULL(cc.IndCd,0) END  AS n_IndustryCode,	"+
				"id.c_desc AS c_Industry,	"+
				"ih.c_desc AS c_IndustryHeader,	"+
				"CASE WHEN cc.c_tin='' THEN NULL ELSE cc.c_tin END AS c_TIN,	"+
				"brw.c_borclass AS c_BorrowerType,	"+
				"bt.c_desc AS c_SizeOfFirm,	"+
				"ISNULL(cc.n_assets,0) AS n_Assets,	"+
				"ISNULL(cc.n_liabilities,0) AS n_Liabilities,	"+
				"ISNULL(cc.n_equity,0) AS n_Equity,	"+
				"ISNULL(cc.n_grossincome,0) AS n_GrossIncome,	"+
				"ISNULL(cc.n_expenses,0) AS n_Expenses,	"+
				"ISNULL(cc.n_netincome,0) AS n_NetIncome,	"+
				"cc.d_auditeddate AS d_audited	"+
			"FROM	"+ 
				"dbcif.dbo.client cc	"+ 
			"INNER JOIN	"+ 
				"accountofficer ao	"+ 
				"ON ao.c_acctofficercode = cc.c_acctofficercode	"+ 
				"	LEFT JOIN (	"+
				"		select inv.*,CASE WHEN dateadd(day,90+1,dateadd(day,cc.n_dunning,d_invoicedate))<='"+asOfDate+"' THEN  dateadd(day,90+1,dateadd(day,cc.n_dunning,d_invoicedate))  ELSE NULL END as pastDueDate,	"+
				"				  CASE WHEN dateadd(day,cc.n_dunning,d_invoicedate)<='"+asOfDate+"' THEN	"+	 
				"				  CASE WHEN dateadd(day,90+1,dateadd(day,cc.n_dunning,d_invoicedate))<='"+asOfDate+"' THEN 4 ELSE 2 END	"+	
				"				  ELSE 1 END AS Status	"+
				"		FROM INVOICE inv	"+
				"		INNER JOIN CC cc	"+
				"			ON cc.c_clntcode = inv.c_clntcode AND cc.c_custcode = inv.c_custcode	"+
				"				WHERE (d_fullypaiddate > '"+asOfDate+"' OR d_fullypaiddate IS NULL) AND inv.c_status <> '7'	" +
				"				AND inv.d_transactiondate <= '"+asOfDate+"'	"+
				"				)a	  "+
				"		ON a.c_clntcode = cc.c_clntcode	 "+
			"LEFT OUTER JOIN	"+
				"monthlybalances mb	"+ 
				"on mb.c_clntcode = cc.c_clntcode	"+ 	
			"LEFT OUTER JOIN 	"+
				"borrtype bt	"+
				"on cc.c_borwtype=bt.c_borwtype	"+
			"LEFT OUTER JOIN	"+
				"industrydetail id	"+
				"on cc.IndCd=id.IndCd	"+
			"LEFT OUTER JOIN	"+ 	
				"industryHeader ih	"+
				"on id.DivCd=ih.DivCd	"+
			/*"LEFT OUTER JOIN	"+ 
				"(select * from dbo.getBLRFile (cc.c_clntcode,"+asOfDate +")) blr	"+
				"on blr.clientCode = cc.c_clntcode	"+*/
			"LEFT OUTER JOIN	 	"+
			"	 (SELECT rh.C_CLNTCODE,	"+
			"			SUM(ISNULL(rh.N_AMOUNT,0)-ISNULL(rh.N_OPAMT,0)) as N_AMOUNT,	"+
			"		SUM(cn.N_AMOUNT) as CN_N_AMOUNT,	"+
			"		SUM(rh.N_OPAMT) as N_OVERPAYMENT,	"+
			"		ISNULL(sum(rh.n_penaltychg),0) as n_penaltychg,	"+
			"		ISNULL(sum(n_pdinterest),0) as n_pdinterest,	"+
			"		MAX(rh.d_transactiondate) as d_transactiondate	"+
			"FROM ReceiptsHdr rh	"+
			"		LEFT OUTER JOIN	"+
			"			(select SUM(N_AMOUNT) as N_AMOUNT,C_RECEIPTNO,C_CLNTCODE from CreditNote where " +
			//"		D_TRANSACTIONDATE between '"+firstDayMo+"' AND '"+asOfDate+"' " +
			"		(d_cancelledDate>'"+asOfDate+"' OR d_cancelledDate IS NULL) GROUP by C_CLNTCODE,C_RECEIPTNO)	cn	"+
			"			ON cn.C_RECEIPTNO = rh.N_REFNO	" +
			"			AND rh.C_CLNTCODE = cn.C_CLNTCODE"+
			"		LEFT OUTER JOIN 	"+
			"			refund  ref 	"+
			"			on rh.n_refundrefno = ref.n_refno		"+
			"WHERE 	"+
			//"	rh.D_TRANSACTIONDATE between '"+firstDayMo+"' AND '"+asOfDate+"'	"+
			"	  (ref.d_transactiondate > '"+asOfDate+"' OR ref.n_refno IS NULL) 	" +
			"	AND rh.d_transactiondate <='"+asOfDate+"'	"+
			"	AND (d_datebounced>'"+asOfDate+"' OR d_datebounced IS NULL) 	"+
			"	AND rh.C_RECEIPTTYPE IN ('1', '2','3','4')  	"+
			"GROUP BY rh.C_CLNTCODE) rh 	"+
			"on rh.C_CLNTCODE = cc.C_CLNTCODE	"+
			"LEFT OUTER JOIN	"+
				"borrower brw	"+
				"on cc.c_borwcode=brw.c_borwcode	"+
			"WHERE	"+ 
				//"cc.c_clntcode in (267,301,302)	AND "+
				"cc.c_clntcode>=124	AND "+
				"cc.C_STATUS = 1	"+ 
			"GROUP BY	"+ 
				"cc.c_clntcode,	"+ 
				"cc.c_name,	"+ 
				"ao.c_name,	"+ 
				"cc.c_currencycode,	"+ 
				"cc.n_investmentlimit, 	"+
				"cc.n_receivables,	"+ 
				"cc.n_reserves,	"+ 
				"cc.n_fiutran,	"+
				"cc.d_effdate,	"+ 
				"mb.N_AUGFIU,	"+ 
				"mb.N_AUGREC,	"+ 
				"mb.N_AUGRES,	"+ 
				"cc.N_ADVANCEDRATIO,	"+
				"bt.c_desc,	"+
				"cc.n_assets,	"+
				"cc.n_liabilities,	"+
				"cc.n_equity,	"+
				"cc.n_grossincome,	"+
				"cc.n_expenses,	"+
				"cc.n_netincome,	"+
				"cc.d_auditeddate,	"+
				"cc.c_tin,	"+
				"cc.IndCd,	"+
				"id.c_desc,	"+
				"ih.c_desc,	"+
				"cc.d_reviewDate,	"+
				"cc.n_settlement,	"+
				/*"blr.effDate,	"+
				"blr.expDate,	"+
				"blr.blrVal,	"+*/
				"n_scr,	" +
				"n_dcr,	"+
				//"rd.n_receiptamt,	"+
				"brw.c_borclass,	"+ 
				"rh.CN_N_AMOUNT,	"+
				"rh.N_AMOUNT,	"+
				"rh.N_OVERPAYMENT	"+
			"ORDER BY	"+ 
				"cc.c_clntcode	"+
				"";

		log.info("Query: "+sSQL);

		final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

			lFm  = getJdbcTemplate().query(sSQL,new BeanPropertyRowMapper(FactoringManagement.class));
			for(int x =0 ; x<lFm.size();x++){
				ClientDAO cld = new ClientDAO();
				List<ClientActivities> list = cld.getClientActivities(lFm.get(x).getC_ClntCode(), strAsOfDate);
				int index=list.size()-1;
				if((filter&&list.get(index).getTotalReceivables()>0)||!filter){
					lFm.get(x).setN_receivables(list.get(index).getTotalReceivables());
					lFm.get(x).setN_reserves(list.get(index).getTotalReserves());	
					lFm.get(x).setN_fiutran(list.get(index).getTotalFiuBalance());	
					lFm.get(x).setN_dcAccrual(list.get(index).getDiscountCharges());
					//lFm.get(x).setN_CreditNote(list.get(index).getCreditNotes());
					lFm.get(x).setCEUnpaid(list.get(index).getTotalReceivables()*(1-lFm.get(x).getAdvancedRatio()));
					Double CEPaid = ((lFm.get(x).getN_CreditNote()+lFm.get(x).getN_receipts())*lFm.get(x).getN_CERatio())+lFm.get(x).getN_overpayment();
					lFm.get(x).setN_CEPaid(CEPaid);

					lFm.get(x).setN_ClntEquity(lFm.get(x).getN_CEPaid()+lFm.get(x).getCEUnpaid());
					
					  sSQL = "select ISNULL(sum(N_INVOICEAMT),0) from Invoice	" +
						  "where C_STATUS between 2 and 5 and C_CLNTCODE = "+lFm.get(x).getC_ClntCode();
/*					try{
						Double equity  = (Double) getJdbcTemplate().queryForObject(sSQL, Double.class);
						lFm.get(x).setN_ClntEquity(equity*lFm.get(x).getN_CERatio());
					}
					catch(EmptyResultDataAccessException e){
						lFm.get(x).setN_ClntEquity(0.00);
					}*/
					  
					Map BLRMap= new HashMap();
					try {
						BLRMap = getJdbcTemplate().queryForMap("select * from dbo.getBLRFile ("+lFm.get(x).getC_ClntCode()+",'"+asOfDate+"')");
						if (!BLRMap.isEmpty()){
								lFm.get(x).setD_BlrFrom(SDF.parse(BLRMap.get("effDate").toString()));
								lFm.get(x).setD_BlrTo(SDF.parse(BLRMap.get("expDate").toString()));
								lFm.get(x).setN_DCRate((Double.parseDouble(BLRMap.get("blrVal").toString())+lFm.get(x).getN_dcr())/100);
						}
					} catch (ParseException e) {
							e.printStackTrace();
					} catch (EmptyResultDataAccessException e){
						log.info("No Valid BLR For This Date");
						lFm.get(x).setN_DCRate(lFm.get(x).getN_dcr()/100);
					}
				}else
					lFm.set(x, null);
			}

		return lFm;
	}

	public List<FactoringManagement> getFactoringManagement2(String asOfDate, String branchCode)  {
		List<FactoringManagement> lFm = new ArrayList<FactoringManagement>();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");

		final String strAsOfDate = asOfDate;
		Date dAsOfDate = DateHelper.parse(asOfDate);
		SimpleDateFormat sdf = new SimpleDateFormat("MMM");
		SimpleDateFormat sdfMo = new SimpleDateFormat("MM");		
		SimpleDateFormat sdfYear = new SimpleDateFormat("YYYY");
		String mo=sdf.format(dAsOfDate).toUpperCase();

		boolean isLastYear=false;

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(dAsOfDate);

		String firstDayMo = sdfMo.format(dAsOfDate) + "/01/" + gc.get(GregorianCalendar.YEAR);

		GregorianCalendar dateToday = new GregorianCalendar();

		log.info("dateToday: " + dateToday);
		int newDateToday = Integer.parseInt(sdfYear.format(date.newDate()));
		if((newDateToday-1)==gc.get(GregorianCalendar.YEAR)){ //before: (dateToday.get(GregorianCalendar.YEAR)-1)
			isLastYear=true;		
		}		

		if(mo.equalsIgnoreCase("DEC")&& isLastYear ){
			mo="PREVYR";		
		}		
		else if (!mo.equalsIgnoreCase("DEC") && isLastYear) {
			mo = "PREV" + mo;
		}

		String sSQL = "select cc.c_clntcode, cc.c_name, cc.c_currencycode, " +
        "cc.n_investmentlimit," + 
        "cc.d_effdate,isnull(sum(a.n_invoiceamt),0) as factoredInvoice, ao.c_name as aoName, " +                               
        "isnull(mb.N_" + mo + "FIU,0) as n_fiutran, " +
        "isnull(mb.N_" + mo + "REC,0) as n_receivables, " +                
        "isnull(mb.N_" + mo + "RES,0) as n_reserves," +
        //RLS (redd) 01/19/2011  change currency to advanced ratio per advice by ms rache
        "ISNULL(cc.N_ADVANCEDRATIO,0.00) as advancedRatio  from dbcif.dbo.client cc " +
        "inner join accountofficer ao on ao.c_acctofficercode = cc.c_acctofficercode " +
        "left join (select c_clntcode, n_invoiceamt from invoices " +
        "where c_status between '2' and '6' and d_invoicedate " +
        "between '" + firstDayMo + "' and '" + asOfDate + "' " + 
        "and c_branchcode = '" + branchCode + "')a " +
        "on a.c_clntcode = cc.c_clntcode " +
        "inner join monthlybalances mb on mb.c_clntcode = cc.c_clntcode " + 
        "WHERE cc.C_STATUS = 1 " +
        "group by cc.c_clntcode, cc.c_name, ao.c_name, cc.c_currencycode, cc.n_investmentlimit, " +
        "cc.n_receivables, cc.n_reserves, cc.n_fiutran,cc.d_effdate, " + 
        "mb.N_" + mo + "FIU, mb.N_" + mo + "REC, mb.N_" + mo + "RES, cc.N_ADVANCEDRATIO " +
		"order by cc.c_clntcode";

		log.info(sSQL+ "testpoint");

			lFm =getJdbcTemplate().query(sSQL, new RowMapper(){
				Calendar getdate= Calendar.getInstance();

				@Override
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
					FactoringManagement fm = new FactoringManagement();
					ClientDAO cld = new ClientDAO();
					List<ClientActivities> list = cld.getClientActivities(rs.getString("c_clntcode"), strAsOfDate);
					int index=list.size()-1;
					fm.setAoName(rs.getString("aoName"));
					fm.setC_ClntCode(rs.getString("c_clntcode"));
					fm.setC_CurrencyCode(rs.getString("c_currencycode"));
					fm.setC_Name(rs.getString("c_name"));
					fm.setD_effDate(rs.getDate("d_effdate"));
					fm.setFactoredInvoice(rs.getDouble("factoredInvoice"));
					fm.setN_investmentlimit(rs.getDouble("n_investmentlimit"));
					fm.setN_receivables(list.get(index).getTotalReceivables());
					fm.setN_reserves(list.get(index).getTotalReserves());	
					fm.setN_fiutran(list.get(index).getTotalFiuBalance());
					fm.setN_dcCollected(list.get(index).getDcCollected());
					fm.setN_dcAccrual(list.get(index).getDiscountCharges());		
					//RLS (redd) 01/19/2011 change currency to advanced ratio per advice by ms rache 
					fm.setAdvancedRatio(rs.getDouble("advancedRatio"));
					getdate= Calendar.getInstance();					
					return fm;
				}	
			});

		return lFm;
	}

	//FACTORED RECIEVABLE
	@SuppressWarnings("unchecked")
	public List<FactoringManagement> getFactoringManagement3(String asOfDate, String branchCode)  {
		List<FactoringManagement> lFm = new ArrayList<FactoringManagement>();

		final String strAsOfDate = asOfDate;
		Date dAsOfDate = DateHelper.parse(asOfDate);

		SimpleDateFormat sdfMo = new SimpleDateFormat("MM");		

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dAsOfDate);
		calendar.add(Calendar.MONTH, -11);
		String dunningFrom = DateHelper.format(calendar.getTime());
		
		calendar.setTime(dAsOfDate);
		calendar.add(Calendar.MONTH, -5);
		String dunningFrom6mos = DateHelper.format(calendar.getTime());

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(dAsOfDate);

		String firstDayMo = sdfMo.format(dAsOfDate) + "/01/" + gc.get(GregorianCalendar.YEAR);

		String sSQL = " "+
				"SELECT	*, CASE WHEN q1.d_lastRefund <= q1.d_lastadvance THEN CASE WHEN d_lastadvance <=d_lastPayment then d_lastPayment else d_lastadvance end	"+
				"	else   CASE WHEN d_lastRefund <=d_lastPayment then d_lastPayment else d_lastRefund end end d_lastDCCollected	"+
				"	FROM("+
				"		SELECT CASE WHEN sum(distinct(a.status)) = 1 THEN 'CURRENT'	"+
				"		WHEN sum(distinct(a.status)) = 2 THEN 'DELINQUENT'	"+
				"		WHEN sum(distinct(a.status)) = 3 THEN 'CURRENT AND DELINQUENT'	"+
				"		WHEN sum(distinct(a.status)) = 4 THEN 'PAST DUE'	"+
				"		WHEN sum(distinct(a.status)) = 5 THEN 'CURRENT AND PAST DUE'	"+
				"		WHEN sum(distinct(a.status)) = 6 THEN 'DELINQUENT AND PASTDUE'	"+
				"		WHEN sum(distinct(a.status)) = 7 THEN 'CURRENT AND DELINQUENT AND PASTDUE'	"+
				"		END AS c_Status,	"+
				"		cc.c_clntcode,	"+
				"		cc.c_name,	"+
				"		ao.c_name AS aoName,	"+
				"		ISNULL(cc.N_ADVANCEDRATIO,0.00)/100 AS advancedRatio,	"+
				"		ISNULL((100-cc.N_ADVANCEDRATIO),0.00)/100 AS n_CERatio,	"+
				"		ISNULL(cc.n_investmentlimit,0) AS n_investmentlimit,	"+
				"		ISNULL(adv.n_svcchg,0) AS n_serviceCharge,	"+
				"		ISNULL(ref.n_penaltyCharge,0)+ISNULL(adv.n_penaltychg,0)+ISNULL(rh.n_penaltychg,0) AS n_penaltyCharge,	"+
				"		ISNULL(rh.CN_N_AMOUNT,0) as n_CreditNote,	"+
				"		ISNULL(rh.N_AMOUNT,0) as n_receipts,	"+
				"		ISNULL(rh.N_OVERPAYMENT,0) as n_overpayment,	"+
				"		((ISNULL(rh.CN_N_AMOUNT,0)+ISNULL(rh.N_AMOUNT,0))*ISNULL((100-cc.N_ADVANCEDRATIO)/100,0.00))+ISNULL(rh.N_OVERPAYMENT,0) as n_CEPaid,	"+
				/*"		max(ref.d_transactiondate) AS d_lastRefund,	"+
				"		max(rh.d_transactiondate) AS d_lastPayment,	"+
				"		max(adv.d_transactiondate) AS d_lastadvance,	"+*/
				"		d_lastRefund =(select max(d_transactiondate) from refund where c_clntcode =cc.c_clntcode  AND d_transactiondate <='"+asOfDate+"' AND c_status=2),	"+
				"		d_lastPayment =(select max(d_transactiondate) from receiptshdr where c_clntcode =cc.c_clntcode  AND d_transactiondate <='"+asOfDate+"' AND d_datebounced is null),	"+
				"		d_lastadvance =(select max(d_transactiondate) from advances where c_clntcode =cc.c_clntcode  AND d_transactiondate <='"+asOfDate+"' AND c_status=2),	"+
				"		CASE WHEN max(adv.d_transactiondate)<=max(ref.d_transactiondate) THEN max(ref.d_transactiondate)	"+
				"		ELSE max(adv.d_transactiondate) END AS d_lastDCCollected,	"+
				"		cc.n_settlement AS n_Term,	"+
				"		cc.d_reviewDate,	"+
				"		cc.IndCd AS n_IndustryCode,	"+
				"		id.c_desc AS c_Industry,	"+
				"		bt.c_desc AS c_SizeOfFirm,	"+
				"		ISNULL(cc.n_dcr,0) as n_dcr,	"+
				"		ISNULL(adj.n_amount,0) as n_DCAdjustment,	"+
				"		max(a.pastDueDate) as d_PDODate,	"+
				"		(select dbo.GetDunning (cc.c_clntcode,5,'"+dunningFrom+"', '"+asOfDate+"')) as n_avgDunning,	"+
				"		(select dbo.GetDunning (cc.c_clntcode,5,'"+dunningFrom6mos+"', '"+asOfDate+"')) as n_avgDunning6mos	"+
				"	FROM	"+
				"		dbcif.dbo.client cc	 "+
				"	INNER JOIN	 "+
				"		accountofficer ao	 "+
				"		ON ao.c_acctofficercode = cc.c_acctofficercode	 "+
				"	LEFT JOIN (	"+
				"		select inv.*,CASE WHEN dateadd(day,90+1,dateadd(day,cc.n_dunning,d_invoicedate))<='"+asOfDate+"' THEN  dateadd(day,90+1,dateadd(day,cc.n_dunning,d_invoicedate))  ELSE NULL END as pastDueDate,	"+
				"				  CASE WHEN dateadd(day,cc.n_dunning,d_invoicedate)<='"+asOfDate+"' THEN	"+	 
				"				  CASE WHEN dateadd(day,90+1,dateadd(day,cc.n_dunning,d_invoicedate))<='"+asOfDate+"' THEN 4 ELSE 2 END	"+	
				"				  ELSE 1 END AS Status	"+
				"		FROM INVOICE inv	"+
				"		INNER JOIN CC cc	"+
				"			ON cc.c_clntcode = inv.c_clntcode AND cc.c_custcode = inv.c_custcode	"+
				"				WHERE (d_fullypaiddate > '"+asOfDate+"' OR d_fullypaiddate IS NULL) AND inv.c_status <> '7'	" +
				"				AND inv.d_transactiondate <= '"+asOfDate+"'	"+
				"				)a	  "+
				"		ON a.c_clntcode = cc.c_clntcode	 "+
				"	LEFT OUTER JOIN	"+
				"		monthlybalances mb	 "+
				"		on mb.c_clntcode = cc.c_clntcode	 "+
				"	LEFT OUTER JOIN	 "+
				"		borrtype bt	"+
				"		on cc.c_borwtype=bt.c_borwtype	"+
				"	LEFT OUTER JOIN	"+
				"		industrydetail id	"+
				"		on cc.IndCd=id.IndCd	"+
				"	LEFT OUTER JOIN	 "+
				"		industryHeader ih	"+
				"		on id.DivCd=ih.DivCd	"+
				"	LEFT OUTER JOIN	"+
				"		(SELECT c_clntcode,	"+
				"			ISNULL(sum(n_svcchg),0) as n_svcchg, "+
				"			ISNULL(sum(n_penaltychg),0) as n_penaltychg,	"+
				"			ISNULL(sum(n_pdinterest),0) as n_pdinterest,	"+
				"			MAX(d_transactiondate) as d_transactiondate "+
				"			 FROM advances "+
				"			 WHERE d_transactiondate BETWEEN   '"+firstDayMo+"' AND '"+asOfDate+"' "+
				"				AND C_STATUS<>3	"+
				"			 GROUP BY c_clntcode) adv	"+
				"		ON adv.c_clntcode = cc.c_clntcode	"+
				"	LEFT OUTER JOIN	"+
				"		 (SELECT c_clntcode,	"+ 
				"				sum(n_refamt)AS refAmt,	"+ 
				"				sum(n_pdinterest) AS pdInterest,	"+ 
				"				sum(n_penaltychg) as n_penaltyCharge,	"+
				"				max(d_transactiondate) as d_transactiondate	"+
				"		FROM refund where c_status<>3	"+  
				"			and d_transactiondate BETWEEN   '"+firstDayMo+"' AND '"+asOfDate+"'    GROUP BY c_clntcode)ref	" +
				"		on ref.c_clntcode= cc.c_clntcode	"+
				"	LEFT OUTER JOIN	 	"+
				"		 (SELECT rh.C_CLNTCODE,	"+
				"			SUM(ISNULL(rh.N_AMOUNT,0)-ISNULL(rh.N_OPAMT,0)) as N_AMOUNT,	"+
				"			SUM(cn.N_AMOUNT) as CN_N_AMOUNT,	"+
				"			SUM(rh.N_OPAMT) as N_OVERPAYMENT,	"+
				"			ISNULL(sum(rh.n_penaltychg),0) as n_penaltychg,	"+
				"			ISNULL(sum(n_pdinterest),0) as n_pdinterest,	"+
				"			MAX(rh.d_transactiondate) as d_transactiondate	"+
				"	FROM ReceiptsHdr rh	"+
				"			LEFT OUTER JOIN	"+
				"				(select SUM(N_AMOUNT) as N_AMOUNT,C_RECEIPTNO,C_CLNTCODE from CreditNote where " +
				//"				D_TRANSACTIONDATE between '"+firstDayMo+"' AND '"+asOfDate+"' " +
				"				(d_cancelledDate>'"+asOfDate+"' OR d_cancelledDate IS NULL) GROUP by C_CLNTCODE,C_RECEIPTNO)	cn	"+
				"				ON cn.C_RECEIPTNO = rh.N_REFNO	" +
				"				AND rh.C_CLNTCODE = cn.C_CLNTCODE"+
				"			LEFT OUTER JOIN 	"+
				"				refund  ref 	"+
				"				on rh.n_refundrefno = ref.n_refno		"+
				"	WHERE 	"+
				//"		rh.D_TRANSACTIONDATE between '"+firstDayMo+"' AND '"+asOfDate+"'	"+
				"		  (ref.d_transactiondate < '"+asOfDate+"' OR ref.n_refno IS NULL) 	"+
				"		AND (d_datebounced>'"+asOfDate+"' OR d_datebounced IS NULL) 	" +
				"		AND rh.d_transactiondate <='"+asOfDate+"'	"+
				"		AND rh.C_RECEIPTTYPE IN ('1', '2','3','4')  	"+
				"	GROUP BY rh.C_CLNTCODE) rh 	"+
				"	on rh.C_CLNTCODE = cc.C_CLNTCODE	"+
				"	LEFT OUTER JOIN			"+
				"		(SELECT sum(ISNULL(adj.n_amount,0)) as n_amount,adj.c_clntcode FROM adjustment adj		"+
				"		INNER JOIN AdjustmentType	 	"+
				"		ON adj.C_ADJCODE = AdjustmentType.C_ADJCODE		"+
				"		INNER JOIN	 	"+
				"		chartofaccounts coa		"+
				"		ON AdjustmentType.c_glcode = coa.c_icbsglcode		"+
				"		WHERE (d_transactiondate BETWEEN '"+firstDayMo+"' AND '"+asOfDate+"')		" +
				"		AND c_status IN (1,2)"+
				"		GROUP BY adj.c_clntcode		"+
				"		)adj		"+
				"		on cc.c_clntcode = adj.c_clntcode		"+
				"	WHERE	 	"+
				"		cc.c_clntcode>=124	AND 	"+
				//"		cc.c_clntcode in (267,301,302)	AND 	"+
				"		cc.C_STATUS = 1	 	"+
				"	GROUP BY	 	"+
				"		cc.c_clntcode,	 	"+
				"		cc.c_name,	 	"+
				"		ao.c_name,	 	"+
				"		cc.c_currencycode,	 	"+
				"		cc.n_investmentlimit, 		"+
				"		cc.n_receivables, 		"+
				"		cc.n_reserves,	 	"+
				"		cc.n_fiutran,		"+
				"		cc.d_effdate,	 	"+
				"		mb.N_AUGFIU,	"+
				"		mb.N_AUGREC,	"+
				"		mb.N_AUGRES,	"+
				"		cc.N_ADVANCEDRATIO,	"+
				"		bt.c_desc,		"+
				"		cc.n_assets,		"+
				"		cc.n_liabilities,		"+
				"		cc.n_equity,		"+
				"		cc.n_grossincome,		"+
				"		cc.n_expenses,		"+
				"		cc.n_netincome,		"+
				"		cc.d_auditeddate,		"+
				"		cc.c_tin,	"+
				"		cc.IndCd,	"+
				"		id.c_desc,	"+
				"		ih.c_desc,	"+
				"		cc.d_reviewDate,	"+
				"		cc.n_settlement,	"+
				"		n_scr,	"+
				"		cc.n_dcr,	"+
				"		adj.n_amount,	"+
				"		adv.n_svcchg,	"+
				"		rh.CN_N_AMOUNT,	"+
				"		rh.N_AMOUNT,	"+
				"		rh.N_OVERPAYMENT,	"+
				"		ref.n_penaltyCharge,	"+
				"		adv.n_penaltychg,	" +
				"		rh.n_penaltychg	" +
				"	)q1	"+
				"	ORDER BY	"+
				"		c_clntcode	";

		final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

		log.info("Query "+sSQL);

			lFm  = getJdbcTemplate().query(sSQL,new BeanPropertyRowMapper(FactoringManagement.class));
			for(int x =0 ; x<lFm.size();x++){

				ClientDAO cld = new ClientDAO();
				List<ClientActivities> list = cld.getClientActivities(lFm.get(x).getC_ClntCode(), strAsOfDate);
				int index=list.size()-1;
				lFm.get(x).setN_receivables(list.get(index).getTotalReceivables());
				lFm.get(x).setN_reserves(list.get(index).getTotalReserves());	
				lFm.get(x).setN_fiutran(list.get(index).getTotalFiuBalance());	
				lFm.get(x).setN_dcAccrual(list.get(index).getDiscountCharges());
				lFm.get(x).setN_dcCollected(list.get(index).getDcCollected());
				lFm.get(x).setCEUnpaid(list.get(index).getTotalReceivables()*(1-lFm.get(x).getAdvancedRatio()));
				//lFm.get(x).setN_CreditNote(list.get(index).getCreditNotes());
				Double CEPaid = ((lFm.get(x).getN_CreditNote()+lFm.get(x).getN_receipts())*lFm.get(x).getN_CERatio())+lFm.get(x).getN_overpayment();
				lFm.get(x).setN_CEPaid(CEPaid);

				lFm.get(x).setN_ClntEquity(lFm.get(x).getN_CEPaid()+lFm.get(x).getCEUnpaid());
				lFm.get(x).setN_serviceCharge(list.get(index).getServiceCharges());



				//CHARGES
				Map chargesMap = new HashMap();
				Double dcr = 0.0;
				try{
					chargesMap = getJdbcTemplate().queryForMap("SELECT top 1 d_date,ISNULL(n_curValue,0) AS n_curValue FROM ratesHistory WHERE d_date<= '"+asOfDate+"' AND c_clntcode = "+lFm.get(x).getC_ClntCode()+"and c_charge='DCR' ORDER BY d_date desc, id desc");
					dcr=Double.parseDouble(chargesMap.get("n_curValue").toString());
					lFm.get(x).setN_dcr(dcr);
				}catch(EmptyResultDataAccessException e){
					log.info("Discount Rate Unchanged");
				}

				//AdvanceRatio
				try{
					chargesMap = getJdbcTemplate().queryForMap("SELECT top 1 d_Date,ISNULL(n_PrevValue,0) AS n_PrevValue FROM ratesHistory WHERE d_date<= '"+asOfDate+"' AND c_clntcode = "+lFm.get(x).getC_ClntCode()+" and c_charge='ADVRATIO' ORDER BY d_date desc, id desc");
					lFm.get(x).setD_AdvRatioChanged(SDF.parse(chargesMap.get("d_Date").toString()));
					lFm.get(x).setN_prevAdvRate(Double.parseDouble(chargesMap.get("n_PrevValue").toString()));
				}catch (ParseException e) {
					e.printStackTrace();
				}catch(EmptyResultDataAccessException e){
					log.info("Ratio Unchanged");
				}

				//PREVIOUS DISCOUNT CHARGE
				try{
					chargesMap = getJdbcTemplate().queryForMap("SELECT	"+
						"max(d_date) as d_date,ISNULL(SUM(ISNULL(n_prevValue,0))/100,0) as DCRATE	"+ 
					"FROM(	"+
						"SELECT	"+
							"*	"+
						"FROM(	"+
							"SELECT	"+
								"TOP 1  *	"+ 
							"FROM	"+
								"rateshistory	"+ 
							"WHERE	"+
								"c_charge IN ( 'blr','dcr')	"+
								"AND d_date <='"+asOfDate+"'	"+
								"AND '"+asOfDate+"' BETWEEN d_CurBLRFrom AND d_CurBLRTo	"+  
								"AND c_clntcode ="+lFm.get(x).getC_ClntCode()+"	"+
							"ORDER BY	"+
								"id DESC	"+
							")q1	"+
						"UNION	"+
						"SELECT	"+ 
							"*	"+
						"FROM(	"+
							"SELECT	"+
								"TOP 1 *	"+
							"FROM	"+
								"rateshistory	"+ 
							"WHERE	"+
								"c_charge = 'dcr'	"+
								"AND d_date <='"+asOfDate+"'	"+
								"AND c_clntcode ="+lFm.get(x).getC_ClntCode()+"	"+
							"ORDER BY	"+
								"id DESC	"+
							")q2	"+
						")a	"+
					"");
					String d_date = chargesMap.get("d_date")!=null?chargesMap.get("d_date").toString():null;

					if(d_date !=null){
						lFm.get(x).setD_DCRateChanged(SDF.parse(d_date));
					}

					Double discountCharge = Double.parseDouble(chargesMap.get("DCRATE").toString());

					/*if(dcr==0 && discountCharge !=0){
						discountCharge = discountCharge + (lFm.get(x).getN_dcr()/100);
					}
					else
						discountCharge = null;*/

					lFm.get(x).setN_prevDCRate(discountCharge);

				}catch (ParseException e) {
					e.printStackTrace();
				}

				Map BLRMap= new HashMap();
				try {
					BLRMap = getJdbcTemplate().queryForMap("select * from dbo.getBLRFile ("+lFm.get(x).getC_ClntCode()+",'"+asOfDate+"')");
					if (!BLRMap.isEmpty()){
							lFm.get(x).setD_BlrFrom(SDF.parse(BLRMap.get("effDate").toString()));
							lFm.get(x).setD_BlrTo(SDF.parse(BLRMap.get("expDate").toString()));
							lFm.get(x).setN_DCRate((Double.parseDouble(BLRMap.get("blrVal").toString())+lFm.get(x).getN_dcr())/100);
					}
				} catch (ParseException e) {
						e.printStackTrace();
				} catch (EmptyResultDataAccessException e){
					log.info("No Valid BLR For This Date");
					lFm.get(x).setN_DCRate(lFm.get(x).getN_dcr()/100);
				}
			}

		return lFm;
	}
}
