package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.ReportField;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

public class ReportFieldDataSource   implements JRDataSource{

	List<?> list= new ArrayList<ReportField>();
	private int index =-1;
	private int lastIndex = 0;
	

	//SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	//DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	
	public ReportFieldDataSource(List<?> list){
		this.list= list;
		lastIndex= this.list.size();		
	}
	

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		  FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Object value = null;
		String field = jRField.getName();		
		if(list.size()>0){
			ReportField rf = (ReportField)list.get(index);
			
			if("clientCode".equals(field)){   			
				value=rf.getClientCode();
			}
			if("transactionDate".equals(field)){   			
				value=rf.getTransactionDate();
			}
			if("clientName".equals(field)){   			
				value=rf.getClientName();
			}
			if("customerName".equals(field)){   			
				value=rf.getCustomerName();
			}			
			if("invoiceAmount".equals(field)){   			
				value=rf.getInvoiceAmount();
			}	
			if("invoiceNumber".equals(field)){   			
				value=rf.getInvoiceNumber();
			}
			if("accountOfficer".equals(field)){   			
				value=rf.getAccountOfficer();
			}
			if("advanceRefNumber".equals(field)){   			
				value=rf.getAdvanceRefNumber();
			}
			if("nTerm".equals(field)){   			
				value=rf.getInvoiceAmount();
			}
			if("oS_InvAmt".equals(field)){   			
				value=rf.getOS_InvAmt();
			}			
			if("fullyPaidDate".equals(field)){   			
				value=rf.getFullyPaidDate();
			}			
			if("receiptAmount".equals(field)){   			
				value=rf.getReceiptAmount();
			}
			if("discChargeCollected".equals(field)){   			
				value=rf.getDiscChargeCollected();
			}
			if("discountCharge".equals(field)){   			
				value=rf.getDiscountCharge();
			}
			if("serviceCharge".equals(field)){   			
				value=rf.getServiceCharge();
			}
			if("dscRate".equals(field)){   			
				value=rf.getDscRate();
			}
			if("scrRate".equals(field)){   			
				value=rf.getScrRate();
			}
			if("advanceRatio".equals(field)){   			
				value=rf.getAdvanceRatio();
			}
			if("creditNoteAmount".equals(field)){   			
				value=rf.getCreditNoteAmount();
			}
			if("invoiceDate".equals(field)){   			
				value=rf.getInvoiceDate();
			}	
			if("discAccrual".equals(field)){   			
				value=rf.getDiscAccrual();
			}
			
			
			if("refundNumber".equals(field)){   			
				value=rf.getRefundNumber();
			}			
			if("refundDiscCharge".equals(field)){   			
				value=rf.getRefundDiscCharge();
			}	
			if("refundAmount".equals(field)){   			
				value=rf.getRefundAmount();
			}	
			

			if("discChargeAdvanceSum".equals(field)){   			
				value=rf.getDiscChargeAdvanceSum();
			}
			if("discChargeRefundSum".equals(field)){   			
				value=rf.getDiscChargeRefundSum();
			}
			if("totalDiscount".equals(field)){   			
				value=rf.getTotalDiscount();
			}				
			if("serviceChargeAdvanceSum".equals(field)){   			
				value=rf.getServiceChargeAdvanceSum();
			}
			if("settingUpFee".equals(field)){   			
				value=rf.getSettingUpFee();
			}			
			if("discChargeSettingUpFeeSum".equals(field)){   			
				value=rf.getDiscChargeSettingUpFeeSum();
			}		

			//RLS(redd) 01/05/2010 additional column for monthly charges report
			if("adjustmentAmountSum".equals(field)){   			
				value=rf.getAdjustmentAmountSum();
			}	
			
			//RLS(redd) 01/06/2010 additional field for schedule of invoices report
			if("blrExpiryDate".equals(field)){   			
				value=rf.getBlrExpiryDate();
			}	

			//--RLS(redd)  01/12/2011 add column term in sched of invoice			
			if("invoiceTerm".equals(field)){   			
				value=rf.getInvoiceTerm();
			}	

			
			//--RLS(redd)  01/13/2011 Schedule of Advances	
			if("bankName".equals(field)){   			
				value=rf.getBankName();
			}	
			
			if("branchCode".equals(field)){   			
				value=rf.getBranchCode();
			}	
			
			if("bankCode".equals(field)){   			
				value=rf.getBankCode();
			}			
			
			if("branchName".equals(field)){   			
				value=rf.getBranchName();
			}
			
			if("accountOfficerCode".equals(field)){   			
				value=rf.getAccountOfficerCode();
			}	
			
			if("bankAccountNo".equals(field)){   			
				value=rf.getBankAccountNo();
			}	
			
			if("advanceAmount".equals(field)){   			
				value=rf.getAdvanceAmount();
			}			
			
			if("dcOfSettingUpFee".equals(field)){   			
				value=rf.getDcOfSettingUpFee();
			}	

			//RLS(redd) 01/19/2011 add to get sum of receivables per client in Schedule of Advances			
			if("receivable".equals(field)){   			
				value=rf.getReceivable();
			}				
			
			//RLS(redd) 01/24/2011 fields for activity log			
			if("logId".equals(field)){   			
				value=rf.getLogId();
			}	

			if("logTime".equals(field)){   			
				value=rf.getLogTime();
			}			
			
			if("userId".equals(field)){   			
				value=rf.getUserId();
			}	
			
			if("ipAddress".equals(field)){   			
				value=rf.getIpAddress();
			}
			
			if("details".equals(field)){   			
				value=rf.getDetails();
			}	
			
			//CVG as of 2/22/15
			if("count_inv".equals(field)){
				value=rf.getCount_inv();
			}
			
			
			//added by CVG as of 04-19-16
			if("cntAdvanceAmt".equals(field)){
				value=rf.getCntAdvanceAmt();
			}
			
			if("currentDate".equals(field)){
				value=date.newDate();
			}
			//parameter for Sched of Receipt
			//if("paymentType".equals(field)){
			//	value=rf.getPaymentType();
			//}
			
			
		}
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}
}
