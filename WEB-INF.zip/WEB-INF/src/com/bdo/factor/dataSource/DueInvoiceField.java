/*@ Added by	: Roldan Somontina
 * 	Java Name	: DueInvoiceField.java
 * 	Date Added	: May 20, 2009
 *  Source Code for Invoice Due Report
 */ 	

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class DueInvoiceField implements JRDataSource{
	private Logger log = Logger.getLogger(DueInvoiceField.class);
	
	List<Invoice> dueInvoiceList= new ArrayList<Invoice>();
	private int index =-1;
	private int lastIndex = 0;
	private String temp="";
	
	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	
	@SuppressWarnings("unchecked")
	public DueInvoiceField(String startDate,String endDate){
		Map param = new HashMap();
		param.put("startDate", startDate);
		param.put("endDate", endDate);
		INVOICEDAO invoiceDao = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
		dueInvoiceList = invoiceDao.getDueInvoiceForReport(param);
		lastIndex=dueInvoiceList.size();
	}
	
	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
        Object value = null;
    	String field = jRField.getName();
    	Invoice invoice = (Invoice)dueInvoiceList.get(index);
    	FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
    	if(dueInvoiceList.size()>0){
   		
    		if("clientName".equals(field)){
    			if(!temp.equals(invoice.getC_NAME())){
    				value=invoice.getC_NAME();
    				temp =invoice.getC_NAME();
    			}else{
    				value="------";
    			}
    		}   
    		if("customerName".equals(field)){
    			value=invoice.getC_CUSTNAME();
    		}      		
    		if("invoiceNumber".equals(field)){
    			value=invoice.getC_INVOICENO();    			
    		}   		
    		if("transactionDate".equals(field)){
    			value=sdf.format(invoice.getD_TRANSACTIONDATE());
    			log.info("sdf.format(invoice.getD_TRANSACTIONDATE()=>  "+sdf.format(invoice.getD_TRANSACTIONDATE()));
    			//value=invoice.getTransactionDate();
    			//log.info("invoice.getTransactionDate()= "+invoice.getTransactionDate());
    		}    		
    		if("invoiceDate".equals(field)){
    			value=sdf.format(invoice.getD_INVOICEDATE());
    			log.info("sdf.format(invoice.getD_INVOICEDATE())=> "+sdf.format(invoice.getD_INVOICEDATE()));
    			//value=invoice.getInvoiceDate();
    			//log.info("invoice.getInvoiceDate()= "+invoice.getInvoiceDate());
    		}
    		if("invoiceAmount".equals(field)){
    			value=df.format(invoice.getN_INVOICEAMT());
    			log.info("df.format(invoice.getN_INVOICEAMT()) "+df.format(invoice.getN_INVOICEAMT()));
    		}
    		
    		if("currentDate".equals(field)){
    			value = date.newDate();
    		}
    				
    	}
 	
		return value;
	}

	@Override
	public boolean next() throws JRException {
        index ++;
        if(index<lastIndex){
            return true;
        }
        return false;
	}
	
}