package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.ClientDebtTurn;
import com.bdo.factor.beans.PDC;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class PDCRegistryField implements JRDataSource{
	private Logger log = Logger.getLogger(PDCRegistryField.class);
	List<PDC> lPDC = new ArrayList<PDC> ();
	
	private int index =-1;
	private int lastIndex = 0;
	
	private String startDate;
	private String endDate;
	private String clientCode;
	private String branchCode;
	
	SimpleDateFormat sdf = new SimpleDateFormat ("mm/dd/yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	
	PDCRegistryDAO pdcDao = (PDCRegistryDAO)Persistence.getDAO("pdcRegistryDAO");
	
	public PDCRegistryField(String clientCode, String branchCode, String startDate, String endDate){
		this.startDate=startDate;
		this.endDate=endDate;
		this.branchCode=branchCode;
		this.clientCode=clientCode;		
		Map param = new HashMap();
		param.put("startDate", startDate);
		param.put("endDate", endDate);
		param.put("branchCode", branchCode);
		param.put("clientCode", clientCode);	
		
		lPDC = pdcDao.getPDC(clientCode, branchCode, startDate, endDate);
		lastIndex=lPDC.size();
	}

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Object value = null;
		String field = jRField.getName();
		PDC pdc = (PDC) lPDC.get(index);
		
		if(lPDC.size()>0){				
					      		
					if("clientName".equals(field)){
						value=pdc.getClientName();    			
					}   		
					if("customerName".equals(field)){
						value=pdc.getCustomerName();    			
					}
					if("checkType".equals(field)){
						value=pdc.getCheckType();    			
					}
					if("bankName".equals(field)){
						value=pdc.getBankName();    			
					}
					if("checkDate".equals(field)){
						value=DateHelper.format(pdc.getD_CheckedDate());    			
					}
					if("checkNo".equals(field)){
						value=pdc.getN_CheckNo();    			
					}
					if("checkAmount".equals(field)){
						value=df.format(pdc.getN_CheckAmount());    			
					}
					if("currencyCode".equals(field)){
						value=pdc.getCurrencyCode();    			
					}
					if("status".equals(field)){
						value=pdc.getStatus();    			
					}			
					if ("dateRange".equals(field)) {
						value = startDate + "-" + endDate;
					}				
					if ("currentDate".equals(field)) {
						value = date.newDate(); //
					}	
		}   


		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}
}
