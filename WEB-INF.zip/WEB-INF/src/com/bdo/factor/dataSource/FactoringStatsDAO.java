package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdo.factor.beans.FactoringStatistics;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.FactorConnection;
//import com.sun.net.ssl.internal.ssl.Debug;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.apache.log4j.Logger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class FactoringStatsDAO extends JdbcDaoSupport
{
	private static Logger log = Logger.getLogger(FactoringStatsDAO.class);
	public FactoringStatsDAO() 
	{}
	
	@SuppressWarnings("unchecked")
	public List<FactoringStatistics> getFactoringStatsDao(String branchCode, String clientCode, String monthYear)
	{
		int asOfMonth = Integer.parseInt(monthYear.substring(0, 2));
		String sSQL = "";
		String sSQLJanuary = "";
		String sSQLFebruary = "";
		String sSQLMarch = "";
		String sSQLApril = "";
		String sSQLMay = "";
		String sSQLJune = "";
		String sSQLJuly = "";
		String sSQLAugust = "";
		String sSQLSeptember = "";
		String sSQLOctober = "";
		String sSQLNovember = "";
		String sSQLDecember = "";
		
		if (asOfMonth >= 1)
		{
			sSQLJanuary = this.getMonthSQL(1, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLJanuary= " SELECT" +
						 " 1 AS MonthNumber, " +	
						 " '"+this.getMonthName(1)+"' AS MonthName," +
						 " 0 InvoicesPrev," +
						 " 0 AS InvoicesCurrent," +
						 " 0 CollectionPrev," +
						 " 0 AS CollectionCurrent," +
						 " 0 AS FIUPrev," +
						 " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 2)
		{
			sSQLFebruary = this.getMonthSQL(2, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLFebruary = " SELECT" +
						   " 2 AS MonthNumber, " +
						   " '"+this.getMonthName(2)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   " 0 AS FIUPrev," +
						   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 3)
		{
			sSQLMarch = this.getMonthSQL(3, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLMarch = " SELECT" +
						   " 3 AS MonthNumber, " +
						   " '"+this.getMonthName(3)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   " 0 AS FIUPrev," +
						   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 4)
		{
			sSQLApril = this.getMonthSQL(4, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLApril = " SELECT" +
					       " 4 AS MonthNumber, " +
						   " '"+this.getMonthName(4)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   " 0 AS FIUPrev," +
						   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 5)
		{
			sSQLMay = this.getMonthSQL(5, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLMay = " SELECT" +
						   " 5 AS MonthNumber, " +
						   " '"+this.getMonthName(5)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   " 0 AS FIUPrev," +
						   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 6)
		{
			sSQLJune = this.getMonthSQL(6, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLJune = " SELECT" +
						   " 6 AS MonthNumber, " +	 
						   " '"+this.getMonthName(6)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   " 0 AS FIUPrev," +
						   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 7)
		{
			sSQLJuly = this.getMonthSQL(7, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLJuly = " SELECT" +
					   " 7 AS MonthNumber, " +
					   " '"+this.getMonthName(7)+"' AS MonthName," +
					   " 0 InvoicesPrev," +
					   " 0 AS InvoicesCurrent," +
					   " 0 CollectionPrev," +
					   " 0 AS CollectionCurrent," +
					   " 0 AS FIUPrev," +
					   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 8)
		{
			sSQLAugust = this.getMonthSQL(8, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLAugust = " SELECT" +
					   " 8 AS MonthNumber, " +	
					   " '"+this.getMonthName(8)+"' AS MonthName," +
					   " 0 InvoicesPrev," +
					   " 0 AS InvoicesCurrent," +
					   " 0 CollectionPrev," +
					   " 0 AS CollectionCurrent," +
					   " 0 AS FIUPrev," +
					   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 9)
		{
			sSQLSeptember = this.getMonthSQL(9, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLSeptember = " SELECT" +
						    " 9 AS MonthNumber, " +
						    " '"+this.getMonthName(9)+"' AS MonthName," +
						    " 0 InvoicesPrev," +
						    " 0 AS InvoicesCurrent," +
						    " 0 CollectionPrev," +
						    " 0 AS CollectionCurrent," +
						    " 0 AS FIUPrev," +
						    " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 10)
		{
			sSQLOctober = this.getMonthSQL(10, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLOctober = " SELECT" +
						   " 10 AS MonthNumber, " +	
						   " '"+this.getMonthName(10)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   " 0 AS FIUPrev," +
						   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 11)
		{
			sSQLNovember = this.getMonthSQL(11, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLNovember = " SELECT" +
						   " 11 AS MonthNumber, " + 
						   " '"+this.getMonthName(11)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   " 0 AS FIUPrev," +
						   " 0 AS FIUCurr" ;
		}
		
		if (asOfMonth >= 12)
		{
			sSQLDecember = this.getMonthSQL(12, branchCode, clientCode, monthYear); 				
		}
		else
		{
			sSQLDecember = " SELECT" +
						   " 12 AS MonthNumber, " +	
						   " '"+this.getMonthName(12)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   " 0 AS FIUPrev," +
						   " 0 AS FIUCurr" ;
		}
		
		
		sSQL = "SELECT MonthNumber, MonthName, ROUND(SUM(InvoicesPrev), 3) AS prevInvoice, " +
			   "ROUND(SUM(InvoicesCurrent), 3) AS currInvoice, " +
			   "ROUND(SUM(CollectionPrev), 3) AS prevCollection, " +
			   "ROUND(SUM(CollectionCurrent), 3) AS currCollection, " +
			   "ROUND(SUM(FIUPrev), 3) AS prevFIU, " +
			   "ROUND(SUM(FIUCurr), 3) AS currFIU, " +
	   		   "(SELECT DISTINCT(ClientName) FROM CSO WHERE C_CLNTCODE = '"+clientCode+"' AND C_BRANCHCODE = '"+branchCode+"') AS clientName, " +
	   		   "(SELECT DISTINCT(ServiceOfficerName) FROM CSO WHERE C_CLNTCODE = '"+clientCode+"' AND C_BRANCHCODE = '"+branchCode+"') AS serviceOfficer " +
			   "FROM " +
			   "(" +
					sSQLJanuary + 
					" UNION " +
					sSQLFebruary + 
					" UNION " +
					sSQLMarch + 
					" UNION " +
					sSQLApril + 
					" UNION " +
					sSQLMay + 
					" UNION " +
					sSQLJune + 
					" UNION " +
					sSQLJuly + 
					" UNION " +
					sSQLAugust + 
					" UNION " +
					sSQLSeptember + 
					" UNION " +
					sSQLOctober + 
					" UNION " +
					sSQLNovember + 
					" UNION " +
					sSQLDecember + 					
			   ")AS derivedTable " +
			   "GROUP BY MonthName, MonthNumber " +
			   "ORDER By MonthNumber ";
		
		log.info("[debug][getFactoringStatsDao]" + sSQL);
		
		List<FactoringStatistics> factoringStatsLists = new ArrayList<FactoringStatistics>();
		
		factoringStatsLists = getJdbcTemplate().query(sSQL, new RowMapper(){
				@Override					
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException
				{
					FactoringStatistics factoringStats = new FactoringStatistics();
						factoringStats.setMonthName(rs.getString("MonthName"));
						factoringStats.setCurrInvoiceAmt(rs.getDouble("currInvoice"));
						factoringStats.setPrevInvoiceAmt(rs.getDouble("prevInvoice"));
						factoringStats.setPrevCollection(rs.getDouble("prevCollection"));
						factoringStats.setCurrCollection(rs.getDouble("currCollection"));
						factoringStats.setCurrFIU(rs.getDouble("currFIU"));
						factoringStats.setPrevFIU(rs.getDouble("prevFIU"));
						factoringStats.setClientName(rs.getString("clientName"));						
						factoringStats.setServiceOfficerName(rs.getString("serviceOfficer"));
					return factoringStats;					
				}
			}
		);
		
		
		return factoringStatsLists;
	}
	
	
	private String getMonthSQL(int monthNumber, String branchCode, String clientCode, String monthYear)
	{				
		String sqlQuery	= "SELECT " +
						  monthNumber+" AS MonthNumber, " +	
		  				  "'"+getMonthName(monthNumber)+"' AS MonthName, " +
		  				  " 0 InvoicesPrev, " +
		  				  " ISNULL(SUM(ISNULL(Invoice.N_INVOICEAMT, 0)),0) AS InvoicesCurrent, " +
		  				  " 0 CollectionPrev, " +
		  				  "0 AS CollectionCurrent, " +
		  				  "0 AS FIUPrev, " +
		  				  "0 AS FIUCurr " +
		  				  "FROM " +
		  				  "Invoice " +
		  				  "WHERE " +
		  				  "MONTH(Invoice.D_TRANSACTIONDATE) = "+monthNumber+" " +
		  				  "AND " +
		  				  "YEAR(Invoice.D_TRANSACTIONDATE) = YEAR('"+monthYear+"') " +
		  				  "AND Invoice.C_CLNTCODE = '"+clientCode+"' " +
		  				  " AND Invoice.C_STATUS <> 7 " +
		  				  
		  				  
		  				  "	UNION " +
		  				  
		  				  "	SELECT " +
		  				  monthNumber+" AS MonthNumber, " +
						  "	'"+getMonthName(monthNumber)+"' AS MonthName, " +
						  "	ISNULL(SUM(ISNULL(Invoice.N_INVOICEAMT, 0)),0) InvoicesPrev, " +
						  "	0 AS InvoicesCurrent, " +
						  "	0 CollectionPrev, " +
						  "	0 AS CollectionCurrent, " +
						  "	0 AS FIUPrev, " +
						  "	0 AS FIUCurr " +
						  "	FROM " +
						  "	Invoice " +
						  "	WHERE " +
						  "	MONTH(Invoice.D_TRANSACTIONDATE) = "+monthNumber+" " +
						  "	AND " +
						  "	YEAR(Invoice.D_TRANSACTIONDATE) = (YEAR('"+monthYear+"') - 1) " +
						  "	AND Invoice.C_CLNTCODE = '"+clientCode+"' " +
						  " AND Invoice.C_STATUS <> 7 " +
						  
						  "	UNION " +
						  
						  "	SELECT " +
						  monthNumber+" AS MonthNumber, " +
						  "	'"+getMonthName(monthNumber)+"' AS MonthName, " +
						  "	0 InvoicesPrev, " +
						  "	0 AS InvoicesCurrent, " +
						  "	0 CollectionPrev, " +
						  "	ISNULL(SUM(ISNULL(ReceiptsHdr.N_AMOUNT, 0)),0) AS CollectionCurrent, " +
						  "	0 AS FIUPrev, " +
						  "	0 AS FIUCurr " +
						  " FROM " +
						  "	ReceiptsHdr " +
						  "	WHERE " + 
						  "	ReceiptsHdr.C_CLNTCODE = '"+clientCode+"' " +
						  "	AND  " +
						  " MONTH(ReceiptsHdr.D_TRANSACTIONDATE) = "+monthNumber+" " +
						  " AND" +
						  "	YEAR(ReceiptsHdr.D_TRANSACTIONDATE) = YEAR('"+monthYear+"')" +
						  
						  " UNION " +
						  
						  " SELECT " +
						  monthNumber+" AS MonthNumber, " +
						  " '"+getMonthName(monthNumber)+"' AS MonthName," +
						  " 0 InvoicesPrev," +
						  " 0 AS InvoicesCurrent," +
						  " ISNULL(SUM(ISNULL(ReceiptsHdr.N_AMOUNT, 0)),0) CollectionPrev," +
						  " 0 AS CollectionCurrent," +
						  " 0 AS FIUPrev," +
						  " 0 AS FIUCurr" +
						  " FROM" +
						  " ReceiptsHdr" +
						  " WHERE" +
						  " ReceiptsHdr.C_CLNTCODE = '"+clientCode+"' " +
						  " AND" +
						  " MONTH(ReceiptsHdr.D_TRANSACTIONDATE) = "+monthNumber+" " +
						  " AND" +
						  " YEAR(ReceiptsHdr.D_TRANSACTIONDATE) = (YEAR('"+monthYear+"') - 1)" +
						  
						  " UNION " +
						  
						  this.getMonthlyBalancesFiu(monthNumber, clientCode, monthYear);
		
		return sqlQuery;
	}
	
	private String getMonthName(int monthNumber)
	{
		String retval = "";
		switch (monthNumber)
		{
			case 1:
			retval = "January";
			break;
			
			case 2:
			retval = "February";
			break;
			
			case 3:
			retval = "March";
			break;
			
			case 4:
			retval = "April";
			break;
			
			case 5:
			retval = "May";
			break;
			
			case 6:
			retval = "June";
			break;
			
			case 7:
			retval = "July";
			break;
			
			case 8:
			retval = "August";
			break;
			
			case 9:
			retval = "September";
			break;
			
			case 10:
			retval = "October";
			break;
			
			case 11:
			retval = "November";
			break;
			
			case 12:
			retval = "December";
			break;
		}
		
		return retval;
	}
	
	private String getMonthlyBalancesFiu(int monthNumber, String clientCode, String theYear)
	{
		
		String fiu = "";
		String asOfDate="";
		ClientDAO clntDao = new ClientDAO();
		if (monthNumber == 1)
		{	
			log.info("[debug]theYear:->"+theYear.substring(6));			
			asOfDate = DateHelper.getLastDateOfTheMonth("01/01/"+theYear.substring(6));
			System.out.println("[debug]->"+asOfDate);
			fiu =  " SUM(ISNULL(N_PREVJANFIU, 0)) AS FIUPrev," +
				   clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
			       //" SUM(ISNULL(N_JANFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 2)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("02/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);			
			fiu = " SUM(ISNULL(N_PREVFEBFIU, 0)) AS FIUPrev," +
				clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				  //" SUM(ISNULL(N_FEBFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 3)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("03/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVMARFIU, 0)) AS FIUPrev," +
				 clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				 // " SUM(ISNULL(N_MARFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 4)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("04/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVAPRFIU, 0)) AS FIUPrev," +
				  clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				  //" SUM(ISNULL(N_APRFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 5)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("05/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVMAYFIU, 0)) AS FIUPrev," +
				  clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				  //" SUM(ISNULL(N_MAYFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 6)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("06/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVJUNFIU, 0)) AS FIUPrev," +
				  clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				  //" SUM(ISNULL(N_JUNFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 7)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("07/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVJULFIU, 0)) AS FIUPrev," +
			clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				  //" SUM(ISNULL(N_JULFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 8)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("08/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVAUGFIU, 0)) AS FIUPrev," +
			clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				 //" SUM(ISNULL(N_AUGFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 9)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("09/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVSEPFIU, 0)) AS FIUPrev," +
			clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				  //" SUM(ISNULL(N_SEPFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 10)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("01/10/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVOCTFIU, 0)) AS FIUPrev," +
				clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				//" SUM(ISNULL(N_OCTFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 11)
		{
			asOfDate = DateHelper.getLastDateOfTheMonth("11/01/"+theYear.substring(6));
			log.info(asOfDate);
			fiu = " SUM(ISNULL(N_PREVNOVFIU, 0)) AS FIUPrev," +
				clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;  
				//" SUM(ISNULL(N_NOVFIU, 0)) AS FIUCurr" ;
		}
		else if (monthNumber == 12)
		{					
			asOfDate = DateHelper.getLastDateOfTheMonth("12/01/"+theYear.substring(6));
			log.info("[debug]->"+asOfDate);
			fiu = " SUM(ISNULL(N_PREVYRFIU, 0)) AS FIUPrev," +
			clntDao.getClientFIUbyAsOfDate(clientCode, asOfDate)+" AS FIUCurr" ;
				  //" SUM(ISNULL(N_DECFIU, 0)) AS FIUCurr" ;
		}
		
		String sqlString = " SELECT " +
						   monthNumber+" AS MonthNumber, " +
						   " '"+this.getMonthName(monthNumber)+"' AS MonthName," +
						   " 0 InvoicesPrev," +
						   " 0 AS InvoicesCurrent," +
						   " 0 CollectionPrev," +
						   " 0 AS CollectionCurrent," +
						   fiu +						   
						   " FROM" +
						   " monthlyBalances" +
						   " WHERE " +
						   " monthlyBalances.C_CLNTCODE = '"+clientCode+"'	" ;
		
		return sqlString;
	}
	
	
	
	/*public static void main (String[] args) 
	{
		//FactoringStatsDAO factoringstatsdao = new FactoringStatsDAO();
		//List str = factoringstatsdao.getFactoringStatsDao("02", "38", "07/01/2009");
	}*/
	
}
