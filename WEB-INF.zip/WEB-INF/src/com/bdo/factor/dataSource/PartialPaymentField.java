package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.PDC;
import com.bdo.factor.beans.PartialPayment;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class PartialPaymentField implements JRDataSource{
	private Logger log = Logger.getLogger(PartialPaymentField.class);
	List<PartialPayment> lPayment = new ArrayList<PartialPayment> ();
	
	private int index =-1;
	private int lastIndex = 0;
	
	private String startDate;
	private String endDate;
	private String clientCode;
	private String customerCode;
	private String branchCode;
	
	SimpleDateFormat sdf = new SimpleDateFormat ("mm/dd/yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	
	PartialPaymentDAO pPaymentDao = (PartialPaymentDAO)Persistence.getDAO("partialPaymentDAO");
	
	public PartialPaymentField(String clientCode, String branchCode, String startDate, String endDate){
		this.startDate=startDate;
		this.endDate=endDate;
		this.branchCode=branchCode;
		this.clientCode=clientCode;	
				
		Map param = new HashMap();
		param.put("startDate", startDate);
		param.put("endDate", endDate);
		param.put("branchCode", branchCode);
		param.put("clientCode", clientCode);		
		
		lPayment = pPaymentDao.getPartialPayment(branchCode, clientCode, startDate, endDate);
		lastIndex=lPayment.size();
	}
	
	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Object value = null;
		String field = jRField.getName();
		PartialPayment pPayment = (PartialPayment) lPayment.get(index);
		
		if(lPayment.size()>0){				
			if("clientName".equals(field)){
				value=pPayment.getClientName();    			
			}   		
			if("customerName".equals(field)){
				value=pPayment.getCustomerName();    			
			}
			if("invoiceNo".equals(field)){
				value=pPayment.getInvoiceNo();    			
			}
			if("transactionDate".equals(field)){
				value=DateHelper.format(pPayment.getTransactionDate());    			
			}
			if("invoiceAmount".equals(field)){
				value=pPayment.getInvoiceAmount();    			
			}
			if("receiptAmount".equals(field)){
				value=pPayment.getReceiptAmount();    			
			}
			if("refNo".equals(field)){
				value=pPayment.getRefNo();    			
			}
			if("invoiceDueDate".equals(field)){
				value=DateHelper.format(pPayment.getInvoiceDueDate());    			
			}
			if ("dateRange".equals(field)) {
				value = startDate + "-" + endDate;
			}
			if ("currentDate".equals(field)) {
				value = date.newDate();
			}
		}
		
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}
}
