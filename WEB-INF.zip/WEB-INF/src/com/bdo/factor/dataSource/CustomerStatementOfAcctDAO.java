package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.apache.log4j.Logger;
import com.bdo.factor.beans.CustomerStatementOfAcct;
import com.bdo.factor.beans.Customer;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.FactorConnection;

public class CustomerStatementOfAcctDAO extends JdbcDaoSupport 
{
	private static Logger log = Logger.getLogger(CustomerStatementOfAcctDAO.class);
			
	@SuppressWarnings("unchecked")
	public List getCustomerDetailsByCode(long CustomerCode, String ClientCode)
	{
		List<Customer> customerList = new ArrayList<Customer>();
//		String sSQL = "SELECT C_CUSTNAME, C_ADDRESS, C_TELNO " + 
//					  "FROM Customer " +
//					  "WHERE C_CUSTCODE = " + CustomerCode;
		String sSQL = "SELECT CUST.C_CUSTNAME, " +
					  "CUST.C_ADDRESS, " +
					  "ISNULL(CC.C_COLLECTTELNO,'') AS C_TELNO, " +
					  "ISNULL(CC.C_COLLECTCONTACT,'') AS C_COLLECTCONTACT " +
					  "FROM CUSTOMER CUST " +
					  "INNER JOIN CCLINK CC ON CUST.C_CUSTCODE=CC.C_CUSTCODE " +
					  "WHERE CUST.C_CUSTCODE = " + CustomerCode + " " +
					  "AND CC.C_CLNTCODE = " + ClientCode;
		
		System.out.println("[CustomerStatementOfAcctDAO]->[getCustomerDetailsByCode][args1:" +CustomerCode+"][debug]: " +sSQL);
		customerList = getJdbcTemplate().query
		(
			sSQL, new RowMapper()
			{					
				@Override					
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException
				{
					Customer customer = new Customer();
					customer.setC_CustName(rs.getString("C_CUSTNAME"));
					customer.setC_Address(rs.getString("C_ADDRESS"));
					customer.setC_TelNo(rs.getString("C_TELNO"));
					customer.setC_CollectContact(rs.getString("C_COLLECTCONTACT"));
					return customer; 
				}					
			}
		);
		return customerList;
	}
	
	public String getCustmerNameByCode(long CustomerCode)
	{		 
		String retval = "";
		String sSQL = "SELECT C_CUSTNAME FROM Customer WHERE C_CUSTCODE = " + CustomerCode;
		System.out.println("[CustomerStatementOfAcctDAO]->[getCustmerNameByCode][args1:" +CustomerCode+"][debug]: " +sSQL);
		retval = (String)getJdbcTemplate().queryForObject(sSQL, 
			new RowMapper()
			{
				@Override 
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException
				{										
					return rs.getString("C_CUSTNAME");										
				}
			}
		);
				
		return retval;		
	}
	
	public int getCountOfCustStmtOfAccount(String clientCode, long custCode, String asOfDate, String branchCode) throws SQLException
	{
		Statement stmt=null;
		ResultSet rs = null;
		Connection conn = null;
		int retval = 0;
		
		String sSQL = "	  SELECT COUNT(Invoice.C_INVOICENO) as cntVal, " +
					  "	  Invoice.C_INVOICENO as ref, Invoice.C_CUSTCODE " +					  				  						  						 
					  "	  FROM Invoice " + 
					  "	  WHERE Invoice.C_BRANCHCODE = '"+branchCode+"' " +
					  "	  AND (Invoice.C_STATUS != 1 AND Invoice.C_STATUS != 7) " +
					  "	  AND Invoice.D_INVOICEDATE <= '"+asOfDate+"' " +
					  "	  AND Invoice.C_CLNTCODE = '"+clientCode+"' " +
					  "   GROUP BY Invoice.C_INVOICENO, Invoice.C_CUSTCODE ";
				
			if (custCode > 0)
			{
				sSQL += "   AND Invoice.C_CUSTCODE = " + custCode;
			}
			
			log.info(sSQL);		
			try
			{
					conn = new FactorConnection().getConnection();
					stmt = conn.createStatement();
					rs = stmt.executeQuery(sSQL);
					while(rs.next())
					{
						
						retval = retval + rs.getInt("cntVal");						
						sSQL = "SELECT " +							   
							   " COUNT(ReceiptsDtl.N_REFNO) as retVal" +							   					  
							   " FROM ReceiptsDtl CROSS JOIN ReceiptsHdr " +							   
							   " WHERE " +  
							   " ReceiptsDtl.C_INVOICENO = '"+rs.getString("ref")+"' " +							  
							   " AND ReceiptsHdr.C_CLNTCODE = '"+clientCode+"' " +					
							   " AND ReceiptsHdr.C_CUSTCODE = " + rs.getLong("C_CUSTCODE") +					
					           " AND ReceiptsDtl.N_REFNO = ReceiptsHdr.N_REFNO ";
						log.info(sSQL);
						
						retval = retval + getCount(sSQL,conn);
						
						sSQL = " SELECT " +
							   " COUNT(CreditNote.C_INVOICENO) as retVal" +
							   " FROM CreditNote " +
							   " WHERE " +
							   " CreditNote.C_INVOICENO = '"+rs.getString("ref")+"' " +
							   " AND CreditNote.C_BRANCHCODE = '"+branchCode+"' " +
							   " AND CreditNote.C_CUSTCODE = " + rs.getLong("C_CUSTCODE") +						
							   " AND CreditNote.C_CLNTCODE = '"+clientCode+"'";
						
						log.info(sSQL);
						
						retval = retval + getCount(sSQL,conn);
						sSQL = " SELECT " +
							   " COUNT(ReceiptsHdr.N_REFNO) AS retVal " + 
							   " FROM ReceiptsHdr " +
							   " WHERE " +							   
							   " ReceiptsHdr.D_TRANSACTIONDATE <= '"+asOfDate+"' " + 
							   " AND " + 
							   " N_OPAMT <> 0 AND ReceiptsHdr.C_CLNTCODE = '"+clientCode+"'" +
							   " AND ReceiptsHdr.C_BRANCHCODE='"+branchCode+"' ";
						
						if (custCode > 0)
						{
							 sSQL += " AND ReceiptsHdr.C_CUSTCODE=" + custCode;
						}
						log.info(sSQL);
						retval = retval + getCount(sSQL,conn);
						sSQL = " SELECT " + 
							   " COUNT(Refund.N_REFNO) AS retVal " +
							   " FROM Refund " +
							   " WHERE " +
							   " Refund.C_BRANCHCODE = '"+branchCode+"' " +
							   " AND Refund.D_TRANSACTIONDATE <= '"+asOfDate+"' " +							 	
							   " AND Refund.C_CLNTCODE = '"+clientCode+"' ";
						if (custCode > 0)
						{
							  sSQL+= "	  AND Refund.C_CUSTCODE = " + custCode;
						}
						log.info(sSQL);
						retval = retval + getCount(sSQL,conn); 
					}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				stmt.close();	
				rs.close();
				if(!conn.isClosed()){
					conn.close();
				}
			}
		
		return retval;
	}
	
	public int getCount(String sSQL, Connection conn) throws SQLException
	{
		Statement stmt=null;
		ResultSet rs = null;
		//Connection conn = null;
		int retval = 0;
					
			
			log.info(sSQL);		
			try
			{
					//conn = new FactorConnection().getConnection();
					stmt = conn.createStatement();
					rs = stmt.executeQuery(sSQL);
					while(rs.next())
					{
						retval = rs.getInt(1);						
					}
					rs.close();
					stmt.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
			//	conn.close();
				rs.close();
				stmt.close();				
			}
		
		return retval;
	}
	
	@SuppressWarnings("unchecked")
	public List<CustomerStatementOfAcct> getCustomerStatmentOfAccount(String clientCode, long custCode, String asOfDate, String branchCode,Boolean filter) throws SQLException
	{
		Statement stmt=null;
		ResultSet rs = null;			
		
			List<CustomerStatementOfAcct> list = new ArrayList<CustomerStatementOfAcct>();
			String sSQL = "SELECT StatementOfAccount.tDate, StatementOfAccount.DESCr, " +
						  "StatementOfAccount.ref, StatementOfAccount.ref2, StatementOfAccount.dueDate, " +
						  //"StatementOfAccount.ref, StatementOfAccount.dueDate, " +
						  "StatementOfAccount.InvoiceDueAge, ROUND(StatementOfAccount.Debit, 3) AS Debit, " +
						  "ROUND(StatementOfAccount.Credit, 3) AS Credit,StatementOfAccount.d_actualPaidDate, " +
						  "CC.C_NAME, CC.C_CUSTNAME, CC.N_TERM, StatementOfAccount.C_CUSTCODE ";
			if (custCode == 0)
			{
				sSQL += ", StatementOfAccount.C_CUSTCODE ";
			}
					sSQL+=" FROM " + 					   
						  "(		" + 
						  "	  SELECT Invoice.C_CLNTCODE, Invoice.C_CUSTCODE, " +
						  "	  Invoice.D_INVOICEDATE as tDate, " +
						  "	  'Invoice' as DESCr, " +
						  "	  Invoice.C_INVOICENO as ref, " +
						  "	  CAST(Invoice.N_INVNO AS VARCHAR) as ref2 " +
						  "	  ,Invoice.D_INVOICEDUEDATE AS dueDate, " +
						  "		d_actualPaidDate,"+
						  "	  " +
						  "	  CASE WHEN C_STATUS in ('5','6') THEN " +
						  "	  (DATEDIFF(d,Invoice.D_INVOICEDATE,Invoice.D_FULLYPAIDDATE)) " +
						  "	  ELSE (DATEDIFF(d,Invoice.D_INVOICEDATE,'"+asOfDate+"')) " +
						  "	  END AS InvoiceDueAge, Invoice.N_INVOICEAMT as Debit, NULL as Credit " +						  						  						  
						  "	  FROM Invoice " + 
						  "	  WHERE Invoice.C_BRANCHCODE = '"+branchCode+"' " +
						  "	  AND (Invoice.C_STATUS != 1 AND Invoice.C_STATUS != 7) " +
						  "	  AND Invoice.D_INVOICEDATE <= '"+asOfDate+"' " +
						  "	  AND Invoice.C_CLNTCODE = '"+clientCode+"' ";
					
				if (custCode > 0)
				{
					sSQL += "   AND Invoice.C_CUSTCODE = " + custCode;
				}						  				
						  
						sSQL+=" UNION " +
						  
						  "	  SELECT " +
						  "	  Refund.C_CLNTCODE, " +
						  "   Refund.C_CUSTCODE, " +
						  "   Refund.D_TRANSACTIONDATE AS tDate, " + 
						  "   'Refund' AS DESCr, " +
						  "   CAST(Refund.N_REFNO AS NVARCHAR(50)) as ref," +
						  "   CAST(Refund.N_REFNO AS NVARCHAR(50)) as ref2," +
						  "   NULL dueDate, " +
						  "   NULL AS InvoiceDueAge, NULL AS Debit, " +
						  "   N_REFAMT AS  Credit, " +
						  "		NULL as d_actualPaidDate"+
						  "   FROM Refund " +
						  "   WHERE " +
						  "   Refund.C_BRANCHCODE = '"+branchCode+"' " +
						  "   AND Refund.D_TRANSACTIONDATE <= '"+asOfDate+"' " +							 	
						  "   AND Refund.C_CLNTCODE = '"+clientCode+"' ";
						  
					if (custCode > 0)
					{
						  sSQL+= "	  AND Refund.C_CUSTCODE = " + custCode;
					}
				
						  
					sSQL += ") AS StatementOfAccount CROSS JOIN CC " +
						  "WHERE CC.C_CLNTCODE =  StatementOfAccount.C_CLNTCODE " +
						  "AND CC.C_CUSTCODE = StatementOfAccount.C_CUSTCODE " ;
						  /*if(filter){
							  sSQL +=   "	and d_actualpaiddate is null	";
						  }*/
					
					sSQL += 	  "ORDER BY CC.C_NAME, CC.C_CUSTNAME, " +
						  "StatementOfAccount.tDate ASC " ; 						  
		log.info("[getCustomerStatementOfAccount]=>"+sSQL);
	
		Connection conn = null;
		try
		{
			    conn = new FactorConnection().getConnection();
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sSQL);
				log.info("columnCount: " + rs.getMetaData().getColumnCount());				
				while(rs.next())
				{					
					CustomerStatementOfAcct customerStmt = new CustomerStatementOfAcct();
					customerStmt.setTDate(rs.getDate("tDate"));
					customerStmt.setDescription(rs.getString("DESCr"));
					customerStmt.setReferenceNo(rs.getString("ref"));
					customerStmt.setReferenceNo2(rs.getString("ref2"));
					customerStmt.setDueDate(rs.getDate("dueDate"));
					customerStmt.setInvoiceDue(rs.getInt("InvoiceDueAge"));
					customerStmt.setDebit(rs.getDouble("Debit"));
					customerStmt.setCredit(rs.getDouble("Credit"));						
					customerStmt.setClientName(rs.getString("C_NAME"));
					customerStmt.setCustomerName(rs.getString("C_CUSTNAME"));
					customerStmt.setN_TERM(rs.getInt("N_TERM"));
					customerStmt.setCustCode(rs.getLong("C_CUSTCODE"));
					customerStmt.setCustCode(custCode==0 ? rs.getLong("C_CUSTCODE") : custCode);	
					customerStmt.setD_actualPaidDate(rs.getDate("d_actualPaidDate"));
					list.add(customerStmt);
				
					String description = customerStmt.getDescription();									
					
					if (description.trim().equalsIgnoreCase("Invoice"))
					{
						List<CustomerStatementOfAcct> receiptsList = new ArrayList<CustomerStatementOfAcct>();
												
						receiptsList = this.getReceipts(clientCode,customerStmt.getCustCode(), asOfDate, rs.getString("ref2"), branchCode, customerStmt.getN_TERM(),conn);
						if (receiptsList != null && receiptsList.size() > 0) {							
							Iterator itr = receiptsList.iterator(); 
							while (itr.hasNext())
							{
								CustomerStatementOfAcct r = (CustomerStatementOfAcct)itr.next();								
								list.add(r);
								
								List<CustomerStatementOfAcct> creditNoteList = new ArrayList<CustomerStatementOfAcct>();
								creditNoteList = this.getCreditNote(clientCode,customerStmt.getCustCode(), asOfDate, rs.getString("ref"), branchCode, customerStmt.getN_TERM(),r.getReferenceNo(),conn);
								if (creditNoteList != null && creditNoteList.size() > 0) {							
									Iterator itr1 = creditNoteList.iterator(); 
									while (itr1.hasNext())
									{
										CustomerStatementOfAcct cn = (CustomerStatementOfAcct)itr1.next();								
										list.add(cn);																
									}							
								}
								
								CustomerStatementOfAcct c = (CustomerStatementOfAcct) this.getCancelledRecipts(clientCode, customerStmt.getCustCode(), asOfDate, rs.getString("ref2"), branchCode, r.getReferenceNo(),customerStmt.getInvoiceDue(),conn);
								if (c.getDescription()!= null)
								{
									list.add(c);
								}
								
//								CustomerStatementOfAcct op = (CustomerStatementOfAcct) this.getOverPayment(clientCode,  customerStmt.getCustCode(), asOfDate, branchCode, r.getReferenceNo(), customerStmt.getInvoiceDue());
//								if (op.getDescription() != null)
//								{
//									list.add(op);
//									CustomerStatementOfAcct cop = this.getCancelledOverPayment(clientCode, customerStmt.getCustCode(), asOfDate, branchCode, op.getReferenceNo(),customerStmt.getInvoiceDue());
//									if (cop.getDescription() != null) {																											
//										list.add(cop);										
//									}
//								}
								 
							}																			
						}						
					}										
				}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}		
		finally{
			rs.close();
			stmt.close();
			if(!conn.isClosed()){
				conn.close();
			}
		}
		return list;
	}
		
	private CustomerStatementOfAcct getCancelledRecipts(String clientCode, 
												  long custCode, 
												  String asOfDate, 
												  String invoiceNo, 
												  String branchCode,
												  String recNRefNo,
												  int dueAge,Connection conn) throws SQLException
	{
		Statement stmt=null;
		ResultSet rs = null;
		//Connection conn = new FactorConnection().getConnection();
		String sSQL = "";
		
		sSQL = "SELECT " +
			   "'0' AS C_CLNTCODE, " + 
			   "0 AS C_CUSTCODE, " + 
			   "ReceiptsHdr.D_TRANSACTIONDATE AS tDate, " +  			   
			   "CASE WHEN ReceiptsHdr.C_RECEIPTTYPE = 1 AND ReceiptsHdr.C_STATUS = 3 AND ReceiptsHdr.B_CLEARED = 1 THEN " +
			   "	'Dishonored'" +
			   "WHEN ReceiptsHdr.C_RECEIPTTYPE = 2 AND ReceiptsHdr.C_STATUS = 3 THEN " +
			   "	'RCT CSH CANCELLED' " +
			   "WHEN ReceiptsHdr.C_RECEIPTTYPE = 3 AND ReceiptsHdr.C_STATUS = 3 THEN " +
			   "	'RCT CA CANCELLED' " +
			   "WHEN ReceiptsHdr.C_RECEIPTTYPE = 4 AND ReceiptsHdr.C_STATUS = 3 THEN " +
			   "	'RCT REF CANCELLED' " +
			   "WHEN ReceiptsHdr.C_RECEIPTTYPE = 1 AND ReceiptsHdr.C_STATUS = 3 AND ReceiptsHdr.B_CLEARED = 0 THEN " +
			   "	'RCT CHK CANCELLED' " +
			   "END AS DESCr, " +  
			   "ReceiptsDtl.C_INVOICENO AS  ref, " + 
			   "NULL dueDate, " + 
			   "NULL InvoiceDueAge, " + 
			   "(ReceiptsDtl.N_RECEIPTAMT + ROUND(ISNULL(CreditNote.N_AMOUNT, 0.00),3)) AS Debit, " +
			   "NULL AS Credit, ReceiptsHdr.N_REFNO AS ReceiptDtlNo, " +
			   "CC.C_NAME, CC.C_CUSTNAME " + 
			   "FROM ReceiptsDtl CROSS JOIN Invoice CROSS JOIN ReceiptsHdr " +
			   "CROSS JOIN CC LEFT JOIN CreditNote " +
			   "ON ReceiptsHdr.N_REFNO = CreditNote.C_RECEIPTNO " +
			   "AND CreditNote.C_INVOICENO = Invoice.C_INVOICENO " + 
			   "WHERE " + 
			   "ReceiptsDtl.N_INVNO = Invoice.N_INVNO " + 
			   //"ReceiptsDtl.C_INVOICENO = Invoice.C_INVOICENO " +
			   "AND Invoice.C_BRANCHCODE = '"+branchCode+"' " +
			   " AND (Invoice.C_STATUS != 1 AND Invoice.C_STATUS != 7) " + 
			   "AND ReceiptsHdr.D_TRANSACTIONDATE <= '"+asOfDate+"' " + 
			   "AND Invoice.C_CLNTCODE = '"+clientCode+"' " +
			   "AND CC.C_CUSTCODE = " + custCode + " AND ReceiptsHdr.N_REFNO = '" + recNRefNo + "' " + //changed to CC from Invoice CVG 03162017
			   "AND ReceiptsDtl.N_REFNO = ReceiptsHdr.N_REFNO AND ReceiptsHdr.C_STATUS = 3 	" + 			   
			   "AND CC.C_CLNTCODE = Invoice.C_CLNTCODE " +
			   //"AND CC.C_CUSTCODE = Invoice.C_CUSTCODE " +
			   "AND Invoice.N_INVNO = '"+invoiceNo+"'" ;
			   //"AND Invoice.C_INVOICENO = '"+invoiceNo+"'" ;
		log.info("[getCancelledRecipts]-->"+sSQL);
		CustomerStatementOfAcct customerStmt = new CustomerStatementOfAcct();
		try
		 {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);		
			if(rs.next())
			{				
				customerStmt.setTDate(rs.getDate("tDate"));
				customerStmt.setDescription(rs.getString("DESCr"));
				customerStmt.setReferenceNo(rs.getString("ref"));
				customerStmt.setDueDate(rs.getDate("dueDate"));
				customerStmt.setInvoiceDue(rs.getInt("InvoiceDueAge"));
				customerStmt.setDebit(rs.getDouble("Debit"));
				customerStmt.setCredit(rs.getDouble("Credit"));						
				customerStmt.setClientName(rs.getString("C_NAME"));			
				customerStmt.setCustomerName(rs.getString("C_CUSTNAME"));				
				customerStmt.setReceipts(rs.getDouble("Credit"));				
				customerStmt.setN_TERM((0));				
				customerStmt.setReceiptDue((dueAge));
				log.info("getCancelledReceipts::age-->"+customerStmt.getReceiptDue());
				customerStmt.setCustCode(custCode);				
			}
			stmt.close();
			rs.close();
			 	
		}		 
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{			
			stmt.close();
			rs.close();
			//conn.close();
		}
		
		return customerStmt;			
	}
		
	private CustomerStatementOfAcct getOverPayment(String clientCode, long custCode, 
			                                             String asOfDate, String branchCode, 
			                                             String recNRefNo, int dueAge)
			                                             throws SQLException
    {
		String sSQL = "SELECT '0' AS C_CLNTCODE, " + 
					  "0 AS C_CUSTCODE, " +
					  "CC.C_NAME, CC.C_CUSTNAME,ReceiptsHdr.C_CLNTCODE, " + 	  
					  "ReceiptsHdr.C_CUSTCODE, " + 	  
					  "ReceiptsHdr.D_TRANSACTIONDATE AS tDate, " + 	  
					  "'Over Payment' AS DESCr, " + 	  
					  "CAST(ReceiptsHdr.N_REFNO AS NVARCHAR(50)) ref,    NULL dueDate, " + 	  
					  "NULL InvoiceDueAge, NULL AS Debit, " + 	  	
					  "ROUND(ISNULL(ReceiptsHdr.N_OPAMT, 0.00), 3) AS Credit " + 	  
					  "FROM ReceiptsHdr CROSS JOIN CC " + 	  
					  "WHERE " + 	  
					  "ReceiptsHdr.D_TRANSACTIONDATE <= '"+asOfDate+"' " + 	  
					  "AND " + 	  
					  "N_OPAMT <> 0 AND ReceiptsHdr.C_CLNTCODE = '"+clientCode+"' " +    
					  "AND ReceiptsHdr.C_CUSTCODE= " + custCode + 
					  " AND ReceiptsHdr.N_REFNO = '"+recNRefNo+"' " +
					  " AND CC.C_CUSTCODE = ReceiptsHdr.C_CUSTCODE " +
					  " AND CC.C_CLNTCODE = ReceiptsHdr.C_CLNTCODE";
		
				
		Statement stmt = null;
		ResultSet rs  = null;
		Connection conn = new FactorConnection().getConnection();
		log.info("[getOverPayment]-->"+sSQL);
		CustomerStatementOfAcct customerStmt = new CustomerStatementOfAcct();
		try
		 {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);		
			if(rs.next())
			{				
				customerStmt.setTDate(rs.getDate("tDate"));
				customerStmt.setDescription(rs.getString("DESCr"));
				customerStmt.setReferenceNo(rs.getString("ref"));
				customerStmt.setDueDate(rs.getDate("dueDate"));
				customerStmt.setInvoiceDue(rs.getInt("InvoiceDueAge"));
				customerStmt.setDebit(rs.getDouble("Debit"));
				customerStmt.setCredit(rs.getDouble("Credit"));						
				customerStmt.setClientName(rs.getString("C_NAME"));			
				customerStmt.setCustomerName(rs.getString("C_CUSTNAME"));				
				customerStmt.setReceipts(rs.getDouble("Credit"));				
				customerStmt.setN_TERM((0));
				customerStmt.setReceiptDue(dueAge);
				customerStmt.setCustCode(custCode);	
				return customerStmt;
			}
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
		 finally
		 {			
			stmt.close();
			rs.close();
			conn.close();
		 }
		
		return customerStmt;			
    }			                                             
		
	private CustomerStatementOfAcct getCancelledOverPayment(String clientCode, long custCode,
																  String asOfDate, String branchCode, 
																  String recNRefNo, int dueAge)
																  throws SQLException 
    {		
		String sSQL = "SELECT '0' AS C_CLNTCODE, " + 
					  "0 AS C_CUSTCODE, " + 
					  "ReceiptsHdr.D_TRANSACTIONDATE AS tDate, " + 
					  "CASE WHEN ReceiptsHdr.C_RECEIPTTYPE = 1 AND ReceiptsHdr.C_STATUS = 3 AND ReceiptsHdr.B_CLEARED = 1 THEN " +
					  " 'Dishonored' " +
					  " WHEN ReceiptsHdr.C_RECEIPTTYPE = 1 AND ReceiptsHdr.C_STATUS = 3 AND ReceiptsHdr.B_CLEARED = 0 THEN" +
					  " 'RCT CHK CANCELLED'" +
					  " END AS DESCr," +
					  " ReceiptsHdr.N_REFNO AS  ref," +
					  " NULL dueDate, NULL InvoiceDueAge," +
					  " ROUND(ISNULL(ReceiptsHdr.N_OPAMT, 0.00), 3) AS Debit," +
					  " NULL AS Credit, " +
					  " CC.C_NAME, CC.C_CUSTNAME " +
					  " FROM " +
					  " ReceiptsHdr CROSS JOIN CC" +
					  " WHERE" +
					  " ReceiptsHdr.D_TRANSACTIONDATE <= '"+asOfDate+"' " +
					  " AND CC.C_CLNTCODE = ReceiptsHdr.C_CLNTCODE " +
					  " AND CC.C_CUSTCODE = ReceiptsHdr.C_CUSTCODE " +
					  " AND ReceiptsHdr.N_REFNO = '"+ recNRefNo +"'" +
					  " AND ReceiptsHdr.C_CLNTCODE = '"+clientCode+"' " +
					  " AND ReceiptsHdr.C_BRANCHCODE = '"+branchCode+"' " +
					  "AND ReceiptsHdr.C_CUSTCODE = " + custCode;		
		Statement stmt = null;
		ResultSet rs  = null;
		Connection conn = new FactorConnection().getConnection();
		log.info("[getCancelledOverPayment]-->"+sSQL);
		CustomerStatementOfAcct customerStmt = new CustomerStatementOfAcct();
		try
		 {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);		
			if(rs.next())
			{		
				
				customerStmt.setTDate(rs.getDate("tDate"));
				customerStmt.setDescription(rs.getString("DESCr"));
				customerStmt.setReferenceNo(rs.getString("ref"));
				customerStmt.setDueDate(rs.getDate("dueDate"));
				customerStmt.setInvoiceDue(rs.getInt("InvoiceDueAge"));
				customerStmt.setDebit(rs.getDouble("Debit"));
				customerStmt.setCredit(rs.getDouble("Credit"));						
				customerStmt.setClientName(rs.getString("C_NAME"));			
				customerStmt.setCustomerName(rs.getString("C_CUSTNAME"));				
				customerStmt.setReceipts(rs.getDouble("Credit"));				
				customerStmt.setN_TERM((0));				
				customerStmt.setCustCode(custCode);	
				customerStmt.setReceiptDue((dueAge));	
				log.info("getCancelledOverPayment::age-->"+customerStmt.getReceiptDue());
				return customerStmt;
			}
			stmt.close();
			rs.close();
			conn.close();		
		}		 
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{			
			stmt.close();
			rs.close();
			conn.close();
		}
		
		return customerStmt;
		
    }
	
	private List<CustomerStatementOfAcct> getReceipts(String clientCode, 
													  long custCode, 
													  String asOfDate, 
													  String invoiceNo, 
													  String branchCode,
													  long receiptNTerm,
													  Connection conn) throws SQLException
	{
		
		List<CustomerStatementOfAcct> list = new ArrayList<CustomerStatementOfAcct>();
		Statement stmt1=null;
		ResultSet rs1 = null;
		//Connection conn = new FactorConnection().getConnection();				
		
		String sSQL = "SELECT " +
		   			  "'0' AS C_CLNTCODE, " +
		   			  " 0 AS C_CUSTCODE, " +
		   			  " ReceiptsHdr.D_TRANSACTIONDATE AS tDate, " + 
		   			  " 'Receipts' AS DESCr, " +
		   			  " ReceiptsDtl.N_REFNO  ref, " +
		   			  " NULL dueDate, " +
		   			  " NULL InvoiceDueAge, " + 
		   			  " NULL AS Debit, " +
		   			 // " CASE WHEN (ReceiptsHdr.N_AMOUNT < ReceiptsDtl.N_AMTINV ) THEN " +
		   			 // " ReceiptsHdr.N_AMOUNT " +
		   			 // " ELSE" +
		   			 // " ReceiptsHdr.N_TOTINVAMT " +
		   			 // " END AS  Credit, " +
		   			  " ROUND(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0.00), 3) AS Credit, " +		   			  
		   			  " CC.C_NAME, CC.C_CUSTNAME, " +			  
		   			  " CASE WHEN Invoice.C_STATUS in ('5','6') THEN " +
		   			  " (DATEDIFF(d,Invoice.D_INVOICEDATE,Invoice.D_FULLYPAIDDATE))  " +
		   			  " ELSE (DATEDIFF(d,Invoice.D_INVOICEDATE,'"+asOfDate+"')) " +
		   			  " END AS receiptDueAge, "+receiptNTerm+" AS N_TERM " +
		   			  " FROM ReceiptsDtl CROSS JOIN Invoice CROSS JOIN ReceiptsHdr " +
		   			  " CROSS JOIN CC " + 
		   			  " WHERE " +  
		   			  " ReceiptsDtl.N_INVNO = Invoice.N_INVNO " +
		   			  //" ReceiptsDtl.C_INVOICENO = Invoice.C_INVOICENO " +
		   			  " AND Invoice.C_BRANCHCODE = '"+branchCode+"' " +
		   			  " AND (Invoice.C_STATUS != 1 AND Invoice.C_STATUS != 7) " +
		   			  " AND Invoice.D_INVOICEDATE <= '"+asOfDate+"' " +
		   			  " AND Invoice.C_CLNTCODE = '"+clientCode+"' " +
		   			  " AND Invoice.C_CUSTCODE = " + custCode +					
		   			  " AND ReceiptsDtl.N_REFNO = ReceiptsHdr.N_REFNO " +
		   			  " AND ReceiptsHdr.C_STATUS IN (1, 2, 3, 4) " +
		   			  " AND ReceiptsHdr.C_CLNTCODE= Invoice.C_CLNTCODE " +
		   			  " AND Invoice.N_INVNO = '"+invoiceNo+"'" +
		   			  //" AND Invoice.C_INVOICENO = '"+invoiceNo+"'" +
		   			  " AND CC.C_CLNTCODE = Invoice.C_CLNTCODE " +
		   			  " AND CC.C_CUSTCODE = Invoice.C_CUSTCODE " +
		   			  " AND ReceiptsHdr.C_BRANCHCODE=Invoice.C_BRANCHCODE";
		   			 // + " AND ReceiptsHdr.D_TRANSACTIONDATE <= '"+asOfDate+"'" ; // add this to remove negative in balance CVG 03-20-2017
					  log.info("[getReceipts]==>"+sSQL);
		try
		 {
			stmt1 = conn.createStatement();
			rs1 = stmt1.executeQuery(sSQL);		
			while(rs1.next())
			{
				CustomerStatementOfAcct customerStmt = new CustomerStatementOfAcct();
				customerStmt.setTDate(rs1.getDate("tDate"));
				customerStmt.setDescription(rs1.getString("DESCr"));
				customerStmt.setReferenceNo(rs1.getString("ref"));
				customerStmt.setDueDate(rs1.getDate("dueDate"));
				customerStmt.setInvoiceDue(rs1.getInt("InvoiceDueAge"));
				customerStmt.setDebit(rs1.getDouble("Debit"));
				customerStmt.setCredit(rs1.getDouble("Credit"));						
				customerStmt.setClientName(rs1.getString("C_NAME"));			
				customerStmt.setCustomerName(rs1.getString("C_CUSTNAME"));				
				customerStmt.setReceipts(rs1.getDouble("Credit"));
				customerStmt.setReceiptDue(rs1.getInt("receiptDueAge"));
				log.info("getReceipts::age-->"+customerStmt.getReceiptDue());
				customerStmt.setN_TERM((rs1.getInt("N_TERM")));				
				customerStmt.setCustCode(custCode);				
				list.add(customerStmt);				
			}
			stmt1.close();
			rs1.close();
		//	conn.close();		
		}		 
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			stmt1.close();
			rs1.close();
		//	conn.close();
		}
		
		return list;
		
	}
	
	
	private List<CustomerStatementOfAcct> getCreditNote(String clientCode, 
												  long custCode, 
												  String asOfDate, 
												  String invoiceNo, 
												  String branchCode,
												  long receiptNTerm,
												  String receiptNRefNo
												  ,Connection conn) throws SQLException
	{		
		List<CustomerStatementOfAcct> list = new ArrayList<CustomerStatementOfAcct>();
		Statement stmt1=null;
		ResultSet rs1 = null;
		//Connection conn = new FactorConnection().getConnection();
		
//		String sSQL = " SELECT CreditNote.C_CLNTCODE, " +
//					  " CreditNote.C_CUSTCODE, " +
//					  " CreditNote.D_TRANSACTIONDATE AS tDate, " +
//					  " 'Credit Note' AS DESCr, " +
//					  " CreditNote.C_INVOICENO as ref, " +
//					  " NULL dueDate, " +
//					  " NULL AS InvoiceDueAge, NULL AS Debit, ROUND(ISNULL(N_AMOUNT, 0.00), 3) AS  Credit, " +
//					  " CreditNote.N_REFNO AS ReceiptDtlNo," +
//					  " CC.C_NAME, CC.C_CUSTNAME, " +			  
//					  " CASE WHEN Invoice.C_STATUS = 5 THEN " +
//					  " (DATEDIFF(d,Invoice.D_INVOICEDATE,Invoice.D_FULLYPAIDDATE))  " +
//					  " ELSE (DATEDIFF(d,Invoice.D_INVOICEDATE,'"+asOfDate+"')) " +
//					  " END AS receiptDueAge, "+receiptNTerm+" AS N_TERM " +
//					  " FROM CreditNote CROSS JOIN Invoice " +
//					  " CROSS JOIN CC " +
//					  " WHERE " +
//					  " CreditNote.C_INVOICENO = Invoice.C_INVOICENO " +
//					  " AND CreditNote.C_CLNTCODE = Invoice.C_CLNTCODE " +
//					  " AND CreditNote.C_CUSTCODE = Invoice.C_CUSTCODE " +
//					  //" AND CreditNote.C_STATUS != 3 " +
//					  " AND CreditNote.C_BRANCHCODE = Invoice.C_BRANCHCODE " +
//					  " AND Invoice.C_BRANCHCODE = '"+branchCode+"' AND " +
//					  " (Invoice.C_STATUS != 1 AND Invoice.C_STATUS != 7) " + 
//					  " AND Invoice.D_INVOICEDATE <= '"+asOfDate+"' " + 
//					  " AND Invoice.C_CLNTCODE = '"+clientCode+"' AND Invoice.C_CUSTCODE = " + custCode + 
//					  " AND Invoice.C_INVOICENO = '"+invoiceNo+"' " +
//					  " AND CC.C_CLNTCODE = Invoice.C_CLNTCODE " +
//					  " AND CC.C_CUSTCODE = Invoice.C_CUSTCODE " +
//					  " AND CreditNote.C_RECEIPTNO = '"+receiptNRefNo+"'"   ;
//		  log.info("[getCreditNote]==>"+sSQL);
		
			String sSQL = " SELECT CreditNote.C_CLNTCODE, " +
					" CreditNote.C_CUSTCODE, " +
					" CreditNote.D_TRANSACTIONDATE AS tDate, " +
					" 'Credit Note' AS DESCr, " +
					" CreditNote.C_INVOICENO as ref, " +
					" NULL dueDate, " +
					" NULL AS InvoiceDueAge, NULL AS Debit, ROUND(ISNULL(N_AMOUNT, 0.00), 3) AS  Credit, " +
					" CreditNote.N_REFNO AS ReceiptDtlNo," +
					" CC.C_NAME, CC.C_CUSTNAME, " +			  
					" CASE WHEN Invoice.C_STATUS in ('5','6') THEN " +
					" (DATEDIFF(d,Invoice.D_INVOICEDATE,Invoice.D_FULLYPAIDDATE))  " +
					" ELSE (DATEDIFF(d,Invoice.D_INVOICEDATE,'"+asOfDate+"')) " +
					" END AS receiptDueAge, "+receiptNTerm+" AS N_TERM " +
					" FROM CreditNote Inner JOIN" +
					" (Select inv.* from invoice inv inner join receiptsdtl rd on" +
					" inv.n_invno=rd.n_invno inner join receiptshdr rh on" +
					" rh.n_refno=rd.n_refno where rh.n_refno='"+receiptNRefNo+"') Invoice" + 
				    " ON CreditNote.C_INVOICENO = Invoice.C_INVOICENO" + 
                   	" cross join CC " +
					" WHERE " +
					" CreditNote.C_INVOICENO = Invoice.C_INVOICENO " +
					" AND CreditNote.C_CLNTCODE = Invoice.C_CLNTCODE " +
					" AND CreditNote.C_CUSTCODE = Invoice.C_CUSTCODE " +
					//" AND CreditNote.C_STATUS != 3 " +
					" AND CreditNote.C_BRANCHCODE = Invoice.C_BRANCHCODE " +
					" AND Invoice.C_BRANCHCODE = '"+branchCode+"' AND " +
					" (Invoice.C_STATUS != 1 AND Invoice.C_STATUS != 7) " + 
					" AND Invoice.D_INVOICEDATE <= '"+asOfDate+"' " + 
					" AND Invoice.C_CLNTCODE = '"+clientCode+"' AND Invoice.C_CUSTCODE = " + custCode + 
					" AND Invoice.C_INVOICENO = '"+invoiceNo+"' " +
					" AND CC.C_CLNTCODE = Invoice.C_CLNTCODE " +
					" AND CC.C_CUSTCODE = Invoice.C_CUSTCODE " +
					" AND CreditNote.C_RECEIPTNO = '"+receiptNRefNo+"'";
					//		+ "and CreditNote.D_TRANSACTIONDATE = '"+asOfDate+"' ";// add this to remove negative in balance CVG 03-20-2017
			log.info("[getCreditNote]==>"+sSQL);
			
			
			
			try
			 {
				stmt1 = conn.createStatement();
				rs1 = stmt1.executeQuery(sSQL);		
				while(rs1.next())
				{
					CustomerStatementOfAcct customerStmt = new CustomerStatementOfAcct();
					customerStmt.setTDate(rs1.getDate("tDate"));
					customerStmt.setDescription(rs1.getString("DESCr"));
					customerStmt.setReferenceNo(rs1.getString("ref"));
					customerStmt.setDueDate(rs1.getDate("dueDate"));
					customerStmt.setInvoiceDue(rs1.getInt("InvoiceDueAge"));
					customerStmt.setDebit(rs1.getDouble("Debit"));
					customerStmt.setCredit(rs1.getDouble("Credit"));						
					customerStmt.setClientName(rs1.getString("C_NAME"));			
					customerStmt.setCustomerName(rs1.getString("C_CUSTNAME"));				
					customerStmt.setReceipts(rs1.getDouble("Credit"));
					customerStmt.setReceiptDue(rs1.getInt("receiptDueAge"));
					customerStmt.setN_TERM((rs1.getInt("N_TERM")));				
					customerStmt.setCustCode(custCode);
					log.info("getCreditNote::age-->"+customerStmt.getReceiptDue());
					list.add(customerStmt);				
				}
				stmt1.close();
				rs1.close();
				//conn.close();		
			}		 
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				stmt1.close();
				rs1.close();
			//	conn.close();
			}
		return list;
					
		}
	
	public static void main(String[] args) throws SQLException
	{
		CustomerStatementOfAcctDAO custStmtOfAcctDao = (CustomerStatementOfAcctDAO)Persistence.getDAO("customerStmtOfAcctDao");		
	//	System.out.println("Count->"+custStmtOfAcctDao.getCustomerStatmentOfAccount("5", 10, "08/05/2009", "01").size());
		List<CustomerStatementOfAcct> list1 = new ArrayList<CustomerStatementOfAcct>();
	//	list1 = custStmtOfAcctDao.getCustomerStatmentOfAccount("5", 10, "08/05/2009", "01");
		
		for (int x=0; x<list1.size(); x++)
		{			
			CustomerStatementOfAcct custStmtOfAcct = (CustomerStatementOfAcct)list1.get(x);
			System.out.println("["+x+"]Description-->" + custStmtOfAcct.getDescription() + "|referenceno->" + custStmtOfAcct.getReferenceNo());			
		}
		
		
	}
	
}
