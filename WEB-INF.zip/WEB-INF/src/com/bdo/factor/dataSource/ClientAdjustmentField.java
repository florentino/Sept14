/*@ Added by	: Roldan Somontina
 * 	Java Name	: VerifyInvoiceField.java
 * 	Date Added	: May 19, 2009
 *  Source Code for Invoice Due Report
 */ 

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Adjustment;
import com.bdo.factor.beans.BLRFile;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.Persistence;

public class ClientAdjustmentField extends ClientDAO implements JRDataSource{
	private static Logger log = Logger.getLogger(ClientActivityField.class);

	List clientAdjustmentList= new ArrayList();	
	//List<BLRFile> blrList= new ArrayList<BLRFile>();
	private int index=-1;
	private int lastIndex = 0;



	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	//CCLinkDAO ccLinkDao = (CCLinkDAO)Persistence.getDAO("ccLinkDao");

	public ClientAdjustmentField(String clientCode,String asOfDate){
		clientAdjustmentList= getClientAdjustments(clientCode,asOfDate);
		//blrList = BLRFileDAO.getAllBLRFile(clientCode);
		lastIndex= clientAdjustmentList.size();
		log.info("(ClientAdjustmentField)lastIndex=> "+lastIndex);
	}


	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		Adjustment adj = (Adjustment)clientAdjustmentList.get(index);
//		if(ca.getClient()!=null){
//			Client c = (Client) ca.getClient();
//
//			if("clientName".equals(field)){   			
//				value=c.getC_Name();
//			}
//			if("address".equals(field)){   			
//				value=c.getC_Address();
//			}
//			if("contact".equals(field)){   			
//				value=c.getC_Contact();
//			}
//			if("currency".equals(field)){   			
//				value=c.getC_Currency();
//			}
//			if("dcr".equals(field)){   			
//				value=c.getN_Dcr();
//			}
//			if("scr".equals(field)){   			
//				value=c.getN_Scr();
//			}	
//			if("startDate".equals(field)){   			
//				value=ca.getStartDate();				
//			}
//			if("rates".equals(field)){
//				value=BLRFileDAO.getBLRFileWithDiscountCharge(ca.getClientCode());
//			}
//		}
//
//		/*
//		if(ca.getBlrFile()!=null){
//			BLRFile b=(BLRFile) ca.getBlrFile();
//			if("blr".equals(field)){   			
//				value=b.getBlr();
//			}
//			if("effectivityDate".equals(field)){   			
//				value=b.getEffectiveDate();
//			}
//			if("expiryDate".equals(field)){   			
//				value=b.getExpiryDate();
//			}			
//		}else{
//			if("blr".equals(field)){   			
//				value=0.00;
//			}			
//		}
//		*/
		
		if(clientAdjustmentList.size()>0/*&&index+1!=lastIndex*/){
			if("D_APPROVEDDATE".equals(field)){   			
				value=adj.getD_APPROVEDDATE();
			}
			if("N_REFNO".equals(field)){   			
				value=adj.getN_REFNO();
			}
			if("C_CUSTNAME".equals(field)){   			
				value=adj.getC_CUSTCODE();
			}
			if("C_NAME".equals(field)){   			
				value=adj.getC_CLNTCODE();
			}
			if("C_BRANCHCODE".equals(field)){   			
				value=adj.getC_BRANCHCODE();
			}
			if("C_INVOICENO".equals(field)){   			
				value=adj.getC_INVOICENO();
			}
			if("C_ADJCODE".equals(field)){   			
				value=adj.getC_ADJCODE();
			}	
			if("N_AMOUNT".equals(field)){   			
				value=adj.getN_AMOUNT();
			}	
			if("C_STATUS".equals(field)){   			
				value=adj.getC_STATUS();
			}	
			
			
			
		}
//		if(index+1==lastIndex){
//			if("totalReceivables".equals(field)){   			
//				value=ca.getTotalReceivables();
//			}
//			if("totalReserves".equals(field)){   			
//				value=ca.getTotalReserves();
//			}
//			if("totalFiuTransaction".equals(field)){   			
//				value=ca.getTotalFiuTransaction();
//			}
//			if("totalFiuBalance".equals(field)){   			
//				value=ca.getTotalFiuBalance();
//			}			
//			if("invoices".equals(field)){   			
//				value=ca.getInvoices();
//			}
//			if("advances".equals(field)){   			
//				value=ca.getAdvances();
//			}	
//			if("receipts".equals(field)){   			
//				value=ca.getReceipts();
//			}
//			if("creditNotes".equals(field)){   			
//				value=ca.getCreditNotes();
//			}
//			if("refunds".equals(field)){   			
//				value=ca.getRefunds();
//			}			
//			if("serviceCharges".equals(field)){   			
//				value=ca.getServiceCharges();
//			}			
//			if("discountCharges".equals(field)){   			
//				value=ca.getDiscountCharges();
//			}
//			if("dcOnCashDelays".equals(field)){   			
//				value=ca.getDcOnCashDelays();
//			}
//			if("setupFee".equals(field)){   			
//				value=ca.getSetupFee();
//			}
//			if("dcCollected".equals(field)){   			
//				value=ca.getDcCollected();
//			}
//			if("overpayment".equals(field)){   			
//				value=ca.getOverpayment();
//			}
//			if("receiptAdvance".equals(field)){   			
//				value=ca.getReceiptAdvance();
//			}
//			if("receiptRefund".equals(field)){   			
//				value=ca.getReceiptRefund();
//			}
//		}

		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
