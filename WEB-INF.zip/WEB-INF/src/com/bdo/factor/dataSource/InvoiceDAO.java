
 package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.Audit;
import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.beans.ReportField;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.service.AuditService;
import com.bdo.factor.service.CCLinkService;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.util.ServiceUtility;
import com.bdo.factor.util.Money;







public class InvoiceDAO extends JdbcDaoSupport
{	
	private static Logger log = Logger.getLogger(InvoiceDAO.class);	
	@SuppressWarnings("unchecked")
	public List<Invoice> getInvoiceScheduleOfEditLst(String branchCode, String clientCode, String startDate, String endDate)
	{
		
		List<Invoice> list = new ArrayList<Invoice>();
				
		String sSQL = "SELECT DISTINCT(DerivedInvoice.C_INVOICENO), " +
					  "	DerivedInvoice.C_CUSTNAME, DerivedInvoice.N_TERM, " +
					  " ISNULL(DerivedInvoice.N_INVOICEAMT,0) AS N_INVOICEAMT, DerivedInvoice.D_INVOICEDATE, " +
					  " ISNULL(DerivedInvoice.N_EXCHANGERATE,0) AS N_EXCHANGERATE, DerivedInvoice.N_ORIGINVOICEAMT, " +
					  " DerivedInvoice.C_CURRENCYCODE, DerivedInvoice.C_NAME, " +
					  " DerivedInvoice.C_CUSTCODE, " +
					  " DerivedInvoice.C_CLNTCODE, " +
					  " SUM(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0)) AS N_RECEIPTAMT, " +
					  " SUM(ISNULL(CreditNote.N_AMOUNT, 0)) AS CreditNote_N_AMOUNT, " +
					  " DerivedInvoice.stat, " +
					  " ABS( ROUND(ISNULL(DerivedInvoice.N_INVOICEAMT,0), 3) - ( ROUND(SUM(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0)), 3) + ROUND(SUM(ISNULL(CreditNote.N_AMOUNT, 0)), 3) ) ) AS OSInvAmt " +
					  "	FROM " +
					  " (SELECT Invoice.C_INVOICENO, CC.C_CUSTNAME, " +
					  "	Invoice.N_TERM, Invoice.N_INVOICEAMT, Invoice.D_INVOICEDATE " +
					  "	,stat = " +
					  "		CASE Invoice.C_STATUS " +
					  "		WHEN '1' THEN 'For Verification' " + 
					  "		WHEN '2' THEN 'For Release of Advances' " +
					  "		WHEN '2' THEN 'Released Advances' " +
					  "		WHEN '4' THEN 'Partially Paid'  " +
					  "		WHEN '5' THEN 'Fully Paid' " +
					  "		WHEN '6' THEN 'Closed' " +
					  "		WHEN '7' THEN 'Cancelled/Disapproved' " +
					  "		END, " +
					  "		ISNULL(Invoice.N_EXCHANGERATE, 0) AS N_EXCHANGERATE, " +
					  "		ISNULL(N_ORIGINVOICEAMT, 0) N_ORIGINVOICEAMT, " + 
					  "		Invoice.C_CURRENCYCODE, CC.C_NAME, CC.C_CLNTCODE, CC.C_CUSTCODE, " +
					  "		Invoice.C_BRANCHCODE " + 	  
						
					  "		FROM " + 
					  "		Invoice CROSS JOIN CC " + 	
						
					  "		WHERE " + 
					  "		Invoice.C_CUSTCODE = CC.C_CUSTCODE AND " + 
					  "		Invoice.D_TRANSACTIONDATE BETWEEN '" + startDate + "' AND " +
					  "		'" + endDate + "' " +
					  "		AND Invoice.C_BRANCHCODE = '" + branchCode + "' " +
					  "		AND CC.C_BRANCHCODE = Invoice.C_BRANCHCODE " +
					  "		AND Invoice.C_CLNTCODE = CC.C_CLNTCODE " +
					  "		AND Invoice.C_CLNTCODE = " + clientCode + " " +
					  "		AND Invoice.C_STATUS BETWEEN 2 AND 6 " + 					  
					  "		) AS DerivedInvoice " +
							
					  "		LEFT OUTER JOIN ReceiptsHdr ON " + 
					  "		ReceiptsHdr.C_BRANCHCODE = DerivedInvoice.C_BRANCHCODE " +
					  "		AND ReceiptsHdr.C_CUSTCODE = DerivedInvoice.C_CUSTCODE " +
					  "		AND ReceiptsHdr.C_CLNTCODE = DerivedInvoice.C_CLNTCODE " +
					  "		AND ReceiptsHdr.C_STATUS<>3 " +
							
					  "		LEFT OUTER JOIN ReceiptsDtl ON " + 
					  "		ReceiptsDtl.N_REFNO = ReceiptsHdr.N_REFNO " +
					  "		AND DerivedInvoice.C_INVOICENO = ReceiptsDtl.C_INVOICENO " +
						
					  "		LEFT OUTER JOIN CreditNote " +
					  "	ON CreditNote.C_INVOICENO = DerivedInvoice.C_INVOICENO " +
					  "	AND CreditNote.C_STATUS <> 3 " +
					  " AND DerivedInvoice.C_CLNTCODE = CreditNote.C_CLNTCODE " +					   
					  "	AND CreditNote.C_RECEIPTNO = ReceiptsHdr.N_REFNO " +		
					  "		GROUP BY " + 
					  "		DerivedInvoice.C_INVOICENO, DerivedInvoice.C_CUSTNAME, DerivedInvoice.N_TERM, " + 
					  "     DerivedInvoice.N_INVOICEAMT, DerivedInvoice.D_INVOICEDATE, " +
					  "     DerivedInvoice.N_EXCHANGERATE, DerivedInvoice.N_ORIGINVOICEAMT, " +
					  "		DerivedInvoice.C_CURRENCYCODE, DerivedInvoice.C_NAME, DerivedInvoice.C_CUSTCODE,  " + 
					  "		DerivedInvoice.C_CLNTCODE, DerivedInvoice.stat " +
					  "		ORDER BY DerivedInvoice.C_NAME, DerivedInvoice.C_CUSTNAME, DerivedInvoice.D_INVOICEDATE";
	
		log.info("[getInvoiceScheduleOfEditLst][debug]==>" + sSQL);
		
		list = getJdbcTemplate().query
		(
				
				sSQL, new RowMapper()
				{
					
					@Override
					
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						Invoice invoice = new Invoice();
						invoice.setC_INVOICENO(rs.getString("C_INVOICENO"));
						invoice.setC_CUSTNAME(rs.getString("C_CUSTNAME"));
						invoice.setN_TERM(rs.getInt("N_TERM"));
						invoice.setN_INVOICEAMT(rs.getDouble("N_INVOICEAMT"));
						invoice.setD_INVOICEDATE(rs.getDate("D_INVOICEDATE"));
						invoice.setC_CURRENCYCODE(rs.getString("C_CURRENCYCODE"));
						invoice.setN_EXCHANGERATE(rs.getDouble("N_EXCHANGERATE"));
						invoice.setN_ORIGINVOICEAMT(rs.getDouble("N_ORIGINVOICEAMT"));
						invoice.setN_RECEIPTAMT(rs.getDouble("N_RECEIPTAMT"));
						invoice.setCreditNote_N_AMOUNT(rs.getDouble("CreditNote_N_AMOUNT"));
						invoice.setN_OSInvAmt(rs.getDouble("OSInvAmt"));
						return invoice; 
					}					
				}
		);		
		
		return list;		             
		             
	}
	
	public double getTotalInvoiceAmount(String branchCode, String clientCode, String startDate, String endDate)
	{		 
		double retval = 0.0;
		String sSQL   = "SELECT SUM(Invoice.N_ORIGINVOICEAMT) " +
					    "FROM 		Invoice CROSS JOIN CC " + 		
					    "WHERE " + 		
					    "Invoice.C_CUSTCODE = CC.C_CUSTCODE AND " + 		
					    "Invoice.D_TRANSACTIONDATE BETWEEN '"+startDate+"' AND " + 		
					    "'"+endDate+"' " + 		
					    "AND Invoice.C_BRANCHCODE = '"+branchCode+"' " + 		
					    "AND CC.C_BRANCHCODE = Invoice.C_BRANCHCODE " + 		
					    "AND CC.C_CLNTCODE = "+clientCode+" ";
		log.info("[getTotalInvoiceAmount][debug]==>" + sSQL);
		retval = (Double)getJdbcTemplate().queryForObject(sSQL, 
			new RowMapper()
			{
				@Override 
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException
				{										
					return rs.getDouble(1);										
				}
			}
		);
				
		return retval;		
	}
	
	public double getTotalInvoiceAmountFiltered(String branchCode, String clientCode, String startDate, String endDate)
	{		 
		double retval = 0.0;
		String sSQL   = "SELECT ROUND(SUM(Invoice.N_ORIGINVOICEAMT), 3) " +
					    "FROM 		Invoice CROSS JOIN CC " + 		
					    "WHERE Invoice.C_STATUS BETWEEN 2 AND 6 AND " + 		
					    "Invoice.C_CUSTCODE = CC.C_CUSTCODE AND " + 		
					    "Invoice.D_TRANSACTIONDATE BETWEEN '"+startDate+"' AND " + 		
					    "'"+endDate+"' " + 		
					    "AND Invoice.C_BRANCHCODE = '"+branchCode+"' " + 		
					    "AND CC.C_BRANCHCODE = Invoice.C_BRANCHCODE " + 		
					    "AND CC.C_CLNTCODE = "+clientCode+" ";
		log.info("[getTotalInvoiceAmount][debug]==>" + sSQL);
		retval = (Double)getJdbcTemplate().queryForObject(sSQL, 
			new RowMapper()
			{
				@Override 
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException
				{										
					return rs.getDouble(1);										
				}
			}
		);
				
		return retval;		
	}
	
	
	/*  Added by :Roldan Somontina
	 *  Method for Invoices for Verification
	 *  Date:  May 18, 2009
	 *  
	 */
	@SuppressWarnings("unchecked")
	public List<Invoice> getVerifyInvoice(String startDate,String endDate)
	{
		
		List<Invoice> list = new ArrayList<Invoice>();
				
		String sSQL = "SELECT *, Customer.C_CUSTNAME" + 					  		
		              " FROM " + 
		              " Invoice CROSS JOIN Customer " + 
		              " WHERE Invoice.C_CUSTCODE = Customer.C_CUSTCODE " +
		              " AND CONVERT(nvarchar,D_TRANSACTIONDATE,101)>='"+startDate+"' "+
		              " AND CONVERT(nvarchar,D_TRANSACTIONDATE,101)<='"+endDate+"' " +
		              		"ORDER BY Invoice.C_CLNTCODE";
	
		log.info("[getVerifyInvoice][debug]==>" + sSQL);
		System.out.println(sSQL);
		list = getJdbcTemplate().query
		(
				
				sSQL, new RowMapper()
				{
					
					@Override
					
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						Invoice invoice = new Invoice();
						invoice.setC_CLNTCODE(rs.getString("C_CLNTCODE"));						
						invoice.setD_INVOICEDATE(rs.getDate("D_INVOICEDATE"));
						invoice.setC_CUSTNAME(rs.getString("C_CUSTNAME"));
						invoice.setD_TRANSACTIONDATE(rs.getDate("D_TRANSACTIONDATE"));
						invoice.setC_INVOICENO(rs.getString("C_INVOICENO"));
						invoice.setN_INVOICEAMT(rs.getDouble("N_INVOICEAMT"));
						return invoice; 
					}					
				}
		);		
		
		return list;	
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Invoice> getVerifyInvoiceInView(String startDate,String endDate,String branchCode)
	{
		
		List<Invoice> list = new ArrayList<Invoice>();
				
		String sSQL = "SELECT *" + 					  		
		              " FROM " + 
		              " ReportInvoice  " + 
		              " WHERE " +
		              " C_STATUS='1' AND C_BRANCHCODE='"+branchCode+"'" +
		              " AND CONVERT(nvarchar,D_TRANSACTIONDATE,101)>='"+startDate+"' "+
		              " AND CONVERT(nvarchar,D_TRANSACTIONDATE,101)<='"+endDate+"' " +
		              		"ORDER BY C_NAME,C_CUSTNAME";
	
		log.info("[getVerifyInvoice][debug]==>" + sSQL);
		System.out.println(sSQL);
		list = getJdbcTemplate().query
		(
				
				sSQL, new RowMapper()
				{
					
					@Override
					
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						Invoice invoice = new Invoice();
						invoice.setC_CLNTCODE(rs.getString("C_CLNTCODE"));	
						invoice.setC_NAME(rs.getString("C_NAME"));
						invoice.setD_INVOICEDATE(rs.getDate("D_INVOICEDATE"));
						//invoice.setInvoiceDate(rs.getString("D_INVOICEDATE"));
						invoice.setC_CUSTNAME(rs.getString("C_CUSTNAME"));
						invoice.setD_TRANSACTIONDATE(rs.getDate("D_TRANSACTIONDATE"));
						//invoice.setTransactionDate(rs.getString("D_TRANSACTIONDATE"));
						invoice.setC_INVOICENO(rs.getString("C_INVOICENO"));
						invoice.setN_INVOICEAMT(rs.getDouble("N_INVOICEAMT"));
						return invoice; 
					}					
				}
		);
		return list; 
	}
	
	@SuppressWarnings("unchecked")
	public List<Invoice> getVerifyInvoiceInView(String startDate,String endDate)
	{
		
		List<Invoice> list = new ArrayList<Invoice>();
				
		String sSQL = "SELECT *" + 					  		
		              " FROM " + 
		              " ReportInvoice  " + 
		              " WHERE " +
		              " C_STATUS='1' " +
		              " AND CONVERT(nvarchar,D_TRANSACTIONDATE,101)>='"+startDate+"' "+
		              " AND CONVERT(nvarchar,D_TRANSACTIONDATE,101)<='"+endDate+"' " +
		              		"ORDER BY C_NAME,C_CUSTNAME";
	
		log.info("[getVerifyInvoice][debug]==>" + sSQL);
		System.out.println(sSQL);
		list = getJdbcTemplate().query
		(
				
				sSQL, new RowMapper()
				{
					
					@Override
					
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						Invoice invoice = new Invoice();
						invoice.setC_CLNTCODE(rs.getString("C_CLNTCODE"));	
						invoice.setC_NAME(rs.getString("C_NAME"));
						invoice.setD_INVOICEDATE(rs.getDate("D_INVOICEDATE"));						
						invoice.setC_CUSTNAME(rs.getString("C_CUSTNAME"));
						invoice.setD_TRANSACTIONDATE(rs.getDate("D_TRANSACTIONDATE"));					
						invoice.setC_INVOICENO(rs.getString("C_INVOICENO"));
						invoice.setN_INVOICEAMT(rs.getDouble("N_INVOICEAMT"));
						return invoice; 
					}					
				}
		);
		return list; 
	}
	
	public boolean cancelInvoice(long InvNo, String uid){
		AuditService as = AuditService.getInstance();
		
		String C_CLNTCODE=getField("C_CLNTCODE", "Invoice", "N_INVNO="+InvNo);
		String C_CUST=getField("C_CUSTCODE", "Invoice", "N_INVNO="+InvNo);
		String C_BRANCH=getField("C_BRANCHCODE", "Invoice", "N_INVNO="+InvNo);
		String N_INVOICEAMT=getField("N_INVOICEAMT", "Invoice", "N_INVNO="+InvNo);
		
		String sSQL="update Invoice set C_STATUS='7',D_CANCELLEDDATE=(select [currentdate] FROM [factorsGetDate]),B_ADVANCES=0 where N_INVNO="+InvNo; //before:GETDATE()
		log.info("[cancelInvoice][sSQL]==>" + sSQL);
		boolean update=getJdbcTemplate().update(sSQL)>0?true:false;
		sSQL = "UPDATE CCLink SET N_RUNNINGBAL=N_RUNNINGBAL-N_INVOICEAMT FROM CCLink INNER JOIN "+
		"(SELECT C_CLNTCODE, C_CUSTCODE, SUM(N_INVOICEAMT) AS N_INVOICEAMT FROM Invoice WHERE N_INVNO="+InvNo+
		" GROUP BY C_CLNTCODE, C_CUSTCODE) b ON CCLink.C_CLNTCODE = b.C_CLNTCODE AND CCLink.C_CUSTCODE = b.C_CUSTCODE";
		update=getJdbcTemplate().update(sSQL)>0?true:false;
		log.info(sSQL);
		log.info("cclink==>"+update);
		
		String nIneligible1 = getField("N_INELIGIBLEREC","CCLink","c_clntcode="+C_CLNTCODE+" and c_custcode="+C_CUST);
		
		sSQL = "update cclink set N_INELIGIBLEREC=case when N_RUNNINGBAL > dbo.GetCCLimit(c_clntcode,c_custcode,(select [currentdate] FROM [factorsGetDate])) then"+ //before:GETDATE()
		" N_RUNNINGBAL-dbo.GetCCLimit(c_clntcode,c_custcode,(select [currentdate] FROM [factorsGetDate])) else 0 end where c_clntcode="+C_CLNTCODE+" and c_custcode="+C_CUST; //before:GETDATE()
		//sSQL = "update cclink set N_INELIGIBLEREC=(case when n_runningbal-n_cclimit > 0 then n_runningbal-n_cclimit else 0 end) where c_clntcode="+
		//C_CLNTCODE+" and c_custcode="+C_CUST;
		update=getJdbcTemplate().update(sSQL)>0?true:false;
		log.info(sSQL);
		log.info("cclink==>"+update);
		
		String nIneligible2 = getField("N_INELIGIBLEREC","CCLink","c_clntcode="+C_CLNTCODE+" and c_custcode="+C_CUST);
		
		if (update){
			as.addAudit(uid,"U","CCLink","C_CLNTCODE="+C_CLNTCODE+
			";N_RUNNINGBAL="+getField("N_RUNNINGBAL","CCLink","C_CLNTCODE="+C_CLNTCODE+" and C_CUSTCODE="+C_CUST)+
			";N_INELIGIBLEREC="+getField("N_INELIGIBLEREC","CCLink","C_CLNTCODE="+C_CLNTCODE+" and C_CUSTCODE="+C_CUST));
		}
		
		double ir=Double.parseDouble(nIneligible1)-Double.parseDouble(nIneligible2);
		
		log.info("cust ir before update..."+nIneligible1);
		log.info("cust ir after update..."+nIneligible2);
		
		sSQL="update dbCIF.dbo.Client set N_RECEIVABLES=N_RECEIVABLES-"+N_INVOICEAMT+
		",N_INELIGIBLEREC = CASE WHEN (N_INELIGIBLEREC-"+ir+")<0 then 0 ELSE (N_INELIGIBLEREC-"+ir+") END,N_RESERVES=N_RESERVES-"+N_INVOICEAMT+"+N_SCR/100*"+N_INVOICEAMT+",N_FIUTRAN = N_FIUTRAN - N_SCR / 100 *"+
		N_INVOICEAMT+" WHERE C_CLNTCODE="+C_CLNTCODE;
		log.info("[cancelInvoice][sSQL]==>" + sSQL);
		update=getJdbcTemplate().update(sSQL)>0?true:false;
		if (update){
			sSQL = "N_RECEIVABLES="+getField("N_RECEIVABLES","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+";"+
			"N_INELIGIBLEREC="+getField("N_INELIGIBLEREC","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+";"+
			"N_RESERVES="+getField("N_RESERVES","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+";"+
			"N_FIUTRAN="+getField("N_FIUTRAN","dbCIF.dbo.Client","C_CLNTCODE="+C_CLNTCODE)+";"+
			"C_CLNTCODE="+C_CLNTCODE;
			as.addAudit(uid,"U","Client",sSQL);
		}
		
		return update;
	}
								 
	public boolean updateInvoiceStatus(String stat,String where,String where2,String where3,String UserId)
	{	
		Map newData = new HashMap();
		AuditService as = AuditService.getInstance();
		String[] rec=where2.split(",");
		String[] rec2=where.split(",");
		log.info("p1:"+stat);
		log.info("p2:"+where);
		log.info("p3:"+where2);
		log.info("p4:"+UserId);
		String tmp="C_BRANCHCODE+'-'+cast(C_CLNTCODE as nvarchar)+'-'+cast(C_CUSTCODE as nvarchar)";
		int i = 0;
		
		String whr = "(C_BRANCHCODE+'-'+CAST(C_CLNTCODE AS nvarchar)+" +
			"'-'+CAST(C_CUSTCODE AS nvarchar)+'-'+C_INVOICENO+'-'+" +
			"CONVERT(varchar(10),D_INVOICEDATE, 101) IN ("+where+"))";
		String sSQL = "";
		if (stat.equals("2")){
			sSQL = "UPDATE Invoice SET C_STATUS='"+stat+"',D_TRANSACTIONDATE=CONVERT(varchar,(select [currentdate] FROM [factorsGetDate]),101) "; //before: GETDATE()
		} else {
			sSQL = "UPDATE Invoice SET C_STATUS='"+stat+"' ";
		}
		as.addAudit(UserId, "U", "INVOICE", "C_STATUS="+stat);
		log.info("updateInvoiceStatus:"+sSQL);
		if (stat.equals("7")){
			sSQL = sSQL+",D_CANCELLEDDATE=(select [currentdate] FROM [factorsGetDate]),B_ADVANCES=0 "; //before: GETDATE()
		} else {
			String upd = "UPDATE CCLink SET N_RUNNINGBAL=N_RUNNINGBAL+N_INVOICEAMT FROM CCLink INNER JOIN "+
			"(SELECT C_CLNTCODE, C_CUSTCODE, SUM(N_INVOICEAMT) AS N_INVOICEAMT FROM Invoice WHERE "+whr+
			" GROUP BY C_CLNTCODE, C_CUSTCODE) b ON CCLink.C_CLNTCODE = b.C_CLNTCODE AND CCLink.C_CUSTCODE = b.C_CUSTCODE";
			log.info("updaterunningbal==>"+upd);
			boolean updatecc=getJdbcTemplate().update(upd)>0?true:false;
			
			if (updatecc){
				for (i=0;i<rec.length;i++){
					log.info("REC------->"+rec[i]);
					as.addAudit(UserId,"U","CCLink","C_BRANCHCODE+C_CLNTCODE+C_CUSTCODE="+rec[i]+";N_RUNNINGBAL="+getField("N_RUNNINGBAL","CCLink","C_BRANCHCODE + '-' + CAST(C_CLNTCODE AS nvarchar) + '-' + CAST(C_CUSTCODE AS nvarchar) = "+rec[i]));
				}

				//log.info("where==>"+where);
				//log.info("where==>"+where2);
				//log.info("where==>"+where3);
				//log.info("UserId==>"+UserId);
			}
			log.info("updatecc==>"+updatecc);
		}
		
		sSQL = sSQL+" WHERE  "+whr;
		log.info("[updateInvoiceStatus][sSQL]==>" + sSQL);
		
		boolean update=getJdbcTemplate().update(sSQL)>0?true:false;
		
		if (update && stat.equals("2")){
			String tmpstr = "";
			for (i=0;i<rec.length;i++){
				String[] r3=rec2[i].split("-");
				String i1 = getField("N_INVOICEAMT","Invoice",tmp+"+'-'+C_INVOICENO+'-'+CONVERT(varchar(10),D_INVOICEDATE, 101)="+rec2[i]);
				//String i2 = getField("SUM(case when N_TOTINVAMT < N_AMOUNT THEN N_TOTINVAMT ELSE N_AMOUNT END)","ReceiptsHdr",tmp+"="+rec[i]+" AND C_STATUS IN ('1','2','4')");
				//String i3 = getField("sum(N_AMOUNT)","CreditNote",tmp+"="+rec[i]+" AND C_STATUS IN ('1','2')");
				//String i4 = getField("SUM(ReceiptsDtl.N_AMTINV - ReceiptsDtl.N_RECEIPTAMT)","Invoice INNER JOIN ReceiptsDtl ON Invoice.N_INVNO = ReceiptsDtl.N_INVNO","Invoice.C_BRANCHCODE+'-'+cast(Invoice.C_CLNTCODE as nvarchar)+'-'+cast(Invoice.C_CUSTCODE as nvarchar)IN("+where2+") AND Invoice.C_STATUS IN ('4')");
				if(i1 == "No Data"){i1 = "0";}
				//if(i2 == "No Data"){i2 = "0";}
				//if(i3 == "No Data"){i3 = "0";}
				//if(i4 == "No Data"){i4 = "0";}
				//String creditlimit = getField("N_CCLIMIT","CCLink",tmp+"="+rec[i]); 
				
				double CustAmt =  Double.parseDouble(i1); //+Double.parseDouble(i4)-Double.parseDouble(i2)-Double.parseDouble(i3);
				log.info(i1);
				//log.info(i2);
				//log.info(i3);
				//log.info(i4);
				log.info("CustAmt="+CustAmt);
				CustAmt = Math.round(CustAmt * 100);
				CustAmt = CustAmt / 100;
				
				String nIneligible1 = getField("sum(N_INELIGIBLEREC)","CCLink","C_BRANCHCODE+CAST(C_CLNTCODE AS nvarchar)="+r3[0]+r3[1]+"'");
				
				sSQL = "update cclink set N_INELIGIBLEREC=case when N_RUNNINGBAL > dbo.GetCCLimit(c_clntcode,c_custcode,(select [currentdate] FROM [factorsGetDate])) then"+ //before: getDate()
				" N_RUNNINGBAL-dbo.GetCCLimit(c_clntcode,c_custcode,(select [currentdate] FROM [factorsGetDate])) else 0 end where "+tmp+"="+rec[i]; //before: getDate()
				log.info("updateInvoiceStatus...cclink..."+sSQL);
				boolean update2=getJdbcTemplate().update(sSQL)>0?true:false;
				log.info("update==>"+update2);
				
				as.addAudit(UserId,"U","CCLink","C_BRANCHCODE+C_CLNTCODE+C_CUSTCODE="+rec[i]+";N_INELIGIBLEREC="+getField("N_INELIGIBLEREC","CCLink",tmp+"="+rec[i]));
				
				if (!tmpstr.contains(r3[0]+r3[1]+"-"+r3[2]+";")){
					tmpstr = tmpstr+r3[0]+r3[1]+"-"+r3[2]+";";
					
					String clientir = getField("sum(N_INELIGIBLEREC)","CCLink","C_BRANCHCODE+CAST(C_CLNTCODE AS nvarchar)="+r3[0]+r3[1]+"'");
					String nIneligible = getField("N_INELIGIBLEREC","dbCIF.dbo.Client","C_CLNTCODE="+r3[1]);
					log.info("tmpstr"+tmpstr);
					double ir=0;
					log.info("client ir should be..."+clientir);
					log.info("cust ir before update..."+nIneligible1);
					log.info("client ir actual..."+nIneligible);
					//String custir = getField("case when N_RUNNINGBAL > N_CCLIMIT then N_RUNNINGBAL-N_CCLIMIT else 0 end","CCLink",tmp+"="+rec[i]);
					log.info("cust ir computed..."+nIneligible);
					
					//if (nIneligible.equals("0.00")){
						ir=Double.parseDouble(clientir)-Double.parseDouble(nIneligible1);
					//} else {
					//	ir=Double.parseDouble(clientir);
					//}

					
					String[] wh=rec[i].split("-");
					String tmp2="C_BRANCHCODE+cast(C_CLNTCODE as nvarchar)="+wh[0]+wh[1]+"'";
					
					sSQL = "UPDATE dbCIF.dbo.Client SET N_RECEIVABLES=(select sum(n_runningbal) from cclink where c_clntcode=dbCIF.dbo.Client.c_clntcode),"+
					"N_INELIGIBLEREC=N_INELIGIBLEREC+("+ir+
					"),N_RESERVES=N_RESERVES+"+i1+"-N_SCR/100*"+i1+",N_FIUTRAN=N_FIUTRAN+N_SCR/100*"+i1+
					" WHERE C_BRANCHCODE+'-'+CAST(C_CLNTCODE AS nvarchar) IN(" + where3 + ")";
					log.info("updateClient..."+sSQL);
					update2=getJdbcTemplate().update(sSQL)>0?true:false;
					log.info("update==>"+update2);
					
					as.addAudit(UserId,"U","Client",tmp2+
						";N_RECEIVABLES="+getField("N_RECEIVABLES","dbCIF.dbo.Client",tmp2)+
						";N_INELIGIBLEREC="+getField("N_INELIGIBLEREC","dbCIF.dbo.Client",tmp2)+
						";N_RESERVES="+getField("N_RESERVES","dbCIF.dbo.Client",tmp2));
				}
				
			}
		}
		return update;	
	}
	
	public String getField(String field,String tableName,String where)
	{	
		String retVal="";
		String sSQL = "SELECT "+field+" FROM "+tableName+" WHERE "+where;

		log.info("getField==>" + sSQL);
		//System.out.println(sSQL);
		if(getJdbcTemplate().queryForList(sSQL).size()>0){
			retVal=(String) getJdbcTemplate().queryForObject
			(
					sSQL, new RowMapper (){
						@Override
						public Object mapRow(ResultSet rs, int arg1) throws SQLException {
							return rs.getString(1)!=null?rs.getString(1).trim():"No Data";

						}
					}
			);

		}
		else{
			retVal="No Data Found";
		}
		//log.info("return value"+retVal);
		return retVal;	
	}
	public static List<Invoice> geAllInvoiceByStatus(Invoice invoice){
		List<Invoice> list = new ArrayList<Invoice>();
	
//		String sSQL = "SELECT *,(DATEDIFF(dd,D_INVOICEDATE,'"+invoice.getAsOfDate()+"')+1) AS ageing FROM Invoice " +
//		  " WHERE C_CLNTCODE="+invoice.getC_CLNTCODE()+" " +
//		  " AND C_CUSTCODE="+invoice.getC_CUSTCODE()+
//		  " AND C_BRANCHCODE="+invoice.getC_BRANCHCODE() +
//		  " AND C_STATUS "+invoice.getC_STATUS();
	
		String sSQL = " select " +  
						" convert(int,(select datediff(day,inv.d_invoicedate, '"+invoice.getAsOfDate()+"'))) as ageing " +  
						" ,*  from invoice inv " +
						" inner join cc on inv.c_clntcode=cc.c_clntcode and inv.c_custcode=cc.c_custcode " +
						  " WHERE inv.C_CLNTCODE="+invoice.getC_CLNTCODE() +
						  " AND inv.C_CUSTCODE="+invoice.getC_CUSTCODE()+
						  " AND inv.C_BRANCHCODE="+invoice.getC_BRANCHCODE() +
						  " AND inv.C_STATUS "+invoice.getC_STATUS();
		
		log.info("geAllInvoiceByStatus (sSQL)= "+sSQL);
		//C_STATUS IN('2','3','4')
		Statement stmt=null;
		ResultSet rs = null;
		try{
			//stmt=getConnection().createStatement();
			Connection conn = new FactorConnection().getConnection();
			stmt=conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			while(rs.next()){
				Invoice i = new Invoice();
				i.setD_INVOICEDATE(rs.getDate("D_INVOICEDATE"));
				i.setN_INVOICEAMT(Money.doRoundOff(rs.getDouble("N_INVOICEAMT")));
				i.setN_TERM(rs.getLong("N_TERM"));
				i.setAgeing(rs.getLong("ageing"));
				i.setC_STATUS(rs.getString("C_STATUS"));
				i.setN_INVNO(rs.getLong("N_INVNO"));
				
				i.setD_INVOICEDUEDATE(rs.getDate("d_invoiceduedate"));
				
				list.add(i);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return list;
	}
	
	public static double getTotalInvoice(CC cc,String option){
		
		String year=option!=null&&option.equalsIgnoreCase("1")?DateHelper.getLastYearDate(cc.getAsOfDate()):cc.getAsOfDate();
		String sSQL="SELECT C_CUSTCODE,C_CUSTNAME,SUM(ROUND(ISNULL(N_INVOICEAMT,0.00),2)) AS amount,CAST((YEAR('"+year+"')) AS NVARCHAR) as mo "+ 
		 " FROM ReportInvoice "+ 	
		 " WHERE (D_TRANSACTIONDATE BETWEEN '01/01/'+CAST(YEAR('"+year+"') AS NVARCHAR)AND '"+year+"')  " +
		 " AND(YEAR(D_TRANSACTIONDATE) = YEAR('"+year+"')) AND (C_CLNTCODE = '"+cc.getClientCode()+"') " +
		 " AND (C_CUSTCODE = '"+cc.getCustomerCode()+"') AND (C_BRANCHCODE = '"+cc.getBranchCode()+"') "+ 
		 " GROUP BY C_CUSTCODE,C_CUSTNAME ";
		log.info("getTotalInvoice]sSQL=> " +sSQL);
		double lastYear=0.00d;
		Statement stmt=null;
		ResultSet rs=null;
		try{		
			stmt=new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
				while(rs.next()){
				BigDecimal bg = new BigDecimal(rs.getDouble("amount"));
				lastYear=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();		
				}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}
		return lastYear;
	}	

	public static List<Invoice> getAllClientInvoiceByStatus(CC cc){
		List<Invoice> list = new ArrayList<Invoice>();
		String sSQL = "SELECT *,((DATEDIFF(dd,D_INVOICEDATE,'"+cc.getAsOfDate()+"')+1)-N_TERM) AS ageing, ((DATEDIFF(dd,D_INVOICEDUEDATE,'"+cc.getAsOfDate()+"')+1)-"+cc.getDunning()+") as ageByDunning FROM Invoice " +
					  " WHERE C_CLNTCODE="+cc.getClientCode()+" " +
					  " AND C_BRANCHCODE="+cc.getBranchCode() +
					  " AND C_STATUS "+cc.getStatus();
		
		log.info("getAllInvoiceByStatus (sSQL)= "+sSQL);
		//C_STATUS IN('2','3','4')
		Statement stmt=null;
		ResultSet rs = null;
		try{
			//stmt=getConnection().createStatement();
			Connection conn = new FactorConnection().getConnection();
			stmt=conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			while(rs.next()){
				Invoice i = new Invoice();
				i.setD_INVOICEDATE(rs.getDate("D_INVOICEDATE"));
				i.setN_INVOICEAMT(Money.doRoundOff(rs.getDouble("N_INVOICEAMT")));
				i.setN_TERM(rs.getLong("N_TERM"));
				i.setC_INVOICENO(rs.getString("C_INVOICENO"));
				i.setAgeing(rs.getInt("ageing"));
				i.setAgeByDunning(rs.getLong("ageByDunning"));
				i.setC_STATUS(rs.getString("C_STATUS"));
				i.setN_INVNO(rs.getLong("N_INVNO"));			
				list.add(i);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return list;
	}
	
	public static double getPartialAmount(long invoiceNumber){
		double partialAmount=0.00d;
		String sSQL=" SELECT    (Invoice.N_INVOICEAMT - SUM(ReceiptsDtl.N_RECEIPTAMT)) AS partialAmount, " +
					"		SUM(ReceiptsDtl.N_RECEIPTAMT) AS receiptAmout, " +
					"		Invoice.N_INVNO, Invoice.N_INVOICEAMT " +
				    " FROM    Invoice INNER JOIN ReceiptsDtl " +
				    " 			ON Invoice.N_INVNO = ReceiptsDtl.N_INVNO " +
				    "LEFT JOIN ReceiptsHdr ON ReceiptsDtl.N_REFNO=ReceiptsHdr.N_REFNO " +
			        "WHERE     (ReceiptsDtl.C_TYPE in('1','2','3','4')) AND (Invoice.N_INVNO = "+invoiceNumber+") AND ReceiptsHdr.C_STATUS<>'3' " +
			        "GROUP BY Invoice.N_INVNO, Invoice.N_INVOICEAMT";					
		log.info("getPartialAmount (sSQL)= "+sSQL);
		Statement stmt=null;
		ResultSet rs = null;
		try{
			stmt=new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			while(rs.next()){
				partialAmount=Money.doRoundOff(rs.getDouble(1));
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}				
		
		return partialAmount;
	}
	
	public static void main(String[] args){
		Invoice i = new Invoice();
		i.setC_CLNTCODE("38");
		i.setC_CUSTCODE("7");
		i.setC_BRANCHCODE("02");
		i.setAsOfDate("12/01/2009");
		i.setC_STATUS("IN('2','3','4')");
		CC cc = new CC();
		cc.setBranchCode("02");
		cc.setClientCode("38");
		cc.setStatus("IN('3','4')");
		int cnt=0;
		log.info("first count: " + cnt);
		InvoiceDAO dao = new InvoiceDAO();
		List list =dao.getScheduleOfInvoices(" WHERE     (Invoice.C_STATUS BETWEEN 2 AND 6)  AND Invoice.D_TRANSACTIONDATE BETWEEN '09/01/2010' AND '09/30/2010'  AND Invoice.C_BRANCHCODE = '01' and Invoice.C_CLNTCODE=178 ",new ReportField("09/01/2010","09/30/2010"));
		//List list =dao.geAllInvoiceByStatus(i);
		//List list =dao.getAllClientInvoiceByStatus(cc);
		ListIterator iter = list.listIterator();
		int size = list.size();
		int count=0;
		/*
		while(iter.hasNext()){
			count+=1;
			if(count<=size){
				Invoice out = (Invoice)iter.next();
				log.info("out.getD_INVOICEDATE() "+out.getD_INVOICEDATE());
				log.info("out.getN_INVOICEAMT() "+out.getN_INVOICEAMT());
				log.info("out.getN_TERM() "+out.getN_TERM());
				log.info("out.getAgeing() "+out.getAgeing());
			}else{
				String overall= (String)iter.next();
				log.info(overall);
			}
			
		
			
		}
		*/	
		while(iter.hasNext()){
			cnt++;
				ReportField rf = (ReportField)iter.next();
				
				log.info("rf.getClientCode() "+rf.getClientCode());	
				log.info("rf.getCustomerCode() "+rf.getCustomerCode());					
				log.info("rf.getClientName() "+rf.getClientName());
				log.info("rf.getCustomerName() "+rf.getCustomerName());	
				log.info("rf.getTransactionDate() "+rf.getTransactionDate());
				log.info("rf.getFullyPaidDate() "+rf.getFullyPaidDate());				
				log.info("rf.getAccountOfficer() "+rf.getAccountOfficer());	
				log.info("rf.getAdvanceRatio() "+rf.getAdvanceRatio());	
				log.info("rf.getDscRate() "+rf.getDscRate());	
				log.info("rf.getScrRate() "+rf.getScrRate());	
				log.info("rf.getDiscChargeCollected() "+rf.getDiscChargeCollected());	
				log.info("rf.getInvoiceNumber() "+rf.getInvoiceNumber());	
				log.info("rf.getInvoiceAmount() "+rf.getInvoiceAmount());	
				log.info("rf.getCreditNoteAmount() "+rf.getCreditNoteAmount());	
				log.info("rf.getReceiptNumber() "+rf.getReceiptNumber());
				
				log.info("rf.getAdvanceRefNumber() "+rf.getAdvanceRefNumber());
				log.info("rf.getBlr() "+rf.getBlr());
				log.info("rf.getReceiptAmount() "+rf.getReceiptAmount());
				log.info("rf.getOS_InvAmt() "+rf.getOS_InvAmt());
				log.info("rf.getDiscountCharge() "+rf.getDiscountCharge());
				log.info("rf.getDiscAccrual() "+rf.getDiscAccrual());
				log.info("===============================================================");
				
		}
		log.info("record count: " + cnt);
		InvoiceDAO inv = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		//inv.getField("N_RATIOAMT", "Advances", " N_REFNO=1");

		//log.info("asdf "+inv.getField("N_RATIOAMT", "Advances", " N_REFNO=1"));		
	}	
	
	
	public List<ReportField>  getScheduleOfInvoices(String whereClause,ReportField r){
		List<ReportField> list = new ArrayList<ReportField>();
					
		log.info("getScheduleOfInvoices (args)= arg1: "+whereClause+" | ReportField arg2:"+r.getAsOfDate());
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		CallableStatement cs=null;
		ResultSet rs = null;
		try{
			cs=new FactorConnection().getConnection().prepareCall("{CALL sp_SCHEDULE_OF_INVOICES (?,?)}");
			cs.setString(1, whereClause);
			cs.setString(2, r.getAsOfDate());
//			cs.setString(2, r.getStartDate());
//			cs.setString(3, r.getEndDate());
			rs = cs.executeQuery();
			double blr=0.00d;
			double discountCharge=0.00d;
			String asOfDate=null;
			String clientCode=null;
			String receiptNumber=null;
			double receiptAmount=0.00d;			
			int cnt=0;
			while(rs.next()){
				cnt++;				
				double oS_InvAmt=0.00d;
				ReportField rf= new ReportField();
				rf.setTransactionDate(sdf.format(rs.getDate("asOfDate")));
				rf.setAsOfDate(rs.getString("asOfDate").trim());
				rf.setClientCode(rs.getString("clientCode").trim());
				/*
				if(cnt==1 || !asOfDate.trim().equals(rf.getTransactionDate()) || !clientCode.trim().equals(rf.getClientCode())){
					blr=getBlr(rf);
					if(asOfDate==null || 
					    !asOfDate.trim().equals(rf.getTransactionDate())) asOfDate=rf.getAsOfDate();
					if(clientCode==null || 
					   !clientCode.trim().equals(rf.getClientCode())) clientCode=rf.getClientCode();
				}				
				rf.setBlr(blr);
				*/
				//rf.setCustomerCode(rs.getString("customerCode").trim());				
				rf.setAccountOfficer(rs.getString("accountOfficer"));
				rf.setClientName(rs.getString("clientName"));
				rf.setCustomerName(rs.getString("customerName"));
				rf.setAccountOfficer(rs.getString("accountOfficer"));
				rf.setFullyPaidDate(rs.getString("fullyPaidDate"));
				rf.setInvoiceNumber(rs.getString("invoiceNumber"));
				rf.setInvoiceAmount(rs.getDouble("invoiceAmount"));
				rf.setAdvanceRefNumber(rs.getString("advanceRefNumber"));
				rf.setNTerm(rs.getLong("nTerm"));
				//rf.setReceiptNumber(rs.getString("receiptNumber"));
				/*
				if(cnt==1 || (rf.getReceiptNumber()!=null && !receiptNumber.trim().equals(rf.getReceiptNumber()))){
					receiptNumber=rf.getReceiptNumber();
					receiptAmount=getReceiptDtlAmount(rf);
				}				
				rf.setReceiptAmount(receiptAmount);
				*/
				rf.setReceiptAmount(rs.getDouble("receiptAmount"));
				rf.setAdvanceRatio(rs.getDouble("advanceRatio"));
				rf.setCreditNoteAmount(rs.getDouble("creditNoteAmount"));
				rf.setDiscChargeCollected(rs.getDouble("discChargeCollected"));
				rf.setDscRate(rs.getDouble("dscRate"));
				rf.setScrRate(rs.getDouble("scrRate"));
				rf.setServiceCharge(rs.getDouble("serviceCharge"));
				/*
				oS_InvAmt=new BigDecimal(rf.getInvoiceAmount()-(rf.getReceiptAmount()+rf.getCreditNoteAmount())).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue();
				rf.setOS_InvAmt(oS_InvAmt);
				*/
				rf.setOS_InvAmt(rs.getDouble("oS_InvAmt"));
				/*
				discountCharge = (rf.getInvoiceAmount()*rf.getAdvanceRatio()/100) * (rf.getDscRate()/100*rf.getBlr()) / 360 * rf.getNTerm();
				rf.setDiscountCharge(discountCharge);
				*/
				double discAccrual = (rs.getString("fullyPaidDate")==null)?(rs.getDouble("discAccrual")-rs.getDouble("discChargeCollected")):0.00;
				rf.setDiscAccrual(discAccrual<0?0.00:discAccrual);
				rf.setDiscountCharge(rs.getDouble("discountCharge"));
				rf.setInvoiceDate(sdf.format(rs.getDate("invoiceDate")));
				
				//RLS(redd) 01/06/2010 additional field for schedule of invoices report
				rf.setBlrExpiryDate(rs.getString("blrExpiryDate"));
				
				//--RLS(redd)  01/12/2011 add column term in sched of invoice
				rf.setInvoiceTerm(rs.getLong("invoiceTerm"));
				
				list.add(rf);	
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(cs!=null)cs.close();
			}
			catch(SQLException e){}
		}				
		
		return list;
	}
	
	public double  getBlr(ReportField rf){
		double retVal = 0.00d;
		String sSQL=" SELECT dbo.GetBLR("+rf.getClientCode()+",'"+rf.getAsOfDate()+"')";					
			//log.info("getBlr(ReportField rf) (sSQL)= "+sSQL);
		PreparedStatement stmt=null;
		ResultSet rs = null;
		try{
			stmt=new FactorConnection().getConnection().prepareStatement("SELECT dbo.GetBLR(?,?)");//.createStatement();
			stmt.setString(1, rf.getClientCode());
			stmt.setString(2, rf.getAsOfDate());
			rs = stmt.executeQuery();
			while(rs.next()){
				retVal=rs.getDouble(1);
			}
		}
		catch(Exception e){
		e.printStackTrace();
		}
		/*
		finally{
		try{
			if(rs!=null)rs.close();
			if(stmt!=null)stmt.close();
		}
		catch(SQLException e){}
		}
		*/
		return retVal;
	}
	
	public double  getReceiptDtlAmount(ReportField rf){
		double retVal = 0.00d;
		String sSQL=" SELECT dbo.GetReceiptDetailAmt('"+rf.getReceiptNumber()+"')";					
			//log.info("getReceiptDtlAmount(ReportField rf) (sSQL)= "+sSQL);
		PreparedStatement stmt=null;
		ResultSet rs = null;
		try{
			stmt=new FactorConnection().getConnection().prepareStatement("SELECT dbo.GetReceiptDetailAmt(?)");//.createStatement();
			stmt.setString(1, rf.getReceiptNumber());
			rs = stmt.executeQuery();
			while(rs.next()){
				retVal=rs.getDouble(1);
			}
		}
		catch(Exception e){
		e.printStackTrace();
		}
		/*
		finally{
		try{
			if(rs!=null)rs.close();
			if(stmt!=null)stmt.close();
		}
		catch(SQLException e){}
		}
		*/
		return retVal;
	}	
	
	public long  getSizeScheduleOfInvoices(String whereClause){
		long size = 0;
					
		log.info("getSizeScheduleOfInvoices (args)= "+whereClause);
		CallableStatement cs=null;
		ResultSet rs = null;
		try{
			cs=new FactorConnection().getConnection().prepareCall("{CALL sp_SIZE_SCHEDULE_OF_INVOICES (?)}");
			cs.setString(1, whereClause);
			rs = cs.executeQuery();
			if(rs.next()){
				size=rs.getInt(1);	
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(cs!=null)cs.close();
			}
			catch(SQLException e){}
		}
		return size;
	}	

	public Map getPenaltyCharge(Map m){
		Map penaltyMap = new HashMap();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat UDF = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
		  
		penaltyMap.put("penalty", (Double) getJdbcTemplate().queryForObject("select sum(N_PENALTYAMOUNT)from dbo.PenChargeStat34("+m.get("c_clntcode")+",'01','PC','"+UDF.format(date.newDate())+"')", Double.class)); //before:new Date()
		penaltyMap.put("pastDue",(Double) getJdbcTemplate().queryForObject("select sum(N_PENALTYAMOUNT)from dbo.PenChargeStat34("+m.get("c_clntcode")+",'01','PDI','"+UDF.format(date.newDate())+"')", Double.class)); //before:new Date()
		penaltyMap.put("N_DCREVERSAL",(Double) getJdbcTemplate().queryForObject("select dbo.getdcreversal('01',"+m.get("c_clntcode")+",'"+UDF.format(date.newDate())+"')",Double.class)); //before:  ",getdate())"
		
		System.out.println("--->>INVOICE DAO getPenaltyCharge...");
		ServiceUtility.viewUserParameters(penaltyMap);
		return penaltyMap;
	}
	
	public String getPreviousPartial(Map m){
		Map penaltyMap = new HashMap();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat UDF = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
		  
		List<String> list = new ArrayList<String>();
		
		String sSQL = "SELECT	charge_description,charge_type,charge_type_string,SUM(n_amount) n_amount,n_refno FROM(SELECT	"+
					"CASE WHEN rdo.charge_type =1 THEN 'Discount charge from transaction Ref No.: '+cast (rh.N_REFNO as nvarchar(100))	"+
						"WHEN rdo.charge_type = 2 THEN 'Unfactored Invoice from transaction Ref No.: '+cast (rh.N_REFNO as nvarchar(100))	"+
						"WHEN rdo.charge_type = 3 THEN 'Penalty Charge from transaction Ref No.: '+cast (rh.N_REFNO as nvarchar(100))	"+
					"END charge_description,	"+
					"rdo.charge_type,	"+
					"CASE WHEN rdo.charge_type =1 THEN 'Discount charge'	"+
						"WHEN rdo.charge_type = 2 THEN 'Unfactored Invoice'	"+
						"WHEN rdo.charge_type = 3 THEN 'Penalty Charge'	"+
					"END charge_type_string,	"+
					"rdo.N_Amount - rdo.collected_amount n_amount,	"+
					"rh.N_REFNO	"+
				"FROM	"+
					"ReceiptsHdr rh	"+
				"INNER JOIN	"+
					"ReceiptsDtlOther rdo on rdo.N_RefNo = rh.N_REFNO	"+
				"WHERE	"+
					"rdo.charge_status = 2	"+
					"and rh.D_DATEBOUNCED IS NULL	"+
					"and rh.c_clntcode =" + m.get("c_clntcode")+"	"+
					"and rh.N_REFNO = (select top 1 N_REFNO from ReceiptsHdr where C_CLNTCODE = rh.C_CLNTCODE and D_DATEBOUNCED is null order by N_REFNO desc))q1	"+
					"GROUP BY charge_type,charge_description,charge_type_string,N_REFNO";
		log.info("[getVerifyInvoice][debug]==>" + sSQL);
		System.out.println(sSQL);
		StringBuilder returnString = new StringBuilder();
		returnString.append(getJdbcTemplate().query
		(
				
				sSQL, new RowMapper()
				{
					
					@Override
					
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						String a = "";
						a= "{"+
						"\"charge_description\":\""+rs.getString("charge_description")+"\""+
						",\"charge_type\":\""+rs.getString("charge_type")+"\""+
						",\"charge_type_string\":\""+rs.getString("charge_type_string")+"\""+
						",\"n_amount\":\""+rs.getString("n_amount")+"\""+
						"}";
						
						return a; 
					}					
				}
		));		
		
		return returnString.toString();	
 
	}
	
	public Double getClientCE(String m){
		Map penaltyMap = new HashMap();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat UDF = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
		  
		List<String> list = new ArrayList<String>();
		
		String sSQL = "SELECT sum(balance)*((100-N_ADVANCEDRATIO)/100) CE FROM(	"+	
						"SELECT	"+
							"i.c_clntcode, i.C_INVOICENO	,i.N_INVNO,sum(i.N_INVOICEAMT)-   sum(ISNULL(q1.N_RECEIPTAMT,0))   - sum(ISNULL(q1.cn_amount,0))	AS BALANCE	"+
						"FROM 	"+
							"Invoice i	"+
						"LEFT JOIN(	"+
							"SELECT	"+
								"rd.*,ISNULL(cn.N_AMOUNT,0)cn_amount,rh.C_CLNTCODE	"+
							"FROM	"+
								"ReceiptsHdr rh	"+
							"INNER JOIN	"+ 
								"ReceiptsDtl rd on rd.N_REFNO = rh.N_REFNO	"+
							"LEFT JOIN	"+
								"CreditNote cn on cn.C_RECEIPTNO = rh.N_REFNO	"+
							"WHERE	"+
								"rh.D_DATEBOUNCED is null and	"+
								"rh.c_clntcode = "+ m +") q1 on q1.C_CLNTCODE = i.C_CLNTCODE AND q1.N_INVNO = i.N_INVNO	"+
						"WHERE	"+	
							"i.C_CLNTCODE = "+ m +"	"+
							"GROUP BY	"+	
							"i.n_invno,i.C_INVOICENO	"+	
							",i.N_INVOICEAMT,i.c_clntcode 	"+
					")q2	"+
					"INNER JOIN	"+
							"dbCIF..Client c on q2.C_CLNTCODE = 	c.C_CLNTCODE	"+
					"GROUP BY	"+
						"c.C_CLNTCODE, c.N_ADVANCEDRATIO ";	
	
		log.info("Get client CE -->" + sSQL);
		
		StringBuilder returnString = new StringBuilder();
		Double CE = 0.0;
		try{
			CE = (Double) getJdbcTemplate().queryForObject(sSQL, Double.class);
		}catch(EmptyResultDataAccessException e){
			e.printStackTrace();
		}
		return CE;
 
	}
	
	public Map<String,Double> getCISAOverdueCharges(String clntcode){
		Map<String,Double> chargesMap = new HashMap<String,Double>();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat UDF = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
		chargesMap.put("penaltyAmt", (Double) getJdbcTemplate().queryForObject("select sum(ISNULL(N_PENALTYAMOUNT,0))from dbo.PenChargeStat34("+clntcode+",'01','PC','"+UDF.format(date.newDate())+"')", Double.class));  //before:new Date()
		chargesMap.put("pastDueInterest",(Double) getJdbcTemplate().queryForObject("select sum(ISNULL(N_PENALTYAMOUNT,0))from dbo.PenChargeStat34("+clntcode+",'01','PDI','"+UDF.format(date.newDate())+"')", Double.class));  //before:new Date()
		chargesMap.put("invoiceAmount", (Double) getJdbcTemplate().queryForObject("select sum(ISNULL(N_INVOICEAMT,0))from dbo.PenChargeStat34("+clntcode+",'01','PC','"+UDF.format(date.newDate())+"')", Double.class));  //before:new Date()
		chargesMap.put("overdueDays", (Double) getJdbcTemplate().queryForObject("select MAX(ISNULL(noOfDays,0)) from dbo.PenChargeStat34("+clntcode+",'01','PC','"+UDF.format(date.newDate())+"')", Double.class));  //before:new Date()
		chargesMap.put("penaltyCount", (Double) getJdbcTemplate().queryForObject("select COUNT(rowNo) from dbo.PenChargeStat34("+clntcode+",'01','PC','"+UDF.format(date.newDate())+"')", Double.class));  //before:new Date()
		return chargesMap;
	}
	

		
	public Map getPenaltyCharge2(String c_clntcode, String c_custcode, String asOfDate,Long invoice){
		Map penaltyMap = new HashMap();
		SimpleDateFormat UDF = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
		//add custcode
		try{
			penaltyMap = getJdbcTemplate().queryForMap("select ISNULL(sum(n_penaltyamount),0.0) as penalty, duedate from dbo.getPenChargePartial('"+c_clntcode+"',01,'"+c_custcode+"',"+invoice+",'PC','"+asOfDate+"') group by duedate");
			//penaltyMap.put("penalty", (Double) getJdbcTemplate().queryForObject("select ISNULL(sum(n_penaltyamount),0.0) from dbo.getPenChargePartial('"+c_clntcode+"',01,"+invoice+",'PC','"+asOfDate+"')", Double.class));
		}catch(EmptyResultDataAccessException ers){
			log.info("No Penalty Charge");
			penaltyMap.put("penalty",0.0);
		}catch(Exception e){
			e.printStackTrace();
		}
		try{
			penaltyMap.put("pastDue", (Double) getJdbcTemplate().queryForObject("select ISNULL(sum(n_penaltyamount),0.0) from dbo.getPenChargePartial('"+c_clntcode+"',01,'"+c_custcode+"',"+invoice+",'PDI','"+asOfDate+"')", Double.class));
			}catch(EmptyResultDataAccessException ers){
				log.info("No PastDue Interest");
				penaltyMap.put("pastDue",0.0);
			}
		catch(Exception e){
			e.printStackTrace();
		}
 
 
		return penaltyMap;
	}
}
