package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.bdo.factor.beans.WeeklyBooking;
import com.bdo.factor.beans.WeeklyBookingSummary;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class WeeklyBookingSummaryField implements JRDataSource{
	private String wkMonth;

	public WeeklyBookingSummary weeklyBookingSumLst = new WeeklyBookingSummary();
	private int index = -1;
	private int lastIndex = 0;
	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	
	public WeeklyBookingSummaryField(){};
	
	public WeeklyBookingSummaryField(String asOfMonth, String branchCode) 
	{		
		System.out.println("asOfMonth : " + asOfMonth);
		WeeklyBookingSummaryDAO wkBookSumDao = (WeeklyBookingSummaryDAO)Persistence.getDAO("weeklyBookingSummaryDao");
		System.out.println("asOfMonth2 : " + asOfMonth);
    	weeklyBookingSumLst = wkBookSumDao.getWeeklyBookingSummary(branchCode, asOfMonth);
    	System.out.println("asOfMonth3 : " + asOfMonth);
    	lastIndex        = 1;  
    	wkMonth = asOfMonth;
	}
	
	@Override
	public Object getFieldValue(JRField jrField) throws JRException {
		Object value = null;

	    FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		String field = jrField.getName();	
		WeeklyBookingSummary wkBookingSum = weeklyBookingSumLst;
		
		if ("grossReceivablesWk1".equals(field))
		{
			value = df.format(wkBookingSum.getReceivablesWk1());
		}
		if ("grossReceivablesWk2".equals(field))
		{
			value = df.format(wkBookingSum.getReceivablesWk2());
		}
		if ("grossReceivablesWk3".equals(field))
		{
			value = df.format(wkBookingSum.getReceivablesWk3());
		}
		if ("grossReceivablesWk4".equals(field))
		{
			value = df.format(wkBookingSum.getReceivablesWk4());
		}
		if ("grossReceivablesWk5".equals(field))
		{
			value = df.format(wkBookingSum.getReceivablesWk5());
		}
		if ("grossReceivablesMTD".equals(field))
		{
			value = df.format(wkBookingSum.getReceivablesMTD());
		}
		if ("grossReceivablesYTD".equals(field))
		{
			value = df.format(wkBookingSum.getReceivablesYTD());
		}
		
		if ("prepaymentsWk1".equals(field)) {
			value = df.format(wkBookingSum.getPrepaymentWk1());
		}
		if ("prepaymentsWk2".equals(field)) {
			value = df.format(wkBookingSum.getPrepaymentWk2());
		}
		if ("prepaymentsWk3".equals(field)) {
			value = df.format(wkBookingSum.getPrepaymentWk3());
		}
		if ("prepaymentsWk4".equals(field)) {
			value = df.format(wkBookingSum.getPrepaymentWk4());
		}
		if ("prepaymentsWk5".equals(field)) {
			value = df.format(wkBookingSum.getPrepaymentWk5());
		}
		if ("prepaymentsMTD".equals(field)) {
			value = df.format(wkBookingSum.getPrepaymentMTD());
		}
		if ("prepaymentsYTD".equals(field)) {
			value = df.format(wkBookingSum.getPrepaymentYTD());
		}
		
		if ("prepaymentsPercentWk1".equals(field)) {
			value = wkBookingSum.getPrepaymentPercentWk1() + "%";
		}
		if ("prepaymentsPercentWk2".equals(field)) {
			value = wkBookingSum.getPrepaymentPercentWk2() + "%";
		}
		if ("prepaymentsPercentWk3".equals(field)) {
			value = wkBookingSum.getPrepaymentPercentWk3() + "%";
		}
		if ("prepaymentsPercentWk4".equals(field)) {
			value = wkBookingSum.getPrepaymentPercentWk4() + "%";
		}
		if ("prepaymentsPercentWk5".equals(field)) {
			value = wkBookingSum.getPrepaymentPercentWk5() + "%";
		}
		if ("prepaymentsPercentMTD".equals(field)) {
			value = wkBookingSum.getPrepaymentPercentMTD() + "%";
		}
		if ("prepaymentsPercentYTD".equals(field)) {
			value = wkBookingSum.getPrepaymentPercentYTD() + "%";
		}
		
		if ("collectionWk1".equals(field)) {
			value = df.format(wkBookingSum.getTotCollectionWk1());
		}
		if ("collectionWk2".equals(field)) {
			value = df.format(wkBookingSum.getTotCollectionWk2());
		}
		if ("collectionWk3".equals(field)) {
			value = df.format(wkBookingSum.getTotCollectionWk3());
		}
		if ("collectionWk4".equals(field)) {
			value = df.format(wkBookingSum.getTotCollectionWk4());
		}
		if ("collectionWk5".equals(field)) {
			value = df.format(wkBookingSum.getTotCollectionWk5());
		}
		if ("collectionMTD".equals(field)) {
			value = df.format(wkBookingSum.getTotCollectionMTD());
		}
		if ("collectionYTD".equals(field)) {
			value = df.format(wkBookingSum.getTotCollectionYTD());
		}
		
		if ("discountChargeWk1".equals(field)) {
			value = df.format(wkBookingSum.getDcWk1());
		}
		if ("discountChargeWk2".equals(field)) {
			value = df.format(wkBookingSum.getDcWk2());
		}
		if ("discountChargeWk3".equals(field)) {
			value = df.format(wkBookingSum.getDcWk3());
		}
		if ("discountChargeWk4".equals(field)) {
			value = df.format(wkBookingSum.getDcWk4());
		}
		if ("discountChargeWk5".equals(field)) {
			value = df.format(wkBookingSum.getDcWk5());
		}
		if ("discountChargeMTD".equals(field)) {
			value = df.format(wkBookingSum.getDcMTD());
		}
		if ("discountChargeYTD".equals(field)) {
			value = df.format(wkBookingSum.getDcYTD());
		}
		
		if ("dunningCycleWk1".equals(field)) {
			value = Math.round(wkBookingSum.getDunningWk1()) + "";
		}
		if ("dunningCycleWk2".equals(field)) {
			value = Math.round(wkBookingSum.getDunningWk2()) + "";
		}
		if ("dunningCycleWk3".equals(field)) {
			value = Math.round(wkBookingSum.getDunningWk3()) + "";
		}
		if ("dunningCycleWk4".equals(field)) {
			value = Math.round(wkBookingSum.getDunningWk4()) + "";
		}
		if ("dunningCycleWk5".equals(field)) {
			value = Math.round(wkBookingSum.getDunningWk5()) + "";
		}
		if ("dunningCycleMTD".equals(field)) {
			value = Math.round(wkBookingSum.getDunningMTD()) + "";
		}
		if ("dunningCycleYTD".equals(field)) {
			value = Math.round(wkBookingSum.getDunningYTD()) + "";
		}
		if("currentDate".equals(field)){
			value = date.newDate();
		}
		
		return value;
	}
	@Override
	public boolean next() throws JRException {
		index ++;
        if(index<lastIndex)
        {
            return true;
        }
        return false;
	}
	
	public double getNetWeeklyBooking(double advanceRatio, double invoiceAmt)
	{		
		return (invoiceAmt * advanceRatio);
		
	}	
	
	public double getDC(double wkAmount, double percent, double dun)
	{
		return (wkAmount * percent)/360 * dun;
	}

}
