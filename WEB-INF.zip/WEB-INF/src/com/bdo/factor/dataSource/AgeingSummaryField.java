/*@ Added by	: Roldan Somontina
 * 	Java Name	: VerifyInvoiceField.java
 * 	Date Added	: May 19, 2009
 *  Source Code for Invoice Due Report
 */ 

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dataSource.CCLinkDAO;
import com.bdo.factor.dao.Persistence;

public class AgeingSummaryField  implements JRDataSource{
	private static Logger log = Logger.getLogger(AgeingSummaryField.class);

	List<CCLink> list= new ArrayList<CCLink>();	
	private int index =-1;
	private int lastIndex = 0;
	

	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00"); 
	ClientDAO cd = new ClientDAO();
	public AgeingSummaryField(CC cc,String operation){
		list= cd.getAgeingSummaryForClient(cc,operation);
		lastIndex= list.size();		
	}
	

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		CCLink cCLink = (CCLink)list.get(index);
		

		if(list.size()>0){
			if("clientName".equals(field)){   			
				value=cCLink.getClientName();
				log.info("clientName "+cCLink.getClientName());
				
			}		
			if("nCurrent".equals(field)){   			
				value=cCLink.getN_Current();
				log.info("nCurrent "+cCLink.getN_Current());
			}			
			if("n1to30".equals(field)){   			
				value=cCLink.getN_1to30();
				log.info("n1to30 "+cCLink.getN_1to30());
			}
			if("n31to60".equals(field)){   			
				value=cCLink.getN_31to60();
				log.info("n31to60 "+cCLink.getN_31to60());
			}
			if("n61to90".equals(field)){   			
				value=cCLink.getN_61to90();
				log.info("n61to90 "+cCLink.getN_61to90());
			}
			if("n91to120".equals(field)){   			
				value=cCLink.getN_91to120();
				log.info("n91to120 "+cCLink.getN_91to120());
			}
			if("n121to150".equals(field)){   			
				value=cCLink.getN_121to150();
				log.info("n121to150 "+cCLink.getN_121to150());
			}
			if("n151to180".equals(field)){   			
				value=cCLink.getN_151to180();
				log.info("n151to180 "+cCLink.getN_151to180());
			}
			if("nOver180".equals(field)){   			
				value=cCLink.getN_Over180();
				log.info("nOver180 "+cCLink.getN_Over180());
			}
			if("nTotalOS".equals(field)){   			
				value=cCLink.getN_TotalOS();
				log.info("nTotalOS "+cCLink.getN_TotalOS());
			}
			if("percentCurrent".equals(field)){   			
				value=cCLink.getPercentCurrent();
				log.info("percentCurrent "+cCLink.getPercentCurrent());
			}
			if("percent1to30".equals(field)){   			
				value=cCLink.getPercent1to30();
				log.info("percent1to30 ");
			}
			if("percent31to60".equals(field)){   			
				value=cCLink.getPercent31to60();
				log.info("percent31to60 "+cCLink.getPercent31to60());
			}
			if("percent61to90".equals(field)){   			
				value=cCLink.getPercent61to90();
				log.info("percent61to90 "+cCLink.getPercent61to90());
			}			
			if("percent91to120".equals(field)){   			
				value=cCLink.getPercent91to120();
				log.info("percent91to120 "+cCLink.getPercent91to120());
			}
			if("percent121to150".equals(field)){   			
				value=cCLink.getPercent121to150();
				log.info("percent121to150 "+cCLink.getPercent121to150());
			}	
			if("percent151to180".equals(field)){   			
				value=cCLink.getPercent151to180();
				log.info("percent151to180 "+cCLink.getPercent151to180());
			}
			if("percentOver180".equals(field)){   			
				value=cCLink.getPercentOver180();
				log.info("percentOver180 "+cCLink.getPercentOver180());
			}						
			if("currentDate".equals(field)){   			
				value=cCLink.getCurrentdate();
				log.info("currentDate "+cCLink.getCurrentdate());
			}
		}

		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
