package com.bdo.factor.dataSource;

import java.util.ArrayList;
import java.util.List;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRException;

import com.bdo.factor.beans.CreditNote;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;


import java.text.DecimalFormat;

public class ScheduleOfCreditNotes implements JRDataSource
{	
	List<CreditNote> creditNoteList = new ArrayList<CreditNote>();
	
	private int index                 = -1;
	private int lastIndex             = 0;
	private String sDate              = "";
	private String eDate              = "";
	private String cCode              = "";
	private String branchName         = "";
	private String userID             = "";	
	private double totalCreditNoteAmt = 0.0;
	private String reportTitle        = "";
	
	public ScheduleOfCreditNotes(String branchCode, String clientCode, String startDate, String endDate, int Status)
	{
		this.setSDate(startDate);
		this.setEDate(endDate);
		this.setClientCode(clientCode);
		if (Status == 2)
		{
			this.setReportTitle("Schedule of Credit Notes");
		}
		else if (Status == 3)
		{
			this.setReportTitle("Schedule of Cancelled Credit Notes");
		}
		CreditNoteDAO creditNoteDao = (CreditNoteDAO)Persistence.getDAO("creditNoteDao");
		creditNoteList              = creditNoteDao.getScheduleOfCreditNote(branchCode, clientCode, this.getSDate(), this.getEDate(), Status);
		totalCreditNoteAmt          = creditNoteDao.getTotalCreditNoteAmt(branchCode, clientCode, this.getSDate(), this.getEDate(), Status);
		lastIndex                   = creditNoteList.size();		
	}
	
	@Override
	public Object getFieldValue(JRField jrField) throws JRException { 
		Object value = null;
		String field = jrField.getName();
		CreditNote creditnote = (CreditNote)creditNoteList.get(index);
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		if (creditNoteList.size() > 0)
		{
			if ("C_CUSTNAME".equals(field))
			{
				value = creditnote.getC_CUSTNAME();
			}
			
			if ("N_REFNO".equals(field))
			{
				value = creditnote.getN_REFNO() + "";
			}
			
			if ("D_APPLICATIONDATE".equals(field))
			{
				value = creditnote.getD_APPLICATIONDATE().toString();				
			}
			
			if ("D_TRANSACTIONDATE".equals(field))
			{
				value = creditnote.getD_TRANSACTIONDATE().toString();				
			}
			
			if ("C_INVOICENO".equals(field))
			{
				value = creditnote.getC_INVOICENO();
			}
			
			if ("D_INVOICEDATE".equals(field))
			{
				value = creditnote.getD_INVOICEDATE().toString();
			}
			
			if ("N_AMOUNT".equals(field))
			{				
				value = numberFormater(creditnote.getN_AMOUNT());
			}
			
			if ("C_DESCRIPTION".equals(field))
			{
				value = creditnote.getC_DESCRIPTION();
			}
		}
		
		if ("dateRange".equals(field))
		{
			value = "From " + this.getSDate() + " to " + this.getEDate();				
		}								
		
		if ("noofinv".equals(field))
		{
			value = lastIndex + "";			
		}
		
		if ("clientName".equals(field))
		{
			value = creditnote.getC_NAME();		
		}
		
		if ("userID".equals(field))
		{
			value = this.getUserID();
		}
		
		if ("branchName".equalsIgnoreCase(field))
		{
			value = this.getBranchName();
		}
		
		if ("totalAmt".equalsIgnoreCase(field))
		{
			value = this.numberFormater(totalCreditNoteAmt); 
		}
		
		if ("titleReport".equals(field))
		{
			value = this.getReportTitle();
		}
		if("currentDate".equals(field)){
			value = date.newDate();
		}
		return value;
	}

	public String getReportTitle() {
		return reportTitle;
	}

	public void setReportTitle(String reportTitle) {
		this.reportTitle = reportTitle;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
        if(index<lastIndex){
            return true;
        }
        return false;
	}
	
	private void setSDate(String sdate)
	{
		sDate = sdate;
	}
	
	private void setClientCode(String clientcode)
	{
		cCode = clientcode;		
	}	
	
	private void setEDate(String edate)
	{
		eDate = edate;
	}
	
	private String getClientCode()
	{
		return cCode;		
	}
	
	private String getSDate()
	{
		return sDate;		
	}
	
	private String getEDate()
	{
		return eDate;		
	}
	
	private String numberFormater(double numbertoformat)
    {
        DecimalFormat df = new DecimalFormat("###,###,##0.00");        
        return df.format(numbertoformat);        
    }

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	
	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
	
}
