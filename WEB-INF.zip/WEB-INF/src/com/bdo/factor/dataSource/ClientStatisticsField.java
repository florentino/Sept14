/**
 * @author KCabungcal 
 * 	Java Name	: ClientDebtTurnField.java * 	
 *  Source Code for ClientDebtTurnField
 **/ 

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Audit;
import com.bdo.factor.beans.ClientStatistics;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.service.ClientService;
import com.bdo.factor.service.SystemSettingService;
import com.bdo.factor.util.DateHelper;

public class ClientStatisticsField  implements JRDataSource{
	private Logger log = Logger.getLogger(ClientStatisticsField.class);

	List<ClientStatistics> clientStat = new ArrayList<ClientStatistics>();
	private int index =-1;
	private int lastIndex = 0;
	
	private String asOfDate;	
	private String clientCode;
	private String startDate;
	private String endDate;
	private String clientName;
	private String currency;
	private float dunningTotal;
	
	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	SimpleDateFormat sdf2 = new SimpleDateFormat ("MMMM yyyy");
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	//dao
	ClientStatisticsDAO cStat = (ClientStatisticsDAO)Persistence.getDAO("clientStatisticsDAO");
	
	public ClientStatisticsField(String clientCode, String asOfDate){
		this.asOfDate=asOfDate;
		
		Map param = new HashMap();
		param.put("asOfDate", asOfDate);		
		param.put("clientCode", clientCode);
				
		clientStat = cStat.getClientStatistics(clientCode, asOfDate);
		lastIndex=clientStat.size();
		
		clientName = getClientName(clientCode);
		endDate = asOfDate;
		Calendar cal = Calendar.getInstance();
		cal.setTime(DateHelper.parse(endDate));
		
		for (int i =0; i <=10; i++) {
			cal.add(Calendar.MONTH, -1);
			cal.setTime(cal.getTime());					
		}
		startDate = DateHelper.format(cal.getTime());
		
		dunningTotal = cStat.getDunningTotal(clientCode, startDate, endDate);
		
		
		currency = getCurrency(clientCode);
	}

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		ClientStatistics cdt = (ClientStatistics) clientStat.get(index);
		
		if(clientStat.size()>0){
					if("month".equals(field)){
						value=cdt.getMonth();    			
					}   		
					if("cnAmount".equals(field)){
						value=cdt.getCnAmount();    			
					}
					if("crn".equals(field)){
						value=cdt.getCrn();    			
					}
					if("discountCharge".equals(field)){
						value=cdt.getDiscountCharge();    			
					}
					if("dunning".equals(field)){
						value=cdt.getDunning();    			
					}
					if("fiu".equals(field)){
						value=cdt.getFiu();    			
					}
					
					if("invoiceAmount".equals(field)){
						value=cdt.getInvoiceAmount();    			
					}
					if("receivables".equals(field)){
						value=cdt.getReceivables();    			
					}
					if("reserves".equals(field)){
						value=cdt.getReserves();    			
					}
					if("svcCharge".equals(field)){
						value=cdt.getServiceCharge();    			
					}
					if("utilPercentage".equals(field)){
						value=cdt.getUtilPercentage();    			
					}
					
					if("clientName".equals(field)){
						value=clientName;
					} 
					if("dateRange".equals(field)){
						String sDate = sdf2.format(DateHelper.parse(startDate));
						String eDate = sdf2.format(DateHelper.parse(endDate));
						value=sDate + "-" + eDate;
					}
					if("currency".equals(field)) {
						value = currency;
					}
					if("dunningTotal".equals(field)) {
						value = dunningTotal;
					}
					if("currentDate".equals(field)) {
						value = cdt.getCurrentDate();
					}
				//}	
							
		}   
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}
	
	public String getClientName(String c_ClntCode) {
		ClientService cs = ClientService.getInstance();
		Map m = new HashMap();
		m.put("C_CLNTCODE", c_ClntCode);
		Map mResult =  cs.searchClientNameByCode(m);
		return mResult.get("result").toString();
	}
	
	public String getCurrency(String c_ClntCode) {		
		ClientService clientSvc = ClientService.getInstance();
		return clientSvc.searchClientCurrency(c_ClntCode);		
	}
	
	
	
	public static void main (String[] args) {		
		ClientStatisticsDAO cbt = (ClientStatisticsDAO)Persistence.getDAO("clientStatisticsDAO");
		List<ClientStatistics> l = cbt.getClientStatistics("38", "07/01/2009");
		ListIterator iter=l.listIterator();
		while(iter.hasNext()){
			ClientStatistics cdt = (ClientStatistics)iter.next();
			System.out.println(cdt.toString());
		}
			
				
	}

}
