package com.bdo.factor.dataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementCreatorFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.ClientDebtTurn;
import com.bdo.factor.beans.PDC;

import java.sql.PreparedStatement;

public class PDCRegistryDAO extends JdbcDaoSupport {
	private Logger log = Logger.getLogger(PDCRegistryDAO.class);
	
	@SuppressWarnings("unchecked")
	public List<PDC> getPDC(String clientCode, final String branchCode, final String startDate, final String endDate)  {
		List<PDC> lResult = new ArrayList<PDC> ();
		String sSQL = "";
		//if (clientCode != null) { 
		if (clientCode == null) {
			sSQL = "select cc.c_name, cc.c_custname, ct.c_description,bank.c_bankname, " +
				"pdc.d_checkdate, pdc.c_bankCode, pdc.n_checkNo, pdc.n_checkAmt, " +
				"pdc.c_currencyCode, pdc.b_processed, pdc.d_datebounced " +
				"from pdc " +
				"inner join cc on cc.c_clntcode = pdc.c_clntcode and  cc.c_custcode = pdc.c_custcode " +
				"inner join checktype ct on ct.c_checktypecode = pdc.c_checktypecode " +
				"inner join bank on bank.c_bankcode = pdc.c_bankcode " +
				"where pdc.d_checkdate between '" + startDate + "' and '" + endDate + "' " +
				"and pdc.c_branchcode = '" + branchCode + "'" +//and pdc.c_clntcode = '" + clientCode + "' " +
				"order by pdc.c_clntcode, pdc.c_custcode, pdc.d_checkdate";
		}
		else {	
			
			sSQL = "select cc.c_name, cc.c_custname, ct.c_description,bank.c_bankname, " +
					"pdc.d_checkdate, pdc.c_bankCode, pdc.n_checkNo, pdc.n_checkAmt, " +
					"pdc.c_currencyCode, pdc.b_processed, pdc.d_datebounced " +
					"from pdc " +
					"inner join cc on cc.c_clntcode = pdc.c_clntcode and  cc.c_custcode = pdc.c_custcode " +
					"inner join checktype ct on ct.c_checktypecode = pdc.c_checktypecode " +
					"inner join bank on bank.c_bankcode = pdc.c_bankcode " +
					"where pdc.d_checkdate between '" + startDate + "' and '" + endDate + "' " +
					"and pdc.c_branchcode = '" + branchCode + "' and pdc.c_clntcode = '" + clientCode + "' " +
					"order by pdc.c_clntcode, pdc.c_custcode, pdc.d_checkdate";
		}
		/*}
		else {
			sSQL = "select cc.c_name, cc.c_custname, ct.c_description,bank.c_bankname, " +
			"pdc.d_checkdate, pdc.c_bankCode, pdc.n_checkNo, pdc.n_checkAmt, " +
			"pdc.c_currencyCode, pdc.b_processed, pdc.d_datebounced " +
			"from pdc " +
			"inner join cc on cc.c_clntcode = pdc.c_clntcode and  cc.c_custcode = pdc.c_custcode " +
			"inner join checktype ct on ct.c_checktypecode = pdc.c_checktypecode " +
			"inner join bank on bank.c_bankcode = pdc.c_bankcode " +
			"where pdc.d_checkdate between ? and ? " +
			"and pdc.c_branchcode = ? " +
			"order by pdc.c_clntcode, pdc.c_custcode, pdc.d_checkdate";
		}*/
		log.info(sSQL);
 
		
		lResult =getJdbcTemplate().query(sSQL, new RowMapper(){
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				PDC pdc = new PDC();
				pdc.setClientName(rs.getString("c_name"));
				pdc.setCustomerName(rs.getString("c_custname"));
				pdc.setCheckType(rs.getString("c_description"));
				pdc.setBankName(rs.getString("c_bankname"));
				pdc.setD_CheckedDate(rs.getDate("d_checkdate"));
				pdc.setN_CheckNo(rs.getString("n_checkNo"));
				pdc.setN_CheckAmount(rs.getDouble("n_checkAmt"));
				pdc.setCurrencyCode(rs.getString("c_currencyCode"));
				pdc.setB_Processed(rs.getString("b_processed"));
				pdc.setD_DateBounced(rs.getDate("d_datebounced"));
				if (pdc.getD_DateBounced() == null) {
					if (pdc.getB_Processed().equalsIgnoreCase("1")) {
						pdc.setStatus("Processed");
					}
					else if (pdc.getB_Processed().equalsIgnoreCase("0")) {
						pdc.setStatus("UnProcessed");
					} 
				}
				else {
					pdc.setStatus("Bounced Check - " + pdc.getD_DateBounced());
				}
				return pdc;
			}			
		});
		
		return lResult;
	}

}
