package com.bdo.factor.dataSource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.ActualDunningBean;
import com.bdo.factor.beans.FactoringManagement;
import com.bdo.factor.service.ActualDunningService;

public class ActualDunningFields implements JRDataSource{
	private Logger log = Logger.getLogger(FactoringManagementField.class);
	private List<ActualDunningBean> lFm = new ArrayList<ActualDunningBean>();
	private int index =-1;
	private int lastIndex = 0;
	private int prevIndex=1;
	private int median=0;
	private static int records=0; 
	
	public ActualDunningFields(){}
	public ActualDunningFields(Map m){
		ActualDunningService ADS = new ActualDunningService();
		lFm= ADS.getFields(Long.valueOf(m.get("clientCode").toString()), Long.valueOf(m.get("custCode").toString()), m.get("startDate").toString(), m.get("endDate").toString());
		
		if(lFm.size()!=0){
			ActualDunningFields.setRecords(0);
			ActualDunningFields.setRecords(lFm.get(lFm.size()-1).getN_actualDunning()+10);
		}
		if((lFm.size()%20)!=0){
			median = lFm.get(lFm.size()/2).getN_actualDunning();
			ActualDunningBean ADBBuff= new ActualDunningBean();
			int counter =20-(lFm.size()%20);
			ADBBuff.setC_clntName(lFm.get(0).getC_clntName());
			ADBBuff.setC_custName(lFm.get(0).getC_custName());
			while( counter !=0){
				ADBBuff.setCount(lFm.size()+counter);
				counter--;
				lFm.add(ADBBuff);
			}
		}
		
		lastIndex = lFm.size();
	}
	
	public static int getRecords() {
		return records;
	}

	public static void setRecords(int records) {
		ActualDunningFields.records = records;
	}

	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		 
		ActualDunningBean fm = (ActualDunningBean) lFm.get(index);
		if(lFm.size() > 0&&(prevIndex!=index)&& fm.getC_invNo()!=null){
			prevIndex=index;
			createModeList(fm.getN_actualDunning());
		}
		
		if (lFm.size() > 0 && fm.getC_invNo()!=null){
			if("c_invNo".equals(field)){value=fm.getC_invNo();}
			if("n_invAmount".equals(field)){value=fm.getN_invAmount();}
			if("d_invDate".equals(field)){value=fm.getD_invDate();}
			if("d_collectDate".equals(field)){value=fm.getD_collectDate();}
			if("n_actualDunning".equals(field)){value=fm.getN_actualDunning();}
			if("n_dunningAmount".equals(field)){value=fm.getN_dunningAmount();}
		}
		if	(lFm.size()>0){
			if("c_clntName".equals(field)){value=fm.getC_clntName();}
			if("c_custName".equals(field)){value=fm.getC_custName();}
			if("count".equals(field)){value=fm.getCount();}
		}
		if(lFm.size()-1==index){
			lFm.get(index/2).getN_actualDunning();
			if("n_median".equals(field)){value=median;}
			if("n_mode".equals(field)){value=getMode();}
			if("n_proposedDunning".equals(field)){value=fm.getN_proposedDunning();}
		}
		
		return value;
	}
	
	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}
	private Map<Integer,Integer> modeList = new HashMap<Integer,Integer>();
	
	private void createModeList(int dunning){
		if(modeList.containsKey(dunning)){
			modeList.put(dunning,  modeList.get(dunning)+1);
		}else
			modeList.put(dunning,1);
	}
	
	private int getMode(){
		int mode=0;
		int value=0;
		int mode1=0;
		if(modeList.size()!=0){
			Iterator  p = modeList.keySet().iterator();
			int s;
			
			while(p.hasNext()){
				value=(Integer) p.next();
				s=(Integer) modeList.get(value);
				
				 
				if(mode==0||mode<s){
					mode=s;
					mode1=value;
				}
			}
		 //System.out.println(mode);
		}
		return mode1;
	}
}