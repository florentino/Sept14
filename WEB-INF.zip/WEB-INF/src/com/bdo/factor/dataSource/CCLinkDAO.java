
package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.Customer;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.controller.ReportController;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.util.Money;
public class CCLinkDAO extends JdbcDaoSupport {
	
	private static Logger log = Logger.getLogger(CCLinkDAO.class);
	SimpleDateFormat sdf = new SimpleDateFormat ("MM/dd/yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	
	
	@SuppressWarnings("unchecked")
	public List getCustAgingAnalysis(CCLink cc,String operation){
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		List list = new ArrayList();	
		String sSQL = 	"	SELECT *,ISNULL(B_NLACT,0) AS nAcknowledged, "+
						"		(CASE WHEN (asOfDay1>=0 AND asOfDay1<=condition1) THEN "+
						"			N_CCLIMIT ELSE "+
						"		 CASE WHEN (asOfDay2>=0 AND asOfDay2<=condition2) THEN "+
						"			N_CCLIMIT1 ELSE 0 "+
						"		 END END )AS FUNDLIMIT, "+
						"		(CASE WHEN (asOfDay1>=0 AND asOfDay1<=condition1) THEN "+
						"			D_CCEXDATE ELSE "+
						"		 CASE WHEN (asOfDay2>=0 AND asOfDay2<=condition2) THEN "+
						"			D_CCEXDATE1 ELSE '' "+
						"		 END END )AS EXPIRYDATE "+						
						"		FROM (SELECT *,DATEDIFF(DAY,D_CCAPDATE,D_CCEXDATE)+1 AS condition1, "+
						"					   DATEDIFF(DAY,D_CCAPDATE1,D_CCEXDATE1)+1 AS condition2,  "+ 
						"					   DATEDIFF(DAY,D_CCAPDATE,'"+cc.getAsOfDate()+"')+1  AS asOfDay1, "+
						"					   DATEDIFF(DAY,D_CCAPDATE1,'"+cc.getAsOfDate()+"')+1 AS asOfDay2 "+ 
						"			  FROM CC WHERE C_CLNTCODE="+cc.getC_ClntCode()+" AND C_BRANCHCODE='"+cc.getC_BranchCode()+"')AS a ";
		log.info("getCustAgingAnalysis(sSQL)= "+sSQL);
		Statement stmt=null;
		ResultSet rs = null;
		try{
			//stmt=getConnection().createStatement();  AgingByDunningList
			stmt=new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			String delim="@";
			double overallCurrent=0.00;
			double overall1to30=0.00;
			double overall31to60=0.00;
			double overall61to90=0.00;
			double overall91to120=0.00;
			double overall121to150=0.00;
			double overall151to180=0.00;
			double overallOver180=0.00;
			double overallTotalOS=0.00;				
			while(rs.next()){
				log.info("starting iteration");
				CCLink ccLink= new CCLink();
				ccLink.setClientName(rs.getString("C_NAME"));
				ccLink.setCustomerName(rs.getString("C_CUSTNAME"));
				ccLink.setFundLimit(rs.getDouble("FUNDLIMIT"));
				ccLink.setN_Term(rs.getInt("N_TERM"));				
				ccLink.setC_Dunning(rs.getLong("N_DUNNING"));
				ccLink.setD_ExDate(rs.getDate("EXPIRYDATE"));
				ccLink.setB_NLAct(rs.getInt("nAcknowledged"));
				ccLink.setCurrentdate(date.newDate());
				Invoice i = new Invoice();
				i.setC_CLNTCODE(rs.getString("C_CLNTCODE"));
				i.setC_CUSTCODE(rs.getString("C_CUSTCODE"));
				i.setC_BRANCHCODE(rs.getString("C_BRANCHCODE"));
				i.setC_STATUS("IN('2','3','4')");
				i.setAsOfDate(cc.getAsOfDate());
				double n_Current=0.00d;
				double n_1to30=0.00d;
				double n_31to60=0.00d;
				double n_61to90=0.00d;
				double n_91to120=0.00d;
				double n_121to150=0.00d;
				double n_151to180=0.00d;
				double n_over180=0.00d;
				double n_TotalOS=0.00d;
				double unapprovedRec=0.00d;
		
				long age=0;
				Date invoiceDueDateFromInvoice = date.newDate();//before:new Date();
				
				Iterator<Invoice> iter=InvoiceDAO.geAllInvoiceByStatus(i).iterator();
				UtilDAO dateDif = new UtilDAO();
				double amount = 0.00d;
				while(iter.hasNext()){
					Invoice inv = (Invoice)iter.next();
					amount=inv.getC_STATUS()!=null&&inv.getC_STATUS().equalsIgnoreCase("4")?InvoiceDAO.getPartialAmount(inv.getN_INVNO()):inv.getN_INVOICEAMT();
					amount= Money.doRoundOff(amount);
					
					invoiceDueDateFromInvoice = inv.getD_INVOICEDUEDATE();
					log.info(invoiceDueDateFromInvoice );
					log.info(inv.getAgeing());
					log.info("Invoice No.:"+inv.getN_INVNO()+" of Invoice with Status ("+inv.getC_STATUS()+")  and its Amount: "+amount);
					if(operation.equalsIgnoreCase("ccAgingAnalysisList")){
						age=inv.getAgeing()-ccLink.getN_Term(); 
						log.info("ccAgingAnalysisList" + age);
						log.info("cc.getN_Term() = "+ccLink.getN_Term());						
					}
					if(operation.equalsIgnoreCase("ccAgingByDunningList")){
						age=inv.getAgeing()-ccLink.getC_Dunning(); 
						log.info("ccAgingByDunningList" + age);
						log.info("cc.getC_Dunning() = "+ccLink.getC_Dunning());	
					}
					log.info("age under operation "+operation+" : "+age);
					if(age>0 && age<31){
						log.info(age);
						n_1to30+=amount;
					}
					else if(age>30 && age<61){
						n_31to60+=amount;
					}
					else if(age>60 && age<91){
						n_61to90+=amount;
					}
					else if(age>90 && age<121){
						n_91to120+=amount;
					}
					else if(age>120 && age<151){
						n_121to150+=amount;
					}
					else if(age>150 && age<181){
						n_151to180+=amount;
					}
					else if(age>180){
						n_over180+=amount;
					}
					else{
						n_Current+=amount;
					}
				}
				n_TotalOS = n_Current + n_1to30 + n_31to60 + n_61to90 + n_91to120 + n_121to150 + n_151to180 + n_over180;
				unapprovedRec=n_TotalOS>ccLink.getFundLimit()?n_TotalOS-ccLink.getFundLimit():0.00d;
				log.info(n_Current);
				ccLink.setN_Current(n_Current);
				ccLink.setN_1to30(n_1to30);
				ccLink.setN_31to60(n_31to60);
				ccLink.setN_61to90(n_61to90);
				ccLink.setN_91to120(n_91to120);
				ccLink.setN_121to150(n_121to150);
				ccLink.setN_151to180(n_151to180);
				ccLink.setN_over180(n_over180);
				ccLink.setN_TotalOS(n_TotalOS);
				ccLink.setUnapprovedReceivables(unapprovedRec);
				ccLink.setCurrentdate(date.newDate());
				 overallCurrent+=ccLink.getN_Current();
				 overall1to30+=ccLink.getN_1to30();
				 overall31to60+=ccLink.getN_31to60();
				 overall61to90+=ccLink.getN_61to90();
				 overall91to120+=ccLink.getN_91to120();
				 overall121to150+=ccLink.getN_121to150();
				 overall151to180+=ccLink.getN_151to180();
				 overallOver180+=ccLink.getN_Over180();
				 overallTotalOS+=ccLink.getN_TotalOS();		
				list.add(ccLink);		
			}
			list.add(df.format(overallCurrent)+delim+df.format(overall1to30)+delim+df.format(overall31to60)+delim+
					df.format(overall61to90)+delim+df.format(overall91to120)+delim+df.format(overall121to150)+delim+
					df.format(overall151to180)+delim+df.format(overallOver180)+delim+df.format(overallTotalOS));
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return list;
	}
	
	public static void main(String[] args){
		CCLinkDAO dao = new CCLinkDAO();
		CCLink cc = new CCLink();
		cc.setAsOfDate("7/02/2009");
		cc.setC_ClntCode("38");
		cc.setC_BranchCode("02");
		Iterator iter= dao.getCustAgingAnalysis(cc,"ccAgingAnalysisList").iterator();
		while(iter.hasNext()){
			CCLink ccLink=(CCLink) iter.next();
			log.info("ClientName:  "+ccLink.getClientName());
			log.info("CustomerName:  "+ccLink.getCustomerName());
			log.info("cc limit:  "+ccLink.getN_ClLimit());
			log.info("n term:  "+ccLink.getN_Term());
			log.info("current:  "+ccLink.getN_Current());
			log.info("1to30:  "+ccLink.getN_1to30());
			log.info("31to60:  "+ccLink.getN_31to60());
			log.info("61to90:  "+ccLink.getN_61to90());
			log.info("91to120:  "+ccLink.getN_91to120());			
			log.info("121to150:  "+ccLink.getN_121to150());
			log.info("151to180 :  "+ccLink.getN_151to180());
			log.info("over180:  "+ccLink.getN_Over180());
			log.info("total os :  "+ccLink.getN_TotalOS());
		}
		//UtilDAO util =(UtilDAO)Persistence.getDAO("utilDao");
		//log.info("datediff trial "+util.getDayDateDiff("01/01/2004", "02/01/2004"));
		//log.info("datediff trial "+getDayDateDiff("01/01/2004", "02/01/2004"));
	}
}
