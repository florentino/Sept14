package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.PDC;
import com.bdo.factor.beans.PartialPayment;

public class PartialPaymentDAO extends JdbcDaoSupport{
	private Logger log = Logger.getLogger(PartialPaymentDAO.class);
	
	public List<PartialPayment> getPartialPayment(String branchCode, String clientCode, String startDate, String endDate) {
		List<PartialPayment> lResult = new ArrayList<PartialPayment> ();
		String sSQL = "";
		
		if (clientCode == null) {
			sSQL = "select rd.C_Invoiceno, rd.n_refno, rd.n_amtinv, rd.n_receiptamt, rh.d_transactiondate, cc.c_custname, cc.c_name, inv.d_invoiceduedate " +
			"from receiptsdtl rd inner join receiptshdr rh on rd.n_refno = rh.n_refno " +
			"inner join invoice inv on rd.n_invno = inv.n_invno " +
			"inner join cc on cc.c_clntcode = rh.c_clntcode and cc.c_custcode = rh.c_custcode " +
			"where cc.c_branchcode = '" + branchCode + "' " +
			"and rh.d_transactiondate between '" + startDate + "' and '" + endDate + "' and rd.c_type = '2' " +
			"and rh.c_status != '3' order by cc.c_clntcode, cc.c_custcode, rd.c_invoiceno, rh.d_transactiondate";
		}
		else {
			sSQL = "select rd.C_Invoiceno, rd.n_refno, rd.n_amtinv, rd.n_receiptamt, rh.d_transactiondate, cc.c_custname, cc.c_name, inv.d_invoiceduedate " +
				"from receiptsdtl rd inner join receiptshdr rh on rd.n_refno = rh.n_refno " +
				"inner join invoice inv on rd.n_invno = inv.n_invno " +
				"inner join cc on cc.c_clntcode = rh.c_clntcode and cc.c_custcode = rh.c_custcode " +
				"where cc.c_branchcode = '" + branchCode + "' and cc.c_clntcode = '" + clientCode + "' " +
				"and rh.d_transactiondate between '" + startDate + "' and '" + endDate + "' and rd.c_type = '2' " +
				"and rh.c_status != '3' order by cc.c_clntcode, cc.c_custcode, rd.c_invoiceno, rh.d_transactiondate";
		}
		
		log.info(sSQL);
		
		lResult =getJdbcTemplate().query(sSQL, new RowMapper(){
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				PartialPayment pPayment = new PartialPayment();
				pPayment.setClientName(rs.getString("c_name"));
				pPayment.setCustomerName(rs.getString("c_custname"));
				pPayment.setInvoiceAmount(rs.getDouble("n_amtinv"));
				pPayment.setInvoiceNo(rs.getString("c_invoiceno"));
				pPayment.setReceiptAmount(rs.getDouble("n_receiptamt"));
				pPayment.setRefNo(rs.getInt("n_refno"));
				pPayment.setTransactionDate(rs.getDate("d_transactiondate"));
				pPayment.setInvoiceDueDate(rs.getDate("d_invoiceduedate"));				
				return pPayment;
			}			
		});
		
		return lResult;
	}
}
