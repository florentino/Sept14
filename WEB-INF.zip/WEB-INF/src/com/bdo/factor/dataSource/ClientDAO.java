package com.bdo.factor.dataSource;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.BLRFile;
import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.beans.MonthlyBalances;
import com.bdo.factor.beans.PostDate;
import com.bdo.factor.beans.Adjustment;
import com.bdo.factor.beans.BLR;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.PostDateDAO;
import com.bdo.factor.service.AccountingMaintenanceService;
import com.bdo.factor.service.AuditService;
import com.bdo.factor.service.BLRService;
import com.bdo.factor.service.ReceiptsDtlOtherService;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.DateUtils;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.util.Money;
import com.bdo.factor.util.ServiceUtility;


public class ClientDAO extends JdbcDaoSupport{

	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static Logger log = Logger.getLogger(ClientDAO.class);
	private static String delim="@";
	private static Money m = new Money();
	public ClientDAO(){

	}
	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/
	
	@SuppressWarnings("unchecked")
	public List getClientName()
	{		
		List<Client> list = new ArrayList<Client>();

		String sSQL = "SELECT *" + 					  		
		" FROM " + 
		" Client " + 
		"ORDER BY C_NAME";

		System.out.println(sSQL);
		list = getJdbcTemplate().query
		(				
				sSQL, new RowMapper()
				{					
					@Override					
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						Client client = new Client();
						client.setC_ClntCode(rs.getString("C_CLNTCODE"));
						client.setC_Name(rs.getString("C_NAME"));
						client.setC_Address(rs.getString("C_ADDRESS"));
						return client; 
					}					
				}
		);	
		return list;
	}

	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	@SuppressWarnings("unchecked")
	public List getClientByCode(String clientCode)
	{		
		List<Client> list = new ArrayList<Client>();

		String sSQL = "SELECT  C_NAME, C_ADDRESS " + 					  		
		"FROM " + 
		"Client WHERE C_CLNTCODE = " + clientCode;  		              

		log.info("[ClientDAO]->[getClientByCode][arg1:"+clientCode+"][debug]: "+sSQL);
		list = getJdbcTemplate().query
		(				
				sSQL, new RowMapper()
				{					
					@Override					
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						Client client = new Client();						
						client.setC_Name(rs.getString("C_NAME"));
						client.setC_Address("C_ADDRESS");
						return client; 
					}					
				}
		);	
		return list;
	}

	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/


	public String getClientNameByCode(String ClientCode)
	{		 
		String retval = "";

		retval = (String)getJdbcTemplate().queryForObject("SELECT C_NAME FROM CLIENT WHERE C_CLNTCODE = " + ClientCode, 
				new RowMapper()
		{
			@Override 
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException
			{										
				return rs.getString("C_NAME");										
			}
		}
		);

		return retval;		
	}

	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	public long getClientCodeByName(String ClientName)
	{		 
		long retval = 0;
		String sSQL = "SELECT C_CLNTCODE FROM CLIENT WHERE C_NAME = '" + ClientName + "'";
		System.out.println("[ClientDAO]->[getClientCodeByName][args1:" +ClientName+"][debug]: " +sSQL);
		retval = (Long)getJdbcTemplate().queryForObject(sSQL, 
				new RowMapper()
		{
			@Override 
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException
			{	
				System.out.println(rs.getLong("C_CLNTCODE"));
				return rs.getLong("C_CLNTCODE");							
			}
		}
		);

		return retval;		
	}

	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	public int getClientConcentrationRepCnt(String branchCode)
	{
		int retval = 0;

		String sSQL = "SELECT COUNT(C_CLNTCODE) AS cnt FROM Client WHERE N_FIU > 1000000 AND C_BRANCHCODE = '"+branchCode+"'";

		System.out.println("[ClientDAO]->[getClientConcentrationRepCnt][args1: "+branchCode+ "][debug]: " +sSQL);

		retval = (Integer)getJdbcTemplate().queryForObject(sSQL, 
				new RowMapper()
		{
			@Override 
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException
			{							
				return rs.getInt("cnt");							
			}
		}
		);		

		return retval;
	}


	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	//Added by: Roldan Somontina last June 9,2009
	public List<Client> getAllClientDetails(String clientCode)
	{		 
		List<Client> list = new ArrayList<Client>();		
		String sSQL = 	" SELECT * FROM (SELECT N_ADVANCEDRATIO,ISNULL(C.C_BRANCHCODE,'') AS C_BRANCHCODE,ISNULL(C.C_CLNTCODE,'') AS C_CLNTCODE, " +  
		"	 ISNULL(C.C_NAME,'') AS C_NAME,ISNULL(C.C_ADDRESS,'') AS C_ADDRESS,ISNULL(C.C_CONTACT,'') AS C_CONTACT, " +
		"    ISNULL(C.N_NOTARIAL,0.00) AS N_NOTARIAL, ISNULL(is_RMU,0)is_RMU, date_tagged_RMU, " +
		"	 ISNULL(C.N_RECEIVABLES,0.00) AS N_RECEIVABLES,ISNULL(C.N_RESERVES,0.00) AS N_RESERVES, " + 
		"	 ISNULL(C.N_SCR,0.00) AS N_SCR, ISNULL(C.N_DCR,0.00) AS N_DCR, ISNULL(C.C_BLRTYPECODE,'0') AS C_BLRTYPECODE, " +
		"	 (CASE WHEN ((C.C_CURRENCYCODE IS NULL)OR LTRIM(C.C_CURRENCYCODE)='')THEN S.C_CURRENCYCODE " + 
		" 	       ELSE C.C_CURRENCYCODE END) AS C_CURRENCYCODE " + 
		" FROM CLIENT C CROSS JOIN dbFactors.dbo.SYSTEMSETTINGS S)a INNER JOIN dbFactors.dbo.CURRENCY c ON a.C_CURRENCYCODE=c.C_CURRENCYCODE " +
		" WHERE C_CLNTCODE='" + clientCode + "'";

		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnectionCIF().createStatement();
			rs = stmt.executeQuery(sSQL);
			while(rs.next()){
				Client client = new Client();
				client.setC_ClntCode(rs.getString("C_CLNTCODE").trim().toUpperCase());
				client.setC_Name(rs.getString("C_NAME").trim().toUpperCase());
				client.setC_Address(rs.getString("C_ADDRESS").trim().toUpperCase());
				client.setC_Contact(rs.getString("C_CONTACT").trim().toUpperCase());
				client.setC_CurrencyCode(rs.getString("C_CURRENCYCODE").trim().toUpperCase());
				client.setC_Currency(rs.getString("C_DESCRIPTION").trim().toUpperCase());
				client.setN_Receivables(rs.getDouble("N_RECEIVABLES"));
				client.setN_Reserves(rs.getDouble("N_RESERVES"));
				client.setC_BlrTypeCode(rs.getString("C_BLRTYPECODE").trim());
				client.setN_Scr(rs.getDouble("N_SCR"));
				client.setN_Dcr(rs.getDouble("N_DCR"));
				client.setN_AdvRatio(rs.getDouble("N_ADVANCEDRATIO"));
				client.setC_BranchCode(rs.getString("C_BRANCHCODE"));
				client.setIs_rmu(rs.getBoolean("is_RMU"));
				client.setDate_tagged_rmu(rs.getDate("date_tagged_RMU"));
				//client.setNotarialFee(rs.getDouble("N_NOTARIAL"));
				list.add(client);
			}			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return list;		
	}	

	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/
	/*
	 * UPDATE 
	 * getClientFIUbyAsOfDate
	 * updateClientMonthEnd
	 * updateClientDailyFIU
	 * LAST UPDATE: 5/2/2012
	 * */
	@SuppressWarnings({ "static-access", "unchecked", "rawtypes" })
	public List<ClientActivities> getClientActivities(String clientCode,String asOfDate)
	{		 
		List<ClientActivities> list = new ArrayList<ClientActivities>();		
			String sSQL = "SELECT     * FROM ( " + 	
		"		SELECT	i.C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_INVOICEAMT AS AMOUNT, 0.00 AS AMOUNT2, N_ADVANCEDRATIO AS ADVRATIO, " +
		"				C_INVOICENO AS ref,  0 AS ref2, '1' AS category , 0 as cashDelay , '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, i.N_SVCCHGTYPE as scType " +
		"				FROM	Invoice i INNER JOIN dbCIF.dbo.CLIENT c ON i.C_CLNTCODE = c.C_CLNTCODE " +
		"				WHERE i.C_STATUS IN('2','3','4','5','6')" +
		" 				AND (i.C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"		SELECT C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"				CAST(N_REFNO AS NVARCHAR) AS REF, c_debit AS REF2,'1a' AS CATEGORY , 0 AS CASHDELAY, C_ADJREC+C_ADJRES+C_ADJFIU+C_ADJFIUBAL+a2.C_ADJDESC AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +  
		"				FROM ADJUSTMENT a INNER JOIN ADJUSTMENTTYPE a2 ON a.C_ADJCODE = a2.C_ADJCODE " +
		"				WHERE C_STATUS = '2'AND B_INCLUDED = 1 " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
		"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, N_PENALTYCHG as penaltyPayment , '' as scType " +
		"                   FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "+  
		"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2b' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment   , '' as scType " +  
        "    				FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4)  AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0  "+
		"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
        "  					 + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')"+
		"				UNION "+
		"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO,   "+
		"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2c' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " + 
		"					FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
		"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
		"   				+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
		"				UNION"	+
		"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG2 AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
		"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment"+ 
		"				, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +
		"				FROM	Advances WHERE ISNULL(N_DISCCHG2,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		//added by CVg as of 03-16-16
		"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_NOTARIAL AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
		"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2d' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +
		"				FROM	Advances WHERE ISNULL(N_NOTARIAL,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		//end
		"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
		"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +
		"				FROM	Advances WHERE     C_TYPE = 2 AND  C_STATUS IN (2,4) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
		"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +
		"				FROM	Advances WHERE     C_TYPE = 3 AND  C_STATUS IN (2,4) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '4' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment, '' as scType " +
		"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND (C_STATUS IN (1,2,4))   " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '5' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment, '' as scType " +
		"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 2 AND (C_STATUS IN (1,2,4)) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"		SELECT a.C_CLNTCODE, a.C_CUSTCODE,  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101)AS D_TRANSACTIONDATE, AMOUNT,AMOUNT2, ADVRATIO, " +
		"				REF, REF2,CATEGORY , CASHDELAY, TYPE,AMOUNT1,OVERPAYMENT,dcPayment, penaltyPayment,'' as scType  FROM ( " +
		"			SELECT rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,rdinv.D_TRANSACTIONDATE,D_FULLYPAIDDATE, ISNULL(SUM(N_RECEIPTAMT),0) AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
		"				CAST(rd2.N_REFNO  AS NVARCHAR) AS REF, rh2.C_RECEIPTTYPE AS REF2,'5A' AS CATEGORY , 0 AS CASHDELAY, '' AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +
		"				FROM RECEIPTSDTL rd2 INNER JOIN( " +
		"			SELECT DISTINCT rh.C_CLNTCODE, rh.C_CUSTCODE,rd.C_INVOICENO,rd.N_INVNO,rh.D_TRANSACTIONDATE,D_FULLYPAIDDATE FROM RECEIPTSDTL rd " + 
		"				INNER JOIN ( " + 
		"			SELECT	C_CLNTCODE, C_CUSTCODE,CAST(N_REFNO AS NVARCHAR) AS REF, D_TRANSACTIONDATE " +
		"				FROM	RECEIPTSHDR WHERE     C_RECEIPTTYPE IN (1,2,3,4) AND (C_STATUS IN (2,4)) " + 
		"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"				) AS rh ON rd.N_REFNO = rh.REF " +
		"				INNER JOIN INVOICE inv ON rd.C_INVOICENO = inv.C_INVOICENO and rd.N_INVNO = inv.N_INVNO " + 
		"				AND inv.C_STATUS IN (5,6) " +  
		"				) AS rdinv ON rd2.C_INVOICENO = rdinv.C_INVOICENO  AND rd2.N_INVNO = rdinv.N_INVNO " +
		"				INNER JOIN  RECEIPTSHDR rh2 ON rd2.N_REFNO=rh2.N_REFNO AND rh2.C_RECEIPTTYPE IN (3,4)  AND rh2.C_STATUS in (2,4)" +
		"				GROUP BY rh2.C_RECEIPTTYPE,rd2.N_REFNO,rdinv.D_TRANSACTIONDATE,rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,D_FULLYPAIDDATE " +
		"		) a where  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101) =  CONVERT(VARCHAR(10), a.D_FULLYPAIDDATE, 101) " +
		"                   UNION " +
		"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2,  0.00 AS ADVRATIO, " + 
		"			CAST(N_REFNO AS NVARCHAR) AS ref, C_STATUS ref2, '6' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment , '' as scType " +
		"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 3 AND (C_STATUS IN (2,4)) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(N_REFNO AS NVARCHAR) AS ref,C_STATUS  AS ref2, '6a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +
		"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 4 AND (C_STATUS IN (2,4)) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"      SELECT	cn.C_CLNTCODE, cn.C_CUSTCODE, cn.D_TRANSACTIONDATE, cn.N_AMOUNT AS AMOUNT,  0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(cn.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '6b' AS category , 0 as cashDelay, '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " + 
		"			FROM	CreditNote cn INNER JOIN RECEIPTSHDR rh ON cn.C_RECEIPTNO = rh.N_REFNO " +
		"			WHERE cn.C_STATUS IN(1,2) AND rh.C_STATUS <> 3 " +
		" 				AND (cn.C_CLNTCODE ='" + clientCode + "') AND (cn.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment , '' as scType " +
		"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		/*//Add Discount Charge and Penalty 
		//7d for Discount Charge
		"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7d' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
		"                   FROM	ReceiptsHdr WHERE   " +
		" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +		
		//7e for Penalty
		"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7e' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
		"                   FROM	ReceiptsHdr WHERE   " +
		" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		*/
		"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  c.D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a2' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +
		"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
		"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
		" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (c.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"    SELECT	C_CLNTCODE, C_CUSTCODE,  (CASE WHEN D_DATEBOUNCED IS NOT NULL THEN D_DATEBOUNCED ELSE D_TRANSACTIONDATE END) AS D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7b' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment, '' as scType " +
		"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  (CASE WHEN D_CANCELLEDDATE IS NOT NULL THEN D_CANCELLEDDATE ELSE D_DATEBOUNCED END) as D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
		"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7c' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +
		"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
		"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
		" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"                   UNION " +
		"    SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_REFAMT AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, " +
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9' AS category , 0 as cashDelay, C_TYPE AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, N_PDINTEREST AS dcPayment, N_PENALTYCHG as penaltyPayment, '' as scType " +
		"                   FROM	Refund WHERE  C_STATUS IN (2,4) " +
		" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
		"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
		"			union"+
		"	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "   +
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9a' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +    
        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0 "+
		"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) "+   
        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
        "			UNION "+	
        "	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, "+  
		"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9b' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, '' as scType " +    
        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
		"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)"+   
        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
        "			UNION "+	
    	"	SELECT C_CLNTCODE,0 C_CUSTCODE ,date_tagged_RMU D_TRANSACTIONDATE, ISNULL(amount_reversed,0) AS AMOUNT, 0 AS AMOUNT2, 0.0 AS ADVRATIO,'CR' as ref, 0 as ref2, 'client' AS category, 0 as cashDelay,'' as type,0 as Amount1, 0 as overPayment, 0 as dcPayment, 0 as penaltyPayment,'' as scType	"+
   	 	"	FROM dbcif..Client where is_RMU = 1 and C_CLNTCODE ='" + clientCode + "' and (date_tagged_RMU BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)	"+ 
        "           			 +'/01/'+  CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')	"+ 
        "	) a " +
        //Replace the order by fields (Previously D_TRANSACTIONDATE,catefory,ref asc)
		"	ORDER BY D_TRANSACTIONDATE,category,ref asc ";		
		log.info(" getClientActivities [args1:" +clientCode+"][debug]: " +sSQL);
		
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);

			double dcr=0.00;
			double scr=0.00;
			double blr = 0.00;
			String blrCode="";
			int day=0;
			int cashDelay=0;
			String custCode="";
			String customerName="";

			double serviceValue=0.00;
			double discountValue=0.00;
			double dcCashDelayValue=0.00;

			 
			
			//Totals
			double receivables=0.00;
			double reserves=0.00;
			double fiuTransaction=0.00;
			double fiuBalance=0.00;

			double invoices=0.00;
			double advances=0.00;
			double receipts=0.00;
			double serviceCharges=0.00;			
			double discountCharges=0.00;
			double dcOnCashDelays=0.00;
			double creditNotes=0.00;
			double refunds=0.00;
			double setupFee=0.00;
			double docStamp=0.00;
			double dcCollected=0.00;
			double dcAccruals=0.00;
			double advratio=0.00;
			double iniVal=0.00;
			int withTrans = 0;
			double lastAccruals = 0.00;
			double overpayment = 0.00;
			double rctAdvance = 0.00;
			double rctRefund = 0.00;
			double dshnrdChks = 0.00;
			double cnCancelled = 0.00;
			String type="";
			String branchCode="";
			
			double pastDueInvoices = 0.00;
			double pastDueCollected = 0.00;
			double penaltyCollected = 0.00;
			double pastDueFR = 0.00;
			
			double balance=0.00;

			//added by CVG as of 03-04-2016
			double notarial = 0.00;
			
			boolean is_rmu = false;
			
			ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
			while(clientList.hasNext()){
				ClientActivities header = new ClientActivities();
				Client client = (Client)clientList.next();
				header.setClient(client);
				header.setClientCode(clientCode);
				dcr=m.doRoundOff(client.getN_Dcr());
				scr=m.doRoundOff(client.getN_Scr());
				advratio =m.doRoundOff(client.getN_AdvRatio());
				branchCode = client.getC_BranchCode();	//rdc08132010
				blrCode = client.getC_BlrTypeCode();
				BLRFileDAO blrDao = new BLRFileDAO();
				BLRService blrService = BLRService.getInstance();
				//ListIterator<BLRFile> blrFileList = blrDao.getBLRFile(clientCode, asOfDate).listIterator();
				Map blrData = new HashMap();
				blrData.put("topCount", 3);
				blrData.put("clntCode", clientCode);
				ListIterator<BLR> blrFileList = blrService.readBLRGeneric(blrData).listIterator();
				while(blrFileList.hasNext()){
					BLR blrFile = (BLR) blrFileList.next();
					log.info("BLR: "+blrFile.getN_blr());
					log.info("Effectivity Date: "+blrFile.getD_effDt());
					log.info("Expiry Date: "+blrFile.getD_expDt());
					blr = m.doRoundOff(blrFile.getN_blr());
					log.info("blrFile.getBlr()"+blrFile.getN_blr());
					header.setBlrFile(blrFile);
					break;
				}
				log.info("advratio: "+advratio);
				
				String strMMM = DateUtils.getLastMonthMMM(asOfDate);//RLS 01/07/2011 add method in getting prefix of month (MMM) DateUtils.getLastMonthMMM(asOfDate)
				strMMM = "N_" + strMMM +"ACC";
				
				is_rmu = client.isIs_rmu();
				
				Map map2 = new HashMap();
				map2.put("C_CLNTCODE", clientCode);
				map2.put("MMM", strMMM);		
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				dcAccruals= m.doRoundOff(invoiceDAO.getLastAccrual(map2));
				log.info("dcAccruals:"+dcAccruals );

				MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
				ListIterator mbList =mbDAO.getMonthBalClntCodeAsOfDate(clientCode,asOfDate).listIterator();						
				while(mbList.hasNext()){

					MonthlyBalances mb = (MonthlyBalances)mbList.next();
					header.setTransactionDate(DateHelper.getDateInFirstDay(asOfDate));
					header.setStartDate(DateHelper.getDateInFirstDay(asOfDate));
					header.setDefinition("Balance B/F");
					header.setRef("");
					//header.setReceivables(mb.getMonthReceivables().doubleValue());
					header.setReceivables(m.doRoundOff(mb.getMonthReceivables().doubleValue()));
					//header.setReserves(mb.getMonthReserves().doubleValue());
					header.setReserves(m.doRoundOff(mb.getMonthReserves().doubleValue()));
					//header.setFiuBalance(mb.getMonthFIU().doubleValue());
					if (m.doRoundOff(mb.getMonthFIU().doubleValue())>iniVal) {	//rdc 08102010
						fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue() + dcAccruals );//header.getFiuTransaction()s;		
						header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
					} else {
						if ((m.doRoundOff(mb.getMonthFIU().doubleValue())==iniVal) && dcAccruals>0){
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue()+dcAccruals);//header.getFiuTransaction();
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
						}else{
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue());//header.getFiuTransaction();
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue()));
						}
					}
					//header.setFiuTransaction(mb.getMonthFIU().doubleValue());
					header.setFiuTransaction(m.doRoundOff(mb.getMonthFIU().doubleValue()));
					receivables=header.getReceivables();
					reserves=header.getReserves();
					fiuTransaction=header.getFiuTransaction();
					
					if((dcAccruals>0.00) && (fiuTransaction==0.00)){
						balance=header.getFiuTransaction()+dcAccruals;
					}else{
					
						balance=header.getFiuTransaction();
					} 
									
					
					break;
				}
				list.add(header);
				break;				
			}
			
			ClientActivities disc = new ClientActivities();
			disc.setDefinition("Last Month's DC Accrual");
			disc.setRef("");
			disc.setReceivables(0.00);			
			
			log.info("reserves before adding discount in balance bf "+reserves);
			if ((fiuTransaction>iniVal)||(reserves>iniVal)||receivables>iniVal) {
				
				if((dcAccruals>0.00) && (fiuTransaction==0.00)){
					fiuBalance=balance-dcAccruals;
				}else{
				    fiuBalance-=dcAccruals;
				}
				reserves+=dcAccruals;
				disc.setReserves(dcAccruals);
			} else {
				disc.setReserves(0.00);
			}
			log.info("reserves after adding discount in balance bf "+reserves);
			disc.setFiuTransaction(0.00);
			disc.setFiuBalance(fiuBalance);	
			dcAccruals=0.00;
			list.add(disc);	
			boolean rset = rs.next();	
			String ref = "";
			while(rset){
				log.info("receipts"+receipts);
				type=rs.getString("type");
				double amount =m.doRoundOff(rs.getDouble("AMOUNT")); 
				double amount1=m.doRoundOff(rs.getDouble("amount1"));
				double amount2 =m.doRoundOff(rs.getDouble("AMOUNT2"));	//rdc07152010
				double opmt = m.doRoundOff(rs.getDouble("overPayment"));
				//added 6/28/2016 for receipts dc and penalty
				double dcPayment = m.doRoundOff(rs.getDouble("dcPayment"));
				double penaltyPayment = m.doRoundOff(rs.getDouble("penaltyPayment"));
				String scType = rs.getString("scType")!=null? rs.getString("scType"):"2"; //cvg 02132017
				String ref2 = rs.getString("ref2").trim();	//rdc07152010
				String date1 = sdf.format(rs.getDate("D_TRANSACTIONDATE"));				
				String category = rs.getString("category").trim();
			
				if (date1.equals(asOfDate)) {
					day = 1;
				} else {
					day = DateHelper.getDayPerTransaction(date1, asOfDate);
				}	
				cashDelay = rs.getInt("cashDelay");
				log.info("Day: "+day);
				log.info("Category "+category);
				ClientActivities c = new ClientActivities();				
				c.setRef(rs.getString("ref"));
				c.setTransactionDate(rs.getDate("D_TRANSACTIONDATE"));				
				if(category.equalsIgnoreCase("1")){
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					c.setDefinition("Invoice");
					c.setReceivables(amount);
					receivables+=amount;
					c.setReserves(amount);
					reserves+=amount;
					c.setFiuTransaction(0.00);
					c.setFiuBalance(fiuBalance);
					invoices+=amount;	
					list.add(c);

					ClientActivities c2 = new ClientActivities();
					c2.setDefinition("Service Charge");
					c2.setRef("");
					c2.setReceivables(0.00);
					if (scType.equals("1")){ //added cvg02132017
						serviceValue=m.doRoundOff(amount*(scr/100)*(advratio/100));
					}else{
						serviceValue=m.doRoundOff(amount*(scr/100)); //old
					}
				
				
					reserves-=serviceValue;
					c2.setReserves(-1*serviceValue);						
					fiuTransaction+=serviceValue;
					c2.setFiuTransaction(serviceValue);
					c2.setFiuBalance(fiuBalance);
					serviceCharges+=serviceValue;
					list.add(c2);

				}
				else if(category.equalsIgnoreCase("1a")){
					String strTypeRec =  type.substring(0, 1);
					String strTypeRes = type.substring(1, 2);
					String strTypeFiu = type.substring(2, 3);
					String strTypeFiuBal = type.substring(3, 4);
					String strDesc = type.substring(4);
					
					if (ref2.equals("1")){
						dcCollected+=amount;
					} else {
						dcCollected-=amount;
					}
					
					//effect on receivables
					if (strTypeRec.equals("1")) {
						receivables+=amount;
						c.setReceivables(amount);
					} else if (strTypeRec.equals("2")) {
						receivables-=amount;
						c.setReceivables(-1*amount);
					} else {
						c.setReceivables(0.00);
					}
					//effect on reserves
					if (strTypeRes.equals("1")) {
						reserves+=amount;
						c.setReserves(amount);
					} else if (strTypeRes.equals("2")) {
						reserves-=amount;
						c.setReserves(-1*amount);
					} else {
						c.setReserves(0.00);
					}
					//effect on fiu
					if (strTypeFiu.equals("1")) {
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
					} else if (strTypeFiu.equals("2")) {
						fiuTransaction-=amount;
						c.setFiuTransaction(-1*amount);
					} else {
						c.setFiuTransaction(0.00);
					}
					//effect on fiu balance
					if (strTypeFiuBal.equals("1")) {
						fiuBalance+=amount;
					} else if (strTypeFiuBal.equals("2")) {
						fiuBalance-=amount;
					}
					c.setFiuBalance(fiuBalance);
					c.setDefinition(strDesc);			
					list.add(c);
				}
				else if(category.equalsIgnoreCase("client")){
					//c.setDefinition("Client Reversal");
					//c.setReceivables(0.0);
					//reserves-=amount;
					//c.setReserves(-1*amount);
					//c.setFiuTransaction(amount);
					//fiuTransaction +=amount;
					//fiuBalance +=amount;
					//c.setFiuBalance(fiuBalance);
					//list.add(c);	
				}
				else if(category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||category.equalsIgnoreCase("2a")||category.equalsIgnoreCase("2c")||category.equalsIgnoreCase("2d")){					
						if(category.equalsIgnoreCase("2"))c.setDefinition("Advances");
						if(category.equalsIgnoreCase("3"))c.setDefinition("Setting-up Fee");
						if(category.equalsIgnoreCase("3a"))c.setDefinition("Advances - Unfactored");
						if(category.equalsIgnoreCase("2a"))c.setDefinition("Doc Stamp");
						if(category.equalsIgnoreCase("2b"))c.setDefinition("Penalty Charge");
						if(category.equalsIgnoreCase("2c"))c.setDefinition("PD - Discount Charge");
						if(category.equalsIgnoreCase("2d"))c.setDefinition("Notarial Fee");
						//08042010
						c.setReceivables(0.00);
						reserves-=amount;
						c.setReserves(-1*amount);
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
						c.setFiuBalance(fiuBalance);
						if(category.equalsIgnoreCase("2")) advances+=amount;			
						list.add(c);
						
						
						if(category.equalsIgnoreCase("2")) {
							discountValue=m.doRoundOff(getDiscountCharge(amount2,blr,dcr,day));

							try{
							Statement s = null;
							ResultSet r = null;
							
							s= new FactorConnection().getConnection().createStatement();
							String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
							"on rh.N_REFNO=rd.N_REFNO inner join Advances adv on	"+
							"adv.N_REFNO=rh.n_advpaymentno inner join "+
							"Invoice inv on rd.N_INVNO=inv.n_invno	"+
							"where rh.C_CLNTCODE='"+clientCode+"' and adv.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
							r= s.executeQuery(query);
							
							if(r.next()){
								double val = r.getDouble("amount")*((100-advratio)/100);
								if(val!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CN Adjustment From Advance");
									op.setRef("");
									op.setReceivables(0.00);
									op.setReserves(0.00);
									op.setFiuTransaction(val);
									fiuTransaction +=val;
									fiuBalance +=val;
									op.setFiuBalance(fiuBalance);
									list.add(op);
								}
							}
							if(penaltyPayment!=0){
								ClientActivities penaltyPaymentCA = new ClientActivities();
								penaltyPaymentCA.setDefinition("Penalty Charge");
								penaltyPaymentCA.setReceivables(0.00);
								reserves-=penaltyPayment;
								penaltyPaymentCA.setReserves(-1*penaltyPayment);
								fiuTransaction+=penaltyPayment;
								penaltyPaymentCA.setFiuTransaction(penaltyPayment);
								penaltyPaymentCA.setFiuBalance(fiuBalance);
								penaltyPaymentCA.setTransactionDate(null);
								penaltyPaymentCA.setRef(null);
								penaltyCollected += penaltyPayment ;
								list.add(penaltyPaymentCA);
							}
							
							
							}
							catch(Exception e){
								e.printStackTrace();
							}	
														
						} else if(category.equalsIgnoreCase("3")) {
								setupFee = amount;
								/*discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,1));	
								dcCollected+=discountValue;*/
						} else if(category.equalsIgnoreCase("3a")) {
							discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,day));
						} else if(category.equalsIgnoreCase("2a")){
							c.setTransactionDate(null);
							c.setRef(null);
							docStamp =  amount; 
						}
						 else if(category.equalsIgnoreCase("2b")){
							 c.setTransactionDate(null);
							 c.setRef(null);
							 penaltyCollected += amount ;
						 }
						 else if(category.equalsIgnoreCase("2c")){
							 pastDueCollected += amount;
							 c.setTransactionDate(null);
							 c.setRef(null);
						 }
						 else if(category.equalsIgnoreCase("2d")){
							 pastDueCollected += amount;
							 c.setTransactionDate(null);
							 c.setRef(null);
							 notarial =  amount; 
						 }
						withTrans = 1;
						
				}	

				else if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("5")||category.equalsIgnoreCase("7a")||category.equalsIgnoreCase("7d")){
					//Added for Discount Charge and penalty for receipt payment
					/*if(category.equalsIgnoreCase("7d")){
						if(amount!=0){
							c.setTransactionDate(null);
							c.setDefinition("Discount Charge");
							c.setReceivables(0.00);
							reserves-=amount;
							c.setReserves(-1*amount);
							fiuTransaction+=amount;
							c.setFiuTransaction(amount);
							c.setFiuBalance(fiuBalance);
							dcCollected += amount;
							list.add(c);
						}
					}
					else if(category.equalsIgnoreCase("7e")){
						if(amount !=0){
							c.setTransactionDate(null);
							c.setDefinition("Penalty Charge");
							c.setReceivables(0.00);
							reserves-=amount;
							c.setReserves(-1*amount);
							fiuTransaction+=amount;
							c.setFiuTransaction(amount);
							c.setFiuBalance(fiuBalance);
							penaltyCollected += amount;
							list.add(c);
						}
					}
					else{*/
						log.info("Receipts cat4 and 5 here....");
						if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
							custCode=rs.getString("C_CUSTCODE");
							customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
						}					
						if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("7a"))c.setDefinition("RCT-CHK-"+customerName);
						if(category.equalsIgnoreCase("5"))c.setDefinition("RCT-CSH-"+customerName);	
							receivables-=amount-opmt;
							
							//fiuBalance-=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
							receipts+=amount;
							c.setReceivables(-1*(amount-opmt));
							//c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
							if(is_rmu){
								c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
								fiuTransaction-=m.doRoundOff((amount-opmt));
								fiuBalance-=m.doRoundOff((amount-opmt));	//rdc08092010
							}else{
								c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
								fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
								fiuBalance-=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
							}
						log.info("amount: "+amount);
						log.info("amount1: "+amount1);
						amount=(amount1<amount)?amount1:amount;
						log.info("amount to be computed for discount: "+amount);
						discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
						c.setReserves(0.00);
						c.setFiuBalance(fiuBalance);
						list.add(c);
							if(opmt!=0){	
								ClientActivities op = new ClientActivities();
								op.setDefinition("Over Payment");
								op.setRef("");
								op.setReceivables(0.00);
								overpayment+=opmt;
								op.setReserves(opmt);
								reserves+=opmt;
								op.setFiuTransaction(0.00);
								op.setFiuBalance(fiuBalance);
								list.add(op);							
							}
							

							if(dcPayment!=0){
								ClientActivities dc = new ClientActivities();
								dc.setTransactionDate(null);
								dc.setDefinition("Discount Charge");
								dc.setReceivables(0.00);
								reserves-=dcPayment;
								dc.setReserves(-1*dcPayment);
								//fiuTransaction+=dcPayment;
								dc.setFiuTransaction(0.00);
								dc.setFiuBalance(fiuBalance);
								dcCollected += dcPayment;
								list.add(dc);
							}
							
							if(penaltyPayment !=0){
								ClientActivities pc = new ClientActivities();
								pc.setTransactionDate(null);
								pc.setDefinition("Penalty Charge");
								pc.setReceivables(0.00);
								reserves-=penaltyPayment;
								pc.setReserves(-1*penaltyPayment);
								//fiuTransaction+=penaltyPayment;
								pc.setFiuTransaction(0.00);
								pc.setFiuBalance(fiuBalance);
								penaltyCollected += penaltyPayment;
								list.add(pc);
							}
							
							//Unfactored Invoice
							ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
							Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
							if(unfactoredAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("Unfactored Invoices");
								ua.setReceivables(0.00);
								reserves-=unfactoredAmount;
								ua.setReserves(-1*unfactoredAmount);
								//fiuTransaction+=penaltyPayment;
								ua.setFiuTransaction(0.00);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							
							//Discount Charge
							Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
							if(dcAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("RMU Discount Charge");
								ua.setReceivables(dcAmount);
								receivables += dcAmount;
								//reserves-=dcAmount;
								//ua.setReserves(-1*dcAmount);
								ua.setReserves(0);
								fiuTransaction+=dcAmount;
								fiuBalance += dcAmount;
								ua.setFiuTransaction(dcAmount);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							//Penalty
							Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
							if(penaltyAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("RMU Penalty Charge");
								ua.setReceivables(penaltyAmount);
								receivables += penaltyAmount;
								//reserves-=penaltyAmount;
								//ua.setReserves(-1*penaltyAmount);
								ua.setReserves(0);
								fiuTransaction+=penaltyAmount;
								fiuBalance += penaltyAmount;
								ua.setFiuTransaction(penaltyAmount);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							 
							
					//}
				}
				else if(category.equalsIgnoreCase("5a")){
					ClientActivities pp = new ClientActivities();
					if(ref2.contentEquals("3")||ref2.contentEquals("4"))
					{
								/*if(ref2.contentEquals("3")){
									pp.setDefinition("CN Adjustment from Advance");
								}
								else if(ref2.contentEquals("4")){
									pp.setDefinition("CN Adjustment from Refund");
								}*/
					}
					else{
						pp.setDefinition("Previous Partial Payment");
					//pp.setRef(rs.getString("ref"));
					pp.setReceivables(0.00);
					pp.setReserves(0.00);
					fiuTransaction+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuTransaction(amount*m.doRoundOff((100-advratio)/100));	
					fiuBalance+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuBalance(fiuBalance);
					list.add(pp);}
				}

				else if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")||category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
					log.info("RCT-ADV and RCT-REF here....");
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
						if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
							custCode=rs.getString("C_CUSTCODE");
							customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
						}						
						
						//////////
						
						
						
						if(category.equalsIgnoreCase("6")){
							c.setDefinition("RCT-ADV-"+customerName);
							rctAdvance+=amount;
						}
						if(category.equalsIgnoreCase("6a")){
							c.setDefinition("RCT-REF-"+customerName);
							rctRefund+=amount;
						}
					
					}
					if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
						if(is_rmu){
							c.setDefinition("RMU Credit Note");
						}else
							c.setDefinition("Credit Note");
						creditNotes+=amount;
					}
					receivables-=amount-opmt;
					c.setReceivables(-1*(amount-opmt));
					
					
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")) {
						c.setReserves(0.00);
						if(rs.getString("ref2").equalsIgnoreCase("2")){
							fiuTransaction-=(amount*(advratio/100))-opmt;
							c.setFiuTransaction(-1*((amount*(advratio/100))-opmt));
							fiuBalance-=(amount*(advratio/100))-opmt;
						}else{
							fiuTransaction-=amount-opmt;
							c.setFiuTransaction(-1*(amount-opmt));
							fiuBalance-=amount-opmt;
						}
						 
						
					} else {
						if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
							if(is_rmu){
								reserves-=amount;
								c.setReserves(-1*amount);
								//fiuTransaction-=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(0);
								//fiuBalance-=m.doRoundOff(amount*(advratio/100));
							}else{
								reserves-=amount;
								c.setReserves(-1*amount);
								fiuTransaction-=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
								fiuBalance-=m.doRoundOff(amount*(advratio/100));
							}
							
						}else{
							reserves-=amount;
							c.setReserves(-1*amount);
							fiuTransaction-=m.doRoundOff(amount*(advratio/100));
							c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
							fiuBalance-=m.doRoundOff(amount*(advratio/100));
						}
					}	
					c.setFiuBalance(fiuBalance);
					log.info("amount: "+amount);
					log.info("amount1: "+amount1);
					amount=(amount1<amount)?amount1:amount;
					log.info("amount to be computed for discount: "+amount);
						
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
						if(opmt!=0){	
							ClientActivities op = new ClientActivities();
							op.setDefinition("Over Payment");
							op.setRef("");
							op.setReceivables(0.00);
							overpayment+=opmt;
							op.setReserves(opmt);
							reserves+=opmt;
							op.setFiuTransaction(0.00);
							op.setFiuBalance(fiuBalance);
							list.add(op);							
						}
						
						
					}						
					list.add(c);
					/*if(category.equalsIgnoreCase("6")&&!rs.getString("ref2").contentEquals("0")){
						try{
							Statement s = null;
							ResultSet r = null;
							s = new FactorConnection().getConnection().createStatement();
							String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
							log.info(sql);
							r = s.executeQuery(sql);
							if(r.next()){
								if(r.getDouble("partialAmount")!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CE Adjustment From RCT-ADV (Partial Payment)");
									op.setRef("");
									op.setReceivables(0.0);
									double partial = amount *((100-advratio)/100);
									op.setReserves(-partial);
									reserves -= partial;
									op.setFiuTransaction(partial);
									fiuTransaction+=partial;
									fiuBalance+=partial;
									op.setFiuBalance(fiuBalance);
									list.add(op);
									
								}
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				else if(category.equalsIgnoreCase("6a")&&!rs.getString("ref2").contentEquals("0")){
					try{
						Statement s = null;
						ResultSet r = null;
						s = new FactorConnection().getConnection().createStatement();
						String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
						log.info(sql);
						r = s.executeQuery(sql);
						if(r.next()){
							if(r.getDouble("partialAmount")!=0){
								ClientActivities op = new ClientActivities();
								op.setDefinition("CE Adjustment From RCT-REF (Partial Payment)");
								op.setRef("");
								op.setReceivables(0.0);
								double partial = amount *((100-advratio)/100);
								op.setReserves(-partial);
								reserves -= partial;
								op.setFiuTransaction(partial);
								fiuTransaction+=partial;
								fiuBalance+=partial;
								op.setFiuBalance(fiuBalance);
								list.add(op);
								
							}
						}
						
					}catch(Exception e){
						e.printStackTrace();
					}
				}*/
				}
				else if(category.equalsIgnoreCase("7b")){
					c.setDefinition("Dishonored Check");
					c.setReserves(0.00);					
					receivables+=amount-opmt;
					dshnrdChks+=amount-opmt;
					//fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
					//fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					
					if(is_rmu){
						c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
						fiuTransaction+=m.doRoundOff((amount-opmt));
						fiuBalance+=m.doRoundOff((amount-opmt));	//rdc08092010
					}else{
						c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
						fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
						fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					}
					
					c.setReceivables(amount-opmt);
					c.setFiuTransaction(m.doRoundOff((amount-opmt)*(advratio/100)));
					c.setFiuBalance(fiuBalance);
					list.add(c);
					if(opmt!=0){	
						ClientActivities op = new ClientActivities();
						op.setDefinition("Reversal of OP");
						op.setRef("");
						op.setReceivables(0.00);
						op.setReserves(-1*opmt);
						reserves-=opmt;
						op.setFiuTransaction(0.00);
						op.setFiuBalance(fiuBalance);
						list.add(op);							
					}
					
					if(dcPayment!=0){
						ClientActivities dc = new ClientActivities();
						dc.setTransactionDate(null);
						dc.setDefinition("Reversal Discount Charge");
						dc.setReceivables(0.00);
						reserves+=dcPayment;
						dc.setReserves(1*dcPayment);
						//fiuTransaction-=dcPayment;
						dc.setFiuTransaction(0.00);
						dc.setFiuBalance(fiuBalance);
						dcCollected -= dcPayment;
						list.add(dc);
					}
					
					if(penaltyPayment !=0){
						ClientActivities pc = new ClientActivities();
						pc.setTransactionDate(null);
						pc.setDefinition("Reversal Penalty Charge");
						pc.setReceivables(0.00);
						reserves+=penaltyPayment;
						pc.setReserves(1*penaltyPayment);
						//fiuTransaction-=penaltyPayment;
						pc.setFiuTransaction(0.00);
						pc.setFiuBalance(fiuBalance);
						penaltyCollected -= penaltyPayment;
						list.add(pc);
					}
					//Unfactored Invoice
					ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
					Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
					if(unfactoredAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal Unfactored Invoices");
						ua.setReceivables(0.00);
						reserves+=unfactoredAmount;
						ua.setReserves(1*unfactoredAmount);
						//fiuTransaction+=penaltyPayment;
						ua.setFiuTransaction(0.00);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					//Discount Charge
					Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
					if(dcAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal RMU Discount Charge");
						ua.setReceivables(-1*dcAmount);
						receivables -= dcAmount;
						//reserves-=dcAmount;
						//ua.setReserves(-1*dcAmount);
						ua.setReserves(0);
						fiuTransaction-=dcAmount;
						fiuBalance -= dcAmount;
						ua.setFiuTransaction(-1*dcAmount);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					//Penalty
					Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
					if(penaltyAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal RMU Penalty Charge");
						ua.setReceivables(-1*penaltyAmount);
						receivables -= penaltyAmount;
						//reserves-=penaltyAmount;
						//ua.setReserves(-1*penaltyAmount);
						ua.setReserves(0);
						fiuTransaction-=penaltyAmount;
						fiuBalance -= penaltyAmount;
						ua.setFiuTransaction(-1*penaltyAmount);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					
//					if (amount2 !=0){
//						ClientActivities receiptDCReversal = new ClientActivities();
//						receiptDCReversal.setDefinition("Reversal of DC-Receipt");
//						receiptDCReversal.setRef("");
//						receiptDCReversal.setReceivables(0.00);
//						receiptDCReversal.setReserves(-1*amount2);
//						reserves-=amount2;
//						receiptDCReversal.setFiuTransaction(0.00);
//						receiptDCReversal.setFiuBalance(fiuBalance);
//						list.add(receiptDCReversal );
//					}
					
				}
				else if(category.equalsIgnoreCase("7c")){
					c.setDefinition("Cancelled CN");
					receivables+=amount-opmt;
					cnCancelled+=amount;
					c.setReceivables(amount-opmt);
					reserves+=amount;
					c.setReserves(amount);
					fiuTransaction+=m.doRoundOff(amount*(advratio/100));
					c.setFiuTransaction(m.doRoundOff(amount*(advratio/100)));
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					c.setFiuBalance(fiuBalance);
					list.add(c);
				}
				else if(category.equalsIgnoreCase("9")){
					
					//if(category.equalsIgnoreCase("9a"))c.setDefinition("Penalty Charge");
					//if(category.equalsIgnoreCase("9b"))c.setDefinition("PD - Discount Charge");
					if(type.equalsIgnoreCase("1"))c.setDefinition("Refund");
					if(type.equalsIgnoreCase("2"))c.setDefinition("Refund with Overpayment");
					if(type.equalsIgnoreCase("3"))c.setDefinition("Refund - Unfactored Invoice");
					if(type.equalsIgnoreCase("4"))c.setDefinition("Refund - Prev CN");	
					
					
					
					c.setReceivables(0.00);
					reserves-=amount;
					c.setReserves(-1*amount);						
					c.setFiuTransaction(0.00);	
					c.setFiuBalance(fiuBalance);
					if(!category.equalsIgnoreCase("9a")&&!category.equalsIgnoreCase("9b")){
						refunds+=amount;
						discountValue=	amount2;	
						
					}
					else
					{
						if(category.equalsIgnoreCase("9a"))
							penaltyCollected += amount ;	
						else
							pastDueCollected += amount;
						
						c.setTransactionDate(null);
						c.setRef(null);
					}
					
					list.add(c);
					if(type.equalsIgnoreCase("1")){
						try{
							Statement s = null;
							ResultSet r = null;
							
							s= new FactorConnection().getConnection().createStatement();
							String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
							"on rh.N_REFNO=rd.N_REFNO inner join refund ref on	"+
							"ref.N_REFNO=rh.n_refpaymentno inner join "+
							"Invoice inv on rd.N_INVNO=inv.n_invno	"+
							"where rh.C_CLNTCODE='"+clientCode+"' and ref.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
							r= s.executeQuery(query);
							
							if(r.next()){
								double val = r.getDouble("amount")*((100-advratio)/100);
								if(val!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CN Adjustment From Refund");
									op.setRef("");
									op.setReceivables(0.00);
									op.setReserves(0.00);
									op.setFiuTransaction(val);
									fiuTransaction +=val;
									fiuBalance +=val;
									op.setFiuBalance(fiuBalance);
									list.add(op);
								}
							}
							
							}
							catch(Exception e){
								e.printStackTrace();
							}	
					}
					if(dcPayment!=0){
						ClientActivities dcClientActivities = new ClientActivities();
						dcClientActivities.setDefinition("PD - Discount Charge");
						dcClientActivities.setReceivables(0.00);
						reserves-=dcPayment;
						dcClientActivities.setReserves(-1*dcPayment);						
						dcClientActivities.setFiuTransaction(0.00);
						dcClientActivities.setFiuBalance(fiuBalance);
						pastDueCollected+=dcPayment;
						list.add(dcClientActivities);
					}
					if(penaltyPayment!=0){
						ClientActivities penaltyPaymentClientActivities = new ClientActivities();
						penaltyPaymentClientActivities.setDefinition("Penalty Charge");
						penaltyPaymentClientActivities.setReceivables(0.00);
						reserves-=penaltyPayment;
						penaltyPaymentClientActivities.setReserves(-1*penaltyPayment);						
						penaltyPaymentClientActivities.setFiuTransaction(0.00);
						penaltyPaymentClientActivities.setFiuBalance(fiuBalance);
						pastDueCollected+=penaltyPayment;
						list.add(penaltyPaymentClientActivities);
					}
				}
				if(category.equalsIgnoreCase("2")||
				   //category.equalsIgnoreCase("3")||
				   category.equalsIgnoreCase("3a")||
				  (category.equalsIgnoreCase("9")&&amount2!=0)
				)
				{
					ClientActivities c3 = new ClientActivities();
				//rdc 08042010	
						c3.setDefinition("Discount Charge");
						c3.setRef("");
						if(category.equalsIgnoreCase("9")&&(type.equalsIgnoreCase("2")||type.equalsIgnoreCase("3")||type.equalsIgnoreCase("4"))){
						}
						else{
							c3.setReceivables(0.00);
						}					
						if(category.equalsIgnoreCase("2") 		
						   ||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")
						   ||category.equalsIgnoreCase("9")){
						   	if (category.equalsIgnoreCase("9")) dcCollected+=amount2;
							if (category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")){ 
								if (amount2>0) {
									c3.setReserves(-1*amount2);
								} else {
									c3.setReserves(amount2);
								}
								reserves-=(amount2);
								fiuTransaction+=amount2;
								c3.setFiuTransaction(amount2); 
								if (category.equalsIgnoreCase("2")) {
									discountCharges=amount2;
									dcCollected+=amount2;
								}
							} else {
								c3.setReserves(-1*discountValue);
								log.info("reserves before adding discount charges: "+reserves);
								reserves+=(-1*discountValue);
								log.info("reserves before adding discount charges: "+reserves);
								
								if (!category.equalsIgnoreCase("9")) {
									c3.setFiuTransaction(discountValue);
									fiuTransaction+=discountValue;
									fiuBalance+=discountValue;
								} else {
									c3.setFiuTransaction(0.00);
								}
							}
							
						}
						else{
							c3.setReserves(0.00); 	//rdc07122010
							c3.setFiuTransaction(0.00);
						}
						c3.setFiuBalance(fiuBalance);
						list.add(c3);	
				}
				rset = rs.next();	//08282010
			}
			
			if(!rset){
				//rdc 08092610 ..... 
				Date today = DateHelper.parse(asOfDate);
				Map map = new HashMap();
				map.put("ADVRATIO", advratio/100.00);
				map.put("BLR", blr/100.00);
				map.put("DCR", dcr/100.00);
				map.put("C_CLNTCODE", clientCode);
				map.put("asOfDate", asOfDate);
				map.put("today", DateHelper.parse(DateHelper.format(today)));
						
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				dcAccruals= m.doRoundOff(invoiceDAO.getDCAccrual2(map));
				log.info("dcAccruals:"+dcAccruals );
				log.info("receivables:"+receivables );
				log.info("reserves:"+reserves );
				log.info("fiuBalance:"+fiuBalance );
				ClientActivities c6 = new ClientActivities();
				
				AccountingMaintenanceService AMS  = AccountingMaintenanceService.getInstance();
				 pastDueInvoices = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(n_penaltyamount),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
				 dcAccruals = dcAccruals+pastDueInvoices;
				 
				reserves+=(-1*dcAccruals);
					fiuBalance+=dcAccruals;	//rdc08092010
					if (dcAccruals>0) {
						c6.setReserves(-1*dcAccruals);
					} else {
						c6.setReserves(dcAccruals);
					}
					c6.setFiuBalance(fiuBalance); 
					discountCharges=dcAccruals;
				
				pastDueFR = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(N_INVOICEAMT),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
				/*if(pastDueInvoices!=0){
					ClientActivities c7 = new ClientActivities();	
					c7.setDefinition("Past Due Interest");
					c7.setRef("");
					c7.setTransactionDate(new Date(asOfDate));	
					c7.setReceivables(0.00);
					c7.setFiuTransaction(0.00);	
					c7.setFiuBalance(fiuBalance);
					reserves-=pastDueInvoices;
					c7.setReserves(-1*pastDueInvoices);
					list.add(c7);
				}*/
				c6.setDefinition("Discount Charges - Accrual");
				c6.setRef("");
				c6.setTransactionDate(new Date(asOfDate));	
				c6.setReceivables(0.00);
				c6.setFiuTransaction(0.00);			
				c6.setTotalReceivables(receivables);
				c6.setTotalReserves(reserves);
				c6.setTotalFiuTransaction(fiuTransaction);
				c6.setTotalFiuBalance(fiuBalance);
				c6.setInvoices(invoices);
				c6.setServiceCharges(serviceCharges);
				c6.setAdvances(advances);
				c6.setReceipts(receipts);
				c6.setCreditNotes(creditNotes);
				c6.setRefunds(refunds);
				c6.setDiscountCharges(discountCharges);
				c6.setDcOnCashDelays(dcOnCashDelays);
				c6.setSetupFee(setupFee);
				c6.setDocStamp(docStamp);
				c6.setDcCollected(dcCollected);
				c6.setOverpayment(overpayment);
				c6.setReceiptAdvance(rctAdvance);
				c6.setReceiptRefund(rctRefund);
				c6.setDshnrdChks(dshnrdChks);
				c6.setCnCancelled(cnCancelled);
				c6.setPenaltyCollected(penaltyCollected);
				c6.setPastDueCollected(pastDueInvoices);
				c6.setPastDueFR(pastDueFR);
				c6.setNotarialFee(notarial); //added by CVG as of 03-16-16
				list.add(c6);
				log.info("total in");
				log.info("8-setupFee/dcCollected:" + setupFee + "/" + dcCollected);
				log.info("doc stamp amount: " + docStamp);
				//end 08092010
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return list;		
	}		


	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/


	public double getDiscountCharge(double fiut,double blr,double dcr,long day){
		double discountCharge=0.00;
		log.info("fiut: "+fiut);
		log.info("blr: "+blr);
		log.info("dcr: "+dcr);
		log.info("Day: "+day);
		blr/=100;
		dcr/=100;		
		discountCharge=m.doRoundOff((fiut*(blr+dcr)*day)/360);
		log.info("Discount Charge: "+discountCharge);
		return discountCharge;
	}

	public double getDConCashDelay(double fiut,double blr,double dcr,long cashDelay){
		double dCOnCashDelay=0.00;
		log.info("fiut: "+fiut);
		log.info("blr: "+blr);
		log.info("dcr: "+dcr);
		log.info("Cash Delay: "+cashDelay);
		blr/=100;
		dcr/=100;
		dCOnCashDelay=m.doRoundOff((fiut*(blr+dcr)*cashDelay)/360);
		return dCOnCashDelay;
	}

	public double getFIU(String clientCode,String asOfDate){
		double fiu=0.00;
		String sSQL = "";
		try{

		}
		catch(Exception e){
			e.printStackTrace();
		}		
		return fiu;		
	}

	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	//Added by: Roldan Somontina last June 9,2009
	public List getAllClientSalesAnalysis(CC cc)
	{		 
		List list = new ArrayList();		
		String sSQL = 	"SELECT DISTINCT C_CUSTCODE,C_NAME,C_CUSTNAME FROM ReportInvoice " + 
		"	WHERE C_CLNTCODE='"+cc.getClientCode()+"' AND C_BRANCHCODE='"+cc.getBranchCode()+"' " + 
		"	AND (D_INVOICEDATE BETWEEN '01/01/'+CAST(YEAR('"+cc.getAsOfDate()+"') AS NVARCHAR) " + 
		"	AND '"+cc.getAsOfDate()+"') AND YEAR(D_INVOICEDATE) = YEAR('"+cc.getAsOfDate()+"')" +
		"   AND C_STATUS "+cc.getStatus()+" ";

		log.info("[getAllClientSalesAnalysis]sSQL=> " +sSQL);
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			double janTotal=0.00;
			double febTotal=0.00;
			double marTotal=0.00;
			double aprTotal=0.00;
			double mayTotal=0.00;
			double junTotal=0.00;
			double julTotal=0.00;
			double augTotal=0.00;
			double sepTotal=0.00;
			double octTotal=0.00;
			double novTotal=0.00;
			double decTotal=0.00;
			double grossTotal=0.00;
			double creditNotesTotal=0.00;
			double nettTotal=0.00;
			double lastYearTotal=0.00;
			while(rs.next()){
				cc.setCustomerCode(rs.getString("C_CUSTCODE"));
				String csa = CustomerDAO.getCustomerSalesAnalysis(cc);
				String[] str=csa.split(delim);
				janTotal+=m.doRoundOff(Double.parseDouble(str[0]));
				febTotal+=m.doRoundOff(Double.parseDouble(str[1]));
				marTotal+=m.doRoundOff(Double.parseDouble(str[2]));
				aprTotal+=m.doRoundOff(Double.parseDouble(str[3]));
				mayTotal+=m.doRoundOff(Double.parseDouble(str[4]));
				junTotal+=m.doRoundOff(Double.parseDouble(str[5]));
				julTotal+=m.doRoundOff(Double.parseDouble(str[6]));
				augTotal+=m.doRoundOff(Double.parseDouble(str[7]));
				sepTotal+=m.doRoundOff(Double.parseDouble(str[8]));
				octTotal+=m.doRoundOff(Double.parseDouble(str[9]));
				novTotal+=m.doRoundOff(Double.parseDouble(str[10]));
				decTotal+=m.doRoundOff(Double.parseDouble(str[11]));
				grossTotal+=m.doRoundOff(Double.parseDouble(str[12]));
				creditNotesTotal+=m.doRoundOff(Double.parseDouble(str[13]));
				nettTotal+=m.doRoundOff(Double.parseDouble(str[14]));
				lastYearTotal+=m.doRoundOff(Double.parseDouble(str[15]));
				list.add(rs.getString("C_CUSTNAME")+delim+csa);
			}
			String overallTotal=janTotal+delim+febTotal+delim+marTotal+delim+aprTotal+delim+
			mayTotal+delim+junTotal+delim+julTotal+delim+augTotal+delim+
			sepTotal+delim+octTotal+delim+novTotal+delim+decTotal+delim+
			grossTotal+delim+creditNotesTotal+delim+nettTotal+delim+lastYearTotal;				
			//list.add("overallTotal"+delim+overallTotal);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return list;		
	}	

	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	public List<CCLink> getAgeingSummaryForClient(CC cc,String operation){
		List<CCLink> list = new ArrayList<CCLink>();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		String sSQL = 	" SELECT DISTINCT CC.C_CLNTCODE,CC.C_NAME, CAST(ROUND(dbo.GetDunning(CC.C_CLNTCODE, '5', DATEADD(MM,-5,'"+cc.getAsOfDate()+"'), '"+cc.getAsOfDate()+"'), 0) AS Integer) AS clientDunning " +
		" FROM         CC INNER JOIN " +
		"                      Invoice ON CC.C_BRANCHCODE = Invoice.C_BRANCHCODE AND CC.C_CLNTCODE = Invoice.C_CLNTCODE AND " + 
		"                      CC.C_CUSTCODE = Invoice.C_CUSTCODE " +
		" WHERE     (CC.ClientStatus = '1') AND (Invoice.C_STATUS IN ('2','3', '4')) AND (CC.C_BRANCHCODE = '"+cc.getBranchCode()+"') ";
		log.info("getAgeingSummaryForClient(sSQL)= "+sSQL);
		log.info("Branch Code: "+cc.getBranchCode());
		log.info("As of Date: "+cc.getAsOfDate());
		Statement stmt=null;
		ResultSet rs = null;
		try{
			stmt=new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);

			while(rs.next()){
				log.info("starting iteration");
				CCLink ccLink= new CCLink();
				ccLink.setClientName(rs.getString("C_NAME"));
				CC cc2 = new CC();
				cc2.setAsOfDate(cc.getAsOfDate());
				cc2.setClientCode(rs.getString("C_CLNTCODE"));
				cc2.setBranchCode(cc.getBranchCode());
				cc2.setStatus("IN('2','3','4')");
				cc2.setDunning(rs.getLong("clientDunning"));
				double n_Current=0.00d;
				double n_1to30=0.00d;
				double n_31to60=0.00d;
				double n_61to90=0.00d;
				double n_91to120=0.00d;
				double n_121to150=0.00d;
				double n_151to180=0.00d;
				double n_over180=0.00d;
				double n_TotalOS=0.00d;

				double percentCurrent=0.00;
				double percent1to30=0.00;
				double percent31to60=0.00;
				double percent61to90=0.00;
				double percent91to120=0.00;
				double percent121to150=0.00;
				double percent151to180=0.00;
				double percentOver180=0.00;

				long age=0;
				Iterator<Invoice> iter=InvoiceDAO.getAllClientInvoiceByStatus(cc2).iterator();
				UtilDAO dateDif = new UtilDAO();
				double amount = 0.00d;
				while(iter.hasNext()){
					Invoice inv = (Invoice)iter.next();
					amount=inv.getC_STATUS()!=null&&inv.getC_STATUS().equalsIgnoreCase("4")?InvoiceDAO.getPartialAmount(inv.getN_INVNO()):inv.getN_INVOICEAMT();
					amount = m.doRoundOff(amount);
					log.info("Invoice No.:"+inv.getN_INVNO()+" of Invoice with Status ("+inv.getC_STATUS()+")  and its Amount: "+amount);
					if(operation.equalsIgnoreCase("ageingSummaryByClient")){
						age=inv.getAgeing();
						log.info("age under operation ageingSummaryByClient");	
						log.info("invoice no.: "+inv.getC_INVOICENO());
						log.info("invoice amount: "+inv.getN_INVOICEAMT());
						log.info("age : "+age);
					}
					if(operation.equalsIgnoreCase("ageingClientByDunning")){												
						age=inv.getAgeByDunning();
						log.info("age under operation ageingClientByDunning");
						log.info("invoice no.: "+inv.getC_INVOICENO());
						log.info("invoice amount: "+inv.getN_INVOICEAMT());						
						log.info("age : "+age);
					}
					if(age>0 && age<31){
						n_1to30+=amount;
					}
					else if(age>30 && age<61){
						n_31to60+=amount;
					}
					else if(age>60 && age<91){
						n_61to90+=amount;
					}
					else if(age>90 && age<121){
						n_91to120+=amount;
					}
					else if(age>120 && age<151){
						n_121to150+=amount;
					}
					else if(age>150 && age<181){
						n_151to180+=amount;
					}
					else if(age>180){
						n_over180+=amount;
					}
					else{
						n_Current+=amount;
					}
				}
				n_TotalOS = n_Current + n_1to30 + n_31to60 + n_61to90 + n_91to120 + n_121to150 + n_151to180 + n_over180;
				//n_TotalOS = m.doRoundOff(n_TotalOS);
				ccLink.setN_Current(n_Current);
				ccLink.setN_1to30(n_1to30);
				ccLink.setN_31to60(n_31to60);
				ccLink.setN_61to90(n_61to90);
				ccLink.setN_91to120(n_91to120);
				ccLink.setN_121to150(n_121to150);
				ccLink.setN_151to180(n_151to180);
				ccLink.setN_over180(n_over180);
				ccLink.setN_TotalOS(n_TotalOS);				
				percentCurrent	=(n_Current/n_TotalOS);
				percent1to30	=(n_1to30/n_TotalOS);
				percent31to60	=(n_31to60/n_TotalOS);
				percent61to90	=(n_61to90/n_TotalOS);
				percent91to120	=(n_91to120/n_TotalOS);
				percent121to150=(n_121to150/n_TotalOS);
				percent151to180=(n_151to180/n_TotalOS);
				percentOver180	=(n_over180/n_TotalOS);				 	
				ccLink.setPercentCurrent(percentCurrent);
				ccLink.setPercent1to30(percent1to30);
				ccLink.setPercent31to60(percent31to60);
				ccLink.setPercent61to90(percent61to90);
				ccLink.setPercent91to120(percent91to120);
				ccLink.setPercent121to150(percent121to150);
				ccLink.setPercent151to180(percent151to180);
				ccLink.setPercentOver180(percentOver180);
				ccLink.setCurrentdate(date.newDate());	
				list.add(ccLink);		
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return list;
	}


	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	public int getFactoringManagementCountRep(String branchCode, String asOfDate)
	{
		int retval = 0;
		try {			

			String sSQL = "select count(cc.c_clntcode) as cnt from client cc " +
			"inner join dbFactors.dbo.accountofficer ao " +
			"on ao.c_acctofficercode = cc.c_acctofficercode " +
			"inner join dbFactors.dbo.invoices inv " +
			"on inv.c_clntcode = cc.c_clntcode " +
			"where inv.c_status between '2' and '5' and inv.d_invoicedate <= '" + asOfDate + "' " +
			"AND cc.C_BRANCHCODE = '"+branchCode+"'";

			System.out.println("[ClientDAO]->[getClientConcentrationRepCnt][args1: "+branchCode+ "][debug]: " +sSQL);

			retval = (Integer)getJdbcTemplate().queryForObject(sSQL, 
					new RowMapper()
			{
				@Override 
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException
				{							
					return rs.getInt("cnt");							
				}
			}
			);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return retval;
	}
	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/
	/*
	 * UPDATE 
	 * getClientFIUbyAsOfDate
	 * updateClientDailyFIU
	 * getClientActivities
	 * LAST UPDATE: 5/2/2012
	 * */
	public Map<String, Object> updateClientMonthEnd(String clientCode,String asOfDate, Map map)
	{		 
		Map returnMap = new HashMap<String,Object>();
		List<ClientActivities> list = new ArrayList<ClientActivities>();	
		String sSQL = "SELECT     * FROM ( " + 	
				"		SELECT	i.C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_INVOICEAMT AS AMOUNT, 0.00 AS AMOUNT2, N_ADVANCEDRATIO AS ADVRATIO, " +
				"				C_INVOICENO AS ref,  0 AS ref2, '1' AS category , 0 as cashDelay , '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,i.N_SVCCHGTYPE as scType " +
				"				FROM	Invoice i INNER JOIN dbCIF.dbo.CLIENT c ON i.C_CLNTCODE = c.C_CLNTCODE " +
				"				WHERE i.C_STATUS IN('2','3','4','5','6')" +
				" 				AND (i.C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"				CAST(N_REFNO AS NVARCHAR) AS REF, c_debit AS REF2,'1a' AS CATEGORY , 0 AS CASHDELAY, C_ADJREC+C_ADJRES+C_ADJFIU+C_ADJFIUBAL+a2.C_ADJDESC AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +  
				"				FROM ADJUSTMENT a INNER JOIN ADJUSTMENTTYPE a2 ON a.C_ADJCODE = a2.C_ADJCODE " +
				"				WHERE C_STATUS = '2'AND B_INCLUDED = 1 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " +
				"                   FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "+  
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2b' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
		        "    				FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4)  AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0  "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
		        "  					 + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')"+
				"				UNION "+
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO,   "+
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2c' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"					FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
				"   				+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
				"				UNION"	+
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG2 AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE ISNULL(N_DISCCHG2,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				//added by CVg as of 03-16-16
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_NOTARIAL AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2d' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE ISNULL(N_NOTARIAL,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				//end
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE     C_TYPE = 2 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE     C_TYPE = 3 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '4' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND (C_STATUS IN (1,2,4))   " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '5' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 2 AND (C_STATUS IN (1,2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT a.C_CLNTCODE, a.C_CUSTCODE,  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101)AS D_TRANSACTIONDATE, AMOUNT,AMOUNT2, ADVRATIO, " +
				"				REF, REF2,CATEGORY , CASHDELAY, TYPE,AMOUNT1,OVERPAYMENT,dcPayment, penaltyPayment,'' as scType   FROM ( " +
				"			SELECT rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,rdinv.D_TRANSACTIONDATE,D_FULLYPAIDDATE, ISNULL(SUM(N_RECEIPTAMT),0) AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(rd2.N_REFNO  AS NVARCHAR) AS REF, rh2.C_RECEIPTTYPE AS REF2,'5A' AS CATEGORY , 0 AS CASHDELAY, '' AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM RECEIPTSDTL rd2 INNER JOIN( " +
				"			SELECT DISTINCT rh.C_CLNTCODE, rh.C_CUSTCODE,rd.C_INVOICENO,rd.N_INVNO,rh.D_TRANSACTIONDATE,D_FULLYPAIDDATE FROM RECEIPTSDTL rd " + 
				"				INNER JOIN ( " + 
				"			SELECT	C_CLNTCODE, C_CUSTCODE,CAST(N_REFNO AS NVARCHAR) AS REF, D_TRANSACTIONDATE " +
				"				FROM	RECEIPTSHDR WHERE     C_RECEIPTTYPE IN (1,2,3,4) AND (C_STATUS IN (2,4)) " + 
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"				) AS rh ON rd.N_REFNO = rh.REF " +
				"				INNER JOIN INVOICE inv ON rd.C_INVOICENO = inv.C_INVOICENO and rd.N_INVNO = inv.N_INVNO " + 
				"				AND inv.C_STATUS IN (5,6) " +  
				"				) AS rdinv ON rd2.C_INVOICENO = rdinv.C_INVOICENO  AND rd2.N_INVNO = rdinv.N_INVNO " +
				"				INNER JOIN  RECEIPTSHDR rh2 ON rd2.N_REFNO=rh2.N_REFNO AND rh2.C_RECEIPTTYPE IN (3,4)  AND rh2.C_STATUS in (2,4)" +
				"				GROUP BY rh2.C_RECEIPTTYPE,rd2.N_REFNO,rdinv.D_TRANSACTIONDATE,rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,D_FULLYPAIDDATE " +
				"		) a where  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101) =  CONVERT(VARCHAR(10), a.D_FULLYPAIDDATE, 101) " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2,  0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, C_STATUS ref2, '6' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 3 AND (C_STATUS IN (2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref,C_STATUS  AS ref2, '6a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 4 AND (C_STATUS IN (2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"      SELECT	cn.C_CLNTCODE, cn.C_CUSTCODE, cn.D_TRANSACTIONDATE, cn.N_AMOUNT AS AMOUNT,  0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(cn.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '6b' AS category , 0 as cashDelay, '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +   
				"			FROM	CreditNote cn INNER JOIN RECEIPTSHDR rh ON cn.C_RECEIPTNO = rh.N_REFNO " +
				"			WHERE cn.C_STATUS IN(1,2) AND rh.C_STATUS <> 3 " +
				" 				AND (cn.C_CLNTCODE ='" + clientCode + "') AND (cn.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				/*//Add Discount Charge and Penalty 
				//7d for Discount Charge
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7d' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
				"                   FROM	ReceiptsHdr WHERE   " +
				" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +		
				//7e for Penalty
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7e' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
				"                   FROM	ReceiptsHdr WHERE   " +
				" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				*/
				"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  c.D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a2' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
				"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
				" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (c.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"    SELECT	C_CLNTCODE, C_CUSTCODE,  (CASE WHEN D_DATEBOUNCED IS NOT NULL THEN D_DATEBOUNCED ELSE D_TRANSACTIONDATE END) AS D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7b' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  (CASE WHEN D_CANCELLEDDATE IS NOT NULL THEN D_CANCELLEDDATE ELSE D_DATEBOUNCED END) as D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7c' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
				"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
				" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"    SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_REFAMT AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9' AS category , 0 as cashDelay, C_TYPE AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	Refund WHERE  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"			union"+
				"	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "   +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9a' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +    
		        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) "+   
		        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
		        "			UNION "+	
		        "	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, "+  
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9b' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +     
		        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)"+   
		        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
		        "			UNION "+	
		    	"	SELECT C_CLNTCODE,0 C_CUSTCODE ,date_tagged_RMU D_TRANSACTIONDATE, ISNULL(amount_reversed,0) AS AMOUNT, 0 AS AMOUNT2, 0.0 AS ADVRATIO,'CR' as ref, 0 as ref2, 'client' AS category, 0 as cashDelay,'' as type,0 as Amount1, 0 as overPayment, 0 as dcPayment, 0 as penaltyPayment,'' as scType	"+
		   	 	"	FROM dbcif..Client where is_RMU = 1 and C_CLNTCODE ='" + clientCode + "' and (date_tagged_RMU BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)	"+ 
		        "           			 +'/01/'+  CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')	"+ 
		        "	) a " +
		        //Replace the order by fields (Previously D_TRANSACTIONDATE,catefory,ref asc)
				"	ORDER BY D_TRANSACTIONDATE,category,ref asc ";				
		log.info(" updateClientMonthEnd [args1:" +clientCode+"][debug]: " +sSQL);
		Statement stmt=null;
		ResultSet rs=null;
		Connection conn = null;
		conn = new FactorConnection().getConnection();
		try{
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);

			double dcr=0.00;
			double scr=0.00;
			double blr = 0.00;
			String blrCode="";
			int day=0;
			int cashDelay=0;
			String custCode="";
			String customerName="";

			double serviceValue=0.00;
			double discountValue=0.00;
			double dcCashDelayValue=0.00;

			//Totals
			double receivables=0.00;
			double reserves=0.00;
			double fiuTransaction=0.00;
			double fiuBalance=0.00;

			double invoices=0.00;
			double advances=0.00;
			double receipts=0.00;
			double serviceCharges=0.00;			
			double discountCharges=0.00;
			double dcOnCashDelays=0.00;
			double creditNotes=0.00;
			double refunds=0.00;
			double setupFee=0.00;
			double docStamp=0.00;
			double dcCollected=0.00;
			double dcAccruals=0.00;
			double advratio=0.00;
			double iniVal=0.00;
			int withTrans = 0;
			double lastAccruals = 0.00;
			double overpayment = 0.00;
			double rctAdvance = 0.00;
			double rctRefund = 0.00;
			double dshnrdChks = 0.00;
			double cnCancelled = 0.00;
			String type="";
			String branchCode="";
			
			double pastDueInvoices = 0.00;
			double pastDueCollected = 0.00;
			double penaltyCollected = 0.00;
			double pastDueFR = 0.00;
			
			double balance=0.00;

			//added by CVG as of 04-11-2016
			double notarial = 0.00;
			
			boolean is_rmu = false;
			
			//for CISA extract
			int overdueCount = 0;
			 
			ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
			MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
			while(clientList.hasNext()){
				ClientActivities header = new ClientActivities();
				Client client = (Client)clientList.next();
				header.setClient(client);
				header.setClientCode(clientCode);
				dcr=m.doRoundOff(client.getN_Dcr());
				scr=m.doRoundOff(client.getN_Scr());
				advratio =m.doRoundOff(client.getN_AdvRatio());
				branchCode = client.getC_BranchCode();	//rdc08132010
				blrCode = client.getC_BlrTypeCode();
				BLRFileDAO blrDao = new BLRFileDAO();
				ListIterator<BLRFile> blrFileList = blrDao.getBLRFile(clientCode, asOfDate).listIterator();
				while(blrFileList.hasNext()){
					BLRFile blrFile = (BLRFile) blrFileList.next();
					log.info("BLR: "+blrFile.getBlr());
					log.info("Effectivity Date: "+blrFile.getEffectiveDate());
					log.info("Expiry Date: "+blrFile.getExpiryDate());
					blr = m.doRoundOff(blrFile.getBlr());
					log.info("blrFile.getBlr()"+blrFile.getBlr());
					//header.setBlrFile(blrFile);
					break;
				}
				
				String strMMM = DateUtils.getLastMonthMMM(asOfDate);//RLS 01/07/2011 add method in getting prefix of month (MMM) DateUtils.getLastMonthMMM(asOfDate)
				strMMM = "N_" + strMMM +"ACC";
				is_rmu = client.isIs_rmu();
				Map map2 = new HashMap();
				map2.put("C_CLNTCODE", clientCode);
				map2.put("MMM", strMMM);		
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				dcAccruals= m.doRoundOff(invoiceDAO.getLastAccrual(map2));
				log.info("dcAccruals:"+dcAccruals );
				
				is_rmu = client.isIs_rmu();
				
				mbDAO = new MonthlyBalancesDAO();
				ListIterator mbList =mbDAO.getMonthBalClntCodeAsOfDate(clientCode,asOfDate).listIterator();						
				while(mbList.hasNext()){

					MonthlyBalances mb = (MonthlyBalances)mbList.next();
					header.setTransactionDate(DateHelper.getDateInFirstDay(asOfDate));
					header.setStartDate(DateHelper.getDateInFirstDay(asOfDate));
					header.setDefinition("Balance B/F");
					header.setRef("");
					header.setReceivables(m.doRoundOff(mb.getMonthReceivables().doubleValue()));
					header.setReserves(m.doRoundOff(mb.getMonthReserves().doubleValue()));
					//header.setFiuBalance(mb.getMonthFIU().doubleValue());
					if (m.doRoundOff(mb.getMonthFIU().doubleValue())>iniVal) {	//rdc 08102010
						fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue() + dcAccruals );//header.getFiuTransaction()s;		
						header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
					} else {
						if ((m.doRoundOff(mb.getMonthFIU().doubleValue())==iniVal) && dcAccruals>0){
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue()+dcAccruals);//header.getFiuTransaction();
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
						}else{
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue());//header.getFiuTransaction();
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue()));
						}
					}
					//header.setFiuTransaction(mb.getMonthFIU().doubleValue());
					header.setFiuTransaction(m.doRoundOff(mb.getMonthFIU().doubleValue()));
					receivables=header.getReceivables();
					reserves=header.getReserves();
					fiuTransaction=header.getFiuTransaction();
					
					if((dcAccruals>0.00) && (fiuTransaction==0.00)){
						balance=header.getFiuTransaction()+dcAccruals;
					}else{
					
						balance=header.getFiuTransaction();
					} 
					
					break;
				}
				list.add(header);
				break;				
			}
			
			ClientActivities disc = new ClientActivities();
			disc.setDefinition("Last Month's DC Accrual");
			disc.setRef("");
			disc.setReceivables(0.00);			
			
			log.info("reserves before adding discount in balance bf "+reserves);
			//reserves-=discountValue; 	//rdc 08102010
			
			if ((fiuTransaction>iniVal)||(reserves>iniVal)||receivables>iniVal) {
				
				if((dcAccruals>0.00) && (fiuTransaction==0.00)){
					fiuBalance=balance-dcAccruals;
				}else{
				    fiuBalance-=dcAccruals;
				}
				reserves+=dcAccruals;
				disc.setReserves(dcAccruals);
			} else {
				disc.setReserves(0.00);
			}
			//lastAccruals = dcAccruals;
			log.info("reserves after adding discount in balance bf "+reserves);
			
			disc.setFiuTransaction(0.00);
			
			disc.setFiuBalance(fiuBalance);	
			//discountCharges+=discountValue; //rdc08102010
			dcAccruals=0.00;
			list.add(disc);	
			boolean rset = rs.next();	
			String ref = "";
			while(rset){
				log.info("receipts"+receipts);
				type=rs.getString("type");
				double amount =m.doRoundOff(rs.getDouble("AMOUNT")); 
				double amount1=m.doRoundOff(rs.getDouble("amount1"));
				double amount2 =m.doRoundOff(rs.getDouble("AMOUNT2"));	//rdc07152010
				double opmt = m.doRoundOff(rs.getDouble("overPayment"));
				//added 6/28/2016 for receipts dc and penalty
				double dcPayment = m.doRoundOff(rs.getDouble("dcPayment"));
				double penaltyPayment = m.doRoundOff(rs.getDouble("penaltyPayment"));
				String scType = rs.getString("scType")!=null? rs.getString("scType"):"2"; //cvg 02132017
				String ref2 = rs.getString("ref2").trim();	//rdc07152010
				String date1 = sdf.format(rs.getDate("D_TRANSACTIONDATE"));				
				String category = rs.getString("category").trim();
				if (date1.equals(asOfDate)) {
					day = 1;
				} else {
					day = DateHelper.getDayPerTransaction(date1, asOfDate);
				}	
				//advratio =m.doRoundOff(rs.getDouble("ADVRATIO"));	//rdc08062010
				cashDelay = rs.getInt("cashDelay");
				log.info("Day: "+day);
				log.info("Category "+category);
				ClientActivities c = new ClientActivities();				
				c.setRef(rs.getString("ref"));
				c.setTransactionDate(rs.getDate("D_TRANSACTIONDATE"));				
				if(category.equalsIgnoreCase("1")){
					//rdc08092010
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					//end 08092010
					c.setDefinition("Invoice");
					c.setReceivables(amount);
					receivables+=amount;
					c.setReserves(amount);
					reserves+=amount;
					c.setFiuTransaction(0.00);
					c.setFiuBalance(fiuBalance);
					invoices+=amount;	
					list.add(c);

					ClientActivities c2 = new ClientActivities();
					c2.setDefinition("Service Charge");
					c2.setRef("");
					c2.setReceivables(0.00);
					
					if (scType.equals("1")){ //added cvg02132017
						serviceValue=m.doRoundOff(amount*(scr/100)*(advratio/100));
					}else{
						serviceValue=m.doRoundOff(amount*(scr/100)); //old
					}//end
					
					reserves-=serviceValue;
					c2.setReserves(-1*serviceValue);						
					fiuTransaction+=serviceValue;
					c2.setFiuTransaction(serviceValue);
					c2.setFiuBalance(fiuBalance);
					serviceCharges+=serviceValue;
					list.add(c2);

				}
				else if(category.equalsIgnoreCase("1a")){
					String strTypeRec =  type.substring(0, 1);
					String strTypeRes = type.substring(1, 2);
					String strTypeFiu = type.substring(2, 3);
					String strTypeFiuBal = type.substring(3, 4);
					String strDesc = type.substring(4);
					
					if (ref2.equals("1")){
						dcCollected+=amount;
					} else {
						dcCollected-=amount;
					}
					
					//effect on receivables
					if (strTypeRec.equals("1")) {
						receivables+=amount;
						c.setReceivables(amount);
					} else if (strTypeRec.equals("2")) {
						receivables-=amount;
						c.setReceivables(-1*amount);
					} else {
						c.setReceivables(0.00);
					}
					//effect on reserves
					if (strTypeRes.equals("1")) {
						reserves+=amount;
						c.setReserves(amount);
					} else if (strTypeRes.equals("2")) {
						reserves-=amount;
						c.setReserves(-1*amount);
					} else {
						c.setReserves(0.00);
					}
					//effect on fiu
					if (strTypeFiu.equals("1")) {
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
					} else if (strTypeFiu.equals("2")) {
						fiuTransaction-=amount;
						c.setFiuTransaction(-1*amount);
					} else {
						c.setFiuTransaction(0.00);
					}
					//effect on fiu balance
					if (strTypeFiuBal.equals("1")) {
						fiuBalance+=amount;
					} else if (strTypeFiuBal.equals("2")) {
						fiuBalance-=amount;
					}
					c.setFiuBalance(fiuBalance);
					c.setDefinition(strDesc);			
					list.add(c);
				}else if(category.equalsIgnoreCase("client")){
					//c.setDefinition("Client Reversal");
					//c.setReceivables(0.0);
					//reserves-=amount;
					//c.setReserves(-1*amount);
					//c.setFiuTransaction(amount);
					//fiuTransaction +=amount;
					//fiuBalance +=amount;
					//c.setFiuBalance(fiuBalance);
					//list.add(c);	
				}
				else if(category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||category.equalsIgnoreCase("2a")||category.equalsIgnoreCase("2b")||category.equalsIgnoreCase("2c")||category.equalsIgnoreCase("2d")){					
					if(category.equalsIgnoreCase("2"))c.setDefinition("Advances");
					if(category.equalsIgnoreCase("3"))c.setDefinition("Setting-up Fee");
					if(category.equalsIgnoreCase("3a"))c.setDefinition("Advances - Unfactored");
					if(category.equalsIgnoreCase("2a"))c.setDefinition("Doc Stamp");
					if(category.equalsIgnoreCase("2b"))c.setDefinition("Penalty Charge");
					if(category.equalsIgnoreCase("2c"))c.setDefinition("PD - Discount Charge");
					if(category.equalsIgnoreCase("2d"))c.setDefinition("Notarial Fee"); //added by CVg as of 04-11-16
					//08042010
					c.setReceivables(0.00);
					reserves-=amount;
					c.setReserves(-1*amount);
					fiuTransaction+=amount;
					c.setFiuTransaction(amount);
					c.setFiuBalance(fiuBalance);
					if(category.equalsIgnoreCase("2")) advances+=amount;			
					list.add(c);
					if(category.equalsIgnoreCase("2")) {
						discountValue=m.doRoundOff(getDiscountCharge(amount2,blr,dcr,day));
						try{
							Statement s = null;
							ResultSet r = null;
							
							s= new FactorConnection().getConnection().createStatement();
							String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
							"on rh.N_REFNO=rd.N_REFNO inner join Advances adv on	"+
							"adv.N_REFNO=rh.n_advpaymentno inner join "+
							"Invoice inv on rd.N_INVNO=inv.n_invno	"+
							"where rh.C_CLNTCODE='"+clientCode+"' and adv.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
							r= s.executeQuery(query);
							
							if(r.next()){
								double val = r.getDouble("amount")*((100-advratio)/100);
								if(val!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CN Adjustment From Advance");
									op.setRef("");
									op.setReceivables(0.00);
									op.setReserves(0.00);
									op.setFiuTransaction(val);
									fiuTransaction +=val;
									fiuBalance +=val;
									op.setFiuBalance(fiuBalance);
									list.add(op);
								}
							}
							
							}
							catch(Exception e){
								e.printStackTrace();
							}	
						
						
					} else if(category.equalsIgnoreCase("3")) {
							setupFee = amount;
							/*discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,1));	
							dcCollected+=discountValue;*/
					} else if(category.equalsIgnoreCase("3a")) {
						discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,day));
					} else if(category.equalsIgnoreCase("2a")){
						c.setTransactionDate(null);
						c.setRef(null);
						docStamp =  amount; 
					}
					 else if(category.equalsIgnoreCase("2b")){
						 c.setTransactionDate(null);
						 c.setRef(null);
						 penaltyCollected += amount ;
						 overdueCount++;
					 }
					 else if(category.equalsIgnoreCase("2c")){
						 pastDueCollected += amount;
						 c.setTransactionDate(null);
						 c.setRef(null);
					 }
					//added by CVG as of 04-11-16
					 else if(category.equalsIgnoreCase("2d")){
						 pastDueCollected += amount;
						 c.setTransactionDate(null);
						 c.setRef(null);
						 notarial =  amount; 
					 }
					//end
					withTrans = 1;
					
			}	

				else if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("5")||category.equalsIgnoreCase("7a")||category.equalsIgnoreCase("7d")){
					//added for discount charge and penalty
					if(category.equalsIgnoreCase("7d")){
						c.setDefinition("Discount Charge");
						c.setReceivables(0.00);
						reserves-=amount;
						c.setReserves(-1*amount);
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
						c.setFiuBalance(fiuBalance);
						list.add(c);
					}
					else{
					
						log.info("Receipts cat4 and 5 here....");
						if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
							custCode=rs.getString("C_CUSTCODE");
							customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
						}					
						if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("7a"))c.setDefinition("RCT-CHK-"+customerName);
						if(category.equalsIgnoreCase("5"))c.setDefinition("RCT-CSH-"+customerName);	
						receivables-=amount-opmt;
						//fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
						
						receipts+=amount;
						c.setReceivables(-1*(amount-opmt));
						//c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
						if(is_rmu){
							c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
							fiuTransaction-=m.doRoundOff((amount-opmt));
							fiuBalance-=m.doRoundOff((amount-opmt));	//rdc08092010
						}else{
							c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
							fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
							fiuBalance-=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
						}
						log.info("amount: "+amount);
						log.info("amount1: "+amount1);
						amount=(amount1<amount)?amount1:amount;
						log.info("amount to be computed for discount: "+amount);
						discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
						c.setReserves(0.00);
						c.setFiuBalance(fiuBalance);
						list.add(c);
							if(opmt!=0){	
								ClientActivities op = new ClientActivities();
								op.setDefinition("Over Payment");
								op.setRef("");
								op.setReceivables(0.00);
								overpayment+=opmt;
								op.setReserves(opmt);
								reserves+=opmt;
								op.setFiuTransaction(0.00);
								op.setFiuBalance(fiuBalance);
								list.add(op);							
							}
							if(dcPayment!=0){
								ClientActivities dc = new ClientActivities();
								dc.setTransactionDate(null);
								dc.setDefinition("Discount Charge");
								dc.setReceivables(0.00);
								reserves-=dcPayment;
								dc.setReserves(-1*dcPayment);
								//fiuTransaction+=dcPayment;
								dc.setFiuTransaction(0.00);
								dc.setFiuBalance(fiuBalance);
								dcCollected += dcPayment;
								list.add(dc);
							}
							
							if(penaltyPayment !=0){
								ClientActivities pc = new ClientActivities();
								pc.setTransactionDate(null);
								pc.setDefinition("Penalty Charge");
								pc.setReceivables(0.00);
								reserves-=penaltyPayment;
								pc.setReserves(-1*penaltyPayment);
								//fiuTransaction+=penaltyPayment;
								pc.setFiuTransaction(0.00);
								pc.setFiuBalance(fiuBalance);
								penaltyCollected += penaltyPayment;
								overdueCount++;
								list.add(pc);
							}
							
							//Unfactored Invoice
							ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
							Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
							if(unfactoredAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("Unfactored Invoices");
								ua.setReceivables(0.00);
								reserves-=unfactoredAmount;
								ua.setReserves(-1*unfactoredAmount);
								//fiuTransaction+=penaltyPayment;
								ua.setFiuTransaction(0.00);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							//Discount Charge
							Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
							if(dcAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("RMU Discount Charge");
								ua.setReceivables(dcAmount);
								receivables += dcAmount;
								//reserves-=dcAmount;
								//ua.setReserves(-1*dcAmount);
								ua.setReserves(0);
								fiuTransaction+=dcAmount;
								fiuBalance += dcAmount;
								ua.setFiuTransaction(dcAmount);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							//Penalty
							Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
							if(penaltyAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("RMU Penalty Charge");
								ua.setReceivables(penaltyAmount);
								receivables += penaltyAmount;
								//reserves-=penaltyAmount;
								//ua.setReserves(-1*penaltyAmount);
								ua.setReserves(0);
								fiuTransaction+=penaltyAmount;
								fiuBalance += penaltyAmount;
								ua.setFiuTransaction(penaltyAmount);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							
							 
					}
				}
				else if(category.equalsIgnoreCase("5a")){
					ClientActivities pp = new ClientActivities();
					if(ref2.contentEquals("3")||ref2.contentEquals("4"))
					{
								/*if(ref2.contentEquals("3")){
									pp.setDefinition("CN Adjustment from Advance");
								}
								else if(ref2.contentEquals("4")){
									pp.setDefinition("CN Adjustment from Refund");
								}*/
					}
					else{
						pp.setDefinition("Previous Partial Payment");
					//pp.setRef(rs.getString("ref"));
					pp.setReceivables(0.00);
					pp.setReserves(0.00);
					fiuTransaction+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuTransaction(amount*m.doRoundOff((100-advratio)/100));	
					fiuBalance+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuBalance(fiuBalance);
					list.add(pp);}
				}

				else if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")||category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
					log.info("RCT-ADV and RCT-REF here....");
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
						if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
							custCode=rs.getString("C_CUSTCODE");
							customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
						}							
						if(category.equalsIgnoreCase("6")){
							c.setDefinition("RCT-ADV-"+customerName);
							rctAdvance+=amount;
						}
						if(category.equalsIgnoreCase("6a")){
							c.setDefinition("RCT-REF-"+customerName);
							rctRefund+=amount;
						}
					
					}
					if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
						if(is_rmu){
							c.setDefinition("RMU Credit Note");
						}else
							c.setDefinition("Credit Note");
						creditNotes+=amount;
					}
					receivables-=amount-opmt;
					c.setReceivables(-1*(amount-opmt));
					
					
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")) {
						c.setReserves(0.00);
						if(rs.getString("ref2").equalsIgnoreCase("2")){
							fiuTransaction-=(amount*(advratio/100))-opmt;
							c.setFiuTransaction(-1*((amount*(advratio/100))-opmt));
							fiuBalance-=(amount*(advratio/100))-opmt;
						}else{
							fiuTransaction-=amount-opmt;
							c.setFiuTransaction(-1*(amount-opmt));
							fiuBalance-=amount-opmt;
						}
						 
						
					} else {
						if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
							if(is_rmu){
								reserves-=amount;
								c.setReserves(-1*amount);
								//fiuTransaction-=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(0);
								//fiuBalance-=m.doRoundOff(amount*(advratio/100));
							}else{
								reserves-=amount;
								c.setReserves(-1*amount);
								fiuTransaction-=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
								fiuBalance-=m.doRoundOff(amount*(advratio/100));
							}
							
						}else{
							reserves-=amount;
							c.setReserves(-1*amount);
							fiuTransaction-=m.doRoundOff(amount*(advratio/100));
							c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
							fiuBalance-=m.doRoundOff(amount*(advratio/100));
						}
					}	
					c.setFiuBalance(fiuBalance);
					log.info("amount: "+amount);
					log.info("amount1: "+amount1);
					amount=(amount1<amount)?amount1:amount;
					log.info("amount to be computed for discount: "+amount);
					discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
						if(opmt!=0){	
							ClientActivities op = new ClientActivities();
							op.setDefinition("Over Payment");
							op.setRef("");
							op.setReceivables(0.00);
							overpayment+=opmt;
							op.setReserves(opmt);
							reserves+=opmt;
							op.setFiuTransaction(0.00);
							op.setFiuBalance(fiuBalance);
							list.add(op);							
						}

					}						
					list.add(c);
					/*if(category.equalsIgnoreCase("6")&&!rs.getString("ref2").contentEquals("0")){
						try{
							Statement s = null;
							ResultSet r = null;
							s = new FactorConnection().getConnection().createStatement();
							String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
							log.info(sql);
							r = s.executeQuery(sql);
							if(r.next()){
								if(r.getDouble("partialAmount")!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CE Adjustment From RCT-ADV (Partial Payment)");
									op.setRef("");
									op.setReceivables(0.0);
									double partial = amount *((100-advratio)/100);
									op.setReserves(-partial);
									reserves -= partial;
									op.setFiuTransaction(partial);
									fiuTransaction+=partial;
									fiuBalance+=partial;
									op.setFiuBalance(fiuBalance);
									list.add(op);
									
								}
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				else if(category.equalsIgnoreCase("6a")&&!rs.getString("ref2").contentEquals("0")){
					try{
						Statement s = null;
						ResultSet r = null;
						s = new FactorConnection().getConnection().createStatement();
						String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
						log.info(sql);
						r = s.executeQuery(sql);
						if(r.next()){
							if(r.getDouble("partialAmount")!=0){
								ClientActivities op = new ClientActivities();
								op.setDefinition("CE Adjustment From RCT-REF (Partial Payment)");
								op.setRef("");
								op.setReceivables(0.0);
								double partial = amount *((100-advratio)/100);
								op.setReserves(-partial);
								reserves -= partial;
								op.setFiuTransaction(partial);
								fiuTransaction+=partial;
								fiuBalance+=partial;
								op.setFiuBalance(fiuBalance);
								list.add(op);
								
							}
						}
						
					}catch(Exception e){
						e.printStackTrace();
					}
				}*/
				}
				else if(category.equalsIgnoreCase("7b")){
					c.setDefinition("Dishonored Check");
					c.setReserves(0.00);					
					receivables+=amount-opmt;
					//fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
					//fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					if(is_rmu){
						c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
						fiuTransaction+=m.doRoundOff((amount-opmt));
						fiuBalance+=m.doRoundOff((amount-opmt));	//rdc08092010
					}else{
						c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
						fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
						fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					}
					c.setReceivables(amount-opmt);
					c.setFiuTransaction(m.doRoundOff((amount-opmt)*(advratio/100)));
					c.setFiuBalance(fiuBalance);
					list.add(c);
					if(opmt!=0){	
						ClientActivities op = new ClientActivities();
						op.setDefinition("Reversal of OP");
						op.setRef("");
						op.setReceivables(0.00);
						op.setReserves(-1*opmt);
						reserves-=opmt;
						op.setFiuTransaction(0.00);
						op.setFiuBalance(fiuBalance);
						list.add(op);							
					}
					if(dcPayment!=0){
						ClientActivities dc = new ClientActivities();
						dc.setTransactionDate(null);
						dc.setDefinition("Reversal Discount Charge");
						dc.setReceivables(0.00);
						reserves+=dcPayment;
						dc.setReserves(1*dcPayment);
						//fiuTransaction-=dcPayment;
						dc.setFiuTransaction(0.00);
						dc.setFiuBalance(fiuBalance);
						dcCollected -= dcPayment;
						list.add(dc);
					}
					
					if(penaltyPayment !=0){
						ClientActivities pc = new ClientActivities();
						pc.setTransactionDate(null);
						pc.setDefinition("Reversal Penalty Charge");
						pc.setReceivables(0.00);
						reserves+=penaltyPayment;
						pc.setReserves(1*penaltyPayment);
						//fiuTransaction-=penaltyPayment;
						pc.setFiuTransaction(0.00);
						pc.setFiuBalance(fiuBalance);
						penaltyCollected -= penaltyPayment;
						overdueCount --;
						list.add(pc);
					}
					//Unfactored Invoice
					ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
					Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
					if(unfactoredAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal Unfactored Invoices");
						ua.setReceivables(0.00);
						reserves+=unfactoredAmount;
						ua.setReserves(1*unfactoredAmount);
						//fiuTransaction+=penaltyPayment;
						ua.setFiuTransaction(0.00);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					//Discount Charge
					Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
					if(dcAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal RMU Discount Charge");
						ua.setReceivables(-1*dcAmount);
						receivables -= dcAmount;
						//reserves-=dcAmount;
						//ua.setReserves(-1*dcAmount);
						ua.setReserves(0);
						fiuTransaction-=dcAmount;
						fiuBalance -= dcAmount;
						ua.setFiuTransaction(-1*dcAmount);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					//Penalty
					Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
					if(penaltyAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal RMU Penalty Charge");
						ua.setReceivables(-1*penaltyAmount);
						receivables -= penaltyAmount;
						//reserves-=penaltyAmount;
						//ua.setReserves(-1*penaltyAmount);
						ua.setReserves(0);
						fiuTransaction-=penaltyAmount;
						fiuBalance -= penaltyAmount;
						ua.setFiuTransaction(-1*penaltyAmount);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
//					if (amount2 !=0){
//						ClientActivities receiptDCReversal = new ClientActivities();
//						receiptDCReversal.setDefinition("Reversal of DC-Receipt");
//						receiptDCReversal.setRef("");
//						receiptDCReversal.setReceivables(0.00);
//						receiptDCReversal.setReserves(-1*amount2);
//						reserves-=amount2;
//						receiptDCReversal.setFiuTransaction(0.00);
//						receiptDCReversal.setFiuBalance(fiuBalance);
//						list.add(receiptDCReversal);
//					}
//					
				}
				else if(category.equalsIgnoreCase("7c")){
					c.setDefinition("Cancelled CN");
					receivables+=amount-opmt;
					c.setReceivables(amount-opmt);
					reserves+=amount;
					c.setReserves(amount);
					fiuTransaction+=m.doRoundOff(amount*(advratio/100));
					c.setFiuTransaction(m.doRoundOff(amount*(advratio/100)));
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					c.setFiuBalance(fiuBalance);
					list.add(c);
				}
				else if(category.equalsIgnoreCase("9")||category.equalsIgnoreCase("9a")||category.equalsIgnoreCase("9b")){
					
					if(category.equalsIgnoreCase("9a"))c.setDefinition("Penalty Charge");
					if(category.equalsIgnoreCase("9b"))c.setDefinition("PD - Discount Charge");
					if(type.equalsIgnoreCase("1"))c.setDefinition("Refund");
					if(type.equalsIgnoreCase("2"))c.setDefinition("Refund with Overpayment");
					if(type.equalsIgnoreCase("3"))c.setDefinition("Refund - Unfactored Invoice");
					if(type.equalsIgnoreCase("4"))c.setDefinition("Refund - Prev CN");	
					
					c.setReceivables(0.00);
					reserves-=amount;
					c.setReserves(-1*amount);						
					c.setFiuTransaction(0.00);	
					c.setFiuBalance(fiuBalance);
					if(!category.equalsIgnoreCase("9a")&&!category.equalsIgnoreCase("9b")){
						refunds+=amount;
						discountValue=	amount2;	
						
					}
					else
					{
						if(category.equalsIgnoreCase("9a")){
							penaltyCollected += amount ;
							overdueCount++;
						}
						else
							pastDueCollected += amount;
						
						c.setTransactionDate(null);
						c.setRef(null);
					}
					
					list.add(c);
					if(type.equalsIgnoreCase("1")){
						try{
							Statement s = null;
							ResultSet r = null;
							
							s= new FactorConnection().getConnection().createStatement();
							String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
							"on rh.N_REFNO=rd.N_REFNO inner join refund ref on	"+
							"ref.N_REFNO=rh.n_refpaymentno inner join "+
							"Invoice inv on rd.N_INVNO=inv.n_invno	"+
							"where rh.C_CLNTCODE='"+clientCode+"' and ref.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
							r= s.executeQuery(query);
							
							if(r.next()){
								double val = r.getDouble("amount")*((100-advratio)/100);
								if(val!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CN Adjustment From Refund");
									op.setRef("");
									op.setReceivables(0.00);
									op.setReserves(0.00);
									op.setFiuTransaction(val);
									fiuTransaction +=val;
									fiuBalance +=val;
									op.setFiuBalance(fiuBalance);
									list.add(op);
								}
							}
							
							}
							catch(Exception e){
								e.printStackTrace();
							}	
					}
				}	
				
				if(category.equalsIgnoreCase("2")||
				   category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||
				  (category.equalsIgnoreCase("9")&&amount2!=0)
				)
				{
					ClientActivities c3 = new ClientActivities();
				//rdc 08042010	
						c3.setDefinition("Discount Charge");
						c3.setRef("");
						if(category.equalsIgnoreCase("9")&&(type.equalsIgnoreCase("2")||type.equalsIgnoreCase("3")||type.equalsIgnoreCase("4"))){
						}
						else{
							c3.setReceivables(0.00);
						}					
						if(category.equalsIgnoreCase("2") 		
						   ||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")
						   ||category.equalsIgnoreCase("9")){
						   	if (category.equalsIgnoreCase("9")) dcCollected+=amount2;
							if (category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")){ 
								if (amount2>0) {
									c3.setReserves(-1*amount2);
								} else {
									c3.setReserves(amount2);
								}
								reserves-=(amount2);
								fiuTransaction+=amount2;
								c3.setFiuTransaction(amount2); 
								if (category.equalsIgnoreCase("2")) {
									discountCharges=amount2;
									dcCollected+=amount2;
								}
							} else {
								c3.setReserves(-1*discountValue);
								log.info("reserves before adding discount charges: "+reserves);
								reserves+=(-1*discountValue);
								log.info("reserves before adding discount charges: "+reserves);
								
								if (!category.equalsIgnoreCase("9")) {
									c3.setFiuTransaction(discountValue);
									fiuTransaction+=discountValue;
									fiuBalance+=discountValue;
								} else {
									c3.setFiuTransaction(0.00);
								}
							}
							
						}
						else{
							c3.setReserves(0.00); 	//rdc07122010
							c3.setFiuTransaction(0.00);
						}
						c3.setFiuBalance(fiuBalance);
						list.add(c3);	
				}
				rset = rs.next();	//08282010
			}
			
			if(!rset){
				//rdc 08092610 ..... 
				Date today = DateHelper.parse(asOfDate);
				Map map3 = new HashMap();
				map3.put("ADVRATIO", advratio/100.00);
				map3.put("BLR", blr/100.00);
				map3.put("DCR", dcr/100.00);
				map3.put("C_CLNTCODE", clientCode);
				map3.put("asOfDate", asOfDate);
				map3.put("today", DateHelper.parse(DateHelper.format(today)));
						
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				dcAccruals= m.doRoundOff(invoiceDAO.getDCAccrual2(map3));
				log.info("dcAccruals:"+dcAccruals );
				ClientActivities c6 = new ClientActivities();
				AccountingMaintenanceService AMS  = AccountingMaintenanceService.getInstance();
				 pastDueInvoices = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(n_penaltyamount),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
				 dcAccruals = dcAccruals+pastDueInvoices;
				//if (withTrans == 1) {
					reserves+=(-1*dcAccruals);
					fiuBalance+=dcAccruals;	//rdc08092010
					if (dcAccruals>0) {
						c6.setReserves(-1*dcAccruals);
					} else {
						c6.setReserves(dcAccruals);
					}
					c6.setFiuBalance(fiuBalance);
					discountCharges=dcAccruals;
					
					pastDueFR = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(N_INVOICEAMT),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
					/*if(pastDueInvoices!=0){
						ClientActivities c7 = new ClientActivities();	
						c7.setDefinition("Past Due Interest");
						c7.setRef("");
						c7.setTransactionDate(new Date(asOfDate));	
						c7.setReceivables(0.00);
						c7.setFiuTransaction(0.00);	
						c7.setFiuBalance(fiuBalance);
						reserves-=pastDueInvoices;
						c7.setReserves(-1*pastDueInvoices);
						list.add(c7);
					}*/
					c6.setDefinition("Discount Charges - Accrual");
					c6.setRef("");
					c6.setTransactionDate(new Date(asOfDate));	
					c6.setReceivables(0.00);
					c6.setFiuTransaction(0.00);			
					c6.setTotalReceivables(receivables);
					c6.setTotalReserves(reserves);
					c6.setTotalFiuTransaction(fiuTransaction);
					c6.setTotalFiuBalance(fiuBalance);
					c6.setInvoices(invoices);
					c6.setServiceCharges(serviceCharges);
					c6.setAdvances(advances);
					c6.setReceipts(receipts);
					c6.setCreditNotes(creditNotes);
					c6.setRefunds(refunds);
					c6.setDiscountCharges(discountCharges);
					c6.setDcOnCashDelays(dcOnCashDelays);
					c6.setSetupFee(setupFee);
					c6.setDocStamp(docStamp);
					c6.setDcCollected(dcCollected);
					c6.setOverpayment(overpayment);
					c6.setReceiptAdvance(rctAdvance);
					c6.setReceiptRefund(rctRefund);
					c6.setDshnrdChks(dshnrdChks);
					c6.setCnCancelled(cnCancelled);
					c6.setPenaltyCollected(penaltyCollected);
					c6.setPastDueCollected(pastDueInvoices);
					c6.setPastDueFR(pastDueFR);
					c6.setNotarialFee(notarial); //added by CVG as of 04-11-16
					c6.setPenaltyCount(overdueCount);
					list.add(c6);
					log.info("total in");
					log.info("8-setupFee/dcCollected:" + setupFee + "/" + dcCollected);
					log.info("doc stamp amount: " + docStamp);
				//end 08092010
			}
			ClientActivities totals = new ClientActivities();
			totals.setClientCode(clientCode);
			totals.setTotalReceivables(receivables);
			totals.setTotalReserves(reserves);
			totals.setTotalFiuTransaction(fiuTransaction);
			totals.setTotalFiuBalance(fiuBalance);
			totals.setInvoices(invoices);
			totals.setServiceCharges(serviceCharges);
			totals.setAdvances(advances);
			totals.setReceipts(receipts);
			totals.setCreditNotes(creditNotes);
			totals.setRefunds(refunds);
			totals.setDiscountCharges(discountCharges);
			totals.setDcOnCashDelays(dcOnCashDelays);
			totals.setSetupFee(setupFee);
			totals.setDocStamp(docStamp);
			totals.setDcCollected(dcCollected);
			totals.setOverpayment(overpayment);
			totals.setReceiptAdvance(rctAdvance);
			totals.setReceiptRefund(rctRefund);
			totals.setNotarialFee(notarial);
		 
			returnMap.put("cisaExtract", mbDAO.extractCISA(totals, asOfDate, map));
				
			
			//Uncomment this part... 
			boolean updateMonthlyBalances=mbDAO.saveMonthlyBalancesByClntCodeAsOfDate(totals, asOfDate,map);
			boolean resetFIUTran = resetFIUTran(clientCode,map);
			log.info("Processing/Updating MonthlyBalances for client with client code"+clientCode+" turn to "+updateMonthlyBalances);
			log.info("Processing/Updating FIUTran for client with client code"+clientCode+" turn to "+resetFIUTran);
			if(updateMonthlyBalances && resetFIUTran){
				conn.commit();
			}else{
				conn.rollback();
			}
			
			
		}
		catch(Exception e){			
			try {
				e.printStackTrace();
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally{			
			try{
				conn.setAutoCommit(true);
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return returnMap;		
	}
	
	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	/*
	 * UPDATE 
	 * getClientFIUbyAsOfDate
	 * updateClientMonthEnd
	 * getClientActivities
	 * LAST UPDATE: 5/2/2012
	 * */
	public void updateClientDailyFIU(String clientCode,String asOfDate,Map map)
	{	
		double fiuBalance=0.00;
		List<ClientActivities> list = new ArrayList<ClientActivities>();		
		String sSQL = "SELECT     * FROM ( " + 	
				"		SELECT	i.C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_INVOICEAMT AS AMOUNT, 0.00 AS AMOUNT2, N_ADVANCEDRATIO AS ADVRATIO, " +
				"				C_INVOICENO AS ref,  0 AS ref2, '1' AS category , 0 as cashDelay , '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment i.N_SVCCHGTYPE as scType " +
				"				FROM	Invoice i INNER JOIN dbCIF.dbo.CLIENT c ON i.C_CLNTCODE = c.C_CLNTCODE " +
				"				WHERE i.C_STATUS IN('2','3','4','5','6')" +
				" 				AND (i.C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"				CAST(N_REFNO AS NVARCHAR) AS REF, c_debit AS REF2,'1a' AS CATEGORY , 0 AS CASHDELAY, C_ADJREC+C_ADJRES+C_ADJFIU+C_ADJFIUBAL+a2.C_ADJDESC AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +   
				"				FROM ADJUSTMENT a INNER JOIN ADJUSTMENTTYPE a2 ON a.C_ADJCODE = a2.C_ADJCODE " +
				"				WHERE C_STATUS = '2'AND B_INCLUDED = 1 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "+  
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2b' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +  
		        "    				FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4)  AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0  "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
		        "  					 + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')"+
				"				UNION "+
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO,   "+
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2c' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"					FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
				"   				+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
				"				UNION"	+
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG2 AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE ISNULL(N_DISCCHG2,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				//added by CVg as of 03-16-16
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_NOTARIAL AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2d' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " + 
				"				FROM	Advances WHERE ISNULL(N_NOTARIAL,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				//end
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE     C_TYPE = 2 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE     C_TYPE = 3 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '4' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND (C_STATUS IN (1,2,4))   " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '5' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 2 AND (C_STATUS IN (1,2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT a.C_CLNTCODE, a.C_CUSTCODE,  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101)AS D_TRANSACTIONDATE, AMOUNT,AMOUNT2, ADVRATIO, " +
				"				REF, REF2,CATEGORY , CASHDELAY, TYPE,AMOUNT1,OVERPAYMENT,dcPayment, penaltyPayment,'' as scType   FROM ( " +
				"			SELECT rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,rdinv.D_TRANSACTIONDATE,D_FULLYPAIDDATE, ISNULL(SUM(N_RECEIPTAMT),0) AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(rd2.N_REFNO  AS NVARCHAR) AS REF, rh2.C_RECEIPTTYPE AS REF2,'5A' AS CATEGORY , 0 AS CASHDELAY, '' AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM RECEIPTSDTL rd2 INNER JOIN( " +
				"			SELECT DISTINCT rh.C_CLNTCODE, rh.C_CUSTCODE,rd.C_INVOICENO,rd.N_INVNO,rh.D_TRANSACTIONDATE,D_FULLYPAIDDATE FROM RECEIPTSDTL rd " + 
				"				INNER JOIN ( " + 
				"			SELECT	C_CLNTCODE, C_CUSTCODE,CAST(N_REFNO AS NVARCHAR) AS REF, D_TRANSACTIONDATE " +
				"				FROM	RECEIPTSHDR WHERE     C_RECEIPTTYPE IN (1,2,3,4) AND (C_STATUS IN (2,4)) " + 
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"				) AS rh ON rd.N_REFNO = rh.REF " +
				"				INNER JOIN INVOICE inv ON rd.C_INVOICENO = inv.C_INVOICENO and rd.N_INVNO = inv.N_INVNO " + 
				"				AND inv.C_STATUS IN (5,6) " +  
				"				) AS rdinv ON rd2.C_INVOICENO = rdinv.C_INVOICENO  AND rd2.N_INVNO = rdinv.N_INVNO " +
				"				INNER JOIN  RECEIPTSHDR rh2 ON rd2.N_REFNO=rh2.N_REFNO AND rh2.C_RECEIPTTYPE IN (3,4)  AND rh2.C_STATUS in (2,4)" +
				"				GROUP BY rh2.C_RECEIPTTYPE,rd2.N_REFNO,rdinv.D_TRANSACTIONDATE,rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,D_FULLYPAIDDATE " +
				"		) a where  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101) =  CONVERT(VARCHAR(10), a.D_FULLYPAIDDATE, 101) " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2,  0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, C_STATUS ref2, '6' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 3 AND (C_STATUS IN (2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref,C_STATUS  AS ref2, '6a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 4 AND (C_STATUS IN (2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"      SELECT	cn.C_CLNTCODE, cn.C_CUSTCODE, cn.D_TRANSACTIONDATE, cn.N_AMOUNT AS AMOUNT,  0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(cn.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '6b' AS category , 0 as cashDelay, '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +   
				"			FROM	CreditNote cn INNER JOIN RECEIPTSHDR rh ON cn.C_RECEIPTNO = rh.N_REFNO " +
				"			WHERE cn.C_STATUS IN(1,2) AND rh.C_STATUS <> 3 " +
				" 				AND (cn.C_CLNTCODE ='" + clientCode + "') AND (cn.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				/*//Add Discount Charge and Penalty 
				//7d for Discount Charge
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7d' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
				"                   FROM	ReceiptsHdr WHERE   " +
				" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +		
				//7e for Penalty
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7e' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
				"                   FROM	ReceiptsHdr WHERE   " +
				" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				*/
				"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  c.D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a2' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
				"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
				" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (c.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"    SELECT	C_CLNTCODE, C_CUSTCODE,  (CASE WHEN D_DATEBOUNCED IS NOT NULL THEN D_DATEBOUNCED ELSE D_TRANSACTIONDATE END) AS D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7b' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  (CASE WHEN D_CANCELLEDDATE IS NOT NULL THEN D_CANCELLEDDATE ELSE D_DATEBOUNCED END) as D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7c' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " + 
				"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
				"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
				" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"    SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_REFAMT AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9' AS category , 0 as cashDelay, C_TYPE AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	Refund WHERE  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"			union"+
				"	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "   +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9a' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +     
		        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) "+   
		        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
		        "			UNION "+	
		        "	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, "+  
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9b' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +     
		        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)"+   
		        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
		        "			UNION "+	
		    	"	SELECT C_CLNTCODE,0 C_CUSTCODE ,date_tagged_RMU D_TRANSACTIONDATE, ISNULL(amount_reversed,0) AS AMOUNT, 0 AS AMOUNT2, 0.0 AS ADVRATIO,'CR' as ref, 0 as ref2, 'client' AS category, 0 as cashDelay,'' as type,0 as Amount1, 0 as overPayment, 0 as dcPayment, 0 as penaltyPayment,'' as scType	"+
		   	 	"	FROM dbcif..Client where is_RMU = 1 and C_CLNTCODE ='" + clientCode + "' and (date_tagged_RMU BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)	"+ 
		        "           			 +'/01/'+  CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')	"+ 
		        "	) a " +
		        //Replace the order by fields (Previously D_TRANSACTIONDATE,catefory,ref asc)
				"	ORDER BY D_TRANSACTIONDATE,category,ref asc ";		
		log.info(" getClientActivities [args1:" +clientCode+"][debug]: " +sSQL);
		
		Statement stmt=null;
		ResultSet rs=null;
		Connection conn = null;
		conn = new FactorConnection().getConnection();
		try{
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);


			double dcr=0.00;
			double scr=0.00;
			double blr = 0.00;
			String blrCode="";
			int day=0;
			int cashDelay=0;
			String custCode="";
			String customerName="";

			double serviceValue=0.00;
			double discountValue=0.00;
			double dcCashDelayValue=0.00;

			//Totals
			double receivables=0.00;
			double reserves=0.00;
			double fiuTransaction=0.00;
			//double fiuBalance=0.00;

			double invoices=0.00;
			double advances=0.00;
			double receipts=0.00;
			double serviceCharges=0.00;			
			double discountCharges=0.00;
			double dcOnCashDelays=0.00;
			double creditNotes=0.00;
			double refunds=0.00;
			double setupFee=0.00;
			double dcCollected=0.00;
			double dcAccruals=0.00;
			double advratio=0.00;
			double iniVal=0.00;
			double docStamp=0.00;
			int withTrans = 0;
			double lastAccruals = 0.00;
			double overpayment = 0.00;
			double rctAdvance = 0.00;
			double rctRefund = 0.00;
			double dshnrdChks = 0.00;
			double cnCancelled = 0.00;
			String type="";
			String branchCode="";
			
			double pastDueInvoices = 0.00;
			double pastDueCollected = 0.00;
			double penaltyCollected = 0.00;
			double pastDueFR = 0.00;
			
			double balance=0.00;
			
			//added by CVG as of 04-11-16
			double notarial = 0.00;
			boolean is_rmu = false;
			ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
			while(clientList.hasNext()){
				ClientActivities header = new ClientActivities();
				Client client = (Client)clientList.next();
				header.setClient(client);
				header.setClientCode(clientCode);
				dcr=m.doRoundOff(client.getN_Dcr());
				scr=m.doRoundOff(client.getN_Scr());
				advratio =m.doRoundOff(client.getN_AdvRatio());
				branchCode = client.getC_BranchCode();	//rdc08132010
				blrCode = client.getC_BlrTypeCode();
			
				BLRFileDAO blrDao = new BLRFileDAO();
				ListIterator<BLRFile> blrFileList = blrDao.getBLRFile(clientCode, asOfDate).listIterator();
				while(blrFileList.hasNext()){
					BLRFile blrFile = (BLRFile) blrFileList.next();
					log.info("BLR: "+blrFile.getBlr());
					log.info("Effectivity Date: "+blrFile.getEffectiveDate());
					log.info("Expiry Date: "+blrFile.getExpiryDate());
					blr = m.doRoundOff(blrFile.getBlr());
					log.info("blrFile.getBlr()"+blrFile.getBlr());
					//header.setBlrFile(blrFile);
					break;
				}
				
				is_rmu = client.isIs_rmu();
				
				String strMMM = DateUtils.getLastMonthMMM(asOfDate);//RLS 01/07/2011 add method in getting prefix of month (MMM) DateUtils.getLastMonthMMM(asOfDate)
				strMMM = "N_" + strMMM +"ACC";				
				
				Map map2 = new HashMap();
				map2.put("C_CLNTCODE", clientCode);
				map2.put("MMM", strMMM);		
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				dcAccruals= m.doRoundOff(invoiceDAO.getLastAccrual(map2));
				log.info("dcAccruals:"+dcAccruals );

				MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
				ListIterator mbList =mbDAO.getMonthBalClntCodeAsOfDate(clientCode,asOfDate).listIterator();						
				while(mbList.hasNext()){

					MonthlyBalances mb = (MonthlyBalances)mbList.next();
					header.setTransactionDate(DateHelper.getDateInFirstDay(asOfDate));
					header.setStartDate(DateHelper.getDateInFirstDay(asOfDate));
					header.setDefinition("Balance B/F");
					header.setRef("");
					header.setReceivables(m.doRoundOff(mb.getMonthReceivables().doubleValue()));
					header.setReserves(m.doRoundOff(mb.getMonthReserves().doubleValue()));
					//header.setFiuBalance(mb.getMonthFIU().doubleValue());
					if (m.doRoundOff(mb.getMonthFIU().doubleValue())>iniVal) {	//rdc 08102010
						fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue() + dcAccruals );//header.getFiuTransaction()s;		
						header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
					} else {
						if ((m.doRoundOff(mb.getMonthFIU().doubleValue())==iniVal) && dcAccruals>0){
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue()+dcAccruals);//header.getFiuTransaction();
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
						}else{
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue());//header.getFiuTransaction();
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue()));
						}
					}
					//header.setFiuTransaction(mb.getMonthFIU().doubleValue());
					header.setFiuTransaction(m.doRoundOff(mb.getMonthFIU().doubleValue()));
					receivables=header.getReceivables();
					reserves=header.getReserves();
					fiuTransaction=header.getFiuTransaction();
					
					if((dcAccruals>0.00) && (fiuTransaction==0.00)){
						balance=header.getFiuTransaction()+dcAccruals;
					}else{
					
						balance=header.getFiuTransaction();
					} 
					
					
					break;
				}
				list.add(header);
				break;				
			}
			
			ClientActivities disc = new ClientActivities();
			disc.setDefinition("Last Month's DC Accrual");
			disc.setRef("");
			disc.setReceivables(0.00);			
			
			log.info("reserves before adding discount in balance bf "+reserves);
			//reserves-=discountValue; 	//rdc 08102010
			if ((fiuTransaction>iniVal)||(reserves>iniVal)||receivables>iniVal) {
				
				if((dcAccruals>0.00) && (fiuTransaction==0.00)){
					fiuBalance=balance-dcAccruals;
				}else{
				    fiuBalance-=dcAccruals;
				}
				reserves+=dcAccruals;
				disc.setReserves(dcAccruals);
			} else {
				disc.setReserves(0.00);
			}
			//lastAccruals = dcAccruals;
			log.info("reserves after adding discount in balance bf "+reserves);
			
			disc.setFiuTransaction(0.00);
			
			disc.setFiuBalance(fiuBalance);	
			//discountCharges+=discountValue; //rdc08102010
			dcAccruals=0.00;
			list.add(disc);	
			boolean rset = rs.next();	
			String ref = "";
			while(rset){
				log.info("receipts"+receipts);
				type=rs.getString("type");
				double amount =m.doRoundOff(rs.getDouble("AMOUNT")); 
				double amount1=m.doRoundOff(rs.getDouble("amount1"));
				double amount2 =m.doRoundOff(rs.getDouble("AMOUNT2"));	//rdc07152010
				double opmt = m.doRoundOff(rs.getDouble("overPayment"));
				//added 6/28/2016 for receipts dc and penalty
				double dcPayment = m.doRoundOff(rs.getDouble("dcPayment"));
				double penaltyPayment = m.doRoundOff(rs.getDouble("penaltyPayment"));
				String scType = rs.getString("scType")!=null? rs.getString("scType"):"2"; //cvg 02132017
				String ref2 = rs.getString("ref2").trim();	//rdc07152010
				String date1 = sdf.format(rs.getDate("D_TRANSACTIONDATE"));				
				String category = rs.getString("category").trim();
				if (date1.equals(asOfDate)) {
					day = 1;
				} else {
					day = DateHelper.getDayPerTransaction(date1, asOfDate);
				}	
				//advratio =m.doRoundOff(rs.getDouble("ADVRATIO"));	//rdc08062010
				cashDelay = rs.getInt("cashDelay");
				log.info("Day: "+day);
				log.info("Category "+category);
				ClientActivities c = new ClientActivities();				
				c.setRef(rs.getString("ref"));
				c.setTransactionDate(rs.getDate("D_TRANSACTIONDATE"));				
				if(category.equalsIgnoreCase("1")){
					//rdc08092010
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					//end 08092010
					c.setDefinition("Invoice");
					c.setReceivables(amount);
					receivables+=amount;
					c.setReserves(amount);
					reserves+=amount;
					c.setFiuTransaction(0.00);
					c.setFiuBalance(fiuBalance);
					invoices+=amount;	
					list.add(c);

					ClientActivities c2 = new ClientActivities();
					c2.setDefinition("Service Charge");
					c2.setRef("");
					c2.setReceivables(0.00);
					if (scType.equals("1")){ //added cvg02132017
						serviceValue=m.doRoundOff(amount*(scr/100)*(advratio/100));
					}else{
						serviceValue=m.doRoundOff(amount*(scr/100)); //old
					}//end
					reserves-=serviceValue;
					c2.setReserves(-1*serviceValue);						
					fiuTransaction+=serviceValue;
					c2.setFiuTransaction(serviceValue);
					c2.setFiuBalance(fiuBalance);
					serviceCharges+=serviceValue;
					list.add(c2);

				}
				else if(category.equalsIgnoreCase("1a")){
					String strTypeRec =  type.substring(0, 1);
					String strTypeRes = type.substring(1, 2);
					String strTypeFiu = type.substring(2, 3);
					String strTypeFiuBal = type.substring(3, 4);
					String strDesc = type.substring(4);
					
					if (ref2.equals("1")){
						dcCollected+=amount;
					} else {
						dcCollected-=amount;
					}
					
					//effect on receivables
					if (strTypeRec.equals("1")) {
						receivables+=amount;
						c.setReceivables(amount);
					} else if (strTypeRec.equals("2")) {
						receivables-=amount;
						c.setReceivables(-1*amount);
					} else {
						c.setReceivables(0.00);
					}
					//effect on reserves
					if (strTypeRes.equals("1")) {
						reserves+=amount;
						c.setReserves(amount);
					} else if (strTypeRes.equals("2")) {
						reserves-=amount;
						c.setReserves(-1*amount);
					} else {
						c.setReserves(0.00);
					}
					//effect on fiu
					if (strTypeFiu.equals("1")) {
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
					} else if (strTypeFiu.equals("2")) {
						fiuTransaction-=amount;
						c.setFiuTransaction(-1*amount);
					} else {
						c.setFiuTransaction(0.00);
					}
					//effect on fiu balance
					if (strTypeFiuBal.equals("1")) {
						fiuBalance+=amount;
					} else if (strTypeFiuBal.equals("2")) {
						fiuBalance-=amount;
					}
					c.setFiuBalance(fiuBalance);
					c.setDefinition(strDesc);			
					list.add(c);
				}else if(category.equalsIgnoreCase("client")){
					//c.setDefinition("Client Reversal");
					//c.setReceivables(0.0);
					//reserves-=amount;
					//c.setReserves(-1*amount);
					//c.setFiuTransaction(amount);
					//fiuTransaction +=amount;
					//fiuBalance +=amount;
					//c.setFiuBalance(fiuBalance);
					//list.add(c);	
				}
				else if(category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||category.equalsIgnoreCase("2a")||category.equalsIgnoreCase("2b")||category.equalsIgnoreCase("2c")||category.equalsIgnoreCase("2d")){					
					if(category.equalsIgnoreCase("2"))c.setDefinition("Advances");
					if(category.equalsIgnoreCase("3"))c.setDefinition("Setting-up Fee");
					if(category.equalsIgnoreCase("3a"))c.setDefinition("Advances - Unfactored");
					if(category.equalsIgnoreCase("2a"))c.setDefinition("Doc Stamp");
					if(category.equalsIgnoreCase("2b"))c.setDefinition("Penalty Charge");
					if(category.equalsIgnoreCase("2c"))c.setDefinition("PD - Discount Charge");
					if(category.equalsIgnoreCase("2d"))c.setDefinition("Notarial Fee"); //added by CVG as of 04-11-16
					//08042010
					c.setReceivables(0.00);
					reserves-=amount;
					c.setReserves(-1*amount);
					fiuTransaction+=amount;
					c.setFiuTransaction(amount);
					c.setFiuBalance(fiuBalance);
					if(category.equalsIgnoreCase("2")) advances+=amount;			
					list.add(c);
					if(category.equalsIgnoreCase("2")) {
						discountValue=m.doRoundOff(getDiscountCharge(amount2,blr,dcr,day));
						try{
							Statement s = null;
							ResultSet r = null;
							
							s= new FactorConnection().getConnection().createStatement();
							String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
							"on rh.N_REFNO=rd.N_REFNO inner join Advances adv on	"+
							"adv.N_REFNO=rh.n_advpaymentno inner join "+
							"Invoice inv on rd.N_INVNO=inv.n_invno	"+
							"where rh.C_CLNTCODE='"+clientCode+"' and adv.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
							r= s.executeQuery(query);
							
							if(r.next()){
								double val = r.getDouble("amount")*((100-advratio)/100);
								if(val!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CN Adjustment From Advance");
									op.setRef("");
									op.setReceivables(0.00);
									op.setReserves(0.00);
									op.setFiuTransaction(val);
									fiuTransaction +=val;
									fiuBalance +=val;
									op.setFiuBalance(fiuBalance);
									list.add(op);
								}
							}
							
							}
							catch(Exception e){
								e.printStackTrace();
							}	
					} else if(category.equalsIgnoreCase("3")) {
							setupFee = amount;
							/*discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,1));	
							dcCollected+=discountValue;*/
					} else if(category.equalsIgnoreCase("3a")) {
						discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,day));
					} else if(category.equalsIgnoreCase("2a")){
						c.setTransactionDate(null);
						c.setRef(null);
						docStamp =  amount; 
					}
					 else if(category.equalsIgnoreCase("2b")){
						 c.setTransactionDate(null);
						 c.setRef(null);
						 penaltyCollected += amount ;
					 }
					 else if(category.equalsIgnoreCase("2c")){
						 pastDueCollected += amount;
						 c.setTransactionDate(null);
						 c.setRef(null);
					 }
					 else if(category.equalsIgnoreCase("2d")){
						 pastDueCollected += amount;
						 c.setTransactionDate(null);
						 c.setRef(null);
						 notarial =  amount; 
					 }
					
					withTrans = 1;
					
			}		

				else if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("5")||category.equalsIgnoreCase("7a")||category.equalsIgnoreCase("7d")){

					if(category.equalsIgnoreCase("7d")){
						c.setDefinition("Discount Charge");
						c.setReceivables(0.00);
						reserves-=amount;
						c.setReserves(-1*amount);
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
						c.setFiuBalance(fiuBalance);
						list.add(c);
					}
					else{
						log.info("Receipts cat4 and 5 here....");
						if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
							custCode=rs.getString("C_CUSTCODE");
							customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
						}					
						if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("7a"))c.setDefinition("RCT-CHK-"+customerName);
						if(category.equalsIgnoreCase("5"))c.setDefinition("RCT-CSH-"+customerName);	
							receivables-=amount-opmt;
							//fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
							
							receipts+=amount;
							c.setReceivables(-1*(amount-opmt));
							//c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
							if(is_rmu){
								c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
								fiuTransaction-=m.doRoundOff((amount-opmt));
								fiuBalance-=m.doRoundOff((amount-opmt));	//rdc08092010
							}else{
								c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
								fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
								fiuBalance-=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
							}
						log.info("amount: "+amount);
						log.info("amount1: "+amount1);
						amount=(amount1<amount)?amount1:amount;
						log.info("amount to be computed for discount: "+amount);
						discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
						c.setReserves(0.00);
						c.setFiuBalance(fiuBalance);
						list.add(c);
							if(opmt!=0){	
								ClientActivities op = new ClientActivities();
								op.setDefinition("Over Payment");
								op.setRef("");
								op.setReceivables(0.00);
								overpayment+=opmt;
								op.setReserves(opmt);
								reserves+=opmt;
								op.setFiuTransaction(0.00);
								op.setFiuBalance(fiuBalance);
								list.add(op);							
							}
							if(dcPayment!=0){
								ClientActivities dc = new ClientActivities();
								dc.setTransactionDate(null);
								dc.setDefinition("Discount Charge");
								dc.setReceivables(0.00);
								reserves-=dcPayment;
								dc.setReserves(-1*dcPayment);
								//fiuTransaction+=dcPayment;
								dc.setFiuTransaction(0.00);
								dc.setFiuBalance(fiuBalance);
								dcCollected += dcPayment;
								list.add(dc);
							}
							
							if(penaltyPayment !=0){
								ClientActivities pc = new ClientActivities();
								pc.setTransactionDate(null);
								pc.setDefinition("Penalty Charge");
								pc.setReceivables(0.00);
								reserves-=penaltyPayment;
								pc.setReserves(-1*penaltyPayment);
								//fiuTransaction+=penaltyPayment;
								pc.setFiuTransaction(0.00);
								pc.setFiuBalance(fiuBalance);
								penaltyCollected += penaltyPayment;
								list.add(pc);
							}
							//Unfactored Invoice
							ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
							Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
							if(unfactoredAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("Unfactored Invoices");
								ua.setReceivables(0.00);
								reserves-=unfactoredAmount;
								ua.setReserves(-1*unfactoredAmount);
								//fiuTransaction+=penaltyPayment;
								ua.setFiuTransaction(0.00);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							//Discount Charge
							Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
							if(dcAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("RMU Discount Charge");
								ua.setReceivables(dcAmount);
								receivables += dcAmount;
								//reserves-=dcAmount;
								//ua.setReserves(-1*dcAmount);
								ua.setReserves(0);
								fiuTransaction+=dcAmount;
								fiuBalance += dcAmount;
								ua.setFiuTransaction(dcAmount);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							//Penalty
							Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
							if(penaltyAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("RMU Penalty Charge");
								ua.setReceivables(penaltyAmount);
								receivables += penaltyAmount;
								//reserves-=penaltyAmount;
								//ua.setReserves(-1*penaltyAmount);
								ua.setReserves(0);
								fiuTransaction+=penaltyAmount;
								fiuBalance += penaltyAmount;
								ua.setFiuTransaction(penaltyAmount);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							
					}
				}
				else if(category.equalsIgnoreCase("5a")){
					ClientActivities pp = new ClientActivities();
					if(ref2.contentEquals("3")||ref2.contentEquals("4"))
					{
								/*if(ref2.contentEquals("3")){
									pp.setDefinition("CN Adjustment from Advance");
								}
								else if(ref2.contentEquals("4")){
									pp.setDefinition("CN Adjustment from Refund");
								}*/
					}
					else{
						pp.setDefinition("Previous Partial Payment");
					//pp.setRef(rs.getString("ref"));
					pp.setReceivables(0.00);
					pp.setReserves(0.00);
					fiuTransaction+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuTransaction(amount*m.doRoundOff((100-advratio)/100));	
					fiuBalance+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuBalance(fiuBalance);
					list.add(pp);}
				}

				else if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")||category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
					log.info("RCT-ADV and RCT-REF here....");
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
						if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
							custCode=rs.getString("C_CUSTCODE");
							customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
						}							
						if(category.equalsIgnoreCase("6")){
							c.setDefinition("RCT-ADV-"+customerName);
							rctAdvance+=amount;
						}
						if(category.equalsIgnoreCase("6a")){
							c.setDefinition("RCT-REF-"+customerName);
							rctRefund+=amount;
						}
					
					}
					if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
						if(is_rmu){
							c.setDefinition("RMU Credit Note");
						}else
							c.setDefinition("Credit Note");
						creditNotes+=amount;
					}
					receivables-=amount-opmt;
					c.setReceivables(-1*(amount-opmt));
					
					
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")) {
						c.setReserves(0.00);
						if(rs.getString("ref2").equalsIgnoreCase("2")){
							fiuTransaction-=(amount*(advratio/100))-opmt;
							c.setFiuTransaction(-1*((amount*(advratio/100))-opmt));
							fiuBalance-=(amount*(advratio/100))-opmt;
						}else{
							fiuTransaction-=amount-opmt;
							c.setFiuTransaction(-1*(amount-opmt));
							fiuBalance-=amount-opmt;
						}
						 
						
					} else {
						if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
							if(is_rmu){
								reserves-=amount;
								c.setReserves(-1*amount);
								//fiuTransaction-=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(0);
								//fiuBalance-=m.doRoundOff(amount*(advratio/100));
							}else{
								reserves-=amount;
								c.setReserves(-1*amount);
								fiuTransaction-=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
								fiuBalance-=m.doRoundOff(amount*(advratio/100));
							}
							
						}else{
							reserves-=amount;
							c.setReserves(-1*amount);
							fiuTransaction-=m.doRoundOff(amount*(advratio/100));
							c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
							fiuBalance-=m.doRoundOff(amount*(advratio/100));
						}
					}	
					c.setFiuBalance(fiuBalance);
					log.info("amount: "+amount);
					log.info("amount1: "+amount1);
					amount=(amount1<amount)?amount1:amount;
					log.info("amount to be computed for discount: "+amount);
					discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
						if(opmt!=0){	
							ClientActivities op = new ClientActivities();
							op.setDefinition("Over Payment");
							op.setRef("");
							op.setReceivables(0.00);
							overpayment+=opmt;
							op.setReserves(opmt);
							reserves+=opmt;
							op.setFiuTransaction(0.00);
							op.setFiuBalance(fiuBalance);
							list.add(op);							
						}					

					}						
					list.add(c);
					/*if(category.equalsIgnoreCase("6")&&!rs.getString("ref2").contentEquals("0")){
						try{
							Statement s = null;
							ResultSet r = null;
							s = new FactorConnection().getConnection().createStatement();
							String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
							log.info(sql);
							r = s.executeQuery(sql);
							if(r.next()){
								if(r.getDouble("partialAmount")!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CE Adjustment From RCT-ADV (Partial Payment)");
									op.setRef("");
									op.setReceivables(0.0);
									double partial = amount *((100-advratio)/100);
									op.setReserves(-partial);
									reserves -= partial;
									op.setFiuTransaction(partial);
									fiuTransaction+=partial;
									fiuBalance+=partial;
									op.setFiuBalance(fiuBalance);
									list.add(op);
									
								}
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				else if(category.equalsIgnoreCase("6a")&&!rs.getString("ref2").contentEquals("0")){
					try{
						Statement s = null;
						ResultSet r = null;
						s = new FactorConnection().getConnection().createStatement();
						String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
						log.info(sql);
						r = s.executeQuery(sql);
						if(r.next()){
							if(r.getDouble("partialAmount")!=0){
								ClientActivities op = new ClientActivities();
								op.setDefinition("CE Adjustment From RCT-REF (Partial Payment)");
								op.setRef("");
								op.setReceivables(0.0);
								double partial = amount *((100-advratio)/100);
								op.setReserves(-partial);
								reserves -= partial;
								op.setFiuTransaction(partial);
								fiuTransaction+=partial;
								fiuBalance+=partial;
								op.setFiuBalance(fiuBalance);
								list.add(op);
								
							}
						}
						
					}catch(Exception e){
						e.printStackTrace();
					}
				}*/
				}
				else if(category.equalsIgnoreCase("7b")){
					c.setDefinition("Dishonored Check");
					c.setReserves(0.00);					
					receivables+=amount-opmt;
					//fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
					//fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					
					if(is_rmu){
						c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
						fiuTransaction+=m.doRoundOff((amount-opmt));
						fiuBalance+=m.doRoundOff((amount-opmt));	//rdc08092010
					}else{
						c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
						fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
						fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					}
					c.setReceivables(amount-opmt);
					c.setFiuTransaction(m.doRoundOff((amount-opmt)*(advratio/100)));
					c.setFiuBalance(fiuBalance);
					list.add(c);
					if(opmt!=0){	
						ClientActivities op = new ClientActivities();
						op.setDefinition("Reversal of OP");
						op.setRef("");
						op.setReceivables(0.00);
						op.setReserves(-1*opmt);
						reserves-=opmt;
						op.setFiuTransaction(0.00);
						op.setFiuBalance(fiuBalance);
						list.add(op);							
					}
					if(dcPayment!=0){
						ClientActivities dc = new ClientActivities();
						dc.setTransactionDate(null);
						dc.setDefinition("Reversal Discount Charge");
						dc.setReceivables(0.00);
						reserves+=dcPayment;
						dc.setReserves(1*dcPayment);
						//fiuTransaction-=dcPayment;
						dc.setFiuTransaction(0.00);
						dc.setFiuBalance(fiuBalance);
						dcCollected -= dcPayment;
						list.add(dc);
					}
					
					if(penaltyPayment !=0){
						ClientActivities pc = new ClientActivities();
						pc.setTransactionDate(null);
						pc.setDefinition("Reversal Penalty Charge");
						pc.setReceivables(0.00);
						reserves+=penaltyPayment;
						pc.setReserves(1*penaltyPayment);
						//fiuTransaction-=penaltyPayment;
						pc.setFiuTransaction(0.00);
						pc.setFiuBalance(fiuBalance);
						penaltyCollected -= penaltyPayment;
						list.add(pc);
					}
					//Unfactored Invoice
					ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
					Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
					if(unfactoredAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal Unfactored Invoices");
						ua.setReceivables(0.00);
						reserves+=unfactoredAmount;
						ua.setReserves(1*unfactoredAmount);
						//fiuTransaction+=penaltyPayment;
						ua.setFiuTransaction(0.00);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					//Discount Charge
					Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
					if(dcAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal RMU Discount Charge");
						ua.setReceivables(-1*dcAmount);
						receivables -= dcAmount;
						//reserves-=dcAmount;
						//ua.setReserves(-1*dcAmount);
						ua.setReserves(0);
						fiuTransaction-=dcAmount;
						fiuBalance -= dcAmount;
						ua.setFiuTransaction(-1*dcAmount);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					//Penalty
					Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
					if(penaltyAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal RMU Penalty Charge");
						ua.setReceivables(-1*penaltyAmount);
						receivables -= penaltyAmount;
						//reserves-=penaltyAmount;
						//ua.setReserves(-1*penaltyAmount);
						ua.setReserves(0);
						fiuTransaction-=penaltyAmount;
						fiuBalance -= penaltyAmount;
						ua.setFiuTransaction(-1*penaltyAmount);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					
//					if (amount2 !=0){
//						ClientActivities receiptDCReversal = new ClientActivities();
//						receiptDCReversal.setDefinition("Reversal of DC-Receipt");
//						receiptDCReversal.setRef("");
//						receiptDCReversal.setReceivables(0.00);
//						receiptDCReversal.setReserves(-1*amount2);
//						reserves-=amount2;
//						receiptDCReversal.setFiuTransaction(0.00);
//						receiptDCReversal.setFiuBalance(fiuBalance);
//						list.add(receiptDCReversal);
//					}
				}
				else if(category.equalsIgnoreCase("7c")){
					c.setDefinition("Cancelled CN");
					receivables+=amount-opmt;
					c.setReceivables(amount-opmt);
					reserves+=amount;
					c.setReserves(amount);
					fiuTransaction+=m.doRoundOff(amount*(advratio/100));
					c.setFiuTransaction(m.doRoundOff(amount*(advratio/100)));
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					c.setFiuBalance(fiuBalance);
					list.add(c);
				}
				else if(category.equalsIgnoreCase("9")||category.equalsIgnoreCase("9a")||category.equalsIgnoreCase("9b")){
					
					if(category.equalsIgnoreCase("9a"))c.setDefinition("Penalty Charge");
					if(category.equalsIgnoreCase("9b"))c.setDefinition("PD - Discount Charge");
					if(type.equalsIgnoreCase("1"))c.setDefinition("Refund");
					if(type.equalsIgnoreCase("2"))c.setDefinition("Refund with Overpayment");
					if(type.equalsIgnoreCase("3"))c.setDefinition("Refund - Unfactored Invoice");
					if(type.equalsIgnoreCase("4"))c.setDefinition("Refund - Prev CN");	
					
					c.setReceivables(0.00);
					reserves-=amount;
					c.setReserves(-1*amount);						
					c.setFiuTransaction(0.00);	
					c.setFiuBalance(fiuBalance);
					if(!category.equalsIgnoreCase("9a")&&!category.equalsIgnoreCase("9b")){
						refunds+=amount;
						discountValue=	amount2;	
						
					}
					else
					{
						if(category.equalsIgnoreCase("9a"))
							penaltyCollected += amount ;
						else
							pastDueCollected += amount;
						
						c.setTransactionDate(null);
						c.setRef(null);
					}
					
					list.add(c);
					if(type.equalsIgnoreCase("1")){
						try{
							Statement s = null;
							ResultSet r = null;
							
							s= new FactorConnection().getConnection().createStatement();
							String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
							"on rh.N_REFNO=rd.N_REFNO inner join refund ref on	"+
							"ref.N_REFNO=rh.n_refpaymentno inner join "+
							"Invoice inv on rd.N_INVNO=inv.n_invno	"+
							"where rh.C_CLNTCODE='"+clientCode+"' and ref.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
							r= s.executeQuery(query);
							
							if(r.next()){
								double val = r.getDouble("amount")*((100-advratio)/100);
								if(val!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CN Adjustment From Refund");
									op.setRef("");
									op.setReceivables(0.00);
									op.setReserves(0.00);
									op.setFiuTransaction(val);
									fiuTransaction +=val;
									fiuBalance +=val;
									op.setFiuBalance(fiuBalance);
									list.add(op);
								}
							}
							
							}
							catch(Exception e){
								e.printStackTrace();
							}	
					}
				}	
				
				if(category.equalsIgnoreCase("2")||
				   category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||
				  (category.equalsIgnoreCase("9")&&amount2!=0)
				)
				{
					ClientActivities c3 = new ClientActivities();
				//rdc 08042010	
						c3.setDefinition("Discount Charge");
						c3.setRef("");
						if(category.equalsIgnoreCase("9")&&(type.equalsIgnoreCase("2")||type.equalsIgnoreCase("3")||type.equalsIgnoreCase("4"))){
						}
						else{
							c3.setReceivables(0.00);
						}					
						if(category.equalsIgnoreCase("2") 		
						   ||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")
						   ||category.equalsIgnoreCase("9")){
						   	if (category.equalsIgnoreCase("9")) dcCollected+=amount2;
							if (category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")){ 
								if (amount2>0) {
									c3.setReserves(-1*amount2);
								} else {
									c3.setReserves(amount2);
								}
								reserves-=(amount2);
								fiuTransaction+=amount2;
								c3.setFiuTransaction(amount2); 
								if (category.equalsIgnoreCase("2")) {
									discountCharges=amount2;
									dcCollected+=amount2;
								}
							} else {
								c3.setReserves(-1*discountValue);
								log.info("reserves before adding discount charges: "+reserves);
								reserves+=(-1*discountValue);
								log.info("reserves before adding discount charges: "+reserves);
								
								if (!category.equalsIgnoreCase("9")) {
									c3.setFiuTransaction(discountValue);
									fiuTransaction+=discountValue;
									fiuBalance+=discountValue;
								} else {
									c3.setFiuTransaction(0.00);
								}
							}
							
						}
						else{
							c3.setReserves(0.00); 	//rdc07122010
							c3.setFiuTransaction(0.00);
						}
						c3.setFiuBalance(fiuBalance);
						list.add(c3);	
				}
				rset = rs.next();	//08282010
			}
			
			if(!rset){
				//rdc 08092610 ..... 
				Date today = DateHelper.parse(asOfDate);
				Map map3 = new HashMap();
				map3.put("ADVRATIO", advratio/100.00);
				map3.put("BLR", blr/100.00);
				map3.put("DCR", dcr/100.00);
				map3.put("C_CLNTCODE", clientCode);
				map3.put("asOfDate", asOfDate);
				map3.put("today", DateHelper.parse(DateHelper.format(today)));
						
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				dcAccruals= m.doRoundOff(invoiceDAO.getDCAccrual2(map3));
				log.info("dcAccruals:"+dcAccruals );
				ClientActivities c6 = new ClientActivities();
				AccountingMaintenanceService AMS  = AccountingMaintenanceService.getInstance();
				 pastDueInvoices = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(n_penaltyamount),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
				 dcAccruals = dcAccruals+pastDueInvoices;
				//if (withTrans == 1) {
					reserves+=(-1*dcAccruals);
					fiuBalance+=dcAccruals;	//rdc08092010
					if (dcAccruals>0) {
						c6.setReserves(-1*dcAccruals);
					} else {
						c6.setReserves(dcAccruals);
					}
					c6.setFiuBalance(fiuBalance);
					discountCharges=dcAccruals;
				 
				pastDueFR = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(N_INVOICEAMT),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
				/*if(pastDueInvoices!=0){
					ClientActivities c7 = new ClientActivities();	
					c7.setDefinition("Past Due Interest");
					c7.setRef("");
					c7.setTransactionDate(new Date(asOfDate));	
					c7.setReceivables(0.00);
					c7.setFiuTransaction(0.00);	
					c7.setFiuBalance(fiuBalance);
					reserves-=pastDueInvoices;
					c7.setReserves(-1*pastDueInvoices);
					list.add(c7);
				}*/
				c6.setDefinition("Discount Charges - Accrual");
				c6.setRef("");
				c6.setTransactionDate(new Date(asOfDate));	
				c6.setReceivables(0.00);
				c6.setFiuTransaction(0.00);			
				c6.setTotalReceivables(receivables);
				c6.setTotalReserves(reserves);
				c6.setTotalFiuTransaction(fiuTransaction);
				c6.setTotalFiuBalance(fiuBalance);
				c6.setInvoices(invoices);
				c6.setServiceCharges(serviceCharges);
				c6.setAdvances(advances);
				c6.setReceipts(receipts);
				c6.setCreditNotes(creditNotes);
				c6.setRefunds(refunds);
				c6.setDiscountCharges(discountCharges);
				c6.setDcOnCashDelays(dcOnCashDelays);
				c6.setSetupFee(setupFee);
				c6.setDocStamp(docStamp);
				c6.setDcCollected(dcCollected);
				c6.setOverpayment(overpayment);
				c6.setReceiptAdvance(rctAdvance);
				c6.setReceiptRefund(rctRefund);
				c6.setDshnrdChks(dshnrdChks);
				c6.setCnCancelled(cnCancelled);
				c6.setPenaltyCollected(penaltyCollected);
				c6.setPastDueCollected(pastDueInvoices);
				c6.setPastDueFR(pastDueFR);
				c6.setNotarialFee(notarial); //added by CVG as of 04-11-16
				list.add(c6);
				log.info("total in");
				log.info("8-setupFee/dcCollected:" + setupFee + "/" + dcCollected);
				log.info("doc stamp amount: " + docStamp);
				//end 08092010
			}
		}
		catch(Exception e){
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally{			
			try{
				conn.setAutoCommit(true);
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}		
				
	}		


	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/


	public boolean saveClientFIU(String clientCode,double fiuBalance, Map map)
	{		 
		boolean update=false;
		log.info("clientCode "+clientCode);
		log.info("fiu balance "+fiuBalance);
		String sSQL = 	" UPDATE Client SET N_FIU="+fiuBalance+" WHERE C_CLNTCODE='" +clientCode+ "'";						
		log.info("saveClientFIU [args1:" +clientCode+"][debug]: " +sSQL);
		PreparedStatement pstmt=null;
		Connection conn = null;
		conn = new FactorConnection().getConnectionCIF();
		try{
			conn.setAutoCommit(false);
			pstmt = conn.prepareStatement(sSQL);
			update = pstmt.executeUpdate()>0;
			conn.commit();
			Map newData = new HashMap();
			AuditService as = AuditService.getInstance();
			newData = ServiceUtility.removeNulls(map);
			PostDate cn = new PostDate(newData);
			as.addAudit(newData.get("C_USERID").toString(),"U","CLIENT","(Client "+clientCode+") N_FIU="+fiuBalance);			
		}
		catch(Exception e){
			try{
				conn.rollback();
			}
			catch(Exception e1){
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally{
			try{
				conn.setAutoCommit(true);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		return update;		
	}

	public boolean resetFIUTran(String clientCode, Map map)
	{		 
		boolean update=false;		
		String sSQL = 	" UPDATE Client SET N_FIUTRAN=0 WHERE C_CLNTCODE='" +clientCode+ "'";						
		log.info("resetFIUTran (args1:" +clientCode+") " +sSQL);
		PreparedStatement pstmt=null;
		Connection conn = null;
		conn = new FactorConnection().getConnectionCIF();					
		try{
			conn.setAutoCommit(false);
			pstmt = conn.prepareStatement(sSQL);
			update = pstmt.executeUpdate()>0;	
			conn.commit();
			Map newData = new HashMap();
			AuditService as = AuditService.getInstance();
			newData = ServiceUtility.removeNulls(map);
			PostDate cn = new PostDate(newData);
			as.addAudit(newData.get("C_USERID").toString(),"U","CLIENT","(Client "+clientCode+") N_FIUTRAN=0");
				
		}
		catch(Exception e){
			try{
				conn.rollback();
			}
			catch(Exception e1){
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally{
			try{
				conn.setAutoCommit(true);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}		
		return update;		
	}	



	public static String getClientConcentration(CC cc){
		String retValue="";		
		String sSQL = "SELECT     C_CLNTCODE,C_NAME,SUM(N_INVOICEAMT) AS amount, mo "+
		"FROM (SELECT     ISNULL(N_INVOICEAMT,0) AS N_INVOICEAMT, DATENAME(MONTH,ISNULL(D_TRANSACTIONDATE,1)) AS mo, C_CUSTCODE,C_CUSTNAME "+
		"           FROM          ReportInvoice "+
		"           WHERE      (D_TRANSACTIONDATE BETWEEN '01/01/'+CAST(YEAR('"+cc.getAsOfDate()+"') AS NVARCHAR) AND '"+cc.getAsOfDate()+"') " +
		"			  AND (YEAR(D_TRANSACTIONDATE) = YEAR('"+cc.getAsOfDate()+"')) AND (C_CLNTCODE ='"+cc.getClientCode()+"') " +
		"			  AND (C_CUSTCODE = '"+cc.getCustomerCode()+"')  AND (C_BRANCHCODE ='"+cc.getBranchCode()+"') " +
		"			  AND C_STATUS "+cc.getStatus()+") "+
		"  a GROUP BY mo, C_CLNTCODE,C_NAME";

		log.info("getClientConceration]sSQL=> " +sSQL);
		Statement stmt=null;
		ResultSet rs=null;
		Statement stmt2=null;
		ResultSet rs2=null;		
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			double jan=0.00;
			double feb=0.00;
			double mar=0.00;
			double apr=0.00;
			double may=0.00;
			double jun=0.00;
			double jul=0.00;
			double aug=0.00;
			double sep=0.00;
			double oct=0.00;
			double nov=0.00;
			double dec=0.00;
			String month="";
			String customerName="";			
			while(rs.next()){
				month=rs.getString("mo").trim();
				BigDecimal bg = new BigDecimal(rs.getDouble("amount"));
				if(month.equalsIgnoreCase("January")){
					jan=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("February")){
					feb=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("March")){
					mar=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("April")){
					apr=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("May")){
					may=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("June")){
					jun=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("July")){
					jul=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("August")){
					aug=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("September")){
					sep=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("October")){
					oct=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}				
				else if(month.equalsIgnoreCase("November")){
					nov=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}	
				else if(month.equalsIgnoreCase("December")){
					dec=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
			}
			double gross=jan+feb+mar+apr+may+jun+jul+aug+sep+oct+nov+dec;
			//gross = m.doRoundOff(gross);
			retValue=jan+delim+feb+delim+mar+delim+apr+delim+may+delim+jun+delim+jul+delim+aug+delim+sep+delim+oct+delim+nov+delim+dec+delim+gross;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return retValue;
	}


	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	/*
	 * UPDATE 
	 * updateClientMonthEnd
	 * updateClientDailyFIU
	 * getClientActivities
	 * LAST UPDATE: 5/2/2012
	 * */
	public double getClientFIUbyAsOfDate(String clientCode,String asOfDate)
	{	
		List<ClientActivities> list = new ArrayList<ClientActivities>();		
	 	
		String sSQL = "SELECT     * FROM ( " + 	
				"		SELECT	i.C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_INVOICEAMT AS AMOUNT, 0.00 AS AMOUNT2, N_ADVANCEDRATIO AS ADVRATIO, " +
				"				C_INVOICENO AS ref,  0 AS ref2, '1' AS category , 0 as cashDelay , '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,i.N_SVCCHGTYPE as scType " + 
				"				FROM	Invoice i INNER JOIN dbCIF.dbo.CLIENT c ON i.C_CLNTCODE = c.C_CLNTCODE " +
				"				WHERE i.C_STATUS IN('2','3','4','5','6')" +
				" 				AND (i.C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"				CAST(N_REFNO AS NVARCHAR) AS REF, c_debit AS REF2,'1a' AS CATEGORY , 0 AS CASHDELAY, C_ADJREC+C_ADJRES+C_ADJFIU+C_ADJFIUBAL+a2.C_ADJDESC AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +   
				"				FROM ADJUSTMENT a INNER JOIN ADJUSTMENTTYPE a2 ON a.C_ADJCODE = a2.C_ADJCODE " +
				"				WHERE C_STATUS = '2'AND B_INCLUDED = 1 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
		/*	"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "+  
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2b' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +  
		        "    				FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4)  AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0  "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
		        "  					 + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')"+
				"				UNION "+
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO,   "+
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2c' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +  
				"					FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
				"   				+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
				"				UNION"	+
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG2 AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE ISNULL(N_DISCCHG2,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				//added by CVg as of 03-16-16
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_NOTARIAL AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2d' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE ISNULL(N_NOTARIAL,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				//end  */
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE     C_TYPE = 2 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM	Advances WHERE     C_TYPE = 3 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '4' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND (C_STATUS IN (1,2,4))   " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '5' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 2 AND (C_STATUS IN (1,2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT a.C_CLNTCODE, a.C_CUSTCODE,  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101)AS D_TRANSACTIONDATE, AMOUNT,AMOUNT2, ADVRATIO, " +
				"				REF, REF2,CATEGORY , CASHDELAY, TYPE,AMOUNT1,OVERPAYMENT,dcPayment, penaltyPayment ,'' as scType  FROM ( " +
				"			SELECT rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,rdinv.D_TRANSACTIONDATE,D_FULLYPAIDDATE, ISNULL(SUM(N_RECEIPTAMT),0) AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(rd2.N_REFNO  AS NVARCHAR) AS REF, rh2.C_RECEIPTTYPE AS REF2,'5A' AS CATEGORY , 0 AS CASHDELAY, '' AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"				FROM RECEIPTSDTL rd2 INNER JOIN( " +
				"			SELECT DISTINCT rh.C_CLNTCODE, rh.C_CUSTCODE,rd.C_INVOICENO,rd.N_INVNO,rh.D_TRANSACTIONDATE,D_FULLYPAIDDATE FROM RECEIPTSDTL rd " + 
				"				INNER JOIN ( " + 
				"			SELECT	C_CLNTCODE, C_CUSTCODE,CAST(N_REFNO AS NVARCHAR) AS REF, D_TRANSACTIONDATE " +
				"				FROM	RECEIPTSHDR WHERE     C_RECEIPTTYPE IN (1,2,3,4) AND (C_STATUS IN (2,4)) " + 
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"				) AS rh ON rd.N_REFNO = rh.REF " +
				"				INNER JOIN INVOICE inv ON rd.C_INVOICENO = inv.C_INVOICENO and rd.N_INVNO = inv.N_INVNO " + 
				"				AND inv.C_STATUS IN (5,6) " +  
				"				) AS rdinv ON rd2.C_INVOICENO = rdinv.C_INVOICENO  AND rd2.N_INVNO = rdinv.N_INVNO " +
				"				INNER JOIN  RECEIPTSHDR rh2 ON rd2.N_REFNO=rh2.N_REFNO AND rh2.C_RECEIPTTYPE IN (3,4)  AND rh2.C_STATUS in (2,4)" +
				"				GROUP BY rh2.C_RECEIPTTYPE,rd2.N_REFNO,rdinv.D_TRANSACTIONDATE,rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,D_FULLYPAIDDATE " +
				"		) a where  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101) =  CONVERT(VARCHAR(10), a.D_FULLYPAIDDATE, 101) " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2,  0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, C_STATUS ref2, '6' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 3 AND (C_STATUS IN (2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref,C_STATUS  AS ref2, '6a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 4 AND (C_STATUS IN (2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"      SELECT	cn.C_CLNTCODE, cn.C_CUSTCODE, cn.D_TRANSACTIONDATE, cn.N_AMOUNT AS AMOUNT,  0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(cn.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '6b' AS category , 0 as cashDelay, '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +  
				"			FROM	CreditNote cn INNER JOIN RECEIPTSHDR rh ON cn.C_RECEIPTNO = rh.N_REFNO " +
				"			WHERE cn.C_STATUS IN(1,2) AND rh.C_STATUS <> 3 " +
				" 				AND (cn.C_CLNTCODE ='" + clientCode + "') AND (cn.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				/*//Add Discount Charge and Penalty 
				//7d for Discount Charge
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7d' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
				"                   FROM	ReceiptsHdr WHERE   " +
				" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +		
				//7e for Penalty
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7e' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
				"                   FROM	ReceiptsHdr WHERE   " +
				" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				*/
				"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  c.D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a2' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
				"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
				" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (c.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"    SELECT	C_CLNTCODE, C_CUSTCODE,  (CASE WHEN D_DATEBOUNCED IS NOT NULL THEN D_DATEBOUNCED ELSE D_TRANSACTIONDATE END) AS D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7b' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment,'' as scType " + 
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  (CASE WHEN D_CANCELLEDDATE IS NOT NULL THEN D_CANCELLEDDATE ELSE D_DATEBOUNCED END) as D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7c' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " + 
				"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
				"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
				" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"    SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_REFAMT AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9' AS category , 0 as cashDelay, C_TYPE AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " + 
				"                   FROM	Refund WHERE  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"			union"+
				"	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "   +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9a' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +     
		        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) "+   
		        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
		        "			UNION "+	
		        "	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, "+  
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9b' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +     
		        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)"+   
		        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
		        "			UNION "+	
		    	"	SELECT C_CLNTCODE,0 C_CUSTCODE ,date_tagged_RMU D_TRANSACTIONDATE, ISNULL(amount_reversed,0) AS AMOUNT, 0 AS AMOUNT2, 0.0 AS ADVRATIO,'CR' as ref, 0 as ref2, 'client' AS category, 0 as cashDelay,'' as type,0 as Amount1, 0 as overPayment, 0 as dcPayment, 0 as penaltyPayment,'' as scType	"+
		   	 	"	FROM dbcif..Client where is_RMU = 1 and C_CLNTCODE ='" + clientCode + "' and (date_tagged_RMU BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)	"+ 
		        "           			 +'/01/'+  CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')	"+ 
		        "	) a " +
		        //Replace the order by fields (Previously D_TRANSACTIONDATE,catefory,ref asc)
				"	ORDER BY D_TRANSACTIONDATE,category,ref asc ";		
					log.info(" getClientActivities [args1:" +clientCode+"][debug]: " +sSQL);
					
					Statement stmt=null;
					ResultSet rs=null;
					double fiuBalance=0.00;
					try{
						stmt = new FactorConnection().getConnection().createStatement();
						rs = stmt.executeQuery(sSQL);
				

						double dcr=0.00;
						double scr=0.00;
						double blr = 0.00;
						String blrCode="";
						int day=0;
						int cashDelay=0;
						String custCode="";
						String customerName="";

						double serviceValue=0.00;
						double discountValue=0.00;
						double dcCashDelayValue=0.00;

						//Totals
						double receivables=0.00;
						double reserves=0.00;
						double fiuTransaction=0.00;
						//double fiuBalance=0.00;

						double invoices=0.00;
						double advances=0.00;
						double receipts=0.00;
						double serviceCharges=0.00;			
						double discountCharges=0.00;
						double dcOnCashDelays=0.00;
						double creditNotes=0.00;
						double refunds=0.00;
						double setupFee=0.00;
						double docStamp=0.00;
						double dcCollected=0.00;
						double dcAccruals=0.00;
						double advratio=0.00;
						double iniVal=0.00;
						int withTrans = 0;
						double lastAccruals = 0.00;
						double overpayment = 0.00;
						double rctAdvance = 0.00;
						double rctRefund = 0.00;
						double dshnrdChks = 0.00;
						double cnCancelled = 0.00;
						String type="";
						String branchCode="";
						
						double pastDueInvoices = 0.00;
						double pastDueCollected = 0.00;
						double penaltyCollected = 0.00;
						double pastDueFR = 0.00;
						
						double balance=0.00;

						//added by CVG as of 04-11-2016
						double notarial = 0.00;
						boolean is_rmu = false;
						ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
						while(clientList.hasNext()){
							ClientActivities header = new ClientActivities();
							Client client = (Client)clientList.next();
						//p	header.setClient(client);
						//p	header.setClientCode(clientCode);
							dcr=m.doRoundOff(client.getN_Dcr());
							scr=m.doRoundOff(client.getN_Scr());
							advratio =m.doRoundOff(client.getN_AdvRatio());
							branchCode = client.getC_BranchCode();	//rdc08132010
					//p		blrCode = client.getC_BlrTypeCode();
							BLRFileDAO blrDao = new BLRFileDAO();
							BLRService blrService = BLRService.getInstance();
							//ListIterator<BLRFile> blrFileList = blrDao.getBLRFile(clientCode, asOfDate).listIterator();
							Map blrData = new HashMap();
							blrData.put("topCount", 3);
							blrData.put("clntCode", clientCode);
							ListIterator<BLR> blrFileList = blrService.readBLRGeneric(blrData).listIterator();						
							while(blrFileList.hasNext()){
								BLR blrFile = (BLR) blrFileList.next();
						//p		log.info("BLR: "+blrFile.getN_blr());
						//p		log.info("Effectivity Date: "+blrFile.getD_effDt());
						//p		log.info("Expiry Date: "+blrFile.getD_expDt());
								blr = m.doRoundOff(blrFile.getN_blr());
						//p		log.info("blrFile.getBlr()"+blrFile.getN_blr());
						//p		header.setBlrFile(blrFile);
								break;								

							}
							log.info("advratio: "+advratio);
							String strMMM = DateUtils.getLastMonthMMM(asOfDate);//RLS 01/07/2011 add method in getting prefix of month (MMM) DateUtils.getLastMonthMMM(asOfDate)
							strMMM = "N_" + strMMM +"ACC";
							is_rmu = client.isIs_rmu();
							Map map2 = new HashMap();
							map2.put("C_CLNTCODE", clientCode);
							map2.put("MMM", strMMM);		
							INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
							dcAccruals= m.doRoundOff(invoiceDAO.getLastAccrual(map2));
							log.info("dcAccruals:"+dcAccruals );
				
							MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
							ListIterator mbList =mbDAO.getMonthBalClntCodeAsOfDate(clientCode,asOfDate).listIterator();						
							while(mbList.hasNext()){
				
								MonthlyBalances mb = (MonthlyBalances)mbList.next();
						//p		header.setTransactionDate(DateHelper.getDateInFirstDay(asOfDate));
						//p		header.setStartDate(DateHelper.getDateInFirstDay(asOfDate));
						//p		header.setDefinition("Balance B/F");
						//p		header.setRef("");
								//header.setReceivables(mb.getMonthReceivables().doubleValue());
						//p		header.setReceivables(m.doRoundOff(mb.getMonthReceivables().doubleValue()));
								//header.setReserves(mb.getMonthReserves().doubleValue());
						//p		header.setReserves(m.doRoundOff(mb.getMonthReserves().doubleValue()));
								//header.setFiuBalance(mb.getMonthFIU().doubleValue());
								if (m.doRoundOff(mb.getMonthFIU().doubleValue())>iniVal) {	//rdc 08102010
									fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue() + dcAccruals );//header.getFiuTransaction()s;		
							//p		header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
								} else {
									if ((m.doRoundOff(mb.getMonthFIU().doubleValue())==iniVal) && dcAccruals>0){
										fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue()+dcAccruals);//header.getFiuTransaction();
							//p			header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
									}else{
										fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue());//header.getFiuTransaction();
							//p			header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue()));
									}
								}
								//header.setFiuTransaction(mb.getMonthFIU().doubleValue());
							//p	header.setFiuTransaction(m.doRoundOff(mb.getMonthFIU().doubleValue()));
							//p	receivables=header.getReceivables();
							//p	reserves=header.getReserves();
							//p	fiuTransaction=header.getFiuTransaction();
								
								if((dcAccruals>0.00) && (fiuTransaction==0.00)){
									balance=header.getFiuTransaction()+dcAccruals;
								}else{
								
									balance=header.getFiuTransaction();
								} 
												
								
								break;
							}
							list.add(header);
							break;				
						}
						
						ClientActivities disc = new ClientActivities();
						disc.setDefinition("Last Month's DC Accrual");
						disc.setRef("");
						disc.setReceivables(0.00);			
						
						log.info("reserves before adding discount in balance bf "+reserves);
						if ((fiuTransaction>iniVal)||(reserves>iniVal)||receivables>iniVal) {
							
							if((dcAccruals>0.00) && (fiuTransaction==0.00)){
								fiuBalance=balance-dcAccruals;
							}else{
							    fiuBalance-=dcAccruals;
							}
				//p			reserves+=dcAccruals;
				//p			disc.setReserves(dcAccruals);
						} else {
							disc.setReserves(0.00);
						}
						log.info("reserves after adding discount in balance bf "+reserves);
				//p		disc.setFiuTransaction(0.00);
				//p		disc.setFiuBalance(fiuBalance);	
						dcAccruals=0.00;
						list.add(disc);	
						boolean rset = rs.next();	
						String ref = "";
						while(rset){
							log.info("receipts"+receipts);
							type=rs.getString("type");
							double amount =m.doRoundOff(rs.getDouble("AMOUNT")); 
							double amount1=m.doRoundOff(rs.getDouble("amount1"));
							double amount2 =m.doRoundOff(rs.getDouble("AMOUNT2"));	//rdc07152010
							double opmt = m.doRoundOff(rs.getDouble("overPayment"));
							//added 6/28/2016 for receipts dc and penalty
							double dcPayment = m.doRoundOff(rs.getDouble("dcPayment"));
						//p	double penaltyPayment = m.doRoundOff(rs.getDouble("penaltyPayment"));
						//p	String scType = rs.getString("scType")!=null? rs.getString("scType"):"2"; //cvg 02132017
							String ref2 = rs.getString("ref2").trim();	//rdc07152010
							String date1 = sdf.format(rs.getDate("D_TRANSACTIONDATE"));				
							String category = rs.getString("category").trim();
							if (date1.equals(asOfDate)) {
								day = 1;
							} else {
								day = DateHelper.getDayPerTransaction(date1, asOfDate);
							}	
							cashDelay = rs.getInt("cashDelay");
							log.info("Day: "+day);
							log.info("Category "+category);
							ClientActivities c = new ClientActivities();				
							c.setRef(rs.getString("ref"));
							c.setTransactionDate(rs.getDate("D_TRANSACTIONDATE"));				
							if(category.equalsIgnoreCase("1")){
								fiuBalance+=m.doRoundOff(amount*(advratio/100));
				//p				c.setDefinition("Invoice");
				//p				c.setReceivables(amount);
				//p				receivables+=amount;
				//p				c.setReserves(amount);
				//p				reserves+=amount;
				//p				c.setFiuTransaction(0.00);
				//p				c.setFiuBalance(fiuBalance);
				//p				invoices+=amount;	
								list.add(c);
				
			/*p					ClientActivities c2 = new ClientActivities();
								c2.setDefinition("Service Charge");
								c2.setRef("");
								c2.setReceivables(0.00);
								
								if (scType.equals("1")){ //added cvg02132017
									serviceValue=m.doRoundOff(amount*(scr/100)*(advratio/100));
								}else if (scType.equals("2")){
									serviceValue=m.doRoundOff(amount*(scr/100)); //old
								}//end
						
								reserves-=serviceValue;
								c2.setReserves(-1*serviceValue);						
								fiuTransaction+=serviceValue;
								c2.setFiuTransaction(serviceValue); 
								c2.setFiuBalance(fiuBalance);
								serviceCharges+=serviceValue;
								list.add(c2);   p*/
				
							}
							else if(category.equalsIgnoreCase("1a")){
								String strTypeRec =  type.substring(0, 1);
								String strTypeRes = type.substring(1, 2);
								String strTypeFiu = type.substring(2, 3);
								String strTypeFiuBal = type.substring(3, 4);
								String strDesc = type.substring(4);
								
								if (ref2.equals("1")){
									dcCollected+=amount;
								} else {
									dcCollected-=amount;
								}
								
					/*p			//effect on receivables
								if (strTypeRec.equals("1")) {
									receivables+=amount;
									c.setReceivables(amount);
								} else if (strTypeRec.equals("2")) {
									receivables-=amount;
									c.setReceivables(-1*amount);
								} else {
									c.setReceivables(0.00);
								}
								//effect on reserves
								if (strTypeRes.equals("1")) {
									reserves+=amount;
									c.setReserves(amount);
								} else if (strTypeRes.equals("2")) {
									reserves-=amount;
									c.setReserves(-1*amount);
								} else {
									c.setReserves(0.00);
								}
								//effect on fiu
								if (strTypeFiu.equals("1")) {
									fiuTransaction+=amount;
									c.setFiuTransaction(amount);
								} else if (strTypeFiu.equals("2")) {
									fiuTransaction-=amount;
									c.setFiuTransaction(-1*amount);
								} else {
									c.setFiuTransaction(0.00);
								}  p*/
								//effect on fiu balance
								if (strTypeFiuBal.equals("1")) {
									fiuBalance+=amount;
								} else if (strTypeFiuBal.equals("2")) {
									fiuBalance-=amount;
								}
								c.setFiuBalance(fiuBalance);
								c.setDefinition(strDesc);			
								list.add(c);
							}else if(category.equalsIgnoreCase("client")){
								//c.setDefinition("Client Reversal");
								//c.setReceivables(0.0);
								//reserves-=amount;
								//c.setReserves(-1*amount);
								//c.setFiuTransaction(amount);
								//fiuTransaction +=amount;
								//fiuBalance +=amount;
								//c.setFiuBalance(fiuBalance);
								//list.add(c);	
							}
							else if(category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")/*p||category.equalsIgnoreCase("2a")||category.equalsIgnoreCase("2c")||category.equalsIgnoreCase("2d")*/){					
								if(category.equalsIgnoreCase("2"))c.setDefinition("Advances");
								if(category.equalsIgnoreCase("3"))c.setDefinition("Setting-up Fee");
								if(category.equalsIgnoreCase("3a"))c.setDefinition("Advances - Unfactored");
						/*p		if(category.equalsIgnoreCase("2a"))c.setDefinition("Doc Stamp");
								if(category.equalsIgnoreCase("2b"))c.setDefinition("Penalty Charge");
								if(category.equalsIgnoreCase("2c"))c.setDefinition("PD - Discount Charge");
								if(category.equalsIgnoreCase("2d"))c.setDefinition("Notarial Fee"); //added by CVG as of 04-11-16   
								//08042010
								c.setReceivables(0.00);
								reserves-=amount;
								c.setReserves(-1*amount);
								fiuTransaction+=amount;
								c.setFiuTransaction(amount);
								c.setFiuBalance(fiuBalance); p*/
								if(category.equalsIgnoreCase("2")) advances+=amount;			
								list.add(c);
								if(category.equalsIgnoreCase("2")) {
									discountValue=m.doRoundOff(getDiscountCharge(amount2,blr,dcr,day));
									try{
										Statement s = null;
										ResultSet r = null;
										
										s= new FactorConnection().getConnection().createStatement();
										String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
										"on rh.N_REFNO=rd.N_REFNO inner join Advances adv on	"+
										"adv.N_REFNO=rh.n_advpaymentno inner join "+
										"Invoice inv on rd.N_INVNO=inv.n_invno	"+
										"where rh.C_CLNTCODE='"+clientCode+"' and adv.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
										r= s.executeQuery(query);
										
										if(r.next()){
											double val = r.getDouble("amount")*((100-advratio)/100);
											if(val!=0){
												ClientActivities op = new ClientActivities();
												op.setDefinition("CN Adjustment From Advance");
												op.setRef("");
												op.setReceivables(0.00);
												op.setReserves(0.00);
												op.setFiuTransaction(val);
												fiuTransaction +=val;
												fiuBalance +=val;
												op.setFiuBalance(fiuBalance);
												list.add(op);
											}
										}
								/*p		if(penaltyPayment!=0){
											ClientActivities penaltyPaymentCA = new ClientActivities();
											penaltyPaymentCA.setDefinition("Penalty Charge");
											penaltyPaymentCA.setReceivables(0.00);
											reserves-=penaltyPayment;
											penaltyPaymentCA.setReserves(-1*penaltyPayment);
											fiuTransaction+=penaltyPayment;
											penaltyPaymentCA.setFiuTransaction(penaltyPayment);
											penaltyPaymentCA.setFiuBalance(fiuBalance);
											penaltyPaymentCA.setTransactionDate(null);
											penaltyPaymentCA.setRef(null);
											penaltyCollected += penaltyPayment ;
											list.add(penaltyPaymentCA);
										} p*/
										
										}
										catch(Exception e){
											e.printStackTrace();
										}	
								} else if(category.equalsIgnoreCase("3")) {
										setupFee = amount;
										/*discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,1));	
										dcCollected+=discountValue;*/
								} else if(category.equalsIgnoreCase("3a")) {
									discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,day));
								} else if(category.equalsIgnoreCase("2a")){
									c.setTransactionDate(null);
									c.setRef(null);
									docStamp =  amount; 
								}
						/*p		 else if(category.equalsIgnoreCase("2b")){
									 c.setTransactionDate(null);
									 c.setRef(null);
									 penaltyCollected += amount ;
								 }
								 else if(category.equalsIgnoreCase("2c")){
									 pastDueCollected += amount;
									 c.setTransactionDate(null);
									 c.setRef(null);
								 }
								//added by CVG as of 04-11-16
								 else if(category.equalsIgnoreCase("2d")){
									 pastDueCollected += amount;
									 c.setTransactionDate(null);
									 c.setRef(null);
									 notarial =  amount; 
								 }// end   p*/
								withTrans = 1; 
								
						}		
				
							else if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("5")||category.equalsIgnoreCase("7a")||category.equalsIgnoreCase("7a")){
							/*	if(category.equalsIgnoreCase("7d")){
									c.setDefinition("Discount Charge");
									c.setReceivables(0.00);
									reserves-=amount;
									c.setReserves(-1*amount);
									fiuTransaction+=amount;
									c.setFiuTransaction(amount);
									c.setFiuBalance(fiuBalance);
									list.add(c);
								}
								else{*/
									log.info("Receipts cat4 and 5 here....");
									if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
										custCode=rs.getString("C_CUSTCODE");
										customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
									}					
									if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("7a"))c.setDefinition("RCT-CHK-"+customerName);
									if(category.equalsIgnoreCase("5"))c.setDefinition("RCT-CSH-"+customerName);	
										receivables-=amount-opmt;
										//fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
										
										receipts+=amount;
										c.setReceivables(-1*(amount-opmt));
										//c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
										if(is_rmu){
											c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
											fiuTransaction-=m.doRoundOff((amount-opmt));
											fiuBalance-=m.doRoundOff((amount-opmt));	//rdc08092010
										}else{
											c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
											fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
											fiuBalance-=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
										}
									log.info("amount: "+amount);
									log.info("amount1: "+amount1);
									amount=(amount1<amount)?amount1:amount;
									log.info("amount to be computed for discount: "+amount);
									discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
									c.setReserves(0.00);
									c.setFiuBalance(fiuBalance);
									list.add(c);
										if(opmt!=0){	
											ClientActivities op = new ClientActivities();
											op.setDefinition("Over Payment");
											op.setRef("");
											op.setReceivables(0.00);
											overpayment+=opmt;
											op.setReserves(opmt);
											reserves+=opmt;
											op.setFiuTransaction(0.00);
											op.setFiuBalance(fiuBalance);
											list.add(op);							
										}
										if(dcPayment!=0){
											ClientActivities dc = new ClientActivities();
											dc.setTransactionDate(null);
											dc.setDefinition("Discount Charge");
											dc.setReceivables(0.00);
											reserves-=dcPayment;
											dc.setReserves(-1*dcPayment);
											//fiuTransaction+=dcPayment;
											dc.setFiuTransaction(0.00);
											dc.setFiuBalance(fiuBalance);
											dcCollected += dcPayment;
											list.add(dc);
										}
										
							/*p			if(penaltyPayment !=0){
											ClientActivities pc = new ClientActivities();
											pc.setTransactionDate(null);
											pc.setDefinition("Penalty Charge");
											pc.setReceivables(0.00);
											reserves-=penaltyPayment;
											pc.setReserves(-1*penaltyPayment);
											//fiuTransaction+=penaltyPayment;
											pc.setFiuTransaction(0.00);
											pc.setFiuBalance(fiuBalance);
											penaltyCollected += penaltyPayment;
											list.add(pc);
										} p */
										//Unfactored Invoice
										ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
										Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
										if(unfactoredAmount !=0){
											ClientActivities ua = new ClientActivities();
											ua.setTransactionDate(null);
											ua.setDefinition("Unfactored Invoices");
											ua.setReceivables(0.00);
											reserves-=unfactoredAmount;
											ua.setReserves(-1*unfactoredAmount);
											//fiuTransaction+=penaltyPayment;
											ua.setFiuTransaction(0.00);
											ua.setFiuBalance(fiuBalance);
											//penaltyCollected += penaltyPayment;
											list.add(ua);
										}
										//Discount Charge
										Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
										if(dcAmount !=0){
											ClientActivities ua = new ClientActivities();
											ua.setTransactionDate(null);
											ua.setDefinition("RMU Discount Charge");
											ua.setReceivables(dcAmount);
											receivables += dcAmount;
											//reserves-=dcAmount;
											//ua.setReserves(-1*dcAmount);
											ua.setReserves(0);
											fiuTransaction+=dcAmount;
											fiuBalance += dcAmount;
											ua.setFiuTransaction(0.00);
											ua.setFiuBalance(fiuBalance);
											//penaltyCollected += penaltyPayment;
											list.add(ua);
										}
										//Penalty
										Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
										if(penaltyAmount !=0){
											ClientActivities ua = new ClientActivities();
											ua.setTransactionDate(null);
											ua.setDefinition("RMU Penalty Charge");
											ua.setReceivables(penaltyAmount);
											receivables += penaltyAmount;
											//reserves-=penaltyAmount;
											//ua.setReserves(-1*penaltyAmount);
											ua.setReserves(0);
											fiuTransaction+=penaltyAmount;
											fiuBalance += penaltyAmount;
											ua.setFiuTransaction(penaltyAmount);
											ua.setFiuBalance(fiuBalance);
											//penaltyCollected += penaltyPayment;
											list.add(ua);
										}
										
								//}
							}
							else if(category.equalsIgnoreCase("5a")){
								ClientActivities pp = new ClientActivities();
								if(ref2.contentEquals("3")||ref2.contentEquals("4"))
								{
											/*if(ref2.contentEquals("3")){
												pp.setDefinition("CN Adjustment from Advance");
											}
											else if(ref2.contentEquals("4")){
												pp.setDefinition("CN Adjustment from Refund");
											}*/
								}
								else{
									pp.setDefinition("Previous Partial Payment");
								//pp.setRef(rs.getString("ref"));
								pp.setReceivables(0.00);
								pp.setReserves(0.00);
								fiuTransaction+=amount*m.doRoundOff((100-advratio)/100);
								pp.setFiuTransaction(amount*m.doRoundOff((100-advratio)/100));	
								fiuBalance+=amount*m.doRoundOff((100-advratio)/100);
								pp.setFiuBalance(fiuBalance);
								list.add(pp);}
							}
				
							else if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")||category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
								log.info("RCT-ADV and RCT-REF here....");
								if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
									if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
										custCode=rs.getString("C_CUSTCODE");
										customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
									}							
									if(category.equalsIgnoreCase("6")){
										c.setDefinition("RCT-ADV-"+customerName);
										rctAdvance+=amount;
									}
									if(category.equalsIgnoreCase("6a")){
										c.setDefinition("RCT-REF-"+customerName);
										rctRefund+=amount;
									}
								
								}
								if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
									if(is_rmu){
										c.setDefinition("RMU Credit Note");
									}else
										c.setDefinition("Credit Note");
									creditNotes+=amount;
								}
								receivables-=amount-opmt;
								c.setReceivables(-1*(amount-opmt));
								
								
								if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")) {
									c.setReserves(0.00);
									if(rs.getString("ref2").equalsIgnoreCase("2")){
										fiuTransaction-=(amount*(advratio/100))-opmt;
										c.setFiuTransaction(-1*((amount*(advratio/100))-opmt));
										fiuBalance-=(amount*(advratio/100))-opmt;
									}else{
										fiuTransaction-=amount-opmt;
										c.setFiuTransaction(-1*(amount-opmt));
										fiuBalance-=amount-opmt;
									}
									 
									
								} else {
									if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
										if(is_rmu){
											reserves-=amount;
											c.setReserves(-1*amount);
											//fiuTransaction-=m.doRoundOff(amount*(advratio/100));
											c.setFiuTransaction(0);
											//fiuBalance-=m.doRoundOff(amount*(advratio/100));
										}else{
											reserves-=amount;
											c.setReserves(-1*amount);
											fiuTransaction-=m.doRoundOff(amount*(advratio/100));
											c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
											fiuBalance-=m.doRoundOff(amount*(advratio/100));
										}
										
									}else{
										reserves-=amount;
										c.setReserves(-1*amount);
										fiuTransaction-=m.doRoundOff(amount*(advratio/100));
										c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
										fiuBalance-=m.doRoundOff(amount*(advratio/100));
									}
								}	
								c.setFiuBalance(fiuBalance);
								log.info("amount: "+amount);
								log.info("amount1: "+amount1);
								amount=(amount1<amount)?amount1:amount;
								log.info("amount to be computed for discount: "+amount);
								//discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
								if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
									if(opmt!=0){	
										ClientActivities op = new ClientActivities();
										op.setDefinition("Over Payment");
										op.setRef("");
										op.setReceivables(0.00);
										overpayment+=opmt;
										op.setReserves(opmt);
										reserves+=opmt;
										op.setFiuTransaction(0.00);
										op.setFiuBalance(fiuBalance);
										list.add(op);							
									}
									
									
									
								}						
								list.add(c);
								/*if(category.equalsIgnoreCase("6")&&!rs.getString("ref2").contentEquals("0")){
									try{
										Statement s = null;
										ResultSet r = null;
										s = new FactorConnection().getConnection().createStatement();
										String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
										log.info(sql);
										r = s.executeQuery(sql);
										if(r.next()){
											if(r.getDouble("partialAmount")!=0){
												ClientActivities op = new ClientActivities();
												op.setDefinition("CE Adjustment From RCT-ADV (Partial Payment)");
												op.setRef("");
												op.setReceivables(0.0);
												double partial = amount *((100-advratio)/100);
												op.setReserves(-partial);
												reserves -= partial;
												op.setFiuTransaction(partial);
												fiuTransaction+=partial;
												fiuBalance+=partial;
												op.setFiuBalance(fiuBalance);
												list.add(op);
												
											}
										}
										
									}catch(Exception e){
										e.printStackTrace();
									}
								}
							else if(category.equalsIgnoreCase("6a")&&!rs.getString("ref2").contentEquals("0")){
								try{
									Statement s = null;
									ResultSet r = null;
									s = new FactorConnection().getConnection().createStatement();
									String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
									log.info(sql);
									r = s.executeQuery(sql);
									if(r.next()){
										if(r.getDouble("partialAmount")!=0){
											ClientActivities op = new ClientActivities();
											op.setDefinition("CE Adjustment From RCT-REF (Partial Payment)");
											op.setRef("");
											op.setReceivables(0.0);
											double partial = amount *((100-advratio)/100);
											op.setReserves(-partial);
											reserves -= partial;
											op.setFiuTransaction(partial);
											fiuTransaction+=partial;
											fiuBalance+=partial;
											op.setFiuBalance(fiuBalance);
											list.add(op);
											
										}
									}
									
								}catch(Exception e){
									e.printStackTrace();
								}
							}*/
							}
							else if(category.equalsIgnoreCase("7b")){
								c.setDefinition("Dishonored Check");
								c.setReserves(0.00);					
								receivables+=amount-opmt;
								dshnrdChks+=amount-opmt;
								//fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
								//fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
								if(is_rmu){
									c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
									fiuTransaction+=m.doRoundOff((amount-opmt));
									fiuBalance+=m.doRoundOff((amount-opmt));	//rdc08092010
								}else{
									c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
									fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
									fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
								}
								c.setReceivables(amount-opmt);
								c.setFiuTransaction(m.doRoundOff((amount-opmt)*(advratio/100)));
								c.setFiuBalance(fiuBalance);
								list.add(c);
								if(opmt!=0){	
									ClientActivities op = new ClientActivities();
									op.setDefinition("Reversal of OP");
									op.setRef("");
									op.setReceivables(0.00);
									op.setReserves(-1*opmt);
									reserves-=opmt;
									op.setFiuTransaction(0.00);
									op.setFiuBalance(fiuBalance);
									list.add(op);							
								}
								if(dcPayment!=0){
									ClientActivities dc = new ClientActivities();
									dc.setTransactionDate(null);
									dc.setDefinition("Reversal Discount Charge");
									dc.setReceivables(0.00);
									reserves+=dcPayment;
									dc.setReserves(1*dcPayment);
									//fiuTransaction-=dcPayment;
									dc.setFiuTransaction(0.00);
									dc.setFiuBalance(fiuBalance);
									dcCollected -= dcPayment;
									list.add(dc);
								}
								
					/*p			if(penaltyPayment !=0){
									ClientActivities pc = new ClientActivities();
									pc.setTransactionDate(null);
									pc.setDefinition("Reversal Penalty Charge");
									pc.setReceivables(0.00);
									reserves+=penaltyPayment;
									pc.setReserves(1*penaltyPayment);
									//fiuTransaction-=penaltyPayment;
									pc.setFiuTransaction(0.00);
									pc.setFiuBalance(fiuBalance);
									penaltyCollected -= penaltyPayment;
									list.add(pc);
								}  p */
								//Unfactored Invoice
								ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
								Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
								if(unfactoredAmount !=0){
									ClientActivities ua = new ClientActivities();
									ua.setTransactionDate(null);
									ua.setDefinition("Reversal Unfactored Invoices");
									ua.setReceivables(0.00);
									reserves+=unfactoredAmount;
									ua.setReserves(1*unfactoredAmount);
									//fiuTransaction+=penaltyPayment;
									ua.setFiuTransaction(0.00);
									ua.setFiuBalance(fiuBalance);
									//penaltyCollected += penaltyPayment;
									list.add(ua);
								}
								//Discount Charge
								Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
								if(dcAmount !=0){
									ClientActivities ua = new ClientActivities();
									ua.setTransactionDate(null);
									ua.setDefinition("Reversal RMU Discount Charge");
									ua.setReceivables(-1*dcAmount);
									receivables -= dcAmount;
									//reserves-=dcAmount;
									//ua.setReserves(-1*dcAmount);
									ua.setReserves(0);
									fiuTransaction-=dcAmount;
									fiuBalance -= dcAmount;
									ua.setFiuTransaction(-1*dcAmount);
									ua.setFiuBalance(fiuBalance);
									//penaltyCollected += penaltyPayment;
									list.add(ua);
								}
								//Penalty
								Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
								if(penaltyAmount !=0){
									ClientActivities ua = new ClientActivities();
									ua.setTransactionDate(null);
									ua.setDefinition("Reversal RMU Penalty Charge");
									ua.setReceivables(-1*penaltyAmount);
									receivables -= penaltyAmount;
									//reserves-=penaltyAmount;
									//ua.setReserves(-1*penaltyAmount);
									ua.setReserves(0);
									fiuTransaction-=penaltyAmount;
									fiuBalance -= penaltyAmount;
									ua.setFiuTransaction(-1*penaltyAmount);
									ua.setFiuBalance(fiuBalance);
									//penaltyCollected += penaltyPayment;
									list.add(ua);
								}
//								if (amount2 !=0){
//									ClientActivities receiptDCReversal = new ClientActivities();
//									receiptDCReversal.setDefinition("Reversal of DC-Receipt");
//									receiptDCReversal.setRef("");
//									receiptDCReversal.setReceivables(0.00);
//									receiptDCReversal.setReserves(-1*amount2);
//									reserves-=amount2;
//									receiptDCReversal.setFiuTransaction(0.00);
//									receiptDCReversal.setFiuBalance(fiuBalance);
//									list.add(receiptDCReversal);
//								}
								
								
							}
							else if(category.equalsIgnoreCase("7c")){
								c.setDefinition("Cancelled CN");
								receivables+=amount-opmt;
								cnCancelled+=amount;
								c.setReceivables(amount-opmt);
								reserves+=amount;
								c.setReserves(amount);
								fiuTransaction+=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(m.doRoundOff(amount*(advratio/100)));
								fiuBalance+=m.doRoundOff(amount*(advratio/100));
								c.setFiuBalance(fiuBalance);
								list.add(c);
							}
							else if(category.equalsIgnoreCase("9")){
								
								//if(category.equalsIgnoreCase("9a"))c.setDefinition("Penalty Charge");
								//if(category.equalsIgnoreCase("9b"))c.setDefinition("PD - Discount Charge");
								if(type.equalsIgnoreCase("1"))c.setDefinition("Refund");
								if(type.equalsIgnoreCase("2"))c.setDefinition("Refund with Overpayment");
								if(type.equalsIgnoreCase("3"))c.setDefinition("Refund - Unfactored Invoice");
								if(type.equalsIgnoreCase("4"))c.setDefinition("Refund - Prev CN");	
								
								c.setReceivables(0.00);
								reserves-=amount;
								c.setReserves(-1*amount);						
								c.setFiuTransaction(0.00);	
								c.setFiuBalance(fiuBalance);
								if(!category.equalsIgnoreCase("9a")&&!category.equalsIgnoreCase("9b")){
									refunds+=amount;
									discountValue=	amount2;	
									
								}
								else
								{
									if(category.equalsIgnoreCase("9a"))
										penaltyCollected += amount ;
									else
										pastDueCollected += amount;
									
									c.setTransactionDate(null);
									c.setRef(null);
								}
								
								list.add(c);
								if(type.equalsIgnoreCase("1")){
									try{
										Statement s = null;
										ResultSet r = null;
										
										s= new FactorConnection().getConnection().createStatement();
										String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
										"on rh.N_REFNO=rd.N_REFNO inner join refund ref on	"+
										"ref.N_REFNO=rh.n_refpaymentno inner join "+
										"Invoice inv on rd.N_INVNO=inv.n_invno	"+
										"where rh.C_CLNTCODE='"+clientCode+"' and ref.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
										r= s.executeQuery(query);
										
										if(r.next()){
											double val = r.getDouble("amount")*((100-advratio)/100);
											if(val!=0){
												ClientActivities op = new ClientActivities();
												op.setDefinition("CN Adjustment From Refund");
												op.setRef("");
												op.setReceivables(0.00);
												op.setReserves(0.00);
												op.setFiuTransaction(val);
												fiuTransaction +=val;
												fiuBalance +=val;
												op.setFiuBalance(fiuBalance);
												list.add(op);
											}
										}
										
										}
										catch(Exception e){
											e.printStackTrace();
										}	
								}
								
								if(dcPayment!=0){
									ClientActivities dcClientActivities = new ClientActivities();
									dcClientActivities.setDefinition("PD - Discount Charge");
									dcClientActivities.setReceivables(0.00);
									reserves-=dcPayment;
									dcClientActivities.setReserves(-1*dcPayment);						
									dcClientActivities.setFiuTransaction(0.00);
									dcClientActivities.setFiuBalance(fiuBalance);
									pastDueCollected+=dcPayment;
									list.add(dcClientActivities);
								}
					/*p			if(penaltyPayment!=0){
									ClientActivities penaltyPaymentClientActivities = new ClientActivities();
									penaltyPaymentClientActivities.setDefinition("Penalty Charge");
									penaltyPaymentClientActivities.setReceivables(0.00);
									reserves-=penaltyPayment;
									penaltyPaymentClientActivities.setReserves(-1*penaltyPayment);						
									penaltyPaymentClientActivities.setFiuTransaction(0.00);
									penaltyPaymentClientActivities.setFiuBalance(fiuBalance);
									pastDueCollected+=penaltyPayment;
									list.add(penaltyPaymentClientActivities);
								}   p*/
								
							}	
							
							if(category.equalsIgnoreCase("2")||
							   //category.equalsIgnoreCase("3")||
							   category.equalsIgnoreCase("3a")||
							  (category.equalsIgnoreCase("9")&&amount2!=0)
							)
							{
								ClientActivities c3 = new ClientActivities();
							//rdc 08042010	
									c3.setDefinition("Discount Charge");
									c3.setRef("");
									if(category.equalsIgnoreCase("9")&&(type.equalsIgnoreCase("2")||type.equalsIgnoreCase("3")||type.equalsIgnoreCase("4"))){
									}
									else{
										c3.setReceivables(0.00);
									}					
									if(category.equalsIgnoreCase("2") 		
									   ||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")
									   ||category.equalsIgnoreCase("9")){
									   	if (category.equalsIgnoreCase("9")) dcCollected+=amount2;
										if (category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")){ 
											if (amount2>0) {
												c3.setReserves(-1*amount2);
											} else {
												c3.setReserves(amount2);
											}
											reserves-=(amount2);
											fiuTransaction+=amount2;
											c3.setFiuTransaction(amount2); 
											if (category.equalsIgnoreCase("2")) {
												discountCharges=amount2;
												dcCollected+=amount2;
											}
										} else {
											c3.setReserves(-1*discountValue);
											log.info("reserves before adding discount charges: "+reserves);
											reserves+=(-1*discountValue);
											log.info("reserves before adding discount charges: "+reserves);
											
											if (!category.equalsIgnoreCase("9")) {
												c3.setFiuTransaction(discountValue);
												fiuTransaction+=discountValue;
												fiuBalance+=discountValue;
											} else {
												c3.setFiuTransaction(0.00);
											}
										}
										
									}
									else{
										c3.setReserves(0.00); 	//rdc07122010
										c3.setFiuTransaction(0.00);
									}
									c3.setFiuBalance(fiuBalance);
									list.add(c3);	
							}
							rset = rs.next();	//08282010
						}
						
				/*p		if(!rset){
							//rdc 08092610 ..... 
							Date today = DateHelper.parse(asOfDate);
							Map map = new HashMap();
							map.put("ADVRATIO", advratio/100.00);
							map.put("BLR", blr/100.00);
							map.put("DCR", dcr/100.00);
							map.put("C_CLNTCODE", clientCode);
							map.put("asOfDate", asOfDate);
							map.put("today", DateHelper.parse(DateHelper.format(today)));
									
							INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
							dcAccruals= m.doRoundOff(invoiceDAO.getDCAccrual2(map));
							log.info("dcAccruals:"+dcAccruals );
							log.info("receivables:"+receivables );
							log.info("reserves:"+reserves );
							log.info("fiuBalance:"+fiuBalance );
							ClientActivities c6 = new ClientActivities();
							AccountingMaintenanceService AMS  = AccountingMaintenanceService.getInstance();
							 pastDueInvoices = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(n_penaltyamount),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
							 dcAccruals = dcAccruals+pastDueInvoices;
								reserves+=(-1*dcAccruals);
								fiuBalance+=dcAccruals;	//rdc08092010
								if (dcAccruals>0) {
									c6.setReserves(-1*dcAccruals);
								} else {
									c6.setReserves(dcAccruals);
								}
								c6.setFiuBalance(fiuBalance);
								discountCharges=dcAccruals;			p*/
							
								//pastDueFR = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(N_INVOICEAMT),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
								
								/*if(pastDueInvoices!=0){
									ClientActivities c7 = new ClientActivities();	
									c7.setDefinition("Past Due Interest");
									c7.setRef("");
									c7.setTransactionDate(new Date(asOfDate));	
									c7.setReceivables(0.00);
									c7.setFiuTransaction(0.00);	
									c7.setFiuBalance(fiuBalance);
									reserves-=pastDueInvoices;
									c7.setReserves(-1*pastDueInvoices);
									list.add(c7);
								}*/
						/*p		c6.setDefinition("Discount Charges - Accrual");
								c6.setRef("");
								c6.setTransactionDate(new Date(asOfDate));	
								c6.setReceivables(0.00);
								c6.setFiuTransaction(0.00);			
								c6.setTotalReceivables(receivables);
								c6.setTotalReserves(reserves);
								c6.setTotalFiuTransaction(fiuTransaction);
								c6.setTotalFiuBalance(fiuBalance);
								c6.setInvoices(invoices);
								c6.setServiceCharges(serviceCharges);
								c6.setAdvances(advances);
								c6.setReceipts(receipts);
								c6.setCreditNotes(creditNotes);
								c6.setRefunds(refunds);
								c6.setDiscountCharges(discountCharges);
								c6.setDcOnCashDelays(dcOnCashDelays);
								c6.setSetupFee(setupFee);
								c6.setDocStamp(docStamp);
								c6.setDcCollected(dcCollected);
								c6.setOverpayment(overpayment);
								c6.setReceiptAdvance(rctAdvance);
								c6.setReceiptRefund(rctRefund);
								c6.setDshnrdChks(dshnrdChks);
								c6.setCnCancelled(cnCancelled);
								c6.setPenaltyCollected(penaltyCollected);
								c6.setPastDueCollected(pastDueInvoices);
								c6.setPastDueFR(pastDueFR);
								c6.setNotarialFee(notarial); //added by CVG as of 04-11-16
								list.add(c6);
								log.info("total in");
								log.info("8-setupFee/dcCollected:" + setupFee + "/" + dcCollected);
								log.info("doc stamp amount: " + docStamp);
							//end 08092010
						}  */
					}
					catch(Exception e){
						e.printStackTrace();
					}
					finally{
						try{
							if(rs!=null)rs.close();
							if(stmt!=null)stmt.close();			
						}
						catch(SQLException e){
						}
					}							

		return fiuBalance;		
	}



	/***********************************************************************************************************************************/
	/***********************************************************************************************************************************/

	
	public void updateClientYearEnd(CC cc){
		//log.info("updating year end of Client: "+cc.getClientName()+" with clientcode("+cc.getClientCode()+") equal  "+MonthlyBalancesDAO.saveYearEnd(cc.getClientCode()));
		log.info("MonthlyBalancesDAO.saveYearEnd("+cc.getBranchCode()+")  "+MonthlyBalancesDAO.saveYearEnd(cc.getBranchCode()));
	}
	
	public boolean doUpdateYearEnd(CC cc){

		boolean update=false;
				
		String sSQL=" UPDATE MonthlyBalances SET " +
		
		" N_PREVYRTWOFIU=N_PREVYRFIU, N_PREVYRTWOREC=N_PREVYRREC, N_PREVYRTWORES=N_PREVYRRES, N_PREVYRTWOACC=N_PREVYRACC, " +
		
		" N_PREVJANFIU=N_JANFIU,	N_PREVFEBFIU=N_FEBFIU,	N_PREVMARFIU=N_MARFIU,	N_PREVAPRFIU=N_APRFIU, "+
		" N_PREVMAYFIU=N_MAYFIU,	N_PREVJUNFIU=N_JUNFIU,	N_PREVJULFIU=N_JULFIU,	N_PREVAUGFIU=N_AUGFIU, "+
		" N_PREVSEPFIU=N_SEPFIU,	N_PREVOCTFIU=N_OCTFIU,	N_PREVNOVFIU=N_NOVFIU,	N_PREVYRFIU=N_DECFIU, "+
		
		" N_PREVJANREC=N_JANREC,	N_PREVFEBREC=N_FEBREC,	N_PREVMARREC=N_MARREC,	N_PREVAPRREC=N_APRREC, "+
		" N_PREVMAYREC=N_MAYREC,	N_PREVJUNREC=N_JUNREC,	N_PREVJULREC=N_JULREC,	N_PREVAUGREC=N_AUGREC, "+
		" N_PREVSEPREC=N_SEPREC,	N_PREVOCTREC=N_OCTREC,	N_PREVNOVREC=N_NOVREC,	N_PREVYRREC=N_DECREC, "+
		
		" N_PREVJANRES=N_JANRES,	N_PREVFEBRES=N_FEBRES,	N_PREVMARRES=N_MARRES,	N_PREVAPRRES=N_APRRES, "+
		" N_PREVMAYRES=N_MAYRES,	N_PREVJUNRES=N_JUNRES,	N_PREVJULRES=N_JULRES,	N_PREVAUGRES=N_AUGRES, "+
		" N_PREVSEPRES=N_SEPRES,	N_PREVOCTRES=N_OCTRES,	N_PREVNOVRES=N_NOVRES,	N_PREVYRRES=N_DECRES, "+
		
		" N_PREVJANACC=N_JANACC, N_PREVFEBACC=N_FEBACC, N_PREVMARACC=N_MARACC, N_PREVAPRACC=N_APRACC, "+
		" N_PREVMAYACC=N_MAYACC, N_PREVJUNACC=N_JUNACC, N_PREVJULACC=N_JULACC, N_PREVAUGACC=N_AUGACC, "+
		" N_PREVSEPACC=N_SEPACC, N_PREVOCTACC=N_OCTACC, N_PREVNOVACC=N_NOVACC, N_PREVYRACC =N_DECACC, "+			
		
		" N_JANFIU=0,	N_FEBFIU=0,	N_MARFIU=0,	N_APRFIU=0, "+
		" N_MAYFIU=0,	N_JUNFIU=0,	N_JULFIU=0,	N_AUGFIU=0, "+
		" N_SEPFIU=0,	N_OCTFIU=0,	N_NOVFIU=0,	N_DECFIU=0, "+
		
		" N_JANREC=0,	N_FEBREC=0,	N_MARREC=0,	N_APRREC=0, "+
		" N_MAYREC=0,	N_JUNREC=0,	N_JULREC=0,	N_AUGREC=0, "+
		" N_SEPREC=0,	N_OCTREC=0,	N_NOVREC=0,	N_DECREC=0, "+
		
		" N_JANRES=0,	N_FEBRES=0,	N_MARRES=0, N_APRRES=0, "+
		" N_MAYRES=0,	N_JUNRES=0,	N_JULRES=0,	N_AUGRES=0, "+
		" N_SEPRES=0,	N_OCTRES=0,	N_NOVRES=0,	N_DECRES=0,	"+	
		
		" N_JANACC=0,	N_FEBACC=0,	N_MARACC=0, N_APRACC=0, "+
		" N_MAYACC=0,	N_JUNACC=0,	N_JULACC=0,	N_AUGACC=0, "+
		" N_SEPACC=0,	N_OCTACC=0,	N_NOVACC=0,	N_DECACC=0	"+
		
		" FROM MonthlyBalances WHERE C_CLNTCODE IN (SELECT C_CLNTCODE FROM dbCIF.dbo.Client WHERE C_BRANCHCODE='"+cc.getBranchCode()+"')";
		log.info("getMonthBalClntCodeAsOfDate (sSQL) "+sSQL);
		Statement stmt=null;
		ResultSet rs=null;
		Connection conn = new FactorConnection().getConnection();
		try{
				conn.setAutoCommit(false);
				stmt = conn.createStatement();
				stmt.executeUpdate(sSQL);				
				conn.commit();
				update=true;				
			}
		catch(Exception e){
			e.printStackTrace();
			try {
				conn.rollback();
				update=false;
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		finally{			
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}
		log.info("(updateClientYearEnd(CC cc)) Updating MonthlyBalances equals= "+update);
		return update;
	}
	public List<Adjustment> getClientAdjustments(String clientCode,String asOfDate)
	{	
		String branchCode = "";
		ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
		while(clientList.hasNext()){
			Client client = (Client)clientList.next();
			branchCode = client.getC_BranchCode();
		}
		List<Adjustment> list = new ArrayList<Adjustment>();		
		String sSQL = "SELECT	adj.D_APPROVEDDATE, adj.N_REFNO, c.C_CUSTNAME as customerName, " +
					  "dbCIF.dbo.Client.C_NAME as clientName, adj.C_BRANCHCODE , adj.C_INVOICENO, " + 
					  "adj.D_INVOICEDATE, adj.C_ADJCODE, adj.N_AMOUNT, adj.C_STATUS " +
					  "FROM    Adjustment adj INNER JOIN dbCIF.dbo.Client ON	adj.C_CLNTCODE = dbCIF.dbo.Client.C_CLNTCODE " + 
					  "INNER JOIN Customer c ON	c.C_CUSTCODE = adj.C_CUSTCODE " +
					  "WHERE	(adj.C_STATUS = '2') AND (adj.C_BRANCHCODE = '"+branchCode+"') AND " + 
					  "(adj.D_APPROVEDDATE = '"+asOfDate+"')" ;
		
		log.info(" getClientAdjustments [args1:" +clientCode+"][debug]: " +sSQL);
		
		Statement stmt=null;
		ResultSet rs=null;
		try{
			
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			
			while(rs.next()){
				Adjustment adj = new Adjustment();
				adj.setD_APPROVEDDATE(rs.getString("D_APPROVEDDATE").trim().toUpperCase());
				adj.setN_REFNO(rs.getString("N_REFNO").trim().toUpperCase());
				adj.setC_CUSTCODE(rs.getString("C_CUSTNAME").trim().toUpperCase());
				adj.setC_CLNTCODE(rs.getString("C_NAME").trim().toUpperCase());
				adj.setC_BRANCHCODE(rs.getString("C_BRANCHCODE").trim().toUpperCase());
				adj.setC_INVOICENO(rs.getString("C_INVOICENO").trim().toUpperCase());
				adj.setD_INVOICEDATE(rs.getString("D_INVOICEDATE").trim().toUpperCase());
				adj.setC_ADJCODE(rs.getString("C_ADJCODE").trim().toUpperCase());
				adj.setN_AMOUNT(rs.getDouble("N_AMOUNT"));
				adj.setC_STATUS(rs.getString("C_STATUS").trim().toUpperCase());
				
				list.add(adj);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return list;			
	}
	
	public Long advancesCount(String clientCode){
		Long count=0L;
		String branchCode="";
		
		ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
		while(clientList.hasNext()){
			Client client = (Client)clientList.next();
			branchCode = client.getC_BranchCode();
		}
		
		String sSQL = "Select count(N_REFNO) as COUNT from advances where c_clntcode=" + clientCode + " " +
		              "and C_BRANCHCODE='" + branchCode + "' and C_STATUS !=3 and C_TYPE='1'";
		
		Statement stmt=null;
		ResultSet rs=null;
		try{
			
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			
			while(rs.next()){
				count = rs.getLong("COUNT");
				
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}
			
		return count;
	}
	
	public String getPreviousAdvancesTransactionDate(String clientCode, String advanceNumber){
		
		String tranDate = "";
		String branchCode="";
		
		ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
		while(clientList.hasNext()){
			Client client = (Client)clientList.next();
			branchCode = client.getC_BranchCode();
		}
		
		String sSQL = "Select convert(nvarchar,max(d_transactiondate),101) as D_TRANSACTIONDATE " +
				      "from advances " + 
		              "where c_clntcode=" + clientCode + " and c_branchcode='" + branchCode + "' " +
		              "and n_refno !=" + advanceNumber + " and c_status != '3' and " + 
		              "d_transactiondate < (select d_transactiondate from advances where " +
		              "n_refno = " + advanceNumber + ")";
		
		Statement stmt=null;
		ResultSet rs=null;
		try{
			
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			
			while(rs.next()){
				tranDate = rs.getString("D_TRANSACTIONDATE");
				
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}
			
		return tranDate;
	}

	//added 05222012
	public List<ClientActivities> getClientActivities2(String clientCode,String asOfDate)
	{		 
		List<ClientActivities> list = new ArrayList<ClientActivities>();		
		String sSQL = "SELECT     * FROM ( " + 	
				"		SELECT	i.C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_INVOICEAMT AS AMOUNT, 0.00 AS AMOUNT2, N_ADVANCEDRATIO AS ADVRATIO, " +
				"				C_INVOICENO AS ref,  0 AS ref2, '1' AS category , 0 as cashDelay , '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment, i.N_SVCCHGTYPE as scType  " + 
				"				FROM	Invoice i INNER JOIN dbCIF.dbo.CLIENT c ON i.C_CLNTCODE = c.C_CLNTCODE " +
				"				WHERE i.C_STATUS IN('2','3','4','5','6')" +
				" 				AND (i.C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"				CAST(N_REFNO AS NVARCHAR) AS REF, c_debit AS REF2,'1a' AS CATEGORY , 0 AS CASHDELAY, C_ADJREC+C_ADJRES+C_ADJFIU+C_ADJFIUBAL+a2.C_ADJDESC AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +  
				"				FROM ADJUSTMENT a INNER JOIN ADJUSTMENTTYPE a2 ON a.C_ADJCODE = a2.C_ADJCODE " +
				"				WHERE C_STATUS = '2'AND B_INCLUDED = 1 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, N_PENALTYCHG as penaltyPayment ,'' as scType " +
				"                   FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "+  
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2b' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment  ,'' as scType " +  
		        "    				FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4)  AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0  "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
		        "  					 + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')"+
				"				UNION "+
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT,0.0 AS AMOUNT2, 0.00 AS ADVRATIO,   "+
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2c' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment   ,'' as scType " +
				"					FROM	Advances WHERE     C_TYPE = 1 AND C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
				"   				+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
				"				UNION"	+
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG2 AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +
				"				FROM	Advances WHERE ISNULL(N_DISCCHG2,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				//added by CVg as of 03-16-16
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_NOTARIAL AS AMOUNT, 0 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'2d' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +
				"				FROM	Advances WHERE ISNULL(N_NOTARIAL,0) <> 0 AND C_TYPE = 1 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				//end
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +
				"				FROM	Advances WHERE     C_TYPE = 2 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_ADVAMT AS AMOUNT, N_DISCCHG1 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(N_REFNO AS NVARCHAR) AS ref, '0' AS ref2,'3a' AS category , 0 as cashDelay, C_TYPE AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +
				"				FROM	Advances WHERE     C_TYPE = 3 AND  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '4' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment  ,'' as scType " +
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND (C_STATUS IN (1,2,4))   " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '5' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment ,'' as scType " +
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 2 AND (C_STATUS IN (1,2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"		SELECT a.C_CLNTCODE, a.C_CUSTCODE,  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101)AS D_TRANSACTIONDATE, AMOUNT,AMOUNT2, ADVRATIO, " +
				"				REF, REF2,CATEGORY , CASHDELAY, TYPE,AMOUNT1,OVERPAYMENT,dcPayment, penaltyPayment ,'' as scType  FROM ( " +
				"			SELECT rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,rdinv.D_TRANSACTIONDATE,D_FULLYPAIDDATE, ISNULL(SUM(N_RECEIPTAMT),0) AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"				CAST(rd2.N_REFNO  AS NVARCHAR) AS REF, rh2.C_RECEIPTTYPE AS REF2,'5A' AS CATEGORY , 0 AS CASHDELAY, '' AS TYPE, 0.00 AS AMOUNT1, 0 AS OVERPAYMENT, 0.00 AS dcPayment, 0.00 as penaltyPayment  ,'' as scType " +
				"				FROM RECEIPTSDTL rd2 INNER JOIN( " +
				"			SELECT DISTINCT rh.C_CLNTCODE, rh.C_CUSTCODE,rd.C_INVOICENO,rd.N_INVNO,rh.D_TRANSACTIONDATE,D_FULLYPAIDDATE FROM RECEIPTSDTL rd " + 
				"				INNER JOIN ( " + 
				"			SELECT	C_CLNTCODE, C_CUSTCODE,CAST(N_REFNO AS NVARCHAR) AS REF, D_TRANSACTIONDATE " +
				"				FROM	RECEIPTSHDR WHERE     C_RECEIPTTYPE IN (1,2,3,4) AND (C_STATUS IN (2,4)) " + 
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"				) AS rh ON rd.N_REFNO = rh.REF " +
				"				INNER JOIN INVOICE inv ON rd.C_INVOICENO = inv.C_INVOICENO and rd.N_INVNO = inv.N_INVNO " + 
				"				AND inv.C_STATUS IN (5,6) " +  
				"				) AS rdinv ON rd2.C_INVOICENO = rdinv.C_INVOICENO  AND rd2.N_INVNO = rdinv.N_INVNO " +
				"				INNER JOIN  RECEIPTSHDR rh2 ON rd2.N_REFNO=rh2.N_REFNO AND rh2.C_RECEIPTTYPE IN (3,4)  AND rh2.C_STATUS in (2,4)" +
				"				GROUP BY rh2.C_RECEIPTTYPE,rd2.N_REFNO,rdinv.D_TRANSACTIONDATE,rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,D_FULLYPAIDDATE " +
				"		) a where  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101) =  CONVERT(VARCHAR(10), a.D_FULLYPAIDDATE, 101) " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2,  0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, C_STATUS ref2, '6' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 3 AND (C_STATUS IN (2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref,C_STATUS  AS ref2, '6a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, ISNULL(N_TOTINVAMT,0.00) AS amount1, N_OPAMT AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +
				"                   FROM	ReceiptsHdr WHERE     C_RECEIPTTYPE = 4 AND (C_STATUS IN (2,4)) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"      SELECT	cn.C_CLNTCODE, cn.C_CUSTCODE, cn.D_TRANSACTIONDATE, cn.N_AMOUNT AS AMOUNT,  0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(cn.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '6b' AS category , 0 as cashDelay, '' AS type, 0.00 AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +  
				"			FROM	CreditNote cn INNER JOIN RECEIPTSHDR rh ON cn.C_RECEIPTNO = rh.N_REFNO " +
				"			WHERE cn.C_STATUS IN(1,2) AND rh.C_STATUS <> 3 " +
				" 				AND (cn.C_CLNTCODE ='" + clientCode + "') AND (cn.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment ,'' as scType " +
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				/*//Add Discount Charge and Penalty 
				//7d for Discount Charge
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_DISCCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7d' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
				"                   FROM	ReceiptsHdr WHERE   " +
				" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +		
				//7e for Penalty
				"     SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7e' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment " +
				"                   FROM	ReceiptsHdr WHERE   " +
				" 				  (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				*/
				"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  c.D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7a2' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +
				"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
				"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
				" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (c.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"    SELECT	C_CLNTCODE, C_CUSTCODE,  (CASE WHEN D_DATEBOUNCED IS NOT NULL THEN D_DATEBOUNCED ELSE D_TRANSACTIONDATE END) AS D_TRANSACTIONDATE, N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7b' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, N_OPAMT AS overPayment, N_DISCCHG AS dcPayment, N_PENALTYCHG as penaltyPayment ,'' as scType " +
				"                   FROM	ReceiptsHdr WHERE C_RECEIPTTYPE = 1 AND C_STATUS = 3 " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"	SELECT	c.C_CLNTCODE, c.C_CUSTCODE,  (CASE WHEN D_CANCELLEDDATE IS NOT NULL THEN D_CANCELLEDDATE ELSE D_DATEBOUNCED END) as D_TRANSACTIONDATE, c.N_AMOUNT AS AMOUNT, 0.00 AS AMOUNT2, 0.00 AS ADVRATIO, " + 
				"			CAST(c.N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '7c' AS category , N_CASHDELAY as cashDelay, C_RECEIPTTYPE AS type, 0.00 AS amount1, 0.00 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +
				"					FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno " +
				"					WHERE C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3  " +
				" 				AND (c.C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"                   UNION " +
				"    SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_REFAMT AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, " +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9' AS category , 0 as cashDelay, C_TYPE AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment  ,'' as scType " +
				"                   FROM	Refund WHERE  C_STATUS IN (2,4) " +
				" 				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) " + 
				"                  + '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "') " +
				"			union"+
				"	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PENALTYCHG AS AMOUNT, 0.0 AS AMOUNT2, 0.00 AS ADVRATIO, "   +
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9a' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment ,'' as scType " +    
		        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PENALTYCHG IS NOT NULL AND N_PENALTYCHG <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar) "+   
		        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
		        "			UNION "+	
		        "	SELECT	C_CLNTCODE, C_CUSTCODE, D_TRANSACTIONDATE, N_PDINTEREST AS AMOUNT, N_DISCCHG AS AMOUNT2, 0.00 AS ADVRATIO, "+  
				"			CAST(N_REFNO AS NVARCHAR) AS ref, 0 AS ref2, '9b' AS category , 0 as cashDelay, '' AS type, ISNULL(N_INELIGIBLEREC,0) AS amount1, 0 AS overPayment, 0.00 AS dcPayment, 0.00 as penaltyPayment,'' as scType " +    
		        "        			FROM	Refund WHERE  C_STATUS IN (2,4) AND N_PDINTEREST IS NOT NULL AND N_PDINTEREST <> 0 "+
				"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)"+   
		        "       			+ '/01/' + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
		        "			UNION "+	
		    	"	SELECT C_CLNTCODE,0 C_CUSTCODE ,date_tagged_RMU D_TRANSACTIONDATE, ISNULL(amount_reversed,0) AS AMOUNT, 0 AS AMOUNT2, 0.0 AS ADVRATIO,'CR' as ref, 0 as ref2, 'client' AS category, 0 as cashDelay,'' as type,0 as Amount1, 0 as overPayment, 0 as dcPayment, 0 as penaltyPayment,'' as scType	"+
		   	 	"	FROM dbcif..Client where is_RMU = 1 and C_CLNTCODE ='" + clientCode + "' and (date_tagged_RMU BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)	"+ 
		        "           			 +'/01/'+  CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')	"+ 
		        "	) a " +
		        //Replace the order by fields (Previously D_TRANSACTIONDATE,catefory,ref asc)
				"	ORDER BY D_TRANSACTIONDATE,category,ref asc ";		
		log.info(" getClientActivities [args1:" +clientCode+"][debug]: " +sSQL);
		
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);

			double dcr=0.00;
			double scr=0.00;
			double blr = 0.00;
			String blrCode="";
			int day=0;
			int cashDelay=0;
			String custCode="";
			String customerName="";

			double serviceValue=0.00;
			double discountValue=0.00;
			double dcCashDelayValue=0.00;

			//Totals
			double receivables=0.00;
			double reserves=0.00;
			double fiuTransaction=0.00;
			double fiuBalance=0.00;

			double invoices=0.00;
			double advances=0.00;
			double receipts=0.00;
			double serviceCharges=0.00;			
			double discountCharges=0.00;
			double dcOnCashDelays=0.00;
			double creditNotes=0.00;
			double refunds=0.00;
			double setupFee=0.00;
			double docStamp=0.00;
			double dcCollected=0.00;
			double dcAccruals=0.00;
			double advratio=0.00;
			double iniVal=0.00;
			int withTrans = 0;
			double lastAccruals = 0.00;
			double overpayment = 0.00;
			double rctAdvance = 0.00;
			double rctRefund = 0.00;
			double dshnrdChks = 0.00;
			double cnCancelled = 0.00;
			String type="";
			String branchCode="";
			
			double pastDueInvoices = 0.00;
			double pastDueCollected = 0.00;
			double penaltyCollected = 0.00;
			double pastDueFR = 0.00;
			
			double balance=0.00;

			boolean is_rmu = false;
			ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
			while(clientList.hasNext()){
				ClientActivities header = new ClientActivities();
				Client client = (Client)clientList.next();
				header.setClient(client);
				header.setClientCode(clientCode);
				dcr=m.doRoundOff(client.getN_Dcr());
				scr=m.doRoundOff(client.getN_Scr());
				advratio =m.doRoundOff(client.getN_AdvRatio());
				branchCode = client.getC_BranchCode();	//rdc08132010
				blrCode = client.getC_BlrTypeCode();
				BLRFileDAO blrDao = new BLRFileDAO();
				ListIterator<BLRFile> blrFileList = blrDao.getBLRFile(clientCode, asOfDate).listIterator();
				while(blrFileList.hasNext()){
					BLRFile blrFile = (BLRFile) blrFileList.next();
					log.info("BLR: "+blrFile.getBlr());
					log.info("Effectivity Date: "+blrFile.getEffectiveDate());
					log.info("Expiry Date: "+blrFile.getExpiryDate());
					blr = m.doRoundOff(blrFile.getBlr());
					log.info("blrFile.getBlr()"+blrFile.getBlr());
					//header.setBlrFile(blrFile);
					break;
				}
				log.info("advratio: "+advratio);
				
				String strMMM = DateUtils.getLastMonthMMM(asOfDate);//RLS 01/07/2011 add method in getting prefix of month (MMM) DateUtils.getLastMonthMMM(asOfDate)
				strMMM = "N_" + strMMM +"ACC";
				is_rmu = client.isIs_rmu();
				Map map2 = new HashMap();
				map2.put("C_CLNTCODE", clientCode);
				map2.put("MMM", strMMM);		
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				dcAccruals= m.doRoundOff(invoiceDAO.getLastAccrual(map2));
				log.info("dcAccruals:"+dcAccruals );

				MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
				ListIterator mbList =mbDAO.getMonthBalClntCodeAsOfDate(clientCode,asOfDate).listIterator();						
				while(mbList.hasNext()){

					MonthlyBalances mb = (MonthlyBalances)mbList.next();
					header.setTransactionDate(DateHelper.getDateInFirstDay(asOfDate));
					header.setStartDate(DateHelper.getDateInFirstDay(asOfDate));
					header.setDefinition("Balance B/F");
					header.setRef("");
					//header.setReceivables(mb.getMonthReceivables().doubleValue());
					header.setReceivables(m.doRoundOff(mb.getMonthReceivables().doubleValue()));
					//header.setReserves(mb.getMonthReserves().doubleValue());
					header.setReserves(m.doRoundOff(mb.getMonthReserves().doubleValue()));
					//header.setFiuBalance(mb.getMonthFIU().doubleValue());
					if (m.doRoundOff(mb.getMonthFIU().doubleValue())>iniVal) {	//rdc 08102010
						fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue() + dcAccruals );//header.getFiuTransaction()s;		
						header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
					} else {
						if ((m.doRoundOff(mb.getMonthFIU().doubleValue())==iniVal) && dcAccruals>0){
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue()+dcAccruals);//header.getFiuTransaction();
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
						}else{
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue());//header.getFiuTransaction();
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue()));
						}
					}
					//header.setFiuTransaction(mb.getMonthFIU().doubleValue());
					header.setFiuTransaction(m.doRoundOff(mb.getMonthFIU().doubleValue()));
					receivables=header.getReceivables();
					reserves=header.getReserves();
					fiuTransaction=header.getFiuTransaction();
					
					if((dcAccruals>0.00) && (fiuTransaction==0.00)){
						balance=header.getFiuTransaction()+dcAccruals;
					}else{
					
						balance=header.getFiuTransaction();
					} 
									
					
					break;
				}
				list.add(header);
				break;				
			}
			
			ClientActivities disc = new ClientActivities();
			disc.setDefinition("Last Month's DC Accrual");
			disc.setRef("");
			disc.setReceivables(0.00);			
			
			log.info("reserves before adding discount in balance bf "+reserves);
			if ((fiuTransaction>iniVal)||(reserves>iniVal)||receivables>iniVal) {
				
				if((dcAccruals>0.00) && (fiuTransaction==0.00)){
					fiuBalance=balance-dcAccruals;
				}else{
				    fiuBalance-=dcAccruals;
				}
				reserves+=dcAccruals;
				disc.setReserves(dcAccruals);
			} else {
				disc.setReserves(0.00);
			}
			log.info("reserves after adding discount in balance bf "+reserves);
			disc.setFiuTransaction(0.00);
			disc.setFiuBalance(fiuBalance);	
			dcAccruals=0.00;
			list.add(disc);	
			boolean rset = rs.next();	
			String ref = "";
			while(rset){
				log.info("receipts"+receipts);
				type=rs.getString("type");
				double amount =m.doRoundOff(rs.getDouble("AMOUNT")); 
				double amount1=m.doRoundOff(rs.getDouble("amount1"));
				double amount2 =m.doRoundOff(rs.getDouble("AMOUNT2"));	//rdc07152010
				double opmt = m.doRoundOff(rs.getDouble("overPayment"));
				//added 6/28/2016 for receipts dc and penalty
				double dcPayment = m.doRoundOff(rs.getDouble("dcPayment"));
				double penaltyPayment = m.doRoundOff(rs.getDouble("penaltyPayment"));
				String scType = rs.getString("scType")!=null? rs.getString("scType"):"2"; //cvg 02132017
				String ref2 = rs.getString("ref2").trim();	//rdc07152010
				String date1 = sdf.format(rs.getDate("D_TRANSACTIONDATE"));				
				String category = rs.getString("category").trim();
				if (date1.equals(asOfDate)) {
					day = 1;
				} else {
					day = DateHelper.getDayPerTransaction(date1, asOfDate);
				}	
				cashDelay = rs.getInt("cashDelay");
				log.info("Day: "+day);
				log.info("Category "+category);
				ClientActivities c = new ClientActivities();				
				c.setRef(rs.getString("ref"));
				c.setTransactionDate(rs.getDate("D_TRANSACTIONDATE"));				
				if(category.equalsIgnoreCase("1")){
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					c.setDefinition("Invoice");
					c.setReceivables(amount);
					receivables+=amount;
					c.setReserves(amount);
					reserves+=amount;
					c.setFiuTransaction(0.00);
					c.setFiuBalance(fiuBalance);
					invoices+=amount;	
					list.add(c);

					ClientActivities c2 = new ClientActivities();
					c2.setDefinition("Service Charge");
					c2.setRef("");
					c2.setReceivables(0.00);
					if (scType.equals("1")){ //added cvg02132017
						serviceValue=m.doRoundOff(amount*(scr/100)*(advratio/100));
					}else{
						serviceValue=m.doRoundOff(amount*(scr/100)); //old
					}
					reserves-=serviceValue;
					c2.setReserves(-1*serviceValue);						
					fiuTransaction+=serviceValue;
					c2.setFiuTransaction(serviceValue);
					c2.setFiuBalance(fiuBalance);
					serviceCharges+=serviceValue;
					list.add(c2);

				}
				else if(category.equalsIgnoreCase("1a")){
					String strTypeRec =  type.substring(0, 1);
					String strTypeRes = type.substring(1, 2);
					String strTypeFiu = type.substring(2, 3);
					String strTypeFiuBal = type.substring(3, 4);
					String strDesc = type.substring(4);
					
					if (ref2.equals("1")){
						dcCollected+=amount;
					} else {
						dcCollected-=amount;
					}
					
					//effect on receivables
					if (strTypeRec.equals("1")) {
						receivables+=amount;
						c.setReceivables(amount);
					} else if (strTypeRec.equals("2")) {
						receivables-=amount;
						c.setReceivables(-1*amount);
					} else {
						c.setReceivables(0.00);
					}
					//effect on reserves
					if (strTypeRes.equals("1")) {
						reserves+=amount;
						c.setReserves(amount);
					} else if (strTypeRes.equals("2")) {
						reserves-=amount;
						c.setReserves(-1*amount);
					} else {
						c.setReserves(0.00);
					}
					//effect on fiu
					if (strTypeFiu.equals("1")) {
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
					} else if (strTypeFiu.equals("2")) {
						fiuTransaction-=amount;
						c.setFiuTransaction(-1*amount);
					} else {
						c.setFiuTransaction(0.00);
					}
					//effect on fiu balance
					if (strTypeFiuBal.equals("1")) {
						fiuBalance+=amount;
					} else if (strTypeFiuBal.equals("2")) {
						fiuBalance-=amount;
					}
					c.setFiuBalance(fiuBalance);
					c.setDefinition(strDesc);			
					list.add(c);
				}else if(category.equalsIgnoreCase("client")){
					//c.setDefinition("Client Reversal");
					//c.setReceivables(0.0);
					//reserves-=amount;
					//c.setReserves(-1*amount);
					//c.setFiuTransaction(amount);
					//fiuTransaction +=amount;
					//fiuBalance +=amount;
					//c.setFiuBalance(fiuBalance);
					//list.add(c);	
				}
				else if(category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||category.equalsIgnoreCase("2a")||category.equalsIgnoreCase("2b")||category.equalsIgnoreCase("2c")){					
						if(category.equalsIgnoreCase("2"))c.setDefinition("Advances");
						if(category.equalsIgnoreCase("3"))c.setDefinition("Setting-up Fee");
						if(category.equalsIgnoreCase("3a"))c.setDefinition("Advances - Unfactored");
						if(category.equalsIgnoreCase("2a"))c.setDefinition("Doc Stamp");
						if(category.equalsIgnoreCase("2b"))c.setDefinition("Penalty Charge");
						if(category.equalsIgnoreCase("2c"))c.setDefinition("PD - Discount Charge");
						//08042010
						c.setReceivables(0.00);
						reserves-=amount;
						c.setReserves(-1*amount);
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
						c.setFiuBalance(fiuBalance);
						if(category.equalsIgnoreCase("2")) advances+=amount;			
						list.add(c);
						if(category.equalsIgnoreCase("2")) {
							discountValue=m.doRoundOff(getDiscountCharge(amount2,blr,dcr,day));
							try{
								Statement s = null;
								ResultSet r = null;
								
								s= new FactorConnection().getConnection().createStatement();
								String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
								"on rh.N_REFNO=rd.N_REFNO inner join Advances adv on	"+
								"adv.N_REFNO=rh.n_advpaymentno inner join "+
								"Invoice inv on rd.N_INVNO=inv.n_invno	"+
								"where rh.C_CLNTCODE='"+clientCode+"' and adv.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
								r= s.executeQuery(query);
								
								if(r.next()){
									double val = r.getDouble("amount")*((100-advratio)/100);
									if(val!=0){
										ClientActivities op = new ClientActivities();
										op.setDefinition("CN Adjustment From Advance");
										op.setRef("");
										op.setReceivables(0.00);
										op.setReserves(0.00);
										op.setFiuTransaction(val);
										fiuTransaction +=val;
										fiuBalance +=val;
										op.setFiuBalance(fiuBalance);
										list.add(op);
									}
								}
								
								}
								catch(Exception e){
									e.printStackTrace();
								}	
						} else if(category.equalsIgnoreCase("3")) {
								setupFee = amount;
								/*discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,1));	
								dcCollected+=discountValue;*/
						} else if(category.equalsIgnoreCase("3a")) {
							discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,day));
						} else if(category.equalsIgnoreCase("2a")){
							c.setTransactionDate(null);
							c.setRef(null);
							docStamp =  amount; 
						}
						 else if(category.equalsIgnoreCase("2b")){
							 c.setTransactionDate(null);
							 c.setRef(null);
							 penaltyCollected += amount ;
						 }
						 else if(category.equalsIgnoreCase("2c")){
							 pastDueCollected += amount;
							 c.setTransactionDate(null);
							 c.setRef(null);
						 }
						withTrans = 1;
						
				}	

				else if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("5")||category.equalsIgnoreCase("7a")||category.equalsIgnoreCase("7d")){
					if(category.equalsIgnoreCase("7d")){
						c.setDefinition("Discount Charge");
						c.setReceivables(0.00);
						reserves-=amount;
						c.setReserves(-1*amount);
						fiuTransaction+=amount;
						c.setFiuTransaction(amount);
						c.setFiuBalance(fiuBalance);
						list.add(c);
					}
					else{
						log.info("Receipts cat4 and 5 here....");
						if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
							custCode=rs.getString("C_CUSTCODE");
							customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
						}					
						if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("7a"))c.setDefinition("RCT-CHK-"+customerName);
						if(category.equalsIgnoreCase("5"))c.setDefinition("RCT-CSH-"+customerName);	
							receivables-=amount-opmt;
							//fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
							
							receipts+=amount;
							c.setReceivables(-1*(amount-opmt));
							//c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
							if(is_rmu){
								c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
								fiuTransaction-=m.doRoundOff((amount-opmt));
								fiuBalance-=m.doRoundOff((amount-opmt));	//rdc08092010
							}else{
								c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
								fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
								fiuBalance-=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
							}
						log.info("amount: "+amount);
						log.info("amount1: "+amount1);
						amount=(amount1<amount)?amount1:amount;
						log.info("amount to be computed for discount: "+amount);
						discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
						c.setReserves(0.00);
						c.setFiuBalance(fiuBalance);
						list.add(c);
							if(opmt!=0){	
								ClientActivities op = new ClientActivities();
								op.setDefinition("Over Payment");
								op.setRef("");
								op.setReceivables(0.00);
								overpayment+=opmt;
								op.setReserves(opmt);
								reserves+=opmt;
								op.setFiuTransaction(0.00);
								op.setFiuBalance(fiuBalance);
								list.add(op);							
							}
							if(dcPayment!=0){
								ClientActivities dc = new ClientActivities();
								dc.setTransactionDate(null);
								dc.setDefinition("Discount Charge");
								dc.setReceivables(0.00);
								reserves-=dcPayment;
								dc.setReserves(-1*dcPayment);
								//fiuTransaction+=dcPayment;
								dc.setFiuTransaction(0.00);
								dc.setFiuBalance(fiuBalance);
								dcCollected += dcPayment;
								list.add(dc);
							}
							
							if(penaltyPayment !=0){
								ClientActivities pc = new ClientActivities();
								pc.setTransactionDate(null);
								pc.setDefinition("Penalty Charge");
								pc.setReceivables(0.00);
								reserves-=penaltyPayment;
								pc.setReserves(-1*penaltyPayment);
								//fiuTransaction+=penaltyPayment;
								pc.setFiuTransaction(0.00);
								pc.setFiuBalance(fiuBalance);
								penaltyCollected += penaltyPayment;
								list.add(pc);
							}
							//Unfactored Invoice
							ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
							Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
							if(unfactoredAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("Unfactored Invoices");
								ua.setReceivables(0.00);
								reserves-=unfactoredAmount;
								ua.setReserves(-1*unfactoredAmount);
								//fiuTransaction+=penaltyPayment;
								ua.setFiuTransaction(0.00);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							//Discount Charge
							Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
							if(dcAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("RMU Discount Charge");
								ua.setReceivables(dcAmount);
								receivables += dcAmount;
								//reserves-=dcAmount;
								//ua.setReserves(-1*dcAmount);
								ua.setReserves(0);
								fiuTransaction+=dcAmount;
								fiuBalance += dcAmount;
								ua.setFiuTransaction(dcAmount);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							//Penalty
							Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
							if(penaltyAmount !=0){
								ClientActivities ua = new ClientActivities();
								ua.setTransactionDate(null);
								ua.setDefinition("RMU Penalty Charge");
								ua.setReceivables(penaltyAmount);
								receivables += penaltyAmount;
								//reserves-=penaltyAmount;
								//ua.setReserves(-1*penaltyAmount);
								ua.setReserves(0);
								fiuTransaction+=penaltyAmount;
								fiuBalance += penaltyAmount;
								ua.setFiuTransaction(penaltyAmount);
								ua.setFiuBalance(fiuBalance);
								//penaltyCollected += penaltyPayment;
								list.add(ua);
							}
							
					}
				}
				else if(category.equalsIgnoreCase("5a")){
					ClientActivities pp = new ClientActivities();
					if(ref2.contentEquals("3")||ref2.contentEquals("4"))
					{
								/*if(ref2.contentEquals("3")){
									pp.setDefinition("CN Adjustment from Advance");
								}
								else if(ref2.contentEquals("4")){
									pp.setDefinition("CN Adjustment from Refund");
								}*/
					}
					else{
						pp.setDefinition("Previous Partial Payment");
					//pp.setRef(rs.getString("ref"));
					pp.setReceivables(0.00);
					pp.setReserves(0.00);
					fiuTransaction+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuTransaction(amount*m.doRoundOff((100-advratio)/100));	
					fiuBalance+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuBalance(fiuBalance);
					list.add(pp);}
				}

				else if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")||category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
					log.info("RCT-ADV and RCT-REF here....");
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
						if(!custCode.trim().equalsIgnoreCase(rs.getString("C_CUSTCODE"))){
							custCode=rs.getString("C_CUSTCODE");
							customerName=CommonDAO.getField("UPPER(SUBSTRING(C_CUSTNAME,1,20))as customerName", "Customer", " WHERE C_CUSTCODE="+custCode);
						}							
						if(category.equalsIgnoreCase("6")){
							c.setDefinition("RCT-ADV-"+customerName);
							rctAdvance+=amount;
						}
						if(category.equalsIgnoreCase("6a")){
							c.setDefinition("RCT-REF-"+customerName);
							rctRefund+=amount;
						}
					
					}
					if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
						if(is_rmu){
							c.setDefinition("RMU Credit Note");
						}else
							c.setDefinition("Credit Note");
						creditNotes+=amount;
					}
					receivables-=amount-opmt;
					c.setReceivables(-1*(amount-opmt));
					
					
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")) {
						c.setReserves(0.00);
						if(rs.getString("ref2").equalsIgnoreCase("2")){
							fiuTransaction-=(amount*(advratio/100))-opmt;
							c.setFiuTransaction(-1*((amount*(advratio/100))-opmt));
							fiuBalance-=(amount*(advratio/100))-opmt;
						}else{
							fiuTransaction-=amount-opmt;
							c.setFiuTransaction(-1*(amount-opmt));
							fiuBalance-=amount-opmt;
						}
						 
						
					} else {
						if(category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
							if(is_rmu){
								reserves-=amount;
								c.setReserves(-1*amount);
								//fiuTransaction-=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(0);
								//fiuBalance-=m.doRoundOff(amount*(advratio/100));
							}else{
								reserves-=amount;
								c.setReserves(-1*amount);
								fiuTransaction-=m.doRoundOff(amount*(advratio/100));
								c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
								fiuBalance-=m.doRoundOff(amount*(advratio/100));
							}
							
						}else{
							reserves-=amount;
							c.setReserves(-1*amount);
							fiuTransaction-=m.doRoundOff(amount*(advratio/100));
							c.setFiuTransaction(-1*m.doRoundOff(amount*(advratio/100)));
							fiuBalance-=m.doRoundOff(amount*(advratio/100));
						}
					}	
					c.setFiuBalance(fiuBalance);
					log.info("amount: "+amount);
					log.info("amount1: "+amount1);
					amount=(amount1<amount)?amount1:amount;
					log.info("amount to be computed for discount: "+amount);
					discountValue=m.doRoundOff(-1*getDiscountCharge(amount,blr,dcr,day));
					if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6a")){
						if(opmt!=0){	
							ClientActivities op = new ClientActivities();
							op.setDefinition("Over Payment");
							op.setRef("");
							op.setReceivables(0.00);
							overpayment+=opmt;
							op.setReserves(opmt);
							reserves+=opmt;
							op.setFiuTransaction(0.00);
							op.setFiuBalance(fiuBalance);
							list.add(op);							
						}					

					}						
					list.add(c);
					/*if(category.equalsIgnoreCase("6")&&!rs.getString("ref2").contentEquals("0")){
						try{
							Statement s = null;
							ResultSet r = null;
							s = new FactorConnection().getConnection().createStatement();
							String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
							log.info(sql);
							r = s.executeQuery(sql);
							if(r.next()){
								if(r.getDouble("partialAmount")!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CE Adjustment From RCT-ADV (Partial Payment)");
									op.setRef("");
									op.setReceivables(0.0);
									double partial = amount *((100-advratio)/100);
									op.setReserves(-partial);
									reserves -= partial;
									op.setFiuTransaction(partial);
									fiuTransaction+=partial;
									fiuBalance+=partial;
									op.setFiuBalance(fiuBalance);
									list.add(op);
									
								}
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				else if(category.equalsIgnoreCase("6a")&&!rs.getString("ref2").contentEquals("0")){
					try{
						Statement s = null;
						ResultSet r = null;
						s = new FactorConnection().getConnection().createStatement();
						String sql="select SUM(case when n_creditnoteamt =0 then n_invoiceamt else 0 end) as partialAmount,SUM(n_invoiceamt) from (select * from Receipts_bak where N_REFNO ="+rs.getString("ref2")+" )q1";
						log.info(sql);
						r = s.executeQuery(sql);
						if(r.next()){
							if(r.getDouble("partialAmount")!=0){
								ClientActivities op = new ClientActivities();
								op.setDefinition("CE Adjustment From RCT-REF (Partial Payment)");
								op.setRef("");
								op.setReceivables(0.0);
								double partial = amount *((100-advratio)/100);
								op.setReserves(-partial);
								reserves -= partial;
								op.setFiuTransaction(partial);
								fiuTransaction+=partial;
								fiuBalance+=partial;
								op.setFiuBalance(fiuBalance);
								list.add(op);
								
							}
						}
						
					}catch(Exception e){
						e.printStackTrace();
					}
				}*/
				}
				else if(category.equalsIgnoreCase("7b")){
					c.setDefinition("Dishonored Check");
					c.setReserves(0.00);					
					receivables+=amount-opmt;
					dshnrdChks+=amount-opmt;
					//fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
					//fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					if(is_rmu){
						c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)));
						fiuTransaction+=m.doRoundOff((amount-opmt));
						fiuBalance+=m.doRoundOff((amount-opmt));	//rdc08092010
					}else{
						c.setFiuTransaction(-1*m.doRoundOff((amount-opmt)*(advratio/100)));
						fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
						fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					}
					c.setReceivables(amount-opmt);
					c.setFiuTransaction(m.doRoundOff((amount-opmt)*(advratio/100)));
					c.setFiuBalance(fiuBalance);
					list.add(c);
					if(opmt!=0){	
						ClientActivities op = new ClientActivities();
						op.setDefinition("Reversal of OP");
						op.setRef("");
						op.setReceivables(0.00);
						op.setReserves(-1*opmt);
						reserves-=opmt;
						op.setFiuTransaction(0.00);
						op.setFiuBalance(fiuBalance);
						list.add(op);							
					}
					if(dcPayment!=0){
						ClientActivities dc = new ClientActivities();
						dc.setTransactionDate(null);
						dc.setDefinition("Reversal Discount Charge");
						dc.setReceivables(0.00);
						reserves+=dcPayment;
						dc.setReserves(1*dcPayment);
						//fiuTransaction-=dcPayment;
						dc.setFiuTransaction(0.00);
						dc.setFiuBalance(fiuBalance);
						dcCollected -= dcPayment;
						list.add(dc);
					}
					
					if(penaltyPayment !=0){
						ClientActivities pc = new ClientActivities();
						pc.setTransactionDate(null);
						pc.setDefinition("Reversal Penalty Charge");
						pc.setReceivables(0.00);
						reserves+=penaltyPayment;
						pc.setReserves(1*penaltyPayment);
						//fiuTransaction-=penaltyPayment;
						pc.setFiuTransaction(0.00);
						pc.setFiuBalance(fiuBalance);
						penaltyCollected -= penaltyPayment;
						list.add(pc);
					}
					//Unfactored Invoice
					ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
					Double unfactoredAmount= _ReceiptsDtlOtherService.sumAllDtlOther(Long.parseLong(c.getRef()));
					if(unfactoredAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal Unfactored Invoices");
						ua.setReceivables(0.00);
						reserves+=unfactoredAmount;
						ua.setReserves(1*unfactoredAmount);
						//fiuTransaction+=penaltyPayment;
						ua.setFiuTransaction(0.00);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					//Discount Charge
					Double dcAmount= _ReceiptsDtlOtherService.sumAllDtlOtherDC(Long.parseLong(c.getRef()));
					if(dcAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal RMU Discount Charge");
						ua.setReceivables(-1*dcAmount);
						receivables -= dcAmount;
						//reserves-=dcAmount;
						//ua.setReserves(-1*dcAmount);
						ua.setReserves(0);
						fiuTransaction-=dcAmount;
						fiuBalance -= dcAmount;
						ua.setFiuTransaction(-1*dcAmount);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
					//Penalty
					Double penaltyAmount= _ReceiptsDtlOtherService.sumAllDtlOtherPenalty(Long.parseLong(c.getRef()));
					if(penaltyAmount !=0){
						ClientActivities ua = new ClientActivities();
						ua.setTransactionDate(null);
						ua.setDefinition("Reversal RMU Penalty Charge");
						ua.setReceivables(-1*penaltyAmount);
						receivables -= penaltyAmount;
						//reserves-=penaltyAmount;
						//ua.setReserves(-1*penaltyAmount);
						ua.setReserves(0);
						fiuTransaction-=penaltyAmount;
						fiuBalance -= penaltyAmount;
						ua.setFiuTransaction(-1*penaltyAmount);
						ua.setFiuBalance(fiuBalance);
						//penaltyCollected += penaltyPayment;
						list.add(ua);
					}
//					if (amount2 !=0){
//						ClientActivities receiptDCReversal = new ClientActivities();
//						receiptDCReversal.setDefinition("Reversal of DC-Receipt");
//						receiptDCReversal.setRef("");
//						receiptDCReversal.setReceivables(0.00);
//						receiptDCReversal.setReserves(-1*amount2);
//						reserves-=amount2;
//						receiptDCReversal.setFiuTransaction(0.00);
//						receiptDCReversal.setFiuBalance(fiuBalance);
//						list.add(receiptDCReversal );
//					}
					
				}
				else if(category.equalsIgnoreCase("7c")){
					c.setDefinition("Cancelled CN");
					receivables+=amount-opmt;
					cnCancelled+=amount;
					c.setReceivables(amount-opmt);
					reserves+=amount;
					c.setReserves(amount);
					fiuTransaction+=m.doRoundOff(amount*(advratio/100));
					c.setFiuTransaction(m.doRoundOff(amount*(advratio/100)));
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					c.setFiuBalance(fiuBalance);
					list.add(c);
				}
				else if(category.equalsIgnoreCase("9")||category.equalsIgnoreCase("9a")||category.equalsIgnoreCase("9b")){
					
					if(category.equalsIgnoreCase("9a"))c.setDefinition("Penalty Charge");
					if(category.equalsIgnoreCase("9b"))c.setDefinition("PD - Discount Charge");
					if(type.equalsIgnoreCase("1"))c.setDefinition("Refund");
					if(type.equalsIgnoreCase("2"))c.setDefinition("Refund with Overpayment");
					if(type.equalsIgnoreCase("3"))c.setDefinition("Refund - Unfactored Invoice");
					if(type.equalsIgnoreCase("4"))c.setDefinition("Refund - Prev CN");	
					
					c.setReceivables(0.00);
					reserves-=amount;
					c.setReserves(-1*amount);						
					c.setFiuTransaction(0.00);	
					c.setFiuBalance(fiuBalance);
					if(!category.equalsIgnoreCase("9a")&&!category.equalsIgnoreCase("9b")){
						refunds+=amount;
						discountValue=	amount2;	
						
					}
					else
					{
						if(category.equalsIgnoreCase("9a"))
							penaltyCollected += amount ;
						else
							pastDueCollected += amount;
						
						c.setTransactionDate(null);
						c.setRef(null);
					}
					
					list.add(c);
					if(type.equalsIgnoreCase("1")){
						try{
							Statement s = null;
							ResultSet r = null;
							
							s= new FactorConnection().getConnection().createStatement();
							String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
							"on rh.N_REFNO=rd.N_REFNO inner join refund ref on	"+
							"ref.N_REFNO=rh.n_refpaymentno inner join "+
							"Invoice inv on rd.N_INVNO=inv.n_invno	"+
							"where rh.C_CLNTCODE='"+clientCode+"' and ref.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
							r= s.executeQuery(query);
							
							if(r.next()){
								double val = r.getDouble("amount")*((100-advratio)/100);
								if(val!=0){
									ClientActivities op = new ClientActivities();
									op.setDefinition("CN Adjustment From Refund");
									op.setRef("");
									op.setReceivables(0.00);
									op.setReserves(0.00);
									op.setFiuTransaction(val);
									fiuTransaction +=val;
									fiuBalance +=val;
									op.setFiuBalance(fiuBalance);
									list.add(op);
								}
							}
							
							}
							catch(Exception e){
								e.printStackTrace();
							}	
					}
				}	
				
				if(category.equalsIgnoreCase("2")||
				   category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||
				  (category.equalsIgnoreCase("9")&&amount2!=0)
				)
				{
					ClientActivities c3 = new ClientActivities();
				//rdc 08042010	
						c3.setDefinition("Discount Charge");
						c3.setRef("");
						if(category.equalsIgnoreCase("9")&&(type.equalsIgnoreCase("2")||type.equalsIgnoreCase("3")||type.equalsIgnoreCase("4"))){
						}
						else{
							c3.setReceivables(0.00);
						}					
						if(category.equalsIgnoreCase("2") 		
						   ||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")
						   ||category.equalsIgnoreCase("9")){
						   	if (category.equalsIgnoreCase("9")) dcCollected+=amount2;
							if (category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")){ 
								if (amount2>0) {
									c3.setReserves(-1*amount2);
								} else {
									c3.setReserves(amount2);
								}
								reserves-=(amount2);
								fiuTransaction+=amount2;
								c3.setFiuTransaction(amount2); 
								if (category.equalsIgnoreCase("2")) {
									discountCharges=amount2;
									dcCollected+=amount2;
								}
							} else {
								c3.setReserves(-1*discountValue);
								log.info("reserves before adding discount charges: "+reserves);
								reserves+=(-1*discountValue);
								log.info("reserves before adding discount charges: "+reserves);
								
								if (!category.equalsIgnoreCase("9")) {
									c3.setFiuTransaction(discountValue);
									fiuTransaction+=discountValue;
									fiuBalance+=discountValue;
								} else {
									c3.setFiuTransaction(0.00);
								}
							}
							
						}
						else{
							c3.setReserves(0.00); 	//rdc07122010
							c3.setFiuTransaction(0.00);
						}
						c3.setFiuBalance(fiuBalance);
						list.add(c3);	
				}
				rset = rs.next();	//08282010
			}
			
			if(!rset){
				//rdc 08092610 ..... 
				Date today = DateHelper.parse(asOfDate);
				Map map = new HashMap();
				map.put("ADVRATIO", advratio/100.00);
				map.put("BLR", blr/100.00);
				map.put("DCR", dcr/100.00);
				map.put("C_CLNTCODE", clientCode);
				map.put("asOfDate", asOfDate);
				map.put("today", DateHelper.parse(DateHelper.format(today)));
						
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				dcAccruals= m.doRoundOff(invoiceDAO.getDCAccrual2(map));
				log.info("dcAccruals:"+dcAccruals );
				log.info("receivables:"+receivables );
				log.info("reserves:"+reserves );
				log.info("fiuBalance:"+fiuBalance );
				ClientActivities c6 = new ClientActivities();
				
				AccountingMaintenanceService AMS  = AccountingMaintenanceService.getInstance();
				 pastDueInvoices = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(n_penaltyamount),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
				 dcAccruals = dcAccruals+pastDueInvoices;
				 
				reserves+=(-1*dcAccruals);
					fiuBalance+=dcAccruals;	//rdc08092010
					if (dcAccruals>0) {
						c6.setReserves(-1*dcAccruals);
					} else {
						c6.setReserves(dcAccruals);
					}
					c6.setFiuBalance(fiuBalance); 
					discountCharges=dcAccruals;
				
				pastDueFR = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(N_INVOICEAMT),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
				/*if(pastDueInvoices!=0){
					ClientActivities c7 = new ClientActivities();	
					c7.setDefinition("Past Due Interest");
					c7.setRef("");
					c7.setTransactionDate(new Date(asOfDate));	
					c7.setReceivables(0.00);
					c7.setFiuTransaction(0.00);	
					c7.setFiuBalance(fiuBalance);
					reserves-=pastDueInvoices;
					c7.setReserves(-1*pastDueInvoices);
					list.add(c7);
				}*/
				c6.setDefinition("Discount Charges - Accrual");
				c6.setRef("");
				c6.setTransactionDate(new Date(asOfDate));	
				c6.setReceivables(0.00);
				c6.setFiuTransaction(0.00);			
				c6.setTotalReceivables(receivables);
				c6.setTotalReserves(reserves);
				c6.setTotalFiuTransaction(fiuTransaction);
				c6.setTotalFiuBalance(fiuBalance);
				c6.setInvoices(invoices);
				c6.setServiceCharges(serviceCharges);
				c6.setAdvances(advances);
				c6.setReceipts(receipts);
				c6.setCreditNotes(creditNotes);
				c6.setRefunds(refunds);
				c6.setDiscountCharges(discountCharges);
				c6.setDcOnCashDelays(dcOnCashDelays);
				c6.setSetupFee(setupFee);
				c6.setDocStamp(docStamp);
				c6.setDcCollected(dcCollected);
				c6.setOverpayment(overpayment);
				c6.setReceiptAdvance(rctAdvance);
				c6.setReceiptRefund(rctRefund);
				c6.setDshnrdChks(dshnrdChks);
				c6.setCnCancelled(cnCancelled);
				c6.setPenaltyCollected(penaltyCollected);
				c6.setPastDueCollected(pastDueInvoices);
				c6.setPastDueFR(pastDueFR);
				list.add(c6);
				log.info("total in");
				log.info("8-setupFee/dcCollected:" + setupFee + "/" + dcCollected);
				log.info("doc stamp amount: " + docStamp);
				//end 08092010
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return list;		
	}
	
	public  ClientActivities getClientActivities3(String clientCode,String asOfDate)
	{		 
		List<ClientActivities> list = new ArrayList<ClientActivities>();		
			String sSQL = "SELECT     * FROM (	"+
"	SELECT	"+
"		N_INVOICEAMT AS AMOUNT, "+
"		D_TRANSACTIONDATE,"+
"		0.00 AS AMOUNT2, "+
"		N_ADVANCEDRATIO AS ADVRATIO,  "+
"		0 AS ref2, '1' AS category , "+
"		0 as cashDelay , '' AS type, "+
"		0.00 AS amount1, 0 AS overPayment, i.N_SVCCHGTYPE as scType   "+
"	FROM	Invoice i INNER JOIN dbCIF.dbo.CLIENT c ON i.C_CLNTCODE = c.C_CLNTCODE  "+
"	WHERE	i.C_STATUS IN('2','3','4','5','6') "+
"			AND (i.C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	UNION  "+
"	SELECT "+
"		N_AMOUNT AS AMOUNT, "+
"		D_TRANSACTIONDATE,"+
"		0.00 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,   "+
"		c_debit AS REF2,"+
"		'1a' AS CATEGORY , "+
"		0 AS CASHDELAY, "+
"		C_ADJREC+C_ADJRES+C_ADJFIU+C_ADJFIUBAL+a2.C_ADJDESC AS TYPE, "+
"		0.00 AS AMOUNT1, "+
"		0 AS OVERPAYMENT ,'' as scType    "+
"	FROM	ADJUSTMENT a INNER JOIN ADJUSTMENTTYPE a2 ON a.C_ADJCODE = a2.C_ADJCODE  "+
"	WHERE	C_STATUS = '2'AND B_INCLUDED = 1  "+
"			AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	UNION  "+
"	SELECT	"+
"		N_ADVAMT AS AMOUNT, "+
"		D_TRANSACTIONDATE,"+
"		N_DISCCHG1 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,  "+
"		'0' AS ref2,'2' AS category , "+
"		0 as cashDelay, "+
"		C_TYPE AS type, "+
"		0.00 AS amount1, "+
"		0 AS overPayment ,'' as scType  "+
"	FROM	Advances "+
"	WHERE	C_TYPE = 1 AND C_STATUS IN (2,4)  "+
"			AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	UNION  "+
"	select ISNULL(N_DISCCHG2,0)+ISNULL(N_PDINTEREST,0)+ISNULL(N_PENALTYCHG,0)as amount,"+
"		D_TRANSACTIONDATE,"+
"		0 AS AMOUNT2, "+
"			0.00 AS ADVRATIO,   "+
"			'0' AS ref2,"+
"			'2a' AS category , "+
"			0 as cashDelay, "+
"			'' AS type, "+
"			0.00 AS amount1, "+
"			0 AS overPayment,'' as scType  "+
"	from("+
"		SELECT	"+
"			N_DISCCHG2,"+
"			N_PDINTEREST,"+
"			 N_PENALTYCHG,"+
"		D_TRANSACTIONDATE"+
"		FROM	Advances "+
"		WHERE	(ISNULL(N_DISCCHG2,0) <> 0 OR ISNULL(N_PDINTEREST,0)<>0 OR ISNULL(N_PENALTYCHG,0)<>0) "+
"				AND C_TYPE = 1 AND  C_STATUS IN (2,4)  "+
"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"				+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')"+
"	)q1"+
"	UNION  "+
"	SELECT	"+
"		N_ADVAMT AS AMOUNT, "+
"		D_TRANSACTIONDATE,"+
"		N_DISCCHG1 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,  "+
"		'0' AS ref2,"+
"		'3' AS category , "+
"		0 as cashDelay, "+
"		C_TYPE AS type, "+
"		0.00 AS amount1, "+
"		0 AS overPayment,'' as scType   "+
"	FROM	Advances "+
"	WHERE	C_TYPE = 2 "+
"			AND  C_STATUS IN (2,4)  "+
"			AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	UNION  "+
"	SELECT	"+
"		N_ADVAMT AS AMOUNT, "+
"		D_TRANSACTIONDATE,"+
"		N_DISCCHG1 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,  "+
"		'0' AS ref2,"+
"		'3a' AS category , "+
"		0 as cashDelay, "+
"		C_TYPE AS type, "+
"		0.00 AS amount1, "+
"		0 AS overPayment ,'' as scType  "+
"	FROM	Advances "+
"	WHERE	C_TYPE = 3 AND  C_STATUS IN (2,4)  "+
"			AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	UNION  "+
"	SELECT	" +
"		sum(amount) as amount," +
"		'' as D_TRANSACTIONDATE,"+
"		0 as amount2," +
"		0 as advratio," +
"		'' as ref2," +
"		'4' as category," +
"		cashdelay," +
"		'' as type," +
"		sum(amount1) as amount1," +
"		sum(overPayment) as overPayment,'' as scType "+
"	FROM(SELECT	"+
"			N_AMOUNT AS AMOUNT, "+
"			0.00 AS AMOUNT2, "+
"			0.00 AS ADVRATIO,  "+
"			0 AS ref2, "+
"			D_TRANSACTIONDATE,"+
"			'4' AS category , "+
"			N_CASHDELAY as cashDelay, "+
"			C_RECEIPTTYPE AS type, "+
"			ISNULL(N_TOTINVAMT,0.00) AS amount1, "+
"			N_OPAMT AS overPayment,'' as scType    "+
"		FROM	ReceiptsHdr "+
"		WHERE	C_RECEIPTTYPE IN (1,2) AND (C_STATUS IN (1,2,4))    "+
"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"				+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')   "+
"	)q1	"+
"	group by q1.cashDelay"+
""+
"	UNION  "+
"	SELECT "+
"		AMOUNT,"+
"		a.D_TRANSACTIONDATE,"+
"		AMOUNT2, "+
"		ADVRATIO,  "+
"		REF2,"+
"		CATEGORY, "+
"		CASHDELAY, "+
"		TYPE,"+
"		AMOUNT1,"+
"		OVERPAYMENT, SCTYPE  "+
"	FROM	(SELECT "+
"				rdinv.C_CLNTCODE, "+
"				rdinv.C_CUSTCODE,"+
"				rdinv.D_TRANSACTIONDATE,"+
"				D_FULLYPAIDDATE, "+
"				ISNULL(SUM(N_RECEIPTAMT),0) AS AMOUNT, "+
"				0.00 AS AMOUNT2, "+
"				0.00 AS ADVRATIO,  "+
"				CAST(rd2.N_REFNO  AS NVARCHAR) AS REF, "+
"				'0' AS REF2,"+
"				'5A' AS CATEGORY , "+
"				0 AS CASHDELAY, "+
"				'' AS TYPE, "+
"				0.00 AS AMOUNT1, "+
"				0 AS OVERPAYMENT,'' as scType    "+
"			FROM RECEIPTSDTL rd2 INNER JOIN(  "+
"				SELECT DISTINCT "+
"					rh.C_CLNTCODE, "+
"					rh.C_CUSTCODE,"+
"					rd.C_INVOICENO,"+
"					rd.N_INVNO,"+
"					rh.D_TRANSACTIONDATE,D_FULLYPAIDDATE "+
"				FROM RECEIPTSDTL rd	INNER JOIN (   "+
"					SELECT	"+
"						C_CLNTCODE, "+
"						C_CUSTCODE,"+
"						CAST(N_REFNO AS NVARCHAR) AS REF, "+
"						D_TRANSACTIONDATE  "+
"					FROM	RECEIPTSHDR "+
"					WHERE	C_RECEIPTTYPE IN (1,2,3,4) AND (C_STATUS IN (2,4))   "+
"							AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"							+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"						) AS rh ON rd.N_REFNO = rh.REF  "+
"				INNER JOIN "+
"					INVOICE inv ON rd.C_INVOICENO = inv.C_INVOICENO and rd.N_INVNO = inv.N_INVNO   "+
"					AND inv.C_STATUS IN (5,6)    "+
"				) AS rdinv ON rd2.C_INVOICENO = rdinv.C_INVOICENO  AND rd2.N_INVNO = rdinv.N_INVNO  "+
"			INNER JOIN  "+
"				RECEIPTSHDR rh2 ON rd2.N_REFNO=rh2.N_REFNO AND rh2.C_RECEIPTTYPE IN (3,4)  "+
"			GROUP BY rd2.N_REFNO,rdinv.D_TRANSACTIONDATE,rdinv.C_CLNTCODE, rdinv.C_CUSTCODE,D_FULLYPAIDDATE  "+
"			) a "+
"	WHERE  CONVERT(VARCHAR(10), a.D_TRANSACTIONDATE, 101) =  CONVERT(VARCHAR(10), a.D_FULLYPAIDDATE, 101)  "+
"	UNION  "+
"	select " +
"		sum(amount) as amount," +
"		'' as D_TRANSACTIONDATE,"+
"		0 as amount2," +
"		0 as advratio," +
"		'' as ref2," +
"		'6' as category," +
"		cashdelay," +
"		'' as type," +
"		sum(amount1) as amount1," +
"		sum(overPayment) as overPayment,'' as scType "+
"	 from("+
"		SELECT	"+
"			N_AMOUNT AS AMOUNT, "+
"			N_CASHDELAY as cashDelay,"+
"			ISNULL(N_TOTINVAMT,0.00) AS amount1, "+
"			N_OPAMT AS overPayment,  "+
"			D_TRANSACTIONDATE"+
"		FROM	ReceiptsHdr "+
"		WHERE	C_RECEIPTTYPE IN(3,4) AND (C_STATUS IN (2,4))  "+
"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"				+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	)q1"+
"	group by q1.cashDelay  "+
"	UNION  "+
"	SELECT	 "+
"		cn.N_AMOUNT AS AMOUNT,  "+
"		cn.D_TRANSACTIONDATE,"+
"		0.00 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,   "+
"		0 AS ref2, "+
"		'6b' AS category , "+
"		0 as cashDelay, "+
"		'' AS type, "+
"		0.00 AS amount1, "+
"		0 AS overPayment,  '' as scType  "+
"	FROM	CreditNote cn INNER JOIN RECEIPTSHDR rh ON cn.C_RECEIPTNO = rh.N_REFNO  "+
"	WHERE	cn.C_STATUS IN(1,2) AND rh.C_STATUS <> 3  "+
"			AND (cn.C_CLNTCODE ='" + clientCode + "') AND (cn.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
/*"	UNION  "+
"	SELECT	"+
"		N_AMOUNT AS AMOUNT, "+
"		D_TRANSACTIONDATE,"+
"		0.00 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,   "+
"		0 AS ref2, "+
"		'7a' AS category , "+
"		N_CASHDELAY as cashDelay, "+
"		C_RECEIPTTYPE AS type, "+
"		0.00 AS amount1, "+
"		N_OPAMT AS overPayment  "+
"	FROM	ReceiptsHdr "+
"	WHERE	C_RECEIPTTYPE = 1 AND C_STATUS = 3  "+
"			AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	UNION  "+
"	SELECT	"+
"		c.N_AMOUNT AS AMOUNT, "+
"		c.D_TRANSACTIONDATE,"+
"		0.00 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,   "+
"		0 AS ref2, "+
"		'7a2' AS category , "+
"		N_CASHDELAY as cashDelay, "+
"		C_RECEIPTTYPE AS type, "+
"		0.00 AS amount1, "+
"		0.00 AS overPayment  "+
"	FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno  "+
"	WHERE	C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3   "+
"			AND (c.C_CLNTCODE ='" + clientCode + "') AND (c.D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	UNION  "+
"	SELECT	 "+
"		N_AMOUNT AS AMOUNT, "+
"		(CASE WHEN D_DATEBOUNCED IS NOT NULL THEN D_DATEBOUNCED ELSE D_TRANSACTIONDATE END) AS D_TRANSACTIONDATE,"+
"		0.00 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,   "+
"		0 AS ref2, "+
"		'7b' AS category , "+
"		N_CASHDELAY as cashDelay, "+
"		C_RECEIPTTYPE AS type, "+
"		0.00 AS amount1, "+
"		N_OPAMT AS overPayment  "+
"	FROM	ReceiptsHdr "+
"	WHERE	C_RECEIPTTYPE = 1 AND C_STATUS = 3  "+
"			AND (C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	UNION  "+
"	SELECT	"+
"		c.N_AMOUNT AS AMOUNT, "+
"		r.D_TRANSACTIONDATE,"+
"		0.00 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,   "+
"		0 AS ref2, "+
"		'7c' AS category , "+
"		N_CASHDELAY as cashDelay, "+
"		C_RECEIPTTYPE AS type, "+
"		0.00 AS amount1, "+
"		0.00 AS overPayment  "+
"	FROM	ReceiptsHdr r inner join creditnote c on c.c_receiptno = r.n_refno  "+
"	WHERE	C_RECEIPTTYPE = 1 AND c.C_STATUS = 3 and r.C_STATUS = 3   "+
"			AND (c.C_CLNTCODE ='" + clientCode + "') AND (D_DATEBOUNCED BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+*/
"	UNION  "+
"	SELECT	"+
"		N_REFAMT AS AMOUNT, "+
"		D_TRANSACTIONDATE,"+
"		N_DISCCHG AS AMOUNT2, "+
"		0.00 AS ADVRATIO,  "+
"		0 AS ref2, "+
"		'9' AS category , "+
"		0 as cashDelay, "+
"		C_TYPE AS type, "+
"		ISNULL(N_INELIGIBLEREC,0) AS amount1, "+
"		0 AS overPayment ,  '' as scType   "+
"	FROM	Refund"+
"	WHERE	C_STATUS IN (2,4)  "+
"			AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"			+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	union"+
"	select "+
"		ISNULL(N_PDINTEREST,0)+ISNULL(N_PENALTYCHG,0) as amount,"+
"		D_TRANSACTIONDATE,"+
"		0 AS AMOUNT2, "+
"		0.00 AS ADVRATIO,   "+
"		0 AS ref2, "+
"		'9b' AS category , "+
"		0 as cashDelay, "+
"		'' AS type, "+
"		0 AS amount1, "+
"		0 AS overPayment,  '' as scType    "+
"	from("+
"		SELECT	"+
"			N_PDINTEREST,"+
"			N_PENALTYCHG, "+
"		D_TRANSACTIONDATE"+
"		FROM	Refund "+
"		WHERE	C_STATUS IN (2,4) AND (ISNULL(N_PDINTEREST,0) <> 0 OR ISNULL(N_PENALTYCHG,0) <>0) "+
"				AND (C_CLNTCODE ='" + clientCode + "') AND (D_TRANSACTIONDATE BETWEEN CONVERT(varchar, CAST(MONTH('" + asOfDate + "') AS nvarchar)   "+
"				+  '/01/'  + CAST(YEAR('" + asOfDate + "') AS nVARCHAR), 101) AND '" + asOfDate + "')  "+
"	)q1"+
" "+
"	) a  "+
"			ORDER BY category asc" ;	 
	
		 
		
		Statement stmt=null;
		ResultSet rs=null;
		ClientActivities c6 = new ClientActivities();
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			
			double dcr=0.00;
			double scr=0.00;
			double blr = 0.00;
			String blrCode="";
			int day=0;
			int cashDelay=0;
			String custCode="";
			String customerName="";

			double serviceValue=0.00;
			double discountValue=0.00;
			double dcCashDelayValue=0.00;

			//Totals
			double receivables=0.00;
			double reserves=0.00;
			double fiuTransaction=0.00;
			double fiuBalance=0.00;

			double discountCharges=0.00;
			 			 
			double dcCollected=0.00;
			double dcAccruals=0.00;
			double advratio=0.00;
			double iniVal=0.00;
			int withTrans = 0;
			double lastAccruals = 0.00;
			 
			String type="";
			String branchCode="";

			double balance=0.00;

			ListIterator<Client> clientList = getAllClientDetails(clientCode).listIterator();
			while(clientList.hasNext()){
				ClientActivities header = new ClientActivities();
				Client client = (Client)clientList.next();
				dcr=m.doRoundOff(client.getN_Dcr());
				scr=m.doRoundOff(client.getN_Scr());
				advratio =m.doRoundOff(client.getN_AdvRatio());
				branchCode = client.getC_BranchCode();
				blrCode = client.getC_BlrTypeCode();
				BLRFileDAO blrDao = new BLRFileDAO();
				ListIterator<BLRFile> blrFileList = blrDao.getBLRFile(clientCode, asOfDate).listIterator();
				while(blrFileList.hasNext()){
					BLRFile blrFile = (BLRFile) blrFileList.next();
					blr = m.doRoundOff(blrFile.getBlr());
					//header.setBlrFile(blrFile);
					break;
				}
				
				String strMMM = DateUtils.getLastMonthMMM(asOfDate);
				strMMM = "N_" + strMMM +"ACC";
				
				Map map2 = new HashMap();
				map2.put("C_CLNTCODE", clientCode);
				map2.put("MMM", strMMM);		
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				Double dcAccrual= invoiceDAO.getLastAccrual(map2);
				dcAccruals= dcAccrual!=null?m.doRoundOff(dcAccrual):0;
				MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
				ListIterator mbList =mbDAO.getMonthBalClntCodeAsOfDate(clientCode,asOfDate).listIterator();						
				while(mbList.hasNext()){

					MonthlyBalances mb = (MonthlyBalances)mbList.next();
					header.setReceivables(m.doRoundOff(mb.getMonthReceivables().doubleValue()));
					header.setReserves(m.doRoundOff(mb.getMonthReserves().doubleValue()));
					if (m.doRoundOff(mb.getMonthFIU().doubleValue())>iniVal) {
						fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue() + dcAccruals );		
						header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
					} else {
						if ((m.doRoundOff(mb.getMonthFIU().doubleValue())==iniVal) && dcAccruals>0){
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue()+dcAccruals);
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue())+dcAccruals);
						}else{
							fiuBalance=m.doRoundOff(mb.getMonthFIU().doubleValue());
							header.setFiuBalance(m.doRoundOff(mb.getMonthFIU().doubleValue()));
						}
					}

					header.setFiuTransaction(m.doRoundOff(mb.getMonthFIU().doubleValue()));
					receivables=header.getReceivables();
					reserves=header.getReserves();
					fiuTransaction=header.getFiuTransaction();
					
					if((dcAccruals>0.00) && (fiuTransaction==0.00)){
						balance=header.getFiuTransaction()+dcAccruals;
					}else{
						balance=header.getFiuTransaction();
					} 
					break;
				}
				list.add(header);
				break;				
			}
			
			if ((fiuTransaction>iniVal)||(reserves>iniVal)||receivables>iniVal) {
				
				if((dcAccruals>0.00) && (fiuTransaction==0.00)){
					fiuBalance=balance-dcAccruals;
				}else{
				    fiuBalance-=dcAccruals;
				}
				reserves+=dcAccruals;
			} 
				
			dcAccruals=0.00;
				
			boolean rset = rs.next();	
			
			while(rset){
				 
				type=rs.getString("type");
				double amount =m.doRoundOff(rs.getDouble("AMOUNT")); 
				double amount1=m.doRoundOff(rs.getDouble("amount1"));
				double amount2 =m.doRoundOff(rs.getDouble("AMOUNT2"));	//rdc07152010
				double opmt = m.doRoundOff(rs.getDouble("overPayment"));
				//added 6/28/2016 for receipts dc and penalty
				double dcPayment = m.doRoundOff(rs.getDouble("dcPayment"));
				double penaltyPayment = m.doRoundOff(rs.getDouble("penaltyPayment"));
				String scType = rs.getString("scType")!=null? rs.getString("scType"):"2"; //cvg 02132017
				String ref2 = rs.getString("ref2").trim();	//rdc07152010
				String date1 = sdf.format(rs.getDate("D_TRANSACTIONDATE"));				
				String category = rs.getString("category").trim();
				if(date1.equals("")){
					if (date1.equals(asOfDate)) {
						day = 1;
					} else {
						day = DateHelper.getDayPerTransaction(date1, asOfDate);
					}
				}
				cashDelay = rs.getInt("cashDelay");
				
				if(category.equalsIgnoreCase("1")){
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
					receivables+=amount;
					reserves+=amount;	

					if (scType.equals("1")){ //added cvg02132017
						serviceValue=m.doRoundOff(amount*(scr/100)*(advratio/100));
					}else{
						serviceValue=m.doRoundOff(amount*(scr/100)); //old
					}//end
					reserves-=serviceValue;						
					fiuTransaction+=serviceValue;

				}
				else if(category.equalsIgnoreCase("1a")){
					String strTypeRec =  type.substring(0, 1);
					String strTypeRes = type.substring(1, 2);
					String strTypeFiu = type.substring(2, 3);
					String strTypeFiuBal = type.substring(3, 4);
					String strDesc = type.substring(4);
					
					if (ref2.equals("1")){
						dcCollected+=amount;
					} else {
						dcCollected-=amount;
					}
					
					//effect on receivables
					if (strTypeRec.equals("1")) {
						receivables+=amount;
					} else if (strTypeRec.equals("2")) {
						receivables-=amount;
					} 
					//effect on reserves
					if (strTypeRes.equals("1")) {
						reserves+=amount;
					} else if (strTypeRes.equals("2")) {
						reserves-=amount;
					}
					//effect on fiu
					if (strTypeFiu.equals("1")) {
						fiuTransaction+=amount;
					} else if (strTypeFiu.equals("2")) {
						fiuTransaction-=amount;
					} 
					//effect on fiu balance
					if (strTypeFiuBal.equals("1")) {
						fiuBalance+=amount;
					} else if (strTypeFiuBal.equals("2")) {
						fiuBalance-=amount;
					}			
				}else if(category.equalsIgnoreCase("client")){
					//c.setDefinition("Client Reversal");
					//c.setReceivables(0.0);
					//c.setReserves(0.0);
					//c.setFiuTransaction(amount);
					//reserves-=amount;
					//c.setReserves(-1*amount);
					//fiuTransaction +=amount;
					//fiuBalance +=amount;
					//c.setFiuBalance(fiuBalance);
					//list.add(c);	
				}
				else if(category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||category.equalsIgnoreCase("2a")||category.equalsIgnoreCase("2b")||category.equalsIgnoreCase("2c")){											
						
						reserves-=amount;
						fiuTransaction+=amount;
						
						if(category.equalsIgnoreCase("2")) {
							discountValue=m.doRoundOff(getDiscountCharge(amount2,blr,dcr,day));
							try{
								Statement s = null;
								ResultSet r = null;
								
								s= new FactorConnection().getConnection().createStatement();
								String query =" select ISNULL(SUM(rd.N_RECEIPTAMT),0) as amount from ReceiptsHdr rh inner join receiptsdtl rd	"+
								"on rh.N_REFNO=rd.N_REFNO inner join Advances adv on	"+
								"adv.N_REFNO=rh.n_advpaymentno inner join "+
								"Invoice inv on rd.N_INVNO=inv.n_invno	"+
								"where rh.C_CLNTCODE='"+clientCode+"' and adv.N_REFNO="+rs.getString("ref")+" and inv.D_FULLYPAIDDATE is not null";
								r= s.executeQuery(query);
								
								if(r.next()){
									double val = r.getDouble("amount")*((100-advratio)/100);
									if(val!=0){
										ClientActivities op = new ClientActivities();
										op.setDefinition("CN Adjustment From Advance");
										op.setRef("");
										op.setReceivables(0.00);
										op.setReserves(0.00);
										op.setFiuTransaction(val);
										fiuTransaction +=val;
										fiuBalance +=val;
										op.setFiuBalance(fiuBalance);
										list.add(op);
									}
								}
								
								}
								catch(Exception e){
									e.printStackTrace();
								}	
							
						} else if(category.equalsIgnoreCase("3")) {
								/*discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,1));	
								dcCollected+=discountValue;*/
						} else if(category.equalsIgnoreCase("3a")) {
							discountValue=m.doRoundOff(getDiscountCharge(amount,blr,dcr,day));
						}
						withTrans = 1;
						
				}	

				else if(category.equalsIgnoreCase("4")||category.equalsIgnoreCase("7a")){
						receivables-=amount-opmt;
						fiuTransaction-=m.doRoundOff((amount-opmt)*(advratio/100));
						fiuBalance-=m.doRoundOff((amount-opmt)*(advratio/100));
						
						if(opmt!=0){	
							reserves+=opmt;			
						}				
				}
				else if(category.equalsIgnoreCase("5a")){
					fiuTransaction+=amount*m.doRoundOff((100-advratio)/100);	
					fiuBalance+=amount*m.doRoundOff((100-advratio)/100);
					/*ClientActivities pp = new ClientActivities();
					if(ref2.contentEquals("3")||ref2.contentEquals("4"))
					{
								if(ref2.contentEquals("3")){
									pp.setDefinition("CN Adjustment from Advance");
								}
								else if(ref2.contentEquals("4")){
									pp.setDefinition("CN Adjustment from Refund");
								}
					}
					else{
						pp.setDefinition("Previous Partial Payment");
					//pp.setRef(rs.getString("ref"));
					pp.setReceivables(0.00);
					pp.setReserves(0.00);
					fiuTransaction+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuTransaction(amount*m.doRoundOff((100-advratio)/100));	
					fiuBalance+=amount*m.doRoundOff((100-advratio)/100);
					pp.setFiuBalance(fiuBalance);
					list.add(pp);}*/
				}

				else if(category.equalsIgnoreCase("6")||category.equalsIgnoreCase("6b")||category.equalsIgnoreCase("7a2")){
					
					receivables-=amount-opmt;
					if(category.equalsIgnoreCase("6")) {
						fiuTransaction-=amount-opmt;
						fiuBalance-=amount-opmt;
						if(opmt!=0){	
							reserves+=opmt;						
						}	
					} else {
						reserves-=amount;
						fiuTransaction-=m.doRoundOff(amount*(advratio/100));
						fiuBalance-=m.doRoundOff(amount*(advratio/100));
					}	
					 
					 						
				}
				else if(category.equalsIgnoreCase("7b")){				
					receivables+=amount-opmt;
					fiuTransaction+=m.doRoundOff((amount-opmt)*(advratio/100));
					fiuBalance+=m.doRoundOff((amount-opmt)*(advratio/100));	//rdc08092010
					if(opmt!=0){	
						reserves-=opmt;			
					}					
				}
				else if(category.equalsIgnoreCase("7c")){
					receivables+=amount-opmt;
					reserves+=amount;
					fiuTransaction+=m.doRoundOff(amount*(advratio/100));
					fiuBalance+=m.doRoundOff(amount*(advratio/100));
				}
				else if(category.equalsIgnoreCase("9")||category.equalsIgnoreCase("9a")||category.equalsIgnoreCase("9b")){
					reserves-=amount;
					if(!category.equalsIgnoreCase("9a")&&!category.equalsIgnoreCase("9b")){
						discountValue=	amount2;	
					}
					
				}	
				
				if(category.equalsIgnoreCase("2")||
				   category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")||
				  (category.equalsIgnoreCase("9")&&amount2!=0)
				)
				{
				
						if(category.equalsIgnoreCase("2") 		
						   ||category.equalsIgnoreCase("3")||category.equalsIgnoreCase("3a")
						   ||category.equalsIgnoreCase("9")){
						   	if (category.equalsIgnoreCase("9")) dcCollected+=amount2;
							if (category.equalsIgnoreCase("2")||category.equalsIgnoreCase("3")){ 
								reserves-=(amount2);
								fiuTransaction+=amount2;
								if (category.equalsIgnoreCase("2")) {
									discountCharges=amount2;
									dcCollected+=amount2;
								}
							} else {
								reserves+=(-1*discountValue);
								if (!category.equalsIgnoreCase("9")) {
									fiuTransaction+=discountValue;
									fiuBalance+=discountValue;
								} 
							}
							
						}	
				}
				
				rset = rs.next();
			}
			
			if(!rset){ 
				Date today = DateHelper.parse(asOfDate);
				Map map = new HashMap();
				map.put("C_CLNTCODE", clientCode);
				map.put("asOfDate", asOfDate);
				
						
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				
				AccountingMaintenanceService AMS  = AccountingMaintenanceService.getInstance();
				dcAccruals = Double.parseDouble((AMS.queryForObject("SELECT DBO.GetRefundDC('"+clientCode+"','"+asOfDate+"')")).toString());
				c6.setDcAccrual(dcAccruals);
				Double pastDueInvoices = Double.parseDouble((AMS.queryForObject("SELECT ISNULL(SUM(n_penaltyamount),0) FROM dbo.Pencharge('"+clientCode+"','"+branchCode+"','PDI','"+asOfDate+"')")).toString());
				 dcAccruals = dcAccruals+pastDueInvoices;
				 
				reserves+=(-1*dcAccruals);
					fiuBalance+=dcAccruals;	
					discountCharges=dcAccruals;
				
				c6.setTotalReceivables(receivables);
				c6.setTotalReserves(reserves);
				c6.setTotalFiuBalance(fiuBalance);
				c6.setDiscountCharges(discountCharges);
				c6.setDcCollected(dcCollected);

				list.add(c6);
				 
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return c6;		
	}
	
	public Map getDelinquentFromClient(String N_REFNO){
		Map map= new HashMap();
		try{
			Statement stmt=null;
			ResultSet rs=null;
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery("SELECT ISNULL(SUM(N_AMOUNT),0.0) AS AMOUNT,proceeds=(select ISNULL(N_ADVAMT,0.0) from Advances where n_refno ="+N_REFNO+") FROM RECEIPTSHDR WHERE N_ADVPAYMENTNO = "+N_REFNO);
			if(rs.next()){
				
				map.put("amount",rs.getDouble("AMOUNT"));
				map.put("proceeds",rs.getDouble("proceeds") );
			}
		}catch(Exception e)
		{e.printStackTrace();}
		return map;
	}
}
