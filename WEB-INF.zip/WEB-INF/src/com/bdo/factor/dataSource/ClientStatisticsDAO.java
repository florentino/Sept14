package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.ClientDebtTurn;
import com.bdo.factor.beans.ClientStatistics;
import com.bdo.factor.beans.MonthlyBalances;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.FactorConnection;

public class ClientStatisticsDAO extends JdbcDaoSupport {
	Logger log = Logger.getLogger(ClientStatisticsDAO.class);
	
	DecimalFormat df = new DecimalFormat("##0.00");
	
	public ClientStatisticsDAO() {}
	
	public List<ClientStatistics> getClientStatistics(String clientCode, String asOfDate) {
		List<ClientStatistics> lClientStat = new ArrayList<ClientStatistics> ();
		Date asOfDated = DateHelper.parse(asOfDate); 
		Calendar cal = Calendar.getInstance();
		cal.setTime(asOfDated);
		lClientStat.add(getClientStatisticsAsOfDate(clientCode, cal.getTime()));
		
		for (int i =0; i <=10; i++) {
			cal.add(Calendar.MONTH, -1);
			cal.setTime(cal.getTime());		
			log.info("clientCode: " + clientCode); 
			lClientStat.add(getClientStatisticsAsOfDate(clientCode, cal.getTime()));			
		}
						
		return lClientStat;
	}
	
	public ClientStatistics getClientStatisticsAsOfDate(String clientCode,Date asOfDate) {
		ClientStatistics clientStat = new ClientStatistics();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		clientStat.setCurrentDate(date.newDate());
		//get Monthly Balances
		SimpleDateFormat sdf = new SimpleDateFormat("MMM");
		String mo = sdf.format(asOfDate);		
		SimpleDateFormat sdf2 = new SimpleDateFormat("MM");
		String mo2 = sdf2.format(asOfDate);		
		Calendar cal = Calendar.getInstance();
		cal.setTime(asOfDate);
		SimpleDateFormat sdfYY = new SimpleDateFormat("yy");
		String yy =sdfYY.format(cal.getTime()); 
		clientStat.setMonth(mo + " " + yy);
		String sSQL="SELECT IsNull(N_"+mo+"FIU, 0) as N_" + mo + "FIU , IsNull(N_"+mo+"REC,0) as N_"+mo+"REC ," +
				"IsNull( N_"+mo+"RES,0) AS N_"+mo+"RES FROM MonthlyBalances " +
				"WHERE C_CLNTCODE= '" + clientCode + "'";
		log.info("sQL for Mo Balances: " + sSQL);
		PreparedStatement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){				
					double fiu = rs.getDouble(1);
					double rec = rs.getDouble(2);
					double res = rs.getDouble(3);
					clientStat.setFiu(roundTwoDecimals(fiu));
					clientStat.setReceivables(roundTwoDecimals(rec));
					clientStat.setReserves(roundTwoDecimals(res));
					
					double utilPercentage = roundTwoDecimals(fiu / rec);
					clientStat.setUtilPercentage(utilPercentage);					
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}	
		
		//get from Advances Table
		stmt=null;
		rs=null;
		String sMonth = "", sDay = "", eDay = "";		
		int sday = cal.getActualMaximum(cal.DAY_OF_MONTH);
		int eday = cal.getActualMinimum(cal.DAY_OF_MONTH);
		if (sday <= 9) {
			sDay = "0" + sday;
		}
		else {
			sDay = sday + "";
		}
		if (eday <= 9) {
			eDay = "0" + eday;
		}
		else {
			eDay = eday + "";
		}
		
		String startDate = mo2 + "/" + eDay + "/" + cal.get(cal.YEAR);		
		String endDate = mo2 + "/" + sDay + "/" + cal.get(cal.YEAR);		
						
		try{
			sSQL="select isNull(sum(adv.n_discchgcd),0) as discountCharge, isNull(sum(adv.n_svcchg),0) as svcCharge " +
					"from (select n_svcchg, n_discchgcd from advances " +
					"where d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_clntcode = '" + clientCode + "' )adv";
			log.info("sSql:" + sSQL);
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){				
					double discountCharge = rs.getDouble("discountCharge");
					double svcCharge = rs.getDouble("svcCharge");					
					clientStat.setDiscountCharge(roundTwoDecimals(discountCharge));
					clientStat.setServiceCharge(roundTwoDecimals(svcCharge));										
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}	
				
		//get Total Invoices
		stmt=null;
		rs=null;
		try{
			sSQL="select isNull(sum(n_invoiceamt),0) as invoiceAmt from invoices " +
					"where d_invoicedate between '" + startDate + "' and '" + endDate + "'" +
							" AND c_clntCode = '" + clientCode + "'";	
			System.out.println("sSQL for invoice:" + sSQL);
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){				
					double invoiceAmount = rs.getDouble("invoiceAmt");							
					clientStat.setInvoiceAmount(roundTwoDecimals(invoiceAmount));														
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}	
	
		//getCN
		stmt=null;
		rs=null;
		try{
			sSQL="select isNull(sum(creditnote.n_amount),0) as cnAmount from creditnote " +					
					"where d_transactiondate between '" + startDate + "' and '" + endDate + "' " +
					"and c_clntcode = '" + clientCode + "'";
			log.info("sSQL for CN:" + sSQL);
			
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){				
					double cnAmount = rs.getDouble("cnAmount");					
					clientStat.setCnAmount(roundTwoDecimals(cnAmount));														
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}	
		double crn = 0;
		if (clientStat.getInvoiceAmount() > 0) {
			crn = roundTwoDecimals((clientStat.getCnAmount() / clientStat.getInvoiceAmount()));
		}
		else {
			crn = 0.00;
		}
		clientStat.setCrn(crn);
		
		//get Dunning
		stmt=null;
		rs=null;
		try{
			sSQL="select dbo.GetDunning (?,?,'"+ startDate + "', '" + endDate + "') as dunning";	
			log.info("SQL FOR DUNNING: " + sSQL);
			
			
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			stmt.setString(1,clientCode);
			stmt.setString(2, "5");			
			rs = stmt.executeQuery();
				while(rs.next()){				
					float dunning = rs.getFloat("dunning");			
					log.info("dunning:" + dunning);
					clientStat.setDunning(roundTwoDecimalsF(dunning));														
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}
		
		//get Monthly discount charge
		MonthlyChargesDAO moCharges = (MonthlyChargesDAO)Persistence.getDAO("monthlyChargesDao");
		double discountCharge  = moCharges.getDiscountChargePerClient(endDate, Long.parseLong(clientCode));
		log.info("discountCharge: " + endDate + ":" + discountCharge);
		
		clientStat.setDiscountCharge(roundTwoDecimals(discountCharge));		
		
		return clientStat;
	}
	
	public float getDunningTotal(String clientCode, String startDate, String endDate) {
		
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String sSQL = null;
		float dunning = 0f;
		try{						
			sSQL="select dbo.GetDunning (?,?,'"+ startDate + "', '" + endDate + "') as dunning";	
			log.info("SQL FOR DUNNING: " + sSQL);
			
			
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			stmt.setString(1,clientCode);
			stmt.setString(2, "5");			
			rs = stmt.executeQuery();
				while(rs.next()){				
					dunning = rs.getFloat("dunning");														
				}
				return dunning;
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}
		return dunning;
	}
	
	private double roundTwoDecimals(double d) {
		return Double.valueOf(df.format(d));
	}
	private float roundTwoDecimalsF(float d) {
		return Float.valueOf(df.format(d));
	}
	
	
}
