package com.bdo.factor.dataSource;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.WeeklyBooking;
import com.bdo.factor.beans.WeeklyBookingSummary;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;

public class WeeklyBookingSummaryDAO extends JdbcDaoSupport{
	private static Logger log = Logger.getLogger(WeeklyBookingDAO.class);
	
	public WeeklyBookingSummaryDAO() {}
	
	public WeeklyBookingSummary getWeeklyBookingSummary(final String branchCode, String wkMonth)
	{
		System.out.println("wkMonth::: " + wkMonth);
		WeeklyBookingSummary wbs = new WeeklyBookingSummary();
		List<WeeklyBooking> wBookingLst = new ArrayList<WeeklyBooking>();
		
		WeeklyBookingDAO wkBookDao = (WeeklyBookingDAO)Persistence.getDAO("weeklyBookingDao");
		
		wkBookDao.setBusinessDays(wkMonth);
		wBookingLst = wkBookDao.getWeeklyBooking(branchCode);
		
		WeeklyBookingFields wbf = new WeeklyBookingFields();
		
		double totalReceivablesWk1 = 0;
		double totalReceivablesWk2 = 0;
		double totalReceivablesWk3 = 0;
		double totalReceivablesWk4 = 0;
		double totalReceivablesWk5 = 0;
		double totalReceivablesMTD = 0;
		double totalReceivablesYTD = 0;
		
		double totalPrepaymentsWk1 = 0;
		double totalPrepaymentsWk2 = 0;
		double totalPrepaymentsWk3 = 0;
		double totalPrepaymentsWk4 = 0;
		double totalPrepaymentsWk5 = 0;
		double totalPrepaymentsMTD = 0;
		double totalPrepaymentsYTD = 0;
		
		double totalCollectionWk1 = 0;
		double totalCollectionWk2 = 0;
		double totalCollectionWk3 = 0;
		double totalCollectionWk4 = 0;
		double totalCollectionWk5 = 0;
		double totalCollectionMTD = 0;
		double totalCollectionYTD = 0;		
		
		double grandTotalDCWk1 = 0;
		double grandTotalDCWk2 = 0;
		double grandTotalDCWk3 = 0;
		double grandTotalDCWk4 = 0;
		double grandTotalDCWk5 = 0;
		double grandTotalDCMTD = 0;
		double grandTotalDCYTD = 0;
		
		double netWeeklyBookingWk1 = 0;
		double netWeeklyBookingWk2 = 0;
		double netWeeklyBookingWk3 = 0;
		double netWeeklyBookingWk4 = 0;
		double netWeeklyBookingWk5 = 0;
		double netWeeklyBookingMTD = 0;
		double netWeeklyBookingYTD = 0;
		
		double totalWDunningFactorWk1 = 0;
		double totalWDunningFactorWk2 = 0;
		double totalWDunningFactorWk3 = 0;
		double totalWDunningFactorWk4 = 0;
		double totalWDunningFactorWk5 = 0;
		double totalWDunningFactorMTD = 0;
		double totalWDunningFactorYTD = 0;
		
		double totalDunningCycleWk1 = 0;
		double totalDunningCycleWk2 = 0;
		double totalDunningCycleWk3 = 0;
		double totalDunningCycleWk4 = 0;
		double totalDunningCycleWk5 = 0;
		
		double totalDunCycleWk1 = 0;
		double totalDunCycleWk2 = 0;
		double totalDunCycleWk3 = 0;
		double totalDunCycleWk4 = 0;
		double totalDunCycleWk5 = 0;
		double totalDunCycleMTD = 0;
		double totalDunCycleYTD = 0;
		
		double finTotalDunCycleWk1 = 0;
		double finTotalDunCycleWk2 = 0;
		double finTotalDunCycleWk3 = 0;
		double finTotalDunCycleWk4 = 0;
		double finTotalDunCycleWk5 = 0;
		double finTotalDunCycleMTD = 0;
		double finTotalDunCycleYTD = 0;
		
		for(WeeklyBooking w:wBookingLst) {
			totalReceivablesWk1 = w.getInvoiceAmt1stWeek() + totalReceivablesWk1;
			totalReceivablesWk2 = w.getInvoiceAmt2ndWeek() + totalReceivablesWk2;
			totalReceivablesWk3 = w.getInvoiceAmt3rdWeek() + totalReceivablesWk3;
			totalReceivablesWk4 = w.getInvoiceAmt4thWeek() + totalReceivablesWk4;
			totalReceivablesWk5 = w.getInvoiceAmt5thWeek() + totalReceivablesWk5;
			totalReceivablesMTD = w.getInvoiceAmt1stWeek() + w.getInvoiceAmt2ndWeek() + w.getInvoiceAmt3rdWeek() + w.getInvoiceAmt4thWeek() + w.getInvoiceAmt5thWeek() + totalReceivablesMTD;
			totalReceivablesYTD = w.getYtd() + totalReceivablesYTD;
			
			netWeeklyBookingWk1 = wbf.getNetWeeklyBooking(w.getInvoiceAmt1stWeek(), w.getAdvanceRatio()); 
			netWeeklyBookingWk2 = wbf.getNetWeeklyBooking(w.getInvoiceAmt2ndWeek(), w.getAdvanceRatio());
			netWeeklyBookingWk3 = wbf.getNetWeeklyBooking(w.getInvoiceAmt3rdWeek(), w.getAdvanceRatio());
			netWeeklyBookingWk4 = wbf.getNetWeeklyBooking(w.getInvoiceAmt4thWeek(), w.getAdvanceRatio());
			netWeeklyBookingWk5 = wbf.getNetWeeklyBooking(w.getInvoiceAmt5thWeek(), w.getAdvanceRatio());
			netWeeklyBookingMTD = wbf.getNetWeeklyBooking((w.getInvoiceAmt1stWeek() + w.getInvoiceAmt2ndWeek() + w.getInvoiceAmt3rdWeek() + w.getInvoiceAmt4thWeek() + w.getInvoiceAmt5thWeek()), w.getAdvanceRatio());
			netWeeklyBookingYTD = wbf.getNetWeeklyBooking(w.getYtd(), w.getAdvanceRatio());
						
			totalPrepaymentsWk1 = netWeeklyBookingWk1 + totalPrepaymentsWk1;
			totalPrepaymentsWk2 = netWeeklyBookingWk2 + totalPrepaymentsWk2;
			totalPrepaymentsWk3 = netWeeklyBookingWk3 + totalPrepaymentsWk3;
			totalPrepaymentsWk4 = netWeeklyBookingWk4 + totalPrepaymentsWk4;
			totalPrepaymentsWk5 = netWeeklyBookingWk5 + totalPrepaymentsWk5;
			totalPrepaymentsMTD = netWeeklyBookingMTD + totalPrepaymentsMTD;
			totalPrepaymentsYTD = netWeeklyBookingYTD + totalPrepaymentsYTD;
			
			totalCollectionWk1 = w.getTotCollectionWk1() + totalCollectionWk1;
			totalCollectionWk2 = w.getTotCollectionWk2() + totalCollectionWk2;
			totalCollectionWk3 = w.getTotCollectionWk3() + totalCollectionWk3;
			totalCollectionWk4 = w.getTotCollectionWk4() + totalCollectionWk4;
			totalCollectionWk5 = w.getTotCollectionWk5() + totalCollectionWk5;
			totalCollectionMTD = w.getTotCollectionWk1() + w.getTotCollectionWk2() + w.getTotCollectionWk3() + w.getTotCollectionWk4() + w.getTotCollectionWk5() + totalCollectionMTD;
			totalCollectionYTD = w.getTotCollectionWkYTD() + totalCollectionYTD;
			
			double totalDCWk1 = wbf.getDC(netWeeklyBookingWk1, w.getPercentOne(), Math.round(w.getDunMontly()));
			double totalDCWk2 = wbf.getDC(netWeeklyBookingWk2, w.getPercentOne(), Math.round(w.getDunMontly()));
			double totalDCWk3 = wbf.getDC(netWeeklyBookingWk3, w.getPercentOne(), Math.round(w.getDunMontly()));
			double totalDCWk4 = wbf.getDC(netWeeklyBookingWk4, w.getPercentOne(), Math.round(w.getDunMontly()));
			double totalDCWk5 = wbf.getDC(netWeeklyBookingWk5, w.getPercentOne(), Math.round(w.getDunMontly()));
			double sumDCWk = totalDCWk1 + totalDCWk2 + totalDCWk3 + totalDCWk4 + totalDCWk5; 
			double totalDCMTD = sumDCWk;
			
			grandTotalDCWk1 = grandTotalDCWk1 + totalDCWk1;
			grandTotalDCWk2 = grandTotalDCWk2 + totalDCWk2;
			grandTotalDCWk3 = grandTotalDCWk3 + totalDCWk3;
			grandTotalDCWk4 = grandTotalDCWk4 + totalDCWk4;
			grandTotalDCWk5 = grandTotalDCWk5 + totalDCWk5;
			grandTotalDCMTD = grandTotalDCMTD + totalDCMTD;
			
			UtilDAO utilDao    = (UtilDAO)Persistence.getDAO("utilDao");
			Calendar cal = Calendar.getInstance();
			cal.setTime(DateHelper.parse(wkMonth));
			cal.set(cal.DAY_OF_MONTH, cal.getActualMaximum(cal.DAY_OF_MONTH));
			String eom = DateHelper.format(cal.getTime());
			int month = cal.get(Calendar.MONTH) + 1;
			String monthName = utilDao.getMonthName(month);
			double ytdDC =wkBookDao.getYearlyDC(w.getClientCode(), monthName);
			double totalDCYTD = 0;
			if (eom.equalsIgnoreCase(wkMonth)) {
				totalDCYTD = ytdDC + totalDCYTD;
			}
			else {
				totalDCYTD = ytdDC + sumDCWk + totalDCYTD;
			}
			
			grandTotalDCYTD = grandTotalDCYTD + totalDCYTD;
			
			totalWDunningFactorWk1 = netWeeklyBookingWk1 * Math.round(w.getDunMontly());
			totalWDunningFactorWk2 = netWeeklyBookingWk2 * Math.round(w.getDunMontly());
			totalWDunningFactorWk3 = netWeeklyBookingWk3 * Math.round(w.getDunMontly());
			totalWDunningFactorWk4 = netWeeklyBookingWk4 * Math.round(w.getDunMontly());
			totalWDunningFactorWk5 = netWeeklyBookingWk5 * Math.round(w.getDunMontly());
			totalWDunningFactorMTD = netWeeklyBookingMTD * Math.round(w.getDunMontly());
			totalWDunningFactorYTD = netWeeklyBookingYTD * Math.round(w.getDunMontly());
			
			
			totalDunCycleWk1 = netWeeklyBookingWk1 != 0 ? totalWDunningFactorWk1 / netWeeklyBookingWk1 : 0;
			totalDunCycleWk2 = netWeeklyBookingWk2 != 0 ? totalWDunningFactorWk2 / netWeeklyBookingWk2 : 0;
			totalDunCycleWk3 = netWeeklyBookingWk3 != 0 ? totalWDunningFactorWk3 / netWeeklyBookingWk3 : 0;
			totalDunCycleWk4 = netWeeklyBookingWk4 != 0 ? totalWDunningFactorWk4 / netWeeklyBookingWk4 : 0;
			totalDunCycleWk5 = netWeeklyBookingWk5 != 0 ? totalWDunningFactorWk5 / netWeeklyBookingWk5 : 0;
			totalDunCycleMTD = netWeeklyBookingMTD != 0 ? totalWDunningFactorMTD / netWeeklyBookingMTD : 0;
			totalDunCycleYTD = netWeeklyBookingYTD != 0 ? totalWDunningFactorYTD / netWeeklyBookingYTD : 0;
			
			finTotalDunCycleWk1 = totalDunCycleWk1 + finTotalDunCycleWk1;
			finTotalDunCycleWk2 = totalDunCycleWk2 + finTotalDunCycleWk2;
			finTotalDunCycleWk3 = totalDunCycleWk3 + finTotalDunCycleWk3;
			finTotalDunCycleWk4 = totalDunCycleWk4 + finTotalDunCycleWk4;
			finTotalDunCycleWk5 = totalDunCycleWk5 + finTotalDunCycleWk5;
			finTotalDunCycleMTD = totalDunCycleMTD + finTotalDunCycleMTD;
			finTotalDunCycleYTD = totalDunCycleYTD + finTotalDunCycleYTD;			
		}
		
		wbs.setDcWk1(grandTotalDCWk1);
		wbs.setDcWk2(grandTotalDCWk2);
		wbs.setDcWk3(grandTotalDCWk3);
		wbs.setDcWk4(grandTotalDCWk4);
		wbs.setDcWk5(grandTotalDCWk5);
		wbs.setDcMTD(grandTotalDCMTD);
		wbs.setDcYTD(grandTotalDCYTD);
		
		wbs.setDunningWk1(finTotalDunCycleWk1);
		wbs.setDunningWk2(finTotalDunCycleWk2);
		wbs.setDunningWk3(finTotalDunCycleWk3);
		wbs.setDunningWk4(finTotalDunCycleWk4);
		wbs.setDunningWk5(finTotalDunCycleWk5);
		wbs.setDunningMTD(finTotalDunCycleMTD);
		wbs.setDunningYTD(finTotalDunCycleYTD);
		
		wbs.setPrepaymentWk1(totalPrepaymentsWk1);
		wbs.setPrepaymentWk2(totalPrepaymentsWk2);
		wbs.setPrepaymentWk3(totalPrepaymentsWk3);
		wbs.setPrepaymentWk4(totalPrepaymentsWk4);
		wbs.setPrepaymentWk5(totalPrepaymentsWk5);
		wbs.setPrepaymentMTD(totalPrepaymentsMTD);
		wbs.setPrepaymentYTD(totalPrepaymentsYTD);
		
		wbs.setReceivablesWk1(totalReceivablesWk1);
		wbs.setReceivablesWk2(totalReceivablesWk2);
		wbs.setReceivablesWk3(totalReceivablesWk3);
		wbs.setReceivablesWk4(totalReceivablesWk4);
		wbs.setReceivablesWk5(totalReceivablesWk5);
		wbs.setReceivablesMTD(totalReceivablesMTD);
		wbs.setReceivablesYTD(totalReceivablesYTD);
		
		wbs.setTotCollectionWk1(totalCollectionWk1);
		wbs.setTotCollectionWk2(totalCollectionWk2);
		wbs.setTotCollectionWk3(totalCollectionWk3);
		wbs.setTotCollectionWk4(totalCollectionWk4);
		wbs.setTotCollectionWk5(totalCollectionWk5);
		wbs.setTotCollectionMTD(totalCollectionMTD);
		wbs.setTotCollectionYTD(totalCollectionYTD);
		
		double prepaymentPercentWk1 = totalReceivablesWk1 != 0 ? (totalPrepaymentsWk1 / totalReceivablesWk1) * 100 : 0;
		double prepaymentPercentWk2 = totalReceivablesWk2 != 0 ? (totalPrepaymentsWk2 / totalReceivablesWk2) * 100 : 0;
		double prepaymentPercentWk3 = totalReceivablesWk3 != 0 ? (totalPrepaymentsWk3 / totalReceivablesWk3) * 100 : 0;
		double prepaymentPercentWk4 = totalReceivablesWk4 != 0 ? (totalPrepaymentsWk4 / totalReceivablesWk4) * 100 : 0;
		double prepaymentPercentWk5 = totalReceivablesWk5 != 0 ? (totalPrepaymentsWk5 / totalReceivablesWk5) * 100 : 0;
		double prepaymentPercentMTD = totalReceivablesMTD != 0 ? (totalPrepaymentsMTD / totalReceivablesMTD) * 100 : 0;
		double prepaymentPercentYTD = totalReceivablesMTD != 0 ? (totalPrepaymentsMTD / totalReceivablesMTD) * 100 : 0;
		
		wbs.setPrepaymentPercentWk1(prepaymentPercentWk1);
		wbs.setPrepaymentPercentWk2(prepaymentPercentWk2);
		wbs.setPrepaymentPercentWk3(prepaymentPercentWk3);
		wbs.setPrepaymentPercentWk4(prepaymentPercentWk4);
		wbs.setPrepaymentPercentWk5(prepaymentPercentWk5);
		wbs.setPrepaymentPercentMTD(prepaymentPercentMTD);
		wbs.setPrepaymentPercentYTD(prepaymentPercentYTD);
		
		return wbs;
	}
}
