package com.bdo.factor.dataSource;
import java.util.List;
import java.util.ArrayList;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRException;
import com.bdo.factor.beans.PDOInvoice;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.INVOICEDAO;
public class PDOInvoiceDS  implements JRDataSource
{
	private List<PDOInvoice> pdoInvoiceList = new ArrayList<PDOInvoice>();
	private int index          = -1;
	private int lastIndex      = 0;
	private String displayDate = "";
	public PDOInvoiceDS(String asOfDate, String branchCode)
	{
		/*INVOICEDAO pdoInvoiceDao = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
		pdoInvoiceList = pdoInvoiceDao.getPDOInvoiceList(asOfDate, branchCode);
		lastIndex = pdoInvoiceList.size();
		displayDate = asOfDate;*/
	}
	
	
	
	
	
	
	@Override
	public Object getFieldValue(JRField jrField) throws JRException 
	{
		Object value = null;
		String field = jrField.getName();
		PDOInvoice pdoInvoice = (PDOInvoice)pdoInvoiceList.get(index);
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		if (this.lastIndex > 0)
		{
			if ("AO".equals(field))
			{
				value = pdoInvoice.getAo();
			}
			
			if ("Client".equals(field))
			{
				value = pdoInvoice.getClient();
			}
			
			if ("Customer".equals(field))
			{
				value = pdoInvoice.getCustomer();
			}
			
			if ("DunningPerLAM".equals(field))
			{
				value = pdoInvoice.getDunningPerLam();
			}
			
			if ("CreditTerm".equals(field))
			{
				value = pdoInvoice.getCreditTerm();
			}
			
			if ("InvoiceNumber".equals(field))
			{
				value = pdoInvoice.getInvoiceNumber();
			}
			
			if ("InvoiceAge".equals(field))
			{
				value = pdoInvoice.getInvoiceAge();
			}	
			
			if ("ActualInvoiceAge".equals(field))
			{
				value = pdoInvoice.getActualInvoiceAge();
			}
			
			if ("Amount".equals(field))
			{
				value = pdoInvoice.getAmount();
			}
			
			if ("PrePaymentRatio".equals(field))
			{
				value = pdoInvoice.getPrePaymentRatio();
			}	
			
			if ("lt90DPD".equals(field))
			{
				value = pdoInvoice.getLt90DPD();
			}
			
			if ("gt90DPD".equals(field))
			{
				value = pdoInvoice.getGt90DPD();
			}									
		}
				
		if ("asOfDate".equals(field))
		{
			value = "as of " + displayDate;
		}
		if("currentDate".equals(field)){
			value = date.newDate();
		}
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
        if(index<lastIndex){
            return true;
        }
        return false;		
	}
}
