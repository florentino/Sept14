package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.Audit;

public class AuditTrailDao extends JdbcDaoSupport {
	
	private Logger log = Logger.getLogger(AuditTrailDao.class);
	
	public List<Audit> getAuditTrail(String startDate, String endDate){
		List<Audit> list= new ArrayList<Audit>();
		String sSQL = "select (select u.C_USERNAME from UserTable u where u.C_USERID=a.UserId) as name,* from Audit a WHERE CONVERT(nvarchar,UpdateDate,101)>='"+startDate+"' and CONVERT(nvarchar,UpdateDate,101)<='"+endDate+"'";
		log.info(sSQL);
		list =getJdbcTemplate().query(sSQL, new RowMapper(){
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Audit audit = new Audit();
				audit.setUserID(rs.getString("name"));
				log.info("UserId: "+rs.getString("UserId"));
				audit.setNewValue(rs.getString("NewValue"));
				audit.setTableName(rs.getString("TableName"));
				audit.setType(rs.getString("Type"));				
				audit.setUpdateDate(rs.getDate("UpdateDate"));				
				return audit;
			}			
		});
		return list;
	}
}
