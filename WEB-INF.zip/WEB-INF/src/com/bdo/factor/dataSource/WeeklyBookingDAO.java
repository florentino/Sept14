package com.bdo.factor.dataSource;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.DateUtils;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.beans.MonthlyDC;
import com.bdo.factor.beans.WeeklyBooking;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.*;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class WeeklyBookingDAO extends JdbcDaoSupport 
{
	private static Logger log = Logger.getLogger(WeeklyBookingDAO.class);
	
    private String weekOne;
    private String weekTwo;
    private String weekThree;
    private String weekFour;
    private String weekFive;
    
    private Date firstDateOne;
    private Date firstDateTwo;
    private Date firstDateThree;
    private Date firstDateFour;
    private Date firstDateFive;

    private Date secondDateOne;
    private Date secondDateTwo;
    private Date secondDateThree;
    private Date secondDateFour;
    private Date secondDateFive;
    
    private String betweenDateOne;
    private String betweenDateTwo;
    private String betweenDateThree;
    private String betweenDateFour;
    private String betweenDateFive;    
    
    private String asOfDate;
 
    
    
	public WeeklyBookingDAO() {}

	public int getWeeklyBookingCount(String branchCode)
	{		
		int retval = 0;
		String sSQL="SELECT " +
					"(SELECT COUNT(C_INVOICENO) AS cnt " + 
					"FROM Invoice WHERE C_BRANCHCODE = '"+branchCode+"' " + 
					"AND C_STATUS BETWEEN 2 AND 5 " + 
					"AND D_TRANSACTIONDATE " + getBetweenDateOne()+")" +
					 " + " +
					 "(SELECT COUNT(C_INVOICENO) AS cnt " + 
					 "FROM Invoice WHERE C_BRANCHCODE = '"+branchCode+"' " + 
					 "AND C_STATUS BETWEEN 2 AND 5 " + 
					 "AND D_TRANSACTIONDATE " + getBetweenDateTwo()+") " +
					 " + " +
					 "(SELECT COUNT(C_INVOICENO) AS cnt " + 
					 "FROM Invoice WHERE C_BRANCHCODE = '"+branchCode+"' " + 
					 "AND C_STATUS BETWEEN 2 AND 5 " + 
					 "AND D_TRANSACTIONDATE " + getBetweenDateThree()+") " +
					 " + " +
					 "(SELECT COUNT(C_INVOICENO) AS cnt " + 
					 "FROM Invoice WHERE C_BRANCHCODE = '"+branchCode+"' " + 
					 "AND C_STATUS BETWEEN 2 AND 5 " + 
					 "AND D_TRANSACTIONDATE " + getBetweenDateFour()+") " +
					 " + " +
					 "(SELECT COUNT(C_INVOICENO) AS cnt " + 
					 "FROM Invoice WHERE C_BRANCHCODE = '"+branchCode+"' " + 
					 "AND C_STATUS BETWEEN 2 AND 5 " + 
					 "AND D_TRANSACTIONDATE " + getBetweenDateFive()+") as counter";		
		
		log.info(sSQL);
		
		retval = (Integer)getJdbcTemplate().queryForObject(sSQL, 
				new RowMapper()
				{
					@Override 
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{							
						return rs.getInt("counter");							
					}
				}
			);		
		
		return retval;			
	}
	
	@SuppressWarnings("unchecked")
	public List<WeeklyBooking> getWeeklyBooking(final String branchCode)
	{
		final String wkOne   = this.getWeekOne();
		final String wkTwo   = this.getWeekTwo();
		final String wkThree = this.getWeekThree();
		final String wkFour  = this.getWeekFour();
		final String wkFive  = this.getWeekFive();		
		Calendar cal6Mo = Calendar.getInstance();
		cal6Mo.setTime(DateHelper.parse(this.getAsOfDate()));
		cal6Mo.add(Calendar.MONTH, -6);
		String date6Mo = DateHelper.format(cal6Mo.getTime());
		
		SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
		String firstDayOfTheMonth = SDF.format(DateHelper.getDateInFirstDay(this.getAsOfDate()));
		
		
		List<WeeklyBooking> list = new ArrayList<WeeklyBooking>();
			String sSQL = "select DISTINCT(ISNULL(t1.C_CLNTCODE,0)) AS C_CLNTCODE, " +
						  "v1.C_NAME, CASE WHEN v1.ClientStatus=1 THEN 'Active' ELSE 'Inactive' END AS clientStatus, v1.C_ACCTOFFICERCODE, " +
						  "(SELECT distinct count(rh.n_refno) as receiptCount " +
						  "FROM receiptsdtl rd left join receiptshdr rh on rd.n_refno = rh.n_refno " +
						  "WHERE C_CLNTCODE = t1.C_CLNTCODE AND rh.c_status != '3' and d_transactiondate between '" + date6Mo + "' and '" + DateHelper.getLastDateOfTheMonth(this.getAsOfDate()) + "') AS receiptCount, " +
						  "(SELECT N_SETTLEMENT " +
						  "FROM dbcif.dbo.client WHERE C_CLNTCODE = v1.C_CLNTCODE) as creditTerm, " +					  
						  "(SELECT ROUND(SUM(ISNULL(N_ORIGINVOICEAMT,0)), 3) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateOne() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS weekOne, " + 
						  "(SELECT ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateTwo() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS weekTwo, " +
						  "(SELECT ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateThree() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS weekThree, " + 
						  "(SELECT ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateFour() +
						  "AND C_STATUS BETWEEN 2 AND 6) AS weekFour, " + 
						  "(SELECT ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateFive() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS weekFive, " +
						  
						  "(SELECT round(ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) * (v1.N_SCR/100),2) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateOne() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS scOne, " +
						  "(SELECT round(ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) * (v1.N_SCR/100),2) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateTwo() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS scTwo, " +
						  "(SELECT round(ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) * (v1.N_SCR/100),2) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateThree() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS scThree, " +
						  "(SELECT round(ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) * (v1.N_SCR/100),2) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateFour() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS scFour, " +
						  "(SELECT round(ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) * (v1.N_SCR/100),2) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE " + getBetweenDateFive() + 
						  "AND C_STATUS BETWEEN 2 AND 6) AS scFive, " +
						  "(SELECT round(ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 2) * (v1.N_SCR/100),2) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND D_TRANSACTIONDATE BETWEEN '"+this.getJanuaryOfTheYear(this.getAsOfDate())+"' " + " AND '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"'" +
						  "AND C_STATUS BETWEEN 2 AND 6) AS scYearly, " +
					  
						  "(SELECT case when count(*) >= 1 then 'SC rate has been changed' else NULL end  FROM ratesHistory WHERE c_Clntcode = t1.C_CLNTCODE  AND C_Charge='SCR' " + 
						  "AND d_Date BETWEEN '"+firstDayOfTheMonth+"' " + " AND '"+this.getAsOfDate()+"') as scStatus," +
						  "(SELECT case when count(*) >= 1 then 'BL Rate has been changed' else NULL end  FROM ratesHistory WHERE c_Clntcode = t1.C_CLNTCODE  AND C_Charge='BLR' " + 
						  "AND d_Date BETWEEN '"+firstDayOfTheMonth+"' " + " AND '"+this.getAsOfDate()+"') as blrStatus, " +
						  "(SELECT case when count(*) >= 1 then 'Advance Ratio has been changed' else NULL end  FROM ratesHistory WHERE c_Clntcode = t1.C_CLNTCODE  AND C_Charge='AdvRatio' " + 
						  "AND d_Date BETWEEN '"+firstDayOfTheMonth+"' " + " AND '"+this.getAsOfDate()+"') as advanceRatioStatus," +
						  						  
						  "(SELECT ROUND(SUM(ISNULL(N_ORIGINVOICEAMT, 0)), 3) FROM Invoice WHERE C_CLNTCODE = t1.C_CLNTCODE " +
						  " AND D_TRANSACTIONDATE BETWEEN '"+this.getJanuaryOfTheYear(this.getAsOfDate())+"' " +
						  " AND '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"' AND C_STATUS BETWEEN 2 AND 6) AS ytd, " +
						  //"dbo.GetDunning(t1.C_CLNTCODE, '5', DATEADD(MM,-6,'"+DateHelper.format(this.getSecondDateOne())+"'), '"+DateHelper.format(this.getSecondDateOne())+"') AS dunOne, " +
						  //"dbo.GetDunning(t1.C_CLNTCODE, '5', DATEADD(MM,-6,'"+DateHelper.format(this.getSecondDateTwo())+"'), '"+DateHelper.format(this.getSecondDateTwo())+"') AS dunTwo, " +
						  //"dbo.GetDunning(t1.C_CLNTCODE, '5', DATEADD(MM,-6,'"+DateHelper.format(this.getSecondDateThree())+"'), '"+DateHelper.format(this.getSecondDateThree())+"') AS dunThree, " +
						  //"dbo.GetDunning(t1.C_CLNTCODE, '5', DATEADD(MM,-6,'"+DateHelper.format(this.getSecondDateFour())+"'), '"+DateHelper.format(this.getSecondDateFour())+"') AS dunFour, " +
						  //"dbo.GetDunning(t1.C_CLNTCODE, '5', DATEADD(MM,-6,'"+DateHelper.format(this.getSecondDateFive())+"'), '"+DateHelper.format(this.getSecondDateFive())+"') AS dunFive, " +
						  //"dbo.GetDunning(t1.C_CLNTCODE, '5', DATEADD(MM,-6,'"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"'), '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"') AS dunMonthly, " + //rdc10042010
//						  "(SELECT N_DUNNING=SUM((N_INVOICEAMT * (DATEDIFF(D,D_INVOICEDATE,D_FULLYPAIDDATE)+1))/N_INVOICEAMT) " +
//						  "FROM INVOICE WHERE C_STATUS='5' AND C_CLNTCODE=T1.C_CLNTCODE AND D_INVOICEDATE BETWEEN DATEADD(MM,-6,'"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"') " +
//						  "AND '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"') AS dunMonthly, " +
						  "(SELECT N_DUNNING=(select IsNull(round((sum(averageAmount) / sum(n_invoiceAmt)),2),0) as dunning from (select 	Invoice.n_invoiceAmt, " +
						  "(invoice.n_invoiceamt * (datediff(dd,invoice.d_invoicedate, invoice.d_fullypaiddate) + 1)) as averageAmount " + 
						  "from Invoice left join creditnote on Invoice.C_BRANCHCODE = CreditNote.C_BRANCHCODE AND Invoice.C_CLNTCODE = CreditNote.C_CLNTCODE AND " + 
						  "Invoice.C_CUSTCODE = CreditNote.C_CUSTCODE AND CreditNote.C_INVOICENO = Invoice.C_INVOICENO " + 
						  "where (Invoice.C_STATUS BETWEEN 5 AND 6) AND (invoice.c_clntcode =t1.C_CLNTCODE) " + 
						  "AND (invoice.d_invoicedate between DATEADD(MM,-6,'"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"') " +
						  "AND '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"'))derivedTbl)) AS dunMonthly, " + 
						  //"dbo.GetDunning(t1.C_CLNTCODE, '5', DATEADD(MM,-12,'"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"'), '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"') AS dunYearly, " +
						  "dbo.GetBLR(t1.C_CLNTCODE, '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"') + (v1.N_DCR/100) percentOne, " +
						  //"dbo.GetBLR(t1.C_CLNTCODE, '"+DateHelper.format(this.getSecondDateTwo())+"') + (v1.N_DCR/100) percentTwo, " +
						  //"dbo.GetBLR(t1.C_CLNTCODE, '"+DateHelper.format(this.getSecondDateThree())+"') + (v1.N_DCR/100) percentThree, " +
						  //"dbo.GetBLR(t1.C_CLNTCODE, '"+DateHelper.format(this.getSecondDateFour())+"') + (v1.N_DCR/100) percentFour, " +
						  //"dbo.GetBLR(t1.C_CLNTCODE, '"+DateHelper.format(this.getSecondDateFive())+"') + (v1.N_DCR/100) percentFive,  " +					  
						  "v1.N_ADVANCEDRATIO, '"+this.asOfDate+"' AS asOfDate,  ISNULL((v1.N_SCR / 100), 0) as N_SCR, " +
						  "(SELECT " +
						  "ROUND(SUM(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0)), 3) " +
						  "FROM " +
						  "ReceiptsHdr CROSS JOIN ReceiptsDtl " + 
						  "WHERE " +
						  "ReceiptsHdr.D_TRANSACTIONDATE " + getBetweenDateOne() +   					  
						  " AND ReceiptsHdr.C_CLNTCODE = t1.C_CLNTCODE " +
						  "AND ReceiptsHdr.C_BRANCHCODE = '"+branchCode+"' " + 
						  "AND ReceiptsHdr.C_STATUS <> 3 " +
						  "AND ReceiptsHdr.N_REFNO = ReceiptsDtl.N_REFNO) AS totCollectionWk1, " +
						  "(SELECT " +
						  "ROUND(SUM(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0)), 3) " +
						  "FROM " +
						  "ReceiptsHdr CROSS JOIN ReceiptsDtl " + 
						  "WHERE " +
						  "ReceiptsHdr.D_TRANSACTIONDATE " + getBetweenDateTwo() +   					  
						  " AND ReceiptsHdr.C_CLNTCODE = t1.C_CLNTCODE " +
						  "AND ReceiptsHdr.C_BRANCHCODE = '"+branchCode+"' " + 
						  "AND ReceiptsHdr.C_STATUS <> 3 " +
						  "AND ReceiptsHdr.N_REFNO = ReceiptsDtl.N_REFNO) AS totCollectionWk2, " +					  
						  "(SELECT " +
						  "ROUND(SUM(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0)), 3) " +
						  "FROM " +
						  "ReceiptsHdr CROSS JOIN ReceiptsDtl " + 
						  "WHERE " +
						  "ReceiptsHdr.D_TRANSACTIONDATE " + getBetweenDateThree() +   					  
						  " AND ReceiptsHdr.C_CLNTCODE = t1.C_CLNTCODE " +
						  "AND ReceiptsHdr.C_BRANCHCODE = '"+branchCode+"' " + 
						  "AND ReceiptsHdr.C_STATUS <> 3 " +
						  "AND ReceiptsHdr.N_REFNO = ReceiptsDtl.N_REFNO) AS totCollectionWk3, " +
						  "(SELECT " +
						  "ROUND(SUM(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0)), 3) " +
						  "FROM " +
						  "ReceiptsHdr CROSS JOIN ReceiptsDtl " + 
						  "WHERE " +
						  "ReceiptsHdr.D_TRANSACTIONDATE " + getBetweenDateFour() +   					  
						  " AND ReceiptsHdr.C_CLNTCODE = t1.C_CLNTCODE " +
						  "AND ReceiptsHdr.C_BRANCHCODE = '"+branchCode+"' " + 
						  "AND ReceiptsHdr.C_STATUS <> 3 " +
						  "AND ReceiptsHdr.N_REFNO = ReceiptsDtl.N_REFNO) AS totCollectionWk4, " +
						  "(SELECT " +
						  "ROUND(SUM(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0)), 3) " +
						  "FROM " +
						  "ReceiptsHdr CROSS JOIN ReceiptsDtl " + 
						  "WHERE " +
						  "ReceiptsHdr.D_TRANSACTIONDATE " + getBetweenDateFive() +   					  
						  " AND ReceiptsHdr.C_CLNTCODE = t1.C_CLNTCODE " +
						  "AND ReceiptsHdr.C_BRANCHCODE = '"+branchCode+"' " + 
						  "AND ReceiptsHdr.C_STATUS <> 3 " +
						  "AND ReceiptsHdr.N_REFNO = ReceiptsDtl.N_REFNO) AS totCollectionWk5, " +					  
						  "(SELECT " +
						  "ROUND(SUM(ISNULL(ReceiptsDtl.N_RECEIPTAMT, 0)), 3) " +
						  "FROM " +
						  "ReceiptsHdr CROSS JOIN ReceiptsDtl " + 
						  "WHERE " +
						  " ReceiptsHdr.D_TRANSACTIONDATE BETWEEN '"+this.getJanuaryOfTheYear(this.getAsOfDate())+"' " +
						  " AND '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"' "+
						  " AND ReceiptsHdr.C_CLNTCODE = t1.C_CLNTCODE " +
						  "AND ReceiptsHdr.C_BRANCHCODE = '"+branchCode+"' " + 
						  "AND ReceiptsHdr.C_STATUS <> 3 " +
						  "AND ReceiptsHdr.N_REFNO = ReceiptsDtl.N_REFNO) AS totCollectionWkYTD, " +					  
						  " (SELECT SUM(CC.N_DUNNING)/(COUNT(CC.C_CUSTCODE)) FROM CC WHERE C_CLNTCODE=t1.C_CLNTCODE) AS N_DUNNING " +
						  "FROM " + 
						  "Invoice t1 " +					  
						  "Right JOIN (select cc.* from cc inner join dbcif.dbo.client client on cc.c_clntcode = client.c_clntcode and client.c_branchcode = '"+branchCode+"') v1 " +
						  "ON " + 
						  "v1.C_CLNTCODE = t1.C_CLNTCODE " + 
						  "AND v1.C_BRANCHCODE = '"+branchCode+"' " +						
						  "ORDER BY " + 
						  "v1.C_ACCTOFFICERCODE, C_NAME ";
			log.info("GetDUNNING:" + sSQL);		
			final List<WeeklyBooking> list2 = new ArrayList();
			list = getJdbcTemplate().query
			
			(
					sSQL, new RowMapper()
					{
						@Override
						public Object mapRow(ResultSet rs, int rowNum)throws SQLException 
						{
							if (rs.getLong("C_CLNTCODE")>= 124 ){
								WeeklyBooking weeklyBooking = new WeeklyBooking();
								weeklyBooking.setBranchCode(branchCode);
								weeklyBooking.setClientCode(rs.getLong("C_CLNTCODE"));
								
								weeklyBooking.setClientName(rs.getString("C_NAME"));
								weeklyBooking.setAccountOfficer(rs.getString("C_ACCTOFFICERCODE"));
								weeklyBooking.setWeekOne(wkOne);
								weeklyBooking.setWeekTwo(wkTwo);
								weeklyBooking.setWeekThree(wkThree);
								weeklyBooking.setWeekFour(wkFour);
								weeklyBooking.setWeekFive(wkFive);
								weeklyBooking.setInvoiceAmt1stWeek(rs.getDouble("weekOne"));
								
								weeklyBooking.setScOne(rs.getDouble("scOne"));
								weeklyBooking.setScTwo(rs.getDouble("scTwo"));
								weeklyBooking.setScThree(rs.getDouble("scThree"));
								weeklyBooking.setScFour(rs.getDouble("scFour"));
								weeklyBooking.setScFive(rs.getDouble("scFive"));
								weeklyBooking.setYearlySC(rs.getDouble("scYearly"));
								
								weeklyBooking.setScStatus(rs.getString("scStatus"));
								weeklyBooking.setBlrStatus(rs.getString("blrStatus"));
								weeklyBooking.setAdvanceRatioStatus(rs.getString("advanceRatioStatus"));
								
								weeklyBooking.setClientStatus(rs.getString("clientStatus"));
								
								
								
								weeklyBooking.setInvoiceAmt2ndWeek(rs.getDouble("weekTwo"));
								weeklyBooking.setInvoiceAmt3rdWeek(rs.getDouble("weekThree"));
								weeklyBooking.setInvoiceAmt4thWeek(rs.getDouble("weekFour"));
								weeklyBooking.setInvoiceAmt5thWeek(rs.getDouble("weekFive"));
								weeklyBooking.setAdvanceRatio(rs.getDouble("N_ADVANCEDRATIO"));
								weeklyBooking.setYtd(rs.getDouble("ytd"));
								//weeklyBooking.setDunOne(rs.getDouble("dunOne"));
								//weeklyBooking.setDunTwo(rs.getDouble("dunTwo"));
								//weeklyBooking.setDunThree(rs.getDouble("dunThree"));
								//weeklyBooking.setDunFour(rs.getDouble("dunFour"));
								//weeklyBooking.setDunFive(rs.getDouble("dunFive"));					
								weeklyBooking.setPercentOne(rs.getDouble("percentOne"));						
								weeklyBooking.setPercentTwo(rs.getDouble("percentOne"));						
								weeklyBooking.setPercentThree(rs.getDouble("percentOne"));						
								weeklyBooking.setPercentFour(rs.getDouble("percentOne"));
								weeklyBooking.setPercentFive(rs.getDouble("percentOne"));
								
								//double dunning = getDunning(rs.getLong("C_CLNTCODE"));
								if (rs.getInt("receiptCount") <= 0) {
										System.out.println("dunMonthly: " + rs.getDouble("creditTerm"));
										weeklyBooking.setDunMontly(rs.getDouble("creditTerm"));
								}
								else if (rs.getDouble("dunMonthly") <= 0) { //rdc10042010
								//else if (dunning <= 0) {	
									weeklyBooking.setDunMontly(rs.getDouble("N_DUNNING"));
								}
								else {
									//weeklyBooking.setDunMontly(dunning);
									weeklyBooking.setDunMontly(rs.getDouble("dunMonthly") );
								}
								//weeklyBooking.setDunMontly((rs.getDouble("dunMonthly")) <= 0 ? rs.getDouble("N_DUNNING") : rs.getDouble("dunMonthly"));												
								WeeklyBookingDAO weeklyBookingDao = (WeeklyBookingDAO)Persistence.getDAO("weeklyBookingDao");
								weeklyBooking.setYearlyDC(weeklyBookingDao.getDiscountChargePerClientPerYear(rs.getString("asOfDate"), rs.getLong("C_CLNTCODE")));						
								//weeklyBooking.setDunYearly(rs.getDouble("dunYearly"));
								/*
								weeklyBooking.setSfWkOne(weeklyBookingDao.getServiceCharge(branchCode, rs.getLong("C_CLNTCODE"), weeklyBookingDao.getBetweenDateOne()));
								weeklyBooking.setSfWkTwo(weeklyBookingDao.getServiceCharge(branchCode, rs.getLong("C_CLNTCODE"), weeklyBookingDao.getBetweenDateTwo()));
								weeklyBooking.setSfWkThree(weeklyBookingDao.getServiceCharge(branchCode, rs.getLong("C_CLNTCODE"), weeklyBookingDao.getBetweenDateThree()));
								weeklyBooking.setSfWkFour(weeklyBookingDao.getServiceCharge(branchCode, rs.getLong("C_CLNTCODE"), weeklyBookingDao.getBetweenDateFour()));
								weeklyBooking.setSfWkFive(weeklyBookingDao.getServiceCharge(branchCode, rs.getLong("C_CLNTCODE"), weeklyBookingDao.getBetweenDateFive()));
								weeklyBooking.setSfMtd(weeklyBookingDao.getServiceChargePerMonthPerClient(branchCode, rs.getLong("C_CLNTCODE"), asOfDate));
								weeklyBooking.setSfYtd(weeklyBookingDao.getServiceChargePerYearPerClient(branchCode, rs.getLong("C_CLNTCODE"), asOfDate));
								weeklyBooking.setSfPercent(rs.getDouble("N_SCR"));
								*/
								
								weeklyBooking.setSfPercent(rs.getDouble("N_SCR"));
								weeklyBooking.setTotCollectionWk1(rs.getDouble("totCollectionWk1"));
								weeklyBooking.setTotCollectionWk2(rs.getDouble("totCollectionWk2"));
								weeklyBooking.setTotCollectionWk3(rs.getDouble("totCollectionWk3"));
								weeklyBooking.setTotCollectionWk4(rs.getDouble("totCollectionWk4"));
								weeklyBooking.setTotCollectionWk5(rs.getDouble("totCollectionWk5"));
								weeklyBooking.setTotCollectionWkYTD(rs.getDouble("totCollectionWkYTD"));
								list2.add(weeklyBooking);
								return weeklyBooking;
							}
							else
								return null;
						}					
					}
			);
			log.info("getWeeklyBooking->"+sSQL);
		return list2;		
	}
	
	public String getJanuaryOfTheYear(String theDate)
	{
		String[] dateOfTheYear = theDate.split("/");
		return  "01/01/" + dateOfTheYear[2];
	}
	
	@SuppressWarnings("static-access")
	public void setBusinessDays(String dateToParse)
	{
		System.out.println("date To parse: " + dateToParse);
		this.setAsOfDate(dateToParse);
		String[] monthOfTheYear = dateToParse.split("/");
		Calendar cal = Calendar.getInstance();
		cal.setTime(DateHelper.parse((monthOfTheYear[0]+"/01/"+monthOfTheYear[2])));
		int numberOfWeeksInMonth = cal.getActualMaximum(Calendar.DAY_OF_WEEK_IN_MONTH)+1;
		int firstDayOfTheMonth = cal.get(Calendar.DAY_OF_WEEK);
		
		while (firstDayOfTheMonth==Calendar.SATURDAY || firstDayOfTheMonth==Calendar.SUNDAY)
		{				
			cal.add(cal.DATE, 1);
			firstDayOfTheMonth = cal.get(Calendar.DAY_OF_WEEK);
		}
        setFirstDateOne(cal.getTime());        
		int y = 6 - firstDayOfTheMonth;
		cal.add(cal.DATE, y);
		setSecondDateOne(cal.getTime());
		setWeekOne(getFirstDateOne(), getSecondDateOne());
		setBetweenDateOne(getFirstDateOne(), getSecondDateOne());
		for(int i=1; i<=numberOfWeeksInMonth-1; i++)
		{		
			if (i==1)
			{
				cal.add(cal.DATE,3);				
				setFirstDateTwo(cal.getTime());			
				cal.add(cal.DATE, 4);
				setSecondDateTwo(cal.getTime());
				setWeekTwo(getFirstDateTwo(), getSecondDateTwo());
				setBetweenDateTwo(getFirstDateTwo(), getSecondDateTwo());
			}
			else if (i==2)
			{
				cal.add(cal.DATE,3);				
				setFirstDateThree(cal.getTime());			
				cal.add(cal.DATE, 4);
				setSecondDateThree(cal.getTime());
				setWeekThree(getFirstDateThree(), getSecondDateThree());
				setBetweenDateThree(getFirstDateThree(), getSecondDateThree());
			}
			else if (i==3)
			{
				cal.add(cal.DATE,3);				
				setFirstDateFour(cal.getTime());			
				cal.add(cal.DATE, 4);
				setSecondDateFour(cal.getTime());
				setWeekFour(getFirstDateFour(), getSecondDateFour());
				setBetweenDateFour(getFirstDateFour(), getSecondDateFour());
			}
			else if (i==4)
			{
				cal.add(cal.DATE,3);				
				setFirstDateFive(cal.getTime());			
				cal.add(cal.DATE, 4);
				setSecondDateFive(cal.getTime());
				setWeekFive(getFirstDateFive(), getSecondDateFive());
				setBetweenDateFive(getFirstDateFive(), getSecondDateFive());
			}			
		}
	}
	
	public String getBetweenDateOne() {
		return betweenDateOne;
	}

	public void setBetweenDateOne(Date firstDate, Date secondDate) {
		this.betweenDateOne = getFormatedBetweenDate(firstDate, secondDate);
	}

	public String getBetweenDateTwo() {
		return betweenDateTwo;
	}

	public void setBetweenDateTwo(Date firstDate, Date secondDate) {
		this.betweenDateTwo = getFormatedBetweenDate(firstDate, secondDate);
	}

	public String getBetweenDateThree() {
		return betweenDateThree;
	}

	public void setBetweenDateThree(Date firstDate, Date secondDate) {
		this.betweenDateThree = getFormatedBetweenDate(firstDate, secondDate);
	}

	public String getBetweenDateFour() {
		return betweenDateFour;
	}

	public void setBetweenDateFour(Date firstDate, Date secondDate) {
		this.betweenDateFour = getFormatedBetweenDate(firstDate, secondDate);
	}

	public String getBetweenDateFive() {
		return betweenDateFive;
	}

	public void setBetweenDateFive(Date firstDate, Date secondDate) {
		this.betweenDateFive = getFormatedBetweenDate(firstDate, secondDate);
	}

	public void setFirstDateOne(Date firstdateone)
    {
        firstDateOne = firstdateone;
    }

    public Date getFirstDateOne()
    {
        return firstDateOne;
    }

    public void setFirstDateTwo(Date firstdatetwo)
    {
        firstDateTwo = firstdatetwo;
    }

    public Date getFirstDateTwo()
    {
        return firstDateTwo;
    }

    public void setFirstDateThree(Date firstdatethree)
    {
        firstDateThree = firstdatethree;
    }

    public Date getFirstDateThree()
    {
        return firstDateThree;
    }

    public void setFirstDateFour(Date firstdatefour)
    {
        firstDateFour = firstdatefour;
    }

    public Date getFirstDateFour()
    {
        return firstDateFour;
    }

    public void setFirstDateFive(Date firstdatefive)
    {
        firstDateFive = firstdatefive;
    }

    public Date getFirstDateFive()
    {
        return firstDateFive;
    }

    
    public void setSecondDateOne(Date seconddateone)
    {
        secondDateOne = seconddateone;
    }

    public Date getSecondDateOne()
    {
        return secondDateOne;
    }

    public void setSecondDateTwo(Date seconddatetwo)
    {
        secondDateTwo = seconddatetwo;
    }

    public Date getSecondDateTwo()
    {
        return secondDateTwo;
    }

    public void setSecondDateThree(Date seconddatethree)
    {
        secondDateThree = seconddatethree;
    }

    public Date getSecondDateThree()
    {
        return secondDateThree;
    }

    public void setSecondDateFour(Date seconddatefour)
    {
        secondDateFour = seconddatefour;
    }

    public Date getSecondDateFour()
    {
        return secondDateFour;
    }

    public void setSecondDateFive(Date seconddatefive)
    {
        secondDateFive = seconddatefive;
    }

    public Date getSecondDateFive()
    {
        return secondDateFive;
    }


    public void setWeekOne(Date firstDate, Date secondDate)
    {
        weekOne = getTwoDate(firstDate, secondDate);
    }

    public String getWeekOne()
    {
        return weekOne;
    }

    public void setWeekTwo(Date firstDate, Date secondDate)
    {
        weekTwo = getTwoDate(firstDate, secondDate);
    }

    public String getWeekTwo()
    {
        return weekTwo;
    }
    public void setWeekThree(Date firstDate, Date secondDate)
    {
        weekThree = getTwoDate(firstDate, secondDate);
    }

    public String getWeekThree()
    {
        return weekThree;
    }
    public void setWeekFour(Date firstDate, Date secondDate)
    {
        weekFour = getTwoDate(firstDate, secondDate);
    }

    public String getWeekFour()
    {
        return weekFour;
    }
    public void setWeekFive(Date firstDate, Date secondDate)
    {
        weekFive = getTwoDate(firstDate, secondDate);
    }
    
    public String getWeekFive()
    {
        return weekFive;
    }
    
    public String getAsOfDate() {
		return asOfDate;
	}

	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
    
	public String formatDate(Date dateToFormat, String desiredFormat) 
    {
		String formattedDate = new String();
		formattedDate = new SimpleDateFormat(desiredFormat).format(dateToFormat);
		return formattedDate;	
	}
    
	public String getTwoDate(Date firstdate, Date seconddate)
	{
		return formatDate(firstdate, "MMM dd - ") + formatDate(seconddate, "dd");
	}
	
	public String getFormatedBetweenDate(Date firstdate, Date seconddate)
	{
		return " BETWEEN '" + formatDate(firstdate, "MM/dd/yyyy")+ "' AND '" + formatDate(seconddate, "MM/dd/yyyy") + "' ";
	}	
	
	public double getDiscountChargePerClientPerYear(String asOfMonth, long clientCode)
	{
		MonthlyChargesDAO monthlyCharges = (MonthlyChargesDAO)Persistence.getDAO("monthlyChargesDao");
		double retval = 0.00;
		String asOfDate = DateHelper.getLastDateOfTheMonth(asOfMonth);
		if (clientCode > 0)
		{
			String sSQL =	" SELECT " +
							" ISNULL(SUM(discountCharge), 0) as subTotal " +
							" FROM " +
							"(	" + 
								" SELECT " +     
								" DISTINCT(cast(Invoice.C_INVOICENO as varchar)) AS ref," +
								" (ISNULL(Invoice.N_INVOICEAMT,0) * (CC.N_SCR/100)) " +
								" * (dbo.GetBLR(Invoice.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100))" +
								" * (DATEDIFF(Day, " + 
								" Invoice.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360 AS discountCharge " +
								" FROM Invoice CROSS JOIN CC " +							
								" WHERE     Invoice.D_TRANSACTIONDATE " + 
								" BETWEEN '"+this.getJanuaryOfTheYear(asOfDate)+"' " +
								" AND '"+asOfDate+"' AND Invoice.C_CLNTCODE = "+clientCode+" AND " + 
								" Invoice.C_STATUS IN (2,3,4,5) AND CC.C_CLNTCODE = Invoice.C_CLNTCODE " +
								" UNION " +										
								" SELECT " + 
								" DISTINCT(CAST(Advances.N_REFNO AS VARCHAR)) AS ref, " +
								" ISNULL(Advances.N_ADVAMT,0) " +
								" * (dbo.GetBLR(Advances.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100)) " +
								" * (DATEDIFF(Day,Advances.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360 AS discountCharge " +
								" FROM " +
								" Advances CROSS JOIN CC" +	 		
								" WHERE " +     
								" Advances.D_TRANSACTIONDATE " +
								" BETWEEN " +
								" '"+this.getJanuaryOfTheYear(asOfDate)+"' AND '"+asOfDate+"' " +
								" AND Advances.C_CLNTCODE = "+clientCode+" AND " +
								" Advances.C_STATUS = 2 " + 	
								" AND Advances.C_TYPE IN ('1','2') " +
								" AND CC.C_CLNTCODE = Advances.C_CLNTCODE  " +
	
								" UNION " + 
								" SELECT " + 
								" DISTINCT(CAST(ReceiptsHdr.N_REFNO AS VARCHAR)) AS ref, " +
	 
								" CASE WHEN N_TOTINVAMT < N_AMOUNT THEN " +
		
								" (ISNULL(ReceiptsHdr.N_TOTINVAMT, 0) " +  
								" * " + 
								" (dbo.GetBLR(ReceiptsHdr.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100)) * (DATEDIFF(Day, " + 
								" ReceiptsHdr.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360) * -1 " +
								" ELSE " +
								" (ISNULL(ReceiptsHdr.N_AMOUNT, 0) " + 
								" * " + 
								" (dbo.GetBLR(ReceiptsHdr.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100)) * (DATEDIFF(Day, " + 
								" ReceiptsHdr.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360) * - 1 " +
								" END " +
								" AS discountCharge " +
								" FROM " + 
								" ReceiptsHdr " +
								" CROSS JOIN CC " +							
								" WHERE " +     
								" ReceiptsHdr.D_TRANSACTIONDATE " + 
								" BETWEEN " +
								" '"+this.getJanuaryOfTheYear(asOfDate)+"' AND '"+asOfDate+"' " + 
								" AND ReceiptsHdr.C_CLNTCODE = "+clientCode+" AND " + 
								" ReceiptsHdr.C_STATUS IN (1,2,4) " +  
								" AND ReceiptsHdr.C_RECEIPTTYPE IN (1,2) " +
								" AND CC.C_CLNTCODE = ReceiptsHdr.C_CLNTCODE " +
								"UNION "+
								"SELECT " +
								"DISTINCT(CAST(Refund.N_REFNO AS VARCHAR)) AS ref, " + 
								"(ISNULL(Refund.N_INELIGIBLEREC , 0) " +
								"* " +
								" (dbo.GetBLR(Refund.C_CLNTCODE, '"+asOfDate+"') + (CC.N_DCR / 100)) * (DATEDIFF(Day," + 
								"Refund.D_TRANSACTIONDATE, '"+asOfDate+"') + 1) / 360) AS discountCharge " +
								"FROM " + 
								"Refund CROSS JOIN CC " +
								"WHERE " +
								"Refund.C_STATUS = 2 " +
								"AND " + 
								"Refund.C_CLNTCODE= " + clientCode + 
								" AND " +
								"Refund.D_TRANSACTIONDATE " + 
								"BETWEEN " +
								"'"+this.getJanuaryOfTheYear(asOfDate)+"' AND '"+asOfDate+"' " + 
								"AND Refund.C_CLNTCODE = "+clientCode+
								" UNION "+
								monthlyCharges.getMonthlyBalancesPrevFiu(asOfDate, clientCode) +
							" ) AS discCharge " ;
			
			log.info("[getDiscountChargePerClientPerYear]==>"+sSQL);
			try
			{
				retval = Double.parseDouble(getJdbcTemplate().queryForObject(sSQL, new RowMapper()
				{
		
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException {				
						return rs.getDouble("subTotal");
					}
					
				}
				
				).toString());
			}
			catch(Exception e)
			{
				retval = 0;
			}
		}
		else
		{
			retval = 0;
		}
		return retval;
	}
	
	
	
	private double getServiceChargePerYearPerClient(String branchCode, long clientCode, String asOfDate) throws SQLException
	{
		Statement stmt=null;
		ResultSet rs = null;
		Connection conn = new FactorConnection().getConnection();
		String sSQL = "SELECT TOP 1 (SUM(i.N_INVOICEAMT) * (c.N_SCR/100)) AS sCharge " +
				"FROM " +
				"Invoice AS i CROSS JOIN CC AS C " +
				"WHERE " +
				"i.D_TRANSACTIONDATE BETWEEN '"+ this.getJanuaryOfTheYear(asOfDate) +"' AND" +
				"'"+DateHelper.getLastDateOfTheMonth(asOfDate)+"' "+
				"AND i.C_CLNTCODE = c.C_CLNTCODE " +
				"AND i.C_BRANCHCODE = '"+branchCode+"' " +
				"AND c.C_CLNTCODE = i.C_CLNTCODE " +
				"AND c.C_CUSTCODE = i.C_CUSTCODE " +
				"AND i.C_STATUS BETWEEN 2 AND 6" +
				"AND i.C_CLNTCODE = '"+clientCode+"' " +
				"GROUP BY c.N_SCR ";				
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			if (rs.next())
			{
				return rs.getDouble(1);
			}
			stmt.close();
			rs.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			stmt.close();
			rs.close();
			conn.close();
		}
		log.info(sSQL);	
		return 0.00;		
	}
	private double getServiceChargePerMonthPerClient(String branchCode, long clientCode, String asOfDate) throws SQLException
	{
		Statement stmt=null;
		ResultSet rs = null;
		Connection conn = new FactorConnection().getConnection();
		String sSQL = "SELECT TOP 1 (SUM(i.N_INVOICEAMT) * (c.N_SCR/100)) AS sCharge " +
		"FROM " +
		"Invoice AS i CROSS JOIN CC AS C " +
		"WHERE " +
		"CAST(MONTH(i.D_TRANSACTIONDATE) as varchar) + '-' + CAST (YEAR(i.D_TRANSACTIONDATE) as varchar) " +
		" = " +
		"CAST(MONTH('"+asOfDate+"') as varchar) + '-' + CAST (YEAR('"+asOfDate+"') as varchar) " +
		"AND i.C_CLNTCODE = c.C_CLNTCODE " +
		"AND i.C_BRANCHCODE = '"+branchCode+"' " +
		"AND c.C_CLNTCODE = i.C_CLNTCODE " +
		"AND c.C_CUSTCODE = i.C_CUSTCODE " +
		"AND i.C_STATUS BETWEEN 2 AND 6" +
		"AND i.C_CLNTCODE = '"+clientCode+"' " +
		"GROUP BY c.N_SCR ";
		
		log.info("[getServiceChargePerMonthPerClient]==>"+sSQL);
		
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			if (rs.next())
			{
				return rs.getDouble(1);
			}
			stmt.close();
			rs.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			stmt.close();
			rs.close();
			conn.close();
		}			
		return 0.00;		
	}
	
	private double getServiceCharge(String branchCode, long clientCode, String asOfDate)throws SQLException
	{
		Statement stmt=null;
		ResultSet rs = null;
		Connection conn = new FactorConnection().getConnection();			
		String sSQL = "SELECT top 1 " + 
					  "(SUM(i.N_INVOICEAMT) * (c.N_SCR/100)) AS sCharge " + 
					  "FROM " + 
					  "		Invoice AS i CROSS JOIN CC AS C " + 
					  "WHERE " + 
					  "i.D_TRANSACTIONDATE " + asOfDate +  					  
					  " AND i.C_CLNTCODE = c.C_CLNTCODE " + 
					  "AND i.C_BRANCHCODE = '"+branchCode+"' " + 
					  "AND " + 
					  "c.C_CLNTCODE = i.C_CLNTCODE " + 
					  "AND " +  
					  "c.C_CUSTCODE = i.C_CUSTCODE " +  
					  "AND i.C_STATUS BETWEEN 2 AND 6 " +  
					  "AND i.C_CLNTCODE = " +clientCode +
					  " GROUP BY " + 
					  "c.N_SCR";
		
		log.info("[getServiceCharge]==>"+sSQL);
		
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			if (rs.next())
			{
				return rs.getDouble(1);
			}
			stmt.close();
			rs.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			stmt.close();
			rs.close();
			conn.close();
		}
		
		return 0.00;
	}
	
	public int updateMonthlyDC(long clientCode, String month, double monthlyDC) {
		int result = 0;		
		Statement stmt=null;
		ResultSet rs = null;
		Connection conn = new FactorConnection().getConnection();			
		String sSQL = "UPDATE MonthlyDC set " + month + " = " + monthlyDC + " where C_CLNTCODE = " + clientCode;
		log.info("[getServiceCharge]==>"+sSQL);
		
		try
		{
			stmt = conn.createStatement();
			result = stmt.executeUpdate(sSQL);
			
			//stmt.close();			
			//conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}			
		}		
		return result;
	}
	
	public double getYearlyDC(long clientCode, String month)
	{
		Statement stmt=null;
		ResultSet rs = null;
		Connection conn = new FactorConnection().getConnection();			
		String sSQL = "SELECT * from MONTHLYDC where c_clntcode = " + clientCode;
		double ytdTotal = 0.0;
		MonthlyDC moDC = new MonthlyDC();				
		log.info("[getServiceCharge]==>"+sSQL);
		
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			if (rs.next())
			{				
				moDC.setClientCode(rs.getLong("C_CLNTCODE"));
				moDC.setJanuary(rs.getDouble("January"));
				moDC.setFebruary(rs.getDouble("February"));
				moDC.setMarch(rs.getDouble("March"));
				moDC.setApril(rs.getDouble("April"));
				moDC.setMay(rs.getDouble("May"));
				moDC.setJune(rs.getDouble("June"));
				moDC.setJuly(rs.getDouble("July"));
				moDC.setAugust(rs.getDouble("August"));
				moDC.setSeptember(rs.getDouble("September"));
				moDC.setOctober(rs.getDouble("October"));
				moDC.setNovember(rs.getDouble("November"));
				moDC.setDecember(rs.getDouble("December"));				
			}
			stmt.close();
			rs.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				rs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		
		if (month.equalsIgnoreCase("January")) {
			ytdTotal = moDC.getJanuary();
		}
		else if (month.equalsIgnoreCase("February")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary();
		}
		else if (month.equalsIgnoreCase("March")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch();
		}
		else if (month.equalsIgnoreCase("April")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril();
		}
		else if (month.equalsIgnoreCase("May")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril() + moDC.getMay();
		}
		else if (month.equalsIgnoreCase("June")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril() + moDC.getMay() + moDC.getJune();
		}
		else if (month.equalsIgnoreCase("July")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril() + 
			moDC.getMay() + moDC.getJune() + moDC.getJuly();
		}
		else if (month.equalsIgnoreCase("August")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril() + 
			moDC.getMay() + moDC.getJune() + moDC.getJuly() + moDC.getAugust();
		}
		else if (month.equalsIgnoreCase("September")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril() + 
			moDC.getMay() + moDC.getJune() + moDC.getJuly() + moDC.getAugust() + moDC.getSeptember();
		}
		else if (month.equalsIgnoreCase("October")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril() + 
			moDC.getMay() + moDC.getJune() + moDC.getJuly() + moDC.getAugust() + moDC.getSeptember() + moDC.getOctober();
		}
		else if (month.equalsIgnoreCase("November")) {
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril() + 
			moDC.getMay() + moDC.getJune() + moDC.getJuly() + moDC.getAugust() + moDC.getSeptember() + moDC.getOctober() + moDC.getNovember();
		}
		else if (month.equalsIgnoreCase("December")) {			
			ytdTotal = moDC.getJanuary() + moDC.getFebruary() + moDC.getMarch() + moDC.getApril() + 
			moDC.getMay() + moDC.getJune() + moDC.getJuly() + moDC.getAugust() + moDC.getSeptember() + moDC.getOctober() + moDC.getNovember() + moDC.getDecember();
		}
		
		System.out.println("ytdTotal: " + ytdTotal + ": clientCode: " + clientCode);
		return ytdTotal;
		
	}
	
	private double getDunning(long clientCode)throws SQLException
	{
		Statement stmt=null;
		ResultSet rs = null;
		Connection conn = new FactorConnection().getConnection();			
		String sSQL = "SELECT dbo.GetDunning('" + clientCode +"', '5', DATEADD(MM,-6,'"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"'), '"+DateHelper.getLastDateOfTheMonth(this.getAsOfDate())+"')" ;
		
		log.info("[getDunning]==>"+sSQL);
		
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			if (rs.next())
			{
				return rs.getDouble(1);
			}
			stmt.close();
			rs.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			stmt.close();
			rs.close();
			conn.close();
		}
		
		return 0.00;
	}
	
	
	public double getTotalAllClientRec(String branchCode, String asOfDate){
		double retval =0;
		
		SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
		String firstDayOfTheMonth = SDF.format(DateHelper.getDateInFirstDay(asOfDate));
		String mo=DateUtils.getLastMonthMMM(asOfDate);
		log.info(mo);
	
//		String sSQL = "SELECT ISNULL(SUM(ISNULL(n_invoiceamt,0)),0)+" +
//		              "(SELECT ISNULL(SUM(isnull(N_"+ mo + "REC,0)),0) from monthlybalances mb " +
//		              "INNER JOIN dbcif.dbo.client c on mb.c_clntcode=c.c_clntcode " +
//		              "WHERE mb.c_clntcode >= 124 AND c.c_branchcode='"+branchCode+ "')-" +
//		              "(SELECT ISNULL(SUM(ISNULL(ISNULL(rd.n_receiptamt,0)+ISNULL(cn.n_amount,0),0)),0) " +
//		              "FROM receiptsdtl rd " + 
//		              "INNER JOIN receiptshdr rh " +
//		              "ON rh.n_refno=rd.n_refno " +
//		              "LEFT JOIN creditnote cn " +
//		              "ON rd.c_invoiceno=cn.c_invoiceno " + 
//		              "AND rh.c_clntcode=cn.c_clntcode " + 
//		              "AND rh.c_custcode=cn.c_custcode " + 
//		              "AND rd.n_refno=cn.c_receiptno " +
//		              "WHERE rh.d_datebounced is  NULL " +
//		              "AND rh.c_clntcode >=124 AND rh.c_branchcode='"+branchCode+ "' " +
//		              "AND rh.d_transactiondate BETWEEN '" +firstDayOfTheMonth + "' AND '" + asOfDate +"') as totalAllClientRec " +
//		              "FROM invoice where c_status BETWEEN '2' and '6' " +
//		              "AND c_clntcode >=124 AND c_branchcode='"+branchCode+ "' " +
//		              "AND d_transactiondate BETWEEN '"+ firstDayOfTheMonth + "' AND '" + asOfDate + "'";
		
		String sSQL = "SELECT ISNULL(SUM(ISNULL(inv.n_invoiceamt,0)-isnull(rcts.n_receiptamt,0)),0) totalAllClientRec " + 
		              "from Invoice inv left join " +
		              "(select sum(rd.n_receiptamt) as n_receiptamt,rd.n_invno from ReceiptsHdr rh inner join ReceiptsDtl rd " +
		              "on rh.N_REFNO=rd.N_REFNO and rh.c_status!='3'group by rd.n_invno)rcts on inv.N_INVNO=rcts.N_INVNO " +
		              "where inv.C_STATUS in ('2','3','4') and c_clntcode >= 124 and d_transactiondate <= '" +asOfDate + "'";
			
			
		log.info(sSQL);
		retval = (Double)getJdbcTemplate().queryForObject(sSQL, 
				new RowMapper()
				{
					@Override 
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{							
						return rs.getDouble("totalAllClientRec");							
					}
				}
			);
			
		return retval;
		
	}
	
	public int getInvCountWeekly(String branchCode, String betweenDate){
		
		int retval =0;

		String sSQL = "SELECT COUNT(N_REFNO) as InvCount  FROM Advances WHERE " + 
				      "D_TRANSACTIONDATE " + betweenDate +  
				      " AND C_BRANCHCODE='"+ branchCode +"' AND C_STATUS ='2'"; 
		

		log.info(sSQL);
		retval = (Integer)getJdbcTemplate().queryForObject(sSQL, 
				new RowMapper()
				{
					@Override 
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{							
						return rs.getInt("invCount");							
					}
				}
			);
			
		return retval;
		
	}
	
	public int getInvCountYTD(String branchCode, String asOfDate){
		
		int retval =0;
					  
		String sSQL = "SELECT COUNT(N_REFNO) as InvCount  FROM Advances WHERE " + 
				      "D_TRANSACTIONDATE BETWEEN '" + this.getJanuaryOfTheYear(asOfDate) + "' AND '" + asOfDate + "' " +
				      "AND C_BRANCHCODE='"+ branchCode +"' AND C_STATUS ='2'"; 
		

		log.info(sSQL);
		retval = (Integer)getJdbcTemplate().queryForObject(sSQL, 
				new RowMapper()
				{
					@Override 
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{							
						return rs.getInt("invCount");							
					}
				}
			);
			
		return retval;
		
	}
	
	
	public static void main(String[] args) throws SQLException
	{    	
//		//WeeklyBookingDAO wkBookDao = (WeeklyBookingDAO)Persistence.getDAO("weeklyBookingDao");
//		//System.out.println(wkBookDao.getLastDateOfTheMonth("01/02/2009"));
//		//wkBookDao.setBusinessDays("07/31/2009");
//		//wkBookDao.getWeeklyBooking("02");		
//		//System.out.println(wkBookDao.getJanuaryOfTheYear(("01/03/1980")));
//		
//		Statement stmt=null;
//		ResultSet rs = null;
//		Connection conn = new FactorConnection().getConnection();			
//		String sSQL = "SELECT dbo.GetDunning('166', '5', DATEADD(MM,-6,'10/31/2010'), '10/31/2010')" ;
//		
//		log.info("[getServiceCharge]==>"+sSQL);
//		
//		try
//		{
//			stmt = conn.createStatement();
//			rs = stmt.executeQuery(sSQL);
//			if (rs.next())
//			{
//				System.out.println( rs.getDouble(1));
//			}
//			stmt.close();
//			rs.close();
//			conn.close();
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//		finally
//		{
//			stmt.close();
//			rs.close();
//			conn.close();
//		}
		double test1 = 0;
		if (test1 <= 0.0) {
			System.out.println("less or equal 0");
		} else {
			System.out.println("greater than 0");
		}
	}
	
	public double getYearlyDC(String asOfDate, String clntcode){
		
		 SimpleDateFormat SDF= new SimpleDateFormat("MM/dd/yyyy");
		 Calendar s = Calendar.getInstance();
		 String year="";
		 try {
			s.setTime(SDF.parse(asOfDate));
			  year =String.valueOf(s.get(Calendar.YEAR));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = "SELECT ISNULL(ROUND(SUM(ISNULL(N_ORIGINVOICEAMT,0)), 3),0) FROM Invoice WHERE	"+  
					"	D_TRANSACTIONDATE  between '01/01/"+year+"' and '"+asOfDate+"'	"+
					"	AND C_STATUS BETWEEN 2 AND 6  AND c_clntcode ="+clntcode;
		double YDC = (Double) getJdbcTemplate().queryForObject(sql, Double.class);
		return	YDC;
	}
	
}