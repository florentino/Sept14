package com.bdo.factor.dataSource;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.bdo.factor.dao.Persistence;

import com.bdo.factor.util.FactorConnection;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class MenuDAO extends JdbcDaoSupport 
{
	private static Logger log = Logger.getLogger(MenuDAO.class);

	public String getMenuItems(String userRole, String target, String urlPath) throws SQLException
	{
		//String retval = "{";
		String retval = "";
		String sSQL   = "";		
		Statement stmt = null;
		ResultSet rs   = null;
		Connection conn = null;
		sSQL = "SELECT distinct(mr.MOD_NAME), mr.MOD_DESC, CLASS_ORDER " + 
			   "FROM ModuleReference mr CROSS JOIN " + 
			   "RoleModule rm " + 
			   "WHERE " + 
			   "rm.ROLE = '"+userRole+"' AND " + 			   
			   "rm.MOD_NAME = mr.MOD_NAME " + 
			   "AND (" +
			   " ISNULL(LEN(mr.PARENT_MOD_NAME), 0) > 0 " +
			   "OR NOT mr.PARENT_MOD_NAME = '0' " +
			   "OR ISNULL(LEN(mr.CLASS_ORDER), 0) > 0 " +
			   "OR mr.CLASS_ORDER <> '0') " +
			   "AND (ISNULL(LEN(mr.SUB_ORDER), 0) = 0 OR mr.SUB_ORDER = '0') " +
			   "ORDER BY CLASS_ORDER "; 
		log.info("-getMenuItems-->"+sSQL);
		try {
			conn = new FactorConnection().getConnection(); 
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			while(rs.next())
			{				
								
				retval += "<li><span><strong>"+rs.getString(2)+"</strong></span>"+this.getChildMenuItems(target, urlPath, rs.getString(1))+this.getSubMenu(target, urlPath, rs.getString(1))+"</li>";
				
			}									
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) 
		{			
			e.printStackTrace();
		}
		finally
		{
			rs.close();
			stmt.close();
			conn.close();
		}
		
		//retval +="}";
		return retval;
	}
	
	public String getChildMenuItems(String target, String urlPath, String parentId) throws SQLException
	{
		String retval = "";
		String sSQL = "";
		
		Statement stmt = null;
		ResultSet rs   = null;
		Connection conn = null;
		String data = "";
		sSQL = "SELECT " +
				"DISTINCT(mc.CLASS_NAME), cr.CLASS_DESC, cr.url " +
				"FROM " +
				"ClassReference cr CROSS JOIN " +
				"ModuleClass mc " +
				"WHERE " +
				"cr.CLASS_NAME = mc.CLASS_NAME " +
				"AND mc.MOD_NAME = '"+parentId+"' AND ISNULL(LEN(cr.URL), 0) > 0 AND cr.URL <> '0' ";				
		log.info("-getChildMenuItems-"+parentId+"->"+sSQL);
		try
		{
			conn = new FactorConnection().getConnection(); 
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);		
			while(rs.next())
			{								
				if (rs.getString(3).equalsIgnoreCase("popReport"))
				{
					data +="<li><a target=\""+target+"\" href=\""+urlPath+"/"+rs.getString(3)+".BDOFactor?view="+rs.getString(1)+"\"&pop=1>"+rs.getString(2)+"</a></li>";
				}
				else
				{
					data +="<li><a target=\""+target+"\" href=\""+urlPath+"/"+rs.getString(3)+".BDOFactor?view="+rs.getString(1)+"\">"+rs.getString(2)+"</a></li>";
				}
			}
			
			if (!data.equals(""))
			{
				retval += "<ul>"+data+"</ul>";
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch (SQLException e) 
		{			
			e.printStackTrace();
		}
		finally
		{
			rs.close();
			stmt.close();
			conn.close();
		}
		return retval;
	}
	
	public String getSubMenu(String target, String urlPath, String parentId) throws SQLException
	{
		Statement stmt = null;
		ResultSet rs   = null;
		Connection conn = null;
		String data = "";
		String retval = "";		
		
		String sSQL = "SELECT MOD_NAME, " +
					  " MOD_DESC " +  
					  " FROM moduleReference " +
					  " WHERE " +
					  " PARENT_MOD_NAME='"+parentId+"' " +
					  " AND (ISNULL(LEN(CLASS_ORDER), 0) = 0 OR CLASS_ORDER=0) " +
					  " ORDER BY SUB_ORDER ";
		
		log.info("-getSubMenu-"+parentId+"->"+sSQL);
		
		try
		{
			conn = new FactorConnection().getConnection(); 
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);
					
			while(rs.next())
			{												
				data +="<li><span><strong>"+rs.getString(2)+"</strong></span>"+this.getChildMenuItems(target, urlPath ,rs.getString(1))+"</li>";
			}
			if (!data.equals(""))
			{
				retval += "<ul>"+data+"</ul>";
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch (SQLException e) 
		{			
			e.printStackTrace();
		}
		finally
		{
			rs.close();
			stmt.close();
			conn.close();
		}
		
		return retval;
	}		

	public String newGetMenuItems(String userRole, String target, String urlPath) throws SQLException
	{
		//String retval = "{";
		String retval = "";
		String sSQL   = "";		
		Statement stmt = null;
		ResultSet rs   = null;
		Connection conn = null;
		sSQL = "select distinct(mr.mod_name)"+
				 " ,mr.mod_desc"+
				 " ,CASE WHEN mr.class_order is null THEN (select max(class_order) from modulereference)"+
						"WHEN mr.class_order=0 THEN	(select max(class_order) from modulereference)"+
						"ELSE mr.class_order END	 AS class_order	"+
			"from "+
				"rolemodule rm "+
				"	inner join "+
				"		modulereference mr on rm.mod_name=mr.mod_name"+
				"	inner join"+
				"		rolereference rr on rm.role=rr.role "+
			"where rm.role='"+userRole+"'"+
			"AND (mr.parent_mod_name='' OR  mr.parent_mod_name is null)"+
			"AND MOD_DESC <> 'PUBLIC'"+
			"order by class_order,mr.mod_name";

		log.info("-getMenuItems-->"+sSQL);
		try {
			conn = new FactorConnection().getConnection(); 
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);
			while(rs.next())
			{				
								
				retval += "<li><span><strong>"+rs.getString(2)+"</strong></span><ul>"+this.newGetChildMenuItems(rs.getString(1), target, urlPath)+"</ul></li>";
				
			}									
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) 
		{			
			e.printStackTrace();
		}
		finally
		{
			rs.close();
			stmt.close();
			conn.close();
		}
		
		//retval +="}";
		return retval;
	}

	public String newGetChildMenuItems(String parent, String target,String urlPath) throws SQLException
	{
		String retval = "";
		String sSQL = "";
		
		Statement stmt = null;
		ResultSet rs   = null;
		Connection conn = null;
		String data = "";
		sSQL ="select distinct(cr.class_name),cr.class_desc,cr.url from moduleclass  mc "+
				"inner join "+
				"classreference cr on mc.class_name=cr.class_name "+
				"where mod_name='"+parent+"'AND (URL is not null AND LEN(URL) <> 0) order by cr.class_desc";
		try
		{
			conn = new FactorConnection().getConnection(); 
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);		
			while(rs.next())
			{								
				if (rs.getString(3)!=null&&rs.getString(3).equalsIgnoreCase("popReport"))
				{
					data +="<li><a target=\""+target+"\" href=\""+urlPath+"/"+rs.getString(3)+".BDOFactor?view="+rs.getString(1)+"\"&pop=1>"+rs.getString(2)+"</a></li>";
				}
				else
				{
					data +="<li><a target=\""+target+"\" href=\""+urlPath+"/"+rs.getString(3)+".BDOFactor?view="+rs.getString(1)+"\">"+rs.getString(2)+"</a></li>";
				}
			}
			
			if (!data.equals(""))
			{
			retval += data;
			}
			 
		}
		catch (SQLException e) 
		{			
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			rs.close();
			stmt.close();
			conn.close();
		}
//childparent
		data = "";
		sSQL ="SELECT distinct(mr.mod_name)" +
					 ",mod_desc," +
					 "CASE WHEN  class_order is null THEN (select max(class_order) from modulereference)"+
						   "WHEN  class_order=0 THEN	(select max(class_order) from modulereference)"+
						   "ELSE  class_order END	 AS class_order " +
			   "FROM modulereference mr " +
			   		"INNER JOIN rolemodule rm ON mr.mod_name = rm.mod_name " +
			   "WHERE parent_mod_name = '"+parent+"' " +
			   "ORDER BY class_order,mr.mod_name";
		try
		{
			conn = new FactorConnection().getConnection(); 
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sSQL);		
			while(rs.next())
			{								
				retval += "<li><span><strong>"+rs.getString(2)+"</strong></span><ul>"+this.newGetChildMenuItems(rs.getString(1), target, urlPath)+"</ul></li>";
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch (SQLException e) 
		{			
			e.printStackTrace();
		}
		finally
		{
			rs.close();
			stmt.close();
			conn.close();
		}
		
		return retval;
	}

}
