package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.AuditLogs;
import com.bdo.factor.beans.ClientDebtTurn;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;

public class AuditLogsDAO extends JdbcDaoSupport{
	private Logger log = Logger.getLogger(AuditLogsDAO.class);
	
	private SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	public List<AuditLogs> getAuditLogs(String userID, String branchCode, String startDate, String endDate){
		List<AuditLogs> lResult= new ArrayList<AuditLogs>();
		StringBuilder userQuery = new StringBuilder();
		
		if (userID != null && userID.trim() != "") {
			userQuery.append(" and usertable.c_userId = '").append(userID).append("'");
		}
		if (branchCode != null && branchCode.trim() != "") {
			userQuery.append(" and branch.c_branchcode = '").append(branchCode).append("'");
		}
		
		startDate = startDate + " 00:00:00";
		endDate = endDate +  " 23:59:59";
				//removed 'order by' as of 10/21/15 by Garcia		
		String sSQL = "select usertable.c_userid, " +
				"type=(CASE WHEN Type='U' THEN 'Update' " +
				"WHEN Type='I' THEN 'Insert' WHEN Type='D' THEN 'Delete' ELSE 'Unrecognized' END) " +
				", audit.tablename, audit.newvalue, audit.updatedate, usertable.c_branchcode, " +
				"branch.c_branchname from audit " +
				"inner join usertable on usertable.c_userid = audit.userID " +
				"inner join branch on branch.c_branchcode = usertable.c_branchcode " +
				"where audit.UpdateDate between '" + startDate + "' AND '" + endDate + "'";
		
		
		//moved 'order by' here as of 10/21/15 by Garcia		
		if (userQuery.toString() != null) {
			sSQL = sSQL + userQuery.toString() + " order by audit.updatedate";
		}
			
		log.info(sSQL);
		lResult =getJdbcTemplate().query(sSQL, new RowMapper(){
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				AuditLogs audit = new AuditLogs();
				FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");	
				audit.setBranchName(rs.getString("c_branchname"));
				audit.setNewValue(rs.getString("newvalue"));
				audit.setTableName(rs.getString("tablename"));
				audit.setType(rs.getString("type"));				
				audit.setUpdateDate(formatter.format(rs.getTimestamp("updatedate")));				
				audit.setUserId(rs.getString("c_userid"));
				audit.setCurrentDate(date.newDate());
				return audit;
			}			
		});
					
		return lResult;
	}
		
}
