package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.beans.FactoringManagement;
import com.bdo.factor.beans.PDODelinquent;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;

public class PDODelinquentDAO2 extends JdbcDaoSupport {
	
	//CLASS VARIABLES
	private Logger log = Logger.getLogger(PDODelinquentDAO2.class);
	private Integer pdo;
	private Integer PDOInvoices;
	private Integer DelinquentInvoices;
	private Integer pdodelTotal;
	private Double TotPDO;
	private Double TotDel;
	private Double TotPDODel;
	
	
	private Double rowNumber =0.0;
	private Double rowCount =0.0 ;
	private Boolean process;
	private Boolean completed;
	private Boolean error;
	private Integer remaining;
	private Map updateMap;
	
	@SuppressWarnings("unchecked")
	public List<PDODelinquent> getField(String asOfDate, String branchCode) {
		setProcess(false);
		List<PDODelinquent> lFm = new ArrayList<PDODelinquent>();
		List<PDODelinquent> lResult = new ArrayList<PDODelinquent>();
		
		PDOInvoices=0;
		DelinquentInvoices=0;
		pdodelTotal=0;
		TotPDO =0.0;
		TotDel=0.0;
		TotPDODel=0.0;
		setRowCount(0.0);
		
		final String strAsOfDate = asOfDate;
		Date dAsOfDate = DateHelper.parse(asOfDate);
		try{
			String ssql = "SELECT  "+
				"count(Client)	"+
				"	FROM	"+	
				"		(	"+			
				"		SELECT TOP 100 PERCENT	"+		 
				"			v2.C_NAME AS Client,	  	"+
				"			V2.N_DUNNING AS DunningPerLAM,	"+
				""+						 
				"			CASE WHEN v1.D_FULLYPAIDDATE = '' THEN	"+	
				"				(DATEDIFF(d,v1.D_FULLYPAIDDATE,'" + strAsOfDate + "')  +1)	"+	
				"			ELSE	"+	
				"				(DATEDIFF(d,v1.D_INVOICEDATE,'" + strAsOfDate + "'))	"+	
				"			END AS InvoiceAge	"+ 				
				"		FROM	"+		
				"			Invoice v1 INNER JOIN CC v2 on v1.C_CLNTCODE = v2.C_CLNTCODE	"+	
				"			AND v1.C_CUSTCODE = v2.C_CUSTCODE	"+	
				"			left outer join receiptsdtl rd on rd.n_invno = v1.n_invno	"+	   			
				"		WHERE	"+	
				"			v1.D_INVOICEDATE <= '" + strAsOfDate + "'	"+	
				"			AND v1.C_BRANCHCODE = v2.C_BRANCHCODE	"+	
				"			AND v1.C_BRANCHCODE = 01"+	
				"			AND v1.C_STATUS BETWEEN 2 AND 4	"+	 
				"		GROUP BY v1.d_transactiondate,v1.N_TERM,v1.n_invno,v1.c_invoiceno,v1.d_invoicedate,v1.d_invoiceduedate,v1.c_status,v1.n_invoiceamt,v1.d_fullypaiddate,v2.C_ACCTOFFICERCODE,v2.c_name,v2.C_CUSTNAME,v2.n_dunning,v2.c_clntcode,v2.N_ADVANCEDRATIO,v2.c_custcode"+	
				"		ORDER BY 	v2.C_NAME, v2.C_CUSTNAME, v1.D_INVOICEDATE"+		 		
				"		) AS PDOInvoices"+	
				"	WHERE InvoiceAge >  DunningPerLAM	";
			setRowNumber((Double) getJdbcTemplate().queryForObject(ssql,Double.class));
		}catch(Exception e){
			e.printStackTrace();
			setError(true);
			setRowNumber(0.0);
		}
		setProcess(true);
		String sSQL = 
				"SELECT  "+
						"Client,  " +
						"CASE WHEN datediff(day,dateadd(day,DunningPerLAM+span,d_invoicedate),'" + strAsOfDate + "')<0 THEN	(select sum(discountCharge) FROM  dbo.getpartialpaymentDC(c_clntcode,n_invno,'" + strAsOfDate + "')) else 0 END as dcAccrual,	" +
						"dateadd(day,DunningPerLAM,d_invoicedate) as dateDunning,	" +
						"dateadd(day,DunningPerLAM+span,d_invoicedate) as pastDueDate,	"+
						//"dcAccrual = ( ),	"+
						"n_invno,	"+
						"AO,  "+
						"c_custcode,	"+
						"c_clntcode,	"+
						"dcr/100 as dcr, "+
						"Customer,	"+  
						"DunningPerLAM,	"+  
						"CreditTerm,	"+ 
						"InvoiceNumber,	"+ 
						"d_invoicedate,	"+
						"remainingAmount,	"+
						"(ISNULL(remainingAmount,0)*PrePaymentRatio) as prePaymentAdvAmount,"+
						"d_transactiondate,	"+
						"CASE WHEN datediff(day,dateadd(day,90,d_invoiceduedate),'" + strAsOfDate + "')>1 then 1 else 0 end as status,"+
						"Amount,	"+
						"(ISNULL(Amount,0)*PrePaymentRatio) as origPrePayInvAmount,"+
						"d_invoiceduedate,	"+
						"advDate,	"+
						"refDate,	"+
						"rhDate,	"+
						"case when advDate < refDate then refdate else advdate end as d_lastDCCollection,"+
						"lastPayment=(select max(d_transactiondate) from receiptsdtl rd inner join receiptshdr rh on rd.n_refno = rh.n_refno AND c_invoiceno=PDOInvoices.InvoiceNumber AND rh.c_status IN (2,4) and rh.c_clntcode=PDOInvoices.c_clntcode AND rh.c_custcode=PDOInvoices.c_custcode),	"+
						"InvoiceAge as actualInvoiceAge,	"+ 
						"ABS(DunningPerLAM - InvoiceAge) AS actualInvoiceAgeLessLam,	"+
						"PrePaymentRatio,	"+
						"CASE WHEN ABS(DunningPerLAM - InvoiceAge) > 1 AND ABS(DunningPerLAM - InvoiceAge) < 31  THEN	"+
							"ROUND((PrePaymentRatio * remainingAmount), 3)	"+
						"ELSE	"+
							"0.00	"+
						"END AS NetBal1_30,	"+ 
						"CASE WHEN ABS(DunningPerLAM - InvoiceAge) > 31 AND ABS(DunningPerLAM - InvoiceAge) < 61  THEN	"+
							"ROUND((PrePaymentRatio * remainingAmount), 3)	"+
						"ELSE	"+
							"0.00	"+
						"END AS NetBal31_60,	"+
						"CASE WHEN ABS(DunningPerLAM - InvoiceAge) > 61 AND ABS(DunningPerLAM - InvoiceAge) < 91  THEN	"+
							"ROUND((PrePaymentRatio * remainingAmount), 3)	"+
						"ELSE	"+
							"0.00	"+
						"END AS NetBal61_90,	"+ 
						"CASE WHEN ABS(DunningPerLAM - InvoiceAge) > 90  THEN	"+
							"ROUND((PrePaymentRatio * remainingAmount), 3)	"+
						"ELSE	"+
							"0.00	"+
						"END AS NetBalgt90,	"+
						"PC,	"+
						"PDI,	"+
						"(ROUND((PrePaymentRatio * remainingAmount), 3))as netUnpaidInterestPenalty,	"+
						"(ROUND((PrePaymentRatio * remainingAmount), 3)) + PDI as netUnpaidDC,	"+
						"(ROUND((PrePaymentRatio * remainingAmount), 3)) + PC + PDI as netUnpaidDCPenalty	"+
				"FROM	"+
					"(	"+		
					"SELECT TOP 100 PERCENT	"+	 
						"v2.C_ACCTOFFICERCODE AS AO,	"+
						"v2.C_NAME AS Client,	"+ 
						"v2.C_CUSTNAME AS Customer,	"+
						"V2.N_DUNNING AS DunningPerLAM,	"+
						"v2.c_clntcode,	"+
						"v2.c_custcode,	"+
						"v1.N_TERM AS CreditTerm,	"+
						"v1.n_invno,	"+	
						"v1.C_INVOICENO AS InvoiceNumber,	"+
						"v1.d_invoicedate,	"+
						"v1.d_invoiceduedate,	"+
						"v1.c_status,	"+ 
						"v1.d_transactiondate,	" +
						"span = (select n_pastduespan from systemsettings),	"+
						"dcr = (select n_dcr from dbcif..client where c_clntcode=v1.c_clntcode),	"+
						"advDate = (select max(d_transactiondate) from advances where d_transactiondate <= convert(smalldatetime, '" + strAsOfDate + "') and c_clntcode=v2.c_clntcode and c_status='2' and c_type<>'2'),	"+	
						"refDate = (select max(d_transactiondate) from refund where d_transactiondate <= convert(smalldatetime, '" + strAsOfDate + "') and c_clntcode=v2.c_clntcode and c_status in ('2','4')),	"+
						"rhDate = (select max(d_transactiondate) from receiptsHdr where c_clntcode = v2.c_clntcode),	"+	
						"(v1.N_INVOICEAMT-   (ISNULL(sum(rd.n_receiptamt),0)-    ISNULL(    (select sum(rd.n_receiptamt) from receiptsdtl rd     inner join receiptshdr rh on rh.n_refno = rd.n_refno    where rh.c_status = '3' and rd.n_invno = v1.n_invno   ),0))   ) as remainingAmount      ,	"+
						"CASE WHEN v1.D_FULLYPAIDDATE = '' THEN	"+
							"(DATEDIFF(d,v1.D_FULLYPAIDDATE,'" + strAsOfDate + "') + 1)	"+
						"ELSE	"+
							"(DATEDIFF(d,v1.D_INVOICEDATE,'" + strAsOfDate + "'))	"+
						"END AS InvoiceAge,	"+				
					"ROUND(v1.N_INVOICEAMT, 3) AS Amount, (v2.N_ADVANCEDRATIO/100) AS PrePaymentRatio,	"+
						"PC = (select ISNULL(sum( n_penaltyamount ),0) from dbo.getPenChargePartial(v2.c_clntcode,01,v1.n_invno,'PC','" + strAsOfDate + "') ),	"+
						"PDI = (select ISNULL(sum( n_penaltyamount ),0) from dbo.getPenChargePartial(v2.c_clntcode,01,v1.n_invno,'PDI','" + strAsOfDate + "') )	"+
					"FROM	"+	
						"Invoice v1 INNER JOIN CC v2 on v1.C_CLNTCODE = v2.C_CLNTCODE	"+
						"AND v1.C_CUSTCODE = v2.C_CUSTCODE	"+
						"left outer join receiptsdtl rd on rd.n_invno = v1.n_invno	"+   			
					"WHERE	"+
						"v1.D_INVOICEDATE <= '" + strAsOfDate + "'	"+
						"AND v1.C_BRANCHCODE = v2.C_BRANCHCODE	"+
						"AND v1.C_BRANCHCODE = 01	"+
						"AND v1.C_STATUS BETWEEN 2 AND 4	"+ 
					"GROUP BY v1.c_clntcode, v1.d_transactiondate,v1.N_TERM,v1.n_invno,v1.c_invoiceno,v1.d_invoicedate,v1.d_invoiceduedate,v1.c_status,v1.n_invoiceamt,v1.d_fullypaiddate,v2.C_ACCTOFFICERCODE,v2.c_name,v2.C_CUSTNAME,v2.n_dunning,v2.c_clntcode,v2.N_ADVANCEDRATIO,v2.c_custcode	"+
					"ORDER BY 	v2.C_NAME, v2.C_CUSTNAME, v1.D_INVOICEDATE	"+	 		
					") AS PDOInvoices	"+
				"WHERE InvoiceAge >  DunningPerLAM	and remainingamount>0"+  
				"ORDER BY client,customer	";
		log.info(sSQL+ "testpoint");
		final InvoiceDAO ID = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		final ClientDAO cd = new ClientDAO();
		final Map infoMap = new HashMap();
		lFm =getJdbcTemplate().query(sSQL, new RowMapper(){
			Map chargesMap = new HashMap();
			String c_clntcodeold="",c_clntcodenew;
			Double DCAccrual = 0.0;
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				setRowCount((double) rowNum);
				PDODelinquent fm = new PDODelinquent();
				c_clntcodenew = rs.getString("c_clntcode");
				
				if(!c_clntcodeold.contentEquals(c_clntcodenew)){
					DCAccrual = 0.0;
					List<ClientActivities> ca =	cd.getClientActivities(c_clntcodenew, strAsOfDate);
					int index=ca.size()-1;
					fm.setClientFIU(ca.get(index).getTotalFiuBalance());
					fm.setClientReceivable(ca.get(index).getTotalReceivables());
					DCAccrual = ca.get(index).getDiscountCharges();
					c_clntcodeold=c_clntcodenew;
				}
				log.info(rs.getInt("status"));
				if(rs.getInt("status")==1){
					PDOInvoices++;
					TotPDO+=rs.getDouble("remainingAmount");
				}
				else{
					DelinquentInvoices++;
					TotDel+=rs.getDouble("remainingAmount");
				}
				
				TotPDODel+=rs.getDouble("remainingAmount");
				pdodelTotal++;
				//chargesMap = ID.getPenaltyCharge2(rs.getString("c_clntcode"),strAsOfDate,rs.getLong("n_invno"));
				//Double penaltyCharge = Double.parseDouble(chargesMap.get("penalty").toString());
				Double penaltyCharge = rs.getDouble("PC");
				
				//Double interest = Double.parseDouble(chargesMap.get("pastDue").toString());
				 
				Double interest = rs.getDouble("PDI")+rs.getDouble("dcAccrual"); 
				fm.setC_clntcode(rs.getString("c_clntcode"));
				fm.setD_lastAdvance(rs.getDate("advDate"));
				fm.setD_lastRefund(rs.getDate("refDate"));
				fm.setD_lastCollection(rs.getDate("rhDate"));
				fm.setD_lastDCCollection(rs.getDate("d_lastDCCollection"));
				fm.setC_clntName(rs.getString("Client"));
				fm.setAo(rs.getString("AO"));
				fm.setC_custName(rs.getString("Customer"));
				fm.setC_invoiceNo(rs.getString("InvoiceNumber"));
				fm.setDunningPerLam(rs.getInt("DunningPerLAM"));
				fm.setD_invoiceDate(rs.getDate("d_invoicedate"));
				fm.setN_origAmount(rs.getDouble("Amount"));
				fm.setN_advRatio(rs.getDouble("PrePaymentRatio"));
				fm.setOrigPrePayInvAmount(rs.getDouble("origPrePayInvAmount"));
				fm.setD_transactionDate(rs.getDate("d_transactionDate"));
				fm.setD_dateBasedOnDunning(rs.getDate("dateDunning"));
				fm.setActualInvoiceAge(rs.getInt("actualInvoiceAge"));
				fm.setActualInvoiceAgeLessLam(rs.getInt("actualInvoiceAgeLessLam"));
				fm.setOutstandingInvBalance(rs.getDouble("remainingAmount"));
				fm.setPrePaymentAdvAmount(rs.getDouble("prePaymentAdvAmount"));
				fm.setD_lastInvCollection(rs.getDate("lastPayment"));
				fm.setUnpaidDC(interest);
				fm.setPenaltyCharge(penaltyCharge);
				fm.setDatePastDue(rs.getDate("pastDueDate"));
				fm.setNetBal1_30(rs.getDouble("NetBal1_30"));
				fm.setNetBal31_60(rs.getDouble("NetBal31_60"));
				fm.setNetBal61_90(rs.getDouble("NetBal61_90"));
				fm.setNetBalgt90(rs.getDouble("NetBalgt90"));
				fm.setNetUnpaidInterestPenalty(rs.getDouble("netUnpaidInterestPenalty"));
				fm.setNetUnpaidDC(rs.getDouble("netUnpaidDC")+rs.getDouble("dcAccrual"));
				fm.setNetUnpaidDCPenalty(rs.getDouble("netUnpaidDCPenalty")+rs.getDouble("dcAccrual"));
				fm.setStatus(rs.getInt("status"));
				fm.setDcr(rs.getDouble("dcr"));
				return fm;
			}	
		});
		if(lFm.size()>0){
			//PDODelinquentDAO.rowNumber=PDODelinquentDAO.rowCount;
			PDODelinquent pdo = new PDODelinquent();
			pdo.setTotPDODel(TotPDODel);
			pdo.setPdodelTotal(pdodelTotal);
			pdo.setAsOfDate(dAsOfDate);
			pdo.setTotDel(TotDel);
			pdo.setTotPDO(TotPDO);
			pdo.setPDOInvoices(PDOInvoices);
			pdo.setDelinquentInvoices(DelinquentInvoices);
			lFm.add(pdo);
			setRowNumber(getRowCount());
		}
		else{
			setRowCount(1.0);
			setRowNumber(1.0);
		}
		
		return lFm;
	}
	
	public Map getUpdate(){
		updateMap = new HashMap();
		updateMap.put("process",getProcess());
		updateMap.put("newValue",getRemaining());
		return  updateMap;
	}
 
	public Double getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Double rowNumber) {
		this.rowNumber = rowNumber;
	}

	public Double getRowCount() {
		return rowCount;
	}

	public void setRowCount(Double rowCount) {
		this.rowCount = rowCount;
	}

	public Boolean getProcess() {
		return process;
	}

	public void setProcess(Boolean process) {
		this.process = process;
	}

	public Boolean getCompleted() {
		return completed;
	}

	public void setCompleted(Boolean completed) {
		this.completed = completed;
	}

	public Integer getRemaining() {
		remaining = (int) Math.round((getRowCount()/getRowNumber())*100);
		return remaining;
	}

	public void setRemaining(Integer remaining) {
		this.remaining = remaining;
	}

	public Boolean getError() {
		return error;
	}

	public void setError(Boolean error) {
		this.error = error;
	}
}
