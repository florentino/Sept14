/**
 * @author KCabungcal 
 * 	Java Name	: ClientDebtTurnField.java * 	
 *  Source Code for ClientDebtTurnField
 **/ 

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Audit;
import com.bdo.factor.beans.ClientDebtTurn;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;

public class ClientDebtTurnField  implements JRDataSource{
	private Logger log = Logger.getLogger(VerifyInvoiceFieldOd.class);

	List<ClientDebtTurn> clientDebtTurnList= new ArrayList<ClientDebtTurn>();
	private int index =-1;
	private int lastIndex = 0;
	
	private String startDate;
	private String endDate;
	private String clientCode;
	private String customerCode;
	private String status;

	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	//dao
	ClientDebtTurnDAO cbt = (ClientDebtTurnDAO)Persistence.getDAO("clientDebtTurnDAO");
	
	public ClientDebtTurnField(String clientCode, String customerCode, String status, String startDate, String endDate){
		this.startDate=startDate;
		this.endDate=endDate;
		this.status=status;
		this.clientCode=clientCode;
		this.customerCode=customerCode;
		Map param = new HashMap();
		param.put("startDate", startDate);
		param.put("endDate", endDate);
		param.put("status", status);
		param.put("clientCode", clientCode);
		param.put("custCode", customerCode);
		
		clientDebtTurnList = cbt.getClientDebtTurn(clientCode, customerCode, status, startDate, endDate);
		lastIndex=clientDebtTurnList.size();
	}

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		ClientDebtTurn cdt = (ClientDebtTurn) clientDebtTurnList.get(index);
		
		if(clientDebtTurnList.size()>0){
				//ListIterator iter=clientDebtTurnList.listIterator();
				
				//while(iter.hasNext()){
					
					if("aoName".equals(field)){
						value=cdt.getAccountOfficer();
					}      		
					if("clientName".equals(field)){
						value=cdt.getClientName();    			
					}   		
					if("customerName".equals(field)){
						value=cdt.getCustomerName();    			
					}
					if("datePaid".equals(field)){
						value=DateHelper.format(cdt.getDatePaid());    			
					}
					if("invoiceDate".equals(field)){
						value=DateHelper.format(cdt.getInvoiceDate());    			
					}
					if("invoiceNo".equals(field)){
						value=cdt.getInvoiceNo();    			
					}
					if("monthPaid".equals(field)){
						value=cdt.getMonthPaid();    			
					}
					if("amount".equals(field)){
						value=df.format(cdt.getAmount());    			
					}
					if("amountCollected".equals(field)){
						value=df.format(cdt.getAmountCollected());    			
					}
					if("average".equals(field)){
						value=df.format(cdt.getAverage());    			
					}
					if("dunning".equals(field)){
						value=df.format(cdt.getDunning());    			
					}
					if("speedPaid".equals(field)){
						value=Integer.valueOf(cdt.getSpeedPaid()).toString();    			
					}
					if("totalAverage".equals(field)){
						value=df.format(cdt.getTotalAverage());    			
					}
					if("totalInvoice".equals(field)){
						value=df.format(cdt.getTotalInv());    			
					}
					if("amountDouble".equals(field)){
						value=cdt.getAmount();    			
					}
					if("averageDouble".equals(field)){
						value=cdt.getAverage();    			
					}
					if("currentDate".equals(field)){
						value=cdt.getCurrentDate();    			
					}
				//}	
				if ("dateRange".equals(field)) {
					value = startDate + "-" + endDate;
				}				
		}   


		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}
	
	public static void main (String[] args) {		
		ClientDebtTurnDAO cbt = (ClientDebtTurnDAO)Persistence.getDAO("clientDebtTurnDAO");
		List<ClientDebtTurn> l = cbt.getClientDebtTurn("38", "8", "5", "06/01/2009", "08/01/2009");
		ListIterator iter=l.listIterator();
		while(iter.hasNext()){
			ClientDebtTurn cdt = (ClientDebtTurn)iter.next();
			System.out.println(cdt.toString());
		}
	}

}
