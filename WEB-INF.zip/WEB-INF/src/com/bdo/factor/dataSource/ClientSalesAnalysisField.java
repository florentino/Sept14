package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;

public class ClientSalesAnalysisField implements JRDataSource{
	private Logger log = Logger.getLogger(ClientSalesAnalysisField.class);

	List<Client> list= new ArrayList<Client>();
	List list2= new ArrayList();
	CC cc = null;
	private int index =-1;
	private int lastIndex = 0;

	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");

	public ClientSalesAnalysisField(CC cc){
		this.cc = cc;
		ClientDAO clientDao = new ClientDAO();
		list	=	clientDao.getAllClientDetails(cc.getClientCode());
		list2	=	clientDao.getAllClientSalesAnalysis(cc);
		lastIndex=list2.size();
	}

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Object value = null;
		String field = jRField.getName();
		String[] str = list2.get(index).toString().split("@");
		if(index==0){
			Client c = (Client) list.get(0);
			if("clientName".equals(field)){
				value=c.getC_Name();
			}   
			if("year".equals(field)){
				value=DateHelper.getYear(cc.getAsOfDate());
			} 
			if("currency".equals(field)){
				value=c.getC_CurrencyCode();
			} 	
			if("currentDate".equals(field)){
				value=date.newDate();
			} 	
		}
		if(list2.size()>0/*&&((index+1)<lastIndex)*/){
			if("customerName".equals(field)){
				value=str[0];
			}      		
			if("jan".equals(field)){
				value=Double.parseDouble(str[1]);    			
			}  
			if("feb".equals(field)){
				value=Double.parseDouble(str[2]);    			
			}
			if("mar".equals(field)){
				value=Double.parseDouble(str[3]);    			
			}
			if("apr".equals(field)){
				value=Double.parseDouble(str[4]);    			
			}			
			if("may".equals(field)){
				value=Double.parseDouble(str[5]);    			
			}
			if("jun".equals(field)){
				value=Double.parseDouble(str[6]);    			
			}
			if("jul".equals(field)){
				value=Double.parseDouble(str[7]);
			}      		
			if("aug".equals(field)){
				value=Double.parseDouble(str[8]);    			
			}  
			if("sep".equals(field)){
				value=Double.parseDouble(str[9]);    			
			}
			if("oct".equals(field)){
				value=Double.parseDouble(str[10]);    			
			}
			if("nov".equals(field)){
				value=Double.parseDouble(str[11]);    			
			}
			if("dec".equals(field)){
				value=Double.parseDouble(str[12]);    			
			}
			if("gross".equals(field)){
				value=Double.parseDouble(str[13]);    			
			}
			if("creditNotes".equals(field)){
				value=Double.parseDouble(str[14]);    			
			}
			if("nett".equals(field)){
				value=Double.parseDouble(str[15]);    			
			}
			if("lastYear".equals(field)){
				value=Double.parseDouble(str[16]);    			
			}	
		}
		return value;
	}   

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}
}
