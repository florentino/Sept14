package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.AccountForReview;
import com.bdo.factor.beans.FactoringManagement;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;


public class FactoringManagementField implements JRDataSource{
	private Logger log = Logger.getLogger(FactoringManagementField.class);
	List<FactoringManagement> lFm = new ArrayList<FactoringManagement>();
	private int index =-1;
	private int lastIndex = 0;
	
	private String asOfDate;
	private String branchCode;
	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	SimpleDateFormat sdf = new SimpleDateFormat ("mm/dd/yyyy");
	
	FactoringManagementDAO fmDao = (FactoringManagementDAO)Persistence.getDAO("factoringManagementDAO");
	
	public FactoringManagementField(String asOfDate, String branchCode) {
		this.asOfDate=asOfDate;		
		this.branchCode=branchCode;
		
		Map param = new HashMap();
		param.put("asOfDate", asOfDate);		
		param.put("branchCode", branchCode);
		
		lFm = fmDao.getFactoringManagement2(asOfDate, branchCode);
		lastIndex = lFm.size();
	}
	
	public FactoringManagementField(String asOfDate, String branchCode, String operation,Boolean filter) {

		Map<String,String> param = new HashMap<String,String>();
		param.put("asOfDate", asOfDate);		
		param.put("branchCode", branchCode);
		
		if(operation.contentEquals("FactoredReceivable")){
			lFm = fmDao.getFactoringManagement3(asOfDate, branchCode);
		}
		if(operation.contentEquals("FactoredReceivableCredex")){
			lFm = fmDao.getFactoringManagement(asOfDate, branchCode,filter);
		}

		lastIndex = lFm.size();
	}
	
	
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		FactoringManagement fm = (FactoringManagement) lFm.get(index);
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");		
		if (lFm.size() > 0&&fm!=null) {
			if ("advancedRatio".equals(field)) {value = fm.getAdvancedRatio();}
			if ("c_ClntCode".equals(field)) {value = fm.getC_ClntCode();}
			if ("c_Name".equals(field)) {value = fm.getC_Name();}
			if ("aoName".equals(field)) {value = fm.getAoName();}
			if ("n_receivables".equals(field)) {value = fm.getN_receivables();}
			if ("n_dcAccrual".equals(field)) {value = fm.getN_dcAccrual();}
			if ("n_reserves".equals(field)) {value = fm.getN_reserves();}
			if ("n_fiutran".equals(field)) {value = fm.getN_fiutran();}
			if ("n_investmentlimit".equals(field)) {value = fm.getN_investmentlimit();}
			if ("n_dcCollected".equals(field)) {value = fm.getN_dcCollected();}
			if ("c_Status".equals(field)) {value = fm.getC_Status();}
			if ("n_ClntEquity".equals(field)) {value = fm.getN_ClntEquity();}
			if ("n_DCRate".equals(field)) {value = fm.getN_DCRate();}
			if ("d_BlrFrom".equals(field)) {value = fm.getD_BlrFrom();}
			if ("d_BlrTo".equals(field)) {value = fm.getD_BlrTo();}
			if ("n_Term".equals(field)) {value = fm.getN_Term();}
			if ("n_IndustryCode".equals(field)) {value = fm.getN_IndustryCode();}
			if ("c_Industry".equals(field)) {value = fm.getC_Industry();}
			if ("c_SizeOfFirm".equals(field)) {value = fm.getC_SizeOfFirm();}
			if ("n_CreditNote".equals(field)) {value = fm.getN_CreditNote();}
			if ("c_CurrencyCode".equals(field)) {value = fm.getC_CurrencyCode();}
			if ("d_effDate".equals(field)) {value = fm.getD_effDate();}
			if ("factoredInvoice".equals(field)) {value = fm.getFactoredInvoice();}
			if ("n_DCAdjustment".equals(field)) {value = fm.getN_DCAdjustment();}
			if ("n_CERatio".equals(field)) {value = fm.getN_CERatio();}
			if ("n_serviceCharge".equals(field)) {value = fm.getN_serviceCharge();}
			if ("n_penaltyCharge".equals(field)) {value = fm.getN_penaltyCharge();}
			if ("CEUnpaid".equals(field)) {value = fm.getCEUnpaid();}
			if ("n_receipts".equals(field)) {value = fm.getN_receipts();}
			if ("n_overpayment".equals(field)) {value = fm.getN_overpayment();}
			if ("n_CEPaid".equals(field)) {value = fm.getN_CEPaid();}
			if ("d_PDODate".equals(field)) {value = fm.getD_PDODate();}
			if ("d_lastDCCollected".equals(field)) {value = fm.getD_lastDCCollected();}
			if ("d_lastPayment".equals(field)) {value = fm.getD_lastPayment();}
			if ("d_lastRefund".equals(field)) {value = fm.getD_lastRefund();}
			if ("d_lastAdvance".equals(field)) {value = fm.getD_lastAdvance();}
			if ("d_DCRateChanged".equals(field)) {value = fm.getD_DCRateChanged();}
			if ("n_prevDCRate".equals(field)) {value = fm.getN_prevDCRate();}
			if ("d_AdvRatioChanged".equals(field)) {value = fm.getD_AdvRatioChanged();}
			if ("n_prevAdvRate".equals(field)) {value = fm.getN_prevAdvRate()!=null?fm.getN_prevAdvRate()/100:null;}
			if ("n_dunning".equals(field)) {value = fm.getN_dunning();}
			if ("n_avgDunning".equals(field)) {value = fm.getN_avgDunning();}
			if ("d_review".equals(field)) {value = fm.getD_review();}
			if ("d_ReviewDate".equals(field)) {value = fm.getD_ReviewDate();}
			if ("c_IndustryHeader".equals(field)) {value = fm.getC_IndustryHeader();}
			if ("c_TIN".equals(field)) {value = fm.getC_TIN();}
			if ("c_BorrowerType".equals(field)) {value = fm.getC_BorrowerType();}
			if ("n_Assets".equals(field)) {value = fm.getN_Assets();}
			if ("n_Liabilities".equals(field)) {value = fm.getN_Liabilities();}
			if ("n_Equity".equals(field)) {value = fm.getN_Equity();}
			if ("n_GrossIncome".equals(field)) {value = fm.getN_GrossIncome();}
			if ("n_Expenses".equals(field)) {value = fm.getN_Expenses();}
			if ("n_NetIncome".equals(field)) {value = fm.getN_NetIncome();}
			if ("d_audited".equals(field)) {value = fm.getD_audited();}
			if ("n_avgDunning6mos".equals(field)) {value = fm.getN_avgDunning6mos();}
			if ("currentDate".equals(field)) {value = date.newDate();} //CVG			
		}
		return value;
	}
	
	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}
}
