/*@ Added by	: Roldan Somontina
 * 	Java Name	: VerifyInvoiceField.java
 * 	Date Added	: May 19, 2009
 *  Source Code for Invoice Due Report
 */ 

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.BLRFile;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.service.BLRService;

public class ClientActivityField extends ClientDAO implements JRDataSource{
	private static Logger log = Logger.getLogger(ClientActivityField.class);

	List clientActivityList= new ArrayList();	
	List<BLRFile> blrList= new ArrayList<BLRFile>();
	private int index=-1;
	private int lastIndex = 0;



	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	//CCLinkDAO ccLinkDao = (CCLinkDAO)Persistence.getDAO("ccLinkDao");

	public ClientActivityField(String clientCode,String asOfDate){
		clientActivityList= getClientActivities(clientCode,asOfDate);
		blrList = BLRFileDAO.getAllBLRFile(clientCode);
		lastIndex= clientActivityList.size();
		log.info("(ClientActivityField)lastIndex=> "+lastIndex);
	}


	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		 FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		ClientActivities ca = (ClientActivities)clientActivityList.get(index);
		if(ca.getClient()!=null){
			Client c = (Client) ca.getClient();

			if("clientName".equals(field)){   			
				value=c.getC_Name();
			}
			if("address".equals(field)){   			
				value=c.getC_Address();
			}
			if("contact".equals(field)){   			
				value=c.getC_Contact();
			}
			if("currency".equals(field)){   			
				value=c.getC_Currency();
			}
			if("dcr".equals(field)){   			
				value=c.getN_Dcr();
			}
			if("scr".equals(field)){   			
				value=c.getN_Scr();
			}	
			if("startDate".equals(field)){   			
				value=ca.getStartDate();				
			}
			if("rates".equals(field)){
				BLRService blr = BLRService.getInstance();
				Map blrData = new HashMap();
				blrData.put("topCount", 3);
				blrData.put("order", "D_EFFDT asc");
				blrData.put("clntCode", ca.getClientCode());
				value=blr.readBLRSOAString(blrData);
			}
			
			if("currentDate".equals(field)){
				value=date.newDate();
			}
			
		}

		/*
		if(ca.getBlrFile()!=null){
			BLRFile b=(BLRFile) ca.getBlrFile();
			if("blr".equals(field)){   			
				value=b.getBlr();
			}
			if("effectivityDate".equals(field)){   			
				value=b.getEffectiveDate();
			}
			if("expiryDate".equals(field)){   			
				value=b.getExpiryDate();
			}			
		}else{
			if("blr".equals(field)){   			
				value=0.00;
			}			
		}
		*/
		
		if(clientActivityList.size()>0/*&&index+1!=lastIndex*/){
			if("transactionDate".equals(field)){   			
				value=ca.getTransactionDate();
			}
			if("description".equals(field)){   			
				value=ca.getDefinition();
			}
			if("ref".equals(field)){   			
				value=ca.getRef();
			}
			if("receivables".equals(field)){   			
				value=ca.getReceivables();
			}
			if("reserves".equals(field)){   			
				value=ca.getReserves();
			}
			if("fiuTransaction".equals(field)){   			
				value=ca.getFiuTransaction();
			}
			if("fiuBalance".equals(field)){   			
				value=ca.getFiuBalance();
			}			
		}
		if(index+1==lastIndex){
			if("totalReceivables".equals(field)){   			
				value=ca.getTotalReceivables();
			}
			if("totalReserves".equals(field)){   			
				value=ca.getTotalReserves();
			}
			if("totalFiuTransaction".equals(field)){   			
				value=ca.getTotalFiuTransaction();
			}
			if("totalFiuBalance".equals(field)){   			
				value=ca.getTotalFiuBalance();
			}			
			if("invoices".equals(field)){   			
				value=ca.getInvoices();
			}
			if("advances".equals(field)){   			
				value=ca.getAdvances();
			}	
			if("receipts".equals(field)){   			
				value=ca.getReceipts();
			}
			if("creditNotes".equals(field)){   			
				value=ca.getCreditNotes();
			}
			if("refunds".equals(field)){   			
				value=ca.getRefunds();
			}			
			if("serviceCharges".equals(field)){   			
				value=ca.getServiceCharges();
			}			
			if("discountCharges".equals(field)){   			
				value=ca.getDiscountCharges();
			}
			if("dcOnCashDelays".equals(field)){   			
				value=ca.getDcOnCashDelays();
			}
			if("setupFee".equals(field)){   			
				value=ca.getSetupFee();
			}
			if("docStamp".equals(field)){   			
				value=ca.getDocStamp();
			}
			if("dcCollected".equals(field)){   			
				value=ca.getDcCollected();
			}
			if("overpayment".equals(field)){   			
				value=ca.getOverpayment();
			}
			if("receiptAdvance".equals(field)){   			
				value=ca.getReceiptAdvance();
			}
			if("receiptRefund".equals(field)){   			
				value=ca.getReceiptRefund();
			}
			if("dshnrdChks".equals(field)){
				value=ca.getDshnrdChks();
			}
			if("cnCancelled".equals(field)){
				value=ca.getCnCancelled();
			}
			if("pastDueCollected".equals(field)){
				value=ca.getPastDueCollected();
			}
			if("penaltyCollected".equals(field)){
				value=ca.getPenaltyCollected();
			}
			if("pastDueFR".equals(field)){
				value=ca.getPastDueFR();
			}
			
			//added by CVG as of 03-04-16
			if("notarialFee".equals(field)){
				value=ca.getNotarialFee();
			}
			
			
		}

		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
