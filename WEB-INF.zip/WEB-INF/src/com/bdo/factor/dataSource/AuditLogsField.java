package com.bdo.factor.dataSource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.AccountForReview;
import com.bdo.factor.beans.AuditLogs;
import com.bdo.factor.dao.Persistence;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class AuditLogsField implements JRDataSource{
	private Logger log = Logger.getLogger(AuditLogsField.class);
	List<AuditLogs> lAudit = new ArrayList<AuditLogs>();
	private int index =-1;
	private int lastIndex = 0;
	
	private String startDate;
	private String endDate;
	private String branchCode;
	private String userID;
	
	AuditLogsDAO auditDao = (AuditLogsDAO)Persistence.getDAO("auditLogsDAO");
	
	public AuditLogsField(String startDate, String endDate, String branchCode, String userID) {
		this.startDate=startDate;
		this.endDate=endDate;
		this.branchCode=branchCode;
		this.userID=userID;
		
		Map param = new HashMap();
		param.put("startDate", startDate);
		param.put("endDate", endDate);
		param.put("branchCode", branchCode);
		param.put("userID", userID);
		
		lAudit = auditDao.getAuditLogs(userID, branchCode, startDate, endDate);
		lastIndex = lAudit.size();
	}
	
	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		AuditLogs audit = (AuditLogs) lAudit.get(index);
		
		if (lAudit.size() > 0) {
			if ("branchName".equals(field)) {
				value = audit.getBranchName();
			}
			if ("newValue".equals(field)) {
				value = audit.getNewValue();
			}
			if ("tableName".equals(field)) {
				value = audit.getTableName();
			}
			if ("type".equals(field)) {
				value = audit.getType();
			}
			if ("updateDate".equals(field)) {
				value = audit.getUpdateDate();
			}
			if ("userId".equals(field)) {
				value = audit.getUserId();
			}
			if ("dateRange".equals(field)) {
				value = startDate + "=" + endDate;
			}
			if ("currentDate".equals(field)) {
				value = audit.getCurrentDate();
			}
		}
		return value;
	}
	
	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
