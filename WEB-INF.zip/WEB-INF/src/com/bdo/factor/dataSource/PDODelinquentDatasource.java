package com.bdo.factor.dataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;
import org.omg.PortableInterceptor.INACTIVE;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

 

import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.beans.FactoringManagement;
import com.bdo.factor.beans.PDODelinquent;
import com.bdo.factor.beans.PDOInvoice;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.LoaderHandler;

public class PDODelinquentDatasource implements JRDataSource {

	private List<PDODelinquent> PDODelinquentList = new ArrayList<PDODelinquent>();
	private static List<PDODelinquent> PDODelinquentSummaryList = new ArrayList<PDODelinquent>();//THREAD UNSAFE
	private int index          = -1;
	private int lastIndex      = 0;
	private String displayDate = "";
	private Boolean summaryFlag= false;
	
	public PDODelinquentDatasource(String asOfDate, String branchCode,String sessionID){
		try{
			summaryFlag =true;
			
			//NORMAL WAY TO GET FIELD VALUES
				PDODelinquentDAO2 PDD =(PDODelinquentDAO2) Persistence.getDAO("PDODelinquentDAO2");
				PDODelinquentList = PDD.getField(asOfDate, branchCode);
			
			
			//USE LOAD HANDLER
			/*LoaderHandler op = new LoaderHandler();
			op.<PDODelinquentDAO2>LoaderHandler(sessionID, "PDODelinquentDAO2");
			PDODelinquentList = ((PDODelinquentDAO2) op.getInstance2(sessionID)).getField(asOfDate, branchCode);*/
		
		}
		catch(Exception e){e.printStackTrace();}
		lastIndex = PDODelinquentList.size();
	}
	
	public PDODelinquentDatasource(String asOfDate, String branchCode){
		Map<String,List<PDODelinquent>> PDMap= new HashMap();
		try{
			INVOICEDAO ID = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			//PDODelinquentList = ID.getPDOInvoiceList(asOfDate, branchCode);
			PDMap= ID.getPDOInvoiceList(asOfDate, branchCode);
			PDODelinquentList = PDMap.get("pdoList");
			this.PDODelinquentSummaryList = PDMap.get("pdoListSummaryDelinquents");
		}
		catch(Exception e){e.printStackTrace();}
		lastIndex = PDODelinquentList.size();
	}
	
	public PDODelinquentDatasource (){
		PDODelinquentList = this.PDODelinquentSummaryList;
		lastIndex = PDODelinquentList.size();
	}

	
	@Override
	public Object getFieldValue(JRField jrField) throws JRException {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Object value = null;
		String field = jrField.getName();
		PDODelinquent PD = (PDODelinquent)PDODelinquentList.get(index);

		if(PDODelinquentList.size()>0){
			if(index!=lastIndex-1 || !summaryFlag){
				if ("d_lastAdvance".equals(field)) {value=PD.getD_lastAdvance();}
				if ("d_lastRefund".equals(field)) {value=PD.getD_lastRefund();}
				if ("d_lastCollection".equals(field)) {value=PD.getD_lastCollection();}
				if ("c_clntName".equals(field)) {value=PD.getC_clntName();}
				if ("ao".equals(field)) {value=PD.getAo();}
				if ("c_custName".equals(field)) {value=PD.getC_custName();}
				if("rates".equals(field)){
					value=BLRFileDAO.getBLRFileWithDiscountCharge(PD.getC_clntcode());
				}
				if("netInvoice".equals(field)){value=PD.getNetInvoice();}
				if ("c_invoiceNo".equals(field)) {value=PD.getC_invoiceNo();}
				if ("dunningPerLam".equals(field)) {value=PD.getDunningPerLam();}
				if ("d_invoiceDate".equals(field)) {value=PD.getD_invoiceDate();}
				if ("n_origAmount".equals(field)) {value=PD.getN_origAmount();}
				if ("n_advRatio".equals(field)) {value=PD.getN_advRatio();}
				if ("origPrePayInvAmount".equals(field)) {value=PD.getOrigPrePayInvAmount();}
				if ("d_transactionDate".equals(field)) {value=PD.getD_transactionDate();}
				if ("d_dateBasedOnDunning".equals(field)) {value=PD.getD_dateBasedOnDunning();}
				if ("actualInvoiceAge".equals(field)) {value=PD.getActualInvoiceAge();}
				if ("actualInvoiceAgeLessLam".equals(field)) {value=PD.getActualInvoiceAgeLessLam();}
				if ("outstandingInvBalance".equals(field)) {value=PD.getOutstandingInvBalance();}
				if ("prePaymentAdvAmount".equals(field)) {value=PD.getPrePaymentAdvAmount();}
				if ("d_lastInvCollection".equals(field)) {value=PD.getD_lastInvCollection();}
				if ("unpaidDC".equals(field)) {value=PD.getUnpaidDC();}
				if ("penaltyCharge".equals(field)) {value=PD.getPenaltyCharge();}
				if ("datePastDue".equals(field)) {value=PD.getDatePastDue();}
				if ("NetBal1_30".equals(field)) {value=PD.getNetBal1_30();}
				if ("NetBal31_60".equals(field)) {value=PD.getNetBal31_60();}
				if ("NetBal61_90".equals(field)) {value=PD.getNetBal61_90();}
				if ("NetBalgt90".equals(field)) {value=PD.getNetBalgt90();}
				if ("netUnpaidInterestPenalty".equals(field)) {value=PD.getNetUnpaidInterestPenalty();}
				if ("netUnpaidDC".equals(field)) {value=PD.getNetUnpaidDC();}
				if ("netUnpaidDCPenalty".equals(field)) {value=PD.getNetUnpaidDCPenalty();}
				if ("d_lastDCCollection".equals(field)) {value=PD.getD_lastDCCollection();}
				if ("clientFIU".equals(field)) {value=PD.getClientFIU();}
				if ("clientReceivable".equals(field)) {value=PD.getClientReceivable();}
				if ("creditTerm".equals(field)) {value=PD.getCreditTerm();}
				if ("status".equals(field)) {value=PD.getStatus();}
				if ("dcr".equals(field)) {value=PD.getDcr();}
				if ("currentDate".equals(field)) {value=date.newDate();} //
			}
			else if(index==lastIndex-1 && summaryFlag){
				if ("PDOInvoices".equals(field)) {value=PD.getPDOInvoices();}
				if ("DelinquentInvoices".equals(field)) {value=PD.getDelinquentInvoices();}
				if ("pdodelTotal".equals(field)) {value=PD.getPdodelTotal();}
				if ("TotPDO".equals(field)) {value=PD.getTotPDO();}
				if ("TotDel".equals(field)) {value=PD.getTotDel();}
				if ("TotPDODel".equals(field)) {value=PD.getTotPDODel();}
			}
		}
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
        if(index<lastIndex){
            return true;
        }
        return false;	
	}
	
}
