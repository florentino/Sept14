package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRException;

import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.beans.WeeklyBooking;

import org.apache.log4j.Logger;

public class WeeklyBookingFields implements JRDataSource
{
	private static Logger log = Logger.getLogger(WeeklyBookingFields.class);
	public List<WeeklyBooking> weeklyBookingLst = new ArrayList<WeeklyBooking>();
	
	private int index = -1;
	private int lastIndex = 0;	
	
	private String wkMonth;
	
	private double scOne;
	private double scTwo;
	private double scThree;
	private double scFour;
	private double scFive;
		
	private double dcOne;
	private double dcTwo;
	private double dcThree;
	private double dcFour;
	private double dcFive;
	private double dcYTD;
	private double netMTD;
	private double netYTD;
	private double netMTDDC;
	private double netMTDSC;

	private double netYTDDC;
	private double netYTDSC;
	
	private double monthlyPercent;
	private double yearlyPercent;
	
	private double netAmount1;
	private double netAmount2;
	private double netAmount3;
	private double netAmount4;
	private double netAmount5;
	
	private double wDunningFactor1 = 0.00;
	private double wDunningFactor2 = 0.00;
	private double wDunningFactor3 = 0.00;
	private double wDunningFactor4 = 0.00;
	private double wDunningFactor5 = 0.00;
	private double wDunningFactorMTD = 0.00;
	private double wDunningFactorYTD = 0.00;	
	
	double wDunningFactorWk1Sum = 0.00;
	double netAmount1Sum = 0.00;
	double dunOneTotal = 0.00;
	double wDunningFactorWk2Sum = 0.00;
	double netAmount2Sum = 0.00;
	double dunTwoTotal = 0.00;
	double wDunningFactorWk3Sum = 0.00;
	double netAmount3Sum = 0.00;
	double dunThreeTotal = 0.00;
	double wDunningFactorWk4Sum = 0.00;
	double netAmount4Sum = 0.00;
	double dunFourTotal = 0.00;
	double dunFiveTotal = 0.00;	
	double wDunningFactorWk5Sum = 0.00;
	double netAmount5Sum = 0.00;	
	double wDunningFactorMoSum = 0.00;
	double netAmountMTDSum = 0.00;	
	double wDunningFactorYrSum = 0.00;
	double netAmountYTDSum = 0.00;	
	double dunMonthlyTotal = 0.00;
	double dunYearlyTotal = 0.00;
	
	double aveEY1Tot = 0.00;
	double aveEY2Tot = 0.00;
	double aveEY3Tot = 0.00;
	double aveEY4Tot = 0.00;
	double aveEY5Tot = 0.00;
	double aveEYMTDTot = 0.00;
	double aveEYYTDTot = 0.00;
	double WkDC1st_SC = 0.00;
	double WkDC2nd_SC = 0.00;
	double WkDC3rd_SC = 0.00;
	double WkDC4th_SC = 0.00;
	double WkDC5th_SC = 0.00;
	double MTD_DC_SC = 0.00;
	double YTD_DC_SC = 0.00;
	
	double dcYear = 0.0;
	
	public WeeklyBookingFields(){};
	
	public WeeklyBookingFields(String asOfMonth, String branchCode) 
	{		
		System.out.println("asOfMonth: " + asOfMonth);
		WeeklyBookingDAO wkBookDao = (WeeklyBookingDAO)Persistence.getDAO("weeklyBookingDao");
    	wkBookDao.setBusinessDays(asOfMonth);
    	weeklyBookingLst = wkBookDao.getWeeklyBooking(branchCode);
    	lastIndex        = weeklyBookingLst.size();  
    	wkMonth = asOfMonth;
    	
	}

	@Override
	@SuppressWarnings("unused")
	public Object getFieldValue(JRField jrField) throws JRException {
		Object value = null;
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
		WeeklyBookingDAO wkBkDAO = (WeeklyBookingDAO)Persistence.getDAO("weeklyBookingDao");
		
		String field = jrField.getName();	
		WeeklyBooking wkBooking = (WeeklyBooking)weeklyBookingLst.get(index);
		
		DecimalFormat df = new DecimalFormat("#.##");
				
		
		if (this.lastIndex > 0)
		{
			if (this.index==this.lastIndex-1)
			//if (this.index==0)
			{	
			log.info(field);
			if ("GrandTotalDCYear".equals(field))
				{
				 value=dcYear;
				}
				if ("portfolioWk1".equals(field))
				{	
					String secondDateOne = SDF.format(wkBkDAO.getSecondDateOne());
					value = wkBkDAO.getTotalAllClientRec(wkBooking.getBranchCode().toString(),secondDateOne);
				}
				if ("portfolioWk2".equals(field))
				{	
					String secondDateTwo = SDF.format(wkBkDAO.getSecondDateTwo());
					if (DateHelper.parse(wkBkDAO.getAsOfDate()).after(wkBkDAO.getSecondDateOne()) || DateHelper.parse(wkBkDAO.getAsOfDate())==(DateHelper.parse(secondDateTwo)) )
					{	
						value = wkBkDAO.getTotalAllClientRec(wkBooking.getBranchCode().toString(),secondDateTwo);
					}else{
						value = 0.00;
					}
				}
				if ("portfolioWk3".equals(field))
				{	
					String secondDateThree = SDF.format(wkBkDAO.getSecondDateThree());
					if (DateHelper.parse(wkBkDAO.getAsOfDate()).after(wkBkDAO.getSecondDateTwo()) || DateHelper.parse(wkBkDAO.getAsOfDate())==(DateHelper.parse(secondDateThree)) )
					{
						value = wkBkDAO.getTotalAllClientRec(wkBooking.getBranchCode().toString(),secondDateThree);
					}else{
						value = 0.00;
					}
				}
				if ("portfolioWk4".equals(field))
				{	
					String secondDateFour = SDF.format(wkBkDAO.getSecondDateFour());
					if (DateHelper.parse(wkBkDAO.getAsOfDate()).after(wkBkDAO.getSecondDateThree()) || DateHelper.parse(wkBkDAO.getAsOfDate())==(DateHelper.parse(secondDateFour)) )
					{
						value = wkBkDAO.getTotalAllClientRec(wkBooking.getBranchCode().toString(),secondDateFour);
					}else{
						value =0.00;
					}
				}
				if ("portfolioWk5".equals(field))
				{	
					String secondDateFive = SDF.format(wkBkDAO.getSecondDateFive());
					if (DateHelper.parse(wkBkDAO.getAsOfDate()).after(wkBkDAO.getSecondDateFour()) || DateHelper.parse(wkBkDAO.getAsOfDate())==(DateHelper.parse(secondDateFive)) )
					{	
					value = wkBkDAO.getTotalAllClientRec(wkBooking.getBranchCode().toString(),secondDateFive);
					}else{
						value = 0.00;
					}
						
				}
				if ("invCountOne".equals(field))
				{	
					value = wkBkDAO.getInvCountWeekly(wkBooking.getBranchCode(), wkBkDAO.getBetweenDateOne());
				}
				if ("invCountTwo".equals(field))
				{	
					value = wkBkDAO.getInvCountWeekly(wkBooking.getBranchCode(), wkBkDAO.getBetweenDateTwo());
				}
				if ("invCountThree".equals(field))
				{	
					value = wkBkDAO.getInvCountWeekly(wkBooking.getBranchCode(), wkBkDAO.getBetweenDateThree());
				}
				if ("invCountFour".equals(field))
				{	
					value = wkBkDAO.getInvCountWeekly(wkBooking.getBranchCode(), wkBkDAO.getBetweenDateFour());
				}
				if ("invCountFive".equals(field))
				{	
					value = wkBkDAO.getInvCountWeekly(wkBooking.getBranchCode(), wkBkDAO.getBetweenDateFive());
				}
				if ("invCountYTD".equals(field))
				{	
					value = wkBkDAO.getInvCountYTD(wkBooking.getBranchCode(), wkBkDAO.getAsOfDate());
				}
			}
			if("currentDate".equals(field)){
				value = date.newDate();
			}
			if ("clientCode".equals(field))
			{
				value = wkBooking.getClientCode();
			}
			if ("clientStatus".equals(field))
			{
				value = wkBooking.getClientStatus();
			}
			if ("acctOfficer".equals(field))
			{
				value = wkBooking.getAccountOfficer();
			}
			if ("client".equals(field))
			{
				value = wkBooking.getClientName();
			}
			if ("invoiceAmt1stWeek".equals(field))
			{
				value = wkBooking.getInvoiceAmt1stWeek();
			}
			if ("invoiceAmt2ndWeek".equals(field))
			{
				value = wkBooking.getInvoiceAmt2ndWeek();
			}
			if ("invoiceAmt3rdWeek".equals(field))
			{
				value = wkBooking.getInvoiceAmt3rdWeek();
			}
			if ("invoiceAmt4thWeek".equals(field))
			{
				value = wkBooking.getInvoiceAmt4thWeek();
			}
			if ("invoiceAmt5thWeek".equals(field))
			{
				value = wkBooking.getInvoiceAmt5thWeek();
			}
			if ("mtd".equals(field))
			{
				value = wkBooking.getInvoiceAmt1stWeek() + wkBooking.getInvoiceAmt2ndWeek() + wkBooking.getInvoiceAmt3rdWeek() + wkBooking.getInvoiceAmt4thWeek() + wkBooking.getInvoiceAmt5thWeek(); 
			}
			if ("ytd".equals(field))
			{
				value = wkBooking.getYtd();
			}
			if ("prep".equals("field"))
			{
				value = wkBooking.getAdvanceRatio();
			}
			if ("netInvAmt1stWeek".equals(field))
			{
				netAmount1 = getNetWeeklyBooking(wkBooking.getInvoiceAmt1stWeek() , wkBooking.getAdvanceRatio());				
				value = netAmount1; 
				System.out.println("netInvAmt1stWeek: " + netAmount1);
			}
			if ("netInvAmt2ndWeek".equals(field))
			{
				netAmount2 = getNetWeeklyBooking(wkBooking.getInvoiceAmt2ndWeek() , wkBooking.getAdvanceRatio());				
				value = netAmount2;
			}
			if ("netInvAmt3rdWeek".equals(field))
			{
				netAmount3 = getNetWeeklyBooking(wkBooking.getInvoiceAmt3rdWeek() , wkBooking.getAdvanceRatio());
				
				value = netAmount3; 
			}
			if ("netInvAmt4thWeek".equals(field))
			{
				netAmount4 = getNetWeeklyBooking(wkBooking.getInvoiceAmt4thWeek() , wkBooking.getAdvanceRatio());
				
				value = netAmount4; 
			}
			if ("netInvAmt5thWeek".equals(field))
			{
				netAmount5 = getNetWeeklyBooking(wkBooking.getInvoiceAmt5thWeek() , wkBooking.getAdvanceRatio());
				
				value = netAmount5; 
			}
			if ("prep".equals(field))
			{
				value = wkBooking.getAdvanceRatio();
			}
			if ("netMTD".equals(field))
			{
				netMTD = getNetWeeklyBooking((wkBooking.getInvoiceAmt1stWeek() + wkBooking.getInvoiceAmt2ndWeek() + wkBooking.getInvoiceAmt3rdWeek() + wkBooking.getInvoiceAmt4thWeek() + wkBooking.getInvoiceAmt5thWeek()), wkBooking.getAdvanceRatio());
				wDunningFactorMTD = netMTD * wkBooking.getDunMontly();
				
				netAmountMTDSum = netMTD + netAmountMTDSum;
				
				wDunningFactorMoSum = wDunningFactorMoSum + wDunningFactorMTD;
				
				dunMonthlyTotal = wDunningFactorMoSum / netAmountMTDSum;
				value = netMTD;  
			}
			if ("netYTD".equals(field))
			{
				netYTD = getNetWeeklyBooking(wkBooking.getYtd(), wkBooking.getAdvanceRatio());
				wDunningFactorYTD = netYTD * wkBooking.getDunMontly();
				netAmountYTDSum = netYTD + netAmountYTDSum;	
				
				wDunningFactorYrSum = wDunningFactorYTD + wDunningFactorYrSum;
				dunYearlyTotal = wDunningFactorYrSum / netAmountYTDSum; 
				
				value =  netYTD;
			}
			
			if ("scOne".equals(field))
			{
				scOne = wkBooking.getScOne(); 
				value = scOne;
				
			}
			if ("scTwo".equals(field))
			{
				scTwo = wkBooking.getScTwo(); 
				value = scTwo;
			}
			if ("scThree".equals(field))
			{
				scThree = wkBooking.getScThree(); 
				value = scThree;
			}
			if ("scFour".equals(field))
			{
				scFour = wkBooking.getScFour(); 
				value = scFour;
			}
			if ("scFive".equals(field))
			{
				scFive = wkBooking.getScFive(); 
				value = scFive;
			}
			if ("monthlySC".equals(field))
			{
				netMTDSC =  scOne + scTwo + scThree + scFour + scFive;
				value = netMTDSC;
			}
			
			if ("scYearly".equals(field))
			{
				value = wkBooking.getYearlySC();
				netYTDSC=wkBooking.getYearlySC();
				
			}
			if ("scStatus".equals(field))
			{
				value=wkBooking.getScStatus();
			}
			if ("blrStatus".equals(field))
			{
				value=wkBooking.getBlrStatus();
			}
			if ("advanceRatioStatus".equals(field))
			{
				value=wkBooking.getAdvanceRatioStatus();
			}
				
			
			if ("dunOne".equals(field))
			{
				value = wkBooking.getDunMontly();//wkBooking.getDunOne();
			}
			if ("percentOne".equals(field))
			{
				value = wkBooking.getPercentOne();		
				
			}

			
			if ("dcOne".equals(field))
			{								
				dcOne = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt1stWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentOne(), Math.round(wkBooking.getDunMontly()));
				//dcOne = ((netAmount1 * (wkBooking.getPercentOne()/100))/360) *  wkBooking.getDunMontly();
				
				value = Double.parseDouble(df.format(dcOne)); 
			}
						
			if ("dunTwo".equals(field))
			{
				value = wkBooking.getDunMontly();//wkBooking.getDunTwo();
			}
			if ("percentTwo".equals(field))
			{
				value = wkBooking.getPercentTwo();				
			}
			if ("dcTwo".equals(field))
			{
				//dcTwo = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt2ndWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentTwo(), Math.round(wkBooking.getDunTwo()));
				dcTwo = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt2ndWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentTwo(), Math.round(wkBooking.getDunMontly()));				
				//dcTwo = ((netAmount2 * (wkBooking.getPercentTwo()/100))/360) *  wkBooking.getDunMontly();
				value = Double.parseDouble(df.format(dcTwo));   
			}
			if ("dunThree".equals(field))
			{
				value = wkBooking.getDunMontly();//wkBooking.getDunThree();
			}
			if ("percentThree".equals(field))
			{
				value = wkBooking.getPercentThree();				
			}
			if ("dcThree".equals(field))
			{
				//dcThree = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt3rdWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentThree(), Math.round(wkBooking.getDunThree()));
				dcThree = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt3rdWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentThree(), Math.round(wkBooking.getDunMontly()));
				//dcThree = ((netAmount3 * (wkBooking.getPercentThree()/100))/360) *  wkBooking.getDunMontly();
				value = Double.parseDouble(df.format(dcThree)); 
			}
			if ("dunFour".equals(field))
			{
				value = wkBooking.getDunMontly();//wkBooking.getDunFour();
			}
			if ("percentFour".equals(field))
			{
				value = wkBooking.getPercentFour();				
			}
			if ("dcFour".equals(field))
			{
				//dcFour = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt4thWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentFour(), Math.round(wkBooking.getDunFour()));
				dcFour = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt4thWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentFour(), Math.round(wkBooking.getDunMontly()));				
				//dcFour = ((netAmount4 * (wkBooking.getPercentFour()/100))/360) *  wkBooking.getDunMontly();				
				value = Double.parseDouble(df.format(dcFour));  				
			}
			if ("dunFive".equals(field))
			{
				value = wkBooking.getDunMontly();//wkBooking.getDunFive();
			}
			if ("percentFive".equals(field))
			{				
				value = wkBooking.getPercentFive();				
			}
			if ("dcFive".equals(field))
			{
				//dcFive = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt5thWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentFive(), Math.round(wkBooking.getDunFive()));
				dcFive = this.getDC(getNetWeeklyBooking(wkBooking.getInvoiceAmt5thWeek() , wkBooking.getAdvanceRatio()), wkBooking.getPercentFive(), Math.round(wkBooking.getDunMontly()));
				//dcFive = ((netAmount5 * (wkBooking.getPercentFive()/100))/360) *  wkBooking.getDunMontly();
				value = Double.parseDouble(df.format(dcFive)); 
			}
			if ("dunMonthly".equals(field))
			{
				DecimalFormat dtFormat = new DecimalFormat("###0");
				value = Double.parseDouble(dtFormat.format(wkBooking.getDunMontly()));
				
			}
			if ("montlyDC".equals(field))
			{				
				netMTDDC = dcOne + dcTwo + dcThree + dcFour + dcFive;
				
				//save monthlyDC to db
				System.out.println("MONTH: " + wkMonth);
				Calendar cal = Calendar.getInstance();
				cal.setTime(DateHelper.parse(wkMonth));
				cal.set(cal.DAY_OF_MONTH, cal.getActualMaximum(cal.DAY_OF_MONTH));
				Date eoDate = cal.getTime();
				String eom = DateHelper.format(cal.getTime());
				if (eom.equals(wkMonth) || eoDate.before(date.newDate())) { //before: new Date()
					System.out.println("end of month...");
					UtilDAO utilDao    = (UtilDAO)Persistence.getDAO("utilDao");
					int month = cal.get(Calendar.MONTH) + 1;
					String monthName = utilDao.getMonthName(month);
					
					WeeklyBookingDAO wkBookDao = (WeeklyBookingDAO)Persistence.getDAO("weeklyBookingDao");
					wkBookDao.updateMonthlyDC(wkBooking.getClientCode(), monthName, netMTDDC);
				}				
				//DecimalFormat df = new DecimalFormat("#.##");
				//value = Double.parseDouble(df.format(netMTDDC)); 
				value = Double.parseDouble(df.format(netMTDDC));
				 
			}
			
			if ("percentMonthly".equals(field))
			{			
				//monthlyPercent = (netMTDDC/wkBooking.getDunMontly()) * 360 / netMTD;
				monthlyPercent = wkBooking.getPercentOne();
				if (Double.valueOf(monthlyPercent).isNaN())
				{					
					value = 0.00;
				}
				else
				{
					value = monthlyPercent;
				}				
			}
			if ("dunYearly".equals(field))
			{
				value = wkBooking.getDunMontly();				
			}
			if ("dcYearly".equals(field))
			{	
				WeeklyBookingDAO wkBookDao = (WeeklyBookingDAO)Persistence.getDAO("weeklyBookingDao");
				UtilDAO utilDao    = (UtilDAO)Persistence.getDAO("utilDao");
				Calendar cal = Calendar.getInstance();
				cal.setTime(DateHelper.parse(wkMonth));
				cal.set(cal.DAY_OF_MONTH, cal.getActualMaximum(cal.DAY_OF_MONTH));
				String eom = DateHelper.format(cal.getTime());
				int month = cal.get(Calendar.MONTH) + 1;
				String monthName = utilDao.getMonthName(month);
				double ytdDC =wkBookDao.getYearlyDC(wkBooking.getClientCode(), monthName);
				
				
				
				if (eom.equalsIgnoreCase(wkMonth)) {
					value = ytdDC;
					netYTDDC=ytdDC;
				}
				else {
					value = ytdDC + netMTDDC;
					netYTDDC=ytdDC + netMTDDC;
				}
				
				//dcYTD = this.getDC(getNetWeeklyBooking(wkBooking.getYtd() , wkBooking.getAdvanceRatio()), wkBooking.getPercentOne(), Math.round(wkBooking.getDunMontly()));
				//value = dcYTD; 
			}
			if ("percentYearly".equals(field))
			{
				yearlyPercent= wkBooking.getPercentOne();
				if (Double.valueOf(yearlyPercent).isNaN())
				{					
					value = 0.00;
				}
				else
				{
					value = yearlyPercent;
				}
			}
			/*if ("sfWkOne".equals(field))
			{
				value = wkBooking.getSfWkOne();
			}
			if ("sfWkTwo".equals(field))
			{
				value = wkBooking.getSfWkTwo();
			}
			if ("sfWkThree".equals(field))
			{
				value = wkBooking.getSfWkThree();
			}
			if ("sfWkFour".equals(field))
			{
				value = wkBooking.getSfWkFour();
			}
			if ("sfWkFive".equals(field))
			{
				value = wkBooking.getSfWkFive();
			}
			if ("skMtd".equals(field))
			{
				value = wkBooking.getSfMtd();
			}
			if ("skYtd".equals(field))
			{
				value = wkBooking.getSfYtd();
			}
			if ("1stWkDC_SC".equals(field))
			{
				WkDC1st_SC = WkDC1st_SC + (dcOne + wkBooking.getSfWkOne());				
				value = dcOne + wkBooking.getSfWkOne();								 
			}
			if ("2ndWkDC_SC".equals(field))
			{
				WkDC2nd_SC = WkDC2nd_SC + (dcTwo + wkBooking.getSfWkTwo());							
				value = dcTwo + wkBooking.getSfWkTwo();
			}
			if ("3rdWkDC_SC".equals(field))
			{
				WkDC3rd_SC = WkDC3rd_SC + (dcThree + wkBooking.getSfWkThree());							
				value = dcThree + wkBooking.getSfWkThree();
			}
			if ("4thWkDC_SC".equals(field))
			{				
				WkDC4th_SC = WkDC4th_SC + (dcFour + wkBooking.getSfWkFour());	
				value = dcFour + wkBooking.getSfWkFour();
			}
			if ("5thWkDC_SC".equals(field))
			{
				WkDC5th_SC = WkDC5th_SC + (dcFive + wkBooking.getSfWkFive());				
				value = dcFive + wkBooking.getSfWkFive();
			}
			
			if ("MTD_DC_SC".equals(field))
			{				
				MTD_DC_SC = MTD_DC_SC + (netMTDDC + wkBooking.getSfMtd()); 				 
				value = netMTDDC + wkBooking.getSfMtd();
			}
			if ("YTD_DC_SC".equals(field))
			{				
				YTD_DC_SC = YTD_DC_SC + dcYTD + wkBooking.getSfYtd();
				value = dcYTD + wkBooking.getSfYtd();
			}*/
			if ("aveEYWkOne".equals(field))
			{
				//double aveEYWkOne = ((dcOne + wkBooking.getSfWkOne()) * 360) / netAmount1;
				double aveEYWkOne = (dcOne + scOne) / wkBooking.getDunMontly() * 360 / netAmount1;
				if (Double.valueOf(aveEYWkOne).isNaN() || Double.valueOf(aveEYWkOne).isInfinite())
				{
					value = 0.00;
				}
				else
				{
					value = aveEYWkOne;
				}
			}
			if ("aveEYWkTwo".equals(field))
			{
				//double aveEYWkTwo =((dcTwo + wkBooking.getSfWkTwo()) * 360) / netAmount2;
				double aveEYWkTwo = (dcTwo + scTwo) / wkBooking.getDunMontly() * 360 / netAmount2;
				if (Double.valueOf(aveEYWkTwo).isNaN() || Double.valueOf(aveEYWkTwo).isInfinite())
				{
					value = 0.00;
				}
				else
				{
					value = aveEYWkTwo;
				} 
			}
			if ("aveEYWkThree".equals(field))
			{
				//double aveEYWkThree = ((dcThree + wkBooking.getSfWkThree()) * 360) / netAmount3;
				double aveEYWkThree = (dcThree + scThree) / wkBooking.getDunMontly() * 360 / netAmount3;
				if (Double.valueOf(aveEYWkThree).isNaN() || Double.valueOf(aveEYWkThree).isInfinite() )
				{
					value = 0.00;
				}
				else
				{
					value = aveEYWkThree;
				}
			}
			if ("aveEYWkFour".equals(field))
			{
				//double aveEYWkFour = ((dcFour + wkBooking.getSfWkFour()) * 360) / netAmount4;
				double aveEYWkFour = (dcFour + scFour) / wkBooking.getDunMontly() * 360 / netAmount4;
				if (Double.valueOf(aveEYWkFour).isNaN() || Double.valueOf(aveEYWkFour).isInfinite())
				{
					value = 0.00;
				}
				else
				{
					value = aveEYWkFour;
				}
			}
			if ("aveEYWkFive".equals(field))
			{
				double aveEYWkFive = (dcFive + scFive)/ wkBooking.getDunMontly() * 360 / netAmount5;
				//double aveEYWkFive = ((dcFive + wkBooking.getSfWkFive()) * 360) / netAmount5; 
				if (Double.valueOf(aveEYWkFive).isNaN() || Double.valueOf(aveEYWkFive).isInfinite())
				{
					value = 0.00;
				}
				else
				{
					value = aveEYWkFive;
				} 
			}
			if ("aveEYMonth".equals(field))
			{
				//double aveEYMonth = ((netMTDDC + wkBooking.getSfMtd()) * 360) / netMTD;
				double aveEYMonth = (netMTDDC + netMTDSC) / wkBooking.getDunMontly() * 360 / netMTD;
				if (Double.valueOf(aveEYMonth).isNaN() || (Double.valueOf(aveEYMonth).isInfinite()))
				{
					value = 0.00; 
				}
				else
				{
					value = aveEYMonth;
				}
			}
			if ("aveEYYear".equals(field))
			{
				///xxx
				//double aveEYYEar = ((netMTDDC + wkBooking.getSfMtd()) * 360) / netMTD;//((netYTDDC + wkBooking.getSfYtd()) * 360) / netYTD;
				double aveEYYEar = (netYTDDC + netYTDSC) / wkBooking.getDunMontly() * 360 / netYTD;
				if (Double.valueOf(aveEYYEar).isNaN())
				{
					value = 0.00; 
				}
				else
				{
					value = aveEYYEar;
				} 
			}
			/*
			if ("sfPercentOne".equals(field) ||
				"sfPercentTwo".equals(field) || 
				"sfPercentThree".equals(field) || 
				"sfPercentFour".equals(field) || 
				"sfPercentFive".equals(field))
			{
				value = wkBooking.getSfPercent();	
			}			
			*/
			if ("wDunningFactorWk1".equals(field))
			{
				wDunningFactor1 = netAmount1 * Math.round(wkBooking.getDunMontly());
				value = this.wDunningFactor1;
				System.out.println("wDunningFactorWk1/variable1: " + wDunningFactor1);
			}
			
			if ("wDunningFactorWk2".equals(field))
			{
				wDunningFactor2 = netAmount2 * Math.round(wkBooking.getDunMontly());
				value = this.wDunningFactor2;
			}
			     
			if ("wDunningFactorWk3".equals(field))
			{
				wDunningFactor3 = netAmount3 * Math.round(wkBooking.getDunMontly());
				value = this.wDunningFactor3;
			}
			
			if ("wDunningFactorWk4".equals(field))
			{
				wDunningFactor4 = netAmount4 * Math.round(wkBooking.getDunMontly());
				value = this.wDunningFactor4;
			}
			
			if ("wDunningFactorWk5".equals(field))
			{
				wDunningFactor5 = netAmount5 * Math.round(wkBooking.getDunMontly());
				value = this.wDunningFactor5;
			}	
			
			if ("wDunningFactorMTD".equals(field))
			{
				value = wDunningFactorMTD;
			}
			
			if ("wDunningFactorYTD".equals(field))
			{
				value = wDunningFactorYTD;
			}
			
			if ("totCollectionWk1".equals(field))
			{
				value = wkBooking.getTotCollectionWk1();
			}
			
			if ("totCollectionWk2".equals(field))
			{
				value = wkBooking.getTotCollectionWk2();
			}
			
			if ("totCollectionWk3".equals(field))
			{
				value = wkBooking.getTotCollectionWk3();
			}
			
			if ("totCollectionWk4".equals(field))
			{
				value = wkBooking.getTotCollectionWk4();
			}
			
			if ("totCollectionWk5".equals(field))
			{
				value = wkBooking.getTotCollectionWk5();
			}
			
			if ("totCollectionWkMTD".equals(field))
			{
				value = wkBooking.getTotCollectionWk1() 
						+ wkBooking.getTotCollectionWk2() 
						+ wkBooking.getTotCollectionWk3() 
						+ wkBooking.getTotCollectionWk4() 
						+ wkBooking.getTotCollectionWk5();
			}
			if ("totCollectionWkYTD".equals(field))
			{
				value = wkBooking.getTotCollectionWkYTD();
			}
			
			if ("dunOneTotal".equals(field))
			{				
				netAmount1Sum = netAmount1 + netAmount1Sum;				
				wDunningFactorWk1Sum = wDunningFactor1 + wDunningFactorWk1Sum;
				dunOneTotal = wDunningFactorWk1Sum / netAmount1Sum;				
				if (Double.valueOf(dunOneTotal).isNaN())
				{
					value = 0.00;
				}
				else
				{
					value = dunOneTotal;
				}
			}
			
			if ("dunTwoTotal".equals(field))
			{
				
				netAmount2Sum = netAmount2 + netAmount2Sum;				
				wDunningFactorWk2Sum = wDunningFactor2 + wDunningFactorWk2Sum;				
				dunTwoTotal = wDunningFactorWk2Sum / netAmount2Sum;		
				if (Double.valueOf(dunTwoTotal).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = dunTwoTotal;
				}					
			}
			
			if ("dunThreeTotal".equals(field))
			{
				
				netAmount3Sum = netAmount3 + netAmount3Sum;				
				wDunningFactorWk3Sum = wDunningFactor3 + wDunningFactorWk3Sum;				
				dunThreeTotal = wDunningFactorWk3Sum / netAmount3Sum; 
				if (Double.valueOf(dunThreeTotal).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = dunThreeTotal;
				}				
			}
			
			if ("dunFourTotal".equals(field))
			{
				
				netAmount4Sum = netAmount4 + netAmount4Sum;
				wDunningFactorWk4Sum = wDunningFactor4 + wDunningFactorWk4Sum;
				dunFourTotal = wDunningFactorWk4Sum / netAmount4Sum; 
				if (Double.valueOf(dunFourTotal).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = dunFourTotal;
				}	
				
			}
			
			if ("dunFiveTotal".equals(field))
			{
				
				netAmount5Sum =  netAmount5 + netAmount5Sum;
				wDunningFactorWk5Sum = wDunningFactor5 + wDunningFactorWk5Sum;
				dunFiveTotal = wDunningFactorWk5Sum / netAmount5Sum;
				if (Double.valueOf(dunFiveTotal).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = dunFiveTotal; 
				}	
					
				
			}
			
			if ("dunMonthlyTotal".equals(field))
			{	
				if (Double.valueOf(dunMonthlyTotal).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = dunMonthlyTotal; 
				}	
								
			}
			
			if ("dunYearlyTotal".equals(field))
			{
				if (Double.valueOf(dunYearlyTotal).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = dunYearlyTotal; 
				}								
				
			}
			
			
			if ("aveEY1Tot".equals(field))
			{
				//aveEY1Tot = (WkDC1st_SC * 360) / netAmount1Sum;
				aveEY1Tot = (dcOne+scOne) / wkBooking.getDunMontly() * 360 / netAmount1;
				if (Double.valueOf(aveEY1Tot).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = aveEY1Tot;
				}
				
			}
			
			if ("aveEY2Tot".equals(field))
			{				
				//aveEY2Tot = (WkDC2nd_SC * 360) / netAmount2Sum;
				aveEY2Tot = (dcTwo+scTwo) / wkBooking.getDunMontly() * 360 / netAmount2;
				if (Double.valueOf(aveEY2Tot).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = aveEY2Tot;
				}				
			}
			
			if ("aveEY3Tot".equals(field))
			{
				//aveEY3Tot = (WkDC3rd_SC * 360) / netAmount3Sum;
				aveEY3Tot = (dcThree+scThree) / wkBooking.getDunMontly() * 360 / netAmount3;
				if (Double.valueOf(aveEY3Tot).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = aveEY3Tot;
				}
				
			}
			
			if ("aveEY4Tot".equals(field))
			{	
				//aveEY4Tot = (WkDC4th_SC * 360) / netAmount4Sum;
				aveEY4Tot = (dcFour+scFour) / wkBooking.getDunMontly() * 360 / netAmount4;
				if (Double.valueOf(aveEY4Tot).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = aveEY4Tot;
				}						
			}
			
			if ("aveEY5Tot".equals(field))
			{
				//aveEY5Tot = (WkDC5th_SC * 360) / netAmount5Sum;
				aveEY5Tot = (dcFive+scFive) / wkBooking.getDunMontly() * 360 / netAmount5;
				if (Double.valueOf(aveEY5Tot).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = aveEY5Tot;
				}					
			}
			
			if ("aveEYMTDTot".equals(field))
			{
				//aveEYMTDTot = (MTD_DC_SC * 360) / netAmountMTDSum;
				aveEYMTDTot = netMTDDC / wkBooking.getDunMontly() * 360 / netMTD;
				if (Double.valueOf(aveEYMTDTot).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = aveEYMTDTot;
				}				
			}
			
			if ("aveEYYTDTot".equals(field))
			{													
				//aveEYYTDTot = (YTD_DC_SC * 360) / netAmountYTDSum;
				 aveEYYTDTot = netMTDDC / wkBooking.getDunMontly() * 360 / netMTD;
				if (Double.valueOf(aveEYYTDTot).isNaN())
				{
					value =  0.00;
				}
				else
				{
					value = aveEYYTDTot;
				}
			}
		}
		
		if ("weekOne".equals(field))
		{
			value = wkBooking.getWeekOne();
		}
		
		if ("weekTwo".equals(field))
		{
			value = wkBooking.getWeekTwo();
		}
		
		if ("weekThree".equals(field))
		{
			value = wkBooking.getWeekThree();
		}
		
		if ("weekFour".equals(field))
		{
			value = wkBooking.getWeekFour();
		}
		
		if ("weekFive".equals(field))
		{
			value = wkBooking.getWeekFive();
		}	
		if ("N_SCR".equals(field))
		{
			value = wkBooking.getSfPercent();
		}
		if ("GrandTotalDCYear".equals(field))
		{

			Double qvalue = this.getDC((wkBkDAO.getYearlyDC(wkBkDAO.getAsOfDate(),String.valueOf(wkBooking.getClientCode()))*wkBooking.getAdvanceRatio()), wkBooking.getPercentOne(), Math.round(wkBooking.getDunMontly()));
			this.dcYear +=(Double)qvalue;
		}
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
        if(index<lastIndex)
        {   log.info(index);
            return true;
        }
        return false;
	}
	
	public double getNetWeeklyBooking(double advanceRatio, double invoiceAmt)
	{		
		return (invoiceAmt * advanceRatio);
		
	}	
	
	public double getDC(double wkAmount, double percent, double dun)
	{
		return (wkAmount * percent)/360 * dun;
	}
}
