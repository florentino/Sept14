/*@ Added by	: Roldan Somontina
 * 	Java Name	: VerifyInvoiceField.java
 * 	Date Added	: May 19, 2009
 *  Source Code for Invoice Due Report
 */ 

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dataSource.CustomerDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

public class AdvicesSummaryField implements JRDataSource{
	private static Logger log = Logger.getLogger(AdvicesSummaryField.class);

	List<AdvicesReport> list= new ArrayList<AdvicesReport>();	
	private int index =-1;
	private int lastIndex = 0;

	

	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	//CCLinkDAO ccLinkDao = (CCLinkDAO)Persistence.getDAO("ccLinkDao");

	public AdvicesSummaryField(List<AdvicesReport> list){
		this.list= list;
		lastIndex= list.size();
		log.info("lastIndex=> "+lastIndex);
	}
	

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Object value = null;
		String field = jRField.getName();
		AdvicesReport ar = (AdvicesReport)list.get(index);

		if(list.size()>0){
			if("clientName".equals(field)){   			
				value=ar.getClientName();
			}
			if("transactionDate".equals(field)){   			
				value=ar.getTransactionDate();
			}
			if("bankAccountNo".equals(field)){   			
				value=ar.getBankAccountNo();
			}			
			if("serviceOfficer".equals(field)){   			
				value=ar.getServiceOfficer();
			}			
			if("amount".equals(field)){   			
				value=ar.getAmount();
			}
			if("description".equals(field)){   			
				value=ar.getDescription();
			}			
			if("C_BANKACCOUNT".equals(field)){   			
				value=ar.getC_BANKACCOUNT();
			}
			if("C_APPROVER".equals(field)){   			
				value=ar.getC_APPROVER();
			}
			if("C_BANKACCOUNT".equals(field)){   			
				value=ar.getC_BANKACCOUNT();
			}
			if("C_BANKNAME".equals(field)){   			
				value=ar.getC_BANKNAME();
			}
			if("C_ADDRESS".equals(field)){   			
				value=ar.getC_ADDRESS();
			}			
			if("C_COMPANYNAME".equals(field)){   			
				value=ar.getC_COMPANYNAME();
			}
			if("C_CURRENCYCODE".equals(field)){   			
				value=ar.getC_CURRENCYCODE();
			}

		}
		if("currentDate".equals(field)){   			
			value= date.newDate();
		}
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
