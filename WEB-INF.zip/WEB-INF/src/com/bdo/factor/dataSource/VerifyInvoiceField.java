/*@ Added by	: Roldan Somontina
 * 	Java Name	: VerifyInvoiceField.java
 * 	Date Added	: May 19, 2009
 *  Source Code for Invoice Due Report
 */ 

package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Audit;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;

public class VerifyInvoiceField  implements JRDataSource{
	private Logger log = Logger.getLogger(VerifyInvoiceFieldOd.class);

	List<Invoice> verifyInvoiceList= new ArrayList<Invoice>();
	List listClntCode= new ArrayList();
	private int index =-1;
	private int lastIndex = 0;
	private String temp="";
	private String startDate;
	private String endDate;

	SimpleDateFormat sdf = new SimpleDateFormat ("MMMM dd, yyyy");	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	INVOICEDAO uniqueClientDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
	InvoiceDAO invoiceDao = (InvoiceDAO)Persistence.getDAO("invoiceDao");

	public VerifyInvoiceField(String startDate,String endDate){
		this.startDate=startDate;
		this.endDate=endDate;
		Map param = new HashMap();
		param.put("startDate", startDate);
		param.put("endDate", endDate);
		listClntCode=uniqueClientDAO.getUniqueClientCode(param);
		lastIndex=listClntCode.size();
	}

	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		String clientCode = (String)listClntCode.get(index);
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");

		if(listClntCode.size()>0){
			if("clientName".equals(field)){   			
				value="";   			
				verifyInvoiceList = invoiceDao.getVerifyInvoiceInView(clientCode,startDate, endDate);
				Iterator iter=verifyInvoiceList.iterator();
				while(iter.hasNext()){
					Invoice invoice = (Invoice)iter.next();
					if("customerName".equals(field)){
						value=invoice.getC_CUSTNAME();
					}      		
					if("invoiceNumber".equals(field)){
						value=invoice.getC_INVOICENO();    			
					}   		
					if("transactionDate".equals(field)){
						value=sdf.format(invoice.getD_TRANSACTIONDATE());
						log.info("sdf.format(invoice.getD_TRANSACTIONDATE()=>  "+sdf.format(invoice.getD_TRANSACTIONDATE()));
						//value=invoice.getTransactionDate();
						//log.info("invoice.getTransactionDate()= "+invoice.getTransactionDate());
					}    		
					if("invoiceDate".equals(field)){
						value=sdf.format(invoice.getD_INVOICEDATE())+"\n";
						log.info("sdf.format(invoice.getD_INVOICEDATE())=> "+sdf.format(invoice.getD_INVOICEDATE()));
						//value=invoice.getInvoiceDate();
						//log.info("invoice.getInvoiceDate()= "+invoice.getInvoiceDate());
					}
					if("invoiceAmount".equals(field)){
						value=df.format(invoice.getN_INVOICEAMT());
						log.info("df.format(invoice.getN_INVOICEAMT()) "+df.format(invoice.getN_INVOICEAMT()));
					}   				
				}  				
			}
		}   
		if("currentDate".equals(field)){
			value = date.newDate();
		}


		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
