package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.util.Money;

public class CustomerDAO {
	
	private static Logger log = Logger.getLogger(CustomerDAO.class);
	private static String delim="@";

	
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@SuppressWarnings("unchecked")
	public static String getCustomerSalesAnalysis(CC cc){
		String retValue="";		
		String sSQL = "SELECT     C_CUSTCODE,C_CUSTNAME,SUM(N_INVOICEAMT) AS amount, mo "+
		"FROM (SELECT     ISNULL(N_INVOICEAMT,0) AS N_INVOICEAMT, DATENAME(MONTH,ISNULL(D_INVOICEDATE,1)) AS mo, C_CUSTCODE,C_CUSTNAME "+
	      "           FROM          ReportInvoice "+
	      "           WHERE      (D_INVOICEDATE BETWEEN '01/01/'+CAST(YEAR('"+cc.getAsOfDate()+"') AS NVARCHAR) AND '"+cc.getAsOfDate()+"') " +
	      "			  AND (YEAR(D_INVOICEDATE) = YEAR('"+cc.getAsOfDate()+"')) AND (C_CLNTCODE ='"+cc.getClientCode()+"') " +
	      "			  AND (C_CUSTCODE = '"+cc.getCustomerCode()+"')  AND (C_BRANCHCODE ='"+cc.getBranchCode()+"') " +
	      "			  AND C_STATUS "+cc.getStatus()+") "+
		  "  a GROUP BY mo, C_CUSTCODE,C_CUSTNAME";
                      
		log.info("getCustomerYearlyTotalInvoice]sSQL=> " +sSQL);
		Statement stmt=null;
		ResultSet rs=null;
		Statement stmt2=null;
		ResultSet rs2=null;		
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			double jan=0.00;
			double feb=0.00;
			double mar=0.00;
			double apr=0.00;
			double may=0.00;
			double jun=0.00;
			double jul=0.00;
			double aug=0.00;
			double sep=0.00;
			double oct=0.00;
			double nov=0.00;
			double dec=0.00;
			String month="";
			String customerName="";			
			while(rs.next()){
				month=rs.getString("mo").trim();
				BigDecimal bg = new BigDecimal(rs.getDouble("amount"));
				if(month.equalsIgnoreCase("January")){
					jan=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("February")){
					feb=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("March")){
					mar=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("April")){
					apr=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("May")){
					may=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("June")){
					jun=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("July")){
					jul=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("August")){
					aug=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("September")){
					sep=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(month.equalsIgnoreCase("October")){
					oct=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}				
				else if(month.equalsIgnoreCase("November")){
					nov=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}	
				else if(month.equalsIgnoreCase("December")){
					dec=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
			}
			double gross=jan+feb+mar+apr+may+jun+jul+aug+sep+oct+nov+dec;
			double creditNotes=CreditNoteDAO.getCreditNoteTotalAmount(cc,null);
			double nett = gross - creditNotes; 
			double lastYear=InvoiceDAO.getTotalInvoice(cc,"1")-CreditNoteDAO.getCreditNoteTotalAmount(cc,"1");
			retValue=jan+delim+feb+delim+mar+delim+apr+delim+may+delim+jun+delim+jul+delim+aug+delim+sep+delim+oct+delim+nov+delim+dec+delim+gross+delim+creditNotes+delim+nett+delim+lastYear;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}				
		return retValue;
	}
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
	
	public static void main(String[] args){
		CustomerDAO customerDAO = new CustomerDAO();
		CC cc = new CC();
		cc.setClientCode("38");
		cc.setCustomerCode("8");
		cc.setBranchCode("02");
		cc.setAsOfDate("06/30/2009");
		cc.setStatus("IN ('2','3','4','5')");
		String[] str= customerDAO.getCustomerSalesAnalysis(cc).split(delim);
			log.info("---------------------------------------");
			log.info("jan: "+str[0]);
			log.info("feb: "+str[1]);	
			log.info("mar: "+str[2]);	
			log.info("apr: "+str[3]);	
			log.info("may: "+str[4]);	
			log.info("jun: "+str[5]);	
			log.info("jul: "+str[6]);	
			log.info("aug: "+str[7]);	
			log.info("sep: "+str[8]);	
			log.info("oct: "+str[9]);	
			log.info("nov: "+str[10]);	
			log.info("dec: "+str[11]);
			log.info("gross: "+str[12]);
			log.info("credit note: "+str[13]);
			log.info("nett: "+str[14]);
			log.info("last year: "+str[15]);			

	}	
	

	
	public List<CCLink> getAllCustomerConcentration(CC cc)
	{	
		String where=(cc.getCustomerCode()!=null)?" AND C_CUSTCODE="+cc.getCustomerCode():"";
		List<CCLink> list = new ArrayList<CCLink>();		
		String sSQL = 	"SELECT C_CUSTNAME,C_NAME,CC.C_CUSTCODE,CC.C_CLNTCODE,CC.N_TERM, " + 
						"	(CASE 	WHEN '"+cc.getAsOfDate()+"' BETWEEN D_CCAPDATE AND D_CCEXDATE THEN ISNULL(N_CCLIMIT,0.00) " +
						"	     	WHEN '"+cc.getAsOfDate()+"' BETWEEN D_CCAPDATE1 AND D_CCEXDATE1 THEN ISNULL(N_CCLIMIT1,0.00)ELSE 0.00 END) AS fundLimit " +
						" FROM CC WHERE C_BRANCHCODE ='"+cc.getBranchCode()+"' " +
						where+" "+
						" ORDER BY C_CUSTNAME ";

		log.info("[getAllCustomerConcentration]sSQL=> " +sSQL);
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
			String delim="@";
			double overallCurrent=0.00;
			double overall1to30=0.00;
			double overall31to60=0.00;
			double overall61to90=0.00;
			double overall91to120=0.00;
			double overall121to150=0.00;
			double overall151to180=0.00;
			double overallOver180=0.00;
			double overallTotalOS=0.00;				
			while(rs.next()){
				log.info("starting iteration");
				CCLink ccLink= new CCLink();
				ccLink.setClientName(rs.getString("C_NAME"));
				ccLink.setCustomerName(rs.getString("C_CUSTNAME"));
				ccLink.setFundLimit(rs.getDouble("FUNDLIMIT"));
				ccLink.setN_Term(rs.getInt("N_TERM"));
				Invoice i = new Invoice();
				i.setC_CLNTCODE(rs.getString("C_CLNTCODE"));
				i.setC_CUSTCODE(rs.getString("C_CUSTCODE"));	
				i.setC_BRANCHCODE(cc.getBranchCode());
				i.setC_STATUS(cc.getStatus());
				i.setAsOfDate(cc.getAsOfDate());
				double n_Current=0.00d;
				double n_1to30=0.00d;
				double n_31to60=0.00d;
				double n_61to90=0.00d;
				double n_91to120=0.00d;
				double n_121to150=0.00d;
				double n_151to180=0.00d;
				double n_over180=0.00d;
				double n_TotalOS=0.00d;
				
		
				long age=0;
				Iterator<Invoice> iter=InvoiceDAO.geAllInvoiceByStatus(i).iterator();
				double amount = 0.00d;
				while(iter.hasNext()){
					Invoice inv = (Invoice)iter.next();
					amount=inv.getC_STATUS()!=null&&inv.getC_STATUS().equalsIgnoreCase("4")?InvoiceDAO.getPartialAmount(inv.getN_INVNO()):inv.getN_INVOICEAMT();
					amount = Money.doRoundOff(amount);
					age=inv.getAgeing()-inv.getN_TERM();
					log.info("ccAgingAnalysisList");
					log.info("inv.getAgeing()"+inv.getAgeing());
					log.info("Invoice N_TERM "+inv.getN_TERM());
					log.info("CCLink N_TERM "+ccLink.getN_Term());					
					log.info("getAllCustomerConcentration ageing: "+age);					

					if(age>0 && age<31){
						n_1to30+=amount;
					}
					else if(age>30 && age<61){
						n_31to60+=amount;
					}
					else if(age>60 && age<91){
						n_61to90+=amount;
					}
					else if(age>90 && age<121){
						n_91to120+=amount;
					}
					else if(age>120 && age<151){
						n_121to150+=amount;
					}
					else if(age>150 && age<181){
						n_151to180+=amount;
					}
					else if(age>180){
						n_over180+=amount;
					}
					else{
						n_Current+=amount;
					}
				}
				n_TotalOS = n_Current + n_1to30 + n_31to60 + n_61to90 + n_91to120 + n_121to150 + n_151to180 + n_over180;
				ccLink.setN_Current(n_Current);
				ccLink.setN_1to30(n_1to30);
				ccLink.setN_31to60(n_31to60);
				ccLink.setN_61to90(n_61to90);
				ccLink.setN_91to120(n_91to120);
				ccLink.setN_121to150(n_121to150);
				ccLink.setN_151to180(n_151to180);
				ccLink.setN_over180(n_over180);
				ccLink.setN_TotalOS(n_TotalOS);
				 overallCurrent+=ccLink.getN_Current();
				 overall1to30+=ccLink.getN_1to30();
				 overall31to60+=ccLink.getN_31to60();
				 overall61to90+=ccLink.getN_61to90();
				 overall91to120+=ccLink.getN_91to120();
				 overall121to150+=ccLink.getN_121to150();
				 overall151to180+=ccLink.getN_151to180();
				 overallOver180+=ccLink.getN_Over180();
				 overallTotalOS+=ccLink.getN_TotalOS();		
				list.add(ccLink);		
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return list;
	}	
	

}
