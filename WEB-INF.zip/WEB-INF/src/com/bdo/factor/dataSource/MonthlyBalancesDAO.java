package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.AccountOfficer;
import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLinkBean;
import com.bdo.factor.beans.CISABusinessBean;
import com.bdo.factor.beans.CISAContract;
import com.bdo.factor.beans.CISAContractReference;
import com.bdo.factor.beans.CISAIndividualBean;
import com.bdo.factor.beans.CISALink;
import com.bdo.factor.beans.CisaCustomerReference;
import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.beans.ClientBean;
import com.bdo.factor.beans.MonthlyBalances;
import com.bdo.factor.beans.PostDate;
import com.bdo.factor.dao.AdvancesDAO;
import com.bdo.factor.dao.CISADAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.ReceiptsDtlDAO;
import com.bdo.factor.dao.SystemSettingsDAO;
import com.bdo.factor.service.AccountOfficerService;
import com.bdo.factor.service.AuditService;
import com.bdo.factor.service.CISAService;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.DateUtils;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.util.ServiceUtility;

public class MonthlyBalancesDAO {
	
	private static Logger log = Logger.getLogger(MonthlyBalancesDAO.class);
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	public MonthlyBalancesDAO() {
		//   TODO Auto-generated constructor stub
	}
	
	public List<MonthlyBalances> getMonthBalClntCodeAsOfDate(String clientCode,String asOfDate){
		List<MonthlyBalances> list = new ArrayList<MonthlyBalances>();
		String mo=DateUtils.getLastMonthMMM(asOfDate);
		log.info(mo);
		String sSQL="SELECT ISNULL(N_"+mo+"FIU,0.00) , ISNULL(N_"+mo+"REC,0.00) , ISNULL(N_"+mo+"RES,0.00) FROM MonthlyBalances WHERE C_CLNTCODE='"+clientCode+"'";			
		log.info("MonthlyBalanceDAO -getMonthBalClntCodeAsOfDate (sSQL) "+sSQL);
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
				while(rs.next()){				
					BigDecimal fiu = new BigDecimal(rs.getDouble(1));
					BigDecimal monthReceivables = new BigDecimal(rs.getDouble(2));
					BigDecimal monthReserves = new BigDecimal(rs.getDouble(3));					
					MonthlyBalances mb = new MonthlyBalances(fiu.setScale(2, BigDecimal.ROUND_HALF_UP),monthReceivables.setScale(2, BigDecimal.ROUND_HALF_UP),monthReserves.setScale(2, BigDecimal.ROUND_HALF_UP));
					list.add(mb);
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}		
		return list;
	}
	
	
	public boolean saveMonthlyBalancesByClntCodeAsOfDate(ClientActivities ca,String asOfDate, Map map){
		List<MonthlyBalances> list = new ArrayList<MonthlyBalances>();
		Date date = DateHelper.parse(asOfDate); 
		GregorianCalendar gc = new GregorianCalendar();
		SimpleDateFormat sdf = new SimpleDateFormat("MMM");
		gc.setTime(date);		
		Date month = gc.getTime();			
		String mo=sdf.format(month).toUpperCase();
		/*
		if(mo.equalsIgnoreCase("DEC")){
			mo="PREVYR";		
		}
		*/
		log.info("MMM "+mo);
		boolean update=false;
				
		//String sSQL="UPDATE MonthlyBalances SET N_"+mo+"FIU="+ca.getTotalFiuBalance()+" , N_"+mo+"REC="+ca.getTotalReceivables()+" , N_"+mo+"RES="+ca.getTotalReserves()+" , N_"+mo+"ACC="+ca.getDiscountCharges()+"  WHERE C_CLNTCODE='"+ca.getClientCode()+"'";
		String sSQL="UPDATE MonthlyBalances SET N_"+mo+"FIU="+ca.getTotalFiuTransaction()+" , N_"+mo+"REC="+ca.getTotalReceivables()+" , N_"+mo+"RES="+ca.getTotalReserves()+" , N_"+mo+"ACC="+ca.getDiscountCharges()+"  WHERE C_CLNTCODE='"+ca.getClientCode()+"'";
		log.info("getMonthBalClntCodeAsOfDate (sSQL) "+sSQL);
		Statement stmt=null;
		ResultSet rs=null;
		Connection conn = new FactorConnection().getConnection();
		
		 
		try{
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			update= stmt.executeUpdate(sSQL)>0;
			log.info("(saveMonthlyBalancesByClntCodeAsOfDate) Updating MonthlyBalances equals= "+update);
			conn.commit();
			Map newData = new HashMap();
			AuditService as = AuditService.getInstance();
			newData = ServiceUtility.removeNulls(map);
			PostDate cn = new PostDate(newData);
			as.addAudit(newData.get("C_USERID").toString(),"U","MonthlyBalances","(Client "+ca.getClientCode()+") N_"+mo+"FIU="+ca.getTotalFiuBalance()+" , N_"+mo+"REC="+ca.getTotalReceivables()+" , N_"+mo+"RES="+ca.getTotalReserves()+" , N_"+mo+"ACC="+ca.getDiscountCharges());				
			}
		catch(Exception e){
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally{			
			try{
				conn.setAutoCommit(true);
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}  
		}		
		return update;
	}	

	public boolean extractCISA(ClientActivities ca,String asOfDate, Map map){
		SystemSettingsDAO _SystemSettingsDAO = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
		if(!_SystemSettingsDAO.getIsCISAEnabled()){
			return true;
		}
		
		com.bdo.factor.dao.ClientDAO cd =(com.bdo.factor.dao.ClientDAO)Persistence.getDAO("ClientDAO");
		ClientBean clientBean = cd.getClientByID(Long.parseLong(ca.getClientCode()));
		CISAService _CISAService = CISAService.getInstance();
		try{	
		AccountOfficerService AOService = AccountOfficerService.getInstance();
		AccountOfficer AO = AOService.getAccountOfficerByCode(clientBean.getC_ACCTOFFICERCODE());
		
		//moved here
		com.bdo.factor.dao.CCLinkDAO ccLinkDAO = (com.bdo.factor.dao.CCLinkDAO) Persistence.getDAO("CCLinkDAO");
		List<CCLinkBean> clientCustomerLink = ccLinkDAO.getCCLinkByClientCode(Long.parseLong(ca.getClientCode()));
		List<CISALink> _CISALinkList = new ArrayList<CISALink>();
		Map<String,List<CISALink>> CISALinkMap = new HashMap<String,List<CISALink>>();
		
		
		//Client
		Map<String,List<CISAContractReference>> _CISAContractReferenceMap = new HashMap<String,List<CISAContractReference>>();
		List<CISAContractReference> _CISAContractReferenceList = new ArrayList<CISAContractReference>();
		//Customer
		Map<String,List<CisaCustomerReference>> _CisaCustomerReference = new HashMap<String,List<CisaCustomerReference>>();
		List<CisaCustomerReference> _CISACustomerReferenceList = new ArrayList<CisaCustomerReference>();
				
		CISADAO _CISADAO = (CISADAO)Persistence.getDAO("CISADAO");
		
		int checkIfClientExist = _CISADAO.checkIfClientExist(Integer.parseInt(String.valueOf(clientBean.getC_CLNTCODE())));
		CISAContractReference _CISAContractRef = new CISAContractReference();
		
	//ClientReference
		if(checkIfClientExist == 0){
			_CISAContractRef.setTransID(Integer.parseInt(String.valueOf(clientBean.getC_CLNTCODE())));
			//_CISAReference.setContractSource("FaMS");
			_CISAContractReferenceList.add(_CISAContractRef);
			}
	
		if(_CISAContractReferenceList.size()!=0){
			_CISAContractReferenceMap.put("CISAContractReferenceList", _CISAContractReferenceList);
			_CISAService.AddCISALinkListReferenceClient(_CISAContractReferenceMap);
			}	
		
		//CustomerReference
		for (CCLinkBean ccLinkBean1 : clientCustomerLink) {	
			CisaCustomerReference _CISACustomerREf = new CisaCustomerReference();
			int checkIfCustomerExist = _CISADAO.checkIfCustomerExist(Integer.parseInt(String.valueOf(ccLinkBean1.getC_CUSTCODE())));
			if(checkIfCustomerExist == 0){
				_CISACustomerREf.setClientID(Integer.parseInt(String.valueOf(ccLinkBean1.getC_CUSTCODE())));
				_CISACustomerREf.setClientSource("FaMS");
				_CISACustomerReferenceList.add(_CISACustomerREf);
			}
			
		}
		//CustomerReference
		if(_CISACustomerReferenceList.size()!=0){
			_CisaCustomerReference.put("CISACustomerReferenceList", _CISACustomerReferenceList);		
			_CISAService.AddCISALinkListReferenceCustomer(_CisaCustomerReference);
		}
		//end
		
		
		if(clientBean.getC_BORWCODE()!=null &&clientBean.getC_BORWCODE().equalsIgnoreCase("50")){ // check if the cause id getC_BORWCODE
			CISAIndividualBean _CISAIndividualBean = new CISAIndividualBean();
			_CISAIndividualBean.setRecord_type("ID");
			_CISAIndividualBean.setParty_id("FaMSC"+_CISADAO.getRefID(String.valueOf(clientBean.getC_CLNTCODE()))); //before String.valueOf(clientBean.getC_CLNTCODE()
			_CISAIndividualBean.setFirst_name("");
			_CISAIndividualBean.setLast_name(clientBean.getC_NAME());
			_CISAIndividualBean.setGender("");
			_CISAIndividualBean.setDate_of_birth(clientBean.getD_BUSINESSDATEOFBIRTH()!=null?  sdf.format(clientBean.getD_BUSINESSDATEOFBIRTH()):"");
			_CISAIndividualBean.setNationality("PH");
			_CISAIndividualBean.setAddress1_addressType("MI");
			_CISAIndividualBean.setAddress1_fullAddress(clientBean.getC_ADDRESS());
			_CISAIndividualBean.setContact1_contactType("1");
			_CISAIndividualBean.setContact1_contactValue(clientBean.getC_TELNO()!=null?clientBean.getC_TELNO():"000-0000");
			_CISAIndividualBean.setIdentification1_type  ("10");
			_CISAIndividualBean.setIdentification1_number(clientBean.getC_TIN());
			_CISAIndividualBean.setId1_type(null);
			_CISAIndividualBean.setId1_number(null);
			_CISAIndividualBean.setAccount_officer(AO!=null?AO.getC_Name():"");
			_CISAService.AddCISAIndividualBean(_CISAIndividualBean);
		}
		else{
			CISABusinessBean _CISABusinessBean = new CISABusinessBean();
			_CISABusinessBean.setRecord_type("BD");
			_CISABusinessBean.setParty_id("FaMSC"+_CISADAO.getRefID(String.valueOf(clientBean.getC_CLNTCODE()))); //before Integer.parseInt(String.valueOf(clientBean.getC_CLNTCODE()
			_CISABusinessBean.setTrade_name(clientBean.getC_NAME());
			_CISABusinessBean.setAddress1_addressType("MT");
			_CISABusinessBean.setAddress1_fullAddress(clientBean.getC_ADDRESS());
			_CISABusinessBean.setContact1_contactType("1");
			_CISABusinessBean.setContact1_contactValue(clientBean.getC_TELNO().isEmpty()?"000-0000":clientBean.getC_TELNO());
			_CISABusinessBean.setIdentification1_type("10"); // from 16 to 10
			_CISABusinessBean.setIdentification1_number(clientBean.getC_TIN());//changed to tin
			_CISABusinessBean.setAccount_officer(AO!=null?AO.getC_Name():"");
			_CISAService.AddCISABusinessBean(_CISABusinessBean);
		}
			
		        
	
		//CCLINK
		List<CCLinkBean> clientCustomerLink2 = ccLinkDAO.getCCLinkByClientCode(Long.parseLong(ca.getClientCode()));
		for (CCLinkBean ccLinkBean2 : clientCustomerLink2) {						
				CISALink _CISALink = new CISALink();
				_CISALink.setProvider_subject_no_parent("FaMSC"+_CISADAO.getRefID(String.valueOf(clientBean.getC_CLNTCODE()))); //before String.valueOf(clientBean.getC_CLNTCODE())
				_CISALink.setRole_of_parent("R");
				_CISALink.setProvider_subject_no_child("FaMS"+_CISADAO.getCustRefID(String.valueOf(ccLinkBean2.getC_CUSTCODE()))); //changed CVG120616
				_CISALinkList.add(_CISALink);				
			}
		
		//CCLINK
		if(_CISALinkList.size()!=0){
			CISALinkMap.put("CISALinkList", _CISALinkList);
			//_CISAService.AddCISALinkList(CISALinkMap); CVG09062017
		}
		
		//check if Client has an unpaid invoice and if has an outstanding balance
		INVOICEDAO invoiceDAO2  = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
		int addToCisaontract = invoiceDAO2.checkClientInvoice(String.valueOf(clientBean.getC_CLNTCODE()));
		int unpaidChecker = (invoiceDAO2.getOutstandingPaymentNumber(String.valueOf(clientBean.getC_CLNTCODE()), asOfDate));
		SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy");
		
		if ((addToCisaontract!= 0) && (unpaidChecker!= 0) &&(ca.getTotalFiuBalance()!=0) && (ca.getTotalFiuBalance()>0)){ //ADD to Cisa Contract if Client has an invoice
		CISAContract _CISAContract = new CISAContract();
		_CISAContract.setRecord_type("CI");
		_CISAContract.setProvider_subject_no("FaMSC"+_CISADAO.getRefID(String.valueOf(clientBean.getC_CLNTCODE()))); //changed CVG120616
		_CISAContract.setRole("B");
		_CISAContract.setProvider_contract_no("FaMSC"+_CISADAO.getRefID(String.valueOf(clientBean.getC_CLNTCODE()))); //changed CVG120616
		_CISAContract.setContract_type("22");
		_CISAContract.setContract_phase("AC");
		_CISAContract.setCurrency("PHP");
		_CISAContract.setOriginal_currency("PHP");
		
		String yearClientSince = sdfYear.format(clientBean.getD_CLIENTSINCE()!=null?clientBean.getD_CLIENTSINCE():new Date(0, 0, 0));	
		if (yearClientSince.contentEquals("1900")){
			_CISAContract.setContract_start_date(clientBean.getD_DATECREATE());
		}else{
			_CISAContract.setContract_start_date(clientBean.getD_CLIENTSINCE());
		}
		
		_CISAContract.setTransaction_type_sub_facility("NA");
		_CISAContract.setOutstanding_balance(((Double)(ca.getTotalFiuBalance()*100)).intValue());
		_CISAContract.setAccount_officer(AO!=null?AO.getC_Name():"");
		
		
		double monthly_payment_amount = invoiceDAO2.getInvoiceAmount(String.valueOf(clientBean.getC_CLNTCODE()),asOfDate);
		int outstanding_payment_number = (invoiceDAO2.getOutstandingPaymentNumber(String.valueOf(clientBean.getC_CLNTCODE()), asOfDate));
				//!=null?
				//invoiceDAO2.getOutstandingPaymentNumber(String.valueOf(clientBean.getC_CLNTCODE()), asOfDate):"0"); 
		Date contract_end_planned_date = (invoiceDAO2.getInvoiceDuedate(String.valueOf(clientBean.getC_CLNTCODE()), asOfDate));
		
		ReceiptsDtlDAO receiptsDtlDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
		double last_payment_amount = receiptsDtlDAO.getLastPaymentAmount(String.valueOf(clientBean.getC_CLNTCODE()),asOfDate);
			
		AdvancesDAO advancesDAO = (AdvancesDAO)Persistence.getDAO("AdvancesDAO");
		double financed_amount = advancesDAO.getFinanceAmount(String.valueOf(clientBean.getC_CLNTCODE()), asOfDate);		
		
		_CISAContract.setContract_end_planned_date(contract_end_planned_date);
		_CISAContract.setFinanced_amount(financed_amount);
		_CISAContract.setInstallment_numbers(outstanding_payment_number); 
		_CISAContract.setPayment_periodicity("I");
		_CISAContract.setMonthly_payment_amount(monthly_payment_amount);
		_CISAContract.setLast_payment_amount(last_payment_amount);
		_CISAContract.setOutstanding_payment_no(outstanding_payment_number);
		
		 Map<String,Double> chargesMap = new HashMap<String,Double>();
		 InvoiceDAO invoiceDAO  = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		 chargesMap = invoiceDAO.getCISAOverdueCharges(String.valueOf(clientBean.getC_CLNTCODE()));
		 double penaltyAmount = chargesMap.get("penaltyAmt")!=null?chargesMap.get("penaltyAmt"):0;
		 double pastDueInterest = chargesMap.get("pastDueInterest")!=null?chargesMap.get("pastDueInterest"):0;
		 double invoiceAmount = chargesMap.get("invoiceAmount")!=null?chargesMap.get("invoiceAmount"):0;
		 int overdueDays = chargesMap.get("overdueDays")!=null?chargesMap.get("overdueDays").intValue():0;
		 int penaltyCount = chargesMap.get("penaltyCount")!=null?chargesMap.get("penaltyCount").intValue():0;
		 int overdueValue =0 ;
		 if(overdueDays==0)
			 overdueValue = 0;
		 else if(overdueDays>=1 && overdueDays<=30)
			 overdueValue = 1;
		 else if( overdueDays>=31 && overdueDays<=60)
			 overdueValue = 2;
		 else if( overdueDays>=61 && overdueDays<=90)
			 overdueValue = 3;
		 else if( overdueDays>=91 && overdueDays<=180)
			 overdueValue = 4;
		 else if( overdueDays>=181 && overdueDays<=365)
			 overdueValue = 5;
		 else if(overdueDays >=366)
			 overdueValue = 6;
		 
		 
		 
		_CISAContract.setOverdue_payments_no(penaltyCount);
		_CISAContract.setOverdue_payments_amount(((Double)((invoiceAmount+penaltyAmount+pastDueInterest)*100)).intValue());
		_CISAContract.setOverdue_days(overdueValue);
		_CISAService.ADDCISAContract(_CISAContract);
		}
				
		return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
			
		}
		
	}
	/**
	 * @param args
	 */
		public static String getParseMonth(String date){
			String[] str = date.split("/");
			if(str[0].startsWith("0"))return str[0].substring(1, 2);
			return str[0];
		}
		

		public static boolean saveYearEnd(String branchCode){
			boolean update=false;
			try{
				Connection conn= new FactorConnection().getConnection();
				CallableStatement cstmt = conn.prepareCall("{call sp_SAVEYEAREND('"+branchCode+"')}");
				int i = cstmt.executeUpdate();
				log.info("size of all client in Branch:"+branchCode+" which have been updated equal to "+i);
				update=i>0?true:false;
				log.info("Updating/Saving Year End of all Branch Code('"+branchCode+"') equal to "+update);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			return update;
		}	
		
		
		
		public MonthlyBalances getYearEndMonthlyBalances(CC cc){
			MonthlyBalances mb = new MonthlyBalances();
			String sSQL = 	" SELECT * FROM MonthlyBalances WHERE C_CLNTCODE="+cc.getClientCode();						
			log.info("getYearEndMonthlyBalances (args1:" +cc.getClientCode()+") " +sSQL);
			PreparedStatement pstmt=null;
			Connection conn = null;
			ResultSet rs = null;
			conn = new FactorConnection().getConnection();					
			try{
				conn.setAutoCommit(false);
				pstmt = conn.prepareStatement(sSQL);
				rs=pstmt.executeQuery();
				while(rs.next()){
					mb.setClientCode(cc.getClientCode());
					mb.setN_PREVJANFIU(rs.getDouble("N_PREVJANFIU"));
					mb.setN_PREVFEBFIU(rs.getDouble("N_PREVFEBFIU"));
					mb.setN_PREVMARFIU(rs.getDouble("N_PREVMARFIU"));
					mb.setN_PREVAPRFIU(rs.getDouble("N_PREVAPRFIU"));
					mb.setN_PREVMAYFIU(rs.getDouble("N_PREVMAYFIU"));
					mb.setN_PREVJUNFIU(rs.getDouble("N_PREVJUNFIU"));
					mb.setN_PREVJULFIU(rs.getDouble("N_PREVJULFIU"));
					mb.setN_PREVAUGFIU(rs.getDouble("N_PREVAUGFIU"));
					mb.setN_PREVSEPFIU(rs.getDouble("N_PREVSEPFIU"));
					mb.setN_PREVOCTFIU(rs.getDouble("N_PREVOCTFIU"));
					mb.setN_PREVNOVFIU(rs.getDouble("N_PREVNOVFIU"));
					mb.setN_PREVYRFIU(rs.getDouble("N_PREVYRFIU"));	
					
					mb.setN_PREVJANREC(rs.getDouble("N_PREVJANREC"));
					mb.setN_PREVFEBREC(rs.getDouble("N_PREVFEBREC"));
					mb.setN_PREVMARREC(rs.getDouble("N_PREVMARREC"));
					mb.setN_PREVAPRREC(rs.getDouble("N_PREVAPRREC"));
					mb.setN_PREVMAYREC(rs.getDouble("N_PREVMAYREC"));
					mb.setN_PREVJUNREC(rs.getDouble("N_PREVJUNREC"));
					mb.setN_PREVJULREC(rs.getDouble("N_PREVJULREC"));
					mb.setN_PREVAUGREC(rs.getDouble("N_PREVAUGREC"));
					mb.setN_PREVSEPREC(rs.getDouble("N_PREVSEPREC"));
					mb.setN_PREVOCTREC(rs.getDouble("N_PREVOCTREC"));
					mb.setN_PREVNOVREC(rs.getDouble("N_PREVNOVREC"));
					mb.setN_PREVYRREC(rs.getDouble("N_PREVYRREC"));	
					
					mb.setN_PREVJANRES(rs.getDouble("N_PREVJANRES"));
					mb.setN_PREVFEBRES(rs.getDouble("N_PREVFEBRES"));
					mb.setN_PREVMARRES(rs.getDouble("N_PREVMARRES"));
					mb.setN_PREVAPRRES(rs.getDouble("N_PREVAPRRES"));
					mb.setN_PREVMAYRES(rs.getDouble("N_PREVMAYRES"));
					mb.setN_PREVJUNRES(rs.getDouble("N_PREVJUNRES"));
					mb.setN_PREVJULRES(rs.getDouble("N_PREVJULRES"));
					mb.setN_PREVAUGRES(rs.getDouble("N_PREVAUGRES"));
					mb.setN_PREVSEPRES(rs.getDouble("N_PREVSEPRES"));
					mb.setN_PREVOCTRES(rs.getDouble("N_PREVOCTRES"));
					mb.setN_PREVNOVRES(rs.getDouble("N_PREVNOVRES"));
					mb.setN_PREVYRRES(rs.getDouble("N_PREVYRRES"));						
					
				}
				conn.commit();
					
			}
			catch(Exception e){
				try{
					conn.rollback();
				}
				catch(Exception e1){
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			finally{
				try{
					conn.setAutoCommit(true);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}					
			return mb;
		}
		
/*		
		public static boolean saveYearEnd(String clientCode){
			boolean update=false;
			try{
				Connection conn= new FactorConnection().getConnection();
				CallableStatement cstmt = conn.prepareCall("{call sp_SAVEYEAREND('"+clientCode+"')}");
				update=cstmt.executeUpdate()>0?true:false;
				log.info("Updating/Saving Year End of client code('"+clientCode+"') is "+update);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			return update;
		}
*/		
	public static void main(String[] args) {
		/*
		MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
		CC cc = new CC();
		cc.setClientCode("38");
		MonthlyBalances m = mbDAO.getYearEndMonthlyBalances(cc);
		System.out.println("getN_PREVYRRES: "+m.getN_PREVYRRES());
		
		ListIterator li =mbDAO.getMonthBalClntCodeAsOfDate("38","1/30/2009").listIterator();
		while(li.hasNext()){
			MonthlyBalances mb = (MonthlyBalances)li.next();
			log.info("fiu "+mb.getMonthFIU());
			log.info("receivables "+mb.getMonthReceivables());
			log.info("reserves "+mb.getMonthReserves());
		}
		// TODO Auto-generated method stub
		
		log.info(""+getParseMonth("3/02/2009"));
		log.info(""+getParseMonth("12/02/2009"));
		log.info(""+getParseMonth("04/02/2009"));
		*/
		//mbDAO.saveYearEnd("38");
		GregorianCalendar gc = new GregorianCalendar();
		System.out.println("Time "+gc.getTime());
		System.out.println("Year "+gc.get(GregorianCalendar.YEAR));
		System.out.println("Time with Dateformat MM/dd/yyyy "+DateHelper.format(gc.getTime()));
	}

}
