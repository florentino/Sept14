 package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CreditNote;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.FactorConnection;

public class CreditNoteDAO extends JdbcDaoSupport
{
	private static Logger log = Logger.getLogger(CreditNoteDAO.class);	
	
	@SuppressWarnings("unchecked")
	
	public List<CreditNote> getScheduleOfCreditNote(String branchCode, String clientCode, String startDate, String endDate, int Status)
	{
				
		List<CreditNote> list = new ArrayList<CreditNote>();
		
		String sSQL = "SELECT DISTINCT(CreditNote.N_REFNO), CreditNote.D_APPLICATIONDATE, " +
		              "CreditNote.D_INVOICEDATE, CreditNote.C_INVOICENO, " +
                      "ROUND(CreditNote.N_AMOUNT, 3) AS N_AMOUNT, " + 
                      "Invoices.C_CUSTNAME, " +
                      "CNTYPE.C_DESCRIPTION, " +
                      "CreditNote.D_TRANSACTIONDATE, " +
                      "Invoices.C_NAME " +
                      "FROM CreditNote " +
                      "INNER JOIN Invoices " +
                      "ON CreditNote.C_BRANCHCODE = Invoices.C_BRANCHCODE " +
                      "AND CreditNote.C_CLNTCODE = Invoices.C_CLNTCODE " +
                      "AND CreditNote.C_CUSTCODE = Invoices.C_CUSTCODE " +
                      "AND CreditNote.C_INVOICENO = Invoices.C_INVOICENO " +
                      "AND CreditNote.C_INVOICENO = Invoices.C_INVOICENO " +
                      "AND CreditNote.D_TRANSACTIONDATE BETWEEN '"+startDate+"' AND " +
                      "'"+endDate+"' " +
                      "INNER JOIN CNTYPE ON CreditNote.C_CNTYPECODE = CNTYPE.C_CNTYPECODE " +
                      " AND CreditNote.C_BRANCHCODE = Invoices.C_BRANCHCODE " +
                      "WHERE " +
                      "CreditNote.C_BRANCHCODE = '" + branchCode + "' ";
				if (Status == 2)
				{
					sSQL +=" AND CreditNote.C_STATUS IN(1,2) ";
				}
				else if (Status == 3)
				{
					sSQL +=" AND CreditNote.C_STATUS = 3 ";
				}
                 sSQL +=" AND CreditNote.C_CLNTCODE = " + clientCode +
                      " ORDER BY Invoices.C_NAME, Invoices.C_CUSTNAME, CreditNote.D_APPLICATIONDATE " ;
		
		
		log.info("[getScheduleOfCreditNote][Status]==>" + Status);
		log.info("[getScheduleOfCreditNote][debug]==>" + sSQL);
		list = getJdbcTemplate().query(sSQL,
			
				new RowMapper()
				{
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException
					{					
						CreditNote creditNote = new CreditNote();
						
						creditNote.setN_REFNO(rs.getLong("N_REFNO"));
						creditNote.setC_NAME(rs.getString("C_NAME"));
						creditNote.setD_APPLICATIONDATE(rs.getDate("D_APPLICATIONDATE"));
						creditNote.setD_TRANSACTIONDATE(rs.getDate("D_TRANSACTIONDATE"));
						creditNote.setD_INVOICEDATE(rs.getDate("D_INVOICEDATE"));
						creditNote.setC_INVOICENO(rs.getString("C_INVOICENO"));
						creditNote.setN_AMOUNT(rs.getDouble("N_AMOUNT"));
						creditNote.setC_CUSTNAME(rs.getString("C_CUSTNAME"));
						creditNote.setC_DESCRIPTION(rs.getString("C_DESCRIPTION"));
						return creditNote;					
					}
				}
			
			);
		
		System.out.println("-->>> SIZE: "+list.size());
		
		return list;				
	}
	
	public double getTotalCreditNoteAmt(String branchCode, String clientCode, String startDate, String endDate, int Status)
	{		 
		double retval = 0.0;
		String sSQL   = "SELECT ROUND(SUM(CreditNote.N_AMOUNT), 3) "+		
		"FROM CreditNote " +        
        "WHERE CreditNote.D_TRANSACTIONDATE BETWEEN '"+startDate+"' AND " +
        " '"+endDate+"' " +
        "AND " +
        "CreditNote.C_BRANCHCODE = '" + branchCode + "' "+ 
        "AND CreditNote.C_CLNTCODE = " + clientCode + 
        " AND CreditNote.C_STATUS = " + Status ;
        //" AND CreditNote.C_STATUS = '1' " +
        //"OR CreditNote.C_STATUS = '2'";
		
		log.info("[getTotalInvoiceAmount][debug]==>" + sSQL);
		log.info("[getTotalInvoiceAmount][debug]==>" + sSQL);
		retval = (Double)getJdbcTemplate().queryForObject(sSQL, 
			new RowMapper()
			{
				@Override 
				public Object mapRow(ResultSet rs, int rowNum) throws SQLException
				{										
					return rs.getDouble(1);										
				}
			}
		);
				
		return retval;		
	}
	

	public static double getCreditNoteTotalAmount(CC cc,String option){
		String year=option!=null&&option.equalsIgnoreCase("1")?DateHelper.getLastYearDate(cc.getAsOfDate()):cc.getAsOfDate();
		
		String sSQL="SELECT ISNULL(SUM(N_AMOUNT),0) AS amount FROM CreditNote INNER JOIN CC " +
					"	ON CreditNote.C_CLNTCODE=CC.C_CLNTCODE " +
					"	   AND CreditNote.C_CUSTCODE=CC.C_CUSTCODE " + 
					"		   AND CreditNote.C_BRANCHCODE=CC.C_BRANCHCODE " + 
					"	  WHERE (CreditNote.D_TRANSACTIONDATE BETWEEN '01/01/'+CAST(YEAR('"+year+"') AS NVARCHAR) AND '"+year+"') " +
				  //"			AND YEAR(CreditNote.D_TRANSACTIONDATE)=YEAR('"+cc.getAsOfDate()+"') " +
					"			AND (CreditNote.C_CLNTCODE = '"+cc.getClientCode()+"') AND (CreditNote.C_CUSTCODE = '"+cc.getCustomerCode()+"') " +
					"			AND CreditNote.C_BRANCHCODE='"+cc.getBranchCode()+"' AND CreditNote.C_STATUS=2 " +
					"     GROUP BY CreditNote.C_CLNTCODE,CreditNote.C_CUSTCODE,CreditNote.C_BRANCHCODE";
	
		log.info("getCreditNoteTotalAmount]sSQL=> " +sSQL);
		double total=0.00d;
		Statement stmt=null;
		ResultSet rs=null;
		try{		
			stmt=new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
				while(rs.next()){
				BigDecimal bg = new BigDecimal(rs.getDouble("amount"));
				total=bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();		
				}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}
		return total;
	}
	
	
	
	
}
