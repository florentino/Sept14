package com.bdo.factor.dataSource;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bdo.factor.beans.ClientDebtTurn;
import com.bdo.factor.beans.TransactionControlTotal;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.FactorConnection;

public class TransactionControlTotalDAO extends JdbcDaoSupport{
	private Logger log = Logger.getLogger(TransactionControlTotalDAO.class);
	
	public TransactionControlTotal getTransactionControlTotal(String startDate, String endDate, String branchCode) {		
		TransactionControlTotal tct = new TransactionControlTotal();
		
		String sSQL =  "select invCount.invCount, invCount.invAmount, invCancelled.invCancelledCount, " +
				"invCancelled.invCancelledAmount, svcChg.svcChg, svcChg.svcchgCount, " +
				"discchgcd.discchg1, discchgcd.discchg1Count, cd.cdAmount, cd.cdCount, cd.refDiscchgCount, cd.refDiscchg " +
				"from (select count(inv.c_invoiceno) as invCount, IsNull(sum(inv.n_invoiceAmt),0) as invAmount " +
				"from invoice inv where inv.c_status between '2' and '6' and inv.d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchCode = '" + branchCode + "')invCount " +
				"cross join (select count(inv.c_invoiceno) as invCancelledCount, IsNull(sum(inv.n_invoiceAmt),0) as invCancelledAmount " +
				"from invoice inv where inv.c_status='7' and inv.d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "')invCancelled " +
				"cross join (select IsNull(sum(n_svcchg),0) as svcchg, count(n_svcchg) as svcchgCount " +
				"from advances where advances.d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_status = '2' and c_branchcode = '" + branchCode + "') svcChg " +
				"cross join (select IsNull(sum(n_discchg1),0)as discchg1, IsNull(count(n_discchg1),0)as discchg1Count " +
				"from advances where d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_status = '2' and c_branchcode = '" + branchCode + "') discchgcd " +
				"cross join (select IsNull(sum(n_discchgcd),0)as cdAmount, IsNull(count(n_discchgcd),0)as cdCount, " +
				"IsNull(sum(n_discchg),0) as refDiscchg, IsNull(count(n_discchg),0) as refDiscchgCount " +
				"from refund where d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "' and c_status = '2')cd";
		
		log.info(sSQL);
		
		PreparedStatement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){				
					tct.setInvCount(rs.getInt("invCount"));
					tct.setInvAmount(rs.getDouble("invAmount"));
					tct.setInvCancelledCount(rs.getInt("invCancelledCount"));
					tct.setInvCancelledAmount(rs.getDouble("invCancelledAmount"));
					tct.setSvcChargeCount(rs.getInt("invCount"));					
					tct.setDiscChargeCount((rs.getInt("discchg1Count") + rs.getInt("refDiscchgCount")));
					tct.setDiscChargeAmount((rs.getDouble("discchg1") + rs.getDouble("refDiscchg")));
					tct.setCashDelayAmount(rs.getDouble("cdAmount"));
					tct.setCashDelayCount(rs.getInt("cdCount"));
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}	
		
		sSQL = "select sum (scharge) as serviceCharge from " +
				"(select cc.n_scr, (n_invoiceamt * (n_scr / 100)) as scharge " +
				"from invoice inv inner join cc on inv.c_clntcode = cc.c_clntcode and inv.c_custcode = cc.c_custcode " +
				"where inv.c_status between '2' and '6' and inv.d_transactiondate between '" + startDate + "' and '" + endDate + "' and inv.c_branchCode = '" + branchCode + "')dtable";
		
		log.info("sql1A:" + sSQL);
		
		stmt=null;
		rs=null;
		try{
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){					
					tct.setSvcChargeAmount(rs.getDouble("serviceCharge"));					
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}	
		
		sSQL = "select receiptsCHK.receiptCHK, receiptsCHK.receiptCHKCount, receiptsCSH.receiptCSH, receiptsCSH.receiptCSHCount," +
				"receiptsCA.receiptCA, receiptsCA.receiptCACount, dishonored.dishonored, dishonored.dishonoredCount, " +
				"cancelledRCSH.cancelledRCSH, cancelledRCSH.cancelledRCSHCount, cancelledRCA.cancelledRCA, cancelledRCA.cancelledRCACount,cn.cnAmount, cn.cnCount, cnCancelled.cnCancelledAmount, cnCancelled.cnCancelledCount " +
				"from ( select IsNull(sum(n_amount),0) as receiptCHK, count(n_amount) as receiptCHKCount from receiptshdr " +
				"where c_receipttype = '1' and c_status in ('1', '2', '4') and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') receiptsCHK " +
				"cross join (select IsNull(sum(n_amount),0) as receiptCSH, count(n_amount) as receiptCSHCount from receiptshdr " +
				"where c_receipttype = '2' and c_status in ('1', '2', '4') and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') receiptsCSH " +
				"cross join (select IsNull(sum(n_amount),0) as receiptCA, count(n_amount) as receiptCACount from receiptshdr " +
				"where c_receipttype = '3' and c_status in ('1', '2', '4') and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') receiptsCA " +
				"cross join (select IsNull(sum(n_amount),0) as dishonored, count(n_amount) as dishonoredCount from receiptshdr " +
				"where c_status = '3' and c_receipttype = '1' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') dishonored " +
				
				"cross join (select IsNull(sum(n_amount),0) as cancelledRCSH, count(n_amount) as cancelledRCSHCount from receiptshdr " +
				"where c_status = '3' and c_receipttype = '2' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') cancelledRCSH " +
				
				"cross join (select IsNull(sum(n_amount),0) as cancelledRCA, count(n_amount) as cancelledRCACount from receiptshdr " +
				"where c_status = '3' and c_receipttype = '3' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') cancelledRCA " +
				
				"cross join (select IsNull(sum(n_amount),0) as cnAmount, count(n_amount) as cnCount from creditnote " +
				"where c_status in ('1', '2') and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "' )cn " +
				"cross join (select IsNull(sum(n_amount),0) as cnCancelledAmount, count(n_amount) as cnCancelledCount from creditnote " +
				"where c_status = '3' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "' )cnCancelled";
		
		log.info("SQL 2" + sSQL);
		
		stmt=null;
		rs=null;
		try{
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){				
					tct.setReceiptsChkCount(rs.getInt("receiptCHKCount"));
					tct.setReceiptsChkAmount(rs.getDouble("receiptCHK"));
					tct.setReceiptsCashCount(rs.getInt("receiptCSHCount"));
					tct.setReceiptsCashAmount(rs.getDouble("receiptCSH"));
					tct.setReceiptsCACount(rs.getInt("receiptCACount"));
					tct.setReceiptsCAAmount(rs.getDouble("receiptCA"));
					tct.setDishonoredCheckAmount(rs.getDouble("dishonored"));
					tct.setDishonoredCheckCount(rs.getInt("dishonoredCount"));
					tct.setCancelledReceiptsCSH(rs.getDouble("cancelledRCSH"));
					tct.setCancelledReceiptsCSHCount(rs.getInt("cancelledRCSHCount"));
					tct.setCancelledReceiptsCA(rs.getDouble("cancelledRCA"));
					tct.setCancelledReceiptsCACount(rs.getInt("cancelledRCACount"));
					tct.setCnAmount(rs.getDouble("cnAmount"));
					tct.setCnCount(rs.getInt("cnCount"));
					tct.setCnCancelledAmount(rs.getDouble("cnCancelledAmount"));
					tct.setCnCancelledCount(rs.getInt("cnCancelledCount"));										
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}
		
		sSQL = "select ref1.ref1amt, ref1.ref1Count, ref2.ref2amt, ref2.ref2Count, ref3.ref3amt, ref3.ref3Count, ref4.ref4Count, ref4.ref4Amt, " +
				"cref.cancelledRefAmt, cref.cancelledRefCount " +
				"from (select isNull(sum(n_refamt),0) as ref1amt, count(n_refamt) as ref1Count from refund " +
				"where c_status = '2' and c_type = '1' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') ref1 " +
				"cross join (select isNull(sum(n_refamt),0) as ref2amt, count(n_refamt) as ref2Count " +
				"from refund where c_status = '2' and c_type = '2' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') ref2 " +
				"cross join (select isNull(sum(n_refamt),0) as ref3amt, count(n_refamt) as ref3Count " +
				"from refund where c_status = '2' and c_type = '3' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') ref3 " +
				"cross join (select isNull(sum(n_refamt),0) as ref4amt, count(n_refamt) as ref4Count from refund " +
				"where c_status = '2' and c_type = '4' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') ref4 " +
				"cross join (select isNull(sum(n_refamt),0) as cancelledRefAmt, count(n_refamt) as cancelledRefCount from refund " +
				"where c_status = '3' and d_transactiondate between '" + startDate + "' and '" + endDate + "' and c_branchcode = '" + branchCode + "') cRef";
		
		log.info("SQL 3" + sSQL);
		
		stmt=null;
		rs=null;
		try{
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){				
					tct.setRefund1Count(rs.getInt("ref1Count"));
					tct.setRefund1Amount(rs.getDouble("ref1amt"));
					tct.setRefund2Count(rs.getInt("ref2Count"));
					tct.setRefund2Amount(rs.getDouble("ref2amt"));
					tct.setRefund3Count(rs.getInt("ref3Count"));
					tct.setRefund3Amount(rs.getDouble("ref3amt"));
					tct.setRefund4Amount(rs.getDouble("ref4amt"));
					tct.setRefund4Count(rs.getInt("ref4Count"));
					tct.setRefundCancelledAmount(rs.getDouble("cancelledRefAmt"));
					tct.setRefundCancelledCount(rs.getInt("cancelledRefCount"));												
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}
		
		sSQL = 	"select adv.advAmount, advCount, advSettingUp.advSettingUpFee, advSettingUp.advSettingUpFeeCount, " +
				"cancelledAdv.cancelledAdv, cancelledAdv.cancelledAdvCount " +
				"from (select IsNull(sum(n_advamt),0) as advAmount, count(*) as advCount from advances " +
				"where c_type = '1' and c_status = '2' and c_branchcode = '" + branchCode + "' and d_transactiondate between '" + startDate + "' and '" + endDate + "') adv " +
				"cross join  (select IsNull(sum(n_advamt),0) as advSettingUpFee, count(*) as advSettingUpFeeCount from advances " +
				"where c_type = '2' and c_status = '2' and c_branchcode = '" + branchCode + "' and d_transactiondate between '" + startDate + "' and '" + endDate + "') advSettingUp " +
				"cross join (select IsNull(sum(n_advamt),0) as cancelledAdv, count(*) as cancelledAdvCount from advances " +
				"where c_status = '3' and c_branchcode = '" + branchCode + "' and d_transactiondate between '" + startDate + "' and '" + endDate + "') cancelledAdv";

		log.info("SQL 4" + sSQL);

		stmt=null;
		rs=null;
		try{
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
			while(rs.next()){				
				tct.setAdvancesCount(rs.getInt("advCount"));
				tct.setAdvancesAmount(rs.getDouble("advAmount"));
				tct.setAdvancesSettingUpFee(rs.getDouble("advSettingUpFee"));
				tct.setAdvancesSettingUpFeeCount(rs.getInt("advSettingUpFeeCount"));
				tct.setCancelledAdvances(rs.getDouble("cancelledAdv"));
				tct.setCancelledAdvancesCount(rs.getInt("cancelledAdvCount"));																
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}
		
		sSQL = 	"select rh.c_clntcode, rh.n_cashdelay, rh.d_transactiondate, IsNull(rh.n_amount,0) as n_amount, IsNull(n_totinvamt,0) as n_totinvamt, cc.n_dcr " +
				"from receiptshdr rh " +
				"left join cc on cc.c_clntcode = rh.c_clntcode and cc.c_custcode = rh.c_custcode " +
				"where rh.c_branchcode = '" + branchCode + "' and rh.n_cashdelay > 0 and rh.c_status in ('1', '2', '4') " +
				"and rh.d_transactiondate between '" + startDate + "' and '" + endDate + "'";

		log.info("SQL 5" + sSQL);
				
		List lCashDelay = new ArrayList();

		stmt=null;
		rs=null;
		try{
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
			
			while(rs.next()){
				Map mCashDelay = new HashMap();
				mCashDelay.put("nAmount", rs.getDouble("n_amount") + "");
				mCashDelay.put("clntCode", rs.getString("c_clntcode"));
				mCashDelay.put("transactionDate", rs.getDate("d_transactiondate") + "");
				mCashDelay.put("cashDelay", rs.getInt("n_cashdelay") + "");
				mCashDelay.put("totInvAmount", rs.getDouble("n_totinvamt") + "");
				mCashDelay.put("dcr", rs.getDouble("n_dcr") + "");
				
				lCashDelay.add(mCashDelay);		
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}
		
		
		double totalCashDelayAmount = 0;		
		
		for (int i = 0; i < lCashDelay.size(); i++) {
			Map m = (HashMap) lCashDelay.get(i);
			double blr = 0;
			double cashDelayAmount = 0;
			String clientCode = m.get("clntCode").toString();
			double nAmount = Double.parseDouble(m.get("nAmount").toString());
			double invoiceAmount = Double.parseDouble(m.get("totInvAmount").toString());
			int cashDelay = Integer.parseInt(m.get("cashDelay").toString());
			String transactionDate = m.get("transactionDate").toString();
			double dcr = Double.parseDouble(m.get("dcr").toString());
			
			sSQL = 	"select dbo.getBlr (" + clientCode + ", '" + transactionDate + "') as BLR";
			
			log.info("SQL 5" + sSQL);
			
			stmt=null;
			rs=null;
			try{
				stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
				rs = stmt.executeQuery();
		
				while(rs.next()){
					blr = rs.getDouble("BLR");
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			finally{
				try{
					if(rs!=null)rs.close();
					if(stmt!=null)stmt.close();
				}
				catch(SQLException e){}
			}	
			
			if (nAmount < invoiceAmount) {
				cashDelayAmount = (nAmount * (blr + (dcr/100)) / 360) * cashDelay;				
			}
			else {
				cashDelayAmount = (invoiceAmount * (blr + (dcr/100)) / 360) * cashDelay;
			}
			totalCashDelayAmount = totalCashDelayAmount + cashDelayAmount;
			log.info("cashDelayAmount: " + cashDelayAmount);
			
			
		}
		log.info("ttalcashDelayAmount: " + totalCashDelayAmount);
		tct.setCashDelayAmount(totalCashDelayAmount);
		tct.setCashDelayCount(lCashDelay.size());
		
		double discountChargeTotal = getDiscountChargePerBranch(branchCode, startDate, endDate);
		tct.setDiscChargeAmount(discountChargeTotal);
					
		return tct;
		
	}
	
	public double getDiscountChargePerBranch(String branchCode, String startDate, String endDate) {
		double discountChargeTotal = 0;
		
		Set sClientCode = new HashSet();
		
		Calendar cal = new GregorianCalendar();
		cal.setTime(DateHelper.parse(endDate));
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(cal.DAY_OF_MONTH));
		String monthEndDate = DateHelper.format(cal.getTime());
		
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
		/*
		String sSQL = "select distinct(c_clntcode) as clientCode from invoice " +
				"where c_status in ('2', '3', '4', '5') and c_branchcode = '" + branchCode + "' " +
				"and d_transactiondate between '" + startDate + "' and '" + monthEndDate + "' union " +
				"select distinct(c_clntcode) as clientCode from advances where c_status = '2' " +
				"and c_type in ('1', '2') and c_branchcode = '" + branchCode + "' " +
				"and d_transactiondate between '" + startDate + "' and '" + monthEndDate + "' union " +
				"select distinct(c_clntcode) as clientCode from receiptshdr where C_STATUS IN (1,2,4) and " +
				"C_RECEIPTTYPE IN (1,2) and c_branchcode = '" + branchCode + "' " +
				"and d_transactiondate between '" + startDate + "' and '" + monthEndDate + "'";
				
			*/
		
		String sSQL = "select distinct(c_clntcode) as clientCode from invoice " +
		"where d_transactiondate between '" + startDate + "' and '" + monthEndDate + "' union " +
		"select distinct(c_clntcode) as clientCode from advances where d_transactiondate between '" + startDate + "' and '" + monthEndDate + "' union " +
		"select distinct(c_clntcode) as clientCode from receiptshdr where d_transactiondate between '" + startDate + "' and '" + monthEndDate + "'";
		
		log.info("sSQL for DiscountCharge: " + sSQL); 
		
		try{
			stmt = new FactorConnection().getConnection().prepareStatement(sSQL);			
			rs = stmt.executeQuery();
				while(rs.next()){
					sClientCode.add(rs.getString("clientCode"));
				}
		}		
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}
		
		if (sClientCode != null && sClientCode.size() > 0) {
			log.info("sClientCodeSize:" + sClientCode.size());
			Iterator i = sClientCode.iterator();
			while (i.hasNext()) {
				MonthlyChargesDAO moCharges = (MonthlyChargesDAO)Persistence.getDAO("monthlyChargesDao");
				String clientCode = (String) i.next();
				log.info("sClientCode: " + clientCode);
				double discountCharge  = moCharges.getDiscountChargePerClient(monthEndDate, Long.parseLong(clientCode));
				discountChargeTotal = discountCharge + discountChargeTotal;
				log.info("discountChargeTotal: " + discountChargeTotal);
			}
		}
		log.info("return discountChargeTotal: " + discountChargeTotal);
		return discountChargeTotal;
	}

}
