package com.bdo.factor.dataSource;

import java.util.List;
import java.util.ArrayList;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRException;

import com.bdo.factor.beans.ClientConcentration;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;

public class ClientConcentrationDS implements JRDataSource
{
	private List<ClientConcentration> clientConcentrationList = new ArrayList<ClientConcentration>();
	private int index          = -1;
	private int lastIndex      = 0;
	
	
	public ClientConcentrationDS(String branchCode)
	{
		ClientDAO clientDao = (ClientDAO)Persistence.getDAO("ClientDAO");
		clientConcentrationList = clientDao.getClientConcentration(branchCode);
		lastIndex = clientConcentrationList.size();
	}
	
	@Override
	public Object getFieldValue(JRField jrFields) throws JRException 
	{
		String fields = jrFields.getName();
		Object value = null;
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");		
		ClientConcentration clientConcentration = (ClientConcentration)clientConcentrationList.get(index);
		
		if (lastIndex > 0)
		{
			if ("C_NAME".equals(fields))
			{
				value = clientConcentration.getCName();
			}
			
			if ("C_CURRENCYCODE".equals(fields))
			{
				value = clientConcentration.getCCurrencyCode();
			}
			
			if ("N_INVESTMENTLIMIT".equals(fields))
			{
				value = clientConcentration.getNInvestmentLimit();
			}
			
			if ("N_RESERVES".equals(fields))
			{
				value = clientConcentration.getNReserves();
			}
			
			if ("N_RECEIVABLES".equals(fields))
			{
				value = clientConcentration.getNReceivables();
			}
			
			if ("N_FIU".equals(fields))
			{
				value = clientConcentration.getNFIU();
			}			
			if("currentDate".equals(fields)){
				value = date.newDate();
			}
		}
		
		return value;
	}

	@Override
	public boolean next() throws JRException {
		index ++;
        if(index<lastIndex){
            return true;
        }
        return false;
	}
}


