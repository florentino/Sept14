package com.bdo.factor.dataSource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import com.bdo.factor.beans.BLRFile;
import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.ClientActivities;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.service.ClientService;

public class RPTClassificationFields extends ClientDAO implements JRDataSource{
	private static Logger log = Logger.getLogger(RPTClassificationFields.class);
	private String branchcode;
	List clientActList= new ArrayList();	
	private int index=-1;
	private int lastIndex = 0;
	private String clientCode;
	private String clientNme;
	private Double fiuBalance;
	Map<String,Double> listToMap = new HashMap();
	List listOfClient = new ArrayList();
	List newCAList = new ArrayList();
	
	public RPTClassificationFields(String branchCode,String asOfDate,Boolean includeZero) {
		ClientService clientService = ClientService.getInstance();
		listOfClient =  clientService.getAllClient(branchCode);
		
		ListIterator li = listOfClient.listIterator();

		while (li.hasNext()){
			Client c = (Client) li.next();
			//clientActList =  getClientActivities4(c.getC_ClntCode(),asOfDate);
			//ClientActivities ca = (ClientActivities)clientActList.get(0);
			fiuBalance = getClientFIUbyAsOfDate(c.getC_ClntCode(),asOfDate);
			clientNme = clientService.searchClientNameByCodeString(c.getC_ClntCode());
			//clientNme = getClientNameByCode(c.getC_ClntCode());
			//log.info("(clientNme)=> "+clientNme);
			ClientActivities newCA = new ClientActivities();
			newCA.setClientCode(c.getC_ClntCode());
			newCA.setTotalFiuBalance(fiuBalance);//ca.getTotalFiuBalance());
			newCA.setClientName(clientNme);//(ca.getClientName());
			System.out.println("INCLUDING ZERO BALANCE: "+includeZero);
			if(includeZero)
				newCAList.add(newCA);
			else{
				if(fiuBalance!=0){
					newCAList.add(newCA);
				}
			}
			
		}
		lastIndex = newCAList.size();
		log.info("(RPTClassificationFields)lastIndex=> "+lastIndex);

	}
	


	@Override
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		ClientActivities ca = (ClientActivities)newCAList.get(index);
		
			if("clientName".equals(field)){   		
				value = ca.getClientName();
			}
			if("currentDate".equals(field)){
				value=date.newDate();
			}

			if("fiuBalance".equals(field)){   			
				value = ca.getTotalFiuBalance();			
			}
			
		return value;
	}
	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
