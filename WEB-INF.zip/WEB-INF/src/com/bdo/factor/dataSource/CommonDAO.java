package com.bdo.factor.dataSource;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bdo.factor.beans.MonthlyBalances;
import com.bdo.factor.util.FactorConnection;

public class CommonDAO {

	public CommonDAO() {
		// TODO Auto-generated constructor stub
	}

	public static String getField(String field,String tableName,String where){
		String sSQL= "SELECT "+field+" FROM "+tableName+" "+where+"";
		System.out.println("sSQL "+sSQL);
		String retVal="";
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = new FactorConnection().getConnection().createStatement();
			rs = stmt.executeQuery(sSQL);
				while(rs.next()){				
					retVal = rs.getString(1);
				}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
			}
			catch(SQLException e){}
		}
		System.out.println("Return value "+retVal);
		return retVal;
	}
	
	
	
	/**
	 * @param args
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}*/

}
