package com.bdo.factor.dataSource;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.AccountForReview;
import com.bdo.factor.dao.Persistence;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class AccountForReviewField implements JRDataSource{
	private Logger log = Logger.getLogger(AccountForReviewField.class);
	List<AccountForReview> lAccount = new ArrayList<AccountForReview>();
	private int index =-1;
	private int lastIndex = 0;
	
	private String startDate;
	private String endDate;
	private String branchCode;
	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	SimpleDateFormat sdf = new SimpleDateFormat ("mm/dd/yyyy");	
	
	AccountForReviewDAO afrDao = (AccountForReviewDAO)Persistence.getDAO("accountForReviewDAO");
	
	public AccountForReviewField(String startDate, String endDate, String branchCode) {
		this.startDate=startDate;
		this.endDate=endDate;
		this.branchCode=branchCode;
		
		Map param = new HashMap();
		param.put("startDate", startDate);
		param.put("endDate", endDate);
		param.put("branchCode", branchCode);
		
		lAccount = afrDao.getAccountForReview(startDate, endDate, branchCode);
		lastIndex = lAccount.size();
	}
	
	public Object getFieldValue(JRField jRField) throws JRException {
		Object value = null;
		String field = jRField.getName();
		AccountForReview afr = (AccountForReview) lAccount.get(index);
		
		if (lAccount.size() > 0) {
			if ("aoName".equals(field)) {
				value = afr.getAccountOfficer();
			}
			if ("clientName".equals(field)) {
				value = afr.getClientName();
			}
			if ("cpsClassification".equals(field)) {
				value = afr.getCpsClassification();
			}
			if ("customerName".equals(field)) {
				value = afr.getCustomerName();
			}
			if ("reviewDate".equals(field)) {
				value = sdf.format(afr.getReviewDate());
			}
			if ("investmentLimit".equals(field)) {
				value = df.format(afr.getInvestmentLimit());
			}
			if ("outstandingAR".equals(field)) {
				value = df.format(afr.getOutstandingAR());
			}
			if ("dateRange".equals(field)) {
				value = startDate + "=" + endDate;
			}

			if ("currentDate".equals(field)) {
				value = afr.getCurrentDate();
			}
		}
		return value;
	}
	
	@Override
	public boolean next() throws JRException {
		index ++;
		if(index<lastIndex){
			return true;
		}
		return false;
	}

}
