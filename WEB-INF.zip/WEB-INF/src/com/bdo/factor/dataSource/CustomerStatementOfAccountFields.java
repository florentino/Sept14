 package com.bdo.factor.dataSource;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRException;

import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.beans.CustomerStatementOfAcct;
import com.bdo.factor.beans.Customer;

public class CustomerStatementOfAccountFields implements JRDataSource
{
	private List<CustomerStatementOfAcct> customerStmtOfAcctList = new ArrayList<CustomerStatementOfAcct>();
	List<Customer> customerList                                  = new ArrayList<Customer>();
	private int index = -1;
	private int lastIndex = 0;
	private String asOfDate = "";
	private long CustCode = 0;	
	private boolean isByClientOnly       = false;
	private String branchName            = "";
	private String userID                = "";
	private double bal                   = 0;
	
	
	private double current               = 0.00;
	private double sumOf1To30Days        = 0.00;
	private double sumOf31To60Days       = 0.00;
	private double sumOf61To90Days       = 0.00;
	private double sumOf91To120Days      = 0.00; 
	private double sumOf121To150Days     = 0.00; 
	private double sumOf151To180Days     = 0.00; 
	private double sumOfMoreThan180Days  = 0.00;
	private double sumOfReceipts1To30Days= 0.00;
	private double sumOfReceipts31To60Days= 0.00;
	private double sumOfReceipts61To90Days= 0.00;
	private double sumOfReceipts91To120Days= 0.00;
	private double sumOfReceipts121To150Days= 0.00;
	private double sumOfReceipts151To180Days= 0.00;
	private double sumOfReceiptsMoreThan180Days= 0.00;
	private double sumOfReceiptsCurrent        = 0.00;
	private long   invoiceDueAge         = 0;	
	private long   receiptDueAge         = 0;
	private long invoiceDueAgeGrp        =0;
	private long   receiptDueAgeGrp         = 0;
	private double currentGrp               = 0.00;
	private double sumOf1To30DaysGrp        = 0.00;
	private double sumOf31To60DaysGrp       = 0.00;
	private double sumOf61To90DaysGrp       = 0.00;
	private double sumOf91To120DaysGrp      = 0.00; 
	private double sumOf121To150DaysGrp     = 0.00; 
	private double sumOf151To180DaysGrp     = 0.00; 
	private double sumOfMoreThan180DaysGrp  = 0.00;
	private double sumOfReceipts1To30DaysGrp= 0.00;
	private double sumOfReceipts31To60DaysGrp= 0.00;
	private double sumOfReceipts61To90DaysGrp= 0.00;
	private double sumOfReceipts91To120DaysGrp= 0.00;
	private double sumOfReceipts121To150DaysGrp= 0.00;
	private double sumOfReceiptsMoreThan180DaysGrp= 0.00;
	private double sumOfReceiptsCurrentGrp= 0.00;
	
	private long custCode                = 0;
	@SuppressWarnings("unchecked")
	public CustomerStatementOfAccountFields(String clientCode, 
											long custCode, 
											String asOfDate, 
											String branchCode,
											Boolean filter) throws SQLException 
	{
		this.setAsOfDate(asOfDate);
		this.setCustCode(custCode);
		
		if (custCode > 0) isByClientOnly = false;
		else isByClientOnly = true;
		//{
			CustomerStatementOfAcctDAO custStmtOfAcctDao = (CustomerStatementOfAcctDAO)Persistence.getDAO("customerStmtOfAcctDao");
			customerStmtOfAcctList = custStmtOfAcctDao.getCustomerStatmentOfAccount(clientCode, custCode, asOfDate, branchCode,filter);
			customerList                                 = custStmtOfAcctDao.getCustomerDetailsByCode(custCode,clientCode);
			
		//}
		
		lastIndex                                    = customerStmtOfAcctList.size();
	}

	@Override
	public Object getFieldValue(JRField jrField) throws JRException 
	{
		Object value = null;
		String field = jrField.getName();
		CustomerStatementOfAcct custStmtOfAcct = (CustomerStatementOfAcct)customerStmtOfAcctList.get(index);
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		int listSize = customerStmtOfAcctList.size();
		if (listSize > 0)
		{
			if ("tDate".equals(field))
			{
				value = custStmtOfAcct.getTDate();
			}
			if ("descr".equals(field))
			{
				value = custStmtOfAcct.getDescription();
			}
			if ("ref".equals(field))
			{
				value = custStmtOfAcct.getReferenceNo();
			}
			if ("ref2".equals(field))
			{
				value = custStmtOfAcct.getReferenceNo2();
			}
			if ("dueDate".equals(field))
			{
				value = custStmtOfAcct.getDueDate();
			}
			if ("debit".equals(field))
			{
				value = numberFormater(custStmtOfAcct.getDebit());				
			}
			if ("credit".equals(field))
			{
				value = numberFormater(custStmtOfAcct.getCredit());
			}
			if ("d_actualPaidDate".equals(field))
			{
				value = custStmtOfAcct.getD_actualPaidDate();
			}
			if (!isByClientOnly)
			{
				if ("balance".equals(field))
				{
					if (custStmtOfAcct.getCredit() > bal)
					{
						bal = ((bal + custStmtOfAcct.getDebit()) - custStmtOfAcct.getCredit());
					}
					else
					{		
						bal = ((bal + custStmtOfAcct.getDebit()) - (custStmtOfAcct.getDescription().trim().equalsIgnoreCase("Over Payment") ? 0.00 : custStmtOfAcct.getCredit()));
					}
					
					value = (this.numberFormater(bal).equals("-0.00")) ? 0.00 : bal;				
				}
			}			
			else
			{		
				if (this.getCustCode() == 0)
				{
					this.setCustCode(custStmtOfAcct.getCustCode());					
				}
				CustCode = this.getCustCode();
				if ("balance".equals(field))
				{					
					if (CustCode == custStmtOfAcct.getCustCode())
					{
						if (custStmtOfAcct.getCredit() > bal)
						{
							bal = ((bal + custStmtOfAcct.getDebit()) - custStmtOfAcct.getCredit());
						}
						else
						{		
							bal = ((bal +  custStmtOfAcct.getDebit()) - (custStmtOfAcct.getDescription().trim().equalsIgnoreCase("Over Payment") ? 0.00 : custStmtOfAcct.getCredit()));
						}																								
						//invoiceDueAgeGrp removed CVG03142017								
					}
					else
					{
						this.setCustCode(custStmtOfAcct.getCustCode());
						bal = 0;
						if (custStmtOfAcct.getCredit() > bal)
						{
							bal = (custStmtOfAcct.getCredit() - (bal + custStmtOfAcct.getDebit()));
						}
						else
						{		
							bal = (bal + custStmtOfAcct.getDebit() - custStmtOfAcct.getCredit());
						}
						
						//invoiceDueAgeGrp removed CVG03142017						
					}
															
					value = (this.numberFormater(bal).equals("-0.00")) ? 0.00 : bal;
				}								
			}
			
			//CVG 03172017
			if (this.getCustCode() == 0)
			{
				this.setCustCode(custStmtOfAcct.getCustCode());					
			}
			CustCode = this.getCustCode();
			if (CustCode != custStmtOfAcct.getCustCode())
			{
				this.sumOf1To30DaysGrp = 0;
				this.sumOf31To60DaysGrp = 0;
				this.sumOf61To90DaysGrp = 0;
				this.sumOf91To120DaysGrp = 0;
				this.sumOf121To150DaysGrp = 0;
				this.sumOf151To180DaysGrp = 0;
				this.sumOfMoreThan180DaysGrp = 0;
				this.currentGrp = 0;
				this.sumOfReceipts1To30DaysGrp=0;
				this.sumOfReceipts31To60DaysGrp=0;
				this.sumOfReceipts61To90DaysGrp=0;
				this.sumOfReceipts91To120DaysGrp=0;
				this.sumOfReceipts121To150DaysGrp=0;
				this.sumOfReceipts151To180Days=0;
				this.sumOfReceiptsMoreThan180DaysGrp=0;
				this.sumOfReceiptsCurrentGrp=0;
			}else{
				
			}
			//end
			
		
			if ("invoiceAge".equals(field))
			{			
				value = (custStmtOfAcct.getInvoiceDue()!=0 ? Integer.toString(custStmtOfAcct.getInvoiceDue()) : "");
				this.invoiceDueAge = custStmtOfAcct.getInvoiceDue();// - custStmtOfAcct.getN_TERM();
				this.receiptDueAge = custStmtOfAcct.getReceiptDue();// - custStmtOfAcct.getN_TERM();							
			
			if ((this.invoiceDueAge >= 1 && this.invoiceDueAge <= 30) || (this.receiptDueAge >=1 && this.receiptDueAge <= 30)) 
			{					
				this.sumOf1To30Days = this.sumOf1To30Days + custStmtOfAcct.getDebit();					
				this.sumOfReceipts1To30Days = this.sumOfReceipts1To30Days + custStmtOfAcct.getReceipts();														
			}
			else if ((this.invoiceDueAge >= 31 && this.invoiceDueAge <= 60) || this.receiptDueAge >=31 && this.receiptDueAge <= 60)
			{
				this.sumOf31To60Days = this.sumOf31To60Days + custStmtOfAcct.getDebit();
				this.sumOfReceipts31To60Days = this.sumOfReceipts31To60Days + custStmtOfAcct.getReceipts();										
			}
			else if ((this.invoiceDueAge >= 61 && this.invoiceDueAge <= 90) || (this.receiptDueAge >=61 && this.receiptDueAge <= 90))
			{
				this.sumOf61To90Days = this.sumOf61To90Days + custStmtOfAcct.getDebit();
				this.sumOfReceipts61To90Days = this.sumOfReceipts61To90Days + custStmtOfAcct.getReceipts();					
			}
			else if ((this.invoiceDueAge >= 91 && this.invoiceDueAge <= 120) || (this.receiptDueAge >=91 && this.receiptDueAge <= 120))
			{
				this.sumOf91To120Days = this.sumOf91To120Days + custStmtOfAcct.getDebit();
				this.sumOfReceipts91To120Days = this.sumOfReceipts91To120Days + custStmtOfAcct.getReceipts();					
			}
			else if ((this.invoiceDueAge >= 121 && this.invoiceDueAge <= 150) || (this.receiptDueAge >=121 && this.receiptDueAge <= 150))
			{
				this.sumOf121To150Days = this.sumOf121To150Days + custStmtOfAcct.getDebit(); 
				this.sumOfReceipts121To150Days = this.sumOfReceipts121To150Days + custStmtOfAcct.getReceipts();					
			}
			else if ((this.invoiceDueAge >= 151 && this.invoiceDueAge <= 180) || (this.receiptDueAge >=151 && this.receiptDueAge <= 180))
			{
				this.sumOf151To180Days = this.sumOf151To180Days + custStmtOfAcct.getDebit();
				this.sumOfReceipts151To180Days = this.sumOfReceipts151To180Days + custStmtOfAcct.getReceipts();									
			}
			else if ((this.invoiceDueAge >= 181) || (this.receiptDueAge >= 181))
			{
				this.sumOfMoreThan180Days = this.sumOfMoreThan180Days + custStmtOfAcct.getDebit(); 
				this.sumOfReceiptsMoreThan180Days = this.sumOfReceiptsMoreThan180Days + custStmtOfAcct.getReceipts();								
			}
			else
			{										
				this.sumOfReceiptsCurrent = this.sumOfReceiptsCurrent + custStmtOfAcct.getReceipts();					
				this.current = this.current + custStmtOfAcct.getDebit();					
			}
			
			//invoiceDueGroup CVG 03152016
					if (this.getCustCode() == 0)
					{
						this.setCustCode(custStmtOfAcct.getCustCode());					
					}
					
					CustCode = this.getCustCode();
					if (CustCode == custStmtOfAcct.getCustCode())
					{
								//a																				
							this.invoiceDueAgeGrp = custStmtOfAcct.getInvoiceDue();// - custStmtOfAcct.getN_TERM();
							this.receiptDueAgeGrp = custStmtOfAcct.getReceiptDue();// - custStmtOfAcct.getN_TERM();
							
							if ((this.invoiceDueAgeGrp >= 1 && this.invoiceDueAgeGrp <= 30) || (this.receiptDueAgeGrp >= 1 && this.receiptDueAgeGrp <= 30)) 
							{
								this.sumOf1To30DaysGrp = this.sumOf1To30DaysGrp + custStmtOfAcct.getDebit();
								this.sumOfReceipts1To30DaysGrp = this.sumOfReceipts1To30DaysGrp + custStmtOfAcct.getReceipts();								
							}
							else if ((this.invoiceDueAgeGrp >= 31 && this.invoiceDueAgeGrp <= 60) || (this.receiptDueAgeGrp >= 31 && this.receiptDueAgeGrp <= 60))
							{		
								this.sumOf31To60DaysGrp = this.sumOf31To60DaysGrp + custStmtOfAcct.getDebit();
								this.sumOfReceipts31To60DaysGrp = this.sumOfReceipts31To60DaysGrp + custStmtOfAcct.getReceipts();															
							}
							else if ((this.invoiceDueAgeGrp >= 61 && this.invoiceDueAgeGrp <= 90) || (this.receiptDueAgeGrp >= 61 && this.receiptDueAgeGrp <= 90))
							{
								this.sumOf61To90DaysGrp = this.sumOf61To90DaysGrp + custStmtOfAcct.getDebit();
								this.sumOfReceipts61To90DaysGrp = this.sumOfReceipts61To90DaysGrp + custStmtOfAcct.getReceipts();					
							}
							else if ((this.invoiceDueAgeGrp >= 91 && this.invoiceDueAgeGrp <= 120) || (this.receiptDueAgeGrp >= 91 && this.receiptDueAgeGrp <= 120))
							{
								this.sumOf91To120DaysGrp = this.sumOf91To120DaysGrp + custStmtOfAcct.getDebit();
								this.sumOfReceipts91To120DaysGrp = this.sumOfReceipts91To120DaysGrp + custStmtOfAcct.getReceipts();				
							}
							else if ((this.invoiceDueAgeGrp >= 121 && this.invoiceDueAgeGrp <= 150) || (this.receiptDueAgeGrp >= 121 && this.receiptDueAgeGrp <= 150))
							{
								this.sumOf121To150DaysGrp = this.sumOf121To150DaysGrp + custStmtOfAcct.getDebit();
								this.sumOfReceipts121To150DaysGrp = this.sumOfReceipts121To150DaysGrp + custStmtOfAcct.getReceipts();															
							}
							else if ((this.invoiceDueAgeGrp >= 151 && this.invoiceDueAgeGrp <= 180) || (this.receiptDueAgeGrp >= 151 && this.receiptDueAgeGrp <= 180))
							{
								this.sumOf151To180DaysGrp = this.sumOf151To180DaysGrp + custStmtOfAcct.getDebit(); 
								this.sumOfReceipts151To180Days = this.sumOfReceipts151To180Days + custStmtOfAcct.getReceipts();															
							}
							else if ((this.invoiceDueAgeGrp >= 181) || (this.receiptDueAgeGrp >= 181))
							{
								this.sumOfMoreThan180DaysGrp = this.sumOfMoreThan180DaysGrp + custStmtOfAcct.getDebit(); 
								this.sumOfReceiptsMoreThan180DaysGrp = this.sumOfReceiptsMoreThan180DaysGrp + custStmtOfAcct.getReceipts();																
							}
							else
							{
								this.currentGrp = this.currentGrp + custStmtOfAcct.getDebit();
								this.sumOfReceiptsCurrentGrp = this.sumOfReceiptsCurrentGrp + custStmtOfAcct.getReceipts();															
							}								
					}
					else
					{
						this.setCustCode(custStmtOfAcct.getCustCode());
						bal = 0;
						if (custStmtOfAcct.getCredit() > bal)
						{
							bal = (custStmtOfAcct.getCredit() - (bal + custStmtOfAcct.getDebit()));
						}
						else
						{		
							bal = (bal + custStmtOfAcct.getDebit() - custStmtOfAcct.getCredit());
						}
						
						this.invoiceDueAgeGrp = custStmtOfAcct.getInvoiceDue();// - custStmtOfAcct.getN_TERM();
						this.receiptDueAgeGrp = custStmtOfAcct.getReceiptDue();// - custStmtOfAcct.getN_TERM();
						this.sumOf1To30DaysGrp = 0;
						this.sumOf31To60DaysGrp = 0;
						this.sumOf61To90DaysGrp = 0;
						this.sumOf91To120DaysGrp = 0;
						this.sumOf121To150DaysGrp = 0;
						this.sumOf151To180DaysGrp = 0;
						this.sumOfMoreThan180DaysGrp = 0;
						this.currentGrp = 0;
						this.sumOfReceipts1To30DaysGrp=0;
						this.sumOf31To60DaysGrp=0;
						this.sumOf61To90DaysGrp=0;
						this.sumOf91To120DaysGrp=0;
						this.sumOf121To150DaysGrp=0;
						this.sumOf151To180DaysGrp=0;
						this.sumOfReceiptsMoreThan180DaysGrp=0;
						this.sumOfReceiptsCurrentGrp=0;
						
						if ((this.invoiceDueAgeGrp >= 1 && this.invoiceDueAgeGrp <= 30) || (this.receiptDueAgeGrp >= 1 && this.receiptDueAgeGrp <= 30)) 
						{
							this.sumOf1To30DaysGrp = this.sumOf1To30DaysGrp + custStmtOfAcct.getDebit();
							this.sumOfReceipts1To30DaysGrp = this.sumOfReceipts1To30DaysGrp + custStmtOfAcct.getReceipts();							
						}
						else if ((this.invoiceDueAgeGrp >= 31 && this.invoiceDueAgeGrp <= 60) || (this.receiptDueAgeGrp >= 31 && this.receiptDueAgeGrp <= 60))
						{				
							
							this.sumOf31To60DaysGrp = this.sumOf31To60DaysGrp + custStmtOfAcct.getDebit();
							this.sumOfReceipts31To60DaysGrp = this.sumOfReceipts31To60DaysGrp + custStmtOfAcct.getReceipts();														
						}
						else if ((this.invoiceDueAgeGrp >= 61 && this.invoiceDueAgeGrp <= 90) || (this.receiptDueAgeGrp >= 61 && this.receiptDueAgeGrp <= 90))
						{
							this.sumOf61To90DaysGrp = this.sumOf61To90DaysGrp + custStmtOfAcct.getDebit();
							this.sumOfReceipts61To90DaysGrp = this.sumOfReceipts61To90DaysGrp + custStmtOfAcct.getReceipts();														
						}
						else if ((this.invoiceDueAgeGrp >= 91 && this.invoiceDueAgeGrp <= 120) || (this.receiptDueAgeGrp >= 91 && this.receiptDueAgeGrp <= 120))
						{
							this.sumOf91To120DaysGrp = this.sumOf91To120DaysGrp + custStmtOfAcct.getDebit();
							this.sumOfReceipts91To120DaysGrp = this.sumOfReceipts91To120DaysGrp + custStmtOfAcct.getReceipts();														
						}
						else if ((this.invoiceDueAgeGrp >= 121 && this.invoiceDueAgeGrp <= 150) || (this.receiptDueAgeGrp >= 121 && this.receiptDueAgeGrp <= 150))
						{
							this.sumOf121To150DaysGrp = this.sumOf121To150DaysGrp + custStmtOfAcct.getDebit();
							this.sumOfReceipts121To150DaysGrp = this.sumOfReceipts121To150DaysGrp + custStmtOfAcct.getReceipts();															
						}
						else if ((this.invoiceDueAgeGrp >= 151 && this.invoiceDueAgeGrp <= 180) || (this.receiptDueAgeGrp >= 151 && this.receiptDueAgeGrp <= 180))
						{
							this.sumOf151To180DaysGrp = this.sumOf151To180DaysGrp + custStmtOfAcct.getDebit(); 
							this.sumOfReceipts151To180Days = this.sumOfReceipts151To180Days + custStmtOfAcct.getReceipts();														
						}
						else if ((this.invoiceDueAgeGrp >= 181) || (this.receiptDueAgeGrp >= 181))
						{
							this.sumOfMoreThan180DaysGrp = this.sumOfMoreThan180DaysGrp + custStmtOfAcct.getDebit(); 
							this.sumOfReceiptsMoreThan180DaysGrp = this.sumOfReceiptsMoreThan180DaysGrp + custStmtOfAcct.getReceipts();														
						}
						else
						{
							this.currentGrp = this.currentGrp + custStmtOfAcct.getDebit();
							this.sumOfReceiptsCurrentGrp = this.sumOfReceiptsCurrentGrp + custStmtOfAcct.getReceipts();														
						}						
					}
															
					value = (this.numberFormater(bal).equals("-0.00")) ? 0.00 : bal;
				}								
			}
		
			if ("invoiceAge".equals(field))
			{				
				value = (custStmtOfAcct.getInvoiceDue()!=0 ? Integer.toString(custStmtOfAcct.getInvoiceDue()) : "");
				
				this.invoiceDueAge = custStmtOfAcct.getInvoiceDue();// - custStmtOfAcct.getN_TERM();
				this.receiptDueAge = custStmtOfAcct.getReceiptDue();// - custStmtOfAcct.getN_TERM();							
				
				if ((this.invoiceDueAge >= 1 && this.invoiceDueAge <= 30) || (this.receiptDueAge >=1 && this.receiptDueAge <= 30)) 
				{					
					this.sumOf1To30Days = this.sumOf1To30Days + custStmtOfAcct.getDebit();					
					this.sumOfReceipts1To30Days = this.sumOfReceipts1To30Days + custStmtOfAcct.getReceipts();														
				}
				else if ((this.invoiceDueAge >= 31 && this.invoiceDueAge <= 60) || (this.receiptDueAge >=31 && this.receiptDueAge <= 60))
				{
					this.sumOf31To60Days = this.sumOf31To60Days + custStmtOfAcct.getDebit();
					this.sumOfReceipts31To60Days = this.sumOfReceipts31To60Days + custStmtOfAcct.getReceipts();										
				}
				else if ((this.invoiceDueAge >= 61 && this.invoiceDueAge <= 90) || (this.receiptDueAge >=61 && this.receiptDueAge <= 90))
				{
					this.sumOf61To90Days = this.sumOf61To90Days + custStmtOfAcct.getDebit();
					this.sumOfReceipts61To90Days = this.sumOfReceipts61To90Days + custStmtOfAcct.getReceipts();					
				}
				else if ((this.invoiceDueAge >= 91 && this.invoiceDueAge <= 120) || (this.receiptDueAge >=91 && this.receiptDueAge <= 120))
				{
					this.sumOf91To120Days = this.sumOf91To120Days + custStmtOfAcct.getDebit();
					this.sumOfReceipts91To120Days = this.sumOfReceipts91To120Days + custStmtOfAcct.getReceipts();					
				}
				else if ((this.invoiceDueAge >= 121 && this.invoiceDueAge <= 150) || (this.receiptDueAge >=121 && this.receiptDueAge <= 150))
				{
					this.sumOf121To150Days = this.sumOf121To150Days + custStmtOfAcct.getDebit(); 
					this.sumOfReceipts121To150Days = this.sumOfReceipts121To150Days + custStmtOfAcct.getReceipts();					
				}
				else if ((this.invoiceDueAge >= 151 && this.invoiceDueAge <= 180) || (this.receiptDueAge >=151 && this.receiptDueAge <= 180))
				{
					this.sumOf151To180Days = this.sumOf151To180Days + custStmtOfAcct.getDebit();
					this.sumOfReceipts151To180Days = this.sumOfReceipts151To180Days + custStmtOfAcct.getReceipts();									
				}
				else if ((this.invoiceDueAge >= 181) || (this.receiptDueAge >= 181))
				{
					this.sumOfMoreThan180Days = this.sumOfMoreThan180Days + custStmtOfAcct.getDebit(); 
					this.sumOfReceiptsMoreThan180Days = this.sumOfReceiptsMoreThan180Days + custStmtOfAcct.getReceipts();								
				}
				else
				{										
					this.sumOfReceiptsCurrent = this.sumOfReceiptsCurrent + custStmtOfAcct.getReceipts();					
					this.current = this.current + custStmtOfAcct.getDebit();					
				}
			}		
		
		if ("dateRange".equals(field))
		{
			value = "as of " + this.getAsOfDate().toString();
		}
		
		if ("branchName".equals(field))
		{
			value = this.getBranchName();
		}
		if ("userID".equals(field))
		{
			value = this.getUserID();
		}
				
		if ("sumCurrent".equals(field))
		{			
			value = numberFormater(this.current - this.sumOfReceiptsCurrent); 
		}
		if ("sum1".equals(field))
		{			
			value = numberFormater(this.sumOf1To30Days - this.sumOfReceipts1To30Days);
		}
		
		if ("sum2".equals(field))
		{			
			value = numberFormater((this.sumOf31To60Days - this.sumOfReceipts31To60Days));
		}
		if ("sum3".equals(field))
		{
			value = numberFormater(this.sumOf61To90Days - this.sumOfReceipts61To90Days);
		}
		if ("sum4".equals(field))
		{
			value = numberFormater(this.sumOf91To120Days - this.sumOfReceipts91To120Days);
		}		
		if ("sum5".equals(field))
		{
			value = numberFormater(this.sumOf121To150Days - this.sumOfReceipts121To150Days);
		}
		if ("sum6".equals(field))
		{
			value = numberFormater(this.sumOf151To180Days - this.sumOfReceipts151To180Days);
		}
		if ("sum7".equals(field))
		{
			value = numberFormater(this.sumOfMoreThan180Days - this.sumOfReceiptsMoreThan180Days);
		}
		
		
		if (!isByClientOnly)
		{				
			Customer customer = (Customer)customerList.get(0);
			if ("custName".equals(field))
			{
				value = customer.getC_CustName();
			}	
			if ("custContactNo".equals(field))
			{
				value = customer.getC_TelNo();
			}									
			
			if ("custAddress".equals(field))
			{
				value = customer.getC_Address();
			}
			
			if ("custContact".equals(field))
			{
				value= customer.getC_CollectContact();
			}
		}
		else
		{
			if ("custName".equals(field))
			{				
				value = custStmtOfAcct.getCustomerName();
			}
			
			if ("sumcurrentGrp".equals(field))
			{
				value = numberFormater(this.currentGrp - this.sumOfReceiptsCurrentGrp); 
			}
			if ("sum1Grp".equals(field))
			{
				value = numberFormater(this.sumOf1To30DaysGrp - this.sumOfReceipts1To30DaysGrp);
			}
			
			if ("sum2Grp".equals(field))
			{
				value = numberFormater(this.sumOf31To60DaysGrp - this.sumOfReceipts31To60DaysGrp);
			}
			if ("sum3Grp".equals(field))
			{
				value = numberFormater(this.sumOf61To90DaysGrp - this.sumOfReceipts61To90DaysGrp);
			}
			if ("sum4Grp".equals(field))
			{
				value = numberFormater(this.sumOf91To120DaysGrp - this.sumOfReceipts91To120DaysGrp);
			}		
			if ("sum5Grp".equals(field))
			{
				value = numberFormater(this.sumOf121To150DaysGrp - this.sumOfReceipts121To150DaysGrp);
			}
			if ("sum6Grp".equals(field))
			{
				value = numberFormater(this.sumOf151To180DaysGrp - this.sumOfReceipts151To180Days);
			}
			if ("sum7Grp".equals(field))
			{
				value = numberFormater(this.sumOfMoreThan180DaysGrp - this.sumOfReceiptsMoreThan180DaysGrp);
			}
			
		}
		if ("clientName".equals(field))
		{
			value = "Supplier - " + custStmtOfAcct.getClientName(); 
		}			
		if("currentDate".equals(field)){
			value = date.newDate();
		}
		return value;		
	}

	@Override
	public boolean next() throws JRException {
		index ++;
        if(index<lastIndex)
        {
            return true;
        }
        return false;
	}
	
	public String getAsOfDate() {
		return asOfDate;
	}

	public void setAsOfDate(String asOfDate) 
	{
		this.asOfDate = asOfDate;
	}
	public long getCustCode() {
		return custCode;
	}

	public void setCustCode(long custcode) {
		custCode = custcode;
	}
	
	private String numberFormater(double numbertoformat)
    {
        DecimalFormat df = new DecimalFormat("###,###,##0.00");        
        return df.format(numbertoformat);        
    }
	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	
	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
}
