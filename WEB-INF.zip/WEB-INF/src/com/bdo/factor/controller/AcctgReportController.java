package com.bdo.factor.controller;
import java.util.Date;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRRuntimeException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.j2ee.servlets.BaseHttpServlet;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.exception.FactorsFormatException;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.util.Validator;
import com.bdo.factor.util.XMLParser;

public class AcctgReportController extends MultiActionController{	
	private static LogOnFormController logOnForm = new LogOnFormController();
	private static Logger log = Logger.getLogger(AcctgReportController.class);
	
	Connection connection = new FactorConnection().getConnection();
	ResultSet resultSet;
	Statement statement;
	
	private String asOfDate; 
	private String entryMade;
	private String entryApproved;
	private String message;
	boolean isPosted = false;
	Validator validator = new Validator();
// ***************************** 
	public ModelAndView subledgerReportViewHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		String view = request.getParameter("view").trim();
		ModelAndView mav = new ModelAndView();
		String sessionID = (String) request.getSession().getId();
		if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
		//added by Cherrie Garcia as of 2-10-15
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		return new ModelAndView("acctgReportView");  //point to acctgReportViewHandler and acctgREportController
	}
	public ModelAndView accountingSubledgerReportHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		
		ModelAndView retMAV = new ModelAndView();
       		if(!isSessionActive(request)){
			retMAV.setViewName("../error/error");
			retMAV.addObject("message", "Invalid Request");
			return new ModelAndView("../error/error");
		}
		
		try{
			retMAV.addObject("jasper", "schedOfSubledger");
			retMAV.setViewName("swf");
			subLedgerReportMV(request,response);
		}
		catch(FactorsFormatException ffe){
			retMAV.setViewName("../error/error");
			retMAV.addObject("message", "Invalid Request Parameter Detected");
		}
		catch(Exception e){ e.printStackTrace(); }
		//added by Cherrie Garcia as of 2-10-15
				response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		
		return retMAV;  
	}
	
	public void subLedgerReportMV(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException,FactorsFormatException{
		HttpSession a = request.getSession(true);
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat sdf = new SimpleDateFormat("MM/d/yyyy");
		String getDate = sdf.format(date.newDate());
		ServletContext context = a.getServletContext();
		try
		{
			String accountName= "";
			String asOfDate = request.getParameter("startDate");
			if(asOfDate == null || !validator.isValidDateFormat(asOfDate)){
				throw new FactorsFormatException("Invalid Date");
			}
			String glCode = request.getParameter("clientName").trim();
			if(glCode == null || !validator.isValidGLCode(glCode)){
				throw new FactorsFormatException("Invalid GL Code");
			}
			String GLCodeDescription = request.getParameter("GLDescription")!=null?request.getParameter("GLDescription").trim():"";
			
			String reportFileName =context.getRealPath("/report/schedOfSubledger.jasper");
			File reportFile = new File(reportFileName);
			if (!reportFile.exists())
				throw new JRRuntimeException("report not found");
		    log.info(glCode);
		 	String sSQL = "exec sp_GET_Subledger '" + glCode.trim() + "','" + asOfDate.trim() + "','" + a.getAttribute("userID").toString().trim() + "'";
			log.info(sSQL);
			
			log.info(GLCodeDescription);
			
			//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
			//statement = connection.createStatement();
			statement = new FactorConnection().getConnection().createStatement();
			resultSet =  statement.executeQuery(sSQL);
			
			log.info("Filling the report");
			String systemname = (String) a.getAttribute("systemName");
			String username = (String) a.getAttribute("userName");
			String branchname = (String) a.getAttribute("branchName");
			HashMap<String, String> pMap = new HashMap<String, String>();
			pMap.put("asOfDate", asOfDate);
			pMap.put("systemName", systemname);
			pMap.put("userName", username);
			pMap.put("branchName", branchname);
			pMap.put("accountName", accountName);
			pMap.put("GLCode", glCode.trim());
			pMap.put("GLCodeDescription", GLCodeDescription.trim());
			pMap.put("currentDate", getDate);
			log.info(asOfDate);
			log.info(systemname);
			log.info(username);
			log.info(branchname);
			log.info(GLCodeDescription);
		  
		  InputStream reportStream = context.getResourceAsStream("/report/schedOfSubledger.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, pMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
		}
		catch (JRException e)
		{
			e.printStackTrace();
		}
		//added by Cherrie Garcia as of 2-10-15
				response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	}
	
//	DAILY BALANCE REPORT
public ModelAndView dailyBalanceReportViewHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		String view = request.getParameter("view").trim();
		ModelAndView mav = new ModelAndView();
		String sessionID = (String) request.getSession().getId();
		if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
		//added by Cherrie Garcia as of 2-10-15
				response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		return new ModelAndView("dailyBal"); //Return to dailyBal.jsp
	}

public ModelAndView accountingDailyBalanceReportHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	try{
		mav.addObject("jasper", "dailyBalances");
		mav.setViewName("swf");
		dailyBalanceReport(request,response);
	}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}catch(Exception e){
		e.printStackTrace();
		mav.setViewName("../error/error");
		mav.addObject("message", "Exception Occured");
	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;	
//	return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
}

public void dailyBalanceReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException, FactorsFormatException{
	HttpSession a = request.getSession(true);
	FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
	ServletContext context = a.getServletContext();
	try	{
		String asOfDate = request.getParameter("startDate");
		if(asOfDate==null||!validator.isValidDateFormat(asOfDate)){
			throw new FactorsFormatException("Invalid Date");
		}
		
		
		String reportFileName =context.getRealPath("/report/dailyBalances.jasper");
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		
		String sSQL = " select c_glcode, "
				+ "currentDate = (select currentdate from factorsGetDate), "
				+ "c_accountName,totDEBIT,totCREDIT,Balance,TransForTheDay = isnull(TotalTransactionForTheDay,0) from (  " +
			" 				select  distinct " +
			" 						subMain.c_glcode " + 
			" 						,subMain.c_accountName " + 
			" 						,totDEBIT = isnull(sum(submain.n_debit),'0.00') " + 
			" 						,TotCREDIT =  isnull(sum(submain.n_credit),'0.00')  " +
			" 						,Balance = isnull(sum(submain.n_debit),0)  - isnull(sum(submain.n_credit),0) " + 
			" 						,TotalTransactionfortheDay = ( " +
			" 							select " +  
			" 							Balance = isnull(sum(subMainInner.n_debit),0)  - isnull(sum(subMainInner.n_credit),0) " + 
			" 							from Subledger subMainInner  " +
			" 							inner join subheader subHInner " + 
			" 							on subMainInner.N_TransactionNo =  subHInner.N_transactionNo " + 
			" 							where  " +
			" 								(subHInner.B_cancelled <> 1  or subHInner.B_cancelled is NULL) " + 
			" 								and subMainInner.d_transactionDate =  '" + asOfDate.toString().trim() +  "'" +
			" 								and subMainInner.c_glcode = subMain.c_glcode  " +
			" 								group by subMainInner.c_glcode, subMainInner.c_accountName " +
			" 							) " +
			" 							from Subledger subMain  " +
			" 							inner join subheader subH  " +
			" 							on subMain.N_TransactionNo =  subH.N_transactionNo " + 
			" 							where  " +
			" 								(subH.B_cancelled <> 1  or subH.B_cancelled is NULL) " + 
			"   							and subMain.d_transactionDate <=  '" + asOfDate.toString().trim() +  "'" +
			" 							group by submain.c_glcode, subMain.c_accountName  " +  
			" 				)a " +
			" ORDER BY c_glcode asc ";
		
		 
		log.info(sSQL);
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("asOfDate", asOfDate);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		log.info(parameterMap);
		
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		statement = new FactorConnection().getConnection().createStatement();  
		//statement = connection.createStatement();
		log.info(sSQL);
		resultSet =  statement.executeQuery(sSQL);
		log.info("Filling the report");
		  
		  InputStream reportStream = context.getResourceAsStream("/report/dailyBalances.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	}
	catch (JRException e)
	{
		e.printStackTrace();
	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
}
//*****************************
// DISBURSEMENT MODULE  -------------------------------------------------------
public ModelAndView disbursementReportViewHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	String view = request.getParameter("view").trim();
	ModelAndView mav = new ModelAndView();
	String sessionID = (String) request.getSession().getId();
	if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return new ModelAndView("disbursement"); //Return to dailyBal.jsp
}

// DISBURSEMENT REPORT #############################
public ModelAndView accountingDisbursementReportHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	try{
		mav.addObject("jasper", "repDisbursement");
		mav.setViewName("swf");
		disbursementReport(request,response); 	}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}
	catch(Exception e){ 
		mav.setViewName("../error/error");
		mav.addObject("message", "Server Exception Occured");
	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;	
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
}

public void disbursementReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException, FactorsFormatException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	try {
		String startDate = request.getParameter("startDate");
		if(startDate ==null ||!validator.isValidDateFormat(startDate)){
			throw new FactorsFormatException("Invalid Date Format");
		}
		String endDate = request.getParameter("endDate");
		if(endDate ==null ||!validator.isValidDateFormat(endDate)){
			throw new FactorsFormatException("Invalid Date End Format");
		}
		
		String reportFileName =context.getRealPath("/report/repDisbursement.jasper");
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		//**
		String sSQL = " select C_GLCode, C_AccountName,C_Type, "
		+ "currentDate = (select currentdate from factorsGetDate)," +
		" isnull(n_debit,0.00) as n_debit, " +
		" isnull(n_credit,0.00) as n_credit,  " +
		" totalAmount from " +
		" (Select  " +
		" 	C_GLCode,C_AccountName,C_Type, " +
		" 	case when totalAmount > 0.00 then abs(totalAmount) end as n_debit, " +
		" 	case when totalAmount < 0.00 then abs(totalAmount) end as n_credit, " +
		" 	totalAmount " +
		" 	From " +
		" 	(SELECT  " +  
		" 			s1.C_GLCode, " +
		" 			sh.C_Type, " +
		" 			s1.C_AccountName, " +
		" 			sum(isnull(n_debit,0.00))-sum(isnull(n_credit,0.00)) as totalAmount, " +
		" 			SUM(ISNULL(s1.N_Debit, 0)) AS n_debit,  " +
		" 			SUM(ISNULL(s1.N_Credit, 0)) AS n_credit " +
		" 			FROM  SubLedger s1 INNER JOIN SubHeader sh ON s1.N_TransactionNo = sh.N_TransactionNo " +
		" 			WHERE  (CONVERT(datetime, s1.D_TransactionDate) >= '" + startDate.toString().trim() + "' and  convert(datetime,s1.d_transactionDate) <= '" + endDate.toString().trim() + "') AND " + 
		" 				(sh.C_Type = 'D') AND (sh.B_Cancelled = 0 OR " +
		" 						sh.B_Cancelled IS NULL) AND (sh.C_BranchCode = '01') " +
		" 			GROUP BY s1.C_GLCode,sh.C_Type ,s1.C_AccountName " +
		" 			)a group by C_GLCode,C_AccountName,c_type,totalAmount " + 
		" 			)b  " +
		" 			where totalAmount != 0.00 order by n_debit desc ";

		
		log.info(sSQL);
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("startDate", startDate);
		parameterMap.put("endDate", endDate);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		log.info(parameterMap);
			
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		log.info(sSQL);
		resultSet =  statement.executeQuery(sSQL);
		//ServletOutputStream servletOutputStream =  response.getOutputStream();
		log.info("Filling the report");
		
		  InputStream reportStream = context.getResourceAsStream("/report/repDisbursement.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	}
	catch (JRException e)
	{
		e.printStackTrace();
	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	}

//PAYMENT REPORT	#############################     
public ModelAndView paymentReportViewHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	String view = request.getParameter("view").trim();
	ModelAndView mav = new ModelAndView();
	String sessionID = (String) request.getSession().getId();
	if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return new ModelAndView("repPayment"); //Return to dailyBal.jsp
}
public ModelAndView accountingPaymentReportHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	try{ 		
		mav.addObject("jasper", "repPayment");
		mav.setViewName("swf");
		paymentReport(request,response); 	}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}
	catch(Exception e){e.printStackTrace();}
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;
}

public void paymentReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException,FactorsFormatException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();

	try
	{
		String startDate = request.getParameter("startDate").trim();
		if(startDate==null||!validator.isValidDateFormat(startDate)){
			throw new FactorsFormatException("Invalid Start Date");
		}
		
		String endDate = request.getParameter("endDate").trim();
		if(endDate==null||!validator.isValidDateFormat(endDate)){
			throw new FactorsFormatException("Invalid Start Date");
		}
		
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		String reportFileName =context.getRealPath("/report/repPayment.jasper");
	
			
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");

		String sSQL = " select C_GLCode, C_AccountName,C_Type, "
		+ "currentDate = (select currentdate from factorsGetDate)," +
		" isnull(n_debit,0.00) as n_debit, " +
		" isnull(n_credit,0.00) as n_credit,  " +
		" totalAmount from " +
		" (Select  " +
		" 	C_GLCode,C_AccountName,C_Type, " +
		" 	case when totalAmount > 0.00 then abs(totalAmount) end as n_debit, " +
		" 	case when totalAmount < 0.00 then abs(totalAmount) end as n_credit, " +
		" 	totalAmount " +
		" 	From " +
		" 	(SELECT  " +  
		" 			s1.C_GLCode, " +
		" 			sh.C_Type, " +
		" 			s1.C_AccountName, " +
		" 			sum(isnull(n_debit,0.00))-sum(isnull(n_credit,0.00)) as totalAmount, " +
		" 			SUM(ISNULL(s1.N_Debit, 0)) AS n_debit,  " +
		" 			SUM(ISNULL(s1.N_Credit, 0)) AS n_credit " +
		" 			FROM  SubLedger s1 INNER JOIN SubHeader sh ON s1.N_TransactionNo = sh.N_TransactionNo " +
		" 			WHERE  (CONVERT(datetime, s1.D_TransactionDate) >= '" + startDate.toString().trim() + "' and  convert(datetime,s1.d_transactionDate) <= '" + endDate.toString().trim() + "') AND " + 
		" 				(sh.C_Type = 'P') AND (sh.B_Cancelled = 0 OR " +
		" 						sh.B_Cancelled IS NULL) AND (sh.C_BranchCode = '01') " +
		" 			GROUP BY s1.C_GLCode,sh.C_Type ,s1.C_AccountName " +
		" 			)a group by C_GLCode,C_AccountName,c_type,totalAmount " + 
		" 			)b  " +
		" 			where totalAmount != 0.00 order by n_debit desc ";

		log.info(sSQL);

		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("startDate", startDate);
		parameterMap.put("endDate", endDate);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		
		
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		resultSet =  statement.executeQuery(sSQL);
		log.info("Filling the report");
		
		
	  InputStream reportStream = context.getResourceAsStream("/report/repPayment.jasper");
      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
      statement.close();
	  connection.close();
		
	} 	catch (JRException e) 	{
		e.printStackTrace(); 	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	}

//TRANSACTION INTERFACE REPROT ############################# 
public ModelAndView transactionInterfaceReportViewHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	String view = request.getParameter("view").trim();
	ModelAndView mav = new ModelAndView();
	String sessionID = (String) request.getSession().getId();
	if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
	//added by Cherrie Garcia as of 2-10-15
	response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return new ModelAndView("repTransactionInterface"); //Return to dailyBal.jsp
}
public ModelAndView accountingtransactionInterfaceReportHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	try{ 		
		mav.addObject("jasper", "repTransactionInterface");
		mav.setViewName("swf");
		transactionInterfaceReport(request,response); 	}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}
	catch(Exception e){
		mav.setViewName("../error/error");
		mav.addObject("message", "Server Exception Occured");}
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
	//added by Cherrie Garcia as of 2-10-15
	response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;
}

public void transactionInterfaceReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException, FactorsFormatException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	try 	{
		String reportFileName =context.getRealPath("/report/repTransactionInterface.jasper");
		
		String asOfDate = request.getParameter("startDate");
		if(asOfDate==null||!validator.isValidDateFormat(asOfDate)){
			throw new FactorsFormatException("Invalid Date");
		}
		
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		
				String sSQL = "SELECT     b.D_TransactionDate,"
				+ "currentDate = (select currentdate from factorsGetDate), " +
						" a.N_TransactionNo, " +
				" b.C_GLCode, " +
				" 	a.C_Particular, " +
				" 	b.C_AccountName AS c_description, " +
				" 	d.N_Code, " +
				" 	ISNULL(n_debit, '0.00') AS DEBIT, " +
				" 	ISNULL(n_credit, '0.00') AS CREDIT, b.N_Code AS N_Code " +
				" 		 FROM         SubHeader AS a INNER JOIN " +
				" 		 SubLedger AS b ON a.N_TransactionNo = b.N_TransactionNo INNER JOIN " +
				" 		 ChartOfAccounts AS c ON b.C_GLCode = c.C_ICBSGLCode INNER JOIN " +
				" 		 CostCenter AS d ON b.N_CostCenter = d.N_Code " +
				" WHERE   YEAR(CONVERT(datetime, b.D_TransactionDate, 101)) = YEAR(CONVERT(datetime, '" + asOfDate.trim() + "', 101)) AND MONTH(CONVERT(datetime, " +
				"		 b.D_TransactionDate, 101)) = MONTH(CONVERT(datetime,'" + asOfDate.trim() + "', 101)) AND DAY(CONVERT(datetime, b.D_TransactionDate, 101)) " +
				"		 = DAY(CONVERT(datetime,'" + asOfDate.trim() + "', 101)) 	and d_cancelledDate IS NULL " +
				" ORDER BY a.N_TransactionNo,  n_debit desc;";
			
			
		log.info(sSQL);	
			
		String username=(String) a.getAttribute("userName");
		String branchName = (String) a.getAttribute("branchName");
		String systemName = (String) a.getAttribute("systemName");
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("asOfDate", asOfDate);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchName);
		parameterMap.put("systemName", systemName);
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		resultSet =  statement.executeQuery(sSQL);
		//ServletOutputStream servletOutputStream =  response.getOutputStream();
			InputStream reportStream = context.getResourceAsStream("/report/repTransactionInterface.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	}
	catch (JRException e)
	{
		e.printStackTrace();
	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	}


// ICBS GL UPLOAD EXPORTER #############################
public ModelAndView icbsGLUploadReportViewHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	String view = request.getParameter("view").trim();
	ModelAndView mav = new ModelAndView();
	String sessionID = (String) request.getSession().getId();
	if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
	//added by Cherrie Garcia as of 2-24-15
	response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return new ModelAndView("repICBSGLUpload"); //Return to dailyBal.jsp
}
public void accountingtransactionICBSGLUploadHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	boolean valid = true;
	asOfDate = request.getParameter("asOfDate");
	if (asOfDate==null||!validator.isValidDateFormat(asOfDate)){
		message = "Invalid Date Format";
	}
	
	entryMade = request.getParameter("entryMade").trim();
	if	(entryMade==null||entryMade.isEmpty()){
		message = "Invalid Entry Made";
	}
	
	entryApproved = request.getParameter("entryApproved").trim();
	if	(entryApproved==null||entryApproved.isEmpty()){
		message = "Invalid Entry Approved";
	}
	
	String checkBox = (String)(request.getParameter("openNotepad"));
	Boolean success = false;
	log.info(checkBox);
	if(valid){
		try{ 		
			success = generateCsvFile(request,response); 
			if(success){
				String filename = "TIR";
				String file = "/"+filename+".csv";  
				System.out.println(file);  
				response.setContentType("text/plain");  
				ServletContext ctx = XMLParser.getContext();
				InputStream is = ctx.getResourceAsStream(file);  
				response.setHeader("Content-Disposition","attachment;filename=TIR"+asOfDate+".txt");
				System.out.println(is.toString());  
				int read =0;  
				   
				byte[] bytes = new byte[1024];  
				OutputStream os = response.getOutputStream();  
				   
				while((read = is.read(bytes)) != -1)  
				{  
				   
				   os.write(bytes, 0, read);  
				    
				}  
				System.out.println(read);  
				os.flush();  
				os.close();
				
				 
			}
			else{
				PrintWriter out = response.getWriter();
			    
	
				String html ="<HTML> <BODY onload=\"alert('"+message+"')\">"+
				" </body> </html>";
				out.print(html);
			}
	
		}catch(Exception e){
			 e.printStackTrace();
		}
	}else{
		PrintWriter out =null;
		try {
			out = response.getWriter();
			String html ="<HTML> <BODY onload=\"alert('"+message+"')\">"+
					" </body> </html>";
					out.print(html);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	//return new ModelAndView("repICBSGLUpload");  //point to acctgReportViewHandler and acctgREportController
	//return mav;
}

 
public Boolean generateCsvFile(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	FileWriter writer;
	String pathFile = context.getRealPath("TIR.csv");
	String reportFileName = (pathFile);
	String username = (String) a.getAttribute("userName");
	Statement stmtNotepad;
	SimpleDateFormat UDF;
	boolean valid = false;
	FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
	log.info(username);
	log.info(reportFileName);
	    
	 
	try { 
		String qry = "select  *  from Subheader " + 
					 " where b_posted = 1 and (convert(char(10),D_transactionDate,101) = convert(char(10),'" + asOfDate.toString().trim() + "',101)) ";
		log.info(qry);
		statement = new FactorConnection().getConnection().createStatement();
		resultSet =  statement.executeQuery(qry);
			
		//log.info( resultSet.getObject("counted") );
		isPosted = false;
		
		 
		if(resultSet.next()){
			isPosted = true;
			message = "Selected Date Already Posted";
		}
		
		if (isPosted == true ){valid = false;
			//alert("The record was extracted on the date queried");
			//posted
		}else{
			//not posted
			isPosted = false;
	    	String query = " Select " +
	    			" [TransactionNo] = a.N_TransactionNo,   " +
	    			" [ClientNo] = a. C_ClientCode, " +
	    			" [BranchCode] = a.c_branchCode," +
	    			" [BankNumber] = '1'," +
	    			" [LedgerCode] = 8," +
	    			" [ICBS_GL_AcctNo] = c.C_ICBSGLCode," +
	    			" [CostCenter] = b.n_costcenter," +
	    			" RecordStatus = ' ' ," +
	    			" [DateUploaded] = convert(char(10), a.D_transactionDate,101)," +
	    			" [ITC]=b.n_code," +
	    			" [DC_Code]=CASE WHEN b.n_code =  81 THEN '6' ELSE '1' END," +
	    			" [ETC]= b.n_code," +
	    			" BatchNumber= '999'," +
	    			" SeqNum = '999'," +
	    			" SerRefNum = '0'," +
	    			" TransDec1 = substring(a.c_Particular,1,30), " +
	    			" TransDec2 = substring(a.c_Particular,31,30), " +
	    			" TransDec3 = substring(a.c_Particular,61,30), " +
	    			" [TransAmt]=CASE" +
	    			" 		WHEN b.n_credit < 0 THEN abs(b.n_credit)" +
	    			" 		WHEN b.n_debit < 0 THEN abs(b.n_debit) " +
	    			"		when b.n_credit=0 then b.n_debit  " + 
					"		when b.n_credit is NULL then b.n_debit  " + 
					" ELSE b.n_credit END," +
	    			" [QTY_Items] = '0', " +
	    			" [Bundle_Proc] = '0'," +
	    			" [EntryMade] = ?, " +
	    			" [EntryApproved] = ?," +
	    			" [CurrCode] = '0'," +
	    			" [FCE] = '0'," +
	    			" [FCR]='0'," +
	    			" [RateOverride] = ' '," +
	    			" [Item_expireDate] = '0'," +
	    			" [Error_Codes] = '0'," +
	    			" [GL_BatchNo] = '0'," +
	    			" [GL_seqNo] = '0'" +
	    			" from Subheader          a" +
	    			" INNER JOIN SubLedger b" +
	    			" on a.N_transactionNo =  b.N_transactionNo" +
	    			" INNER JOIN ChartOfAccounts  c   on b.C_GLCode=c.C_ICBSGLCode" +
	    			" INNER JOIN costcenter       d   on b.N_CostCenter=d.n_code" +
	    			" WHERE" +
	    			" ISNULL(b.c_glcode,'') <> ''" +
	    			" AND ISNULL(a.b_cancelled,'') = 0" +
	    			" AND 	isnull(a.b_posted,0)=0" +
	    			" AND ((0 = 0 and convert(char(10),a.D_transactionDate,101) = convert(char(10),?,101))" +
	    			" OR (0 = 1 and convert(char(10),a.D_transactionDate,101) = convert(char(10),?,101)))" +
	    			" ORDER BY a.N_TransactionNo, b.n_credit, b.n_debit desc";
	    	
   	//order by debit first
	    	
	    	log.info(query);
	    	writer = new FileWriter(pathFile);
	    	//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
	    	//statement = connection.createStatement();
	    	connection = new FactorConnection().getConnection();
	    	statement = new FactorConnection().getConnection().createStatement();
	    	
	    	PreparedStatement ps = new FactorConnection().getConnection().prepareStatement(query);
	    	ps.setString(1, entryMade.toString());
	    	ps.setString(2,  entryApproved.toString());
	    	ps.setString(3,  asOfDate.toString());
	    	ps.setString(4,  asOfDate.toString());
	    	
	    	stmtNotepad  = connection.createStatement();
			resultSet =  ps.executeQuery();
	    	//validate if record exists in table
        	boolean isRecordEmpty = false;
        	
        	log.info(isRecordEmpty);
        	Date today = date.newDate(); //before: new Date;  //for posting TAG in Subheader
        	if (isRecordEmpty == true){   //###  beginning of statement
        		return false;
        	}else {  //else  of if statement; do the operation
        		Long GL_seqNo = new Long(10);
        		while (resultSet.next()) {
        			String TransactionNo = resultSet.getString("TransactionNo");
        			String ClientNo = resultSet.getString("clientNo");
        			String BranchCode = resultSet.getString("BranchCode");
        			String BankNumber= resultSet.getString("BankNumber");
        			String LedgerCode= resultSet.getString("LedgerCode");
        			String ICBS_GL_AcctNo= resultSet.getString("ICBS_GL_AcctNo");
        			String CostCenter= resultSet.getString("CostCenter");
        			String RecordStatus= resultSet.getString("RecordStatus");
        			String m;
        			UDF = new SimpleDateFormat ("MM/dd/yyyy");
        			Calendar c = Calendar.getInstance();
        			c.clear();
        			try {
        				c.setTime(UDF.parse(asOfDate.toString().trim()));
        			} catch (ParseException e) {
        				e.printStackTrace();
        			}
				int julianYear = c.get(Calendar.YEAR);
				int julianDay = c.get(6);
				int lenghtJulianDay = Integer.toString(julianDay).length();
				m = (lenghtJulianDay <= 2 ? ("0" + Integer.toString(julianDay)):Integer.toString(julianDay));
				String julianDate = Integer.toString(julianYear) + m;
				String DateUploaded = julianDate;
	        	String ITC= resultSet.getString("ITC");
	        	String DC_Code= resultSet.getString("DC_Code");
	        	String ETC= resultSet.getString("ETC");
	        	String BatchNumber= resultSet.getString("BatchNumber");
	        	String SeqNum= resultSet.getString("SeqNum");	
	        	String SerRefNum= resultSet.getString("SerRefNum");
	        	String TransDec1= resultSet.getString("TransDec1");
	        	String TransDec2= resultSet.getString("TransDec2");
	        	String TransDec3= resultSet.getString("TransDec3");
	        	String TransAmt= resultSet.getString("TransAmt");
	        	String QTY_Items= resultSet.getString("QTY_Items");
	        	String Bundle_Proc= resultSet.getString("Bundle_Proc");
	        	String EntryMade= resultSet.getString("EntryMade");
	        	String EntryApproved= resultSet.getString("EntryApproved"); 
	        	String CurrCode = resultSet.getString("CurrCode"); 
	        	String FCE= resultSet.getString("FCE"); 
	        	String FCR= resultSet.getString("FCR"); 
	        	String RateOverride= resultSet.getString("RateOverride"); 
	        	String Item_expireDate= resultSet.getString("Item_expireDate"); 
	        	String Error_Codes= resultSet.getString("Error_Codes"); 
	        	String GL_BatchNo= resultSet.getString("GL_BatchNo"); 
	        	//String GL_seqNo= resultSet.getString("GL_seqNo"); 
	        	
	        	//Update Subheader Posted field
	        	SimpleDateFormat ud;
	    		ud = new SimpleDateFormat("MM/dd/yyyy");
	        	String sSQLUpdate = "update Subheader " +
	        			" set b_Posted = 1, " +
	        			" d_datePosted = '" + ud.format(today)  + "', " +
	        			" c_PostedBy = '"+ username.toString().trim()  +"' " +
	        			" where N_transactionNo = '" + TransactionNo.toString().trim() + "' " +
	        			" and c_branchCode = '" + BranchCode.toString().trim() + "' " +
	        			" and c_clientCode = '" + ClientNo.toString().trim() + "'";
	        	log.info(sSQLUpdate);
	        	stmtNotepad = connection.createStatement();
	        	stmtNotepad.executeUpdate(sSQLUpdate);
	        	// write to notepad

	     
	        	
	        	
	        	writer.append(BankNumber + "," + 
	        				LedgerCode + "," + 
	        				ICBS_GL_AcctNo + "," + 
	        				CostCenter + "," + 
	        				"\"" + RecordStatus + "\"" + "," + 
	        				DateUploaded + "," + 
	        				ITC + "," +  
	        				DC_Code + "," +  
	        				ETC + "," +
	        				BatchNumber + "," + 
	        				SeqNum + "," + 
	        				SerRefNum + 
	        				",\"" + TransDec1.toString().trim() + "\"" + 
	        				",\"" + TransDec2.toString().trim()+ "\"" + 
	        				",\"" + TransDec3.toString().trim() + "\"" + "," +  
	        				TransAmt.toString() + "," + 
	        				QTY_Items + "," + 
	        				Bundle_Proc + 
	        				",\"" + EntryMade + "\",\"" +
	        				EntryApproved + "\"," + 
	        				CurrCode + "," + 
	        				FCE + "," + 
	        				FCR + ",\"" + 
	        				RateOverride + "\"" + "," + 
	        				Item_expireDate + "," + 
	        				Error_Codes + "," + 
	        				GL_BatchNo + ","  +
	        				GL_seqNo + "\r\n");
	        	
	        	  GL_seqNo += 10;
	        	
        		valid = true;
        		} //end of while
        		if(!valid){
        			message = "No Entries Found";
        		}
        	}//END OF FILE GENERATION
	          writer.flush();
			  writer.close();
			  stmtNotepad.close();
			  connection.close();
			  
		} // End of if Statement   #########	END OF NOT POSTED   
	} catch (SQLException e ) {
		message = "Extraction Error";
		e.printStackTrace();
		valid = false;     
	} finally{
		
	} 
	return valid;
}

//ADJUSTMENT MODULE  #############################
public ModelAndView adjustmentReportViewHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	String view = request.getParameter("view").trim();
	ModelAndView mav = new ModelAndView();
	String sessionID = (String) request.getSession().getId();
	if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return new ModelAndView("repAdjustment"); //Return to repAdjustment.jsp
}

public ModelAndView accountingAdjustmentReportHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	try{ 		
		mav.addObject("jasper", "repAdjustment");
		mav.setViewName("swf");
		adjustmentReport(request,response); 	}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}
	catch(Exception e){ 
		mav.setViewName("../error/error");
		mav.addObject("message", "Server Exception Occured");
	}
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;
}

public void adjustmentReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException, FactorsFormatException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	try 	{
		String startDate = request.getParameter("startDate");
		if(startDate==null||startDate.isEmpty()||validator.isValidDateFormat(startDate)){
			throw new FactorsFormatException("Invalid Start Date Format");
		}
		String endDate = request.getParameter("endDate");
		if(endDate==null||endDate.isEmpty()||validator.isValidDateFormat(endDate)){
			throw new FactorsFormatException("Invalid End Date Format");
		}
		String branchCode= a.getAttribute("branchCode")!=null?a.getAttribute("branchCode").toString():"";
		if(branchCode==null||branchCode.isEmpty()||validator.validBranchCode(branchCode)){
			throw new FactorsFormatException("Invalid Branch Code");
		}
		log.info(branchCode);
		
		String reportFileName =context.getRealPath("/report/repAdjustment.jasper");
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		//**
		String sSQL = " select C_GLCode, C_AccountName,C_Type, "
				+ "currentDate = (select currentdate from factorsGetDate)," +
					" isnull(n_debit,0.00) as n_debit, " +
					" isnull(n_credit,0.00) as n_credit,  " +
					" totalAmount from " +
					" (Select  " +
					" 	C_GLCode,C_AccountName,C_Type, " +
					" 	case when totalAmount > 0.00 then abs(totalAmount) end as n_debit, " +
					" 	case when totalAmount < 0.00 then abs(totalAmount) end as n_credit, " +
					" 	totalAmount " +
					" 	From " +
					" 	(SELECT  " +  
					" 			s1.C_GLCode, " +
					" 			sh.C_Type, " +
					" 			s1.C_AccountName, " +
					" 			sum(isnull(n_debit,0.00))-sum(isnull(n_credit,0.00)) as totalAmount, " +
					" 			SUM(ISNULL(s1.N_Debit, 0)) AS n_debit,  " +
					" 			SUM(ISNULL(s1.N_Credit, 0)) AS n_credit " +
					" 			FROM  SubLedger s1 INNER JOIN SubHeader sh ON s1.N_TransactionNo = sh.N_TransactionNo " +
					" 			WHERE  (CONVERT(datetime, s1.D_TransactionDate) >= '" + startDate.toString().trim() + "' and  convert(datetime,s1.d_transactionDate) <= '" + endDate.toString().trim() + "') AND " + 
					" 				(sh.C_Type = 'A') AND (sh.B_Cancelled = 0 OR " +
					" 						sh.B_Cancelled IS NULL) AND (sh.C_BranchCode = '01') " +
					" 			GROUP BY s1.C_GLCode,sh.C_Type ,s1.C_AccountName " +
					" 			)a group by C_GLCode,C_AccountName,c_type,totalAmount " + 
					" 			)b  " +
					" 			where totalAmount != 0.00 order by n_debit desc ";
		
		
		log.info(sSQL);
		
		//setting up additional field in report
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("startDate", startDate);
		parameterMap.put("endDate", endDate);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		
		log.info(parameterMap);
			
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		log.info(sSQL);
		resultSet =  statement.executeQuery(sSQL);
		log.info("Filling the report");
		
			InputStream reportStream = context.getResourceAsStream("/report/repAdjustment.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	} 	catch (JRException e) 	{
		e.printStackTrace(); 	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	}

// PENALTY CHARGES #############################
public ModelAndView penaltyChargesReportViewHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	String view = request.getParameter("view").trim();
	ModelAndView mav = new ModelAndView();
	String sessionID = (String) request.getSession().getId();
	if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return new ModelAndView("repPenaltyCharges"); //Return to dailyBal.jsp
}

//Viewing Report submit button from 

public ModelAndView accountingGetPenaltyChargesReportHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	//String sessionID = (String) request.getSession().getId();
	try{ 	
		mav.addObject("jasper", "repPenaltyCharges");
		mav.setViewName("swf");
		penaltyChargesReport(request,response); 	}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}
	catch(Exception e){ 
		mav.setViewName("../error/error");
		mav.addObject("message", "Server Exception Occured");
	}
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;
}

public void penaltyChargesReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException,FactorsFormatException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	try 	{
		String reportFileName =context.getRealPath("/report/repPenaltyCharges.jasper");
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		String branchCode= a.getAttribute("branchCode").toString().trim(); 
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		
		String clientCode = (String) request.getParameter("C_CLNTCODE");
		
		String startDate = (String) request.getParameter("startDate");
		if(startDate==null||startDate.isEmpty()||!validator.isValidDateFormat(startDate)){
			throw new FactorsFormatException("Invalid Start Date");
		}
		
		String endDate = (String) request.getParameter("endDate");
		if(endDate==null||endDate.isEmpty()||!validator.isValidDateFormat(endDate)){
			throw new FactorsFormatException("Invalid Start Date");
		}
		
		boolean boxSelection = Boolean.parseBoolean(request.getParameter("boxSelection"));
		
		log.info(clientCode);
		String sSQL ="";
		String sSQLQuery = "";
		
		log.info(boxSelection);	 
		if(boxSelection == true ){sSQL = "" ;}
		else{
			if(clientCode==null||clientCode.isEmpty()||!validator.validClientCode(clientCode)){}
			sSQLQuery =  " AND penaltyDetail.clientCode = " +   clientCode.trim() + " order by c_type";
			log.info(sSQLQuery);
		}
 
	
		  sSQL = " SELECT "
		 		+ "currentDate = (select currentdate from factorsGetDate)," +     
	" penaltyDetail.clientName, " + 
	" penaltyDetail.clientCode,  " +
	" penaltyDetail.branchCode,  " +
	" CONVERT(datetime, penaltyDetail.invoiceDate) AS invoiceDate, " +   
	" CONVERT(datetime, penaltyDetail.d_TransactionDate) AS d_TransactionDate, " + 
	" DATEDIFF(day, CONVERT(datetime, penaltyDetail.invoiceDate), " +
	" CONVERT(datetime, penaltyDetail.d_TransactionDate)) AS invoiceAge,  " + 
	" penaltyDetail.penaltyRate / 100 * 100 AS penaltyRate, " + 
	" penaltyDetail.N_Refno,  penaltyDetail.N_PenaltyCharge, " + 
	" penaltyDetail.C_Type, penaltyDetail.N_AdvanceRefundNo,  " +
	" penaltyDetail.N_InvNo, " +   
	" penaltyDetail.delinquentInvoiceAmount, " + 
	" penaltyDetail.dunningDays, " + 
	" prePaymentRatio = penaltyDetail.prePaymentRatio, " + 
	" penaltyDetail.N_DelinquentDays, " +  
	" penaltyDetail.C_PenaltyType, " + 
	" Invoice_1.C_INVOICENO " +  
	" ,penaltyDetail.D_FromDate " +  
	" ,penaltyDetail.D_ToDate " +
	" FROM         (SELECT     (SELECT     C_NAME FROM         dbCIF.dbo.Client AS cl " + 
	" WHERE     (C_BRANCHCODE =(SELECT     C_BRANCHCODE  FROM Invoice AS inv " + 
	" WHERE      (N_INVNO = pD.N_InvNo))) AND (C_CLNTCODE = (SELECT     C_CLNTCODE  FROM Invoice AS inv " +  
			" WHERE      (N_INVNO = pD.N_InvNo)))) AS clientName,     (SELECT     C_CLNTCODE FROM dbCIF.dbo.Client AS cl " + 
			" WHERE      (C_BRANCHCODE = (SELECT     C_BRANCHCODE FROM Invoice AS inv " + 
			" WHERE      (N_INVNO = pD.N_InvNo))) AND (C_CLNTCODE =     (SELECT     C_CLNTCODE      FROM Invoice AS inv " +     
			" WHERE      (N_INVNO = pD.N_InvNo)))) AS clientCode,     (SELECT     C_BRANCHCODE FROM dbCIF.dbo.Client AS cl " + 
			" WHERE      (C_BRANCHCODE =   (SELECT     C_BRANCHCODE     FROM Invoice AS inv " +     
			" WHERE      (N_INVNO = pD.N_InvNo))) AND (C_CLNTCODE =   (SELECT     C_CLNTCODE     FROM Invoice AS inv " +     
			" WHERE      (N_INVNO = pD.N_InvNo)))) AS branchCode,     (SELECT     D_INVOICEDATE FROM Invoice AS invoice " + 
			" WHERE      (N_INVNO = pD.N_InvNo) AND (C_BRANCHCODE =   (SELECT     C_BRANCHCODE     FROM dbCIF.dbo.Client AS cl " +     
			" WHERE      (C_BRANCHCODE =     (SELECT     C_BRANCHCODE       FROM Invoice AS inv       WHERE      (N_INVNO = pD.N_InvNo))) AND (C_CLNTCODE =     (SELECT     C_CLNTCODE       FROM Invoice AS inv " +       
			" WHERE      (N_INVNO = pD.N_InvNo))))) AND (C_CLNTCODE =   (SELECT     C_CLNTCODE     FROM dbCIF.dbo.Client AS cl " +     
			" WHERE      (C_BRANCHCODE =     (SELECT     C_BRANCHCODE       FROM Invoice AS inv " +       
			" WHERE      (N_INVNO = pD.N_InvNo))) AND (C_CLNTCODE =     (SELECT     C_CLNTCODE       FROM Invoice AS inv " +       
			" WHERE      (N_INVNO = pD.N_InvNo)))))) AS invoiceDate, "
			+ " CONVERT(datetime,          CASE WHEN pD.C_Type = 'A' THEN     (SELECT     CONVERT(varchar, adv.D_TRANSACTIONDATE) FROM advances adv  WHERE      adv.n_refNo = pd.n_advanceRefundNo AND adv.c_branchcode =   (SELECT     adv.c_branchCode FROM advances adv  WHERE      adv.n_refno = pd.n_advanceRefundNo) AND adv.c_clntcode =   (SELECT     adv.c_clntCode FROM advances adv  WHERE      adv.n_refno = pd.n_advanceRefundNo))	"+ 
			"WHEN pD.C_Type ='R' THEN (SELECT     CONVERT(varchar, ref.D_TRANSACTIONDATE) FROM refund ref  WHERE      ref.n_refNo = pd.n_advanceRefundNo AND ref.c_branchcode =   (SELECT     ref.c_branchCode     FROM refund ref  WHERE      ref.n_refno = pd.n_advanceRefundNo) AND ref.c_clntcode =   (SELECT     ref.c_clntCode     FROM refund ref  WHERE      ref.n_refno = pd.n_advanceRefundNo))	"+
			"ELSE (SELECT     CONVERT(varchar, rh.D_TRANSACTIONDATE) FROM ReceiptsHdr rh WHERE     rh.n_refNo = pd.n_advanceRefundNo AND rh.c_branchcode =   (SELECT     rh.c_branchCode     FROM ReceiptsHdr rh  WHERE      rh.n_refno = pd.n_advanceRefundNo) AND rh.c_clntcode =   (SELECT     rh.c_clntCode     FROM ReceiptsHdr rh  WHERE      rh.n_refno = pd.n_advanceRefundNo)) END) AS d_TransactionDate	"+
			",     (SELECT DISTINCT N_PenaltyCharge       FROM TransactionRates AS tR " +       
			" WHERE      (N_RefNo = pD.N_AdvanceRefundNo) AND (C_Type = pD.C_Type)) AS penaltyRate, " + 
			" N_Refno, " + 
			" CONVERT(money,          N_PenaltyCharge) AS N_PenaltyCharge, " + 
			" (CASE WHEN pD.C_Type = 'A' THEN 'Advances' WHEN pD.C_Type = 'R' THEN 'Refund'  WHEN pD.C_Type = 'P' THEN 'Receipts' ELSE '' END)           AS C_Type, " + 
			" N_AdvanceRefundNo, " + 
			" N_InvNo, " + 
			" CONVERT(money, delinquentInvoiceAmount) AS delinquentInvoiceAmount, " + 
			" dunningDays, " +           
			" prePaymentRatio, " + 
			" N_DelinquentDays, " + 
			" C_PenaltyType " +
			" ,D_FromDate " +
			" ,D_ToDate " +
			" FROM PenaltyDetail AS pD) AS penaltyDetail " + 
			" INNER JOIN    Invoice AS Invoice_1 ON penaltyDetail.branchCode = Invoice_1.C_BRANCHCODE AND penaltyDetail.clientCode = Invoice_1.C_CLNTCODE AND    penaltyDetail.N_InvNo = Invoice_1.N_INVNO " +
			"  WHERE (penaltyDetail.d_TransactionDate  between '" + startDate.toString().trim() + 
			"' and '" + endDate.toString().trim() + "')  and branchCode = '" + branchCode.toString().trim() + "' " + sSQLQuery ;
		
		 
		 //abang:  String sSQL = "exec sp_GET_PenaltyDetail '" + clientCode.trim()  + "','" + branchCode.toString().trim()  + "','" + startDate.toString().trim() + "','" + endDate.toString().trim() + "'";
		log.info(sSQL);
		log.info(boxSelection);
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("startDate", startDate);
		parameterMap.put("endDate", endDate);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		parameterMap.put("title","Penalty Charge Report");
		log.info(parameterMap);
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		resultSet =  statement.executeQuery(sSQL);
		//ServletOutputStream servletOutputStream =  response.getOutputStream();
		  InputStream reportStream = context.getResourceAsStream("/report/repPenaltyCharges.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	}
	catch (JRException e) 	{ 		e.printStackTrace(); 	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	}

//ADJUSTMENT REPORT PER DETAIL------------------------------
public ModelAndView accountingGetAdjustmentPerDetailInInterfaceHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	try{ 		
		log.info("passing through accountingGetAdjustmentPerDetailInInterfaceHandler");
		mav.addObject("jasper", "repAdjustmentEntries");
		mav.setViewName("swf");
		adjustmentPerDetailInInterfaceReport(request,response); 	
		}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}
	catch(Exception e){
		mav.setViewName("../error/error");
		mav.addObject("message", "Server Exception Occured");
	}
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController ///accountingGetAdjustmentPerDetailInINterfaceReport.BDOFactor
	//Green
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;
}

public void adjustmentPerDetailInInterfaceReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException, FactorsFormatException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	try 	{ 
		String transactionNo = request.getParameter("transactionNo");
		if (transactionNo==null||transactionNo.isEmpty()||!validator.validClientCode(transactionNo)){
			throw new FactorsFormatException("Invalid Transaction Number");
		}
		String transactionDate = request.getParameter("transactionDate");
		String strparticular= (String)request.getParameter("particular");
		 
		log.info(transactionNo);
		//log.info(DateFormat.getInstance().format(transactionDate.trim()));
		log.info(strparticular);
		
		String reportFileName =context.getRealPath("/report/repAdjustmentEntries.jasper");
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		//**
		String sSQL = "  SELECT "
				+ "currentDate = (select currentdate from factorsGetDate)," +
				"	c_glcode " +
				"	,c_accountname " +
				"	,n_debit = ISNULL(N_DEBIT,0) " +
				"	,n_credit = ISNULL(N_CREDIT,0) " +
				"	,n_costcenter " +
				"	,currentDate = (select currentdate from factorsGetDate)" +
				" FROM subledger " +
				" WHERE N_TRANSACTIONNO='" + transactionNo.toString().trim() + "' " +
				" ORDER BY N_CREDIT,N_DEBIT ";
		
		log.info(sSQL);
		//setting up additional field in report
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("transactionNo", transactionNo);
		parameterMap.put("transactionDate", transactionDate);
		parameterMap.put("strParticular", strparticular);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		
		log.info(parameterMap);
			
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		log.info(sSQL);
		resultSet =  statement.executeQuery(sSQL);
		log.info("Filling the report");
		
		  InputStream reportStream = context.getResourceAsStream("/report/repAdjustmentEntries.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	} 	catch (JRException e) 	{
		e.printStackTrace(); 	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	}

//DISBURSEMENT REPORT PER DETAIL------------------------------

public ModelAndView accountingGetDisbursementPerDetailInInterfaceHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	try{ 		
		
		mav.addObject("jasper", "repDisbursementEntries");
		mav.setViewName("swf");
		disbursementPerDetailInInterfaceReport(request,response); 	
		}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}
	catch(Exception e){
		mav.setViewName("../error/error");
		mav.addObject("message", "Server Exception Occured");
	}
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;
}

public void disbursementPerDetailInInterfaceReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException,FactorsFormatException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	String sSQL = ""; 
	try 	{ 
		String transactionNo = request.getParameter("transactionNo");
		if (transactionNo==null||transactionNo.isEmpty()||!validator.validClientCode(transactionNo)){
			throw new FactorsFormatException("Invalid Transaction Number");
		}
		String transactionDate = request.getParameter("transactionDate");
		String strparticular= (String)request.getParameter("particular");
		String transactiontab = request.getParameter("transactiontab");
		
		log.info(transactionNo);
		log.info(transactiontab);
	
		//log.info(DateFormat.getInstance().format(transactionDate.trim()));
	
		String reportFileName =context.getRealPath("/report/repDisbursementEntries.jasper");
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		
		
		
		//setting up additional field in report
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		
		String titleReport="";
		if (transactiontab.contentEquals("R")){
			titleReport = "Disbursement Refund Entries Report";
			sSQL = " SELECT " + 	
			" sl.c_glcode "
			+ ",currentDate = (select currentdate from factorsGetDate)" + 	
			" ,sl.c_accountname " + 	
			" ,ISNULL(sl.N_DEBIT,0) AS n_debit " +	
			" ,ISNULL(sl.N_CREDIT,0) AS n_credit " +
			" ,sl.n_costcenter " +  
			" ,c_maker = isnull((select ut.c_username from usertable ut where ut.c_userid =ad.c_maker),'') " + 
			" ,c_approver = isnull((select ut.c_username from usertable ut where ut.c_userid = ad.c_approver) ,'') " +
			" FROM subledger sl " + 
			" inner join  subheader sh " + 
			" on sl.n_transactionNo = sh.n_transactionNo " + 
			" inner join refund ad " +
			" on ad.n_refno = sh.n_referenceNo " +
			" where ad.n_refno = sh.n_referenceNo and ad.c_clntcode =sh.c_clientCode and ad.c_branchcode = sh.c_branchcode and sh.n_transactionNo =sl.n_transactionNo " +
			" and sl.N_TRANSACTIONNO='" + transactionNo.toString().trim() + "' ORDER BY sl.N_CREDIT,sl.N_DEBIT";

		}
		else if (transactiontab.contentEquals("A")){
			titleReport = "Disbursement Advance Entries Report";
			sSQL = " SELECT " + 	
			" sl.c_glcode " + 
			" ,currentDate = (select currentdate from factorsGetDate)" + 			
			" ,sl.c_accountname " + 	
			" ,ISNULL(sl.N_DEBIT,0) AS n_debit " +	
			" ,ISNULL(sl.N_CREDIT,0) AS n_credit " +
			" ,sl.n_costcenter " +  
			" ,c_maker = isnull((select ut.c_username from usertable ut where ut.c_userid =ad.c_maker),'') " + 
			" ,c_approver = isnull((select ut.c_username from usertable ut where ut.c_userid = ad.c_approver) ,'') " +
			" FROM subledger sl " + 
			" inner join  subheader sh " + 
			" on sl.n_transactionNo = sh.n_transactionNo " + 
			" inner join advances ad " +
			" on ad.n_refno = sh.n_referenceNo " +
			" where ad.n_refno = sh.n_referenceNo and ad.c_clntcode =sh.c_clientCode and ad.c_branchcode = sh.c_branchcode and sh.n_transactionNo =sl.n_transactionNo " +
			" and sl.N_TRANSACTIONNO='" + transactionNo.toString().trim() + "' ORDER BY sl.N_CREDIT,sl.N_DEBIT";

		}
		else 
			throw new FactorsFormatException("Invalid Report Parameter");
		log.info(sSQL);
		
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("transactionNo", transactionNo);
		parameterMap.put("transactionDate", transactionDate);
		parameterMap.put("strParticular", strparticular);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		parameterMap.put("titleReport", titleReport);
		
		log.info(parameterMap);
			
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		log.info(sSQL);
		resultSet =  statement.executeQuery(sSQL);
		log.info("Filling the report");
		
		  InputStream reportStream = context.getResourceAsStream("/report/repDisbursementEntries.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	} 	catch (JRException e) 	{
		e.printStackTrace(); 	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	}

//PAYMENT REPORT PER DETAIL------------------------------

public ModelAndView accountingGetPaymentPerDetailInInterfaceHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{

	ModelAndView mav = new ModelAndView();
	try{ 		
		
		mav.addObject("jasper", "repPaymentEntries");
		mav.setViewName("swf");
		paymentPerDetailInInterfaceReport(request,response); 	
		}
	catch(FactorsFormatException ffe){
		mav.setViewName("../error/error");
		mav.addObject("message", "Invalid Request Parameter Detected");
	}
	catch(Exception e){ 
		mav.setViewName("../error/error");
		mav.addObject("message", "Server Exception Occured");
	}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
	return mav;
}

public void paymentPerDetailInInterfaceReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException, FactorsFormatException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	try 	{ 
		String transactionNo = (String) request.getParameter("transactionNo").trim();
		if (transactionNo==null||transactionNo.isEmpty()||!validator.validClientCode(transactionNo)){
			throw new FactorsFormatException("Invalid Transaction Number");
		}
		
		String transactionDate =   request.getParameter("transactionDate");
		String strparticular= (String)request.getParameter("particular");
		
		 
		log.info(transactionNo);
	
		//log.info(DateFormat.getInstance().format(transactionDate.trim()));
		
		
		String reportFileName =context.getRealPath("/report/repPaymentEntries.jasper");
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		
		String sSQL = "SELECT "
		+ "currentDate = (select currentdate from factorsGetDate)" + 	
		" ,sl.c_glcode " + 	 
		" ,sl.c_accountname " +
		" ,ISNULL(sl.N_DEBIT,0) AS n_debit " +	
		" ,ISNULL(sl.N_CREDIT,0) AS n_credit " +	
		" ,sl.n_costcenter " +  
		" ,c_maker = (select ut.c_username from usertable ut where ut.c_userid =rh.c_maker) " + 
		" ,c_approver = (select ut.c_username from usertable ut where ut.c_userid = rh.c_approver) " + 
		" FROM subledger sl " + 
		" inner join  subheader sh " + 
		" on sl.n_transactionNo = sh.n_transactionNo " + 
		" inner join receiptshdr rh " +
		" on rh.n_refno = sh.n_referenceNo " +
		" where rh.n_refno = sh.n_referenceNo and rh.c_clntcode =sh.c_clientCode and rh.c_branchcode = sh.c_branchcode and sh.n_transactionNo =sl.n_transactionNo " +
		" and sl.N_TRANSACTIONNO='" + transactionNo.toString().trim() + "' ORDER BY sl.N_CREDIT,sl.N_DEBIT"; 
		
		log.info(sSQL);
		
		//setting up additional field in report
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("transactionNo", transactionNo);
		
		parameterMap.put("transactionDate", transactionDate);
		
		parameterMap.put("strParticular", strparticular);
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		
		log.info(parameterMap);
			
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		log.info(sSQL);
		resultSet =  statement.executeQuery(sSQL);
		log.info("Filling the report");
		
		  InputStream reportStream = context.getResourceAsStream("/report/repPaymentEntries.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	} 	catch (JRException e) 	{
		e.printStackTrace(); 	}
	}

//FAMS CHART OF ACCOUNTS------------------------------

public ModelAndView famsChartOfAccountsHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	ModelAndView mav = new ModelAndView();
	try{ 		
		
		mav.addObject("jasper", "repFAMSChartOfAccounts");
		mav.setViewName("swf");
		famsChartOfAccountsReport(request,response); 	
		}
	catch(Exception e){ 	}
	//return new ModelAndView("swf");  //point to acctgReportViewHandler and acctgREportController
	
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return mav;
}

public void famsChartOfAccountsReport(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, JRException, SQLException{
	HttpSession a = request.getSession(true);
	ServletContext context = a.getServletContext();
	try 	{ 
		
		String reportFileName =context.getRealPath("/report/repFAMSChartOfAccounts.jasper");
		File reportFile = new File(reportFileName);
		if (!reportFile.exists())
			throw new JRRuntimeException("report not found");
		//**
			String sSQL = " SELECT "
					+ "	currentDate = (select currentdate from factorsGetDate), "
					+ "   (SELECT     C_Description " + 
                      " FROM          AcctTypeCode AS aTC " + 
                      " WHERE      (N_Code = SUBSTRING(cOA.C_ICBSGLCode, 1, 1))) AS AccountGroup, C_ICBSGLCode, C_AccountName, C_Description, N_CostCenter, " + 
                      " C_BranchCode, C_NBalance " + 
                      " FROM         ChartOfAccounts AS cOA " + 
                      " ORDER BY AccountGroup,C_ICBSGLCode asc ";
		log.info(sSQL);
		
		//setting up additional field in report
		String username = (String) a.getAttribute("userName");
		String branchname = (String) a.getAttribute("branchName");
		String systemname = (String) a.getAttribute("systemName");
		
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("userName", username);
		parameterMap.put("branchName", branchname);
		parameterMap.put("systemName", systemname);
		
		log.info(parameterMap);
			
		//connection = DriverManager.getConnection("jdbc:jtds:sqlserver://bdowldb03:1433/dbFACTORS","sa","password");
		//statement = connection.createStatement();
		statement = new FactorConnection().getConnection().createStatement();
		log.info(sSQL);
		resultSet =  statement.executeQuery(sSQL);
		log.info("Filling the report");
		
		  InputStream reportStream = context.getResourceAsStream("/report/repFAMSChartOfAccounts.jasper");
	      JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(resultSet);
	      JasperPrint ds = JasperFillManager.fillReport(reportStream, parameterMap, resultSetDataSource);
	      a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, ds );
	      statement.close();
		  connection.close();
	} 	catch (JRException e) 	{
		e.printStackTrace(); 	}
	}


public ModelAndView factorsSettingHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	String view = request.getParameter("view").trim();
	ModelAndView mav = new ModelAndView();
	String sessionID = (String) request.getSession().getId();
	if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
	//added by Cherrie Garcia as of 2-10-15
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	return new ModelAndView("systemSettings");  
}




// debugging or testing page
public ModelAndView debuggingOrTestingHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	String view = request.getParameter("view").trim();
	ModelAndView mav = new ModelAndView();
	String sessionID = (String) request.getSession().getId();
	if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
	return new ModelAndView("zz_debuggingPage");  //point to acctgReportViewHandler and a
	}

private boolean isSessionActive(HttpServletRequest request) {
	String userName = null;
	HttpSession session=request.getSession(true);
	
	userName=(String) session.getAttribute("userName");
	if (userName != null) {
		return true;
	}
	
	return false;		
}

}
