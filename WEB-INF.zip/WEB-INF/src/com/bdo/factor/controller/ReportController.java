package com.bdo.factor.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JExcelApiExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporterParameter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.j2ee.servlets.BaseHttpServlet;
import net.sf.jasperreports.j2ee.servlets.ImageServlet;

import com.bdo.factor.dataSource.*;

import org.apache.commons.httpclient.util.DateParseException;
import org.apache.commons.httpclient.util.DateUtil;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.ReportField;
import com.bdo.factor.dao.AdvancesDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.ReceiptsHeaderDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.RefundDAO;
import com.bdo.factor.dataSource.*;
import com.bdo.factor.exception.FactorsFormatException;
import com.bdo.factor.service.ActivityLogService;
import com.bdo.factor.service.AdvancesService;
import com.bdo.factor.service.SecurityService;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.DateUtils;
import com.bdo.factor.util.FactorConnection;
import com.bdo.factor.util.LoaderHandler;
import com.bdo.factor.util.Money;
import com.bdo.factor.util.Validator;
import com.bdo.factor.controller.LogOnFormController;
import com.bdo.factor.service.NewReportService;

public class ReportController extends MultiActionController{	
	private static Logger log = Logger.getLogger(ReportController.class);
	private static LogOnFormController logOnForm = new LogOnFormController();
	
	DecimalFormat df = new DecimalFormat("###,###,###,###,###,##0.00");
	
/***********************************************************************************************************************************/
/***********************************************************************************************************************************/
	
	public ModelAndView reportViewHandler(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException
	{
		ModelAndView mav = new ModelAndView();
		Map map = new HashMap();
		mav.addObject( "X-FRAME-OPTIONS", "SAMEORIGIN" );
	//
		
		if (request.getParameter("view")==null){
			mav.addObject("message", "Invalid Request");
			mav.setViewName("../error/error");
			return mav;
		}
		String view = request.getParameter("view").trim();
		
		if(view.equalsIgnoreCase("schedAdvances")){
			mav.setViewName("reportAdvance");
		}
		if(view.equalsIgnoreCase("schedAdvances")){
			mav.setViewName("reportAdvance");
		}
		else if(view.equalsIgnoreCase("reportSummaryDC")){
			mav.setViewName("reportSummaryOfDC");
		}
		else if(view.equalsIgnoreCase("refundByClient")){
			mav.setViewName("reportRefundClient");
		}	
		else if(view.equalsIgnoreCase("clientAvail")){
			mav.setViewName("reportClientAvailability");
		}
		else if (view.equals("dishonoredEditList") || view.equals("pdcduefordep") || view.equalsIgnoreCase("reportAudit") 
					//|| view.equalsIgnoreCase("verifyInvoice") || view.equalsIgnoreCase("dueInvoice")
					|| view.equalsIgnoreCase("verifyInvoice") 
					|| view.equalsIgnoreCase("cancelledInvoice")|| view.equalsIgnoreCase("prepaymentAdvice")
					|| view.equalsIgnoreCase("transactionCtrlTotals") || view.equalsIgnoreCase("accountsForReview")
					|| view.equalsIgnoreCase("shedOfInvWithPartial")//add new report 09102010-rod
					|| view.equalsIgnoreCase("AdvRefTransaction")) 
		{
			mav.setViewName("repWithDateRange");
		}
		else if(view.equalsIgnoreCase("debtorsPaymentReport") || view.equalsIgnoreCase("schedOfCreditNote") || view.equalsIgnoreCase("schedOfCanceledCreditNote") 
				|| view.equalsIgnoreCase("pdcRegistry") || view.equalsIgnoreCase("partialPayment") || view.equals("dailyRecEdtLst")||view.equalsIgnoreCase("actualDunningReport")){
			mav.setViewName("repWithDateRangeAndClient");
		}
		else if (view.equalsIgnoreCase("customerStmtOfAcct"))
		{
			mav.setViewName("repWithClientCustAndAsOfDate");
		}
		else if ( view.equalsIgnoreCase("monthlyCharges") || view.equalsIgnoreCase("exposureByIndustry") || view.equalsIgnoreCase("weeklyBooking") ||  view.equalsIgnoreCase("weeklyBookingSummary"))
		{
			mav.setViewName("repWithMonthPicker");
		}
		else if (view.equalsIgnoreCase("ccAgingAnalysisList")||view.equalsIgnoreCase("ccAgingByDunningList")||view.equalsIgnoreCase("clientActivityList") 
				 ||view.equalsIgnoreCase("clientSalesAnalysisList") || view.equalsIgnoreCase("clientStatisticsRevReport"))
		{
			if(view.equalsIgnoreCase("ccAgingAnalysisList"))mav.addObject("tblHeader","Customer Ageing Analysis");
			else if(view.equalsIgnoreCase("ccAgingByDunningList"))mav.addObject("tblHeader","Customer Ageing Analysis By Dunning Days");
			else if(view.equalsIgnoreCase("clientActivityList"))mav.addObject("tblHeader","Client Statement of Account");
			else if(view.equalsIgnoreCase("clientSalesAnalysisList"))mav.addObject("tblHeader","Client Sales Analysis");
			else if(view.equalsIgnoreCase("clientStatisticsRevReport"))mav.addObject("tblHeader", "Client Statistics Review Report");
			//view for report that accept client and as of date
			mav.setViewName("reportClientAsOfDate");
		}
		else if ( view.equalsIgnoreCase("clientDebtTurnReport")){
			mav.setViewName("repWithClientandCustomerCode");
		}
		else if(view.equalsIgnoreCase("receiptsDueRefund")){
			mav.setViewName("reportDateRangeReceiptStatus");
		}	
		else if(view.equalsIgnoreCase("ageingSummaryByClient") ||view.equalsIgnoreCase("ageingClientByDunning") 
				|| view.equalsIgnoreCase("PDOInvoices") || view.equalsIgnoreCase("factoringManagement") || view.equalsIgnoreCase("yearToEndEarningReport")
				|| view.equalsIgnoreCase("dueInvoice") || view.equalsIgnoreCase("clientAdjustments")
				|| view.equalsIgnoreCase("FactoredReceivableCredex")||view.equalsIgnoreCase("FactoredReceivable")
				|| view.equalsIgnoreCase("rptClassification")){ //CVG082917
					if(view.equalsIgnoreCase("ageingSummaryByClient"))mav.addObject("tblHeader","AGEING SUMMARY BY CLIENT");
					else if(view.equalsIgnoreCase("ageingClientByDunning"))mav.addObject("tblHeader","AGEING SUMMARY BY CLIENT BASED ON DUNNING PERIOD");
					else if (view.equalsIgnoreCase("PDOInvoices")){mav.addObject("tblHeader", "PDO INVOICES");
					mav.addObject("PDO", true);}
					else if (view.equalsIgnoreCase("factoringManagement"))mav.addObject("tblHeader", "FACTORING MANAGEMENT");						
					else if (view.equalsIgnoreCase("yearToEndEarningReport"))mav.addObject("tblHeader", "YEAR TO END EARNINGS REPORT");
					else if(view.equalsIgnoreCase("dueInvoice"))mav.addObject("tblHeader","INVOICES DUE FOR COLLECTION");
					else if(view.equalsIgnoreCase("clientAdjustments"))mav.addObject("tblHeader","SCHEDULE OF ADJUSTMENTS");
					else if(view.equalsIgnoreCase("FactoredReceivableCredex")){
							mav.addObject("tblHeader","FACTORED RECEIVABLES - CREDEX");
							mav.addObject("CREDEX", true);
					}
					else if(view.equalsIgnoreCase("FactoredReceivable"))mav.addObject("tblHeader","FACTORS RECEIVABLE");
					else if(view.equalsIgnoreCase("rptClassification")){
						mav.addObject("tblHeader","RPT CLASSIFICATION REPORT");
						mav.addObject("RPTReport",true);
					} //CVG082917
			mav.setViewName("reportAsOfDate");
		}		
		else if (view.equalsIgnoreCase("discountChargeOnCashDelay")){
			mav.setViewName("repWithDateRange");
		}
		else if (view.equalsIgnoreCase("factorStatisticsReport")){
			if (view.equalsIgnoreCase("factorStatisticsReport"))mav.addObject("tblHeader","FACTORING STATISTICS REPORT");
			mav.setViewName("repWithClientAndMonthPicker");
		}
		else if(view.equalsIgnoreCase("customerConcentration")){
			if (view.equalsIgnoreCase("customerConcentration"))mav.addObject("tblHeader", "CUSTOMER CONCENTRATION REPORT");
			mav.setViewName("reportCustomerAsOfDate");
		}
		/*else if(view.equalsIgnoreCase("clientActiveListing") 
				|| view.equalsIgnoreCase("clientConcentrationRep")
				|| view.equalsIgnoreCase("customerListing")
				|| view.equalsIgnoreCase("clientCustomerListing") || view.equalsIgnoreCase("classRefReport"))
		{
			mav.setViewName("pop");
		}*/
		else if (view.equalsIgnoreCase("weeklyBooking")){
			mav.setViewName("weeklyBooking");
		}
		else if (view.equalsIgnoreCase("weeklyBookingSummary")){
			mav.setViewName("weeklyBookingSummary");
		}
		else if (view.equalsIgnoreCase("advices")){
			mav.addObject("tblHeader","SUMMARY OF ADVICES");
			mav.setViewName("reportOptionDateRange");
		}		
		else if (view.equalsIgnoreCase("popReport")){
			mav.setViewName("popReport");
		}		
		else if (view.equalsIgnoreCase("scheduleOfInvoiceEditList")){//RLS 01/06/2011 Add sched of invoice in report client as of date report
			if(view.equalsIgnoreCase("scheduleOfInvoiceEditList"))mav.addObject("tblHeader","SCHEDULE OF INVOICES"); 
			//view for report that accept client with option all client and as of date
			mav.setViewName("reportClientAllAsOfDate");
		}	
		else if (view.equalsIgnoreCase("activityLogReport")){ //RLS 01/21/2011 Add activity log
			if(view.equalsIgnoreCase("activityLogReport"))mav.addObject("tblHeader","ACTIVITY LOG REPORT"); 
			//view for report that accept client with option all client and as of date
			mav.setViewName("reportDateRangeFilterOption");
		}
		//BankCERT and FullyPaidInv CVG 05292017
		else if (view.equalsIgnoreCase("repBankCertification")){
			mav.setViewName("reportBankCertification");
		}	
		else if (view.equalsIgnoreCase("repFullyPaidInvoice")){
			mav.setViewName("reportFullyPaidInvoice");
		}	
		mav.addObject("operation",view);		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!logOnForm.isSecured(view,sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		//added by Cherrie Garcia as of 2-10-15
				response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		return mav;	
	}	
	
/***********************************************************************************************************************************/
/**
 * @throws JRException 
 * @throws IOException *********************************************************************************************************************************/

	
	@SuppressWarnings("unchecked")
	public ModelAndView reportPDF(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException, JRException
	{	
		ModelAndView mav = new ModelAndView();
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		if(!isSessionActive(request)){
			mav.setViewName("../error/error");
			mav.addObject("message", "Invalid Request");
			
			return new ModelAndView("../error/error");
		}
		FactorsDateDAO currentdate = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map valueCheck = request.getParameterMap();
		Iterator<String> valCheckIterator = valueCheck.keySet().iterator();
		String ParamName= "";
		Validator valueValidator = new Validator();
		try{
		while(valCheckIterator.hasNext()){
 			ParamName = valCheckIterator.next().toString();
 			if (ParamName.contentEquals("operation")){
 				if (!valueValidator.validString(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Character String");
 			}
 			else if (ParamName.contentEquals("reportOption")){
 				if (!valueValidator.validString(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Character String");
 			}
 			else if (ParamName.contentEquals("startDate")){
 				if (!valueValidator.isValidDateFormat(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Date Format");
 			}
 			else if (ParamName.contentEquals("endDate")){
 				if (!valueValidator.isValidDateFormat(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Date Format");
 			}
 			else if (ParamName.contentEquals("customerCode")){
 				if (!valueValidator.validClientCode(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Character String");
 			}
 			else if (ParamName.contentEquals("clientCode")){
 				if (!valueValidator.validClientCode(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Client Code");
 			}// to check error thrown 
 			else if (ParamName.contentEquals("asOfDate")){
 				if (!valueValidator.isValidDateFormat(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Date Format");
 			}
 			else if (ParamName.contentEquals("branchcode")){
 				if (!valueValidator.validBranchCode(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Branch Code");
 			}
 			else if (ParamName.contentEquals("reportType")){
 				if (!valueValidator.validString(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Character String");
 				
 			}else if (ParamName.contentEquals("status")){
 				if (!valueValidator.validString(request.getParameter(ParamName)))
 				throw new FactorsFormatException("Invalid Character String");
 			}else if (ParamName.contentEquals("clientName")){
				if (!valueValidator.stringIsValid(request.getParameter(ParamName)))
				throw new FactorsFormatException("Invalid Character String");
 			}else if (ParamName.contentEquals("includeZero")){
				 
				 
 			}else{
 				request.removeAttribute(ParamName);
 				System.out.println("Parameter Dropped");
 			}
		}}catch(FactorsFormatException e){
			e.printStackTrace();
			mav.addObject("message", "Invalid Request");
			mav.setViewName("../error/error");
			return mav;
		}
		
		Map mm = new HashMap();
		
		//ModelAndView mav = new ModelAndView();
		List<?> list = null;
		HttpSession session= request.getSession(true);
		String branchCode = session.getAttribute("branchCode")!=null?session.getAttribute("branchCode").toString():"01";		
		String jasper="";
		String sSQL="";
		String viewName="swf";
		String operation = request.getParameter("operation").trim();
		String reportOption = request.getParameter("reportOption")!=null?request.getParameter("reportOption").trim():"PDF";
		String optionJP = "0";
		CC cc =  new CC(); 
		cc.setBranchCode(branchCode);
		String title = "";
		System.out.println("Operation: "+operation);
		UtilDAO utilDao    = (UtilDAO)Persistence.getDAO("utilDao");
		Map m = new HashMap();
		m.put("branchCode", branchCode);
		m.put("operation", operation);
		
		JRDataSource ds=null;
		long listSize=0;
		if(operation.equalsIgnoreCase("reportAudit")){
			AuditTrailDao atd = (AuditTrailDao)Persistence.getDAO("auditTrailDao");
			String startDate=request.getParameter("startDate").trim();
			String endDate=request.getParameter("endDate").trim();
			listSize=atd.getAuditTrail(startDate,endDate).size();
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);			
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			sSQL			 	  =	getSQLQuery(m);
			optionJP			  = "1";			
			jasper="/report/auditTrail.jasper";		
			if(listSize==0)mm.put("msg","The date you entered doesn't have Audit Data");
			
		}		
		else if(//operation.equalsIgnoreCase("scheduleOfInvoiceEditList") || 
				operation.equalsIgnoreCase("schedOfCreditNote")  || operation.equalsIgnoreCase("schedOfCanceledCreditNote"))
		{					
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();
			String clientCode     = request.getParameter("clientCode");
			if (operation.equalsIgnoreCase("scheduleOfInvoiceEditList"))
			{
				InvoiceDAO invoiceDAO = (InvoiceDAO)Persistence.getDAO("invoiceDao");
				listSize              = invoiceDAO.getInvoiceScheduleOfEditLst(branchCode, clientCode, startDate, endDate).size();
				jasper                = "/report/schedofinvoiceeditlist.jasper";
				if(listSize==0)mm.put("msg","There seems to be no Schedule of Invoices Edit List");
			}
			else if (operation.equalsIgnoreCase("schedOfCreditNote")  || operation.equalsIgnoreCase("schedOfCanceledCreditNote") )
			{
				int Status = 2;
				String msg = "";
				if (operation.equalsIgnoreCase("schedOfCreditNote"))
				{
					Status = 2;
					msg    =  "There seems to be no Schedule of Credit Note.";
				}
				else if (operation.equalsIgnoreCase("schedOfCanceledCreditNote"))
				{
					Status = 3;
					msg    =  "There seems to be no Schedule of Cancelled Credit Note.";
				}
				
				CreditNoteDAO creditNote = (CreditNoteDAO)Persistence.getDAO("creditNoteDao");				
				listSize              = creditNote.getScheduleOfCreditNote(branchCode, clientCode, startDate, endDate, Status).size();
				jasper                = "/report/ScheduleOfCreditNote.jasper";
				if(listSize==0)mm.put("msg",msg);				
			}											
			
			
			mm.put("clientCode",clientCode);
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
		}
		
		else if (operation.equalsIgnoreCase("customerStmtOfAcct"))
		{
			String clientCode = request.getParameter("clientCode"); 
			long custCode   = 0;			
			String asOfDate = request.getParameter("asOfDate").trim();
						
			CustomerStatementOfAcctDAO custStmtOfAcctDao = (CustomerStatementOfAcctDAO)Persistence.getDAO("customerStmtOfAcctDao");
			try 
			{	 
				listSize = custStmtOfAcctDao.getCountOfCustStmtOfAccount(clientCode, custCode, asOfDate, branchCode);
			} 
			catch (Exception e) 
			{
				listSize = 0;
				e.printStackTrace();
			}	
			
			if (request.getParameter("custCode")==null)
			{
				custCode = 0;
			}
			else
			{
				custCode = Long.parseLong(request.getParameter("custCode"));
			}
			
			if (custCode > 0)
			{
				jasper = "/report/customerStmtOfAcct.jasper";			
			}
			else
			{
				jasper = "/report/customerStmtOfAcctAll.jasper";
			}						
			
			Boolean filter = Boolean.parseBoolean(request.getParameter("invFilter"));
			if(listSize==0)mm.put("msg","There seems to be no Customer Statement of Account.");
			mm.put("clientCode", clientCode);
			mm.put("custCode", custCode);
			mm.put("asOfDate", asOfDate);
			mm.put("filter",filter);
		}
		else if (operation.equalsIgnoreCase("actualDunningReport"))
		{
			String clientCode = request.getParameter("clientCode");

			String startDate =request.getParameter("startDate");
			String endDate =request.getParameter("endDate");

			long custCode   = 0;			

			listSize = 1;	

			if (request.getParameter("custCode")==null)
			{
				custCode = 0;
			}
			else
			{
				custCode = Long.parseLong(request.getParameter("custCode"));
			}

			jasper = "/report/ActualDunningReport.jasper";

			mm.put("clientCode", clientCode);
			mm.put("custCode", custCode);
			mm.put("startDate", startDate);
			mm.put("endDate",endDate);
		}
		else if (operation.equalsIgnoreCase("monthlyCharges"))
		{
			String monthYear                    = request.getParameter("monthYear");
			/*			
			MonthlyChargesDAO monthlyChargesDao = (MonthlyChargesDAO)Persistence.getDAO("monthlyChargesDao");
			listSize                            = monthlyChargesDao.getMonthlyCharges(branchCode,monthYear).size();
			jasper                              = "/report/monthlyCharges.jasper";
			if(listSize==0)mm.put("msg","There seems to be no Monthly Charges.");
			mm.put("monthYear", monthYear);
			*/
			/**
			 *	Roldan Somontina
			 *	Modify monthly charges and optimize its object
			 *	12/13/2010
			 */
			m.put("monthYear", monthYear);
			ReportField rf = DateUtils.getFirstAndLastDayOfMonth(m.get("monthYear").toString());
			m.put("startDate", rf.getStartDate());
			m.put("endDate", rf.getEndDate());
			AdvancesDAO advancesDAO = (AdvancesDAO)Persistence.getDAO("advanceDao");
			list = new ArrayList<ReportField>();
			list = advancesDAO.getMonthlyChargesReport(m);			
			listSize = list.size();
			jasper   = "/report/monthlyCharges.jasper";
			if(listSize==0)mm.put("msg","There seems to be no Monthly Charges.");
			ds = new ReportFieldDataSource(list);
			mm.put("monthYear", monthYear);			 
			
 		}		
		else if (operation.equalsIgnoreCase("exposureByIndustry"))
		{
			optionJP			  				= "1";
			String monthYear                    = request.getParameter("monthYear");
			String monthName                    = utilDao.getMonthName(utilDao.getCurrentMonth(monthYear));
			String monthAndYear                 = monthName + " " + utilDao.getCurrentYear(monthYear);  
			sSQL  								= "SELECT count(divCode) FROM fpmsIndustry";
		//	listSize                            = utilDao.getTableRowCount(sSQL);
			listSize =1;
			jasper                              = "/report/exposureByIndustry.jasper";
			if(listSize==0)mm.put("msg","There seems to be List of Industry Found.");
			mm.put("monthYear", monthYear);
			mm.put("monthAndYear", monthAndYear);
		}
		/*
		else if(operation.equalsIgnoreCase("verifyInvoice"))
		{
			InvoiceDAO invoiceDAO = (InvoiceDAO)Persistence.getDAO("invoiceDao");
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			sSQL			 	  =	getSQLQuery(m);
			optionJP			  = "1";
			listSize              = invoiceDAO.getVerifyInvoiceInView(startDate, endDate,branchCode).size();
			jasper                = "/report/verifyInvoice.jasper";
			
		}
		*/	
		
		else if (operation.equalsIgnoreCase("clientAdjustments"))
		{
			String asOfDate        = request.getParameter("asOfDate").trim(); 
			cc.setAsOfDate(asOfDate);
			optionJP			  = "1";
			if (operation.equalsIgnoreCase("clientAdjustments"))
			{
			sSQL =	 "Select count(n_refno) from adjustment where d_approveddate<=?";
			Map va = new HashMap();
			va.put("asOfDate", asOfDate);
			//listSize = utilDao.getTableRowCount(sSQL,va)
			listSize = 1;
			jasper   = "/report/clientAdjustments.jasper";			
			if(listSize==0)mm.put("msg","There seems to be no List of Adjustments.");
			}
		}
		
		else if(operation.equalsIgnoreCase("verifyInvoice")||operation.equalsIgnoreCase("dueInvoice")|| operation.equalsIgnoreCase("cancelledInvoice"))
		{
			
			if(operation.equalsIgnoreCase("verifyInvoice")||operation.equalsIgnoreCase("cancelledInvoice")){
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();
			cc.setStartDate(startDate);
			cc.setEndDate(endDate);
			}	
			if(operation.equalsIgnoreCase("dueInvoice")){
			String asOfDate        = request.getParameter("asOfDate").trim(); 
			cc.setAsOfDate(asOfDate);
			}
			
			if(operation.equalsIgnoreCase("verifyInvoice")){
				title="Schedule of Invoices for Verification";
				cc.setStatus(" IN('1') ");
			}
			if(operation.equalsIgnoreCase("dueInvoice")){
				title="Schedule of Invoices due for Collection";
				cc.setStatus(" IN('3','4') ");
			}
			if(operation.equalsIgnoreCase("cancelledInvoice")){
				title="List of Cancelled Invoices";
				cc.setStatus(" ='7' ");
			}			
			
			if(operation.equalsIgnoreCase("verifyInvoice")||operation.equalsIgnoreCase("cancelledInvoice")){
				m.put("startDate", cc.getStartDate());
				m.put("endDate", cc.getEndDate());
				}
		
			if(operation.equalsIgnoreCase("dueInvoice")){
				m.put("asOfDate", cc.getAsOfDate());
				}
			
			m.put("status", cc.getStatus());
			sSQL			 	  =	getSQLQuery(m);
			optionJP			  = "1";			
		//	listSize              = utilDao.getTableRowCount(sSQL);
			listSize              = 1;
			if(operation.equalsIgnoreCase("dueInvoice"))jasper= "/report/invoiceDue4Collection.jasper";
			if(operation.equalsIgnoreCase("verifyInvoice"))jasper= "/report/invoiceVerify.jasper";
			if(operation.equalsIgnoreCase("cancelledInvoice"))jasper= "/report/invoiceCancelled.jasper";
			if(listSize==0)mm.put("msg","There seems to be no List of "+title+" ");
			//jasper              = "/report/dueInvoice.jasper";
				
		}
		else if(operation.equalsIgnoreCase("prepaymentAdvice")){
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();			
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			m.put("branchCode", branchCode);
			cc.setStartDate(startDate);
			cc.setEndDate(endDate);			
			AdvancesDAO advanceDao =(AdvancesDAO)Persistence.getDAO("advanceDao");			
			jasper                = "/report/advanceWithLetter.jasper";
			double totalAdvances = advanceDao.getTotalAdvanceByDateRange(m);
			Money money = new Money();
			String moneyWord = money.getMoneyInWord(totalAdvances);
			log.info("total advances in word:=>  "+money.toString());
			m.put("totalAdvances", df.format(totalAdvances));
			m.put("moneyWord", moneyWord);
			listSize              = advanceDao.getAllAdvances(m).size();
			if(listSize==0)mm.put("msg","There seems to be no List for Summary of Advances");
			sSQL			 	  =	getSQLQuery(m);
			optionJP			  = "1";			
		}
		else if(operation.equalsIgnoreCase("advancesList")||operation.equalsIgnoreCase("advancesListAllClient"))
		{
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();			
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			m.put("branchCode", branchCode);
			AdvancesDAO advanceDao =(AdvancesDAO)Persistence.getDAO("advanceDao");
			String clientCode     = request.getParameter("clientCode")!=null?request.getParameter("clientCode").trim():"";
			StringBuilder whereClause = new StringBuilder();
			whereClause	.append(" WHERE adv.C_STATUS IN(2,4) AND adv.C_TYPE IN (1,2) AND adv.C_BRANCHCODE =\'"+branchCode+"\'  ")
						.append("      AND CAST(CONVERT(NVARCHAR,adv.D_TRANSACTIONDATE,101) AS SMALLDATETIME) BETWEEN \'"+startDate+"\' AND \'"+endDate+"\'   ");
			if(!clientCode.equalsIgnoreCase(""))whereClause.append(" AND adv.C_CLNTCODE = \'"+clientCode+"\' ");
			list = new ArrayList<ReportField>();
			list = advanceDao.getScheduleOfAdvances(whereClause.toString());
			listSize              = list.size();
			if(listSize==0)mm.put("msg","There seems to be no List of Advances for Client");
			jasper                = "/report/advancePerClient.jasper";
			title				  = "Schedule of Advances "+((clientCode.equalsIgnoreCase(""))?"(All Client)":"");
			ds= new ReportFieldDataSource(list);			
			
/*		
			String clientCodeClause = "";
			if (!clientCode.equals("")) {
				clientCodeClause = " AND adv.c_clntcode =  '" + clientCode + "' ";
			}
			jasper                = "/report/advancePerClient.jasper";
			log.info("clientCodeClause: "+clientCodeClause);
			mm.put("clientCodeClause", clientCodeClause);
			listSize              = 1;//advanceDao.getPerClient(m).size();
			if(listSize==0)mm.put("msg","There seems to be no List of Advances for Client");
			cc.setStartDate(startDate);
			cc.setEndDate(endDate);	
			//sSQL			 	  =	getSQLQuery(m);
			optionJP			  = "1";
*/			
		}
		
		else if(operation.equalsIgnoreCase("clientAvailList")){
			com.bdo.factor.dataSource.ClientDAO cdo = new com.bdo.factor.dataSource.ClientDAO();
			String  clientCode     = request.getParameter("clientCode").trim();
			String  advanceNumber  = request.getParameter("advanceNumber").trim();
			String asOfDate      = request.getParameter("asOfDate").trim();
			String tranDate      = cdo.getPreviousAdvancesTransactionDate(clientCode,advanceNumber);
			Long numberOfAdvances = cdo.advancesCount(clientCode);
			double fiuBalance = 0.00;
//			if (numberOfAdvances == 1) {
//				fiuBalance = 0.00;
//			}else{
				fiuBalance = cdo.getClientFIUbyAsOfDate(clientCode, asOfDate);
//				if (tranDate==null){
//					fiuBalance = 0.00;
//				}else{
//					fiuBalance = cdo.getClientFIUbyAsOfDate(clientCode, tranDate);
//				}
			
//			}
			
			m.put("clientCode", clientCode);
			m.put("advanceNumber", advanceNumber);
			m.put("transactionDate", asOfDate);
			m.put("fiuBalance", fiuBalance);
			Map map = new HashMap();
			map =  cdo.getDelinquentFromClient(advanceNumber);
			double proceeds =Double.parseDouble(map.get("proceeds").toString())- Double.parseDouble(map.get("amount").toString());
			m.put("delAmount",map.containsKey("amount")?map.get("amount"):0.0);
			m.put("proceeds",proceeds);
			mm.put("asOfDate","\'"+asOfDate+"\'");
			optionJP			  = "1";
			AdvancesDAO advanceDao =(AdvancesDAO)Persistence.getDAO("advanceDao");
			listSize              = advanceDao.searchClientAvailability(m).size();
			jasper                = "/report/clientAvailability.jasper";
			if(listSize==0)mm.put("msg","There seems to be no  Client Availability Report for Client ");
		}
		else if(operation.equalsIgnoreCase("refundClientList")){
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();			
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			m.put("branchCode", branchCode);
			RefundDAO refundDao = (RefundDAO)Persistence.getDAO("RefundDAO");
			list = new ArrayList<ReportField>();
			list = refundDao.getRefundToClientReport(m);			
			listSize = list.size();
			ds = new ReportFieldDataSource(list);	
			jasper                = "/report/refundClient.jasper";
			if(listSize==0)mm.put("msg","There seems to be no List for Client's Refund in specified Date");
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
		}
		else if ((operation.equalsIgnoreCase("dishonoredEditList")) || operation.equalsIgnoreCase("pdcduefordep") ||
				  operation.equalsIgnoreCase("shedOfInvWithPartial"))
		{
			optionJP = "1";			
			String startDate = request.getParameter("startDate").trim();
			String endDate   = request.getParameter("endDate").trim();		
			
			if (operation.equalsIgnoreCase("dishonoredEditList"))
			{
				sSQL     = "SELECT COUNT(t1.N_REFNO) " +
						   "FROM ReceiptsHdr t1, CC v1 " +
						   "WHERE " +
						   "t1.D_TRANSACTIONDATE BETWEEN '"+startDate+"' AND '"+endDate+"' " +
						   "AND v1.C_CLNTCODE = t1.C_CLNTCODE " +
						   "AND v1.C_CUSTCODE=t1.C_CUSTCODE " +
						   "AND t1.C_BRANCHCODE = '"+branchCode+"' AND t1.C_STATUS = 3 ";						
				
			//	listSize = utilDao.getTableRowCount(sSQL);
				listSize = 1;
				jasper   = "/report/dishonoredChequeEditList.jasper";			
				if(listSize==0)mm.put("msg","There seems to be no List of Dishonored Cheque Edit List.");
				
			}else if (operation.equalsIgnoreCase("shedOfInvWithPartial"))
			{
				
				  
				 sSQL =	 "Select count(n_invno)" +
				         " from invoice where" + 
				         " d_partialpaiddate between '"+startDate+"' AND '"+endDate+"' " +
				         " and c_status='4' and c_branchcode = '" +branchCode+ "' ";
	
			//	listSize = utilDao.getTableRowCount(sSQL);
				 listSize = 1;
				jasper   = "/report/schedOfInvWithPartial.jasper";			
				if(listSize==0)mm.put("msg","There seems to be no List of Invoice with Partial Payment.");
			}
		
			else if (operation.equalsIgnoreCase("pdcduefordep"))
			{
				sSQL     = "SELECT " +
						   "COUNT(t1.C_CLNTCODE) AS cnt " + 
						   "FROM " + 
						   "PDC t1, CheckType t2, CC v1 " +
						   "WHERE " + 
						   "t1.C_CHECKTYPECODE = t2.C_CHECKTYPECODE " +
						   "AND t1.D_DEPOSITDATE BETWEEN '"+startDate+"' AND '"+endDate+"' " +
						   "AND t1.C_CLNTCODE = v1.C_CLNTCODE " +
						   "AND t1.C_CUSTCODE = v1.C_CUSTCODE " +
						   "AND v1.C_BRANCHCODE = '"+branchCode+"' " ;						
		
			//	listSize = utilDao.getTableRowCount(sSQL);
				listSize = 1;
				jasper   = "/report/pdcDueForDeposit.jasper";			
				if(listSize==0)mm.put("msg","There seems to be no List of PDC Due for Deposit.");
			}
			
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
		}		
		else if (operation.equalsIgnoreCase("debtorsPaymentReport"))
		{
			optionJP = "1";			
			String clientCode  = request.getParameter("clientCode");
			String startDate   = request.getParameter("startDate").trim();
			String endDate     = request.getParameter("endDate").trim();
						
				   sSQL      = "SELECT " +
							   "COUNT(DISTINCT t1.N_REFNO) " +
							   "FROM ReceiptsHdr t1, ReceiptsDtl t2, CC AS v1 " + 
							   "WHERE " +
							   "t1.C_CUSTCODE = v1.C_CUSTCODE " +
							   "AND " +
							   "t1.C_CLNTCODE = v1.C_CLNTCODE " +							   
							   "AND " +
							   "t1.C_BRANCHCODE = '"+branchCode+"' " +
							   "AND t1.D_TRANSACTIONDATE BETWEEN '"+startDate+"' " + 
							   "AND '"+endDate+"' " + 
							   "AND t1.C_CLNTCODE =" + clientCode;
			
		//	listSize = utilDao.getTableRowCount(sSQL);
				   listSize =1;
			jasper = "/report/debtorsPaymentReport.jasper";			
			if(listSize==0)mm.put("msg","There seems to be no List of Debtors Payment");
			mm.put("clientCode",clientCode);
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
		}
		else if (operation.equalsIgnoreCase("AdvRefTransaction"))
		{
				
			String clientCode  = request.getParameter("clientCode");
			String startDate   = request.getParameter("startDate").trim();
			String endDate     = request.getParameter("endDate").trim();
						
				listSize=1;
			jasper = "/report/AdvRefTransaction.jasper";			
			mm.put("clientCode",clientCode);
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
		}
		else if (operation.equalsIgnoreCase("clientConcentrationRep"))
		{
			//optionJP = "2";				
			ClientDAO clientDao = (ClientDAO)Persistence.getDAO("ClientDAO");
			listSize = clientDao.getClientConcentrationCount(branchCode);
			jasper   = "/report/clientConcentrationsReport.jasper";			
			if(listSize==0)mm.put("msg","There is no Client Concentration Report Where FIU is grater than 100000000 PHP.");
		}		
		else if (operation.equalsIgnoreCase("ScheduleOfCreditNoteAllClient") || 
				operation.equalsIgnoreCase("ScheduleOfCreditNoteAllCancelledClient"))
		{
			optionJP = "1";
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();						
			String msg            = "";
			if(operation.equals("ScheduleOfCreditNoteAllClient") || operation.equalsIgnoreCase("ScheduleOfCreditNoteAllCancelledClient"))			
			{
				int Status = 2;
				
				if (operation.equalsIgnoreCase("ScheduleOfCreditNoteAllCancelledClient"))
				{
					Status = 3;
					msg      = "There seems to be no Schedule of Cancelled Credit Note.";	
					jasper                = "/report/ScheduleOfCreditNoteAllClient.jasper";	
				}
				else if (operation.equalsIgnoreCase("ScheduleOfCreditNoteAllClient"))
				{
					Status = 2;
					msg      = "There seems to be no Schedule of Credit Note.";
					jasper                = "/report/ScheduleOfCreditNoteAllClient.jasper";	
				}
				sSQL     = "SELECT COUNT(DISTINCT(CreditNote.N_REFNO)) " +
						   "FROM CreditNote " +
						   " INNER JOIN Invoices " +
						   " ON CreditNote.C_BRANCHCODE = Invoices.C_BRANCHCODE" +
						   " AND CreditNote.C_CLNTCODE = Invoices.C_CLNTCODE" +
						   " AND CreditNote.C_CUSTCODE = Invoices.C_CUSTCODE " +
						   " AND CreditNote.C_INVOICENO = Invoices.C_INVOICENO " +
						   " AND CreditNote.C_INVOICENO = Invoices.C_INVOICENO " +
						   " AND CreditNote.D_APPLICATIONDATE BETWEEN '"+startDate+"' AND " +
						   " '"+endDate+"' " +
						   " INNER JOIN CNTYPE ON CreditNote.C_CNTYPECODE = CNTYPE.C_CNTYPECODE " +
						   " WHERE" +
						   " CreditNote.C_BRANCHCODE = '"+branchCode+"' " +
						   "AND CreditNote.C_STATUS = '"+Status+"'";
				
			//	listSize = utilDao.getTableRowCount(sSQL);
				listSize =1;
				mm.put("c_status", Status);
			}				
			if(listSize==0)mm.put("msg",msg);
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);			
		}
		if (operation.equalsIgnoreCase("dailyRecEdtLstAllClient") || operation.equalsIgnoreCase("dailyRecEdtLst"))
		{
			optionJP = "1";
			String startDate        = request.getParameter("startDate").trim();
			String endDate          = request.getParameter("endDate").trim();
			String clientCode = request.getParameter("clientCode")!=null?request.getParameter("clientCode").trim():"";
			String receiptType = request.getParameter("receiptType")!=null?request.getParameter("receiptType").trim():"''1'',''2'',''3'',''4''";
			String paymentType = request.getParameter("paymentType").trim();//!=null?request.getParameter("paymentType").trim();//:"''1'',''2'',''3''";
			
			/* - jeff
		    String clientCodeClause = "";
			String clientCodeClause2 = "";
			try
			{
				String clientCode = request.getParameter("clientCode");
				if (clientCode!=null)
				{
					clientCodeClause = " AND CC.C_CLNTCODE = '" + clientCode + "' ";
					clientCodeClause2 = " AND C_CLNTCODE = '" + clientCode + "' ";
				}
			}
			catch(Exception e)
			{}		
			listSize = utilDao.getDailyReceiptsCount(branchCode, startDate, endDate, clientCodeClause2);
			*/
			String whereClause=" AND ReceiptsHdr.C_RECEIPTTYPE IN("+receiptType+") AND  ReceiptsDtl.C_TYPE in ("+paymentType+")  AND ReceiptsHdr.D_TRANSACTIONDATE BETWEEN ''"+startDate+"'' AND ''"+endDate+"''  "+((!clientCode.equals(""))?" AND ReceiptsHdr.C_CLNTCODE=''"+clientCode+"''":"");
			listSize = utilDao.getDailyReceiptsCount(branchCode, whereClause.replaceAll("\'\'", "\'"));
			//mm.put("paymentType",paymentType);
			jasper   = "/report/dailyRecieptEditList.jasper";
			if(listSize==0)mm.put("msg","There seems to be no List of Daily Receipts");
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
			mm.put("whereClause", whereClause);
			mm.put("paymentType",paymentType);
			m.put("currentDate", currentdate.newDate());
		}
		if(operation.equalsIgnoreCase("ccAgingAnalysisList")||operation.equalsIgnoreCase("ccAgingByDunningList")||operation.equalsIgnoreCase("clientActivityList")||operation.equalsIgnoreCase("clientSalesAnalysisList")){			
			String clientCode=request.getParameter("no").trim();
			String asOfDate=request.getParameter("asOfDate").trim();
			CCLink ccLink = new CCLink(clientCode,branchCode,asOfDate);
			mm.put("clientCode",clientCode);
			mm.put("asOfDate", asOfDate);
			if(operation.equalsIgnoreCase("ccAgingAnalysisList")||operation.equalsIgnoreCase("ccAgingByDunningList")){
				CCLinkDAO cclinkDao = new CCLinkDAO();
				listSize=cclinkDao.getCustAgingAnalysis(ccLink,operation).size()==1?0:1;
				if(operation.equalsIgnoreCase("ccAgingAnalysisList"))jasper="/report/custAgingAnalysis.jasper";
				if(operation.equalsIgnoreCase("ccAgingByDunningList"))jasper="/report/ccAgingByDunning.jasper";
				if(listSize==0)mm.put("msg"," It seems to be no List of Aging Analysis");
			}
			else if(operation.equalsIgnoreCase("clientActivityList")){
				ClientDAO clientDao = new ClientDAO();
				String sizeQuery = 	" SELECT  COUNT(*) "+
									" FROM  dbCIF.dbo.Client INNER JOIN " +
									" MonthlyBalances ON dbCIF.dbo.Client.C_CLNTCODE = MonthlyBalances.C_CLNTCODE LEFT JOIN " +
									" BLRFile ON dbCIF.dbo.Client.C_CLNTCODE = BLRFile.C_BLRTYPECODE " +
									" WHERE     (dbCIF.dbo.Client.C_CLNTCODE = '"+clientCode+"')";

			//	listSize=utilDao.getTableRowCount(sizeQuery);
				listSize =1;
				//jasper="/report/clientActivity.jasper";
				jasper="/report/clientSOA.jasper";
				if(listSize==0)mm.put("msg","There seems to be no List of Client Activities.\n The cause might be Theres is no MonthlyBalances data \n or BLR for that Client");
			}
			else if(operation.equalsIgnoreCase("clientSalesAnalysisList")){
				com.bdo.factor.dataSource.ClientDAO clientDao = new com.bdo.factor.dataSource.ClientDAO();
				cc.setClientCode(clientCode);			
				cc.setAsOfDate(asOfDate);
				cc.setStatus("IN ('2','3','4','5')");
				listSize=clientDao.getAllClientSalesAnalysis(cc).size();
				jasper="/report/clientSalesAnalysis.jasper";
				if(listSize==0)mm.put("msg","There seems to be no List of Client Sales Analysis");
			}			
						
		}		
		/**	Added by: 	Katherine Cabungcal
		 * 	Date	:	June 24, 2009
		 * 	Purpose	:	Customer Active Listing
		 */		
		else if (operation.equalsIgnoreCase("customerListing"))
		{
			log.info("customerListing...");
			optionJP = "1";				
			listSize = 1;
			jasper   = "/report/customerListingReport.jasper";				
		}			
		/**	Added by: 	Roldan Somontina 
		 * 	Date	:	June 25, 2009
		 * 	Purpose	:	Client Active Listing
		 */
		else if(operation.equalsIgnoreCase("clientActiveListing")){
			sSQL = getSQLQuery(m);
			optionJP = "1";
		//	listSize=utilDao.getTableRowCount(sSQL);
			listSize =1;
			jasper="/report/clientActiveListing.jasper";
			if(listSize==0)mm.put("msg","There seems to be no Active Client");
		}
		/**	Added by: 	Katherine Cabungcal
		 * 	Date	:	June 24, 2009
		 * 	Purpose	:	Client Customer Active Listing
		 */		
		else if (operation.equalsIgnoreCase("clientCustomerListing"))
		{			
			optionJP = "1";				
			listSize = 1;
			jasper   = "/report/clientCustomerListingReport.jasper";				
		}
		else if(operation.equalsIgnoreCase("clientDebtTurnReport")){
			java.util.Date startDateClient = DateHelper.parse(request.getParameter("startDate").trim());
			ClientDebtTurnDAO cbt = (ClientDebtTurnDAO)Persistence.getDAO("clientDebtTurnDAO");
			String endDate= DateHelper.format(startDateClient);
			Calendar cal = Calendar.getInstance();
			cal.setTime(startDateClient);
			cal.add(Calendar.MONTH, -5);			
			int eday = cal.getActualMinimum(cal.DAY_OF_MONTH);
			cal.set(Calendar.DATE, eday);
			String startDate=DateHelper.format(cal.getTime());
			String clientCode = request.getParameter("clientCode").trim();
			String customerCode = request.getParameter("customerCode").trim();
			String status = "('5','6')";
			listSize=cbt.getClientDebtTurn(clientCode, customerCode, status, startDate, endDate).size();
			
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);	
			mm.put("customerCode", customerCode);
			mm.put("clientCode", clientCode);			
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";			
			jasper="/report/ClientDebtTurnReport.jasper";		
			if(listSize==0)mm.put("msg","No Client Debt Turn Generated For the Past 6 Months");
			
		}			
		/**	Added by: 	Roldan Somontina
		 * 	Date	:	June 30, 2009
		 * 	Purpose	:	Receipts Due for Refund Listing created by Mark De Villa
		 */			
		else if (operation.equalsIgnoreCase("receiptsDueRefund"))
		{	
			String startDate        = request.getParameter("startDate").trim();
			String endDate          = request.getParameter("endDate").trim();
			String status          = request.getParameter("status").trim();
			
			cc.setStartDate(startDate);
			cc.setEndDate(endDate);
			cc.setStatus(status);
			
			optionJP = "1";
			Map map = new HashMap();
			map.put("startDate", startDate);
			map.put("endDate", endDate);
			map.put("branchCode", branchCode);
			map.put("status", status);
			
			ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");		
			listSize = rHeaderDAO.getReceiptsDueForRefundSize(map);
						
			jasper   = "/report/receiptsRefund.jasper";
			if(listSize==0)mm.put("msg","No Receipts Due For Refund Generated.");
		}
		
		/**	Added by: 	Roldan Somontina
		 * 	Date	:	June 30, 2009 
		 * 	Purpose	:	Ageing Summary by Client and Ageing Summary by Client based on Dunning Days 
		 */			

		else if (operation.equalsIgnoreCase("ageingSummaryByClient")||operation.equalsIgnoreCase("ageingClientByDunning"))
		{	
			com.bdo.factor.dataSource.ClientDAO c = new com.bdo.factor.dataSource.ClientDAO();
			String asOfDate        = request.getParameter("asOfDate").trim();
			cc.setAsOfDate(asOfDate);
			cc.setStatus(" IN('3','4') ");						
			listSize 	= c.getAgeingSummaryForClient(cc, operation).size();
			title		= operation.equalsIgnoreCase("ageingSummaryByClient")?"AGEING SUMMARY BY CLIENT":"AGEING SUMMARY BY CLIENT BASED ON DUNNING PERIOD";
			jasper   	= "/report/ageingSummaryByClient.jasper";
			if(listSize==0)mm.put("msg","There is no available Ageing Summary/Ageing Summary by Dunning for that Client");
		}	
		else if (operation.equalsIgnoreCase("clientStatisticsRevReport"))
		{
			ClientStatisticsDAO clientStat = (ClientStatisticsDAO)Persistence.getDAO("clientStatisticsDAO");
			String clientCode = request.getParameter("clientCode").trim();
			String asOfDate = request.getParameter("asOfDate").trim();
			String status = "5";
			listSize=clientStat.getClientStatistics(clientCode, asOfDate).size();
			
			mm.put("asOfDate",asOfDate);
			mm.put("clientCode", clientCode);			
			
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";			
			jasper="/report/ClientStatisticsReport.jasper";	
		}
		else if (operation.equalsIgnoreCase("discountChargeOnCashDelay"))
		{
			String startDate        = request.getParameter("startDate").trim();
			String endDate          = request.getParameter("endDate").trim();
			
			ReceiptsHeaderDAO receiptsHdrDao = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			listSize = receiptsHdrDao.getDiscountChargeOnCashDelayCount(startDate, endDate, branchCode);
			jasper = "/report/discountChargeOnCashDelays.jasper";
			if(listSize <= 0)mm.put("msg","There is no available Discount Charge on Cash Delay from "+ startDate + " to " + endDate);
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
			mm.put("branchCode", branchCode);	
		}
		else if (operation.equalsIgnoreCase("PDOInvoices"))
		{
			INVOICEDAO pdinvoiceDao = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			String asOfDate = request.getParameter("asOfDate");
			String reportType = request.getParameter("reportType");
			listSize = pdinvoiceDao.getPDOInvoiceCount(asOfDate, branchCode);			
			if(listSize==0)mm.put("msg","There is no available PDO Invoices as of " + asOfDate);	
			
			mm.put("asOfDate", asOfDate);
			mm.put("reportType", reportType);
			mm.put("id",session.getId());
			
			if(reportType.contentEquals("acctgPDO")){
				jasper = "/report/PDODelinquent.jasper";
			}
			else if (reportType.contentEquals("mktgPDO")){
				jasper = "/report/PDOInvoiceLOD.jasper";
			}
			else if (reportType.contentEquals("lpcPDO")){
				jasper = "/report/PDOInvoiceCollection.jasper";
			}else{
				jasper = "/report/PDOInvoice.jasper";
			}
		}
		else if (operation.equalsIgnoreCase("advancesReport")) {			
			AdvancesService advSvc = AdvancesService.getInstance();
			String n_RefNo = request.getParameter("nRefNo").trim();
			optionJP = "1";
			listSize = advSvc.getAdvancesReportSize(Integer.parseInt(n_RefNo));
			if (listSize <= 0) {
				mm.put("msg","There is no invoice connected in the selected data.");	
			}
			
			int settingUpRefNo = advSvc.getAdvancesSettingUpRefNo(Integer.parseInt(n_RefNo));			
			m.put("n_refNo", n_RefNo);
			
			if (settingUpRefNo > 0) {
				jasper="/report/AdvancesSettingUpFeeReport.jasper";				
			}
			else {
				jasper="/report/AdvancesReport.jasper";	
			}
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";						
		}
		else if (operation.equalsIgnoreCase("userReport")) {			
			optionJP = "1";
			listSize = 1;
			if (listSize <= 0) {
				mm.put("msg","There is no invoice connected in the selected data.");
			}
			m.put("C_BRANCHCODE", branchCode);
			
			jasper="/report/userList.jasper";								
		}
		else if (operation.equalsIgnoreCase("factoringManagement")) {
			
			FactoringManagementDAO fmDao = (FactoringManagementDAO) Persistence.getDAO("factoringManagementDAO"); 			
			String asOfDate = request.getParameter("asOfDate").trim();						
			listSize=1;
			
			mm.put("asOfDate",asOfDate);			
			mm.put("branchCode", branchCode);
						
			jasper = "/report/FactoringManagement.jasper";

		}else if (operation.equalsIgnoreCase("FactoredReceivableCredex")) {
			
			FactoringManagementDAO fmDao = (FactoringManagementDAO) Persistence.getDAO("factoringManagementDAO"); 			
			String asOfDate = request.getParameter("asOfDate").trim();	
			String filter = request.getParameter("FRFilter");
			
			
			
			listSize=1;
			
			mm.put("asOfDate",asOfDate);			
			mm.put("branchCode", branchCode);
			mm.put("filter",filter);
			
			jasper = "/report/FactoredReceivable-Credex.jasper";
			
		}else if (operation.equalsIgnoreCase("FactoredReceivable")) {
			
			FactoringManagementDAO fmDao = (FactoringManagementDAO) Persistence.getDAO("factoringManagementDAO"); 			
			String asOfDate = request.getParameter("asOfDate").trim();						
			listSize=1;
			
			mm.put("asOfDate",asOfDate);			
			mm.put("branchCode", branchCode);

			jasper = "/report/FactoredReceivable.jasper";
		}
		else if (operation.equalsIgnoreCase("factorStatisticsReport"))
		{
			String monthYear                    = request.getParameter("monthYear");
			String clientCode                   = request.getParameter("clientCode");			
			listSize 							= 1;
			jasper                              = "/report/"+operation+".jasper";
			if(listSize==0)mm.put("msg","There seems to be no Factoring Statistics Report.");
			mm.put("monthYear", monthYear);
			mm.put("clientCode",clientCode);
		}		
		else if (operation.equalsIgnoreCase("yearToEndEarningReport"))
		{
			optionJP = "1";
			String asOfDate = request.getParameter("asOfDate");			
			listSize 							= 1;
			jasper                              = "/report/"+operation+".jasper";
			if(listSize==0)mm.put("msg","There seems to be no Year to End Earnings Report.");
			mm.put("asOfDate", asOfDate);			
		}						
		else if (operation.equalsIgnoreCase("refundSummary")) {			
			String n_RefNo = request.getParameter("nRefNo").trim();
			optionJP = "1";
			listSize = 1;						
			m.put("n_refNo", n_RefNo);
			
			jasper="/report/RefundSummarySheet.jasper";							
		}
		else if (operation.equalsIgnoreCase("transactionCtrlTotals"))
		{
			TransactionControlTotalDAO tctDao = (TransactionControlTotalDAO)Persistence.getDAO("transactionControlTotalDAO");				
			String startDate = request.getParameter("startDate").trim();
			String endDate = request.getParameter("endDate").trim();			
			listSize=1;
			
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
			mm.put("branchCode", branchCode);
			
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";			
			jasper="/report/TransactionControlTotals.jasper";	
		}
		else if (operation.equalsIgnoreCase("accountsForReview"))
		{
			AccountForReviewDAO afrDao = (AccountForReviewDAO) Persistence.getDAO("accountForReviewDAO"); 			
			String startDate = request.getParameter("startDate").trim();
			String endDate = request.getParameter("endDate").trim();			
			listSize=1;
			
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
			mm.put("branchCode", branchCode);
			
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";			
			jasper="/report/AccountsForReview.jasper";	
		}
		else if (operation.equalsIgnoreCase("pdcRegistry"))
		{
			PDCRegistryDAO pdcDao = (PDCRegistryDAO) Persistence.getDAO("pdcRegistryDAO"); 			
			String startDate = request.getParameter("startDate").trim();
			String endDate = request.getParameter("endDate").trim();
			String clientCode = request.getParameter("clientCode").trim();
			listSize=pdcDao.getPDC(clientCode, branchCode, startDate, endDate).size();
			
			if(listSize==0)mm.put("msg","There seems to be no PDC Registry Report.");
			
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
			mm.put("branchCode", branchCode);
			mm.put("clientCode", clientCode);
			
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";			
			jasper="/report/PDCRegistry.jasper";	
		}
		else if (operation.equalsIgnoreCase("pdcRegistryAllClient"))
		{
			PDCRegistryDAO pdcDao = (PDCRegistryDAO) Persistence.getDAO("pdcRegistryDAO"); 			
			String startDate = request.getParameter("startDate").trim();
			String endDate = request.getParameter("endDate").trim();
			String clientCode = null;
			listSize=pdcDao.getPDC(clientCode, branchCode, startDate, endDate).size();
			
			if(listSize==0)mm.put("msg","There seems to be no PDC Registry Report.");
			
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
			mm.put("branchCode", branchCode);
			mm.put("clientCode", null);
			
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";			
			jasper="/report/PDCRegistry.jasper";	
		}

		else if (operation.equalsIgnoreCase("customerConcentration")||operation.equalsIgnoreCase("customerConcentrationAll"))
		{	
			ClientDAO c = new ClientDAO();
			String asOfDate        	= request.getParameter("asOfDate").trim();
			cc.setAsOfDate(asOfDate);
			cc.setStatus(" IN('2','3','4') ");
			if(operation.equalsIgnoreCase("customerConcentration"))cc.setCustomerCode(request.getParameter("no").trim());
			listSize 	= 1;
			title		= "CUSTOMER CONCENTRATION REPORT";
			jasper   	= "/report/customerConcentration.jasper";
			if(listSize==0)mm.put("msg","There seems to be no available Customers Concentration");
		}
		
		else if (operation.equalsIgnoreCase("partialPayment"))
		{
			PartialPaymentDAO paymentDao = (PartialPaymentDAO) Persistence.getDAO("partialPaymentDAO"); 			
			String startDate = request.getParameter("startDate").trim();
			String endDate = request.getParameter("endDate").trim();
			String clientCode = request.getParameter("clientCode").trim();
			listSize=paymentDao.getPartialPayment(branchCode, clientCode, startDate, endDate).size();
			
			if(listSize==0)mm.put("msg","There seems to be no Partial Payment Report.");
			
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
			mm.put("branchCode", branchCode);
			mm.put("clientCode", clientCode);
			
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";			
			jasper="/report/PartialPayment.jasper";	
		}
		else if (operation.equalsIgnoreCase("partialPaymentAllClient"))
		{
			PartialPaymentDAO paymentDao = (PartialPaymentDAO) Persistence.getDAO("partialPaymentDAO"); 			
			String startDate = request.getParameter("startDate").trim();
			String endDate = request.getParameter("endDate").trim();
			String clientCode = null;
			listSize=paymentDao.getPartialPayment(branchCode, clientCode, startDate, endDate).size();
			
			if(listSize==0)mm.put("msg","There seems to be no Partial Payment Report.");
			
			mm.put("startDate",startDate);
			mm.put("endDate", endDate);
			mm.put("branchCode", branchCode);
			mm.put("clientCode", null);
			
			//sSQL			 	  =	getSQLQuery(m);
			//optionJP			  = "1";			
			jasper="/report/PartialPayment.jasper";	
		}		
		
		
		else if(operation.equalsIgnoreCase("advices")){
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();	
			String option        = request.getParameter("reportOption").trim();
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			m.put("branchCode", branchCode);
			cc.setStartDate(startDate);
			cc.setEndDate(endDate);
			//AdvancesDAO advanceDao =(AdvancesDAO)Persistence.getDAO("advanceDao");			
			//jasper                = "/report/advicesWithLetter.jasper";
			jasper                ="/report/"+(!option.equalsIgnoreCase("Advances and Refunds")?"advices.jasper":"advices2.jasper");
			title =option+" Advice Summary";
			AdvicesReport ar = new AdvicesReport();
			list = new ArrayList<AdvicesReport>();
			list = ar.getAllAdvices(cc, option);
			Money money = new Money();
			String moneyWord = money.getMoneyInWord(ar.getTotalAmount());
			log.info("Total "+option+" in word:=>  "+money.toString());
			m.put("total", df.format(ar.getTotalAmount()));
			m.put("moneyWord", moneyWord);
			m.put("currentDate", currentdate.newDate());
			mm.put("list", list);
			listSize              = list.size();
			if(listSize==0)mm.put("msg","There seems to be no List for "+option+" Advices Summary");
			sSQL			 	  =	getSQLQuery(m);			
		}

		else if(operation.equalsIgnoreCase("classRefReport"))
		{
			
			listSize = 1;
			jasper   = "/report/classref.jasper";
			if(listSize==0)mm.put("msg","No report....");
		}
		/*------------------------------------*/
		//for testing only
		else if (operation.equalsIgnoreCase("dummy"))
		{	
			optionJP = "1";		
			listSize = 1;
			jasper   = "/report/dummy.jasper";
			if(listSize==0)mm.put("msg","No report....");
		}
		//end testing only
		/*------------------------------------*/
		else if (operation.equalsIgnoreCase("scheduleOfInvoiceEditList") || operation.equalsIgnoreCase("schedofinvoiceeditlistAllClient")){
			//String startDate      = request.getParameter("startDate")!=null?request.getParameter("startDate").trim():"";
			//String endDate        = request.getParameter("endDate")!=null?request.getParameter("endDate").trim():"";
			String asOfDate        = request.getParameter("asOfDate")!=null?request.getParameter("asOfDate").trim():"";
			
			String clientCode     = request.getParameter("clientCode")!=null?request.getParameter("clientCode").trim():"";
			StringBuilder whereClause = new StringBuilder();
			whereClause	.append(" WHERE     (Invoice.C_STATUS BETWEEN 2 AND 6) ")
						//.append(" AND Invoice.D_TRANSACTIONDATE BETWEEN \'"+startDate+"\' AND \'"+endDate+"\' ")
						.append(" AND Invoice.D_TRANSACTIONDATE <= \'"+asOfDate+"\' ")
						.append(" AND Invoice.C_BRANCHCODE = \'"+branchCode+"\' ");
			  if(operation.equalsIgnoreCase("scheduleOfInvoiceEditList"))whereClause.append(" AND Invoice.C_CLNTCODE = \'"+clientCode+"\' ");
			mm.put("whereClause", whereClause.toString());
			InvoiceDAO invoiceDAO = (InvoiceDAO)Persistence.getDAO("invoiceDao");
			list = new ArrayList<ReportField>();
			list = invoiceDAO.getScheduleOfInvoices(whereClause.toString(),new ReportField(asOfDate));
			listSize              = list.size();//invoiceDAO.getSizeScheduleOfInvoices(whereClause.toString());
			jasper                = "/report/scheduleOfInvoices.jasper";
			title				  = "Schedule of Invoices "+(operation.equalsIgnoreCase("schedofinvoiceeditlistAllClient")?"(All Client)":"");
			if(listSize==0)mm.put("msg","There seems to be no "+title);	
			ds= new ReportFieldDataSource(list);//ScheduleOfInvoicesField(list);
			//mm.put("startDate",startDate);
			//mm.put("endDate", endDate);
			mm.put("asOfDate", asOfDate);
		}
		
		else if (operation.equalsIgnoreCase("activityLogReport")){
			String startDate      = request.getParameter("startDate")!=null?request.getParameter("startDate").trim():"";
			String endDate        = request.getParameter("endDate")!=null?request.getParameter("endDate").trim():"";
			int filterNum     	  = request.getParameter("filterField")!=null?new Integer(request.getParameter("filterField").trim()).intValue():1;			
			String fieldValue     = request.getParameter("fieldValue")!=null?request.getParameter("fieldValue").trim():"";
			/*int sortNum     	  = request.getParameter("sort")!=null?new Integer(request.getParameter("sort").trim()).intValue():1;
			String filterField    = filterNum==3?" AND ActivityLog.C_USERID LIKE \'%"+fieldValue+"%\'":filterNum==2?" AND ActivityLog.C_BRANCHCODE LIKE \'%"+fieldValue+"%\'":"";
			String sort			  = sortNum==3?"ActivityLog.C_USERID":sortNum==2?"ActivityLog.C_BRANCHCODE":"ActivityLog.D_LOGDATE";
			
			StringBuilder whereClause = new StringBuilder();
			whereClause	.append(" WHERE CAST(CONVERT(NVARCHAR,ActivityLog.D_LOGDATE,101) AS SMALLDATETIME) BETWEEN \'"+startDate+"\' AND \'"+endDate+"\' ")					
						.append(filterField)
						.append(" ORDER BY ").append(sort).append(" ASC, ActivityLog.N_LOGID ASC");
			mm.put("whereClause", whereClause.toString());*/
			ActivityLogService als = ActivityLogService.getInstance();
			
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			m.put("branchCode", branchCode);
			m.put("filterField",filterNum);
			m.put("fieldValue",fieldValue);
			m.put("currentDate",currentdate.newDate());
			//m.put("sort",sort);
			m.put("order","ASC");
			//m.put("whereClause", whereClause.toString());
			list 				  = new ArrayList<ReportField>();
			list 				  = als.getListActivityLog(m);
			listSize              = list.size();
			jasper                = "/report/activityLog.jasper";
			title				  = "Activity log Report";
			if(listSize==0)mm.put("msg","There seems to be no "+title+" to display");	
			ds= new ReportFieldDataSource(list);

		}
		else if(operation.equalsIgnoreCase("reportSummaryDC"))
		{
			FactorsDateDAO date1 = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
			SimpleDateFormat sdf = new SimpleDateFormat("MM/d/yyyy");
			String getDate = sdf.format(date1.newDate());
			//Report Summary of Discount Charge
			listSize = 1;
			jasper   = "/report/summaryOfDiscountCharge.jasper";
			String startDate      = request.getParameter("startDate").trim();
			String endDate        = request.getParameter("endDate").trim();	
			m.put("startDate", startDate);
			//m.put("startDate", startDate);
			m.put("endDate", endDate);
			m.put("getDate", getDate);
			m.put("clntCode",Long.parseLong( request.getParameter("clientCode")));
			m.put("customerCode",Long.parseLong(request.getParameter("customerCode")));
			m.put("branchCode", request.getParameter("branchcode"));
			m.put("userName", (String) session.getAttribute("userName"));
			optionJP = "1";
			//BankCERT and FullyPaidInv CVG 06012017	
		}else if (operation.equalsIgnoreCase("repFullyPaidInvoice")){
		
			String startDate      = request.getParameter("startDate")!=null?request.getParameter("startDate").trim():"";
			String endDate        = request.getParameter("endDate")!=null?request.getParameter("endDate").trim():"";
			String clientCode =request.getParameter("clientCode")!=null?request.getParameter("clientCode").trim():"";
			String preparedBy      = request.getParameter("preparedBy")!=null?request.getParameter("preparedBy").trim():"";
			String notedBy       = request.getParameter("notedBy")!=null?request.getParameter("notedBy").trim():"";

			m.put("startDate", startDate);
			m.put("endDate", endDate);
			m.put("branchCode", branchCode);
			m.put("clientCode", clientCode);
			m.put("preparedBy", preparedBy);
			m.put("notedBy", notedBy);
			log.info("preparedBy" + preparedBy);
			listSize = 1;
			jasper   = "/report/fullyPaidInvoiceReport.jasper";
			optionJP = "1";
			
		}else if (operation.equalsIgnoreCase("repBankCertification")){
			String asOfDate       = request.getParameter("asOfDate")!=null?request.getParameter("asOfDate").trim():"01/01/1900";
			String startDate      = request.getParameter("startDate")!=null?request.getParameter("startDate").trim():"01/01/1900";
			String endDate        = request.getParameter("endDate")!=null?request.getParameter("endDate").trim():"01/01/1900";
			String clientName     =request.getParameter("clientName")!=null?request.getParameter("clientName").trim():"";
			String signatory      = request.getParameter("signatory")!=null?request.getParameter("signatory").trim():"";
			String location       = request.getParameter("location")!=null?request.getParameter("location").trim():"";
			String reportType      = request.getParameter("reportType")!=null?request.getParameter("reportType").trim():"";
			int dateNum;
			String startMName="";
			String endMName="";
			Date newStartD = null ;
			String startCompare = null;
			String endCompare= null;
			String fullyPaidDateRaw=asOfDate;
			int hasInvoice=0;
			
			INVOICEDAO invDao = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			if (reportType.equals("3")){ 
				jasper   = "/report/FullyPaidInvoiceCerti.jasper";
				
			}else if (reportType.equals("1")){
				Map mdate = new HashMap();
				mdate.put("branchCode", branchCode);
				mdate.put("clientName", clientName);
				mdate.put("asOfDate", asOfDate);
				fullyPaidDateRaw =invDao.getFullyPaidDate(mdate)!=null?invDao.getFullyPaidDate(mdate):asOfDate;
				hasInvoice = invDao.getInvoiceCount(mdate);
				jasper   = "/report/OutstandingReceivablesCert.jasper";
				
			}else if (reportType.equals("2")){
				jasper   = "/report/TotalPaidInterestCert2.jasper";
				
			}

			SimpleDateFormat StrAsDate = new SimpleDateFormat("MM/dd/yyyy");
			 try { //for proper report format
				SimpleDateFormat sdfDay = new SimpleDateFormat("d");
		    	
				String getday = sdfDay.format(StrAsDate.parse(asOfDate));		    	
		    	int dayInt = Integer.parseInt(getday);	  
		    	dateNum = dayInt;
				String ordinal = DateHelper.getDayOrdinalNumber(dateNum);		
				SimpleDateFormat sdfDateOrd = new SimpleDateFormat("dd'"+ordinal+"' 'day of' MMMM, yyyy");
				SimpleDateFormat sdfHeaderDName = new SimpleDateFormat("MMMM dd, yyyy");// 07252017
				
				String headerDate = sdfHeaderDName.format(StrAsDate.parse(asOfDate));
				String ordinalFormat = sdfDateOrd.format(StrAsDate.parse(asOfDate));
				String fullyPaidDate=sdfHeaderDName.format(StrAsDate.parse(fullyPaidDateRaw));
				
				m.put("issuedDate", ordinalFormat );
				m.put("headerDate", headerDate );
				m.put("fullyPaidDate", fullyPaidDate);
				
				log.info("fullyPaidDate " + fullyPaidDate);
				log.info("ordinal " + ordinalFormat);
				
				
				} catch (ParseException e) {
					
					e.printStackTrace();
				}
			
			log.info("clientName " + clientName);
			m.put("startDate", startDate);
			m.put("endDate", endDate);
			m.put("branchCode", branchCode);
			//m.put("clientCode", clientCode);
			m.put("clientName", clientName);
			m.put("clntName", clientName);
			m.put("asOfDate", asOfDate);
			m.put("signatory", signatory);
			m.put("location", location);
			m.put("startMName", startMName);
			m.put("endMName", endMName);
			m.put("hasInvoice", hasInvoice);
			listSize = 1;
			optionJP = "1";
			//log.info("paraaaaams----------------->"+m );
		}else if (operation.equalsIgnoreCase("rptClassification")) {  //CVG082917
			
			//FactoringManagementDAO fmDao = (FactoringManagementDAO) Persistence.getDAO("factoringManagementDAO"); 			
			String asOfDate = request.getParameter("asOfDate").trim();	
			Boolean includeZero = Boolean.parseBoolean(request.getParameter("includeZero"));	 
			listSize=1;
			
			mm.put("asOfDate",asOfDate);			
			mm.put("branchCode", branchCode);
			mm.put("includeZero", includeZero);
			jasper = "/report/RPTClassification.jasper";
		}
		//end
		
		 
	/*	mm.put("reportOption", reportOption);
		mm.put("ds", ds);
		mm.put("listSize",listSize);
		mm.put("operation",operation);
		mm.put("jasper", jasper);
		mm.put("sSQL", sSQL);
		mm.put("optionJP", optionJP);
		mm.put("cc",cc);
		mm.put("title",title);
		mm.put("map",m);
		*/
		/////
		mm.put("reportOption", reportOption);
		mm.put("ds", ds);
		mm.put("listSize",listSize);
		mm.put("operation",operation);
		mm.put("jasper", jasper);
		mm.put("sSQL", sSQL);
		mm.put("optionJP", optionJP);
		mm.put("cc",cc);
		mm.put("title",title);
		mm.put("map",m);
		jasper = jasper.toString().replace("/report/", "").replace(".jasper", "");
		mav.addObject("jasper", jasper);
		mav.setViewName(viewName);
		log.info("sSQL=>"+sSQL);
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!logOnForm.isSecured(operation,sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		
		System.out.println("-------------------------------------------------------------------------------------------------------------filling JasperPrint");
		NewReportService reportService = new NewReportService();
		try {
			reportService.buildReport(request, mm);
		} catch (JRException e) {	 
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		//HTML CVG 040417
	/*	ServletOutputStream outputStream = response.getOutputStream();
		JasperPrint jasperPrint= (JasperPrint) session.getAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE);
		request.getSession().setAttribute(ImageServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE,jasperPrint);
		response.setContentType("text/html");
		JRExporter exporter = null;
		exporter = new JRHtmlExporter();			
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
		exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
		exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "report/images?image=");
		exporter.setParameter(JRHtmlExporterParameter.IS_OUTPUT_IMAGES_TO_DIR,false);
		exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN,false);
		exporter.exportReport();
		
		*/
		//removed 12/03/2013
		/*if(jasper.contentEquals("activityLog")){
			System.out.println(request.getParameter("reportOption"));
			if(request.getParameter("reportOption")!=null){
				if(request.getParameter("reportOption").contentEquals("xls")){
					exportXLSHandler(request, response);
				}
				else
					exportPDFHandler(request, response);
			}
			else
				exportPDFHandler(request, response);
			
		}*/
		return mav;
	}

/***********************************************************************************************************************************/
/***********************************************************************************************************************************/
	
	public String getSQLQuery(Map m){
		String sSQL="";		
		String operation = m.get("operation").toString();
		if(operation.equalsIgnoreCase("reportAudit")){
				sSQL	=  " SELECT (SELECT u.C_USERNAME from UserTable u where u.C_USERID=a.UserId) as userName, " +
            			   " 	type=(CASE WHEN Type='U' THEN 'Update' " +
	           	           " 	WHEN Type='I' THEN 'Insert' " +
            			   " 	WHEN Type='D' THEN 'Delete' " +
                      	   " 	ELSE 'Unrecognized'END), " +
            			   " 	TableName as tableName,NewValue as newValue, " +
            			   " 	UpdateDate as transactionDate " +
            			   " FROM Audit a " +
            			   " WHERE CONVERT(nvarchar,UpdateDate,101) BETWEEN '"+m.get("startDate").toString()+"' AND '"+m.get("endDate").toString()+"'";		
		}
		else if(operation.equalsIgnoreCase("dueInvoice")){
			sSQL	=   "	SELECT     COUNT(DISTINCT C_NAME) AS rowNum " +
			"	FROM         (SELECT     Invoice.C_INVOICENO, CC.C_CUSTNAME, Invoice.N_TERM, Invoice.N_INVOICEAMT, Invoice.D_INVOICEDATE, Invoice.C_STATUS, " + 
			"												  ISNULL(Invoice.N_EXCHANGERATE, 0) AS N_EXCHANGERATE, ISNULL(N_ORIGINVOICEAMT, 0) N_ORIGINVOICEAMT, " + 
			"												  Invoice.C_CURRENCYCODE, CC.C_NAME, CC.C_CLNTCODE, CC.C_CUSTCODE, Invoice.C_BRANCHCODE " +
			"						   FROM          Invoice CROSS JOIN CC " +											
			//"						   WHERE      Invoice.C_CUSTCODE = CC.C_CUSTCODE AND Invoice.D_INVOICEDUEDATE BETWEEN '"+m.get("startDate").toString()+"' AND '"+m.get("endDate").toString()+"' AND " + 
			"						   WHERE      Invoice.C_CUSTCODE = CC.C_CUSTCODE AND Invoice.D_INVOICEDUEDATE <= CONVERT(VARCHAR(10),'"+m.get("asOfDate")+"',101) AND " + 
			"												  Invoice.C_BRANCHCODE = '"+m.get("branchCode").toString()+"' AND CC.C_BRANCHCODE = Invoice.C_BRANCHCODE AND Invoice.C_CLNTCODE = CC.C_CLNTCODE AND " +
			"												  (Invoice.C_STATUS "+m.get("status").toString()+" )) a ";			
		}
		else if(operation.equalsIgnoreCase("verifyInvoice")||operation.equalsIgnoreCase("cancelledInvoice")){
		//else if(operation.equalsIgnoreCase("verifyInvoice")||operation.equalsIgnoreCase("dueInvoice")|| operation.equalsIgnoreCase("cancelledInvoice")){	
				
				sSQL	=   "	SELECT     COUNT(DISTINCT C_NAME) AS rowNum " +
							"	FROM         (SELECT     Invoice.C_INVOICENO, CC.C_CUSTNAME, Invoice.N_TERM, Invoice.N_INVOICEAMT, Invoice.D_INVOICEDATE, Invoice.C_STATUS, " + 
							"												  ISNULL(Invoice.N_EXCHANGERATE, 0) AS N_EXCHANGERATE, ISNULL(N_ORIGINVOICEAMT, 0) N_ORIGINVOICEAMT, " + 
							"												  Invoice.C_CURRENCYCODE, CC.C_NAME, CC.C_CLNTCODE, CC.C_CUSTCODE, Invoice.C_BRANCHCODE " +
							"						   FROM          Invoice CROSS JOIN CC " +											
							"						   WHERE      Invoice.C_CUSTCODE = CC.C_CUSTCODE AND Invoice.D_TRANSACTIONDATE BETWEEN '"+m.get("startDate").toString()+"' AND '"+m.get("endDate").toString()+"' AND " + 
							"												  Invoice.C_BRANCHCODE = '"+m.get("branchCode").toString()+"' AND CC.C_BRANCHCODE = Invoice.C_BRANCHCODE AND Invoice.C_CLNTCODE = CC.C_CLNTCODE AND " +
							"												  (Invoice.C_STATUS "+m.get("status").toString()+" )) a ";
				
					/*
		else if(operation.equalsIgnoreCase("verifyInvoice")){					
				sSQL	=   "SELECT * FROM " +
							"   (SELECT C_NAME AS clientName , C_CUSTNAME AS customerName, " + 
							"	C_INVOICENO AS invoiceNumber, D_INVOICEDATE AS invoiceDate, " + 
							"	D_TRANSACTIONDATE AS transactionDate, N_INVOICEAMT AS invoiceAmount, " + 
							"	N_ORIGINVOICEAMT AS origInvoiceAmt, N_EXCHANGERATE AS exchangeRate, " + 
							"	C_CLNTCODE, C_CUSTCODE, C_STATUS , C_BRANCHCODE " + 
							"      FROM ReportInvoice)AS a, " +  
							"   (SELECT sum(N_INVOICEAMT) AS perCustTotal, x.C_CLNTCODE,x.C_CUSTCODE,x.C_STATUS , x.C_BRANCHCODE " +  
							"      FROM ReportInvoice x GROUP BY c_clntcode,C_CUSTCODE,x.C_STATUS, x.C_BRANCHCODE )as b, " + 
						 	"   (SELECT sum(N_INVOICEAMT) AS perClientTotal, x.C_CLNTCODE,x.C_STATUS , x.C_BRANCHCODE " +  
							"      FROM ReportInvoice x GROUP BY c_clntcode,x.C_STATUS,x.C_BRANCHCODE)as c, " + 	 
							"   (SELECT sum(N_INVOICEAMT) AS overall,C_STATUS,C_BRANCHCODE FROM ReportInvoice y " + 
							"	WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101) BETWEEN '"+m.get("startDate").toString()+"' AND '"+m.get("endDate").toString()+"' " +
							"	GROUP BY C_BRANCHCODE,C_STATUS)as d " +  
							" WHERE " + 
							"    CONVERT(NVARCHAR,a.transactionDate,101) BETWEEN '"+m.get("startDate").toString()+"' " + 
						 	"    AND '"+m.get("endDate").toString()+"' " + 
							"    AND a.C_CLNTCODE=b.C_CLNTCODE AND a.C_CUSTCODE=b.C_CUSTCODE " + 
							"    AND a.C_BRANCHCODE=b.C_BRANCHCODE AND a.C_BRANCHCODE=c.C_BRANCHCODE AND a.C_BRANCHCODE=d.C_BRANCHCODE " +
							"    AND a.C_CLNTCODE=c.C_CLNTCODE AND a.C_STATUS=b.C_STATUS " + 
							"    AND a.C_STATUS=c.C_STATUS AND a.C_STATUS=d.C_STATUS " + 
							"    AND a.C_STATUS='"+Status.forVerification+"' AND a.C_BRANCHCODE='"+m.get("branchCode").toString()+"' " +	     
							" ORDER BY a.C_CLNTCODE,b.C_CUSTCODE ";  
					
			}
			else if(operation.equalsIgnoreCase("dueInvoice")){			
							" SELECT * FROM "+    
							"  	 (SELECT C_NAME AS clientName , C_CUSTNAME AS customerName,	" +							 	
							"  		 C_INVOICENO AS invoiceNumber, D_INVOICEDATE AS invoiceDate, " + 	
							"		 D_TRANSACTIONDATE AS transactionDate, N_INVOICEAMT AS invoiceAmount, " +	
							"		 N_ORIGINVOICEAMT AS origInvoiceAmt, N_EXCHANGERATE AS exchangeRate, " +	
							"		 D_INVOICEDUEDATE AS invoiceDueDate, C_CLNTCODE, C_CUSTCODE, C_STATUS " +      
							"	    FROM ReportInvoice)AS a, " +   
							"	 (SELECT sum(N_INVOICEAMT) AS perCustTotal, x.C_CLNTCODE,x.C_CUSTCODE,x.C_STATUS " +      
							"		FROM ReportInvoice x GROUP BY c_clntcode,C_CUSTCODE,x.C_STATUS)as b, " +   
							"	 (SELECT sum(N_INVOICEAMT) AS perClientTotal, x.C_CLNTCODE " + 
							"		FROM ReportInvoice x WHERE x.C_STATUS='"+Status.releasedAdvances+"' OR  C_STATUS='"+Status.partiallyPaid+"' GROUP BY c_clntcode)as c, " +   
							"	 (SELECT sum(N_INVOICEAMT) AS overall " +
							"		FROM ReportInvoice y WHERE y.C_STATUS='"+Status.releasedAdvances+"' OR y.C_STATUS='"+Status.partiallyPaid+"')as d " + 
						    " WHERE " +    
							" CONVERT(NVARCHAR,a.transactionDate,101)>='"+m.get("startDate").toString()+"' " +     
							" AND CONVERT(NVARCHAR,a.transactionDate,101)<='"+m.get("endDate").toString()+"' " +
							" AND (a.C_STATUS='"+Status.releasedAdvances+"' OR a.C_STATUS='"+Status.partiallyPaid+"' ) " +
							" AND a.C_CLNTCODE=b.C_CLNTCODE AND a.C_CLNTCODE=c.C_CLNTCODE " +
							" AND a.C_CUSTCODE=b.C_CUSTCODE  AND a.C_STATUS=b.C_STATUS " +
						    " ORDER BY a.C_CLNTCODE,b.C_CUSTCODE ";
					*/	    				
    						
			}
			else if(operation.equalsIgnoreCase("advancesList")||operation.equalsIgnoreCase("advancesListAllClient")){
					sSQL =		"SELECT * FROM " +								
								"	 (SELECT C_NAME AS clientName ,C_CUSTNAME as customerName , C_BNKACTNO as bankAccountNo, C_CURRENCYCODE as currencyCode,D_TRANSACTIONDATE AS transactionDate, N_SVCCHG AS serviceCharge, N_DISCCHG1 AS discountCharge,N_ADVAMT as advancesAmount, C_CLNTCODE,C_CUSTCODE,C_TYPE,C_STATUS  " + 
								"		 FROM ReportAdvances WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)>='"+m.get("startDate").toString()+"' AND CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)<='"+m.get("endDate").toString()+"' )AS a, " +
								"	 (SELECT C_CLNTCODE, C_CUSTCODE,C_TYPE,C_STATUS,SUM(N_ADVAMT)AS customerTotal " +	 
								"		 FROM ReportAdvances  WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)>='"+m.get("startDate").toString()+"' AND CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)<='"+m.get("endDate").toString()+"' GROUP BY C_CLNTCODE,C_CUSTCODE,C_TYPE,C_STATUS) AS b, " + 
								"	 (SELECT C_CLNTCODE,C_TYPE,C_STATUS,SUM(N_ADVAMT)AS clientTotal " +	 
								"		 FROM ReportAdvances  WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)>='"+m.get("startDate").toString()+"' AND CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)<='"+m.get("endDate").toString()+"'  GROUP BY C_CLNTCODE,C_TYPE,C_STATUS) AS c " + 		 
								"WHERE " +  
								"	a.C_CLNTCODE=b.C_CLNTCODE AND a.C_CLNTCODE=c.C_CLNTCODE " +
							    "     AND a.C_CUSTCODE = b.C_CUSTCODE " +
								"	 AND a.C_TYPE=b.C_TYPE AND a.C_STATUS=b.C_STATUS  " +
								"	 AND a.C_TYPE=c.C_TYPE AND a.C_STATUS=c.C_STATUS " + 
								"	 AND a.C_TYPE=1 AND a.C_STATUS=2 " +
								"	 AND a.C_CLNTCODE='"+m.get("clientCode").toString()+"'";						
				/*
				else{
					sSQL =		" SELECT * FROM	" +	
								"	 (SELECT C_NAME AS clientName, C_CLNTCODE,C_CUSTNAME as customerName , C_BNKACTNO as bankAccountNo,C_CURRENCYCODE as currencyCode ,C_TYPE,C_STATUS" +  
								"		 FROM ReportAdvances  WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)>='"+m.get("startDate").toString()+"' AND CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)<='"+m.get("endDate").toString()+"' GROUP BY C_NAME,C_CLNTCODE,C_CUSTNAME,C_BNKACTNO,C_CURRENCYCODE,C_TYPE,C_STATUS)AS a, " +
								"	 (SELECT SUM(N_ADVAMT)AS advancesAmount,C_CLNTCODE,C_TYPE,C_STATUS	" + 
								"		 FROM ReportAdvances  WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)>='"+m.get("startDate").toString()+"' AND CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)<='"+m.get("endDate").toString()+"' GROUP BY C_CLNTCODE,C_TYPE,C_STATUS) AS b, " +
								"	 (SELECT SUM(N_ADVAMT)AS total,C_TYPE,C_STATUS	" + 
								"		 FROM ReportAdvances  WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)>='"+m.get("startDate").toString()+"' AND CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)<='"+m.get("endDate").toString()+"' GROUP BY C_TYPE,C_STATUS) AS c " +
								" WHERE  a.C_CLNTCODE=b.C_CLNTCODE " +
								" AND a.C_TYPE=b.C_TYPE AND a.C_STATUS=b.C_STATUS " +
								" AND b.C_TYPE=c.C_TYPE AND b.C_STATUS=c.C_STATUS " +
								" AND a.C_TYPE=1 AND a.C_STATUS=2";					
				}
				*/
			}
			else if(operation.equalsIgnoreCase("refundClientList")){
				sSQL="EXEC sp_SCHEDULE_OF_REFUND "+m.get("branchCode").toString()+","+m.get("startDate").toString()+","+m.get("endDate").toString();	
					/*
						" SELECT     c.C_NAME AS clientName, r.D_TRANSACTIONDATE AS transactionDate, r.N_REFNO AS ref, r.N_REFAMT AS amount,r.N_DISCCHG AS discountCharge " +
						" FROM         Refund r INNER JOIN " +
						"                          (SELECT DISTINCT C_CLNTCODE, C_NAME, C_BRANCHCODE " +
						"                             FROM          CC) c ON r.C_CLNTCODE = c.C_CLNTCODE " +
						" WHERE     (c.C_BRANCHCODE = '"+m.get("branchCode").toString()+"') AND (r.D_TRANSACTIONDATE BETWEEN '"+m.get("startDate").toString()+"' AND '"+m.get("endDate").toString()+"') " +
						" ORDER BY c.C_NAME, r.D_TRANSACTIONDATE ";					
					
					"SELECT * from "+
								"	(SELECT DISTINCT C_CLNTCODE,C_NAME as clientName ,SUM(N_REFAMT)as clientTotal "+  
								"		FROM ReportRefund  " +
								"       WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)>='"+m.get("startDate").toString()+"'  "+ 
								"		AND CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)<='"+m.get("endDate").toString()+"' " +
								"       AND C_BRANCHCODE='"+m.get("branchCode").toString()+"' " +
								"       GROUP BY C_CLNTCODE,C_NAME)as a,  "+
								"	(SELECT SUM(N_REFAMT)as overall FROM ReportRefund  "+ 
								"		WHERE CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)>='"+m.get("startDate").toString()+"' "+
								"		  AND CONVERT(NVARCHAR,D_TRANSACTIONDATE,101)<='"+m.get("endDate").toString()+"' " +
								"         AND C_BRANCHCODE='"+m.get("branchCode").toString()+"' " +
								" )as b";
								*/					
			}
			else if(operation.equalsIgnoreCase("clientActiveListing")){
				sSQL=			" SELECT     COUNT(*) "+
								" FROM dbCIF.dbo.Client c INNER JOIN IndustryDetail i "+
								" ON c.IndCd = i.INDCD "+ 
								" WHERE (c.C_STATUS = '1') AND c.C_BRANCHCODE='"+m.get("branchCode").toString()+"'";
			}
			
		return sSQL;
	}
	
	public String getField(String field,String tableName,String where)
	{	
		String retVal=null;
		String sSQL = "SELECT "+field+" FROM "+tableName+" WHERE "+where;
		
		Connection conn = new FactorConnection().getConnectionCIF();
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = conn.createStatement();
			rs =stmt.executeQuery(sSQL);
			if(rs.next()){
				retVal = rs.getString(field);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();			
			}
			catch(SQLException e){
			}
		}
		log.info("getField==>" + sSQL);
		
		return retVal;	
	}	

	public void exportXLSHandler(HttpServletRequest request, HttpServletResponse response) throws IOException, JRException{
		System.out.println("Exporting to XLS ");BufferedInputStream buf = null;
		HttpSession session = request.getSession(true);
		
		String jasperName = request.getParameter("jasperName");
		Boolean allowed = false;
		
		if(jasperName!=null){
			Map securityMap = new HashMap();
			securityMap.put("CLASS_NAME", jasperName);
			securityMap.put("SESSIONID", session.getId());
			
			SecurityService SS = SecurityService.getInstance();
			securityMap = SS.getIsSecured(securityMap);
			allowed = (Boolean)securityMap.get("secured");
		}
		
		
		if(!allowed){
			System.out.println("Exporting to XLS NOT ALLOWED ");
			
			PrintWriter out = response.getWriter(); 
			String html ="<HTML> <BODY onload=\"alert('You Are Not Allowed To Export this Report to XLS.')\">"+
			" </body> </html>";
			out.print(html);
		}
		else{
			ServletOutputStream outputStream = response.getOutputStream();
			//System.out.println("EXPORT EXPORT");
			JasperPrint jasperPrint= (JasperPrint) session.getAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE);
			JRXlsExporter exporterXLS = new JRXlsExporter();
			exporterXLS.setParameter(
			JRXlsExporterParameter.JASPER_PRINT,
			jasperPrint);
			exporterXLS.setParameter(
			JRXlsExporterParameter.IS_DETECT_CELL_TYPE,
			Boolean.TRUE);
			exporterXLS.setParameter(
			JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND,
			Boolean.FALSE);
			exporterXLS.setParameter(
			JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS,
			Boolean.TRUE);
			exporterXLS.setParameter(
			JRXlsExporterParameter.OUTPUT_STREAM,
			response.getOutputStream());
			response.setContentType("application/vnd.ms-excel");
			exporterXLS.exportReport();
		}
	}

	public void exportPDFHandler(HttpServletRequest request, HttpServletResponse response) throws IOException, JRException{
	
		HttpSession session = request.getSession(true);
		String jasperName = request.getParameter("jasperName");
		Boolean allowed = false;
		
		if(jasperName!=null){
			Map securityMap = new HashMap();
			securityMap.put("CLASS_NAME", jasperName);
			securityMap.put("SESSIONID", session.getId());
			
			SecurityService SS = SecurityService.getInstance();
			securityMap = SS.getIsSecured(securityMap);
			allowed = (Boolean)securityMap.get("secured");
		}
		
		
		if(!allowed){
			System.out.println("Exporting to PDF NOT ALLOWED");
			
			PrintWriter out = response.getWriter(); 
			String html ="<HTML> <BODY onload=\"alert('You Are Not Allowed To Export this Report to PDF.')\">"+
			" </body> </html>";
			out.print(html);
		}
		else{
			ServletOutputStream outputStream = response.getOutputStream();
			JasperPrint jasperPrint= (JasperPrint) session.getAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE);
			request.getSession().setAttribute(ImageServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE,jasperPrint);
			response.setContentType("text/html");
			JRExporter exporter = null;
			exporter = new JRHtmlExporter();			
			exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
			exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "report/images?image=");
			exporter.setParameter(JRHtmlExporterParameter.IS_OUTPUT_IMAGES_TO_DIR,false);
			exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN,false);
			exporter.exportReport();
				
			
			
			
			/*BufferedInputStream buf = null;
			ServletOutputStream outputStream = response.getOutputStream();
			//System.out.println("EXPORT EXPORT");
			JasperPrint jasperPrint= (JasperPrint) session.getAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE);
			response.setContentType("application/pdf");
			JRExporter exporter = null;
			exporter = new JRPdfExporter();				
			exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);		
		
			exporter.exportReport();
			*/
			
		}
	}
	
	
	//html
	public void exportHTMLHandler(HttpServletRequest request, HttpServletResponse response) throws IOException, JRException{
		System.out.println("Exporting to HTML ");
		HttpSession session = request.getSession(true);
		String jasperName = request.getParameter("jasperName");
		Boolean allowed = false;
		
		if(jasperName!=null){
			Map securityMap = new HashMap();
			securityMap.put("CLASS_NAME", jasperName);
			securityMap.put("SESSIONID", session.getId());
			
			SecurityService SS = SecurityService.getInstance();
			securityMap = SS.getIsSecured(securityMap);
			allowed = (Boolean)securityMap.get("secured");
		}
		
	
		ServletOutputStream outputStream = response.getOutputStream();
		JasperPrint jasperPrint= (JasperPrint) session.getAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE);
		request.getSession().setAttribute(ImageServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE,jasperPrint);
		response.setContentType("text/html");
		JRExporter exporter = null;
		exporter = new JRHtmlExporter();			
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
		exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
		exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "report/images?image=");
		exporter.setParameter(JRHtmlExporterParameter.IS_OUTPUT_IMAGES_TO_DIR,false);
		exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN,false);
		exporter.exportReport();
			
		
	}
	
	
	public synchronized ModelAndView getStatus(HttpServletRequest request, HttpServletResponse response){
		Map po = new HashMap();
		ModelAndView mav = new ModelAndView();
		try{
			HttpSession session= request.getSession(true);
			LoaderHandler lh = new LoaderHandler();
			//po = lh.getUpdate(lh.getInstance(session.getId()));
			 
			
			po = lh.getUpdate(lh.getInstance2(session.getId()));
			
			//Map po = PDODelinquentDAO.updateBar();
			
			//po.put("newValue", completed);
			
			System.out.println(po.toString());
			
			request.setAttribute("data", new JSONObject(po));
			mav.setViewName("jsonAjax");
		}catch(Exception e){
			e.printStackTrace();
		}
		return mav;
	}
	
	private boolean isSessionActive(HttpServletRequest request) {
		String userName = null;
		HttpSession session=request.getSession(true);
		
		userName=(String) session.getAttribute("userName");
		if (userName != null) {
			return true;
		}
		
		return false;		
	}
	
	
}
