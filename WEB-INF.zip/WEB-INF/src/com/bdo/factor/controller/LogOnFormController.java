package com.bdo.factor.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.core.SpringVersion;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.mvc.SimpleFormController;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.servlet.view.RedirectView;
import org.apache.log4j.Logger;

import com.bdo.factor.beans.ActivityLog;
import com.bdo.factor.beans.LDAPSConfiguration;
import com.bdo.factor.beans.User;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.SystemSettingsDAO;
import com.bdo.factor.dao.UserDAO;
import com.bdo.factor.service.ActivityLogService;
import com.bdo.factor.service.BranchService;
import com.bdo.factor.service.LDAPSConfigurationService;
import com.bdo.factor.service.SecurityService;
import com.bdo.factor.service.UserService;
import com.bdo.factor.service.WebServiceFactors;
import com.bdo.factor.util.XMLParser;

import java.net.URLDecoder;
import java.net.URLDecoder.*;


public class LogOnFormController extends MultiActionController {
	
	/*
	 * added by jefferson francisco jr.
	 * lastinsert: June 11, 2009
	 * */
	private static Logger log = Logger.getLogger(LogOnFormController.class);
	private static Map userAccess = new HashMap();
	
	
	public LogOnFormController() {
		// TODO Auto-generated constructor stub
	}
	
	public ModelAndView  mainHandler(HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		if (this.isSessionActive(request))
		{
			mav.setViewName("mainLayout");
		}
		else
		{
			mav.setViewName("login");
			try {
				java.util.ResourceBundle rb = java.util.ResourceBundle.getBundle("/_properties/fileLocation"); // change to request
				String urlLoc = rb.getString("url");
				response.sendRedirect(urlLoc+"/login.BDOFactor");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");

		//added by Cherrie Garcia for Http Only	 10/7/15
		String sessionid = (String)request.getSession().getId();
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionid + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionid + ";Secure");
		
		return mav;		
	}
	
	public ModelAndView settingsHandler(HttpServletRequest request, HttpServletResponse response)	
	{
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);		
		String view = "";
				
		try
		{
			if (request.getParameter("view").trim()!=null)
			{
				view = request.getParameter("view").trim();	
			}
			else
			{
				view = "systemSettings";
			}
		}
		catch(Exception e)
		{
			view = "systemSettings";
		}
		
		if (this.isSessionActive(request)) 
		{					
			mav.setViewName(view);
		}
		else
		{
			mav.setViewName("login");	
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(view,sessionID)) {mav.setViewName("notAllowed");}	
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//test as of 09/02/15 by cvg
		//added by Cherrie Garcia for Http Only	
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		
		return mav;
	}
	
	public ModelAndView accountOfficerHandler(HttpServletRequest request, HttpServletResponse response) {		
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("account-officer");
		}
		else {
			mav.setViewName("login");
		}

		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//****end - link security check *****
		
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView serviceOfficerHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
			
		if (this.isSessionActive(request)) {
			mav.setViewName("serviceOfficer");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView bankHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("bank");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView docStampHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("docStamp");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView checkTypeHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("checkType");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView cnTypeHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("cntype");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView currencyHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("currency");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView groupHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("group");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView industryHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("industry");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView holidayHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("holiday");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	

	//////////////////////////////////// 	added by: m.gonzalez start 	/////////////////////////////////////

	public ModelAndView clientMasterMainHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("clientmaster");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView clientMasterHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("clientmaster-list");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}

	public ModelAndView scheduleInvoiceHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("schedule-invoice");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView scheduleCreditNoteHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("schedule-creditnote");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView scheduleReceiptHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("schedule-receipt");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		
		//added by Cherrie Garcia for Http Only	10/07/15
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	
	public ModelAndView invoiceProcessHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			System.out.println("invoice");
			mav.setViewName("invoice");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;

	}
	public ModelAndView advancesHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			System.out.println("advances");
			mav.setViewName("advances");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}

	
	

	@SuppressWarnings("unchecked")
public ModelAndView logInHandler(HttpServletRequest request, HttpServletResponse response) throws Exception {
		java.util.ResourceBundle rb = java.util.ResourceBundle.getBundle("/_properties/fileLocation");
		ModelAndView mav = new ModelAndView();
		HttpSession session=request.getSession(true);
		
		
		
		session.setMaxInactiveInterval(3600);
		String userID = (request.getParameter("c_UserID") != null ? request.getParameter("c_UserID") : "");
		UserService userService = UserService.getInstance();
		SecurityService securityService = SecurityService.getInstance();
		String sessionID = null;		
		String returnData = "";
		this.setURLLoc(request);
//////////////
//		PrintWriter printWriters = response.getWriter();
//		response.setContentType("text/html");													
//		returnData ="<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 " +
//			      "Transitional//EN\">\n";
//		printWriters.println(returnData +
//	                "<HTML>\n" +
//	                "<BODY onload=\"alert('fd')\"" +
//	                "</BODY></HTML>");
//							
//		printWriters.print(returnData);
//		printWriters.flush();
//		printWriters.close();
		//////////////
		if(!request.equals(null)&&request.getParameter("operation")!=null){
				
				String operation = request.getParameter("operation").trim()!=null?request.getParameter("operation").trim():"";
				
				if (operation.trim().equalsIgnoreCase("login")) {
					System.out.println(request.getSession().getId());
					if (session.getAttribute("sessionID")!=null&&session.getAttribute("sessionID").toString().contentEquals(request.getSession().getId())) {
						
						
						/*PrintWriter printWriter = response.getWriter();
						response.setContentType("text/plain");													
						  returnData = "{\"returnData\":[{\"message\":\"Computer Already Logged-in..\"}]}";							
						printWriter.print(returnData);
						printWriter.flush();
						printWriter.close();
						
						printWriter.flush();
						printWriter.close();
						
						*/
						
					
					}
					//userID= (String) request.getSession().getAttribute("c_UserID");
					//userID = (request.getParameter("c_UserID") != null ? request.getParameter("c_UserID") : "");										
					String password = (request.getParameter("c_PassW") != null ? request.getParameter("c_PassW") : "");									
					
					password = URLDecoder.decode(password, "UTF-8");
					//UserService userService = UserService.getInstance();					
				
					LDAPSConfigurationService _LDAPSConfigurationService = new LDAPSConfigurationService();
					LDAPSConfiguration _LDAPSConfiguration = _LDAPSConfigurationService.getLDAPSConfiguration();
					
					session.setAttribute("ldapStatus", _LDAPSConfiguration.getEnableLDAPS().toString());
					
					
					BranchService branchService = BranchService.getInstance();
						
					SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
					Map systemSettingsMap = new HashMap();
					if(systemSettingDao.getSystemSetting().size()!=0){
						systemSettingsMap = (HashMap)systemSettingDao.getSystemSetting().get(0);		
					}
					
					
					if (password.length() == 0 || userID.trim().length() == 0)
					{
						PrintWriter printWriter = response.getWriter();
						response.setContentType("text/plain");													
						returnData = "{\"returnData\":[{\"message\":\"Invalid Login!!!\"}]}";							
						printWriter.print(returnData);
						printWriter.flush();
						printWriter.close();
					}								
					else
					{
						boolean isStop = false;
						
						if(_LDAPSConfiguration.getEnableLDAPS()){// LDAPS IS ENABLED
							User user = userService.searchUserOnly(userID);
							WebServiceFactors ws = new WebServiceFactors();
							String status = "";
							String message = "";
							String[] statusMessage = ws.testWebService(userID.trim(),password,_LDAPSConfiguration );
							status = statusMessage[0];
							message = statusMessage[1];
									
							if (status.equalsIgnoreCase("00")&&user!=null) //check
							{
								if (user.getC_UserName().equals(userID)) { 
									
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");													
									returnData = "{\"returnData\":[{\"message\":\"Invalid Login Details.\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();
									isStop = true;
								} 
								else if (userService.isPurgedUser(user.getC_UserID())) { //
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");						
									returnData = "{\"returnData\":[{\"message\":\"Your account has been disabled. Please contact administrator to activate your account.\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();
									isStop = true;
								}
								else if (!userService.isUserActive(user.getC_UserID())) //c_status
								{
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");													
									returnData = "{\"returnData\":[{\"message\":\"Your account is Inactive, Please contact administrator to activate your account.\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();
									isStop = true;
								}
								/*else if (userService.isPasswordExpiredAndLocked(user.getC_UserID())&& status.isEmpty()) 
								{
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");													
									returnData = "{\"returnData\":[{\"message\":\"Password expires, please contact administrator to reset your password.\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();
									isStop = true;
								}  
								else if (userService.isSuspended(user.getC_UserID())&& status.isEmpty()) 
								{
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");													
									returnData = "{\"returnData\":[{\"message\":\"Access Denied. Please contact user Administrator\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();	
									isStop = true;
								}		
								if (isStop != true&& status.isEmpty()) {
									String result = userService.deActivateUser(user.getC_UserID());
									if (result != null) {
										PrintWriter printWriter = response.getWriter();
										response.setContentType("text/plain");													
										returnData = "{\"returnData\":[{\"message\":\""+result+"\"}]}";							
										printWriter.print(returnData);
										printWriter.flush();
										printWriter.close();
										isStop = true;
									}
								}
							
								if (isStop != true && status.isEmpty()) { //skip
									String resultUnchangedPwd = userService.unchangedPwdWarning(user.getC_UserID());							
									log.info("[debug]+--->"+resultUnchangedPwd);
										if (resultUnchangedPwd != null) {																								
											PrintWriter printWriter = response.getWriter();
											response.setContentType("text/plain");													
											returnData = "{\"returnData\":[{\"message\":\""+resultUnchangedPwd+"\",\"needActivatation\":\"on\"}]}";							
											printWriter.print(returnData);
											printWriter.flush();
											printWriter.close();
											isStop = true;
										}
									
								}*/
								if (!isStop)
								{								
										boolean isLogged = user.getIsLogged()!=0;
										
										
										isLogged = userService.getUserLoggedStatusLDAPS(userID); 	
										/*if (!user.getRole().equals("ADMIN"))
										{
											isLogged = userService.getUserLoggedStatus(userID, password);							
										}							
										else
										{
											isLogged = true;
										}*/
										if (isLogged)
										{
											
											userService.setUserLoginDate(userID);
											String branchName = "";
											sessionID = session.getId();
											branchName = branchService.searchBranchByCode(user.getC_BranchCode());										
											log.info("USERBRANCHCODE:" + user.getC_BranchCode());
											getUserAccess(sessionID,user.getC_UserID());
											userService.resetNTry(userID);
											securityService.parameterSetting();
											session = request.getSession(true);
											log.info("session.getId() : " + sessionID);
											session.setAttribute("userID",userID);
											session.setAttribute("userName",user.getC_UserName());
											session.setAttribute("branchCode",user.getC_BranchCode());
											session.setAttribute("branchName", branchName);
											session.setAttribute("userID", user.getC_UserID());
											session.setAttribute("sessionID", request.getSession().getId());
											session.setAttribute("userObject", user);
											System.out.print(request.getUserPrincipal());
											session.setAttribute("terminalName", request.getUserPrincipal());
											//session.setAttribute("isAdmin", user.getL_Super());
											/**
											 * Modified by: Roldan Somontin Date:10/21/2009 11:00pm
											 * Use for Process - back date
											 * */
											//session.setAttribute("isAdmin", Byte.parseByte(user.getRole().toUpperCase().equals("ADMIN")?"1":"0"));
											//End of Modification
											session.setAttribute("isAdmin", Byte.parseByte("1"));
											
											session.setAttribute("systemName",(String)systemSettingsMap.get("C_SYSTEMNAME"));
											session.setAttribute("sysVersion",(String)systemSettingsMap.get("C_VERSIONNO"));
											session.setAttribute("userRole", user.getRole());
											
											if(user.getRole().equalsIgnoreCase("admin")){
												//System.out.println("_____________________________USER IS ADMIN");
												userService.updateUsers();
											}
											String user_role = userService.GetUserRole(user.getRole());
											session.setAttribute("user_role", user_role);
											session.setMaxInactiveInterval(3600);
																					
											String urlLoc = rb.getString("url");
											session.setAttribute("urlLocation", urlLoc);
											// add here status and message of user service
											ActivityLogService al = ActivityLogService.getInstance();
											Map map = new HashMap();
											map.put("userId", user.getC_UserID());										
											map.put("branchCode",user.getC_BranchCode());
											map.put("ipAddress", request.getRemoteAddr());
											map.put("details", "(LOG IN) User: "+user.getC_UserID()+" has successfully log in to Factor Management System - " +status+" "+message);
											 
											XMLParser.setRequest(request);
											XMLParser.setContext(session.getServletContext());
											al.addActivityLog(map);
											response.sendRedirect(urlLoc+"/main.BDOFactor");	
											mav.setViewName("mainLayout");							
										}
										else
										{
											PrintWriter printWriter = response.getWriter();
											response.setContentType("text/plain");																	
											returnData = "{\"returnData\":[{\"message\":\"User Currently Login to another Computer!!!\"}]}";							
											printWriter.print(returnData);
											printWriter.flush();
											printWriter.close();
											
											//Log out user
											userService.getUserLoggedStatusAsOut(userID);
											ActivityLogService al = ActivityLogService.getInstance();
											Map map = new HashMap();
											map.put("userId", session.getAttribute("userID").toString());										
											map.put("branchCode",session.getAttribute("branchCode").toString());
											map.put("ipAddress", request.getRemoteAddr());
											map.put("details", "(LOG OUT) User "+session.getAttribute("userID").toString()+" has successfully log out to Factor Management System");
											al.addActivityLog(map);	
											
										}																
								}												
							}
							else 
							{
								try
								{
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");			
									if (userService.isSuspended(userID))
									{																	
										returnData = "{\"returnData\":[{\"message\":\"User Account is locked, please contact administrator.\"}]}";							
										printWriter.print(returnData);														
									}
									else
									{
										Map map = new HashMap();
										map.put("userId", userID);										
										map.put("branchCode","01");
										map.put("ipAddress", request.getRemoteAddr());
										map.put("details", "(Invalid) User: "+userID+" has tried to login using invalid credentials - "+status+" "+message);
										ActivityLogService al =  ActivityLogService.getInstance();
										
										al.addActivityLog(map);
										//userService.setNTry(userID); //?
										//userService.lockedUser(userID);	//?							
										returnData = "{\"returnData\":[{\"message\":\""+message+"\"}]}";							
										printWriter.print(returnData);
									}
									printWriter.flush();
									printWriter.close();
								}
								catch(Exception e)
								{}
							}		
						}else{//LDAPS IS DISABLED
							isStop = false;
							User user = userService.searchUser(userID, password);						
							if (user != null) 
							{				
								if (user.getC_UserName().equals(userID)) {
									
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");													
									returnData = "{\"returnData\":[{\"message\":\"Invalid Login Details.\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();
									isStop = true;
								}
								else if (userService.isPurgedUser(user.getC_UserID())) {
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");						
									returnData = "{\"returnData\":[{\"message\":\"Your account has been disabled. Please contact administrator to activate your account.\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();
									isStop = true;
								}
								else if (!userService.isUserActive(user.getC_UserID()))
								{
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");													
									returnData = "{\"returnData\":[{\"message\":\"Your account is Inactive, Please contact administrator to activate your account.\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();
									isStop = true;
								}
								else if (userService.isPasswordExpiredAndLocked(user.getC_UserID()))
								{
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");													
									returnData = "{\"returnData\":[{\"message\":\"Password expires, please contact administrator to reset your password.\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();
									isStop = true;
								}
								else if (userService.isSuspended(user.getC_UserID()))
								{
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");													
									returnData = "{\"returnData\":[{\"message\":\"Access Denied. Please contact user Administrator\"}]}";							
									printWriter.print(returnData);
									printWriter.flush();
									printWriter.close();	
									isStop = true;
								}					
								if (isStop != true) {
									String result = userService.deActivateUser(user.getC_UserID());
									if (result != null) {
										PrintWriter printWriter = response.getWriter();
										response.setContentType("text/plain");													
										returnData = "{\"returnData\":[{\"message\":\""+result+"\"}]}";							
										printWriter.print(returnData);
										printWriter.flush();
										printWriter.close();
										isStop = true;
									}
								}
								if (isStop != true) {
									String resultUnchangedPwd = userService.unchangedPwdWarning(user.getC_UserID());							
									log.info("[debug]+--->"+resultUnchangedPwd);
									if (resultUnchangedPwd != null) {																								
										PrintWriter printWriter = response.getWriter();
										response.setContentType("text/plain");													
										returnData = "{\"returnData\":[{\"message\":\""+resultUnchangedPwd+"\",\"needActivatation\":\"on\"}]}";							
										printWriter.print(returnData);
										printWriter.flush();
										printWriter.close();
										isStop = true;
									}
								}
								if (!isStop)
								{								
										boolean isLogged = true;											
										isLogged = userService.getUserLoggedStatus(userID, password);
										
										/*if (!user.getRole().equals("ADMIN"))
										{
											isLogged = userService.getUserLoggedStatus(userID, password);							
										}							
										else
										{
											isLogged = true;
										}*/
										if (isLogged)
										{
											
											userService.setUserLoginDate(userID);
											String branchName = "";
											sessionID = session.getId();
											branchName = branchService.searchBranchByCode(user.getC_BranchCode());										
											log.info("USERBRANCHCODE:" + user.getC_BranchCode());
											getUserAccess(sessionID,user.getC_UserID());
											userService.resetNTry(userID);
											securityService.parameterSetting();
											session = request.getSession(true);
											log.info("session.getId() : " + sessionID);
											session.setAttribute("userID",userID);
											session.setAttribute("userName",user.getC_UserName());
											session.setAttribute("branchCode",user.getC_BranchCode());
											session.setAttribute("branchName", branchName);
											session.setAttribute("userID", user.getC_UserID());
											session.setAttribute("sessionID", request.getSession().getId());
											session.setAttribute("userObject", user);
											System.out.print(request.getUserPrincipal());
											session.setAttribute("terminalName", request.getUserPrincipal());
											//session.setAttribute("isAdmin", user.getL_Super());
											/**
											 * Modified by: Roldan Somontin Date:10/21/2009 11:00pm
											 * Use for Process - back date
											 * */
											//session.setAttribute("isAdmin", Byte.parseByte(user.getRole().toUpperCase().equals("ADMIN")?"1":"0"));
											//End of Modification
											session.setAttribute("isAdmin", Byte.parseByte("1"));
											
											session.setAttribute("systemName",(String)systemSettingsMap.get("C_SYSTEMNAME"));
											session.setAttribute("sysVersion",(String)systemSettingsMap.get("C_VERSIONNO"));
											session.setAttribute("userRole", user.getRole());
											
											if(user.getRole().equalsIgnoreCase("admin")){
												//System.out.println("_____________________________USER IS ADMIN");
												userService.updateUsers();
											}
											String user_role = userService.GetUserRole(user.getRole());
											session.setAttribute("user_role", user_role);
											session.setMaxInactiveInterval(3600);
																					
											String urlLoc = rb.getString("url");
											session.setAttribute("urlLocation", urlLoc);
											
											ActivityLogService al = ActivityLogService.getInstance();
											Map map = new HashMap();
											map.put("userId", user.getC_UserID());										
											map.put("branchCode",user.getC_BranchCode());
											map.put("ipAddress", request.getRemoteAddr());
											map.put("details", "(LOG IN) User: "+user.getC_UserID()+" has successfully log in to Factor Management System");
											 
											XMLParser.setRequest(request);
											XMLParser.setContext(session.getServletContext());
											al.addActivityLog(map);
											response.sendRedirect(urlLoc+"/main.BDOFactor");	
											mav.setViewName("mainLayout");							
										}
										else
										{
											
											
											
											PrintWriter printWriter = response.getWriter();
											response.setContentType("text/plain");																	
											returnData = "{\"returnData\":[{\"message\":\"User Currently Login to another Computer!!!\"}]}";							
											printWriter.print(returnData);
											printWriter.flush();
											printWriter.close();
										
										
										}																
								}												
							}
							else 
							{
								try
								{
									PrintWriter printWriter = response.getWriter();
									response.setContentType("text/plain");			
									if (userService.isSuspended(userID))
									{																	
										returnData = "{\"returnData\":[{\"message\":\"User Account is locked, please contact administrator.\"}]}";							
										printWriter.print(returnData);														
									}
									else
									{
										Map map = new HashMap();
										map.put("userId", userID);										
										map.put("branchCode","01");
										map.put("ipAddress", request.getRemoteAddr());
										map.put("details", "(Invalid) User: "+userID+" has tried to login using invalid credentials");
										ActivityLogService al =  ActivityLogService.getInstance();
										
										al.addActivityLog(map);
										userService.setNTry(userID);
										userService.lockedUser(userID);								
										returnData = "{\"returnData\":[{\"message\":\"Invalid Login!!!\"}]}";							
										printWriter.print(returnData);
									}
									printWriter.flush();
									printWriter.close();
								}
								catch(Exception e)
								{}
							}	
						}// not ldaps
							
					}
				}
				/*else if(operation.trim().equalsIgnoreCase("logout")) {
					session.invalidate();
					mav.setViewName("login");
				}*/
				else if(operation.trim().equalsIgnoreCase("menu")) {
					mav.setViewName("menu");
				}	
				else if(operation.trim().equalsIgnoreCase("header")) {
					mav.setViewName("header");
				}
				else if(operation.trim().equalsIgnoreCase("logout"))
				{
					if (session.getAttribute("userID")!=null)
					{
						//UserService userService = UserService.getInstance();					
						userService.getUserLoggedStatusAsOut(session.getAttribute("userID").toString());
						ActivityLogService al = ActivityLogService.getInstance();
						Map map = new HashMap();
						map.put("userId", session.getAttribute("userID").toString());										
						map.put("branchCode",session.getAttribute("branchCode").toString());
						map.put("ipAddress", request.getRemoteAddr());
						map.put("details", "(LOG OUT) User "+session.getAttribute("userID").toString()+" has successfully log out to Factor Management System");
						al.addActivityLog(map);						
						userAccess.remove(session.getId());
						session.invalidate();
					}
					//response.sendRedirect("/login.BDOFactor?operation=view");
					mav.setViewName("login");
				}
				else {				
					if(operation.trim().equalsIgnoreCase("view")) {						
						mav.setViewName("login");
					}
					else if(operation.trim().equalsIgnoreCase("expired")) {						
						mav.setViewName("login");
					}								
				}				
		}else{			
			mav.setViewName("login");
			
		}
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView collectionsHandler(HttpServletRequest request, HttpServletResponse response) throws IOException {		
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
	
		String operation = "";
	
		if (this.isSessionActive(request)) {
			operation = request.getParameter("operation")!=null?request.getParameter("operation").trim():"";
			
				if (operation.equalsIgnoreCase("collectionsInvoice")) {											
					
					mav.setViewName("collectionsDetail");
				}
				else if (operation.equalsIgnoreCase("collectionsDetail")) {
					
					mav.setViewName("collectionsDetailB");
				}
				else if (operation.equalsIgnoreCase("collectionsHeader")) {				
					mav.setViewName("collectionsHeader");
				}
				else if (operation.equalsIgnoreCase("collectionsInvoice2")) {
				
					mav.setViewName("collectionsDetailOP");
				}
				else if (operation.equalsIgnoreCase("collectionsRefund")) {
					
					mav.setViewName("collectionsRefundDetail");
				}
				else {
					operation = "receiptsMain";
					System.out.println("set collectionsHeader..." + operation);
					
				
					mav.setViewName("receiptsMain");
				}
			}
		
			else {
				mav.setViewName("login");
			}
		
			
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(operation,sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		
		return mav;
	}

	public ModelAndView discountChargeHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("discount-charge");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView clientListingHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("client-listing");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView customerListingHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("customer-listing");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView clientCustomerListingHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("client-customer-listing");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView clientACStatusHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("client-ac-status");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView blrInquiryHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("blr-inquiry");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView customerHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("customer");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
		
	public ModelAndView adjustmentTypeHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("adjustment-type");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView adjustmentHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("adjustment");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	
	public ModelAndView branchHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("branch");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	

	public ModelAndView creditNotesHandler(HttpServletRequest request, HttpServletResponse response) {		
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			System.out.println("set creditNote");
			mav.setViewName("creditNotes");			
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView pdcHandler(HttpServletRequest request, HttpServletResponse response) {		
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			System.out.println("set PDC");
			mav.setViewName("pdc");			
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView dishonoredChecksHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("dishonoredChecks");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView initializeHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("initialize");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	
	public boolean isSessionActive(HttpServletRequest request) {
		String userName = null;
		HttpSession session=request.getSession(true);
		
		userName=(String) session.getAttribute("userName");
		if (userName != null) {
			return true;
		}
		
		return false;		
	}
	
	public void setURLLoc(HttpServletRequest request) {
		java.util.ResourceBundle rb = java.util.ResourceBundle.getBundle("/_properties/fileLocation");
		String urlLoc = rb.getString("url");
		request.setAttribute("urlLoc", urlLoc);
		
	}
	
	/** 
	 * 	Title			:	Month End Process	
	 * 	Added by		: 	Roldan Somontina
	 *  Date Inserted	:	July 4, 2009
	 *  
	 */
	
	public ModelAndView monthEndHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("monthEnd");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView refundHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("refund");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}	

	/** 
	 * 	Title			:	Day End Process	
	 * 	Added by		: 	Roldan Somontina
	 *  Date Inserted	:	July 11, 2009
	 *  
	 */
	
	public ModelAndView dayEndHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("dayEnd");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}		
	
	public ModelAndView repTableHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("repTable");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	/** 
	 * 	Title			:	Year End Process	
	 * 	Added by		: 	Roldan Somontina
	 *  Date Inserted	:	July 29, 2009
	 *  
	 */
	public ModelAndView yearEndHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("yearEnd");
		}
		else {
			mav.setViewName("login");
		}
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		String sessionID = (String)request.getSession().getId();
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}	
	
	public ModelAndView notAllowedHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("notAllowed");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView auditHandler(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("audit");
		}
		else {
			mav.setViewName("login");
		}
		
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
		
	@SuppressWarnings("unchecked")
	public List getUserAccessList(String user)
	{
		List records = new ArrayList();
		try
		{
			UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
			records         = userDao.getUserAccess(user);
		}
		catch(Throwable x)
		{x.printStackTrace();}
		
		return records;
	}
	
	@SuppressWarnings("unchecked")
	public Map getUserAccess(String sessionID, String user){
		userAccess.put(sessionID,getUserAccessList(user));
		return userAccess;  
	}

	@SuppressWarnings("unchecked")
	public boolean isSecured (String view, String sessionID) {
		boolean secured = false;
		if(sessionID==null || sessionID.isEmpty()){
			return secured;
		}
		log.info("Security sessionID/View : " + view + "/" + sessionID);
		List sessionValues = new ArrayList();
		sessionValues = (List) userAccess.get(sessionID);
		if (sessionValues!=null){
			for (int i = 0; i < sessionValues.size(); i++) {     
				if (((HashMap) sessionValues.get(i)).get("CLASS_NAME").toString().trim().equalsIgnoreCase(view.trim())) {	
					secured=true;
					break;
				}
			}
		}
		log.info("Security isSecured : " + secured);
		return secured;	
	}
	
	/*
	 * added by t_coy01
	 * 
	 * */
	
	public ModelAndView activateAccountHandler(HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView mav = new ModelAndView();
		mav.setViewName("activateAccount");
		return mav;
	}
	
	/*ACCOUNTING MODULE HANDLERS */
	public ModelAndView AccountingAdjusmentHandler(HttpServletRequest request, HttpServletResponse response){ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("acctgAdj");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView AccountingDisbursementHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("acctgDis");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView AccountingPaymentHandler(HttpServletRequest request, HttpServletResponse response){
			ModelAndView mav = new ModelAndView();	
			this.setURLLoc(request);
			
			if (this.isSessionActive(request)) {
				mav.setViewName("acctgPayments");
			}
			else {
				mav.setViewName("login");
			}
		
			//****link security check *****
			String sessionID = (String) request.getSession().getId();
			if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
			//****end - link security check *****
			response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
			//added by Cherrie Garcia for Http Only	10/07/15
			response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
			//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
			return mav;
			
		}
	
	public ModelAndView AccountingEntriesHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("acctgEntries");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	public ModelAndView AccountingReportsHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("acctgReports");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
		
	public ModelAndView PostAdvancesHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("postAdv");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView PostRefundHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("postRef");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView PostReceiptHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("postRec");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView pdoHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("pdo");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView ICBSUploadHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("icbsUpload");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView PenChargeHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("penChg");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView chartAccountHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("chartAccount");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView CostCenterHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("costCenter");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	
	public ModelAndView reportPageHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		String jasper = request.getParameter("jasperName");
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("swf");
			mav.addObject("jasper", jasper);
		}
		else {
			mav.setViewName("login");
		}
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		String sessionID = (String) request.getSession().getId();
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}
	/*ACCOUNTING MODULE HANDLERS ENDS HERE*/
	public ModelAndView testPageHandler(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mav = new ModelAndView();	
		this.setURLLoc(request);
		
		if (this.isSessionActive(request)) {
			mav.setViewName("testPage");
		}
		else {
			mav.setViewName("login");
		}
	
		//****link security check *****
		String sessionID = (String) request.getSession().getId();
		if (!isSecured(mav.getViewName(),sessionID)) {mav.setViewName("notAllowed");}
		//****end - link security check *****
		response.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		//added by Cherrie Garcia for Http Only	10/07/15
		response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure;HttpOnly");
		//response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionID + ";Secure");
		return mav;
	}

}
