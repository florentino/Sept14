package com.bdo.factor.controller;


import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.mvc.Controller;

import com.bdo.factor.beans.dataSourceAAF;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.service.AccountingMaintenanceService;
//import com.bdo.factor.service.AcctgAdjustmentService;
//import com.bdo.factor.service.AcctgAdvService;
//import com.bdo.factor.service.AcctgPaymentsService;
//import com.bdo.factor.service.AcctgRecService;
//import com.bdo.factor.service.AcctgRefService;
import com.bdo.factor.service.ActivityLogService;
import com.bdo.factor.service.AdjustmentTypeService;
import com.bdo.factor.service.AmsService;
import com.bdo.factor.service.AuditService;
import com.bdo.factor.service.BankService;
import com.bdo.factor.service.AccountOfficerService;
import com.bdo.factor.service.BLRFileService;
import com.bdo.factor.service.BLRService;
import com.bdo.factor.service.BranchService;
import com.bdo.factor.service.CCLinkService;
import com.bdo.factor.service.CNService;
import com.bdo.factor.service.ChargeTypeService;
import com.bdo.factor.service.CheckTypeService;
import com.bdo.factor.service.ClientService;
import com.bdo.factor.service.CreditNoteService;
import com.bdo.factor.service.CurrencyService;
import com.bdo.factor.service.CustomerService;
import com.bdo.factor.service.DocStampService;
import com.bdo.factor.service.GroupService;
import com.bdo.factor.service.HolidayService;
import com.bdo.factor.service.IndustryService;
import com.bdo.factor.service.InvoiceService;
import com.bdo.factor.service.MiscCodeService;
import com.bdo.factor.service.MonthlyBalancesService;
import com.bdo.factor.service.PDCService;
import com.bdo.factor.service.PDOService;
import com.bdo.factor.service.PenChgService;
import com.bdo.factor.service.PostDateService;
import com.bdo.factor.service.ReceiptsDtlService;
import com.bdo.factor.service.ReceiptsHeaderService;
import com.bdo.factor.service.ReportSubledgerService;
import com.bdo.factor.service.ServiceOfficerService;
import com.bdo.factor.service.SubHeaderService;
import com.bdo.factor.service.SystemSettingService;
import com.bdo.factor.service.UserService;
import com.bdo.factor.service.AdvancesService;
import com.bdo.factor.service.RefundService;
import com.bdo.factor.service.ReportsService;
import com.bdo.factor.service.SecurityService;
import com.bdo.factor.util.SecurityUtil;




public class BDOFactorController implements Controller
{

//////////////////////////////////////////////////////////////////////////////////////////////
	
	private HashMap servicex = null;
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	@SuppressWarnings("unchecked")
	public void init(){
		
System.out.println("--->>> INIT!!!!! ....");
		
		servicex = new HashMap(); 
		servicex.put("AccountOfficerService",AccountOfficerService.getInstance());
		servicex.put("BankService",BankService.getInstance());		
		servicex.put("BLRFileService",BLRFileService.getInstance());
		servicex.put("CheckTypeService",CheckTypeService.getInstance());
		servicex.put("CNService",CNService.getInstance());
		servicex.put("CurrencyService",CurrencyService.getInstance());
		servicex.put("GroupService",GroupService.getInstance());
		servicex.put("HolidayService",HolidayService.getInstance());
		servicex.put("IndustryService",IndustryService.getInstance());
		servicex.put("CustomerService",CustomerService.getInstance());
		servicex.put("ServiceOfficerService",ServiceOfficerService.getInstance());
		servicex.put("ClientService",ClientService.getInstance());
		servicex.put("CCLinkService",CCLinkService.getInstance());
		servicex.put("UserService",UserService.getInstance());
		servicex.put("BranchService",BranchService.getInstance());
		servicex.put("ReceiptsHeaderService",ReceiptsHeaderService.getInstance());
		servicex.put("ReceiptsDtlService",ReceiptsDtlService.getInstance());
		servicex.put("InvoiceService",InvoiceService.getInstance());
		servicex.put("CreditNoteService",CreditNoteService.getInstance());
		servicex.put("PDCService",PDCService.getInstance());
		servicex.put("AdjustmentTypeService",AdjustmentTypeService.getInstance());		
		servicex.put("SystemSettingService",SystemSettingService.getInstance());		
		servicex.put("PostDateService",PostDateService.getInstance());
		servicex.put("MonthlyBalancesService", MonthlyBalancesService.getInstance());
		servicex.put("AdvancesService",AdvancesService.getInstance());
		servicex.put("RefundService",RefundService.getInstance());
		servicex.put("ReportsService",ReportsService.getInstance());
		servicex.put("AmsService",AmsService.getInstance());
		servicex.put("SecurityService",SecurityService.getInstance());
		servicex.put("AuditService",AuditService.getInstance());
		servicex.put("ActivityLogService",ActivityLogService.getInstance());
		servicex.put("DocStampService",DocStampService.getInstance());
//		servicex.put("AcctgAdjustmentService",AcctgAdjustmentService.getInstance());
//		servicex.put("AcctgPaymentsService",AcctgPaymentsService.getInstance());
//		servicex.put("AcctgAdvService",AcctgAdvService.getInstance());
//		servicex.put("AcctgRecService",AcctgRecService.getInstance());
//		servicex.put("AcctgRefService",AcctgRefService.getInstance());
		servicex.put("PDOService",PDOService.getInstance());
		servicex.put("PenChgService",PenChgService.getInstance());
		servicex.put("AccountingMaintenanceService",AccountingMaintenanceService.getInstance());
		servicex.put("SubHeaderService",SubHeaderService.getInstance());
		servicex.put("ReportSubledgerService",ReportSubledgerService.getInstance());
		
		servicex.put("MiscCodeService",MiscCodeService.getInstance());
		
		servicex.put("BLRService", BLRService.getInstance());
		servicex.put("ChargeTypeService",ChargeTypeService.getInstance());
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		HashMap data = null;
		HashMap parameterDatum = new HashMap();
		String requestServiceClass = "";
		String requestServiceMethod = "";
		String parameterNames = "";
		
		String token = request.getHeader("x-token");
		String report_token = request.getHeader("x-repToken");
		ModelAndView modelAndview = new ModelAndView();
		
		HttpSession session = request.getSession(); 
		
		if( (session!=null && token!=null && session.getAttribute("token")!=null && token.contentEquals(session.getAttribute("token").toString()))
				||(session!=null && report_token!=null && session.getAttribute("repToken")!=null && report_token.contentEquals(session.getAttribute("repToken").toString()))){
			
			if(request.getParameter("classname")==null||request.getParameter("classmethod")==null){
				modelAndview.addObject("message", "Invalid Request");
				modelAndview.setViewName("../error/error");
				return modelAndview;
			}
			
			if(request.getParameter("classname")!=null || request.getParameter("classname").trim().length()>0){
				requestServiceClass = request.getParameter("classname");
			}
			
			if(request.getParameter("classmethod")!=null || request.getParameter("classmethod").trim().length()>0){
				requestServiceMethod = request.getParameter("classmethod");	
				if(requestServiceMethod.contains("?")){
					requestServiceMethod = requestServiceMethod.split("\\?")[0];
				}
			}
			
			System.out.println("--->>> Class: "+requestServiceClass);
			System.out.println("--->>> Method: "+requestServiceMethod);
	
			if (!servicex.containsKey(requestServiceClass)){
				//Invalid class name
 				modelAndview.addObject("message", "Invalid Request");
				modelAndview.setViewName("../error/error");
				return modelAndview;
			}
			
			for(Enumeration names = request.getParameterNames();names.hasMoreElements();){
				parameterNames = (String)names.nextElement();
				parameterDatum.put(parameterNames,request.getParameter(parameterNames));
				
				if(request.getParameter(parameterNames).contains("?")){
					parameterDatum.put("q",request.getParameter(parameterNames).split("\\?")[1].split("\\=")[1]);
				}
			}
			
			Object target = servicex.get(requestServiceClass);
			
			try{
				Method m = target.getClass().getMethod(requestServiceMethod,new Class[] {Map.class});
				data = (HashMap)m.invoke(target,parameterDatum);
			}catch(NoSuchMethodException nsme){
				//Invalid class method
				nsme.printStackTrace();  
				modelAndview.addObject("message", "Invalid Method Requested");
				modelAndview.setViewName("../error/error");
				return modelAndview;
			}catch(Exception e){
				e.printStackTrace();  
				modelAndview.addObject("message", "Server Exception Occured");
				modelAndview.setViewName("../error/error");
				return modelAndview;
			}
			
			if(data != null && data.containsKey("AUTOCOMPLETE")){
				request.setAttribute("data",data.get("AUTOCOMPLETE"));
			}else{
				request.setAttribute("data",new JSONObject(data));
			}
			
			if(data != null && data.containsKey("XML")){
				request.setAttribute("data",data.get("XML"));
				modelAndview.setViewName("xmlAjax");
			}else{
				modelAndview.setViewName("jsonAjax");
			}
			
			System.out.println("--->>> Exit-Controller...");		
		}else{
			
			modelAndview.addObject("message", "Invalid Session request");
			modelAndview.setViewName("../error/error");
			
		}
		return modelAndview;
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
		
}
