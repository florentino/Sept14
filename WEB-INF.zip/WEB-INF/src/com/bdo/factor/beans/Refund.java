package com.bdo.factor.beans;
import java.util.Date;
import java.util.Map;
public class Refund {
	private String C_BRANCHCODE;
	private int N_REFNO;
	private Date D_TRANSACTIONDATE;
	private long C_CLNTCODE;
	private long C_CUSTCODE;
	private double N_COMPUTEDAMT;
	private double N_REFAMT;
	private double N_DISCCHG;
	private double N_DISCCHGCD;
	private String C_STATUS;
	private String C_TYPE;
	private String B_CLNTRELEASE;
	
	public Refund(){
		
	}
	
	public Refund(Map map){
		
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
				this.setC_BRANCHCODE((String) map.get("C_BRANCHCODE"));
		if(map.containsKey("D_TRANSACTIONDATE") && map.get("D_TRANSACTIONDATE")!=null)
			this.setD_TRANSACTIONDATE(new Date(map.get("D_TRANSACTIONDATE").toString()));
		if(map.containsKey("C_CLNTCODE") && map.get("C_CLNTCODE")!=null)
			this.setC_CLNTCODE(Long.parseLong(map.get("C_CLNTCODE").toString()));
		if(map.containsKey("C_CUSTCODE") && map.get("C_CUSTCODE")!=null)
			this.setC_CUSTCODE(Long.parseLong(map.get("C_CUSTCODE").toString()));
		if(map.containsKey("N_COMPUTEDAMT")	&& map.get("N_COMPUTEDAMT")!=null)
			this.setN_COMPUTEDAMT(Double.parseDouble(map.get("N_COMPUTEDAMT").toString()));
		if(map.containsKey("N_REFAMT")	&& map.get("N_REFAMT")!=null)
			this.setN_REFAMT(Double.parseDouble(map.get("N_REFAMT").toString()));
		if(map.containsKey("N_DISCCHG")	&& map.get("N_DISCCHG")!=null)
			this.setN_DISCCHG(Double.parseDouble(map.get("N_DISCCHG").toString()));
		if(map.containsKey("N_DISCCHGCD")	&& map.get("N_DISCCHGCD")!=null)
			this.setN_DISCCHGCD(Double.parseDouble(map.get("N_DISCCHGCD").toString()));	
		if(map.containsKey("C_STATUS") && map.get("C_STATUS")!=null)
			this.setC_STATUS((String) map.get("C_STATUS"));
		if(map.containsKey("C_TYPE") && map.get("C_TYPE")!=null)
			this.setC_TYPE((String) map.get("C_TYPE"));
		if(map.containsKey("B_CLNTRELEASE") && map.get("B_CLNTRELEASE")!=null)
			this.setB_CLNTRELEASE(map.get("B_CLNTRELEASE").toString());
		
	}
	
	public String toString(){
		StringBuilder str = new StringBuilder();
		str.append(";C_BRANCHCODE=").append(C_BRANCHCODE);
		str.append(";N_REFNO=").append(N_REFNO);
		str.append(";D_TRANSACTIONDATE=").append(C_CLNTCODE);
		str.append(";C_CLNTCODE=").append(C_CUSTCODE);
		str.append(";C_CUSTCODE=").append(C_CUSTCODE);
		str.append(";N_COMPUTEDAMT=").append(N_COMPUTEDAMT);
		str.append(";N_REFAMT=").append(N_REFAMT);
		str.append(";N_DISCCHG=").append(N_DISCCHG);
		str.append(";N_DISCCHGCD=").append(N_DISCCHGCD);
		str.append(";C_STATUS=").append(C_STATUS);
		str.append(";C_TYPE=").append(C_TYPE);
		str.append(";B_CLNTRELEASE=").append(B_CLNTRELEASE);
				
		return str.toString();
	}
	
	
	
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}
	public void setC_BRANCHCODE(String c_branchcode) {
		C_BRANCHCODE = c_branchcode;
	}
	public int getN_REFNO() {
		return N_REFNO;
	}
	public void setN_REFNO(int n_refno) {
		N_REFNO = n_refno;
	}
	public String getB_CLNTRELEASE() {
		return B_CLNTRELEASE;
	}
	public void setB_CLNTRELEASE(String l){
		B_CLNTRELEASE = l;
	}
	public Date getD_TRANSACTIONDATE() {
		return D_TRANSACTIONDATE;
	}
	public void setD_TRANSACTIONDATE(Date d_transactiondate) {
		D_TRANSACTIONDATE = d_transactiondate;
	}
	public long getC_CLNTCODE() {
		return C_CLNTCODE;
	}
	public void setC_CLNTCODE(long c_clntcode) {
		C_CLNTCODE = c_clntcode;
	}
	public long getC_CUSTCODE() {
		return C_CUSTCODE;
	}
	public void setC_CUSTCODE(long c_custcode) {
		C_CUSTCODE = c_custcode;
	}
	public double getN_COMPUTEDAMT() {
		return N_COMPUTEDAMT;
	}
	public void setN_COMPUTEDAMT(double n_computedamt) {
		N_COMPUTEDAMT = n_computedamt;
	}
	public double getN_REFAMT() {
		return N_REFAMT;
	}
	public void setN_REFAMT(double n_refamt) {
		N_REFAMT = n_refamt;
	}
	public double getN_DISCCHG() {
		return N_DISCCHG;
	}
	public void setN_DISCCHG(double n_discchg) {
		N_DISCCHG = n_discchg;
	}
	public double getN_DISCCHGCD() {
		return N_DISCCHGCD;
	}
	public void setN_DISCCHGCD(double n_discchgcd) {
		N_DISCCHGCD = n_discchgcd;
	}
	public String getC_STATUS() {
		return C_STATUS;
	}
	public void setC_STATUS(String c_status) {
		C_STATUS = c_status;
	}
	public String getC_TYPE() {
		return C_TYPE;
	}
	public void setC_TYPE(String c_type) {
		C_TYPE = c_type;
	}
}
