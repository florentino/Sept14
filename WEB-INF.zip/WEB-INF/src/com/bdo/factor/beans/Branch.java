package com.bdo.factor.beans;

public class Branch {
	private String c_BrCode;
	private String c_BrName;
	
	public String getC_BrCode() {
		return c_BrCode;
	}

	public void setC_BrCode(String brCode) {
		c_BrCode = brCode;
	}

	public String getC_BrName() {
		return c_BrName;
	}

	public void setC_BrName(String brName) {
		c_BrName = brName;
	}

	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("BRCODE=").append(c_BrCode).append("; ");
		str.append("BRNAME=").append(c_BrName);
		
		return str.toString();
	}
	
}
