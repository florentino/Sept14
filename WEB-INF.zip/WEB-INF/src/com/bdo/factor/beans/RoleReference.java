package com.bdo.factor.beans;

import java.util.HashMap;
import java.util.Map;

public class RoleReference {
	
	private String ROLE;
	private String ROLE_DESC;
			
	public String getROLE() {
		return this.ROLE;
	}

	public void setROLE(String role) {
		ROLE = role;
	}

	public String getROLE_DESC() {
		return this.ROLE_DESC;
	}

	public void setROLE_DESC(String role_desc) {
		ROLE_DESC = role_desc;
	}

	public String toString() {
		StringBuilder strClass = new StringBuilder();
		strClass.append("ROLE=").append(ROLE);
		strClass.append(";ROLE_DESC=").append(ROLE_DESC);
		
		return strClass.toString();
	}
	
	public String toAuditString(RoleReference roleReference)
	{
		StringBuilder str = new StringBuilder();
		str.append("Role "+roleReference.ROLE+" has been updated.");
		boolean updated  = false;
		if(ROLE!=null&&!ROLE.contentEquals(roleReference.ROLE))
		{
			str.append("Role Name is changed from "+roleReference.ROLE+" to "+ROLE+". ");
			updated = true;
		}
		if(ROLE_DESC!=null&&!ROLE_DESC.contentEquals(roleReference.ROLE_DESC))
		{
			str.append("Role Description is changed from "+roleReference.ROLE_DESC+" to "+ROLE_DESC+". ");
			updated = true;
		}
		return updated?str.toString():"No action done to role "+roleReference.ROLE;
	}
	 
}
