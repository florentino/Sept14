package com.bdo.factor.beans;

import java.util.Date;

public class ActualDunningBean {
	private String c_clntName;
	private String c_custName;
	private String c_invNo;
	private double n_invAmount;
	private Date d_invDate;
	private Date d_collectDate;
	private int n_actualDunning;
	private double n_dunningAmount;
	private int count;
	private int n_median;
	private int n_mode;
	private int n_proposedDunning;
	/**
	 * @param args
	 */
	public String getC_clntName() {
		return c_clntName;
	}
	public void setC_clntName(String c_clntName) {
		this.c_clntName = c_clntName;
	}
	public String getC_custName() {
		return c_custName;
	}
	public void setC_custName(String c_custName) {
		this.c_custName = c_custName;
	}
	public String getC_invNo() {
		return c_invNo;
	}
	public void setC_invNo(String c_invNo) {
		this.c_invNo = c_invNo;
	}
	public double getN_invAmount() {
		return n_invAmount;
	}
	public void setN_invAmount(double n_invAmount) {
		this.n_invAmount = n_invAmount;
	}
	public Date getD_invDate() {
		return d_invDate;
	}
	public void setD_invDate(Date d_invDate) {
		this.d_invDate = d_invDate;
	}
	public Date getD_collectDate() {
		return d_collectDate;
	}
	public void setD_collectDate(Date d_collectDate) {
		this.d_collectDate = d_collectDate;
	}
	public int getN_actualDunning() {
		return n_actualDunning;
	}
	public void setN_actualDunning(int n_actualDunning) {
		this.n_actualDunning = n_actualDunning;
	}
	public double getN_dunningAmount() {
		return n_dunningAmount;
	}
	public void setN_dunningAmount(double n_dunningAmount) {
		this.n_dunningAmount = n_dunningAmount;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getN_median() {
		return n_median;
	}
	public void setN_median(int n_median) {
		this.n_median = n_median;
	}
	public int getN_mode() {
		return n_mode;
	}
	public void setN_mode(int n_mode) {
		this.n_mode = n_mode;
	}
	public int getN_proposedDunning() {
		return n_proposedDunning;
	}
	public void setN_proposedDunning(int n_proposedDunning) {
		this.n_proposedDunning = n_proposedDunning;
	}
	

}
