package com.bdo.factor.beans;

import java.util.HashMap;
import java.util.Map;

public class ModuleReference {
	
	private String MOD_NAME;
	private String MOD_DESC;
	private String PARENT_MOD_NAME;
	private String CLASS_ORDER;
	private String SUB_ORDER; 
			
	public String getMOD_NAME() {
		return this.MOD_NAME;
	}

	public void setMOD_NAME(String mod_name) {
		MOD_NAME = mod_name;
	}

	public String getMOD_DESC() {
		return this.MOD_DESC;
	}

	public void setMOD_DESC(String mod_desc) {
		MOD_DESC = mod_desc;
	}
	
	public String getPARENT_MOD_NAME() {
		return this.PARENT_MOD_NAME;
	}

	public void setPARENT_MOD_NAME(String parentmodname) {
		PARENT_MOD_NAME = parentmodname;
	}

	public String getCLASS_ORDER() {
		return this.CLASS_ORDER;
	}

	public void setCLASS_ORDER(String classorder) {
		CLASS_ORDER = classorder;
	}
	
	
	public String getSUB_ORDER() {
		return this.SUB_ORDER;
	}

	public void setSUB_ORDER(String suborder) {
		SUB_ORDER = suborder;
	}
	public String toString() {
		StringBuilder strModule = new StringBuilder();
		strModule.append("MOD_NAME=").append(MOD_NAME);
		strModule.append(";MOD_DESC=").append(MOD_DESC);
		strModule.append(";PARENT_MOD_NAME=").append(PARENT_MOD_NAME);
		strModule.append(";CLASS_ORDER=").append(CLASS_ORDER).toString();
		strModule.append(";SUB_ORDER=").append(SUB_ORDER).toString();

		
		return strModule.toString();
	}
	
	public String toAuditString(ModuleReference moduleReference)
	{
		StringBuilder str = new StringBuilder();
		str.append("Module Reference "+moduleReference.MOD_NAME+" has been updated. ");
		CLASS_ORDER = (CLASS_ORDER!=null&&CLASS_ORDER.contentEquals(""))?"0":CLASS_ORDER;
		SUB_ORDER = (SUB_ORDER!=null&&SUB_ORDER.contentEquals(""))?"0":SUB_ORDER;
		boolean updated =false;
		if(MOD_NAME!=null&&!MOD_NAME.contentEquals(moduleReference.MOD_NAME))
		{
			str.append("Module Name is changed from "+moduleReference.MOD_NAME+" to "+MOD_NAME+". ");
			updated=true;
		}
		if(MOD_DESC!=null&&!MOD_DESC.contentEquals(moduleReference.MOD_DESC))
		{
			str.append("Module Description is changed from "+moduleReference.MOD_DESC+" to "+MOD_DESC+". ");
			updated=true;
		}
		if(PARENT_MOD_NAME!=null&&!PARENT_MOD_NAME.contentEquals(moduleReference.PARENT_MOD_NAME))
		{
			str.append("Parent Module is changed from "+moduleReference.PARENT_MOD_NAME+" to "+PARENT_MOD_NAME+". ");
			updated=true;
		}
		if(CLASS_ORDER!=null&&!CLASS_ORDER.trim().contentEquals(moduleReference.CLASS_ORDER.trim()))
		{
			str.append("Class Order is changed from "+moduleReference.CLASS_ORDER+" to "+CLASS_ORDER+". ");
			updated=true;
		}
		if(SUB_ORDER!=null&&!SUB_ORDER.contentEquals(moduleReference.SUB_ORDER))
		{
			str.append("Sub Order is changed from "+moduleReference.SUB_ORDER+" to "+SUB_ORDER+". ");
			updated=true;
		}
		return updated?str.toString():"No action done to module"+moduleReference.MOD_NAME;
	}
	
	
}
