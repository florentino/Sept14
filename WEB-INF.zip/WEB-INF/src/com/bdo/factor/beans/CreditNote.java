package com.bdo.factor.beans;

import java.util.Date;
import java.util.Map;

import com.bdo.factor.util.DateHelper;

public class CreditNote 
{
	private String C_BRANCHCODE;
	private long N_REFNO;
	private Date D_TRANSACTIONDATE;
	private Date D_APPLICATIONDATE;
	private String C_RECEIPTNO;
	private String C_CLNTCODE;
	private String C_CUSTCODE;
	private Date D_INVOICEDATE;
	private String C_INVOICENO;
	private String C_CNTYPECODE;
	private double N_AMOUNT;
	private String C_STATUS;
	private String C_CUSTNAME;
	private String C_DESCRIPTION;
	private String C_NAME;
	private String C_USERID;
	

	public CreditNote(){
	}
	
	public CreditNote(Map map){

		/*
		this.setC_USERID(map.get("C_USERID").toString());
		this.setC_BRANCHCODE(map.get("C_BRANCHCODE").toString());
		this.setN_REFNO(new Long(map.get("N_REFNO").toString()));
		this.setD_TRANSACTIONDATE(new Date(map.get("D_TRANSACTIONDATE").toString()));
		this.setD_APPLICATIONDATE(new Date(map.get("D_APPLICATIONDATE").toString()));
		this.setC_RECEIPTNO(map.get("C_RECEIPTNO").toString());
		this.setC_CLNTCODE(map.get("C_CLNTCODE").toString());
		this.setC_CUSTCODE(map.get("C_CUSTCODE").toString());
		this.setD_INVOICEDATE(new Date(map.get("D_INVOICEDATE").toString()));
		this.setC_INVOICENO(map.get("C_INVOICENO").toString());
		this.setC_CNTYPECODE(map.get("C_CNTYPECODE").toString());
		this.setN_AMOUNT(new Double(map.get("N_AMOUNT").toString()));
		this.setC_STATUS(map.get("C_STATUS").toString());
		this.setC_CUSTNAME(map.get("C_CUSTNAME").toString());
		this.setC_DESCRIPTION(map.get("C_DESCRIPTION").toString());		
		this.setC_NAME(map.get("C_NAME").toString());
		*/
		
		if(map.containsKey("C_USERID") && map.get("C_USERID")!=null)
			this.setC_USERID(map.get("C_USERID").toString());
		
		if(map.containsKey("N_REFNO") && map.get("N_REFNO")!=null)
			this.setN_REFNO(map.get("N_REFNO") != null && map.get("N_REFNO").toString().trim().length() > 0 ? Long.parseLong(map.get("N_REFNO").toString()):0);
		
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BRANCHCODE((String) map.get("C_BRANCHCODE"));
		
		if(map.containsKey("C_CLNTCODE") && map.get("C_CLNTCODE")!=null)
			this.setC_CLNTCODE((String) map.get("C_CLNTCODE"));
		
		if(map.containsKey("C_CNTYPE") && map.get("C_CNTYPE")!=null)
			this.setC_CNTYPECODE((String) map.get("C_CNTYPE"));
		
		if(map.containsKey("C_CUSTCODE") && map.get("C_CUSTCODE")!=null)
			this.setC_CUSTCODE((String) map.get("C_CUSTCODE"));
		
		if(map.containsKey("C_INVOICENO") && map.get("C_INVOICENO")!=null)
			this.setC_INVOICENO((String) map.get("C_INVOICENO"));
		
		if(map.containsKey("C_RECEIPTNO") && map.get("C_RECEIPTNO")!=null)
			this.setC_RECEIPTNO((String) map.get("C_RECEIPTNO"));
		
		if(map.containsKey("C_STATUS") && map.get("C_STATUS")!=null)
			this.setC_STATUS((String) map.get("C_STATUS"));
		
		if(map.containsKey("D_APPLICATIONDATE") && map.get("D_APPLICATIONDATE")!=null)
			this.setD_APPLICATIONDATE(DateHelper.parse((String) map.get("D_APPLICATIONDATE")));
		
		if(map.containsKey("D_INVOICEDATE") && map.get("D_INVOICEDATE")!=null)
			this.setD_INVOICEDATE(DateHelper.parse((String) map.get("D_INVOICEDATE")));
		
		if(map.containsKey("D_TRANSACTIONDATE") && map.get("D_TRANSACTIONDATE")!=null)
			this.setD_TRANSACTIONDATE(DateHelper.parse((String) map.get("D_TRANSACTIONDATE")));
		
		if(map.containsKey("N_AMOUNT") && map.get("N_AMOUNT")!=null)
			this.setN_AMOUNT(Double.parseDouble(((String) map.get("N_AMOUNT")).replaceAll(",", "")));
		
		if(map.containsKey("C_RECEIPTNO") && map.get("C_RECEIPTNO")!=null)
			this.setC_RECEIPTNO((String) map.get("C_RECEIPTNO"));

				
	}	
	
	public String getC_NAME() {
		return C_NAME;
	}
	public void setC_NAME(String c_name) {
		C_NAME = c_name;
	}
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}
	public void setC_BRANCHCODE(String c_branchcode) {
		C_BRANCHCODE = c_branchcode;
	}
	public long getN_REFNO() {
		return N_REFNO;
	}
	public void setN_REFNO(long n_refno) {
		N_REFNO = n_refno;
	}
	public Date getD_TRANSACTIONDATE() {
		return D_TRANSACTIONDATE;
	}
	public void setD_TRANSACTIONDATE(Date d_transactiondate) {
		D_TRANSACTIONDATE = d_transactiondate;
	}
	public Date getD_APPLICATIONDATE() {
		return D_APPLICATIONDATE;
	}
	public void setD_APPLICATIONDATE(Date d_applicationdate) {
		D_APPLICATIONDATE = d_applicationdate;
	}
	public String getC_RECEIPTNO() {
		return C_RECEIPTNO;
	}
	public void setC_RECEIPTNO(String c_receiptno) {
		C_RECEIPTNO = c_receiptno;
	}
	public String getC_CLNTCODE() {
		return C_CLNTCODE;
	}
	public void setC_CLNTCODE(String c_clntcode) {
		C_CLNTCODE = c_clntcode;
	}
	public String getC_CUSTCODE() {
		return C_CUSTCODE;
	}
	public void setC_CUSTCODE(String c_custcode) {
		C_CUSTCODE = c_custcode;
	}
	public Date getD_INVOICEDATE() {
		return D_INVOICEDATE;
	}
	public void setD_INVOICEDATE(Date d_invoicedate) {
		D_INVOICEDATE = d_invoicedate;
	}
	public String getC_INVOICENO() {
		return C_INVOICENO;
	}
	public void setC_INVOICENO(String c_invoiceno) {
		C_INVOICENO = c_invoiceno;
	}
	public String getC_CNTYPECODE() {
		return C_CNTYPECODE;
	}
	public void setC_CNTYPECODE(String c_cntypecode) {
		C_CNTYPECODE = c_cntypecode;
	}
	public double getN_AMOUNT() {
		return N_AMOUNT;
	}
	public void setN_AMOUNT(double n_amount) {
		N_AMOUNT = n_amount;
	}
	public String getC_STATUS() {
		return C_STATUS;
	}
	public void setC_STATUS(String c_status) {
		C_STATUS = c_status;
	}		
	public String getC_CUSTNAME() {
		return C_CUSTNAME;
	}
	public void setC_CUSTNAME(String c_custname) {
		C_CUSTNAME = c_custname;
	}
	public String getC_DESCRIPTION() {
		return C_DESCRIPTION;
	}
	public void setC_DESCRIPTION(String c_description) {
		C_DESCRIPTION = c_description;
	}

	public String getC_USERID() {
		return C_USERID;
	}

	public void setC_USERID(String c_userid) {
		C_USERID = c_userid;
	}

	public String toString() 
	{
		StringBuilder str = new StringBuilder();
		
		str.append("C_BRANCHCODE=").append(C_BRANCHCODE);
		str.append(";C_USERID=").append(C_USERID);
		str.append(";N_REFNO=").append(N_REFNO);
		str.append(";D_TRANSACTIONDATE=").append(DateHelper.format(D_TRANSACTIONDATE));
		str.append(";D_APPLICATIONDATE=").append(DateHelper.format(D_APPLICATIONDATE));
		str.append(";C_RECEIPTNO=").append(C_RECEIPTNO);
		str.append(";C_CLNTCODE=").append(C_CLNTCODE);
		str.append(";C_CUSTCODE=").append(C_CUSTCODE);
		str.append(";D_INVOICEDATE=").append(DateHelper.format(D_INVOICEDATE));
		str.append(";C_INVOICENO=").append(C_INVOICENO);
		str.append(";C_CNTYPECODE=").append(C_CNTYPECODE);
		str.append(";N_AMOUNT=").append(N_AMOUNT);
		str.append(";C_STATUS=").append(C_STATUS);
		
		return str.toString();
	}		
	
}
