package com.bdo.factor.beans;

public class MonthlyCharges 
{
	private String   clientCode;
	private String clientName;
	private double discountCharge;
	private double cashDelay;
	private double serviceCharge;
	private double totalCharges;
	private double dcCollected;
	private double dcAccrual;
	private String accountOfficer;
	private String customerName;
	
	public String getClientCode() 
	{
		return clientCode;
	}
	public void setClientCode(String clientCode) 
	{
		this.clientCode = clientCode;
	}
	public String getClientName() 
	{
		return clientName;
	}
	public void setClientName(String clientName) 
	{
		this.clientName = clientName;
	}
	public double getDiscountCharge() 
	{
		return discountCharge;
	}
	public void setDiscountCharge(double discountCharge) 
	{
		this.discountCharge = discountCharge;
	}
	public double getCashDelay() 
	{
		return cashDelay;
	}
	public void setCashDelay(double cashDelay) 
	{
		this.cashDelay = cashDelay;
	}
	public double getServiceCharge() 
	{
		return serviceCharge;
	}
	public void setServiceCharge(double serviceCharge) 
	{
		this.serviceCharge = serviceCharge;
	}
	public double getTotalCharges() 
	{
		return totalCharges;
	}
	public void setTotalCharges(double totalCharges) 
	{
		this.totalCharges = totalCharges;
	}	
	public String getAccountOfficer() {
		return accountOfficer;
	}
	public void setAccountOfficer(String accountOfficer) {
		this.accountOfficer = accountOfficer;
	}
	public double getN_dcCollected() {
		return dcCollected;
	}
	public void setN_dcCollected(double n_dcCollected) {
		this.dcCollected = n_dcCollected;
	}
	public double getN_dcAccrual() {
		return dcAccrual;
	}
	public void setN_dcAccrual(double n_dcAccrual) {
		this.dcAccrual = n_dcAccrual;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
}
