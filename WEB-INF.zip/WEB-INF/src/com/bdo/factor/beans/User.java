package com.bdo.factor.beans;

import java.util.Date;
import java.util.Map;

public class User {
	private String c_UserID;
	private String c_BranchCode;
	private String c_UserName;
	private Date d_Issued;
	private Date d_Expired;
	private String c_PassW;
	private int n_Try;
	private byte l_Log;
	private byte l_Lock;
	private byte l_Maintain;
	private byte l_Reset;
	private byte l_Super;
	private String c_LogDtl;
	private byte isLogged;
	private String C_PasswordHistory1;
	private String C_PasswordHistory2;
	private String C_PasswordHistory3;
	private String C_PasswordHistory4;
	private String C_PasswordHistory5;
	private String role;
	private Date d_LastModified;
	private Date d_LastPassWModified;
	
	private boolean reset;

	public User(){		
	}
	
	

	public Date getD_LastModified() {
		return d_LastModified;
	}



	public void setD_LastModified(Date lastModified) {
		d_LastModified = lastModified;
	}



	public Date getD_LastPassWModified() {
		return d_LastPassWModified;
	}



	public void setD_LastPassWModified(Date lastPassWModified) {
		d_LastPassWModified = lastPassWModified;
	}



	public User(Map map){

		if(map.containsKey("C_USERID") && map.get("C_USERID")!=null)
			this.setC_UserID(map.get("C_USERID").toString());
		
		if(map.containsKey("ROLE") && map.get("ROLE")!=null)
			this.setRole(map.get("ROLE").toString());
		
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BranchCode(map.get("C_BRANCHCODE").toString());
		
		if(map.containsKey("C_USERNAME") && map.get("C_USERNAME")!=null)
			this.setC_UserName(map.get("C_USERNAME").toString());
		
		if(map.containsKey("C_PASSW") && map.get("C_PASSW")!=null)
			this.setC_PassW(map.get("C_PASSW").toString());	
		
		if(map.containsKey("L_MAINTAIN") && map.get("L_MAINTAIN")!=null){
			if(map.get("L_MAINTAIN").toString().equals("true")){
				this.setL_Maintain(new Byte("1"));	
			}else{
				this.setL_Maintain(new Byte("0"));	
			}
		}
		
		if(map.containsKey("L_SUPER") && map.get("L_SUPER")!=null){
			if(map.get("L_SUPER").toString().equals("true")){
				this.setL_Super(new Byte("1"));	
			}else{
				this.setL_Super(new Byte("0"));	
			}
		}
		
		if(map.containsKey("isLogged") && map.get("isLogged")!=null){
			if(map.get("isLogged").toString().equals("true")){
				this.setIsLogged(new Byte("1"));	
			}else{
				this.setIsLogged(new Byte("0"));	
			}
		}
		
		if(map.containsKey("C_PasswordHistory1") && map.get("C_PasswordHistory1")!=null)
			this.setC_PasswordHistory1(map.get("C_PasswordHistory1").toString());	
		
		if(map.containsKey("C_PasswordHistory2") && map.get("C_PasswordHistory2")!=null)
			this.setC_PasswordHistory2(map.get("C_PasswordHistory2").toString());
		
		if(map.containsKey("C_PasswordHistory3") && map.get("C_PasswordHistory3")!=null)
			this.setC_PassworHistory3(map.get("C_PasswordHistory3").toString());
				
	}		

	public User(Map map,boolean changePass){

		if(map.containsKey("c_UserID") && map.get("c_UserID")!=null)
			this.setC_UserID(map.get("c_UserID").toString());
		
		if(map.containsKey("con_passW") && map.get("con_passW")!=null)
			this.setC_PassW(map.get("con_passW").toString());
		
		if(map.containsKey("oldPass") && map.get("oldPass")!=null)
			this.setC_PasswordHistory1(map.get("oldPass").toString());	
				
	}	
		
	public String getC_PasswordHistory1() {
		return C_PasswordHistory1;
	}
	public void setC_PasswordHistory1(String passwordHistory1) {
		C_PasswordHistory1 = passwordHistory1;
	}
	public String getC_PasswordHistory2() {
		return C_PasswordHistory2;
	}
	public void setC_PasswordHistory2(String passwordHistory2) {
		C_PasswordHistory2 = passwordHistory2;
	}
	public String getC_PasswordHistory3() {
		return C_PasswordHistory3;
	}
	public void setC_PassworHistory3(String passwordHistory3) {
		C_PasswordHistory3 = passwordHistory3;
	}
	
	public byte getIsLogged() {
		return isLogged;
	}
	public void setIsLogged(byte isLogged) {
		this.isLogged = isLogged;
	}
	public String getC_UserID() {
		return c_UserID;
	}
	public void setC_UserID(String userID) {
		c_UserID = userID;
	}
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public String getC_UserName() {
		return c_UserName;
	}
	public void setC_UserName(String userName) {
		c_UserName = userName;
	}
	public java.util.Date getD_Issued() {
		return d_Issued;
	}
	public void setD_Issued(java.util.Date issued) {
		d_Issued = issued;
	}
	public java.util.Date getD_Expired() {
		return d_Expired;
	}
	public void setD_Expired(java.util.Date expired) {
		d_Expired = expired;
	}
	public String getC_PassW() {
		return c_PassW;
	}
	public void setC_PassW(String passW) {
		c_PassW = passW;
	}
	public int getN_Try() {
		return n_Try;
	}
	public void setN_Try(int try1) {
		n_Try = try1;
	}
	public byte getL_Log() {
		return l_Log;
	}
	public void setL_Log(byte log) {
		l_Log = log;
	}
	public byte getL_Lock() {
		return l_Lock;
	}
	public void setL_Lock(byte lock) {
		l_Lock = lock;
	}
	public byte getL_Maintain() {
		return l_Maintain;
	}
	public void setL_Maintain(byte maintain) {
		l_Maintain = maintain;
	}
	public byte getL_Reset() {
		return l_Reset;
	}
	public void setL_Reset(byte reset) {
		l_Reset = reset;
	}
	public byte getL_Super() {
		return l_Super;
	}
	public void setL_Super(byte super1) {
		l_Super = super1;
	}
	public String getC_LogDtl() {
		return c_LogDtl;
	}
	public void setC_LogDtl(String logDtl) {
		c_LogDtl = logDtl;
	}

	public String getRole() {
		return role;
	}
	public void setRole(String userRole) {
		role = userRole;
	}
	
	
	
	public String getC_PasswordHistory4() {
		return C_PasswordHistory4;
	}

	public void setC_PasswordHistory4(String passwordHistory4) {
		C_PasswordHistory4 = passwordHistory4;
	}

	public String getC_PasswordHistory5() {
		return C_PasswordHistory5;
	}

	public void setC_PasswordHistory5(String passwordHistory5) {
		C_PasswordHistory5 = passwordHistory5;
	}

	public void setC_PasswordHistory3(String passwordHistory3) {
		C_PasswordHistory3 = passwordHistory3;
	}

	public boolean isReset() {
		return reset;
	}



	public void setReset(boolean reset) {
		this.reset = reset;
	}



	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_USERID").append(c_UserID).append(";");
		str.append("C_BRANCHCODE").append(c_BranchCode).append(";");
		str.append("C_USERNAME").append(c_UserName).append(";");
		str.append("D_ISSUED").append(d_Issued).append(";");
		str.append("D_EXPIRED").append(d_Expired).append(";");
		str.append("C_PASSW").append(c_PassW).append(";");
		str.append("N_TRY").append(n_Try).append(";");
		str.append("L_LOG").append(l_Log).append(";");
		str.append("L_LOCK").append(l_Lock).append(";");
		str.append("L_MAINTAIN").append(l_Maintain).append(";");
		str.append("L_RESET").append(l_Reset).append(";");
		str.append("L_SUPER").append(l_Super).append(";");
		str.append("C_LOGDTL").append(c_LogDtl).append(";");
		str.append("isLogged").append(isLogged).append(";");
		str.append("C_PasswordHistory1").append(C_PasswordHistory1).append(";");
		str.append("C_PasswordHistory2").append(C_PasswordHistory2).append(";");
		str.append("C_PasswordHistory3").append(C_PasswordHistory3).append(";");		
		str.append("C_PasswordHistory4").append(C_PasswordHistory4).append(";");		
		str.append("C_PasswordHistory5").append(C_PasswordHistory5).append(";");		
		str.append("D_LASTMODIFIED").append(d_LastModified).append(";");		
		str.append("D_LASTPASSWMODIFIED").append(d_LastPassWModified).append(";");		
		return str.toString();
	}
	
	public String toAuditString(){
		StringBuilder str = new StringBuilder();
		str.append("C_USERID").append("=").append(c_UserID).append(";");
		str.append("C_BRANCHCODE").append("=").append(c_BranchCode).append(";");
		str.append("C_USERNAME").append("=").append(c_UserName).append(";");
		//str.append("D_ISSUED").append("=").append(d_Issued).append(";");
		//str.append("D_EXPIRED").append("=").append(d_Expired).append(";");
		str.append("C_PASSW").append("=").append(c_PassW).append(";");
		//str.append("N_TRY").append("=").append(n_Try).append(";");
		//str.append("L_LOG").append("=").append(l_Log).append(";");
		//str.append("L_LOCK").append("=").append(l_Lock).append(";");
		//str.append("L_MAINTAIN").append("=").append(l_Maintain).append(";");
		//str.append("L_RESET").append("=").append(l_Reset).append(";");
		//str.append("L_SUPER").append("=").append(l_Super).append(";");
		//str.append("C_LOGDTL").append("=").append(c_LogDtl).append(";");
		str.append("isLogged").append("=").append(isLogged).append(";");
		str.append("Role").append("=").append(role).append(";");
		//str.append("C_PasswordHistory1").append("=").append(C_PasswordHistory1).append(";");
		//str.append("C_PasswordHistory2").append("=").append(C_PasswordHistory2).append(";");
		//str.append("C_PasswordHistory3").append("=").append(C_PasswordHistory3).append(";");		
		//str.append("C_PasswordHistory4").append("=").append(C_PasswordHistory4).append(";");		
		//str.append("C_PasswordHistory5").append("=").append(C_PasswordHistory5).append(";");		
		//str.append("D_LASTMODIFIED").append("=").append(d_LastModified).append(";");		
		//str.append("D_LASTPASSWMODIFIED").append("=").append(d_LastPassWModified).append(";");		
		return str.toString();
	}
	
	public String toAuditString(User usr){
		StringBuilder str = new StringBuilder();
		str.append(usr.c_UserID+" account updated. ");
		boolean updated =false;
		if(c_UserID!=null&&!c_UserID.contentEquals(usr.c_UserID))
		{
			str.append("User Id is changed from "+usr.c_UserID+"to "+c_UserID+". ");
			updated=true;
		}
		if(c_BranchCode!=null&&!c_BranchCode.contentEquals(usr.c_BranchCode))
		{
			str.append("Branch code is changed from "+usr.c_BranchCode+" to "+c_BranchCode+". ");
			updated=true;
		}
		if(c_UserName!=null&&!c_UserName.contentEquals(usr.c_UserName))
		{
			str.append("User Name is changed from "+usr.c_UserName+" to "+c_UserName+". ");
			updated=true;
		}
		if(isLogged!=usr.isLogged)
		{
			str.append(isLogged==1?"User logged in":"User Logged out. ");
			updated=true;
		}
		if(role!=null&&!role.contentEquals(usr.role))
		{
			str.append("Role is changed from "+usr.role+" to "+role+". ");
			updated=true;
		}
		if(c_PassW!=null&&!c_PassW.contentEquals(usr.c_PassW)&&!c_PassW.isEmpty())
		{
			str.append("Password has been changed. ");
			if(!updated){
				this.setReset(true);
				updated=true;
			}
		}

		return updated?str.toString():"No action done on userID "+usr.c_UserID;
	}
	
	
}
