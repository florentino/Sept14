package com.bdo.factor.beans;

import java.util.Date;

public class CustomerStatementOfAcct 
{
	private Date tDate;
	private String description;
	private String referenceNo;
	private Date dueDate;
	private int invDue;	
	private double debit;
	private double credit;	
	private double balance;
	private String customerName;
	private String clientName;
	private int N_TERM;
	private long custCode;	
	private double receipts;
	private int receiptDue;
	private String referenceNo2;
	private Date d_actualPaidDate;
	private Date currentDate;
	
	public Date getD_actualPaidDate() {
		return d_actualPaidDate;
	}

	public void setD_actualPaidDate(Date d_actualPaidDate) {
		this.d_actualPaidDate = d_actualPaidDate;
	}

	public String getReferenceNo2() {
		return referenceNo2;
	}

	public void setReferenceNo2(String referenceNo2) {
		this.referenceNo2 = referenceNo2;
	}

	public int getReceiptDue() {
		return receiptDue;
	}

	public void setReceiptDue(int receiptDue) {
		this.receiptDue = receiptDue;
	}

	public double getReceipts() {
		return receipts;
	}

	public void setReceipts(double receipts) {
		if (Double.valueOf(receipts).toString()==null || receipts==0)
		{
			this.receipts = 0;
		}
		else
		{
			this.receipts = receipts;
		}
		
	}

	public long getCustCode() {
		return custCode;
	}

	public void setCustCode(long custCode) {
		this.custCode = custCode;
	}

	public int getInvDue() {
		return invDue;
	}

	public void setInvDue(int invDue) {
		this.invDue = invDue;
	}

	public int getN_TERM() {
		return N_TERM;
	}

	public void setN_TERM(int n_term) {
		N_TERM = n_term;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public Date getTDate() 
	{
		return tDate;
	}
	
	public void setTDate(Date date) 
	{
		tDate = date;
	}
	
	public String getDescription() 
	{
		return description;
	}
	
	public void setDescription(String description) 
	{
		this.description = description;
	}
	
	public String getReferenceNo() 
	{
		return referenceNo;
	}
	
	public void setReferenceNo(String referenceNo) 
	{
		this.referenceNo = referenceNo;
	}
	
	public Date getDueDate() 
	{
		return dueDate;
	}
	
	public void setDueDate(Date dueDate) 
	{
		this.dueDate = dueDate;
	}
	
	public double getDebit() 
	{
		return debit;
	}
	
	public void setDebit(double debit) 
	{
		this.debit = debit;
	}
	
	public double getCredit() 
	{
		return credit;
	}
	
	public void setCredit(double credit) 
	{
		this.credit = credit;
	}
	
	public double getBalance() 
	{
		return balance;
	}
	
	public void setBalance(double Balance)
	{
		this.balance = Balance;
	}
	
	public void setBalance(double credit, double debit) 
	{
		if (this.credit > this.balance)
		{
			this.balance = (this.credit - (this.balance + this.debit));
		}
		else
		{		
			this.balance = ((this.balance + this.debit) - this.credit);
		}
	}	
	
	public void setInvoiceDue(int invdue)
	{
		this.invDue = invdue;		
	}
	
	public int getInvoiceDue()
	{
		return this.invDue;		
	}
	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
}
