package com.bdo.factor.beans;

import java.util.Date;
public class ClientStatistics {	
	private String month;
	private double fiu;
	private double reserves;
	private double receivables;
	private double utilPercentage;
	private double invoiceAmount;
	private double cnAmount;
	private double crn;
	private double discountCharge;
	private double serviceCharge;
	private float dunning;
	private Date currentDate;
	
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public double getFiu() {
		return fiu;
	}
	public void setFiu(double fiu) {
		this.fiu = fiu;
	}
	public double getReserves() {
		return reserves;
	}
	public void setReserves(double reserves) {
		this.reserves = reserves;
	}
	public double getReceivables() {
		return receivables;
	}
	public void setReceivables(double receivables) {
		this.receivables = receivables;
	}
	public double getUtilPercentage() {
		return utilPercentage;
	}
	public void setUtilPercentage(double utilPercentage) {
		this.utilPercentage = utilPercentage;
	}
	public double getInvoiceAmount() {
		return invoiceAmount;
	}
	public void setInvoiceAmount(double invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	public double getCnAmount() {
		return cnAmount;
	}
	public void setCnAmount(double cnAmount) {
		this.cnAmount = cnAmount;
	}
	public double getCrn() {
		return crn;
	}
	public void setCrn(double crn) {
		this.crn = crn;
	}
	public double getDiscountCharge() {
		return discountCharge;
	}
	public void setDiscountCharge(double discountCharge) {
		this.discountCharge = discountCharge;
	}
	public double getServiceCharge() {
		return serviceCharge;
	}
	public void setServiceCharge(double serviceCharge) {
		this.serviceCharge = serviceCharge;
	}
	public float getDunning() {
		return dunning;
	}
	public void setDunning(float dunning) {
		this.dunning = dunning;
	} 
	
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	public String toString() {
		StringBuilder str = new StringBuilder();		
		str.append(";dunning=").append(dunning);
		str.append(";fiu=").append(fiu);
		str.append(";reserves=").append(reserves);
		str.append(";receivables=").append(receivables);
		str.append(";invoiceAmount=").append(invoiceAmount);
		str.append(";cnAmount=").append(cnAmount);
		str.append(";crn=").append(crn);
		str.append(";discountCharge=").append(discountCharge);
		str.append(";svcCharge=").append(serviceCharge);
		str.append(";utilPercentage=").append(utilPercentage);
		str.append(";month=").append(month);		
		return str.toString();
		
	}
}
