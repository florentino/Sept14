package com.bdo.factor.beans;

public class CheckType {
	private String c_CheckTypeCode;
	private String c_Description;
	private int n_NoOfDays;
	
	public String getC_CheckTypeCode() {
		return c_CheckTypeCode;
	}
	public void setC_CheckTypeCode(String checkTypeCode) {
		c_CheckTypeCode = checkTypeCode;
	}
	public String getC_Description() {
		return c_Description;
	}
	public void setC_Description(String description) {
		c_Description = description;
	}
	public int getN_NoOfDays() {
		return n_NoOfDays;
	}
	public void setN_NoOfDays(int noOfDays) {
		n_NoOfDays = noOfDays;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_CHECKTYPECODE=").append(c_CheckTypeCode);
		str.append(";C_DESCRIPTION=").append(c_Description);
		str.append(";N_NOOFDAYS=").append(n_NoOfDays);
		
		return str.toString();
	}
	
}
