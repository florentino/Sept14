package com.bdo.factor.beans;

import java.util.Map;




public class SystemSettings 
{
	private int    N_SETUPFEE = 0;
	private String C_BANKACCOUNT = "";
	private String C_APPROVER = "";
	private String C_COMPANYNAME= "";
	private String C_COMPANYSHORTNAME = "";
	private String C_ADDRESS1 = "";
	private String C_ADDRESS2 = "";
	private String C_ADDRESS3 = "";
	private String C_CURRENCYCODE = "";
	private String C_SYSTEMNAME = "";
	private int    N_CURRADJ = 0;
	private int    N_PASSWORDEXP = 0;
	private String C_BANKCODE;
	private String C_DEFID = "";
	private String C_DEFPASS = "";
	
	
	
	private String C_BM;
	private String C_BANKNAME; 
	private String C_ADDRESS;
		
	
	public SystemSettings(){
		
	}
	
	public SystemSettings(Map map){

		if(map.containsKey("N_SETUPFEE") && map.get("N_SETUPFEE")!=null)
			this.setN_SETUPFEE(Integer.parseInt(map.get("N_SETUPFEE").toString()));
		
		if(map.containsKey("C_BANKACCOUNT") && map.get("C_BANKACCOUNT")!=null)
			this.setC_BANKACCOUNT(map.get("C_BANKACCOUNT").toString());
		
		if(map.containsKey("C_APPROVER") && map.get("C_APPROVER")!=null)
			this.setC_APPROVER(map.get("C_APPROVER").toString());
		
		if(map.containsKey("C_COMPANYNAME") && map.get("C_COMPANYNAME")!=null)
			this.setC_COMPANYNAME(map.get("C_COMPANYNAME").toString());
		
		if(map.containsKey("C_COMPANYSHORTNAME") && map.get("C_COMPANYSHORTNAME")!=null)
			this.setC_COMPANYSHORTNAME(map.get("C_COMPANYSHORTNAME").toString());
		
		if(map.containsKey("C_ADDRESS1") && map.get("C_ADDRESS1")!=null)
			this.setC_ADDRESS1(map.get("C_ADDRESS1").toString());
		
		if(map.containsKey("C_ADDRESS2") && map.get("C_ADDRESS2")!=null)
			this.setC_ADDRESS2(map.get("C_ADDRESS2").toString());
		
		if(map.containsKey("C_ADDRESS3") && map.get("C_ADDRESS3")!=null)
			this.setC_ADDRESS3(map.get("C_ADDRESS3").toString());
		
		if(map.containsKey("C_CURRENCYCODE") && map.get("C_CURRENCYCODE")!=null)
			this.setC_CURRENCYCODE(map.get("C_CURRENCYCODE").toString());
		
		if(map.containsKey("C_SYSTEMNAME") && map.get("C_SYSTEMNAME")!=null)
			this.setC_SYSTEMNAME(map.get("C_SYSTEMNAME").toString());
		
		if(map.containsKey("N_CURRADJ") && map.get("N_CURRADJ")!=null)
			this.setN_CURRADJ(Integer.parseInt(map.get("N_CURRADJ").toString()));
		
		if(map.containsKey("N_PASSWORDEXP") && map.get("N_PASSWORDEXP")!=null)
			this.setN_PASSWORDEXP(Integer.parseInt(map.get("N_PASSWORDEXP").toString()));
		
		if(map.containsKey("C_BANKCODE") && map.get("C_BANKCODE")!=null)
			this.setC_BANKCODE(map.get("C_BANKCODE").toString());
		if(map.containsKey("C_DEFID") && map.get("C_DEFID")!=null)
			this.setC_DEFID(map.get("C_DEFID").toString());
		if(map.containsKey("C_DEFPASS") && map.get("C_DEFPASS")!=null)
			this.setC_DEFPASS(map.get("C_DEFPASS").toString());
		
	}	
	
	
	
	public String getC_BANKCODE() {
		return C_BANKCODE;
	}
	public void setC_BANKCODE(String c_bankcode) {
		C_BANKCODE = c_bankcode;
	}
	public int getN_SETUPFEE() 
	{
		return N_SETUPFEE;
	}
	public void setN_SETUPFEE(int n_setupfee) 
	{
		N_SETUPFEE = n_setupfee;
	}
	public String getC_BANKACCOUNT() 
	{
		return C_BANKACCOUNT;
	}
	public void setC_BANKACCOUNT(String c_bankaccount) 
	{
		C_BANKACCOUNT = c_bankaccount;
	}
	public String getC_APPROVER() 
	{
		return C_APPROVER;
	}
	public void setC_APPROVER(String c_approver) 
	{
		C_APPROVER = c_approver;
	}
	public String getC_COMPANYNAME() {
		return C_COMPANYNAME;
	}
	public void setC_COMPANYNAME(String c_companyname) {
		C_COMPANYNAME = c_companyname;
	}
	public String getC_COMPANYSHORTNAME() {
		return C_COMPANYSHORTNAME;
	}
	public void setC_COMPANYSHORTNAME(String c_companyshortname) {
		C_COMPANYSHORTNAME = c_companyshortname;
	}
	public String getC_ADDRESS1() {
		return C_ADDRESS1;
	}
	public void setC_ADDRESS1(String c_address1) {
		C_ADDRESS1 = c_address1;
	}
	public String getC_ADDRESS2() {
		return C_ADDRESS2;
	}
	public void setC_ADDRESS2(String c_address2) 
	{
		C_ADDRESS2 = c_address2;
	}
	public String getC_ADDRESS3() 
	{
		return C_ADDRESS3;
	}
	public void setC_ADDRESS3(String c_address3) 
	{
		C_ADDRESS3 = c_address3;
	}
	public String getC_CURRENCYCODE() 
	{
		return C_CURRENCYCODE;
	}
	public void setC_CURRENCYCODE(String c_currencycode) 
	{
		C_CURRENCYCODE = c_currencycode;
	}
	public String getC_SYSTEMNAME() 
	{
		return C_SYSTEMNAME;
	}
	public void setC_SYSTEMNAME(String c_systemname) 
	{
		C_SYSTEMNAME = c_systemname;
	}
	public int getN_CURRADJ() 
	{
		return N_CURRADJ;
	}
	public void setN_CURRADJ(int n_curradj) 
	{
		N_CURRADJ = n_curradj;
	}
	public int getN_PASSWORDEXP() 
	{
		return N_PASSWORDEXP;
	}
	public void setN_PASSWORDEXP(int n_passwordexp) 
	{
		N_PASSWORDEXP = n_passwordexp;
	}
	public String getC_DEFID() 
	{
		return C_DEFID;
	}
	public void setC_DEFID(String c_defid) 
	{
		C_DEFID = c_defid;
	}
	public String getC_DEFPASS() 
	{
		return C_DEFPASS;
	}
	public void setC_DEFPASS(String c_defpass) 
	{
		C_DEFPASS = c_defpass;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() 
	{
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder();
		str.append("N_SETUPFEE=").append(this.N_SETUPFEE);
		str.append(";C_BANKACCOUNT=").append(this.C_BANKACCOUNT);
		str.append(";C_APPROVER=").append(this.C_APPROVER);
		str.append(";C_COMPANYNAME=").append(this.C_COMPANYNAME);
		str.append(";C_COMPANYSHORTNAME=").append(this.C_COMPANYSHORTNAME);
		str.append(";C_ADDRESS1=").append(this.C_ADDRESS1);
		str.append(";C_ADDRESS2=").append(this.C_ADDRESS2);
		str.append(";C_ADDRESS3=").append(this.C_ADDRESS3);
		str.append(";C_CURRENCYCODE=").append(this.C_CURRENCYCODE);
		str.append(";C_SYSTEMNAME=").append(this.C_SYSTEMNAME);
		str.append(";N_CURRADJ=").append(this.N_CURRADJ);
		str.append(";N_PASSWORDEXP=").append(this.N_PASSWORDEXP);
		str.append(";C_BANKCODE=").append(this.C_BANKCODE);
		return str.toString();
	}

	public String getC_BM() {
		return C_BM;
	}

	public void setC_BM(String c_bm) {
		C_BM = c_bm;
	}

	public String getC_BANKNAME() {
		return C_BANKNAME;
	}

	public void setC_BANKNAME(String c_bankname) {
		C_BANKNAME = c_bankname;
	}

	public String getC_ADDRESS() {
		return C_ADDRESS;
	}

	public void setC_ADDRESS(String c_address) {
		C_ADDRESS = c_address;
	}		
}
