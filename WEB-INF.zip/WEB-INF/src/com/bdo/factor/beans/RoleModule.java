package com.bdo.factor.beans;

import java.util.HashMap;
import java.util.Map;

public class RoleModule {
	
	private String ROLE;
	private String MOD_NAME;
			
	public String getROLE() {
		return this.ROLE;
	}

	public void setROLE(String role) {
		ROLE = role;
	}

	public String getMOD_NAME() {
		return this.MOD_NAME;
	}

	public void setMOD_NAME(String mod_name) {
		MOD_NAME = mod_name;
	}

	public String toString() {
		StringBuilder strClass = new StringBuilder();
		strClass.append("ROLE=").append(ROLE);
		strClass.append(";MOD_NAME=").append(MOD_NAME);
		
		return strClass.toString();
	}
	
	public String auditString(RoleModule roleModule)
	{
		StringBuilder str = new StringBuilder();
		str.append("Role "+roleModule.ROLE+" and module "+roleModule.MOD_NAME+" has been updated. ");
		boolean updated = false;
		if(ROLE!=null&&!ROLE.contentEquals(roleModule.ROLE))
		{
			str.append("Role Name is changed from "+roleModule.ROLE+" to "+ROLE+". ");
			updated = true;
		}
		if(MOD_NAME!=null&&!MOD_NAME.contentEquals(roleModule.MOD_NAME))
		{
			str.append("Module Name is changed from "+roleModule.MOD_NAME+" to "+MOD_NAME+". ");
			updated = true;
		}
		return updated?str.toString():"No action done to role "+roleModule.ROLE+" with module "+roleModule.MOD_NAME;
	}
	
	
}
