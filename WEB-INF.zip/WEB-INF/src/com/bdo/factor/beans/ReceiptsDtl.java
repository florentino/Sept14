package com.bdo.factor.beans;

import com.bdo.factor.util.DateHelper;

public class ReceiptsDtl {
	private String c_BranchCode;
	private int n_RefNo;
	private String c_InvoiceNo;
	private int n_InvNo;
	private java.util.Date d_InvoiceDate;
	private double n_AmtInv;
	private double n_ReceiptAmt;
	private String c_Type;
	
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public int getN_RefNo() {
		return n_RefNo;
	}
	public void setN_RefNo(int refNo) {
		n_RefNo = refNo;
	}
	public String getC_InvoiceNo() {
		return c_InvoiceNo;
	}
	public void setC_InvoiceNo(String invoiceNo) {
		c_InvoiceNo = invoiceNo;
	}
	public java.util.Date getD_InvoiceDate() {
		return d_InvoiceDate;
	}
	public void setD_InvoiceDate(java.util.Date invoiceDate) {
		d_InvoiceDate = invoiceDate;
	}
	public double getN_AmtInv() {
		return n_AmtInv;
	}
	public void setN_AmtInv(double amtInv) {
		n_AmtInv = amtInv;
	}
	public double getN_ReceiptAmt() {
		return n_ReceiptAmt;
	}
	public void setN_ReceiptAmt(double receiptAmt) {
		n_ReceiptAmt = receiptAmt;
	}
	public String getC_Type() {
		return c_Type;
	}
	public void setC_Type(String type) {
		c_Type = type;
	}		
	public int getN_InvNo() {
		return n_InvNo;
	}
	public void setN_InvNo(int invNo) {
		n_InvNo = invNo;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(c_BranchCode);
		str.append(";N_REFNO=").append(n_RefNo);
		str.append(";C_INVOICENO=").append(c_InvoiceNo);
		str.append(";N_INVNO=").append(n_InvNo);
		str.append(";D_INVOICEDATE=").append(DateHelper.format(d_InvoiceDate));
		str.append(";N_AMTINV=").append(n_AmtInv);
		str.append(";N_RECEIPTAMT=").append(n_ReceiptAmt);
		str.append(";C_TYPE=").append(c_Type);
		
		return str.toString();
	}

}
