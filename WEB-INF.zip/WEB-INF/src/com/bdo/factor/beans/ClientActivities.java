package com.bdo.factor.beans;

import java.util.Date;

public class ClientActivities {
	
	private String clientCode;
	private Client client;
	private BLR blrFile;
	
	//column
	private Date transactionDate;
	private String definition;	
	private String ref;
	private double receivables;
	private double reserves;	
	private double fiuTransaction;
	private double fiuBalance;
	//summary
	private double invoices;
	private double serviceCharges;
	private double creditNotes;
	private double receipts;
	private double advances;
	private double refunds;
	private double discountCharges;
	private double dcOnCashDelays;
	private double setupFee;
	private double docStamp;
	
	//added by CVG 03-04-16
	private double notarialFee;
	
	//Added for CISA Extraction
	private int PenaltyCount;
	
	private double pastDueInvoices;
	private double penaltyCollected;
	private double pastDueCollected;
	private double pastDueFR;

	private double dcCollected;
	private double overpayment;
	private double receiptAdvance;
	private double receiptRefund;
	private double dshnrdChks;
	private double cnCancelled;
	
	private double totalReceivables;
	private double totalReserves;	
	private double totalFiuTransaction;
	private double totalFiuBalance;
	
	private double dcAccrual;
	
	private Date startDate;
	private Date currentDate;
	private String month;
	private String clientName;
	

	public ClientActivities() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getDefinition() {
		return definition;
	}

	public void setDefinition(String definition) {
		this.definition = definition;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public double getReserves() {
		return reserves;
	}

	public void setReserves(double reserves) {
		this.reserves = reserves;
	}

	public double getReceivables() {
		return receivables;
	}

	public void setReceivables(double receivables) {
		this.receivables = receivables;
	}

	public double getFiuTransaction() {
		return fiuTransaction;
	}

	public void setFiuTransaction(double fiuTransaction) {
		this.fiuTransaction = fiuTransaction;
	}

	public double getFiuBalance() {
		return fiuBalance;
	}

	public void setFiuBalance(double fiuBalance) {
		this.fiuBalance = fiuBalance;
	}

	public double getInvoices() {
		return invoices;
	}

	public void setInvoices(double invoices) {
		this.invoices = invoices;
	}

	public double getServiceCharges() {
		return serviceCharges;
	}

	public void setServiceCharges(double serviceCharges) {
		this.serviceCharges = serviceCharges;
	}

	public double getCreditNotes() {
		return creditNotes;
	}

	public void setCreditNotes(double creditNotes) {
		this.creditNotes = creditNotes;
	}

	public double getReceipts() {
		return receipts;
	}

	public void setReceipts(double receipts) {
		this.receipts = receipts;
	}

	public double getAdvances() {
		return advances;
	}

	public void setAdvances(double advances) {
		this.advances = advances;
	}

	public double getRefunds() {
		return refunds;
	}

	public void setRefunds(double refunds) {
		this.refunds = refunds;
	}

	public double getDiscountCharges() {
		return discountCharges;
	}

	public void setDiscountCharges(double discountCharges) {
		this.discountCharges = discountCharges;
	}

	public double getDcOnCashDelays() {
		return dcOnCashDelays;
	}

	public void setDcOnCashDelays(double dcOnCashDelays) {
		this.dcOnCashDelays = dcOnCashDelays;
	}

	public String getClientCode() {
		return clientCode;
	}

	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public double getTotalReceivables() {
		return totalReceivables;
	}

	public void setTotalReceivables(double totalReceivables) {
		this.totalReceivables = totalReceivables;
	}

	public double getTotalReserves() {
		return totalReserves;
	}

	public void setTotalReserves(double totalReserves) {
		this.totalReserves = totalReserves;
	}

	public double getTotalFiuTransaction() {
		return totalFiuTransaction;
	}

	public void setTotalFiuTransaction(double totalFiuTransaction) {
		this.totalFiuTransaction = totalFiuTransaction;
	}

	public double getTotalFiuBalance() {
		return totalFiuBalance;
	}

	public void setTotalFiuBalance(double totalFiuBalance) {
		this.totalFiuBalance = totalFiuBalance;
	}

	public BLR getBlrFile() {
		return blrFile;
	}

	public void setBlrFile(BLR blrFile2) {
		this.blrFile = blrFile2;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public double getSetupFee() {
		return setupFee;
	}

	public void setSetupFee(double setupFee) {
		this.setupFee = setupFee;
	}
	
	public double getDocStamp() {
		return docStamp;
	}

	public void setDocStamp(double docStamp) {
		this.docStamp = docStamp;
	}
	
	public double getDcCollected() {
		return dcCollected;
	}
	
	public double getDshnrdChks(){
		return dshnrdChks;
	}
	
	public void setDshnrdChks(double dshnrdChks){
		this.dshnrdChks = dshnrdChks;
	}
	
	public double getCnCancelled(){
		return cnCancelled;
	}
	
	public void setCnCancelled(double cnCancelled){
		this.cnCancelled = cnCancelled;
	}

	public void setDcCollected(double dcCollected) {
		this.dcCollected = dcCollected;
	}
	public double getOverpayment() {
		return overpayment;
	}

	public void setOverpayment(double overpayment) {
		this.overpayment = overpayment;
	}
	public double getReceiptAdvance() {
		return receiptAdvance;
	}

	public void setReceiptAdvance(double receiptAdvance) {
		this.receiptAdvance = receiptAdvance;
	}
	public double getReceiptRefund() {
		return receiptRefund;
	}

	public void setReceiptRefund(double receiptRefund) {
		this.receiptRefund = receiptRefund;
	}

	public double getPastDueInvoices() {
		return pastDueInvoices;
	}

	public void setPastDueInvoices(double pastDueInvoices) {
		this.pastDueInvoices = pastDueInvoices;
	}

	public double getPenaltyCollected() {
		return penaltyCollected;
	}

	public void setPenaltyCollected(double penaltyCollected) {
		this.penaltyCollected = penaltyCollected;
	}

	
	public double getPastDueCollected() {
		return pastDueCollected;
	}

	public void setPastDueCollected(double pastDueCollected) {
		this.pastDueCollected = pastDueCollected;
	}

	
	public double getPastDueFR() {
		return pastDueFR;
	}

	
	public void setPastDueFR(double pastDueFR) {
		this.pastDueFR = pastDueFR;
	}

	public double getDcAccrual() {
		return dcAccrual;
	}

	public void setDcAccrual(double dcAccrual) {
		this.dcAccrual = dcAccrual;
	}


	//added by CVG as of 03-04-16
	public double getNotarialFee() {
		return notarialFee;
	}

	public void setNotarialFee(double notarialFee) {
		this.notarialFee = notarialFee;
	}

	public int getPenaltyCount() {
		return PenaltyCount;
	}

	public void setPenaltyCount(int penaltyCount) {
		PenaltyCount = penaltyCount;
	}

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	
	public String getClientName() {
		return clientName;
	}
	
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

}
