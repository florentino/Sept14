package com.bdo.factor.beans;

public class ParameterSettings {
	
	
	String defaultpasswd;
	int useridmin;
	int passwdmin;
	int passwdexpire;
	int passwdwarning;		
	int deactivate;
	int disable;
	int purging;
	int n_try;
	int passwdhistory;
	int sessionTimeout;
	
	public String getDefaultpasswd() {
		return defaultpasswd;
	}
	public void setDefaultpasswd(String defaultpasswd) {
		this.defaultpasswd = defaultpasswd;
	}
	public int getUseridmin() {
		return useridmin;
	}
	public void setUseridmin(int useridmin) {
		this.useridmin = useridmin;
	}
	public int getPasswdmin() {
		return passwdmin;
	}
	public void setPasswdmin(int passwdmin) {
		this.passwdmin = passwdmin;
	}
	public int getPasswdexpire() {
		return passwdexpire;
	}
	public void setPasswdexpire(int passwdexpire) {
		this.passwdexpire = passwdexpire;
	}
	public int getPasswdwarning() {
		return passwdwarning;
	}
	public void setPasswdwarning(int passwdwarning) {
		this.passwdwarning = passwdwarning;
	}
	public int getDeactivate() {
		return deactivate;
	}
	public void setDeactivate(int deactivate) {
		this.deactivate = deactivate;
	}
	public int getDisable() {
		return disable;
	}
	public void setDisable(int disable) {
		this.disable = disable;
	}
	public int getPurging() {
		return purging;
	}
	public void setPurging(int purging) {
		this.purging = purging;
	}
	public int getN_try() {
		return n_try;
	}
	public void setN_try(int n_try) {
		this.n_try = n_try;
	}
	public int getPasswdhistory() {
		return passwdhistory;
	}
	public void setPasswdhistory(int passwdhistory) {
		this.passwdhistory = passwdhistory;
	}
	public int getSessionTimeout() {
		return sessionTimeout;
	}
	public void setSessionTimeout(int sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}
	
	public String toAuditString(ParameterSettings parameterSettings){
		StringBuilder str = new StringBuilder();
		boolean update = false;
		if(defaultpasswd!=null&&!defaultpasswd.contentEquals(parameterSettings.defaultpasswd))
		{
			str.append("Default Password is changed from "+parameterSettings.defaultpasswd+" to "+defaultpasswd+". ");
			update = true;
		}
		if(useridmin!=parameterSettings.useridmin)
		{
			str.append("Minimum User Id length is changed from "+parameterSettings.useridmin+" to "+useridmin+". ");
			update = true;
		}
		if(passwdmin!=parameterSettings.passwdmin)
		{
			str.append("Minimum Password Id length is changed from "+parameterSettings.passwdmin+" to "+passwdmin+". ");
			update = true;
		}
		if(passwdexpire!=parameterSettings.passwdexpire)
		{
			str.append("Password Expiration is changed from "+parameterSettings.passwdexpire+" to "+passwdexpire+". ");
			update = true;
		}
		if(passwdwarning!=parameterSettings.passwdwarning)
		{
			str.append("Password Warning is changed from "+parameterSettings.passwdwarning+" to "+passwdwarning+". ");
			update = true;
		}
		if(deactivate!=parameterSettings.deactivate)
		{
			str.append("Deactivation period from last login is changed from "+parameterSettings.deactivate+" to "+deactivate+". ");
			update = true;
		}
		if(disable!=parameterSettings.disable)
		{
			str.append("Activation period is changed from "+parameterSettings.disable+" to "+disable+". ");
			update = true;
		}
		if(purging!=parameterSettings.purging)
		{
			str.append("User Id purging is changed from "+parameterSettings.purging+" to "+purging+". ");
			update = true;
		}
		if(n_try!=parameterSettings.n_try)
		{
			str.append("Number of tries is changed from "+parameterSettings.n_try+" to "+n_try+". ");
			update = true;
		}
		if(passwdhistory!=parameterSettings.passwdhistory)
		{
			str.append("Number of Password History is changed from "+parameterSettings.passwdhistory+" to "+passwdhistory+". ");
			update = true;
		}
		if(sessionTimeout!=parameterSettings.sessionTimeout)
		{
			str.append("Session Timeout is changed from "+parameterSettings.sessionTimeout+" to "+sessionTimeout+". ");
			update = true;
		}
		return update?str.toString():"No action done to parameter settings";
	}
	 
 

}
