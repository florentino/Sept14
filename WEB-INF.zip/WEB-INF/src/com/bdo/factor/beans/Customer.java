package com.bdo.factor.beans;

import java.util.Map;

public class Customer {
	private String c_BranchCode;
	private String c_CustCode;
	private String c_CustName;
	private String c_Address;
	private String c_Contact;
	private String c_TelNo;
	private String c_RocNo;
	private String c_IndCode;
	private String c_BankCode;
	private String c_BankAcct;
	private String c_Group;
	private int n_CuLimit;
	private String c_CollectContact;
	

	public Customer(){
	}

	public Customer(Map map){

		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		
		if(map.containsKey("C_ADDRESS") && map.get("C_ADDRESS")!=null)
			this.setC_Address((String) map.get("C_ADDRESS"));
		
		if(map.containsKey("C_BANKACCT") && map.get("C_BANKACCT")!=null)
			this.setC_BankAcct((String) map.get("C_BANKACCT"));
		
		if(map.containsKey("C_BANKCODE") && map.get("C_BANKCODE")!=null)
			this.setC_BankCode((String) map.get("C_BANKCODE"));
		
		if(map.containsKey("C_CONTACT") && map.get("C_CONTACT")!=null)
			this.setC_Contact((String) map.get("C_CONTACT"));
		
		if(map.containsKey("C_CUSTCODE") && map.get("C_CUSTCODE")!=null)
			this.setC_CustCode((String) map.get("C_CUSTCODE"));
		
		if(map.containsKey("C_CUSTNAME") && map.get("C_CUSTNAME")!=null)
			this.setC_CustName((String) map.get("C_CUSTNAME"));
		
		if(map.containsKey("C_GROUP") && map.get("C_GROUP")!=null)
			this.setC_Group((String) map.get("C_GROUP"));
		
		if(map.containsKey("C_INDCODE") && map.get("C_INDCODE")!=null)
			this.setC_IndCode((String) map.get("C_INDCODE"));
		
		if(map.containsKey("C_BREGNO") && map.get("C_BREGNO")!=null)
			this.setC_RocNo((String) map.get("C_BREGNO"));
		
		if(map.containsKey("C_TELNO") && map.get("C_TELNO")!=null)
			this.setC_TelNo((String) map.get("C_TELNO"));
		
		if(map.containsKey("N_CULIMIT") && map.get("N_CULIMIT")!=null){
			if(map.get("N_CULIMIT")!=null && map.get("N_CULIMIT").toString().trim().length()>0){
				this.setN_CuLimit(Integer.parseInt(map.get("N_CULIMIT").toString()));
			}		
		}
		
		if(map.containsKey("C_COLLECTCONTACT") && map.get("C_COLLECTCONTACT") !=null){
			this.setC_CollectContact((String) map.get("C_COLLECTCONTACT"));
			
		}
		
	}
	
	
	
	/*	Added by:Roldan Somontina
	 * 	Dated: June 08, 2009
	 * */
	private long c_Dunning; 
	
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public String getC_CustCode() {
		return c_CustCode;
	}
	public void setC_CustCode(String custCode) {
		c_CustCode = custCode;
	}
	public String getC_CustName() {
		return c_CustName;
	}
	public void setC_CustName(String custName) {
		c_CustName = custName;
	}
	public String getC_Address() {
		return c_Address;
	}
	public void setC_Address(String address) {
		c_Address = address;
	}
	public String getC_Contact() {
		return c_Contact;
	}
	public void setC_Contact(String contact) {
		c_Contact = contact;
	}
	public String getC_TelNo() {
		return c_TelNo;
	}
	public void setC_TelNo(String telNo) {
		c_TelNo = telNo;
	}
	public String getC_RocNo() {
		return c_RocNo;
	}
	public void setC_RocNo(String rocNo) {
		c_RocNo = rocNo;
	}
	public String getC_IndCode() {
		return c_IndCode;
	}
	public void setC_IndCode(String indCode) {
		c_IndCode = indCode;
	}
	public String getC_BankCode() {
		return c_BankCode;
	}
	public void setC_BankCode(String bankCode) {
		c_BankCode = bankCode;
	}
	public String getC_BankAcct() {
		return c_BankAcct;
	}
	public void setC_BankAcct(String bankAcct) {
		c_BankAcct = bankAcct;
	}
	public String getC_Group() {
		return c_Group;
	}
	public void setC_Group(String group) {
		c_Group = group;
	}
	public int getN_CuLimit() {
		return n_CuLimit;
	}
	public void setN_CuLimit(int cuLimit) {
		n_CuLimit = cuLimit;
	}
	public String getC_CollectContact() {
		return c_CollectContact;
	}
	public void setC_CollectContact(String collectContact) {
		c_CollectContact = collectContact;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(c_BranchCode);
		str.append(";C_CUSTCODE=").append(c_CustCode);
		str.append(";C_CUSTNAME=").append(c_CustName);
		str.append(";C_ADDRESS=").append(c_Address);
//		str.append(";C_CONTACT=").append(c_Contact);
//		str.append(";C_TELNO=").append(c_TelNo);
//		str.append(";C_BREGNO=").append(c_RocNo);
		str.append(";C_INDCODE=").append(c_IndCode);
//		str.append(";C_BANKCODE=").append(c_BankCode);
//		str.append(";C_BANKACCT=").append(c_BankAcct);
		str.append(";C_GROUPCODE=").append(c_Group);
//		
//		str.append(";N_CULIMIT=").append(n_CuLimit);
		str.append(";C_COLLECTCONTACT=").append(c_CollectContact);
		return str.toString();
	}
	public long getC_Dunning() {
		return c_Dunning;
	}
	public void setC_Dunning(long dunning) {
		c_Dunning = dunning;
	}
}
