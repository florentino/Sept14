package com.bdo.factor.beans;

import java.util.HashMap;
import java.util.Map;

public class ModuleClass {
	
	private String MOD_NAME;
	private String CLASS_NAME;
			
	public String getMOD_NAME() {
		return this.MOD_NAME;
	}

	public void setMOD_NAME(String mod_name) {
		MOD_NAME = mod_name;
	}

	public String getCLASS_NAME() {
		return this.CLASS_NAME;
	}

	public void setCLASS_NAME(String class_name) {
		CLASS_NAME = class_name;
	}

	public String toString() {
		StringBuilder strModule = new StringBuilder();
		strModule.append("MOD_NAME=").append(MOD_NAME);
		strModule.append(";CLASS_NAME=").append(CLASS_NAME);
		
		return strModule.toString();
	}
	
	public String toAuditString(ModuleClass moduleClass)
	{
		StringBuilder str = new StringBuilder();
		str.append("Module "+moduleClass.MOD_NAME+" and Class "+moduleClass.CLASS_NAME+" has been updated. ");
		boolean updated = false;
		if(MOD_NAME!=null&&!MOD_NAME.contentEquals(moduleClass.MOD_NAME))
		{
			str.append("Module Name is changed from "+moduleClass.MOD_NAME+" to "+MOD_NAME+". ");
			updated =true;
		}
		if(CLASS_NAME!=null&&!CLASS_NAME.contentEquals(moduleClass.CLASS_NAME))
		{
			str.append("Class Name is changed from "+moduleClass.CLASS_NAME+" to "+CLASS_NAME+". ");
			updated =true;
		}
		return updated?str.toString():"No action done to module "+moduleClass.MOD_NAME+" with Class "+moduleClass.CLASS_NAME;
	}
	
	
}
