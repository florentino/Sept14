package com.bdo.factor.beans;

import java.util.Date;

public class AMS {
	private String n_RefNo;
	private Date d_TransactionDate;
	private String c_ClntCode;
	private double n_Amount;
	private String c_Type;
	private String c_BranchCode;
	private String b_Processed;
	private Date d_DateProcessed;
	private String c_ProcessedBy;
	private String c_Reference;
	private String c_PaymentType;
	
	public String getN_RefNo() {
		return n_RefNo;
	}
	public void setN_RefNo(String refNo) {
		n_RefNo = refNo;
	}
	public Date getD_TransactionDate() {
		return d_TransactionDate;
	}
	public void setD_TransactionDate(Date transactionDate) {
		d_TransactionDate = transactionDate;
	}
	public String getC_ClntCode() {
		return c_ClntCode;
	}
	public void setC_ClntCode(String clntCode) {
		c_ClntCode = clntCode;
	}
	public double getN_Amount() {
		return n_Amount;
	}
	public void setN_Amount(double amount) {
		n_Amount = amount;
	}
	public String getC_Type() {
		return c_Type;
	}
	public void setC_Type(String type) {
		c_Type = type;
	}
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public String getB_Processed() {
		return b_Processed;
	}
	public void setB_Processed(String processed) {
		b_Processed = processed;
	}
	public Date getD_DateProcessed() {
		return d_DateProcessed;
	}
	public void setD_DateProcessed(Date dateProcessed) {
		d_DateProcessed = dateProcessed;
	}
	public String getC_ProcessedBy() {
		return c_ProcessedBy;
	}
	public void setC_ProcessedBy(String processedBy) {
		c_ProcessedBy = processedBy;
	}
	public String getC_Reference() {
		return c_Reference;
	}
	public void setC_Reference(String reference) {
		c_Reference = reference;
	}
	public String getC_PaymentType() {
		return c_PaymentType;
	}
	public void setC_PaymentType(String paymentType) {
		c_PaymentType = paymentType;
	}
	
	
	
}
