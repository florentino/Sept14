 package com.bdo.factor.beans;

import java.util.Map;

public class CustomerClientMaster {

/////////////////////////////////////////////////////////////////////////////////
	
	private String C_BRANCHCODE;
	private String C_CUSTCODE;
	private String C_CUSTNAME;
	private String c_SHORTNAME;
	private String C_ADDRESS;
	private String C_CONTACT;
	private String C_TELNO;
	private String C_BREGNO;
	private String C_BANKCODE;
	private String C_BANKACCT;
	private String C_GROUPCODE;
	private String N_CULIMIT;
	private String C_FAXNO;
	private String C_VERIFYEMAIL1;
	private String C_VERIFYEMAIL2;
	private String C_COLLECTCONTACT;
	private String C_COLLECTTELNO;
	private String C_COLLECTFAXLNO;
	private String C_COLLECTEMAIL1;
	private String C_COLLECTEMAIL2;
	private String C_DUNNING;
	private String C_INDCODE;
	private String C_STATUS;
	
/////////////////////////////////////////////////////////////////////////////////

	public CustomerClientMaster(){
	}
	
/////////////////////////////////////////////////////////////////////////////////
	
	
	public CustomerClientMaster(Map map){
		
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BRANCHCODE(map.get("C_BRANCHCODE").toString());
		
		if(map.containsKey("C_CUSTCODE") && map.get("C_CUSTCODE")!=null)
			this.setC_CUSTCODE(map.get("C_CUSTCODE").toString());
		
		if(map.containsKey("C_CUSTNAME") && map.get("C_CUSTNAME")!=null)
			this.setC_CUSTNAME(map.get("C_CUSTNAME").toString());
		
		if(map.containsKey("c_SHORTNAME") && map.get("c_SHORTNAME")!=null)
			this.setC_SHORTNAME(map.get("c_SHORTNAME").toString());
		
		if(map.containsKey("C_ADDRESS") && map.get("C_ADDRESS")!=null)
			this.setC_ADDRESS(map.get("C_ADDRESS").toString());
		
		if(map.containsKey("C_CONTACT") && map.get("C_CONTACT")!=null)
			this.setC_CONTACT(map.get("C_CONTACT").toString());
		
		if(map.containsKey("C_TELNO") && map.get("C_TELNO")!=null)
			this.setC_TELNO(map.get("C_TELNO").toString());
		
		if(map.containsKey("C_BREGNO") && map.get("C_BREGNO")!=null)
			this.setC_BREGNO(map.get("C_BREGNO").toString());
		
		if(map.containsKey("C_BANKCODE") && map.get("C_BANKCODE")!=null)
			this.setC_BANKCODE(map.get("C_BANKCODE").toString());
		
		if(map.containsKey("C_BANKACCT") && map.get("C_BANKACCT")!=null)
			this.setC_BANKACCT(map.get("C_BANKACCT").toString());
		
		if(map.containsKey("C_GROUPCODE") && map.get("C_GROUPCODE")!=null)
			this.setC_GROUPCODE(map.get("C_GROUPCODE").toString());
		
		if(map.containsKey("N_CULIMIT") && map.get("N_CULIMIT")!=null)
			this.setN_CULIMIT(map.get("N_CULIMIT").toString());
		
		if(map.containsKey("C_FAXNO") && map.get("C_FAXNO")!=null)
			this.setC_FAXNO(map.get("C_FAXNO").toString());
		
		if(map.containsKey("C_VERIFYEMAIL1") && map.get("C_VERIFYEMAIL1")!=null)
			this.setC_VERIFYEMAIL1(map.get("C_VERIFYEMAIL1").toString());
		
		if(map.containsKey("C_VERIFYEMAIL2") && map.get("C_VERIFYEMAIL2")!=null)
			this.setC_VERIFYEMAIL2(map.get("C_VERIFYEMAIL2").toString());
		
		if(map.containsKey("C_COLLECTCONTACT") && map.get("C_COLLECTCONTACT")!=null)
			this.setC_COLLECTCONTACT(map.get("C_COLLECTCONTACT").toString());
		
		if(map.containsKey("C_COLLECTTELNO") && map.get("C_COLLECTTELNO")!=null)
			this.setC_COLLECTTELNO(map.get("C_COLLECTTELNO").toString());
		
		if(map.containsKey("C_COLLECTFAXLNO") && map.get("C_COLLECTFAXLNO")!=null)
			this.setC_COLLECTFAXLNO(map.get("C_COLLECTFAXLNO").toString());
		
		if(map.containsKey("C_COLLECTEMAIL1") && map.get("C_COLLECTEMAIL1")!=null)
			this.setC_COLLECTEMAIL1(map.get("C_COLLECTEMAIL1").toString());
		
		if(map.containsKey("C_COLLECTEMAIL2") && map.get("C_COLLECTEMAIL2")!=null)
			this.setC_COLLECTEMAIL2(map.get("C_COLLECTEMAIL2").toString());
		
		if(map.containsKey("C_DUNNING") && map.get("C_DUNNING")!=null)
			this.setC_DUNNING(map.get("C_DUNNING").toString());
		
		if(map.containsKey("C_INDCODE") && map.get("C_INDCODE")!=null)
			this.setC_INDCODE(map.get("C_INDCODE").toString());
		
		if(map.containsKey("C_STATUS") && map.get("C_STATUS")!=null)
			this.setC_STATUS(map.get("C_STATUS").toString());
					
	}

/////////////////////////////////////////////////////////////////////////////////	
	
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}
	public void setC_BRANCHCODE(String c_branchcode) {
		C_BRANCHCODE = c_branchcode;
	}
	public String getC_CUSTCODE() {
		return C_CUSTCODE;
	}
	public void setC_CUSTCODE(String c_custcode) {
		C_CUSTCODE = c_custcode;
	}
	public String getC_CUSTNAME() {
		return C_CUSTNAME;
	}
	public void setC_CUSTNAME(String c_custname) {
		C_CUSTNAME = c_custname;
	}
	public String getC_SHORTNAME() {
		return c_SHORTNAME;
	}
	public void setC_SHORTNAME(String c_shortname) {
		c_SHORTNAME = c_shortname;
	}
	public String getC_ADDRESS() {
		return C_ADDRESS;
	}
	public void setC_ADDRESS(String c_address) {
		C_ADDRESS = c_address;
	}
	public String getC_CONTACT() {
		return C_CONTACT;
	}
	public void setC_CONTACT(String c_contact) {
		C_CONTACT = c_contact;
	}
	public String getC_TELNO() {
		return C_TELNO;
	}
	public void setC_TELNO(String c_telno) {
		C_TELNO = c_telno;
	}
	public String getC_BREGNO() {
		return C_BREGNO;
	}
	public void setC_BREGNO(String c_bregno) {
		C_BREGNO = c_bregno;
	}
	public String getC_BANKCODE() {
		return C_BANKCODE;
	}
	public void setC_BANKCODE(String c_bankcode) {
		C_BANKCODE = c_bankcode;
	}
	public String getC_BANKACCT() {
		return C_BANKACCT;
	}
	public void setC_BANKACCT(String c_bankacct) {
		C_BANKACCT = c_bankacct;
	}
	public String getC_GROUPCODE() {
		return C_GROUPCODE;
	}
	public void setC_GROUPCODE(String c_groupcode) {
		C_GROUPCODE = c_groupcode;
	}
	public String getN_CULIMIT() {
		return N_CULIMIT;
	}
	public void setN_CULIMIT(String n_culimit) {
		N_CULIMIT = n_culimit;
	}
	public String getC_FAXNO() {
		return C_FAXNO;
	}
	public void setC_FAXNO(String c_faxno) {
		C_FAXNO = c_faxno;
	}
	public String getC_VERIFYEMAIL1() {
		return C_VERIFYEMAIL1;
	}
	public void setC_VERIFYEMAIL1(String c_verifyemail1) {
		C_VERIFYEMAIL1 = c_verifyemail1;
	}
	public String getC_VERIFYEMAIL2() {
		return C_VERIFYEMAIL2;
	}
	public void setC_VERIFYEMAIL2(String c_verifyemail2) {
		C_VERIFYEMAIL2 = c_verifyemail2;
	}
	public String getC_COLLECTCONTACT() {
		return C_COLLECTCONTACT;
	}
	public void setC_COLLECTCONTACT(String c_collectcontact) {
		C_COLLECTCONTACT = c_collectcontact;
	}
	public String getC_COLLECTTELNO() {
		return C_COLLECTTELNO;
	}
	public void setC_COLLECTTELNO(String c_collecttelno) {
		C_COLLECTTELNO = c_collecttelno;
	}
	public String getC_COLLECTFAXLNO() {
		return C_COLLECTFAXLNO;
	}
	public void setC_COLLECTFAXLNO(String c_collectfaxlno) {
		C_COLLECTFAXLNO = c_collectfaxlno;
	}
	public String getC_COLLECTEMAIL1() {
		return C_COLLECTEMAIL1;
	}
	public void setC_COLLECTEMAIL1(String c_collectemail1) {
		C_COLLECTEMAIL1 = c_collectemail1;
	}
	public String getC_COLLECTEMAIL2() {
		return C_COLLECTEMAIL2;
	}
	public void setC_COLLECTEMAIL2(String c_collectemail2) {
		C_COLLECTEMAIL2 = c_collectemail2;
	}
	public String getC_DUNNING() {
		return C_DUNNING;
	}
	public void setC_DUNNING(String c_dunning) {
		C_DUNNING = c_dunning;
	}
	public String getC_INDCODE() {
		return C_INDCODE;
	}
	public void setC_INDCODE(String c_indcode) {
		C_INDCODE = c_indcode;
	}
	public String getC_STATUS() {
		return C_STATUS;
	}
	public void setC_STATUS(String c_status) {
		C_STATUS = c_status;
	}
	
	
/////////////////////////////////////////////////////////////////////////////////
	

	public String toString() {
		
		StringBuilder strCustomerClientMaster = new StringBuilder();
		
		strCustomerClientMaster.append("C_BRANCHCODE=").append(C_BRANCHCODE);
		strCustomerClientMaster.append(";C_CUSTCODE=").append(C_CUSTCODE);
		strCustomerClientMaster.append(";C_CUSTNAME=").append(C_CUSTNAME);
		strCustomerClientMaster.append(";c_SHORTNAME=").append(c_SHORTNAME);
		strCustomerClientMaster.append(";C_ADDRESS=").append(C_ADDRESS);
		strCustomerClientMaster.append(";C_CONTACT=").append(C_CONTACT);
		strCustomerClientMaster.append(";C_TELNO=").append(C_TELNO);
		strCustomerClientMaster.append(";C_BREGNO=").append(C_BREGNO);
		strCustomerClientMaster.append(";C_BANKCODE=").append(C_BANKCODE);
		strCustomerClientMaster.append(";C_BANKACCT=").append(C_BANKACCT);
		strCustomerClientMaster.append(";C_GROUPCODE=").append(C_GROUPCODE);
		strCustomerClientMaster.append(";N_CULIMIT=").append(N_CULIMIT);
		strCustomerClientMaster.append(";C_FAXNO=").append(C_FAXNO);
		strCustomerClientMaster.append(";C_VERIFYEMAIL1=").append(C_VERIFYEMAIL1);
		strCustomerClientMaster.append(";C_VERIFYEMAIL2=").append(C_VERIFYEMAIL2);
		strCustomerClientMaster.append(";C_COLLECTCONTACT=").append(C_COLLECTCONTACT);
		strCustomerClientMaster.append(";C_COLLECTTELNO=").append(C_COLLECTTELNO);
		strCustomerClientMaster.append(";C_COLLECTFAXLNO=").append(C_COLLECTFAXLNO);
		strCustomerClientMaster.append(";C_COLLECTEMAIL1=").append(C_COLLECTEMAIL1);
		strCustomerClientMaster.append(";C_COLLECTEMAIL2=").append(C_COLLECTEMAIL2);
		strCustomerClientMaster.append(";C_DUNNING=").append(C_DUNNING);
		strCustomerClientMaster.append(";C_INDCODE=").append(C_INDCODE);
		strCustomerClientMaster.append(";C_STATUS=").append(C_STATUS);

		
		return strCustomerClientMaster.toString();
	}
		
/////////////////////////////////////////////////////////////////////////////////
	
	
}
