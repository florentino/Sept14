package com.bdo.factor.beans;

import java.util.Date;

public class BLR {
	private Long n_refno;
	private Long c_clntCode;
	private Double n_blr;
	private Date d_effDt;
	private Date d_expDt;
	private Date d_createdDt;
	private String c_userid;
	private String c_status;
	public Long getN_refno() {
		return n_refno;
	}
	public void setN_refno(Long n_refno) {
		this.n_refno = n_refno;
	}
	public Double getN_blr() {
		return n_blr;
	}
	public void setN_blr(Double n_blr) {
		this.n_blr = n_blr;
	}
	public Date getD_effDt() {
		return d_effDt;
	}
	public void setD_effDt(Date d_effDt) {
		this.d_effDt = d_effDt;
	}
	public Date getD_expDt() {
		return d_expDt;
	}
	public void setD_expDt(Date d_expDt) {
		this.d_expDt = d_expDt;
	}
	public Date getD_createdDt() {
		return d_createdDt;
	}
	public void setD_createdDt(Date d_createdDt) {
		this.d_createdDt = d_createdDt;
	}
	public String getC_userid() {
		return c_userid;
	}
	public void setC_userid(String c_userid) {
		this.c_userid = c_userid;
	}
	public String getC_status() {
		return c_status;
	}
	public void setC_status(String c_status) {
		this.c_status = c_status;
	}
	public Long getC_clntCode() {
		return c_clntCode;
	}
	public void setC_clntCode(Long c_clntCode) {
		this.c_clntCode = c_clntCode;
	}

}
