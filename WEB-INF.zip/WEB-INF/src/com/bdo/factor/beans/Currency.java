package com.bdo.factor.beans;

public class Currency {
	private String c_CurrencyCode;
	private java.util.Date d_RateDate;
	private String c_Description;
	private double n_ExchangeRate;
	
	public String getC_CurrencyCode() {
		return c_CurrencyCode;
	}
	public void setC_CurrencyCode(String currencyCode) {
		c_CurrencyCode = currencyCode;
	}
	public java.util.Date getD_RateDate() {
		return d_RateDate;
	}
	public void setD_RateDate(java.util.Date rateDate) {
		d_RateDate = rateDate;
	}
	public String getC_Description() {
		return c_Description;
	}
	public void setC_Description(String description) {
		c_Description = description;
	}
	public double getN_ExchangeRate() {
		return n_ExchangeRate;
	}
	public void setN_ExchangeRate(double exchangeRate) {
		n_ExchangeRate = exchangeRate;
	}
	
	public String toString(){
		StringBuilder str = new StringBuilder();
		str.append("C_CURRENCYCODE=").append(c_CurrencyCode);
		str.append(";D_RATEDATE=").append(d_RateDate);
		str.append(";C_DESCRIPTION=").append(c_Description);
		str.append(";N_EXCHANGERATE=").append(n_ExchangeRate);
		
		return str.toString();
	}
}
