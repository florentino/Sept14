package com.bdo.factor.beans;

import java.util.Date;
import java.util.Map;

import com.bdo.factor.util.DateHelper;

public class PostDate {
	
	private Date d_Initialize;
	private Date d_DayEnd;
	private Date d_MonthEnd;	
	private String c_BranchCode;
	private String C_USERID;
	
	public PostDate(){
	}
	
	public PostDate(Map map){

		if(map.containsKey("C_USERID") && map.get("C_USERID")!=null)
			this.setC_USERID(map.get("C_USERID").toString());
		
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BranchCode(map.get("C_BRANCHCODE").toString());
		
		if(map.containsKey("D_INITIALIZE") && map.get("D_INITIALIZE")!=null)
			this.setD_Initialize(DateHelper.parse(map.get("D_INITIALIZE").toString()));
		
		if(map.containsKey("D_DAYEND") && map.get("D_DAYEND")!=null)
			this.setD_DayEnd(DateHelper.parse(map.get("D_DAYEND").toString()));
		
		if(map.containsKey("D_MONTHEND") && map.get("D_MONTHEND")!=null)
			this.setD_MonthEnd(DateHelper.parse(map.get("D_MONTHEND").toString()));
	}	
	
	public String getC_USERID() {
		return C_USERID;
	}
	public void setC_USERID(String c_userid) {
		C_USERID = c_userid;
	}
	public Date getD_Initialize() {
		return d_Initialize;
	}
	public void setD_Initialize(Date initialize) {
		d_Initialize = initialize;
	}
	public Date getD_DayEnd() {
		return d_DayEnd;
	}
	public void setD_DayEnd(Date dayEnd) {
		d_DayEnd = dayEnd;
	}
	public Date getD_MonthEnd() {
		return d_MonthEnd;
	}
	public void setD_MonthEnd(Date monthEnd) {
		d_MonthEnd = monthEnd;
	}
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	
	public String toString() {
		
		StringBuilder str = new StringBuilder();
		str.append("C_USERID=").append(this.C_USERID);
		str.append(";D_INITIALIZE=").append(this.d_Initialize);
		str.append(";D_DAYEND=").append(this.d_DayEnd);
		str.append(";D_MONTHEND=").append(this.d_MonthEnd);
		str.append(";C_BRANCHCODE=").append(this.c_BranchCode);
		
		return str.toString();
	}
	
}
