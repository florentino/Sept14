package com.bdo.factor.beans;

import java.util.Date;
public class ClientConcentration 
{
	private String cName;
	private String cCurrencyCode;
	private double nInvestmentLimit;
	private double nReceivables;
	private double nReserves;
	private double nFIU;
	private Date currentDate;
	public String getCName() {
		return cName;
	}
	public void setCName(String name) {
		cName = name;
	}
	public String getCCurrencyCode() {
		return cCurrencyCode;
	}
	public void setCCurrencyCode(String currencyCode) {
		cCurrencyCode = currencyCode;
	}
	public double getNInvestmentLimit() {
		return nInvestmentLimit;
	}
	public void setNInvestmentLimit(double investmentLimit) {
		nInvestmentLimit = investmentLimit;
	}
	public double getNReceivables() {
		return nReceivables;
	}
	public void setNReceivables(double receivables) {
		nReceivables = receivables;
	}
	public double getNReserves() {
		return nReserves;
	}
	public void setNReserves(double reserves) {
		nReserves = reserves;
	}
	public double getNFIU() {
		return nFIU;
	}
	public void setNFIU(double nfiu) {
		nFIU = nfiu;
	}	
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;	
	}		
}
