package com.bdo.factor.beans;

import java.util.Date;

public class BLRFile {
	private String c_BlrTypeCode;
	private double n_Blr1;
	private java.util.Date d_EffDt1;
	private java.util.Date d_ExpDt1;
	private double n_Blr2;
	private java.util.Date d_EffDt2;
	private java.util.Date d_ExpDt2;
	private double n_Blr3;
	private java.util.Date d_EffDt3;
	private java.util.Date d_ExpDt3;
	private double n_Blr4;
	private java.util.Date d_EffDt4;
	private java.util.Date d_ExpDt4;
	private double n_Blr5;
	private java.util.Date d_EffDt5;
	private java.util.Date d_ExpDt5;
	
	private double blr;
	private Date effectiveDate;
	private Date expiryDate;
	private double discountCharge;
	
	
	public String getC_BlrTypeCode() {
		return c_BlrTypeCode;
	}
	public void setC_BlrTypeCode(String blrTypeCode) {
		c_BlrTypeCode = blrTypeCode;
	}
	public double getN_Blr1() {
		return n_Blr1;
	}
	public void setN_Blr1(double blr1) {
		n_Blr1 = blr1;
	}
	public java.util.Date getD_EffDt1() {
		return d_EffDt1;
	}
	public void setD_EffDt1(java.util.Date effDt1) {
		d_EffDt1 = effDt1;
	}
	public java.util.Date getD_ExpDt1() {
		return d_ExpDt1;
	}
	public void setD_ExpDt1(java.util.Date expDt1) {
		d_ExpDt1 = expDt1;
	}
	public double getN_Blr2() {
		return n_Blr2;
	}
	public void setN_Blr2(double blr2) {
		n_Blr2 = blr2;
	}
	public java.util.Date getD_EffDt2() {
		return d_EffDt2;
	}
	public void setD_EffDt2(java.util.Date effDt2) {
		d_EffDt2 = effDt2;
	}
	public java.util.Date getD_ExpDt2() {
		return d_ExpDt2;
	}
	public void setD_ExpDt2(java.util.Date expDt2) {
		d_ExpDt2 = expDt2;
	}
	public double getN_Blr3() {
		return n_Blr3;
	}
	public void setN_Blr3(double blr3) {
		n_Blr3 = blr3;
	}
	public java.util.Date getD_EffDt3() {
		return d_EffDt3;
	}
	public void setD_EffDt3(java.util.Date effDt3) {
		d_EffDt3 = effDt3;
	}
	public java.util.Date getD_ExpDt3() {
		return d_ExpDt3;
	}
	public void setD_ExpDt3(java.util.Date expDt3) {
		d_ExpDt3 = expDt3;
	}
	public double getN_Blr4() {
		return n_Blr4;
	}
	public void setN_Blr4(double blr4) {
		n_Blr4 = blr4;
	}
	public java.util.Date getD_EffDt4() {
		return d_EffDt4;
	}
	public void setD_EffDt4(java.util.Date effDt4) {
		d_EffDt4 = effDt4;
	}
	public java.util.Date getD_ExpDt4() {
		return d_ExpDt4;
	}
	public void setD_ExpDt4(java.util.Date expDt4) {
		d_ExpDt4 = expDt4;
	}
	public double getN_Blr5() {
		return n_Blr5;
	}
	public void setN_Blr5(double blr5) {
		n_Blr5 = blr5;
	}
	public java.util.Date getD_EffDt5() {
		return d_EffDt5;
	}
	public void setD_EffDt5(java.util.Date effDt5) {
		d_EffDt5 = effDt5;
	}
	public java.util.Date getD_ExpDt5() {
		return d_ExpDt5;
	}
	public void setD_ExpDt5(java.util.Date expDt5) {
		d_ExpDt5 = expDt5;
	}
	
	public String toString(){
		StringBuilder str = new StringBuilder();
		str.append("C_BLRTYPECODE=").append(c_BlrTypeCode);
		str.append(";N_BLR1=").append(n_Blr1);
		str.append(";D_EFFDT1=").append(d_EffDt1);
		str.append(";E_EXPDT1=").append(d_ExpDt1);
		str.append(";N_BLR2=").append(n_Blr2);
		str.append(";D_EFFDT2").append(d_EffDt2);
		str.append(";D_EXPDT2=").append(d_ExpDt2);
		str.append(";N_BLR3=").append(n_Blr3);
		str.append(";D_EFFDT3=").append(d_EffDt3);
		str.append(";D_EXPDT3=").append(d_ExpDt3);
		str.append(";N_BLR4=").append(n_Blr4);
		str.append(";D_EFFDT4=").append(d_EffDt4);
		str.append(";D_EXPDT4=").append(d_ExpDt4);
		str.append(";N_BLR5=").append(n_Blr5);
		str.append(";D_EFFDT5=").append(d_EffDt5);
		str.append(";D_EXPDT5=").append(d_ExpDt5);
		
		return str.toString();
	}
	public double getBlr() {
		return blr;
	}
	public void setBlr(double blr) {
		this.blr = blr;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public double getDiscountCharge() {
		return discountCharge;
	}
	public void setDiscountCharge(double discountCharge) {
		this.discountCharge = discountCharge;
	}
		
}
