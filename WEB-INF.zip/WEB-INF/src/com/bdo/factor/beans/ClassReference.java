package com.bdo.factor.beans;

import java.util.HashMap;
import java.util.Map;

public class ClassReference {
	
	private String CLASS_NAME;
	private String CLASS_DESC;
	private String URL;
			
	public String getCLASS_NAME() {
		return this.CLASS_NAME;
	}

	public void setCLASS_NAME(String class_name) {
		CLASS_NAME = class_name;
	}

	public String getCLASS_DESC() {
		return this.CLASS_DESC;
	}

	public void setCLASS_DESC(String class_desc) {
		CLASS_DESC = class_desc;
	}
	
	public String getURL() {
		return this.URL;
	}

	public void setURL(String url) {
		URL = url;
	}

	public String toString() {
		StringBuilder strClass = new StringBuilder();
		strClass.append("CLASS_NAME=").append(CLASS_NAME);
		strClass.append(";CLASS_DESC=").append(CLASS_DESC);
		strClass.append(";URL=").append(URL);
		return strClass.toString();
	}
	
	public String toAuditString(ClassReference classReference)
	{
		StringBuilder str = new StringBuilder();
		str.append("Class Reference "+classReference.CLASS_NAME+" has been updated. ");
		boolean updated = false;
		if(CLASS_NAME!=null&&!CLASS_NAME.contentEquals(classReference.CLASS_NAME))
		{
			str.append("Class Name is changed from "+classReference.CLASS_NAME+" to "+CLASS_NAME+". ");
			updated=true;
		}
		if(CLASS_DESC!=null&&!CLASS_DESC.contentEquals(classReference.CLASS_DESC))
		{
			str.append("Class Description is changed from "+classReference.CLASS_DESC+" to "+CLASS_DESC+". ");
			updated=true;
		}
		if(URL!=null&&!URL.contentEquals(classReference.URL))
		{
			str.append("Class URL is changed from "+classReference.URL+" to "+URL+". ");
			updated=true;
		}
		return updated?str.toString():"No Action done on class "+classReference.CLASS_NAME;
	}
	
	
}
