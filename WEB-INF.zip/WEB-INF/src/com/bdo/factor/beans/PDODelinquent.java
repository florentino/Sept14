package com.bdo.factor.beans;

import java.util.Date;

public class PDODelinquent {
	
	private Date asOfDate;
	private Date d_lastAdvance;
	private Date d_lastRefund;
	private Date d_lastCollection;
	private Date d_lastDCCollection;
	private Double clientFIU;
	private Double clientReceivable;
	private String c_clntName;
	private String ao;
	private String c_custName;
	private String c_invoiceNo;
	private Integer dunningPerLam;
	private Date d_invoiceDate;
	private Double n_origAmount;
	private Double n_advRatio;
	private Double origPrePayInvAmount;
	private Date d_transactionDate;
	private Date d_dateBasedOnDunning;
	private Integer actualInvoiceAge;
	private Integer actualInvoiceAgeLessLam;
	private Double outstandingInvBalance;
	private Double prePaymentAdvAmount;
	private Date d_lastInvCollection;
	private Double unpaidDC;
	private Double penaltyCharge;
	private Date datePastDue;
	private Double NetBal1_30;
	private Double NetBal31_60;
	private Double NetBal61_90;
	private Double NetBalgt90;
	private Double netUnpaidInterestPenalty;
	private Double netUnpaidDC;
	private Double netUnpaidDCPenalty;
	private Integer PDOInvoices;
	private Integer DelinquentInvoices;
	private Integer pdodelTotal; 
	private Double TotPDO;
	private Double TotDel;
	private Double TotPDODel;
	private Integer creditTerm;
	private String c_clntcode;
	private Integer status;
	private Double sumNet1_30;
	private Double sumNet31_60;
	private Double sumNet61_90;
	private Double sumNetGt90;
	private Integer count1_30;
	private Integer count31_60;
	private Integer count61_90;
	private Integer countGt90;
	private Double dcr;
	private Double netInvoice;
	
	public Integer getPdodelTotal() {
		return pdodelTotal;
	}
	public void setPdodelTotal(Integer pdodelTotal) {
		this.pdodelTotal = pdodelTotal;
	}
	public Double getTotPDODel() {
		return TotPDODel;
	}
	public void setTotPDODel(Double totPDODel) {
		TotPDODel = totPDODel;
	}
	public Integer getPDOInvoices() {
		return PDOInvoices;
	}
	public void setPDOInvoices(Integer pDOInvoices) {
		PDOInvoices = pDOInvoices;
	}
	public Integer getDelinquentInvoices() {
		return DelinquentInvoices;
	}
	public void setDelinquentInvoices(Integer delinquentInvoices) {
		DelinquentInvoices = delinquentInvoices;
	}
	public Double getTotPDO() {
		return TotPDO;
	}
	public void setTotPDO(Double totPDO) {
		TotPDO = totPDO;
	}
	public Double getTotDel() {
		return TotDel;
	}
	public void setTotDel(Double totDel) {
		TotDel = totDel;
	}
	public Date getD_lastAdvance() {
		return d_lastAdvance;
	}
	public void setD_lastAdvance(Date d_lastAdvance) {
		this.d_lastAdvance = d_lastAdvance;
	}
	public Date getD_lastRefund() {
		return d_lastRefund;
	}
	public void setD_lastRefund(Date d_lastRefund) {
		this.d_lastRefund = d_lastRefund;
	}
	public Date getD_lastCollection() {
		return d_lastCollection;
	}
	public void setD_lastCollection(Date d_lastCollection) {
		this.d_lastCollection = d_lastCollection;
	}
	public String getC_clntName() {
		return c_clntName;
	}
	public void setC_clntName(String c_clntName) {
		this.c_clntName = c_clntName;
	}
	public String getAo() {
		return ao;
	}
	public void setAo(String ao) {
		this.ao = ao;
	}
	public String getC_custName() {
		return c_custName;
	}
	public void setC_custName(String c_custName) {
		this.c_custName = c_custName;
	}
	public String getC_invoiceNo() {
		return c_invoiceNo;
	}
	public void setC_invoiceNo(String c_invoiceNo) {
		this.c_invoiceNo = c_invoiceNo;
	}
	public Integer getDunningPerLam() {
		return dunningPerLam;
	}
	public void setDunningPerLam(Integer dunningPerLam) {
		this.dunningPerLam = dunningPerLam;
	}
	public Date getD_invoiceDate() {
		return d_invoiceDate;
	}
	public void setD_invoiceDate(Date d_invoiceDate) {
		this.d_invoiceDate = d_invoiceDate;
	}
	public Double getN_origAmount() {
		return n_origAmount;
	}
	public void setN_origAmount(Double n_origAmount) {
		this.n_origAmount = n_origAmount;
	}
	public Double getN_advRatio() {
		return n_advRatio;
	}
	public void setN_advRatio(Double n_advRatio) {
		this.n_advRatio = n_advRatio;
	}
	public Double getOrigPrePayInvAmount() {
		return origPrePayInvAmount;
	}
	public void setOrigPrePayInvAmount(Double origPrePayInvAmount) {
		this.origPrePayInvAmount = origPrePayInvAmount;
	}
	public Date getD_transactionDate() {
		return d_transactionDate;
	}
	public void setD_transactionDate(Date d_transactionDate) {
		this.d_transactionDate = d_transactionDate;
	}
	public Date getD_dateBasedOnDunning() {
		return d_dateBasedOnDunning;
	}
	public void setD_dateBasedOnDunning(Date d_dateBasedOnDunning) {
		this.d_dateBasedOnDunning = d_dateBasedOnDunning;
	}
	public Integer getActualInvoiceAge() {
		return actualInvoiceAge;
	}
	public void setActualInvoiceAge(Integer actualInvoiceAge) {
		this.actualInvoiceAge = actualInvoiceAge;
	}
	public Integer getActualInvoiceAgeLessLam() {
		return actualInvoiceAgeLessLam;
	}
	public void setActualInvoiceAgeLessLam(Integer actualInvoiceAgeLessLam) {
		this.actualInvoiceAgeLessLam = actualInvoiceAgeLessLam;
	}
	public Double getOutstandingInvBalance() {
		return outstandingInvBalance;
	}
	public void setOutstandingInvBalance(Double outstandingInvBalance) {
		this.outstandingInvBalance = outstandingInvBalance;
	}
	public Double getPrePaymentAdvAmount() {
		return prePaymentAdvAmount;
	}
	public void setPrePaymentAdvAmount(Double prePaymentAdvAmount) {
		this.prePaymentAdvAmount = prePaymentAdvAmount;
	}
	public Date getD_lastInvCollection() {
		return d_lastInvCollection;
	}
	public void setD_lastInvCollection(Date d_lastInvCollection) {
		this.d_lastInvCollection = d_lastInvCollection;
	}
	public Double getUnpaidDC() {
		return unpaidDC;
	}
	public void setUnpaidDC(Double unpaidDC) {
		this.unpaidDC = unpaidDC;
	}
	public Double getPenaltyCharge() {
		return penaltyCharge;
	}
	public void setPenaltyCharge(Double penaltyCharge) {
		this.penaltyCharge = penaltyCharge;
	}
	public Date getDatePastDue() {
		return datePastDue;
	}
	public void setDatePastDue(Date datePastDue) {
		this.datePastDue = datePastDue;
	}
	public Double getNetBal1_30() {
		return NetBal1_30;
	}
	public void setNetBal1_30(Double netBal1_30) {
		NetBal1_30 = netBal1_30;
	}
	public Double getNetBal31_60() {
		return NetBal31_60;
	}
	public void setNetBal31_60(Double netBal31_60) {
		NetBal31_60 = netBal31_60;
	}
	public Double getNetBal61_90() {
		return NetBal61_90;
	}
	public void setNetBal61_90(Double netBal61_90) {
		NetBal61_90 = netBal61_90;
	}
	public Double getNetBalgt90() {
		return NetBalgt90;
	}
	public void setNetBalgt90(Double netBalgt90) {
		NetBalgt90 = netBalgt90;
	}
	public Double getNetUnpaidInterestPenalty() {
		return netUnpaidInterestPenalty;
	}
	public void setNetUnpaidInterestPenalty(Double netUnpaidInterestPenalty) {
		this.netUnpaidInterestPenalty = netUnpaidInterestPenalty;
	}
	 
	public Double getNetUnpaidDCPenalty() {
		return netUnpaidDCPenalty;
	}
	public void setNetUnpaidDCPenalty(Double netUnpaidDCPenalty) {
		this.netUnpaidDCPenalty = netUnpaidDCPenalty;
	}
	public Double getNetUnpaidDC() {
		return netUnpaidDC;
	}
	public void setNetUnpaidDC(Double netUnpaidDC) {
		this.netUnpaidDC = netUnpaidDC;
	}
	public Date getD_lastDCCollection() {
		return d_lastDCCollection;
	}
	public void setD_lastDCCollection(Date d_lastDCCollection) {
		this.d_lastDCCollection = d_lastDCCollection;
	}
	public Double getClientFIU() {
		return clientFIU;
	}
	public void setClientFIU(Double clientFIU) {
		this.clientFIU = clientFIU;
	}
	public Double getClientReceivable() {
		return clientReceivable;
	}
	public void setClientReceivable(Double clientReceivable) {
		this.clientReceivable = clientReceivable;
	}
	public Date getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}
	public Integer getCreditTerm() {
		return creditTerm;
	}
	public void setCreditTerm(Integer creditTerm) {
		this.creditTerm = creditTerm;
	}
	public String getC_clntcode() {
		return c_clntcode;
	}
	public void setC_clntcode(String c_clntcode) {
		this.c_clntcode = c_clntcode;
	}
	public Double getSumNet1_30() {
		return sumNet1_30;
	}
	public void setSumNet1_30(Double sumNet1_30) {
		this.sumNet1_30 = sumNet1_30;
	}
	public Double getSumNet31_60() {
		return sumNet31_60;
	}
	public void setSumNet31_60(Double sumNet31_60) {
		this.sumNet31_60 = sumNet31_60;
	}
	public Double getSumNet61_90() {
		return sumNet61_90;
	}
	public void setSumNet61_90(Double sumNet61_90) {
		this.sumNet61_90 = sumNet61_90;
	}
	public Double getSumNetGt90() {
		return sumNetGt90;
	}
	public void setSumNetGt90(Double sumNetGt90) {
		this.sumNetGt90 = sumNetGt90;
	}
	public Integer getCount1_30() {
		return count1_30;
	}
	public void setCount1_30(Integer count1_30) {
		this.count1_30 = count1_30;
	}
	public Integer getCount31_60() {
		return count31_60;
	}
	public void setCount31_60(Integer count31_60) {
		this.count31_60 = count31_60;
	}
	public Integer getCount61_90() {
		return count61_90;
	}
	public void setCount61_90(Integer count61_90) {
		this.count61_90 = count61_90;
	}
	public Integer getCountGt90() {
		return countGt90;
	}
	public void setCountGt90(Integer countGt90) {
		this.countGt90 = countGt90;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Double getDcr() {
		return dcr;
	}
	public void setDcr(Double dcr) {
		this.dcr = dcr;
	}
	public Double getNetInvoice() {
		return netInvoice;
	}
	public void setNetInvoice(Double netInvoice) {
		this.netInvoice = netInvoice;
	}
	
	
	 
}
