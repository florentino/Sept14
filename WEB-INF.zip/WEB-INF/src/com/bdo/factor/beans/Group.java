package com.bdo.factor.beans;

public class Group {
	private String c_BranchCode;
	private String c_GroupCode;
	private int n_GrpLimit;
	private double n_AccAmt;
	private String c_GroupName;
	
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public String getC_GroupCode() {
		return c_GroupCode;
	}
	public void setC_GroupCode(String groupCode) {
		c_GroupCode = groupCode;
	}
	public int getN_GrpLimit() {
		return n_GrpLimit;
	}
	public void setN_GrpLimit(int grpLimit) {
		n_GrpLimit = grpLimit;
	}
	public double getN_AccAmt() {
		return n_AccAmt;
	}
	public void setN_AccAmt(double accAmt) {
		n_AccAmt = accAmt;
	}
	public String getC_GroupName() {
		return c_GroupName;
	}
	public void setC_GroupName(String groupName) {
		c_GroupName = groupName;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(c_BranchCode);
		str.append(";C_GROUPCODE=").append(c_GroupCode);
		str.append(";N_GRPLIMIT=").append(n_GrpLimit);
		str.append(";N_ACCAMT=").append(n_AccAmt);
		str.append(";C_GROUPNAME").append(c_GroupName);
		
		return str.toString();
	}
}
