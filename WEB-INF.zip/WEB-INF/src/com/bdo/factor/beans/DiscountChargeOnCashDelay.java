package com.bdo.factor.beans;

import java.util.Date;

public class DiscountChargeOnCashDelay 
{

	private String cName;
	private String cCustName;
	private Date dTransactionDate;
	private long refno;
	private double totalAmount;
	private double nCashDelay;
	private double dCharge;
	public String getCName() {
		return cName;
	}
	public void setCName(String name) {
		cName = name;
	}
	public String getCCustName() {
		return cCustName;
	}
	public void setCCustName(String custName) {
		cCustName = custName;
	}
	public Date getDTransactionDate() {
		return dTransactionDate;
	}
	public void setDTransactionDate(Date transactionDate) {
		dTransactionDate = transactionDate;
	}
	public long getRefno() {
		return refno;
	}
	public void setRefno(long refno) {
		this.refno = refno;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public double getNCashDelay() {
		return nCashDelay;
	}
	public void setNCashDelay(double cashDelay) {
		nCashDelay = cashDelay;
	}
	public double getDCharge() {
		return dCharge;
	}
	public void setDCharge(double charge) {
		dCharge = charge;
	}		
	
}
