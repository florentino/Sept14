package com.bdo.factor.beans;

import java.util.Date;
import java.util.Map;

import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
public class Advances {
	
	private String C_BRANCHCODE;
	private int N_REFNO;
	private Date D_TRANSACTIONDATE;
	private long C_CLNTCODE;
	private long C_CUSTCODE;
	private double N_COMPUTEDAMT;
	private double N_ADVAMT;
	private double N_RATIOAMT;
	private double N_SVCCHG;
	private double N_DISCCHG1;
	private double N_DISCCHG2;
	private double N_DISCCHGCD;
	private String C_TYPE;
	private String C_STATUS;
	private String C_AMS; 
	private double N_NOTARIAL;
	private Date currentDate;

	public Advances(){
	}
	
	public Advances(Map map){
		
		 FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BRANCHCODE(map.get("C_BRANCHCODE").toString());
		
		if(map.containsKey("N_REFNO") && map.get("N_REFNO")!=null)	
			this.setN_REFNO(Integer.parseInt(map.get("N_REFNO").toString()));
		
		if(map.containsKey("D_TRANSACTIONDATE") && map.get("D_TRANSACTIONDATE")!=null)	
			this.setD_TRANSACTIONDATE(new Date(map.get("D_TRANSACTIONDATE").toString()));
		
		if(map.containsKey("C_CLNTCODE") && map.get("C_CLNTCODE")!=null)	
			this.setC_CLNTCODE(new Long(map.get("C_CLNTCODE").toString()));
		
		if(map.containsKey("C_CUSTCODE") && map.get("C_CUSTCODE")!=null)	
			this.setC_CUSTCODE(new Long(map.get("C_CUSTCODE").toString()));
		
		if(map.containsKey("N_COMPUTEDAMT") && map.get("N_COMPUTEDAMT")!=null)
			this.setN_COMPUTEDAMT(new Double(map.get("N_COMPUTEDAMT").toString()));
		
		if(map.containsKey("N_ADVAMT") && map.get("N_ADVAMT")!=null)
			this.setN_ADVAMT(new Double(map.get("N_ADVAMT").toString()));
		
		if(map.containsKey("N_RATIOAMT") && map.get("N_RATIOAMT")!=null)
			this.setN_RATIOAMT(new Double(map.get("N_RATIOAMT").toString()));
		
		if(map.containsKey("N_SVCCHG") && map.get("N_SVCCHG")!=null)
			this.setN_SVCCHG(new Double(map.get("N_SVCCHG").toString()));
		
		if(map.containsKey("N_DISCCHG1") && map.get("N_DISCCHG1")!=null)
			this.setN_DISCCHG1(new Double(map.get("N_DISCCHG1").toString()));
		
		if(map.containsKey("N_DISCCHG2") && map.get("N_DISCCHG2")!=null)
			this.setN_DISCCHG2(new Double(map.get("N_DISCCHG2").toString()));
		
		if(map.containsKey("N_DISCCHGCD") && map.get("N_DISCCHGCD")!=null)
			this.setN_DISCCHGCD(new Double(map.get("N_DISCCHGCD").toString()));
		
		if(map.containsKey("C_TYPE") && map.get("C_TYPE")!=null)
			this.setC_TYPE(map.get("C_TYPE").toString());
		
		if(map.containsKey("C_STATUS") && map.get("C_STATUS")!=null)
			this.setC_STATUS(map.get("C_STATUS").toString());
		
		if(map.containsKey("C_AMS") && map.get("C_AMS")!=null)
			this.setC_AMS(map.get("C_AMS").toString());
		
		if(map.containsKey("N_NOTARIAL") && map.get("N_NOTARIAL")!=null)
			this.setN_NOTARIAL(new Double(map.get("N_NOTARIAL").toString()));
		
		if(map.containsKey("currentDate") && map.get("currentDate")!=null)
			this.setCurrentDate(new Date(map.get("currentDate").toString()));
		
	}


	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}

	public void setC_BRANCHCODE(String c_branchcode) {
		C_BRANCHCODE = c_branchcode;
	}

	public int getN_REFNO() {
		return N_REFNO;
	}

	public void setN_REFNO(int n_refno) {
		N_REFNO = n_refno;
	}

	public Date getD_TRANSACTIONDATE() {
		return D_TRANSACTIONDATE;
	}

	public void setD_TRANSACTIONDATE(Date d_transactiondate) {
		D_TRANSACTIONDATE = d_transactiondate;
	}

	public long getC_CLNTCODE() {
		return C_CLNTCODE;
	}

	public void setC_CLNTCODE(long c_clntcode) {
		C_CLNTCODE = c_clntcode;
	}

	public long getC_CUSTCODE() {
		return C_CUSTCODE;
	}

	public void setC_CUSTCODE(long c_custcode) {
		C_CUSTCODE = c_custcode;
	}

	public double getN_COMPUTEDAMT() {
		return N_COMPUTEDAMT;
	}

	public void setN_COMPUTEDAMT(double n_computedamt) {
		N_COMPUTEDAMT = n_computedamt;
	}

	public double getN_ADVAMT() {
		return N_ADVAMT;
	}

	public void setN_ADVAMT(double n_advamt) {
		N_ADVAMT = n_advamt;
	}

	public double getN_RATIOAMT() {
		return N_RATIOAMT;
	}

	public void setN_RATIOAMT(double n_ratioamt) {
		N_RATIOAMT = n_ratioamt;
	}

	public double getN_SVCCHG() {
		return N_SVCCHG;
	}

	public void setN_SVCCHG(double n_svcchg) {
		N_SVCCHG = n_svcchg;
	}

	public double getN_DISCCHG1() {
		return N_DISCCHG1;
	}

	public void setN_DISCCHG1(double n_discchg1) {
		N_DISCCHG1 = n_discchg1;
	}

	public double getN_DISCCHG2() {
		return N_DISCCHG2;
	}

	public void setN_DISCCHG2(double n_discchg2) {
		N_DISCCHG2 = n_discchg2;
	}

	public double getN_DISCCHGCD() {
		return N_DISCCHGCD;
	}

	public void setN_DISCCHGCD(double n_discchgcd) {
		N_DISCCHGCD = n_discchgcd;
	}

	public String getC_TYPE() {
		return C_TYPE;
	}

	public void setC_TYPE(String c_type) {
		C_TYPE = c_type;
	}

	public String getC_STATUS() {
		return C_STATUS;
	}

	public void setC_STATUS(String c_status) {
		C_STATUS = c_status;
	}

	public String getC_AMS() {
		return C_AMS;
	}

	public void setC_AMS(String c_ams) {
		C_AMS = c_ams;
	}
	
	
	//ADDED BY CVG AS OF 03-16-16
	public double getN_NOTARIAL() {
		return N_NOTARIAL;
	}

	public void setN_NOTARIAL(double n_NOTARIAL) {
		N_NOTARIAL = n_NOTARIAL;
	}

	
	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	public String toString(){
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(C_BRANCHCODE);
		str.append(";N_REFNO=").append(N_REFNO);
		str.append(";D_TRANSACTIONDATE=").append(D_TRANSACTIONDATE);
		str.append(";C_CLNTCODE=").append(C_CLNTCODE);
		str.append(";C_CUSTCODE=").append(C_CUSTCODE);
		str.append(";N_COMPUTEDAMT=").append(N_COMPUTEDAMT);
		str.append(";N_ADVAMT=").append(N_ADVAMT);
		str.append(";N_RATIOAMT=").append(N_RATIOAMT);
		str.append(";N_SVCCHG=").append(N_SVCCHG);
		str.append(";N_DISCCHG1=").append(N_DISCCHG1);
		str.append(";N_DISCCHG2=").append(N_DISCCHG2);
		str.append(";N_DISCCHGCD").append(N_DISCCHGCD);
		str.append(";C_TYPE").append(C_TYPE);
		str.append(";C_STATUS").append(C_STATUS);
		str.append(";C_AMS").append(C_AMS);
		str.append(";N_NOTARIAL=").append(N_NOTARIAL);
		str.append(";currentDate=").append(currentDate);
		
		
		return str.toString();
	}
	
}
