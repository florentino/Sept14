package com.bdo.factor.beans;

import java.util.Date;

public class FactoringManagement {
	
	//GLOBAL
	private String c_ClntCode;
	private String c_Name;
	private String aoName;
	private double n_receivables;
	private double n_dcAccrual;
	private double n_reserves;
	private double n_fiutran;
	private double advancedRatio;
	private Double n_scr;
	private Double n_dcr;
	
	//FACTORING MANAGEMENT & RECEIVABLES
	private double n_investmentlimit;
	private double n_dcCollected;
	
	//FACTORING RECEIVABLES & CREDEX
	String c_Status;
	Double n_ClntEquity;
	Double n_DCRate;
	Date d_BlrFrom;
	Date d_BlrTo;
	Double n_CreditTerm;
	String n_IndustryCode;
	String c_Industry;
	String c_SizeOfFirm;
	Double n_CreditNote;
	Double n_Term;
	
	//FACTORING MANAGEMENT
	private String c_CurrencyCode;
	private java.util.Date d_effDate;
	private double factoredInvoice;
	
	//FACTORING RECEIVABLES
	Double n_DCAdjustment;
	Double n_CERatio;
	Double n_serviceCharge;
	Double n_penaltyCharge;
	Double CEUnpaid;
	Double n_receipts;
	Double n_overpayment;
	Double n_CEPaid;
	Date d_PDODate;
	Date d_lastDCCollected;
	Date d_lastPayment;
	Date d_lastRefund;
	Date d_lastAdvance;
	Date d_DCRateChanged;
	Double n_prevDCRate;
	Date d_AdvRatioChanged;
	Double n_prevAdvRate;
	Double n_dunning;
	Double n_avgDunning;
	Date d_review;
	Double n_avgDunning6mos;
	
	//FACTORING CREDEX
	
	Date d_ReviewDate;
	String c_IndustryHeader;
	String c_TIN;
	String c_BorrowerType;
	Double n_Assets;
	Double n_Liabilities;
	Double n_Equity;
	Double n_GrossIncome;
	Double n_Expenses;
	Double n_NetIncome;
	Date d_audited;

	
	
	
	
	
	
	
	
	public String getC_ClntCode() {
		return c_ClntCode;
	}
	public void setC_ClntCode(String clntCode) {
		c_ClntCode = clntCode;
	}
	public String getC_Name() {
		return c_Name;
	}
	public void setC_Name(String name) {
		c_Name = name;
	}
	public String getC_CurrencyCode() {
		return c_CurrencyCode;
	}
	public void setC_CurrencyCode(String currencyCode) {
		c_CurrencyCode = currencyCode;
	}
	public double getN_investmentlimit() {
		return n_investmentlimit;
	}
	public void setN_investmentlimit(double n_investmentlimit) {
		this.n_investmentlimit = n_investmentlimit;
	}
	public double getN_receivables() {
		return n_receivables;
	}
	public void setN_receivables(double n_receivables) {
		this.n_receivables = n_receivables;
	}
	public double getN_reserves() {
		return n_reserves;
	}
	public void setN_reserves(double n_reserves) {
		this.n_reserves = n_reserves;
	}
	public double getN_fiutran() {
		return n_fiutran;
	}
	public void setN_fiutran(double n_fiutran) {
		this.n_fiutran = n_fiutran;
	}
	public java.util.Date getD_effDate() {
		return d_effDate;
	}
	public void setD_effDate(java.util.Date date) {
		d_effDate = date;
	}
	public double getFactoredInvoice() {
		return factoredInvoice;
	}
	public void setFactoredInvoice(double factoredInvoice) {
		this.factoredInvoice = factoredInvoice;
	}
	public String getAoName() {
		return aoName;
	}
	public void setAoName(String aoName) {
		this.aoName = aoName;
	}
	public double getN_dcCollected() {
		return n_dcCollected;
	}
	public void setN_dcCollected(double n_dcCollected) {
		this.n_dcCollected = n_dcCollected;
	}
	public double getN_dcAccrual() {
		return n_dcAccrual;
	}
	public void setN_dcAccrual(double n_dcAccrual) {
		this.n_dcAccrual = n_dcAccrual;
	}
	public double getAdvancedRatio() {
		return advancedRatio;
	}
	public void setAdvancedRatio(double advancedRatio) {
		this.advancedRatio = advancedRatio;
	}
	public String getC_Status() {
		return c_Status;
	}
	public void setC_Status(String c_Status) {
		this.c_Status = c_Status;
	}
	public Double getN_ClntEquity() {
		return n_ClntEquity;
	}
	public void setN_ClntEquity(Double n_ClntEquity) {
		this.n_ClntEquity = n_ClntEquity;
	}
	public Double getN_DCRate() {
		return n_DCRate;
	}
	public void setN_DCRate(Double n_DCRate) {
		this.n_DCRate = n_DCRate;
	}
	public Date getD_BlrFrom() {
		return d_BlrFrom;
	}
	public void setD_BlrFrom(Date d_blrFrom) {
		d_BlrFrom = d_blrFrom;
	}
	public Date getD_BlrTo() {
		return d_BlrTo;
	}
	public void setD_BlrTo(Date d_blrTo) {
		d_BlrTo = d_blrTo;
	}
	public Double getN_CreditTerm() {
		return n_CreditTerm;
	}
	public void setN_CreditTerm(Double n_CreditTerm) {
		n_CreditTerm = n_CreditTerm;
	}
	public String getN_IndustryCode() {
		return n_IndustryCode;
	}
	public void setN_IndustryCode(String n_IndustryCode) {
		this.n_IndustryCode = n_IndustryCode;
	}
	public String getC_Industry() {
		return c_Industry;
	}
	public void setC_Industry(String c_Industry) {
		this.c_Industry = c_Industry;
	}
	public String getC_SizeOfFirm() {
		return c_SizeOfFirm;
	}
	public void setC_SizeOfFirm(String c_SizeOfFirm) {
		this.c_SizeOfFirm = c_SizeOfFirm;
	}
	public Double getN_CERatio() {
		return n_CERatio;
	}
	public void setN_CERatio(Double n_CERatio) {
		this.n_CERatio = n_CERatio;
	}
	public Double getN_serviceCharge() {
		return n_serviceCharge;
	}
	public void setN_serviceCharge(Double n_serviceCharge) {
		this.n_serviceCharge = n_serviceCharge;
	}
	public Double getN_penaltyCharge() {
		return n_penaltyCharge;
	}
	public void setN_penaltyCharge(Double n_penaltyCharge) {
		this.n_penaltyCharge = n_penaltyCharge;
	}
	public Double getCEUnpaid() {
		return CEUnpaid;
	}
	public void setCEUnpaid(Double cEUnpaid) {
		CEUnpaid = cEUnpaid;
	}
	public Double getN_receipts() {
		return n_receipts;
	}
	public void setN_receipts(Double n_receipts) {
		this.n_receipts = n_receipts;
	}
	public Double getN_overpayment() {
		return n_overpayment;
	}
	public void setN_overpayment(Double n_overpayment) {
		this.n_overpayment = n_overpayment;
	}
	public Double getN_CEPaid() {
		return n_CEPaid;
	}
	public void setN_CEPaid(Double n_CEPaid) {
		this.n_CEPaid = n_CEPaid;
	}
	public Date getD_PDODate() {
		return d_PDODate;
	}
	public void setD_PDODate(Date d_PDODate) {
		this.d_PDODate = d_PDODate;
	}
	public Date getD_lastDCCollected() {
		return d_lastDCCollected;
	}
	public void setD_lastDCCollected(Date d_lastDCCollected) {
		this.d_lastDCCollected = d_lastDCCollected;
	}
	public Date getD_lastPayment() {
		return d_lastPayment;
	}
	public void setD_lastPayment(Date d_lastPayment) {
		this.d_lastPayment = d_lastPayment;
	}
	public Date getD_lastRefund() {
		return d_lastRefund;
	}
	public void setD_lastRefund(Date d_lastRefund) {
		this.d_lastRefund = d_lastRefund;
	}
	public Date getD_lastAdvance() {
		return d_lastAdvance;
	}
	public void setD_lastAdvance(Date d_lastAdvance) {
		this.d_lastAdvance = d_lastAdvance;
	}
	public Date getD_DCRateChanged() {
		return d_DCRateChanged;
	}
	public void setD_DCRateChanged(Date d_DCRateChanged) {
		this.d_DCRateChanged = d_DCRateChanged;
	}
	public Double getN_prevDCRate() {
		return n_prevDCRate;
	}
	public void setN_prevDCRate(Double n_prevDCRate) {
		this.n_prevDCRate = n_prevDCRate;
	}
	public Date getD_AdvRatioChanged() {
		return d_AdvRatioChanged;
	}
	public void setD_AdvRatioChanged(Date d_AdvRatioChanged) {
		this.d_AdvRatioChanged = d_AdvRatioChanged;
	}
	public Double getN_prevAdvRate() {
		return n_prevAdvRate;
	}
	public void setN_prevAdvRate(Double n_prevAdvRate) {
		this.n_prevAdvRate = n_prevAdvRate;
	}
	public Double getN_dunning() {
		return n_dunning;
	}
	public void setN_dunning(Double n_dunning) {
		this.n_dunning = n_dunning;
	}
	public Double getN_avgDunning() {
		return n_avgDunning;
	}
	public void setN_avgDunning(Double n_avgDunning) {
		this.n_avgDunning = n_avgDunning;
	}
	public Date getD_review() {
		return d_review;
	}
	public void setD_review(Date d_review) {
		this.d_review = d_review;
	}
	public Double getN_CreditNote() {
		return n_CreditNote;
	}
	public void setN_CreditNote(Double n_CreditNote) {
		this.n_CreditNote = n_CreditNote;
	}
	public Date getD_ReviewDate() {
		return d_ReviewDate;
	}
	public void setD_ReviewDate(Date d_ReviewDate) {
		this.d_ReviewDate = d_ReviewDate;
	}
	public String getC_IndustryHeader() {
		return c_IndustryHeader;
	}
	public void setC_IndustryHeader(String c_IndustryHeader) {
		this.c_IndustryHeader = c_IndustryHeader;
	}
	public String getC_TIN() {
		return c_TIN;
	}
	public void setC_TIN(String c_TIN) {
		this.c_TIN = c_TIN;
	}
	public String getC_BorrowerType() {
		return c_BorrowerType;
	}
	public void setC_BorrowerType(String c_BorrowerType) {
		this.c_BorrowerType = c_BorrowerType;
	}
	public Double getN_Assets() {
		return n_Assets;
	}
	public void setN_Assets(Double n_Assets) {
		this.n_Assets = n_Assets;
	}
	public Double getN_Liabilities() {
		return n_Liabilities;
	}
	public void setN_Liabilities(Double n_Liabilities) {
		this.n_Liabilities = n_Liabilities;
	}
	public Double getN_Equity() {
		return n_Equity;
	}
	public void setN_Equity(Double n_Equity) {
		this.n_Equity = n_Equity;
	}
	public Double getN_GrossIncome() {
		return n_GrossIncome;
	}
	public void setN_GrossIncome(Double n_GrossIncome) {
		this.n_GrossIncome = n_GrossIncome;
	}
	public Double getN_Expenses() {
		return n_Expenses;
	}
	public void setN_Expenses(Double n_Expenses) {
		this.n_Expenses = n_Expenses;
	}
	public Double getN_NetIncome() {
		return n_NetIncome;
	}
	public void setN_NetIncome(Double n_NetIncome) {
		this.n_NetIncome = n_NetIncome;
	}
	public Date getD_audited() {
		return d_audited;
	}
	public void setD_audited(Date d_audited) {
		this.d_audited = d_audited;
	}
	public Double getN_Term() {
		return n_Term;
	}
	public void setN_Term(Double n_Term) {
		this.n_Term = n_Term;
	}
	public Double getN_scr() {
		return n_scr;
	}
	public void setN_scr(Double n_scr) {
		this.n_scr = n_scr;
	}
	public Double getN_dcr() {
		return n_dcr;
	}
	public void setN_dcr(Double n_dcr) {
		this.n_dcr = n_dcr;
	}
	public Double getN_DCAdjustment() {
		return n_DCAdjustment;
	}
	public void setN_DCAdjustment(Double n_DCAdjustment) {
		this.n_DCAdjustment = n_DCAdjustment;
	}
	public Double getN_avgDunning6mos() {
		return n_avgDunning6mos;
	}
	public void setN_avgDunning6mos(Double n_avgDunning6mos) {
		this.n_avgDunning6mos = n_avgDunning6mos;
	}
}
