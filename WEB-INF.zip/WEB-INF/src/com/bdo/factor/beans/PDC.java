package com.bdo.factor.beans;

import java.util.Date;

import com.bdo.factor.util.DateHelper;

public class PDC {
	private int n_RefNo;	
	private String c_ClntCode;
	private String c_CustCode;
	private Date d_ReceivedDate;
	private Date d_CheckedDate;
	private Date d_DepositDate;
	private String c_BankCode;
	private String n_CheckNo;
	private double n_CheckAmount;
	private String c_Receiver;
	private String c_CheckTypeCode;
	private String b_Processed;
	private Date d_DateBounced;	
	private String c_BranchCode;
	
	private String bankName;
	private String customerName;
	private String clientName;
	private String checkType;
	private String currencyCode;
	private String status;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public int getN_RefNo() {
		return n_RefNo;
	}
	public void setN_RefNo(int refNo) {
		n_RefNo = refNo;
	}	
	public String getC_ClntCode() {
		return c_ClntCode;
	}
	public void setC_ClntCode(String clntCode) {
		c_ClntCode = clntCode;
	}
	public String getC_CustCode() {
		return c_CustCode;
	}
	public void setC_CustCode(String custCode) {
		c_CustCode = custCode;
	}
	public Date getD_ReceivedDate() {
		return d_ReceivedDate;
	}
	public void setD_ReceivedDate(Date receivedDate) {
		d_ReceivedDate = receivedDate;
	}
	public Date getD_CheckedDate() {
		return d_CheckedDate;
	}
	public void setD_CheckedDate(Date checkedDate) {
		d_CheckedDate = checkedDate;
	}
	public Date getD_DepositDate() {
		return d_DepositDate;
	}
	public void setD_DepositDate(Date depositDate) {
		d_DepositDate = depositDate;
	}
	public String getC_BankCode() {
		return c_BankCode;
	}
	public void setC_BankCode(String bankCode) {
		c_BankCode = bankCode;
	}
	public String getN_CheckNo() {
		return n_CheckNo;
	}
	public void setN_CheckNo(String checkNo) {
		n_CheckNo = checkNo;
	}
	public double getN_CheckAmount() {
		return n_CheckAmount;
	}
	public void setN_CheckAmount(double checkAmount) {
		n_CheckAmount = checkAmount;
	}
	public String getC_Receiver() {
		return c_Receiver;
	}
	public void setC_Receiver(String receiver) {
		c_Receiver = receiver;
	}
	public String getC_CheckTypeCode() {
		return c_CheckTypeCode;
	}
	public void setC_CheckTypeCode(String checkTypeCode) {
		c_CheckTypeCode = checkTypeCode;
	}
	public String getB_Processed() {
		return b_Processed;
	}
	public void setB_Processed(String processed) {
		b_Processed = processed;
	}
	public Date getD_DateBounced() {
		return d_DateBounced;
	}
	public void setD_DateBounced(Date dateBounced) {
		d_DateBounced = dateBounced;
	}
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getCheckType() {
		return checkType;
	}
	public void setCheckType(String checkType) {
		this.checkType = checkType;
	}
	
	public String toString(){
		StringBuilder str = new StringBuilder();
		str.append("N_REFNO=").append(n_RefNo);
		str.append(";C_CLNTCODE=").append(c_ClntCode);
		str.append(";C_CUSTCODE=").append(c_CustCode);
		str.append(";D_RECEIVEDDATE=").append(DateHelper.format(d_ReceivedDate));
		str.append(";D_CHECKEDDATE=").append(DateHelper.format(d_CheckedDate));
		str.append(";D_DEPOSITDATE=").append(DateHelper.format(d_DepositDate));
		str.append(";C_BANKCODE=").append(c_BankCode);
		str.append(";N_CHECKNO=").append(n_CheckNo);
		str.append(";N_CHECKAMOUNT=").append(n_CheckAmount);
		str.append(";C_RECEIVER=").append(c_Receiver);
		str.append(";C_CHECKTYPECODE=").append(c_CheckTypeCode);
		str.append(";B_PROCESSED=").append(b_Processed);
		str.append(";D_DATEBOUNCED=").append(DateHelper.format(d_DateBounced));
		str.append(";C_BRANCHCODE=").append(c_BranchCode);
		return str.toString();
	}
}
