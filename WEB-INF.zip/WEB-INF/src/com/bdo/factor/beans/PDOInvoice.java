package com.bdo.factor.beans;

public class PDOInvoice 
{
	private String ao;
	private String client;
	private String customer;
	private double dunningPerLam;
	private double creditTerm;
	private String invoiceNumber;
	private int invoiceAge;
	private int actualInvoiceAge;
	private double amount;
	private double prePaymentRatio;
	private double lt90DPD;
	private double gt90DPD;
	
	public String getAo() {
		return ao;
	}
	public void setAo(String ao) {
		this.ao = ao;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public double getDunningPerLam() {
		return dunningPerLam;
	}
	public void setDunningPerLam(double dunningPerLam) {
		this.dunningPerLam = dunningPerLam;
	}
	public double getCreditTerm() {
		return creditTerm;
	}
	public void setCreditTerm(double creditTerm) {
		this.creditTerm = creditTerm;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public int getInvoiceAge() {
		return invoiceAge;
	}
	public void setInvoiceAge(int invoiceAge) {
		this.invoiceAge = invoiceAge;
	}
	public int getActualInvoiceAge() {
		return actualInvoiceAge;
	}
	public void setActualInvoiceAge(int actualInvoiceAge) {
		this.actualInvoiceAge = actualInvoiceAge;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getPrePaymentRatio() {
		return prePaymentRatio;
	}
	public void setPrePaymentRatio(double prePaymentRatio) {
		this.prePaymentRatio = prePaymentRatio;
	}
	public double getLt90DPD() {
		return lt90DPD;
	}
	public void setLt90DPD(double lt90DPD) {
		this.lt90DPD = lt90DPD;
	}
	public double getGt90DPD() {
		return gt90DPD;
	}
	public void setGt90DPD(double gt90DPD) {
		this.gt90DPD = gt90DPD;
	}	
}
