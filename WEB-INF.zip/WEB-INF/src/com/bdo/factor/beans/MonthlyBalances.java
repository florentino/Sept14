package com.bdo.factor.beans;

import java.math.BigDecimal;

public class MonthlyBalances {
	
	private String clientCode;
	private BigDecimal monthFIU;
	private BigDecimal monthReceivables;
	private BigDecimal monthReserves;
	

	private double N_JANFIU;
	private double N_FEBFIU;
	private double N_MARFIU;
	private double N_APRFIU;
	private double N_MAYFIU;
	private double N_JUNFIU;
	private double N_JULFIU;
	private double N_AUGFIU;
	private double N_SEPFIU;
	private double N_OCTFIU;
	private double N_NOVFIU;
	private double N_DECFIU;
	private double N_PREVJANFIU;
	private double N_PREVFEBFIU;
	private double N_PREVMARFIU;
	private double N_PREVAPRFIU;
	private double N_PREVMAYFIU;
	private double N_PREVJUNFIU;
	private double N_PREVJULFIU;
	private double N_PREVAUGFIU;
	private double N_PREVSEPFIU;
	private double N_PREVOCTFIU;
	private double N_PREVNOVFIU;
	private double N_PREVYRFIU;
	private double N_JANREC;
	private double N_FEBREC;
	private double N_MARREC;
	private double N_APRREC;
	private double N_MAYREC;
	private double N_JUNREC;
	private double N_JULREC;
	private double N_AUGREC;
	private double N_SEPREC;
	private double N_OCTREC;
	private double N_NOVREC;
	private double N_DECREC;
	private double N_PREVJANREC;
	private double N_PREVFEBREC;
	private double N_PREVMARREC;
	private double N_PREVAPRREC;
	private double N_PREVMAYREC;
	private double N_PREVJUNREC;
	private double N_PREVJULREC;
	private double N_PREVAUGREC;
	private double N_PREVSEPREC;
	private double N_PREVOCTREC;
	private double N_PREVNOVREC;
	private double N_PREVYRREC;
	private double N_JANRES;
	private double N_FEBRES;
	private double N_MARRES;
	private double N_APRRES;
	private double N_MAYRES;
	private double N_JUNRES;
	private double N_JULRES;
	private double N_AUGRES;
	private double N_SEPRES;
	private double N_OCTRES;
	private double N_NOVRES;
	private double N_DECRES;
	private double N_PREVJANRES;
	private double N_PREVFEBRES;
	private double N_PREVMARRES;
	private double N_PREVAPRRES;
	private double N_PREVMAYRES;
	private double N_PREVJUNRES;
	private double N_PREVJULRES;
	private double N_PREVAUGRES;
	private double N_PREVSEPRES;
	private double N_PREVOCTRES;
	private double N_PREVNOVRES;
	private double N_PREVYRRES;
	
	public MonthlyBalances() {
		// TODO Auto-generated constructor stub
	}
	
	public MonthlyBalances(BigDecimal monthFIU,BigDecimal monthReceivables,BigDecimal monthReserves) {
		this.monthFIU=monthFIU;
		this.monthReceivables=monthReceivables;
		this.monthReserves=monthReserves;
	}	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public String getClientCode() {
		return clientCode;
	}

	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	public BigDecimal getMonthFIU() {
		return monthFIU;
	}

	public void setMonthFIU(BigDecimal monthFIU) {
		this.monthFIU = monthFIU;
	}

	public BigDecimal getMonthReceivables() {
		return monthReceivables;
	}

	public void setMonthReceivables(BigDecimal monthReceivables) {
		this.monthReceivables = monthReceivables;
	}

	public BigDecimal getMonthReserves() {
		return monthReserves;
	}

	public void setMonthReserves(BigDecimal monthReserves) {
		this.monthReserves = monthReserves;
	}

	public double getN_JANFIU() {
		return N_JANFIU;
	}

	public void setN_JANFIU(double n_janfiu) {
		N_JANFIU = n_janfiu;
	}

	public double getN_FEBFIU() {
		return N_FEBFIU;
	}

	public void setN_FEBFIU(double n_febfiu) {
		N_FEBFIU = n_febfiu;
	}

	public double getN_MARFIU() {
		return N_MARFIU;
	}

	public void setN_MARFIU(double n_marfiu) {
		N_MARFIU = n_marfiu;
	}

	public double getN_APRFIU() {
		return N_APRFIU;
	}

	public void setN_APRFIU(double n_aprfiu) {
		N_APRFIU = n_aprfiu;
	}

	public double getN_MAYFIU() {
		return N_MAYFIU;
	}

	public void setN_MAYFIU(double n_mayfiu) {
		N_MAYFIU = n_mayfiu;
	}

	public double getN_JUNFIU() {
		return N_JUNFIU;
	}

	public void setN_JUNFIU(double n_junfiu) {
		N_JUNFIU = n_junfiu;
	}

	public double getN_JULFIU() {
		return N_JULFIU;
	}

	public void setN_JULFIU(double n_julfiu) {
		N_JULFIU = n_julfiu;
	}

	public double getN_AUGFIU() {
		return N_AUGFIU;
	}

	public void setN_AUGFIU(double n_augfiu) {
		N_AUGFIU = n_augfiu;
	}

	public double getN_SEPFIU() {
		return N_SEPFIU;
	}

	public void setN_SEPFIU(double n_sepfiu) {
		N_SEPFIU = n_sepfiu;
	}

	public double getN_OCTFIU() {
		return N_OCTFIU;
	}

	public void setN_OCTFIU(double n_octfiu) {
		N_OCTFIU = n_octfiu;
	}

	public double getN_NOVFIU() {
		return N_NOVFIU;
	}

	public void setN_NOVFIU(double n_novfiu) {
		N_NOVFIU = n_novfiu;
	}

	public double getN_DECFIU() {
		return N_DECFIU;
	}

	public void setN_DECFIU(double n_decfiu) {
		N_DECFIU = n_decfiu;
	}

	public double getN_PREVJANFIU() {
		return N_PREVJANFIU;
	}

	public void setN_PREVJANFIU(double n_prevjanfiu) {
		N_PREVJANFIU = n_prevjanfiu;
	}

	public double getN_PREVFEBFIU() {
		return N_PREVFEBFIU;
	}

	public void setN_PREVFEBFIU(double n_prevfebfiu) {
		N_PREVFEBFIU = n_prevfebfiu;
	}

	public double getN_PREVMARFIU() {
		return N_PREVMARFIU;
	}

	public void setN_PREVMARFIU(double n_prevmarfiu) {
		N_PREVMARFIU = n_prevmarfiu;
	}

	public double getN_PREVAPRFIU() {
		return N_PREVAPRFIU;
	}

	public void setN_PREVAPRFIU(double n_prevaprfiu) {
		N_PREVAPRFIU = n_prevaprfiu;
	}

	public double getN_PREVMAYFIU() {
		return N_PREVMAYFIU;
	}

	public void setN_PREVMAYFIU(double n_prevmayfiu) {
		N_PREVMAYFIU = n_prevmayfiu;
	}

	public double getN_PREVJUNFIU() {
		return N_PREVJUNFIU;
	}

	public void setN_PREVJUNFIU(double n_prevjunfiu) {
		N_PREVJUNFIU = n_prevjunfiu;
	}

	public double getN_PREVJULFIU() {
		return N_PREVJULFIU;
	}

	public void setN_PREVJULFIU(double n_prevjulfiu) {
		N_PREVJULFIU = n_prevjulfiu;
	}

	public double getN_PREVAUGFIU() {
		return N_PREVAUGFIU;
	}

	public void setN_PREVAUGFIU(double n_prevaugfiu) {
		N_PREVAUGFIU = n_prevaugfiu;
	}

	public double getN_PREVSEPFIU() {
		return N_PREVSEPFIU;
	}

	public void setN_PREVSEPFIU(double n_prevsepfiu) {
		N_PREVSEPFIU = n_prevsepfiu;
	}

	public double getN_PREVOCTFIU() {
		return N_PREVOCTFIU;
	}

	public void setN_PREVOCTFIU(double n_prevoctfiu) {
		N_PREVOCTFIU = n_prevoctfiu;
	}

	public double getN_PREVNOVFIU() {
		return N_PREVNOVFIU;
	}

	public void setN_PREVNOVFIU(double n_prevnovfiu) {
		N_PREVNOVFIU = n_prevnovfiu;
	}

	public double getN_PREVYRFIU() {
		return N_PREVYRFIU;
	}

	public void setN_PREVYRFIU(double n_prevyrfiu) {
		N_PREVYRFIU = n_prevyrfiu;
	}

	public double getN_JANREC() {
		return N_JANREC;
	}

	public void setN_JANREC(double n_janrec) {
		N_JANREC = n_janrec;
	}

	public double getN_FEBREC() {
		return N_FEBREC;
	}

	public void setN_FEBREC(double n_febrec) {
		N_FEBREC = n_febrec;
	}

	public double getN_MARREC() {
		return N_MARREC;
	}

	public void setN_MARREC(double n_marrec) {
		N_MARREC = n_marrec;
	}

	public double getN_APRREC() {
		return N_APRREC;
	}

	public void setN_APRREC(double n_aprrec) {
		N_APRREC = n_aprrec;
	}

	public double getN_MAYREC() {
		return N_MAYREC;
	}

	public void setN_MAYREC(double n_mayrec) {
		N_MAYREC = n_mayrec;
	}

	public double getN_JUNREC() {
		return N_JUNREC;
	}

	public void setN_JUNREC(double n_junrec) {
		N_JUNREC = n_junrec;
	}

	public double getN_JULREC() {
		return N_JULREC;
	}

	public void setN_JULREC(double n_julrec) {
		N_JULREC = n_julrec;
	}

	public double getN_AUGREC() {
		return N_AUGREC;
	}

	public void setN_AUGREC(double n_augrec) {
		N_AUGREC = n_augrec;
	}

	public double getN_SEPREC() {
		return N_SEPREC;
	}

	public void setN_SEPREC(double n_seprec) {
		N_SEPREC = n_seprec;
	}

	public double getN_OCTREC() {
		return N_OCTREC;
	}

	public void setN_OCTREC(double n_octrec) {
		N_OCTREC = n_octrec;
	}

	public double getN_NOVREC() {
		return N_NOVREC;
	}

	public void setN_NOVREC(double n_novrec) {
		N_NOVREC = n_novrec;
	}

	public double getN_DECREC() {
		return N_DECREC;
	}

	public void setN_DECREC(double n_decrec) {
		N_DECREC = n_decrec;
	}

	public double getN_PREVJANREC() {
		return N_PREVJANREC;
	}

	public void setN_PREVJANREC(double n_prevjanrec) {
		N_PREVJANREC = n_prevjanrec;
	}

	public double getN_PREVFEBREC() {
		return N_PREVFEBREC;
	}

	public void setN_PREVFEBREC(double n_prevfebrec) {
		N_PREVFEBREC = n_prevfebrec;
	}

	public double getN_PREVMARREC() {
		return N_PREVMARREC;
	}

	public void setN_PREVMARREC(double n_prevmarrec) {
		N_PREVMARREC = n_prevmarrec;
	}

	public double getN_PREVAPRREC() {
		return N_PREVAPRREC;
	}

	public void setN_PREVAPRREC(double n_prevaprrec) {
		N_PREVAPRREC = n_prevaprrec;
	}

	public double getN_PREVMAYREC() {
		return N_PREVMAYREC;
	}

	public void setN_PREVMAYREC(double n_prevmayrec) {
		N_PREVMAYREC = n_prevmayrec;
	}

	public double getN_PREVJUNREC() {
		return N_PREVJUNREC;
	}

	public void setN_PREVJUNREC(double n_prevjunrec) {
		N_PREVJUNREC = n_prevjunrec;
	}

	public double getN_PREVJULREC() {
		return N_PREVJULREC;
	}

	public void setN_PREVJULREC(double n_prevjulrec) {
		N_PREVJULREC = n_prevjulrec;
	}

	public double getN_PREVAUGREC() {
		return N_PREVAUGREC;
	}

	public void setN_PREVAUGREC(double n_prevaugrec) {
		N_PREVAUGREC = n_prevaugrec;
	}

	public double getN_PREVSEPREC() {
		return N_PREVSEPREC;
	}

	public void setN_PREVSEPREC(double n_prevseprec) {
		N_PREVSEPREC = n_prevseprec;
	}

	public double getN_PREVOCTREC() {
		return N_PREVOCTREC;
	}

	public void setN_PREVOCTREC(double n_prevoctrec) {
		N_PREVOCTREC = n_prevoctrec;
	}

	public double getN_PREVNOVREC() {
		return N_PREVNOVREC;
	}

	public void setN_PREVNOVREC(double n_prevnovrec) {
		N_PREVNOVREC = n_prevnovrec;
	}

	public double getN_PREVYRREC() {
		return N_PREVYRREC;
	}

	public void setN_PREVYRREC(double n_prevyrrec) {
		N_PREVYRREC = n_prevyrrec;
	}

	public double getN_JANRES() {
		return N_JANRES;
	}

	public void setN_JANRES(double n_janres) {
		N_JANRES = n_janres;
	}

	public double getN_FEBRES() {
		return N_FEBRES;
	}

	public void setN_FEBRES(double n_febres) {
		N_FEBRES = n_febres;
	}

	public double getN_MARRES() {
		return N_MARRES;
	}

	public void setN_MARRES(double n_marres) {
		N_MARRES = n_marres;
	}

	public double getN_APRRES() {
		return N_APRRES;
	}

	public void setN_APRRES(double n_aprres) {
		N_APRRES = n_aprres;
	}

	public double getN_MAYRES() {
		return N_MAYRES;
	}

	public void setN_MAYRES(double n_mayres) {
		N_MAYRES = n_mayres;
	}

	public double getN_JUNRES() {
		return N_JUNRES;
	}

	public void setN_JUNRES(double n_junres) {
		N_JUNRES = n_junres;
	}

	public double getN_JULRES() {
		return N_JULRES;
	}

	public void setN_JULRES(double n_julres) {
		N_JULRES = n_julres;
	}

	public double getN_AUGRES() {
		return N_AUGRES;
	}

	public void setN_AUGRES(double n_augres) {
		N_AUGRES = n_augres;
	}

	public double getN_SEPRES() {
		return N_SEPRES;
	}

	public void setN_SEPRES(double n_sepres) {
		N_SEPRES = n_sepres;
	}

	public double getN_OCTRES() {
		return N_OCTRES;
	}

	public void setN_OCTRES(double n_octres) {
		N_OCTRES = n_octres;
	}

	public double getN_NOVRES() {
		return N_NOVRES;
	}

	public void setN_NOVRES(double n_novres) {
		N_NOVRES = n_novres;
	}

	public double getN_DECRES() {
		return N_DECRES;
	}

	public void setN_DECRES(double n_decres) {
		N_DECRES = n_decres;
	}

	public double getN_PREVJANRES() {
		return N_PREVJANRES;
	}

	public void setN_PREVJANRES(double n_prevjanres) {
		N_PREVJANRES = n_prevjanres;
	}

	public double getN_PREVFEBRES() {
		return N_PREVFEBRES;
	}

	public void setN_PREVFEBRES(double n_prevfebres) {
		N_PREVFEBRES = n_prevfebres;
	}

	public double getN_PREVMARRES() {
		return N_PREVMARRES;
	}

	public void setN_PREVMARRES(double n_prevmarres) {
		N_PREVMARRES = n_prevmarres;
	}

	public double getN_PREVAPRRES() {
		return N_PREVAPRRES;
	}

	public void setN_PREVAPRRES(double n_prevaprres) {
		N_PREVAPRRES = n_prevaprres;
	}

	public double getN_PREVMAYRES() {
		return N_PREVMAYRES;
	}

	public void setN_PREVMAYRES(double n_prevmayres) {
		N_PREVMAYRES = n_prevmayres;
	}

	public double getN_PREVJUNRES() {
		return N_PREVJUNRES;
	}

	public void setN_PREVJUNRES(double n_prevjunres) {
		N_PREVJUNRES = n_prevjunres;
	}

	public double getN_PREVJULRES() {
		return N_PREVJULRES;
	}

	public void setN_PREVJULRES(double n_prevjulres) {
		N_PREVJULRES = n_prevjulres;
	}

	public double getN_PREVAUGRES() {
		return N_PREVAUGRES;
	}

	public void setN_PREVAUGRES(double n_prevaugres) {
		N_PREVAUGRES = n_prevaugres;
	}

	public double getN_PREVSEPRES() {
		return N_PREVSEPRES;
	}

	public void setN_PREVSEPRES(double n_prevsepres) {
		N_PREVSEPRES = n_prevsepres;
	}

	public double getN_PREVOCTRES() {
		return N_PREVOCTRES;
	}

	public void setN_PREVOCTRES(double n_prevoctres) {
		N_PREVOCTRES = n_prevoctres;
	}

	public double getN_PREVNOVRES() {
		return N_PREVNOVRES;
	}

	public void setN_PREVNOVRES(double n_prevnovres) {
		N_PREVNOVRES = n_prevnovres;
	}

	public double getN_PREVYRRES() {
		return N_PREVYRRES;
	}

	public void setN_PREVYRRES(double n_prevyrres) {
		N_PREVYRRES = n_prevyrres;
	}
	
	public String toString(){
		StringBuilder str  = new StringBuilder();
		str.append("C_CLNTCODE=").append(this.clientCode);
		str.append("; N_JANFIU=").append(this.N_JANFIU);
		str.append("; N_FEBFIU=").append(this.N_FEBFIU);
		str.append("; N_MARFIU=").append(this.N_MARFIU);
		str.append("; N_APRFIU=").append(this.N_APRFIU);
		str.append("; N_MAYFIU=").append(this.N_MAYFIU);
		str.append("; N_JUNFIU=").append(this.N_JUNFIU);
		str.append("; N_JULFIU=").append(this.N_JULFIU);
		str.append("; N_AUGFIU=").append(this.N_AUGFIU);
		str.append("; N_SEPFIU=").append(this.N_SEPFIU);
		str.append("; N_OCTFIU=").append(this.N_OCTFIU);
		str.append("; N_NOVFIU=").append(this.N_NOVFIU);
		str.append("; N_DECFIU=").append(this.N_DECFIU);
		
		str.append("; N_JANREC=").append(this.N_JANREC);
		str.append("; N_FEBREC=").append(this.N_FEBREC);
		str.append("; N_MARREC=").append(this.N_MARREC);
		str.append("; N_APRREC=").append(this.N_APRREC);
		str.append("; N_MAYREC=").append(this.N_MAYREC);
		str.append("; N_JUNREC=").append(this.N_JUNREC);
		str.append("; N_JULREC=").append(this.N_JULREC);
		str.append("; N_AUGREC=").append(this.N_AUGREC);
		str.append("; N_SEPREC=").append(this.N_SEPREC);
		str.append("; N_OCTREC=").append(this.N_OCTREC);
		str.append("; N_NOVREC=").append(this.N_NOVREC);
		str.append("; N_DECREC=").append(this.N_DECREC);	
		
		str.append("; N_JANRES=").append(this.N_JANRES);
		str.append("; N_FEBRES=").append(this.N_FEBRES);
		str.append("; N_MARRES=").append(this.N_MARRES);
		str.append("; N_APRRES=").append(this.N_APRRES);
		str.append("; N_MAYRES=").append(this.N_MAYRES);
		str.append("; N_JUNRES=").append(this.N_JUNRES);
		str.append("; N_JULRES=").append(this.N_JULRES);
		str.append("; N_AUGRES=").append(this.N_AUGRES);
		str.append("; N_SEPRES=").append(this.N_SEPRES);
		str.append("; N_OCTRES=").append(this.N_OCTRES);
		str.append("; N_NOVRES=").append(this.N_NOVRES);
		str.append("; N_DECRES=").append(this.N_DECRES);		

//
		str.append("; N_PREVJANFIU=").append(this.N_PREVJANFIU);
		str.append("; N_PREVFEBFIU=").append(this.N_PREVFEBFIU);
		str.append("; N_PREVMARFIU=").append(this.N_PREVMARFIU);
		str.append("; N_PREVAPRFIU=").append(this.N_PREVAPRFIU);
		str.append("; N_PREVMAYFIU=").append(this.N_PREVMAYFIU);
		str.append("; N_PREVJUNFIU=").append(this.N_PREVJUNFIU);
		str.append("; N_PREVJULFIU=").append(this.N_PREVJULFIU);
		str.append("; N_PREVAUGFIU=").append(this.N_PREVAUGFIU);
		str.append("; N_PREVSEPFIU=").append(this.N_PREVSEPFIU);
		str.append("; N_PREVOCTFIU=").append(this.N_PREVOCTFIU);
		str.append("; N_PREVNOVFIU=").append(this.N_PREVNOVFIU);
		str.append("; N_PREVYRFIU=").append(this.N_PREVYRFIU);
		
		str.append("; N_PREVJANREC=").append(this.N_PREVJANREC);
		str.append("; N_PREVFEBREC=").append(this.N_PREVFEBREC);
		str.append("; N_PREVMARREC=").append(this.N_PREVMARREC);
		str.append("; N_PREVAPRREC=").append(this.N_PREVAPRREC);
		str.append("; N_PREVMAYREC=").append(this.N_PREVMAYREC);
		str.append("; N_PREVJUNREC=").append(this.N_PREVJUNREC);
		str.append("; N_PREVJULREC=").append(this.N_PREVJULREC);
		str.append("; N_PREVAUGREC=").append(this.N_PREVAUGREC);
		str.append("; N_PREVSEPREC=").append(this.N_PREVSEPREC);
		str.append("; N_PREVOCTREC=").append(this.N_PREVOCTREC);
		str.append("; N_PREVNOVREC=").append(this.N_PREVNOVREC);
		str.append("; N_PREVDECREC=").append(this.N_PREVYRREC);	
		
		str.append("; N_PREVJANRES=").append(this.N_PREVJANRES);
		str.append("; N_PREVFEBRES=").append(this.N_PREVFEBRES);
		str.append("; N_PREVMARRES=").append(this.N_PREVMARRES);
		str.append("; N_PREVAPRRES=").append(this.N_PREVAPRRES);
		str.append("; N_PREVMAYRES=").append(this.N_PREVMAYRES);
		str.append("; N_PREVJUNRES=").append(this.N_PREVJUNRES);
		str.append("; N_PREVJULRES=").append(this.N_PREVJULRES);
		str.append("; N_PREVAUGRES=").append(this.N_PREVAUGRES);
		str.append("; N_PREVSEPRES=").append(this.N_PREVSEPRES);
		str.append("; N_PREVOCTRES=").append(this.N_PREVOCTRES);
		str.append("; N_PREVNOVRES=").append(this.N_PREVNOVRES);
		str.append("; N_PREVDECRES=").append(this.N_PREVYRRES);		
		
		
		return str.toString();
	}

}
