package com.bdo.factor.beans;

public class FactoringStatistics 
{
	private String monthName;
	private double prevInvoiceAmt;
	private  double currInvoiceAmt;
	private double prevCollection;
	private double currCollection;
	private double prevFIU;
	private double currFIU;
	private String clientName;
	private String systemName;
	private String serviceOfficerName;
	
	
	public String getServiceOfficerName() {
		return serviceOfficerName;
	}
	public void setServiceOfficerName(String serviceOfficerName) {
		this.serviceOfficerName = serviceOfficerName;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getMonthName() {
		return monthName;
	}
	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}
	public double getPrevInvoiceAmt() {
		return prevInvoiceAmt;
	}
	public void setPrevInvoiceAmt(double prevInvoiceAmt) {
		this.prevInvoiceAmt = prevInvoiceAmt;
	}
	public double getCurrInvoiceAmt() {
		return currInvoiceAmt;
	}
	public void setCurrInvoiceAmt(double currInvoiceAmt) {
		this.currInvoiceAmt = currInvoiceAmt;
	}
	public double getPrevCollection() {
		return prevCollection;
	}
	public void setPrevCollection(double prevCollection) {
		this.prevCollection = prevCollection;
	}
	public double getCurrCollection() {
		return currCollection;
	}
	public void setCurrCollection(double currCollection) {
		this.currCollection = currCollection;
	}
	public double getPrevFIU() {
		return prevFIU;
	}
	public void setPrevFIU(double prevFIU) {
		this.prevFIU = prevFIU;
	}
	public double getCurrFIU() {
		return currFIU;
	}
	public void setCurrFIU(double currFIU) {
		this.currFIU = currFIU;
	}		
}
