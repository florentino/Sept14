 package com.bdo.factor.beans;

import java.util.Date;

public class Client {
	
	private String c_BranchCode;
	private String c_ClntCode;
	private String c_Name;
	private String c_GroupCode;
	private String c_Address;
	private String c_BlrTypeCode;
	private double n_Dcr;
	private double n_Scr;
	private String c_BnkActNo;
	private String c_BankCode;
	private double n_CreditLimit;
	private String c_AcctOfficerCode;
	private double n_CredAvail;
	private double n_Fiu;
	
	private String c_Contact;
	private double n_Receivables;
	private double n_Reserves;
	private String c_Currency;
	private String c_CurrencyCode;
	private double n_AdvRatio;
	private String d_ReviewDate;
	//added by CVG 03-04-16
		private double notarialFee;
		
	private Date date_tagged_rmu;
	private boolean is_rmu;
	
	public Date getDate_tagged_rmu() {
		return date_tagged_rmu;
	}
	public void setDate_tagged_rmu(Date date_tagged_rmu) {
		this.date_tagged_rmu = date_tagged_rmu;
	}
	public boolean isIs_rmu() {
		return is_rmu;
	}
	public void setIs_rmu(boolean is_rmu) {
		this.is_rmu = is_rmu;
	}
	public String getC_CurrencyCode() {
		return c_CurrencyCode;
	}
	public void setC_CurrencyCode(String currencyCode) {
		c_CurrencyCode = currencyCode;
	}
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public String getC_ClntCode() {
		return c_ClntCode;
	}
	public void setC_ClntCode(String clntCode) {
		c_ClntCode = clntCode;
	}
	public String getC_Name() {
		return c_Name;
	}
	public void setC_Name(String name) {
		c_Name = name;
	}
	public String getC_GroupCode() {
		return c_GroupCode;
	}
	public void setC_GroupCode(String groupCode) {
		c_GroupCode = groupCode;
	}
	public String getC_Address() {
		return c_Address;
	}
	public void setC_Address(String address) {
		c_Address = address;
	}
	public String getC_BlrTypeCode() {
		return c_BlrTypeCode;
	}
	public void setC_BlrTypeCode(String blrTypeCode) {
		c_BlrTypeCode = blrTypeCode;
	}
	public double getN_Dcr() {
		return n_Dcr;
	}
	public void setN_Dcr(double dcr) {
		n_Dcr = dcr;
	}
	public double getN_Scr() {
		return n_Scr;
	}
	public void setN_Scr(double scr) {
		n_Scr = scr;
	}
	public String getC_BnkActNo() {
		return c_BnkActNo;
	}
	public void setC_BnkActNo(String bnkActNo) {
		c_BnkActNo = bnkActNo;
	}
	public String getC_BankCode() {
		return c_BankCode;
	}
	public void setC_BankCode(String bankCode) {
		c_BankCode = bankCode;
	}
	public double getN_CreditLimit() {
		return n_CreditLimit;
	}
	public void setN_CreditLimit(double creditLimit) {
		n_CreditLimit = creditLimit;
	}
	public String getC_AcctOfficerCode() {
		return c_AcctOfficerCode;
	}
	public void setC_AcctOfficerCode(String acctOfficerCode) {
		c_AcctOfficerCode = acctOfficerCode;
	}
	public double getN_CredAvail() {
		return n_CredAvail;
	}
	public void setN_CredAvail(double credAvail) {
		n_CredAvail = credAvail;
	}
	public double getN_Fiu() {
		return n_Fiu;
	}
	public void setN_Fiu(double fiu) {
		n_Fiu = fiu;
	}
		
	public String getC_Contact() {
		return c_Contact;
	}
	public void setC_Contact(String contact) {
		c_Contact = contact;
	}
	public double getN_Receivables() {
		return n_Receivables;
	}
	public void setN_Receivables(double receivables) {
		n_Receivables = receivables;
	}
	public double getN_Reserves() {
		return n_Reserves;
	}
	public void setN_Reserves(double reserves) {
		n_Reserves = reserves;
	}	
	public String getC_Currency() {
		return c_Currency;
	}
	public void setC_Currency(String currency) {
		c_Currency = currency;
	}
	public double getN_AdvRatio() {
		return n_AdvRatio;
	}
	public void setN_AdvRatio(double advratio) {
		n_AdvRatio = advratio;
	}
	
	//added by CVG 
	public double getNotarialFee() {
		return notarialFee;
	}
	public void setNotarialFee(double notarialFee) {
		this.notarialFee = notarialFee;
	}
	
	
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(c_BranchCode);
		str.append(";C_CLNTCODE=").append(c_ClntCode);
		str.append(";C_NAME=").append(c_Name);
		str.append(";C_GROUPCODE=").append(c_GroupCode);
		str.append(";C_ADDRESS").append(c_Address);
		str.append(";C_BLRTYPECODE=").append(c_BlrTypeCode);
		str.append(";N_DCR=").append(n_Dcr);
		str.append(";N_SCR=").append(n_Scr);
		str.append(";C_BNKACTNO=").append(c_BnkActNo);
		str.append(";C_BANKCODE=").append(c_BankCode);
		str.append(";N_CREDITLIMIT=").append(n_CreditLimit);
		str.append(";C_ACCTOFFICERCODE=").append(c_AcctOfficerCode);
		str.append(";N_CREDAVAIL=").append(n_CredAvail);
		str.append(";N_FIU=").append(n_Fiu);
		str.append(";N_ADVANCEDRATIO=").append(n_AdvRatio);
		str.append(";D_REVIEWDATE=").append(d_ReviewDate);
		return str.toString();
	}
	
	public void setD_ReviewDate(String d_ReviewDate) {
		this.d_ReviewDate = d_ReviewDate;
	}
	public String getD_ReviewDate() {
		return d_ReviewDate;
	}
	
}
