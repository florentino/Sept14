package com.bdo.factor.beans;

import java.util.Date;
import java.util.Map;

public class BLRFileClientMaster {

	
/////////////////////////////////////////////////////////////////////////////////

	private String C_BLRTYPECODE;
	
	private String 	N_BLR1;
	private String 	D_EFFDT1;
	private String 	D_EXPDT1;
	
	private String 	N_BLR2;
	private String 	D_EFFDT2;
	private String 	D_EXPDT2;

	private String 	N_BLR3;
	private String 	D_EFFDT3;
	private String 	D_EXPDT3;

	private String 	N_BLR4;
	private String 	D_EFFDT4;
	private String 	D_EXPDT4;

	private String 	N_BLR5;
	private String 	D_EFFDT5;
	private String 	D_EXPDT5;

/////////////////////////////////////////////////////////////////////////////////
	
	public BLRFileClientMaster(){
	}

/////////////////////////////////////////////////////////////////////////////////

	
	public BLRFileClientMaster(Map map){

		if(map.containsKey("C_BLRTYPECODE") && map.get("C_BLRTYPECODE")!=null)
			this.setC_BLRTYPECODE(map.get("C_BLRTYPECODE").toString());
		
		if(map.containsKey("N_BLR1") && map.get("N_BLR1")!=null)
			this.setN_BLR1(map.get("N_BLR1").toString());
		
		if(map.containsKey("D_EFFDT1") && map.get("D_EFFDT1")!=null)
			this.setD_EFFDT1(map.get("D_EFFDT1").toString());
		
		if(map.containsKey("D_EXPDT1") && map.get("D_EXPDT1")!=null)
			this.setD_EXPDT1(map.get("D_EXPDT1").toString());
		
		if(map.containsKey("N_BLR2") && map.get("N_BLR2")!=null)
			this.setN_BLR2(map.get("N_BLR2").toString());
		
		if(map.containsKey("D_EFFDT2") && map.get("D_EFFDT2")!=null)
			this.setD_EFFDT2(map.get("D_EFFDT2").toString());
		
		if(map.containsKey("D_EXPDT2") && map.get("D_EXPDT2")!=null)
			this.setD_EXPDT2(map.get("D_EXPDT2").toString());
		
		if(map.containsKey("N_BLR3") && map.get("N_BLR3")!=null)
			this.setN_BLR3(map.get("N_BLR3").toString());
		
		if(map.containsKey("D_EFFDT3") && map.get("D_EFFDT3")!=null)
			this.setD_EFFDT3(map.get("D_EFFDT3").toString());
		
		if(map.containsKey("D_EXPDT3") && map.get("D_EXPDT3")!=null)
			this.setD_EXPDT3(map.get("D_EXPDT3").toString());

		if(map.containsKey("N_BLR4") && map.get("N_BLR4")!=null)
			this.setN_BLR4(map.get("N_BLR4").toString());
		
		if(map.containsKey("D_EFFDT4") && map.get("D_EFFDT4")!=null)
			this.setD_EFFDT4(map.get("D_EFFDT4").toString());
		
		if(map.containsKey("D_EXPDT4") && map.get("D_EXPDT4")!=null)
			this.setD_EXPDT4(map.get("D_EXPDT4").toString());

		if(map.containsKey("N_BLR5") && map.get("N_BLR5")!=null)
			this.setN_BLR5(map.get("N_BLR5").toString());
		
		if(map.containsKey("D_EFFDT5") && map.get("D_EFFDT5")!=null)
			this.setD_EFFDT5(map.get("D_EFFDT5").toString());
		
		if(map.containsKey("D_EXPDT5") && map.get("D_EXPDT5")!=null)
			this.setD_EXPDT5(map.get("D_EXPDT5").toString());
		
	}
	
/////////////////////////////////////////////////////////////////////////////////	

	public String toString() {
		
		StringBuilder strBLRFileClientMaster = new StringBuilder();
		
		strBLRFileClientMaster.append("C_BLRTYPECODE=").append(C_BLRTYPECODE);
		
		strBLRFileClientMaster.append(";N_BLR1=").append(N_BLR1);
		strBLRFileClientMaster.append(";D_EFFDT1=").append(D_EFFDT1);
		strBLRFileClientMaster.append(";D_EXPDT1=").append(D_EXPDT1);
		
		strBLRFileClientMaster.append(";N_BLR2=").append(N_BLR2);
		strBLRFileClientMaster.append(";D_EFFDT2=").append(D_EFFDT2);
		strBLRFileClientMaster.append(";D_EXPDT2=").append(D_EXPDT2);

		strBLRFileClientMaster.append(";N_BLR3=").append(N_BLR3);
		strBLRFileClientMaster.append(";D_EFFDT3=").append(D_EFFDT3);
		strBLRFileClientMaster.append(";D_EXPDT3=").append(D_EXPDT3);

		strBLRFileClientMaster.append(";N_BLR4=").append(N_BLR4);
		strBLRFileClientMaster.append(";D_EFFDT4=").append(D_EFFDT4);
		strBLRFileClientMaster.append(";D_EXPDT4=").append(D_EXPDT4);

		strBLRFileClientMaster.append(";N_BLR5=").append(N_BLR5);
		strBLRFileClientMaster.append(";D_EFFDT5=").append(D_EFFDT5);
		strBLRFileClientMaster.append(";D_EXPDT5=").append(D_EXPDT5);

		
		return strBLRFileClientMaster.toString();
	}
	

/////////////////////////////////////////////////////////////////////////////////

	
	public String getN_BLR1() {
		return N_BLR1;
	}
	public void setN_BLR1(String n_blr1) {
		N_BLR1 = n_blr1;
	}
	public String getD_EFFDT1() {
		return D_EFFDT1;
	}
	public void setD_EFFDT1(String d_effdt1) {
		D_EFFDT1 = d_effdt1;
	}
	public String getD_EXPDT1() {
		return D_EXPDT1;
	}
	public void setD_EXPDT1(String d_expdt1) {
		D_EXPDT1 = d_expdt1;
	}
	public String getN_BLR2() {
		return N_BLR2;
	}
	public void setN_BLR2(String n_blr2) {
		N_BLR2 = n_blr2;
	}
	public String getD_EFFDT2() {
		return D_EFFDT2;
	}
	public void setD_EFFDT2(String d_effdt2) {
		D_EFFDT2 = d_effdt2;
	}
	public String getD_EXPDT2() {
		return D_EXPDT2;
	}
	public void setD_EXPDT2(String d_expdt2) {
		D_EXPDT2 = d_expdt2;
	}
	public String getN_BLR3() {
		return N_BLR3;
	}
	public void setN_BLR3(String n_blr3) {
		N_BLR3 = n_blr3;
	}
	public String getD_EFFDT3() {
		return D_EFFDT3;
	}
	public void setD_EFFDT3(String d_effdt3) {
		D_EFFDT3 = d_effdt3;
	}
	public String getD_EXPDT3() {
		return D_EXPDT3;
	}
	public void setD_EXPDT3(String d_expdt3) {
		D_EXPDT3 = d_expdt3;
	}
	public String getN_BLR4() {
		return N_BLR4;
	}
	public void setN_BLR4(String n_blr4) {
		N_BLR4 = n_blr4;
	}
	public String getD_EFFDT4() {
		return D_EFFDT4;
	}
	public void setD_EFFDT4(String d_effdt4) {
		D_EFFDT4 = d_effdt4;
	}
	public String getD_EXPDT4() {
		return D_EXPDT4;
	}
	public void setD_EXPDT4(String d_expdt4) {
		D_EXPDT4 = d_expdt4;
	}
	public String getN_BLR5() {
		return N_BLR5;
	}
	public void setN_BLR5(String n_blr5) {
		N_BLR5 = n_blr5;
	}
	public String getD_EFFDT5() {
		return D_EFFDT5;
	}
	public void setD_EFFDT5(String d_effdt5) {
		D_EFFDT5 = d_effdt5;
	}
	public String getD_EXPDT5() {
		return D_EXPDT5;
	}
	public void setD_EXPDT5(String d_expdt5) {
		D_EXPDT5 = d_expdt5;
	}

	public String getC_BLRTYPECODE() {
		return C_BLRTYPECODE;
	}

	public void setC_BLRTYPECODE(String c_blrtypecode) {
		C_BLRTYPECODE = c_blrtypecode;
	}

/////////////////////////////////////////////////////////////////////////////////

		
}
