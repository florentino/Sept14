package com.bdo.factor.beans;

import java.util.Date;

public class ClientDebtTurn {
	private String clientName;
	private String customerName;
	private String accountOfficer;
	private double dunning;
	private String monthPaid;
	private String invoiceNo;
	private Date invoiceDate;
	private double amount;
	private double amountCollected;
	private Date datePaid;
	private int speedPaid;
	private double average;
	private double totalAverage;
	private double totalInv;
	private Date currentDate;
	
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAccountOfficer() {
		return accountOfficer;
	}
	public void setAccountOfficer(String accountOfficer) {
		this.accountOfficer = accountOfficer;
	}
	public double getDunning() {
		return dunning;
	}
	public void setDunning(double dunning) {
		this.dunning = dunning;
	}
	public String getMonthPaid() {
		return monthPaid;
	}
	public void setMonthPaid(String monthPaid) {
		this.monthPaid = monthPaid;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getAmountCollected() {
		return amountCollected;
	}
	public void setAmountCollected(double amountCollected) {
		this.amountCollected = amountCollected;
	}
	public Date getDatePaid() {
		return datePaid;
	}
	public void setDatePaid(Date datePaid) {
		this.datePaid = datePaid;
	}
	public int getSpeedPaid() {
		return speedPaid;
	}
	public void setSpeedPaid(int speedPaid) {
		this.speedPaid = speedPaid;
	}
	public double getAverage() {
		return average;
	}
	public void setAverage(double average) {
		this.average = average;
	}
	public double getTotalAverage() {
		return totalAverage;
	}
	public void setTotalAverage(double totalAverage) {
		this.totalAverage = totalAverage;
	}
	public double getTotalInv() {
		return totalInv;
	}
	public void setTotalInv(double totalInv) {
		this.totalInv = totalInv;
	}
	
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("clientName=").append(clientName);
		str.append(";customerName=").append(customerName);
		str.append(";ao=").append(accountOfficer);
		str.append("invoiceNo=").append(invoiceNo);
		str.append("amount=").append(amount);
		str.append("amountCollected=").append(amountCollected);
		
		return str.toString();
	}
}
