package com.bdo.factor.beans;

public class ServiceOfficer {
	private String c_ServiceOfficerCode;
	private String c_Name;	
	private String c_BranchCode;
	
	public String getC_ServiceOfficerCode() {
		return c_ServiceOfficerCode;
	}
	public void setC_ServiceOfficerCode(String serviceOfficerCode) {
		c_ServiceOfficerCode = serviceOfficerCode;
	}
	public String getC_Name() {
		return c_Name;
	}
	public void setC_Name(String name) {
		c_Name = name;
	}	
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_SERVICEOFFICERCODE=").append(c_ServiceOfficerCode);
		str.append(";C_NAME=").append(c_Name);		
		str.append(";C_BRANCHCODE=").append(c_BranchCode);
		
		return str.toString();
	}
	
}
