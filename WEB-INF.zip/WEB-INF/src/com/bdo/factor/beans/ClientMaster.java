 package com.bdo.factor.beans;

import java.util.Map;

public class ClientMaster {

/////////////////////////////////////////////////////////////////////////////////
	
	private String C_BRANCHCODE;
	private String C_NAME;
	private String C_TELNO;
	private String C_ADDRESS;
	private String C_CONTACT;
	private String C_INDUSTRYCODE;
	private String C_BREGNO;
	private String C_BANKCODE;
	private String C_BNKACTNO;
	private String C_RESTRCTDACCT;
	private String C_ACCTOFFICERCODE;
	private String C_SERVICEOFFICERCODE;
	private String N_INVESTMENTLIMIT;
	private String N_SCR;
	private String D_EFFDATE;
	private String N_DCR;
	private String N_HCR;
	private String N_SETTLEMENT;
	private String N_ADVANCEDRATIO;
	private String C_TIN;
	private String C_CURRENCYCODE;
	private String N_EFFYIELD;
	private String C_BNKACTNOUSD;
	private String C_BANKCODEUSD;
	private String D_CPDATE;
	private String D_REVIEWDATE;
	private String D_CLIENTSINCE;
	private String D_AUDITEDDATE;
	private String D_INHOUSEDATE;
	private String C_RESTRCTDACCTUSD;
	private String C_BORWCODE;
	private String C_BORWTYPE;
	private String CreditRiskCd;
	private String IndCd;
	
	
/////////////////////////////////////////////////////////////////////////////////
	
	public ClientMaster(){
	}

/////////////////////////////////////////////////////////////////////////////////
	
	public ClientMaster(Map map){
		
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BRANCHCODE(map.get("C_BRANCHCODE").toString());
		
		if(map.containsKey("C_BANKCODEUSD") && map.get("C_BANKCODEUSD")!=null)
			this.setC_BANKCODEUSD(map.get("C_BANKCODEUSD").toString());
		
		if(map.containsKey("C_BANKCODE") && map.get("C_BANKCODE")!=null)
			this.setC_BANKCODE(map.get("C_BANKCODE").toString());
		
		
		
		if(map.containsKey("C_NAME") && map.get("C_NAME")!=null)
			this.setC_NAME(map.get("C_NAME").toString());
		
		if(map.containsKey("C_TELNO") && map.get("C_TELNO")!=null)
			this.setC_TELNO(map.get("C_TELNO").toString());
		
		if(map.containsKey("C_ADDRESS") && map.get("C_ADDRESS")!=null)
			this.setC_ADDRESS(map.get("C_ADDRESS").toString());
		
		if(map.containsKey("C_CONTACT") && map.get("C_CONTACT")!=null)
			this.setC_CONTACT(map.get("C_CONTACT").toString());
		
		if(map.containsKey("C_INDUSTRYCODE") && map.get("C_INDUSTRYCODE")!=null)
			this.setC_INDUSTRYCODE(map.get("C_INDUSTRYCODE").toString());
		
		if(map.containsKey("C_BREGNO") && map.get("C_BREGNO")!=null)
			this.setC_BREGNO(map.get("C_BREGNO").toString());
		
		if(map.containsKey("C_BNKACTNO") && map.get("C_BNKACTNO")!=null)
			this.setC_BNKACTNO(map.get("C_BNKACTNO").toString());
		
		if(map.containsKey("C_RESTRCTDACCT") && map.get("C_RESTRCTDACCT")!=null)
			this.setC_RESTRCTDACCT(map.get("C_RESTRCTDACCT").toString());
		
		if(map.containsKey("C_ACCTOFFICERCODE") && map.get("C_ACCTOFFICERCODE")!=null)
			this.setC_ACCTOFFICERCODE(map.get("C_ACCTOFFICERCODE").toString());
		
		if(map.containsKey("C_SERVICEOFFICERCODE") && map.get("C_SERVICEOFFICERCODE")!=null)
			this.setC_SERVICEOFFICERCODE(map.get("C_SERVICEOFFICERCODE").toString());
		
		if(map.containsKey("N_INVESTMENTLIMIT") && map.get("N_INVESTMENTLIMIT")!=null)
			this.setN_INVESTMENTLIMIT(map.get("N_INVESTMENTLIMIT").toString());
		
		if(map.containsKey("N_SCR") && map.get("N_SCR")!=null)
			this.setN_SCR(map.get("N_SCR").toString());
		
		if(map.containsKey("D_EFFDATE") && map.get("D_EFFDATE")!=null)
			this.setD_EFFDATE(map.get("D_EFFDATE").toString());
		
		if(map.containsKey("N_DCR") && map.get("N_DCR")!=null)
			this.setN_DCR(map.get("N_DCR").toString());
		
		if(map.containsKey("N_HCR") && map.get("N_HCR")!=null)
			this.setN_HCR(map.get("N_HCR").toString());
		
		if(map.containsKey("N_SETTLEMENT") && map.get("N_SETTLEMENT")!=null)
			this.setN_SETTLEMENT(map.get("N_SETTLEMENT").toString());
		
		if(map.containsKey("N_ADVANCEDRATIO") && map.get("N_ADVANCEDRATIO")!=null)
			this.setN_ADVANCEDRATIO(map.get("N_ADVANCEDRATIO").toString());
		
		if(map.containsKey("C_TIN") && map.get("C_TIN")!=null)
			this.setC_TIN(map.get("C_TIN").toString());
		
		if(map.containsKey("C_CURRENCYCODE") && map.get("C_CURRENCYCODE")!=null)
			this.setC_CURRENCYCODE(map.get("C_CURRENCYCODE").toString());
		
		if(map.containsKey("N_EFFYIELD") && map.get("N_EFFYIELD")!=null)
			this.setN_EFFYIELD(map.get("N_EFFYIELD").toString());
		
		if(map.containsKey("C_BNKACTNOUSD") && map.get("C_BNKACTNOUSD")!=null)
			this.setC_BNKACTNOUSD(map.get("C_BNKACTNOUSD").toString());
		
		if(map.containsKey("D_CPDATE") && map.get("D_CPDATE")!=null)
			this.setD_CPDATE(map.get("D_CPDATE").toString());
		
		if(map.containsKey("D_REVIEWDATE") && map.get("D_REVIEWDATE")!=null)
			this.setD_REVIEWDATE(map.get("D_REVIEWDATE").toString());
		
		if(map.containsKey("D_CLIENTSINCE") && map.get("D_CLIENTSINCE")!=null)
			this.setD_CLIENTSINCE(map.get("D_CLIENTSINCE").toString());
		
		if(map.containsKey("D_AUDITEDDATE") && map.get("D_AUDITEDDATE")!=null)
			this.setD_AUDITEDDATE(map.get("D_AUDITEDDATE").toString());
		
		if(map.containsKey("D_INHOUSEDATE") && map.get("D_INHOUSEDATE")!=null)
			this.setD_INHOUSEDATE(map.get("D_INHOUSEDATE").toString());
		
		if(map.containsKey("C_RESTRCTDACCTUSD") && map.get("C_RESTRCTDACCTUSD")!=null)
			this.setC_RESTRCTDACCTUSD(map.get("C_RESTRCTDACCTUSD").toString());
		
		if(map.containsKey("C_BORWCODE") && map.get("C_BORWCODE")!=null)
			this.setC_BORWCODE(map.get("C_BORWCODE").toString());
		
		if(map.containsKey("C_BORWTYPE") && map.get("C_BORWTYPE")!=null)
			this.setC_BORWTYPE(map.get("C_BORWTYPE").toString());
		
		if(map.containsKey("CreditRiskCd") && map.get("CreditRiskCd")!=null)
			this.setCreditRiskCd(map.get("CreditRiskCd").toString());
		
		if(map.containsKey("IndCd") && map.get("IndCd")!=null)
			this.setIndCd(map.get("IndCd").toString());
					
	}
/////////////////////////////////////////////////////////////////////////////////
	
	
	
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}
	public void setC_BRANCHCODE(String c_branchcode) {
		C_BRANCHCODE = c_branchcode;
	}
	public String getC_NAME() {
		return C_NAME;
	}
	public void setC_NAME(String c_name) {
		C_NAME = c_name;
	}
	public String getC_TELNO() {
		return C_TELNO;
	}
	public void setC_TELNO(String c_telno) {
		C_TELNO = c_telno;
	}
	public String getC_ADDRESS() {
		return C_ADDRESS;
	}
	public void setC_ADDRESS(String c_address) {
		C_ADDRESS = c_address;
	}
	public String getC_CONTACT() {
		return C_CONTACT;
	}
	public void setC_CONTACT(String c_contact) {
		C_CONTACT = c_contact;
	}
	public String getC_INDUSTRYCODE() {
		return C_INDUSTRYCODE;
	}
	public void setC_INDUSTRYCODE(String c_industrycode) {
		C_INDUSTRYCODE = c_industrycode;
	}
	public String getC_BREGNO() {
		return C_BREGNO;
	}
	public void setC_BREGNO(String c_bregno) {
		C_BREGNO = c_bregno;
	}
	public String getC_BANKCODE() {
		return C_BANKCODE;
	}
	public void setC_BANKCODE(String c_bankcode) {
		C_BANKCODE = c_bankcode;
	}
	public String getC_BNKACTNO() {
		return C_BNKACTNO;
	}
	public void setC_BNKACTNO(String c_bnkactno) {
		C_BNKACTNO = c_bnkactno;
	}
	public String getC_RESTRCTDACCT() {
		return C_RESTRCTDACCT;
	}
	public void setC_RESTRCTDACCT(String c_restrctdacct) {
		C_RESTRCTDACCT = c_restrctdacct;
	}
	public String getC_ACCTOFFICERCODE() {
		return C_ACCTOFFICERCODE;
	}
	public void setC_ACCTOFFICERCODE(String c_acctofficercode) {
		C_ACCTOFFICERCODE = c_acctofficercode;
	}
	public String getC_SERVICEOFFICERCODE() {
		return C_SERVICEOFFICERCODE;
	}
	public void setC_SERVICEOFFICERCODE(String c_serviceofficercode) {
		C_SERVICEOFFICERCODE = c_serviceofficercode;
	}
	public String getN_INVESTMENTLIMIT() {
		return N_INVESTMENTLIMIT;
	}
	public void setN_INVESTMENTLIMIT(String n_investmentlimit) {
		N_INVESTMENTLIMIT = n_investmentlimit;
	}
	public String getN_SCR() {
		return N_SCR;
	}
	public void setN_SCR(String n_scr) {
		N_SCR = n_scr;
	}
	public String getD_EFFDATE() {
		return D_EFFDATE;
	}
	public void setD_EFFDATE(String d_effdate) {
		D_EFFDATE = d_effdate;
	}
	public String getN_DCR() {
		return N_DCR;
	}
	public void setN_DCR(String n_dcr) {
		N_DCR = n_dcr;
	}
	public String getN_HCR() {
		return N_HCR;
	}
	public void setN_HCR(String n_hcr) {
		N_HCR = n_hcr;
	}
	public String getN_SETTLEMENT() {
		return N_SETTLEMENT;
	}
	public void setN_SETTLEMENT(String n_settlement) {
		N_SETTLEMENT = n_settlement;
	}
	public String getN_ADVANCEDRATIO() {
		return N_ADVANCEDRATIO;
	}
	public void setN_ADVANCEDRATIO(String n_advancedratio) {
		N_ADVANCEDRATIO = n_advancedratio;
	}
	public String getC_TIN() {
		return C_TIN;
	}
	public void setC_TIN(String c_tin) {
		C_TIN = c_tin;
	}
	public String getC_CURRENCYCODE() {
		return C_CURRENCYCODE;
	}
	public void setC_CURRENCYCODE(String c_currencycode) {
		C_CURRENCYCODE = c_currencycode;
	}
	public String getN_EFFYIELD() {
		return N_EFFYIELD;
	}
	public void setN_EFFYIELD(String n_effyield) {
		N_EFFYIELD = n_effyield;
	}
	public String getC_BNKACTNOUSD() {
		return C_BNKACTNOUSD;
	}
	public void setC_BNKACTNOUSD(String c_bnkactnousd) {
		C_BNKACTNOUSD = c_bnkactnousd;
	}
	public String getC_BANKCODEUSD() {
		return C_BANKCODEUSD;
	}
	public void setC_BANKCODEUSD(String c_bankcodeusd) {
		C_BANKCODEUSD = c_bankcodeusd;
	}
	public String getD_CPDATE() {
		return D_CPDATE;
	}
	public void setD_CPDATE(String d_cpdate) {
		D_CPDATE = d_cpdate;
	}
	public String getD_REVIEWDATE() {
		return D_REVIEWDATE;
	}
	public void setD_REVIEWDATE(String d_reviewdate) {
		D_REVIEWDATE = d_reviewdate;
	}
	public String getD_CLIENTSINCE() {
		return D_CLIENTSINCE;
	}
	public void setD_CLIENTSINCE(String d_clientsince) {
		D_CLIENTSINCE = d_clientsince;
	}
	public String getD_AUDITEDDATE() {
		return D_AUDITEDDATE;
	}
	public void setD_AUDITEDDATE(String d_auditeddate) {
		D_AUDITEDDATE = d_auditeddate;
	}
	public String getD_INHOUSEDATE() {
		return D_INHOUSEDATE;
	}
	public void setD_INHOUSEDATE(String d_inhousedate) {
		D_INHOUSEDATE = d_inhousedate;
	}
	public String getC_RESTRCTDACCTUSD() {
		return C_RESTRCTDACCTUSD;
	}
	public void setC_RESTRCTDACCTUSD(String c_restrctdacctusd) {
		C_RESTRCTDACCTUSD = c_restrctdacctusd;
	}
	public String getC_BORWCODE() {
		return C_BORWCODE;
	}
	public void setC_BORWCODE(String c_borwcode) {
		C_BORWCODE = c_borwcode;
	}
	public String getC_BORWTYPE() {
		return C_BORWTYPE;
	}
	public void setC_BORWTYPE(String c_borwtype) {
		C_BORWTYPE = c_borwtype;
	}
	public String getCreditRiskCd() {
		return CreditRiskCd;
	}
	public void setCreditRiskCd(String creditRiskCd) {
		CreditRiskCd = creditRiskCd;
	}
	public String getIndCd() {
		return IndCd;
	}
	public void setIndCd(String indCd) {
		IndCd = indCd;
	}
	
	
/////////////////////////////////////////////////////////////////////////////////	
	

	public String toString() {
		
		StringBuilder strClientMaster = new StringBuilder();
		
		strClientMaster.append("C_BRANCHCODE=").append(C_BRANCHCODE);
		strClientMaster.append(";C_NAME=").append(C_NAME);
		strClientMaster.append(";C_TELNO=").append(C_TELNO);
		strClientMaster.append(";C_ADDRESS=").append(C_ADDRESS);
		strClientMaster.append(";C_CONTACT=").append(C_CONTACT);
		//strClientMaster.append(";C_INDUSTRYCODE=").append(C_INDUSTRYCODE);
		strClientMaster.append(";C_BREGNO=").append(C_BREGNO);
		strClientMaster.append(";C_BANKCODE=").append(C_BANKCODE);
		strClientMaster.append(";C_BNKACTNO=").append(C_BNKACTNO);
		strClientMaster.append(";C_RESTRCTDACCT=").append(C_RESTRCTDACCT);
		strClientMaster.append(";C_ACCTOFFICERCODE=").append(C_ACCTOFFICERCODE);
		strClientMaster.append(";C_SERVICEOFFICERCODE=").append(C_SERVICEOFFICERCODE);
		strClientMaster.append(";N_INVESTMENTLIMIT=").append(N_INVESTMENTLIMIT);
		strClientMaster.append(";N_SCR=").append(N_SCR);
		strClientMaster.append(";D_EFFDATE=").append(D_EFFDATE);
		strClientMaster.append(";N_DCR=").append(N_DCR);
		strClientMaster.append(";N_HCR=").append(N_HCR);
		strClientMaster.append(";N_SETTLEMENT=").append(N_SETTLEMENT);
		strClientMaster.append(";N_ADVANCEDRATIO=").append(N_ADVANCEDRATIO);
		strClientMaster.append(";C_TIN=").append(C_TIN);
		strClientMaster.append(";C_CURRENCYCODE=").append(C_CURRENCYCODE);
		strClientMaster.append(";N_EFFYIELD=").append(N_EFFYIELD);
		strClientMaster.append(";C_BNKACTNOUSD=").append(C_BNKACTNOUSD);
		strClientMaster.append(";C_BANKCODEUSD=").append(C_BANKCODEUSD);
		strClientMaster.append(";D_CPDATE=").append(D_CPDATE);
		strClientMaster.append(";D_REVIEWDATE=").append(D_REVIEWDATE);
		strClientMaster.append(";D_CLIENTSINCE=").append(D_CLIENTSINCE);
		strClientMaster.append(";D_AUDITEDDATE=").append(D_AUDITEDDATE);
		strClientMaster.append(";D_INHOUSEDATE=").append(D_INHOUSEDATE);
		strClientMaster.append(";C_RESTRCTDACCTUSD=").append(C_RESTRCTDACCTUSD);
		strClientMaster.append(";C_BORWCODE=").append(C_BORWCODE);
		strClientMaster.append(";C_BORWTYPE=").append(C_BORWTYPE);
		strClientMaster.append(";CreditRiskCd=").append(CreditRiskCd);
		strClientMaster.append(";IndCd=").append(IndCd);
		
		return strClientMaster.toString();
	}
	

/////////////////////////////////////////////////////////////////////////////////
public String toStringClient() {
		
		StringBuilder strClientMaster = new StringBuilder();
		
		strClientMaster.append("C_BRANCHCODE=").append(C_BRANCHCODE);
		strClientMaster.append(";C_NAME=").append(C_NAME);
		strClientMaster.append(";C_TELNO=").append(C_TELNO);
		strClientMaster.append(";C_ADDRESS=").append(C_ADDRESS);
		strClientMaster.append(";C_CONTACT=").append(C_CONTACT);
		strClientMaster.append(";C_BREGNO=").append(C_BREGNO);
		strClientMaster.append(";C_BANKCODE=").append(C_BANKCODE);
		strClientMaster.append(";C_BNKACTNO=").append(C_BNKACTNO);
		strClientMaster.append(";C_RESTRCTDACCT=").append(C_RESTRCTDACCT);
		strClientMaster.append(";C_ACCTOFFICERCODE=").append(C_ACCTOFFICERCODE);
		strClientMaster.append(";C_SERVICEOFFICERCODE=").append(C_SERVICEOFFICERCODE);
		strClientMaster.append(";D_EFFDATE=").append(D_EFFDATE);
		strClientMaster.append(";C_TIN=").append(C_TIN);
		strClientMaster.append(";C_CURRENCYCODE=").append(C_CURRENCYCODE);
		strClientMaster.append(";C_BNKACTNOUSD=").append(C_BNKACTNOUSD);
		strClientMaster.append(";C_BANKCODEUSD=").append(C_BANKCODEUSD);
		strClientMaster.append(";D_CPDATE=").append(D_CPDATE);
		strClientMaster.append(";D_REVIEWDATE=").append(D_REVIEWDATE);
		strClientMaster.append(";D_CLIENTSINCE=").append(D_CLIENTSINCE);
		strClientMaster.append(";D_AUDITEDDATE=").append(D_AUDITEDDATE);
		strClientMaster.append(";D_INHOUSEDATE=").append(D_INHOUSEDATE);
		strClientMaster.append(";C_RESTRCTDACCTUSD=").append(C_RESTRCTDACCTUSD);
		strClientMaster.append(";C_BORWCODE=").append(C_BORWCODE);
		strClientMaster.append(";C_BORWTYPE=").append(C_BORWTYPE);
		strClientMaster.append(";CreditRiskCd=").append(CreditRiskCd);
		strClientMaster.append(";IndCd=").append(IndCd);
		
		return strClientMaster.toString();
	}
	
}
