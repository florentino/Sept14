package com.bdo.factor.beans;

import java.util.HashMap;
import java.util.Map;

public class Bank {
	
	private String c_BANKCODE;
	private String c_BANKNAME;
	private String c_ADDRESS;
	private String c_TELNO;
	private String c_FAXNO;
			
	public String getC_BANKCODE() {
		return this.c_BANKCODE;
	}

	public void setC_BANKCODE(String c_bankcode) {
		c_BANKCODE = c_bankcode;
	}

	public String getC_BANKNAME() {
		return c_BANKNAME;
	}

	public void setC_BANKNAME(String c_bankname) {
		c_BANKNAME = c_bankname;
	}

	public String getC_ADDRESS() {
		return c_ADDRESS;
	}

	public void setC_ADDRESS(String c_address) {
		c_ADDRESS = c_address;
	}

	public String getC_TELNO() {
		return c_TELNO;
	}

	public void setC_TELNO(String c_telno) {
		c_TELNO = c_telno;
	}

	public String getC_FAXNO() {
		return c_FAXNO;
	}

	public void setC_FAXNO(String c_faxno) {
		c_FAXNO = c_faxno;
	}
	
	public String toString() {
		StringBuilder strBank = new StringBuilder();
		strBank.append("C_BANKCODE=").append(c_BANKCODE);
		strBank.append(";C_BANKNAME=").append(c_BANKNAME);
		strBank.append(";C_ADDRESS=").append(c_ADDRESS);
		strBank.append(";C_TELNO=").append(c_TELNO);
		strBank.append(";C_FAXNO=").append(c_FAXNO);
		
		return strBank.toString();
	}
	
	
}
