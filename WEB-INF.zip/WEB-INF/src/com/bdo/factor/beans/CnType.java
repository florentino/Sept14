package com.bdo.factor.beans;

public class CnType {
	private String c_CnTypeCode;
	private String c_Description;
	
	public String getC_CnTypeCode() {
		return c_CnTypeCode;
	}
	public void setC_CnTypeCode(String cnTypeCode) {
		c_CnTypeCode = cnTypeCode;
	}
	public String getC_Description() {
		return c_Description;
	}
	public void setC_Description(String description) {
		c_Description = description;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_CNTYPECODE=").append(c_CnTypeCode);	
		str.append(";C_DESCRIPTION=").append(c_Description);
		
		return str.toString();
	}
}
