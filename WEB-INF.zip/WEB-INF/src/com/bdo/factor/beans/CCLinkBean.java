package com.bdo.factor.beans;

import java.util.Date;

public class CCLinkBean {
	private String C_BRANCHCODE;
	private long C_CLNTCODE;
	private long C_CUSTCODE;
	private double N_CLLIMIT;
	private Date D_EXDATE;
	private int N_DUNNING;
	private byte C_STATUS;
	private int N_TERM;
	private String N_CURRENCYCODE;
	private double N_OVER30DAY;
	private double N_OVER60DAY;
	private double N_OVER90DAY;
	private double N_OVER120DAY;
	private double N_OVER150DAY;
	private double N_OVER180DAY;
	private double N_OVER210DAY;
	private byte B_NLACT;
	private double N_RUNNINGBAL;
	private double N_CCLIMIT;
	private Date D_CCAPDATE;
	private Date D_CCEXDATE;
	private double N_CCLIMIT1;
	private Date D_CCAPDATE1;
	private Date D_CCEXDATE1;
	private String C_CONTACT;
	private String C_TELNO;
	private String C_FAXNO;
	private String C_VERIFYEMAIL1;
	private String C_VERIFYEMAIL2;
	private String C_COLLECTCONTACT;
	private String C_COLLECTTELNO;
	private String C_COLLECTFAXLNO;
	private String C_COLLECTEMAIL1;
	private String C_COLLECTEMAIL2;
	private Date D_CREATEDATE;
	private Date D_LASTUPDATEDATE;
	private double N_INELIGIBLEREC;
	private String C_COLLECTADDRESS;
	private String C_COLLECTTIME;
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}
	public void setC_BRANCHCODE(String c_BRANCHCODE) {
		C_BRANCHCODE = c_BRANCHCODE;
	}
	public long getC_CLNTCODE() {
		return C_CLNTCODE;
	}
	public void setC_CLNTCODE(long c_CLNTCODE) {
		C_CLNTCODE = c_CLNTCODE;
	}
	public long getC_CUSTCODE() {
		return C_CUSTCODE;
	}
	public void setC_CUSTCODE(long c_CUSTCODE) {
		C_CUSTCODE = c_CUSTCODE;
	}
	public double getN_CLLIMIT() {
		return N_CLLIMIT;
	}
	public void setN_CLLIMIT(double n_CLLIMIT) {
		N_CLLIMIT = n_CLLIMIT;
	}
	public Date getD_EXDATE() {
		return D_EXDATE;
	}
	public void setD_EXDATE(Date d_EXDATE) {
		D_EXDATE = d_EXDATE;
	}
	public int getN_DUNNING() {
		return N_DUNNING;
	}
	public void setN_DUNNING(int n_DUNNING) {
		N_DUNNING = n_DUNNING;
	}
	public byte getC_STATUS() {
		return C_STATUS;
	}
	public void setC_STATUS(byte c_STATUS) {
		C_STATUS = c_STATUS;
	}
	public int getN_TERM() {
		return N_TERM;
	}
	public void setN_TERM(int n_TERM) {
		N_TERM = n_TERM;
	}
	public String getN_CURRENCYCODE() {
		return N_CURRENCYCODE;
	}
	public void setN_CURRENCYCODE(String n_CURRENCYCODE) {
		N_CURRENCYCODE = n_CURRENCYCODE;
	}
	public double getN_OVER30DAY() {
		return N_OVER30DAY;
	}
	public void setN_OVER30DAY(double n_OVER30DAY) {
		N_OVER30DAY = n_OVER30DAY;
	}
	public double getN_OVER60DAY() {
		return N_OVER60DAY;
	}
	public void setN_OVER60DAY(double n_OVER60DAY) {
		N_OVER60DAY = n_OVER60DAY;
	}
	public double getN_OVER90DAY() {
		return N_OVER90DAY;
	}
	public void setN_OVER90DAY(double n_OVER90DAY) {
		N_OVER90DAY = n_OVER90DAY;
	}
	public double getN_OVER120DAY() {
		return N_OVER120DAY;
	}
	public void setN_OVER120DAY(double n_OVER120DAY) {
		N_OVER120DAY = n_OVER120DAY;
	}
	public double getN_OVER150DAY() {
		return N_OVER150DAY;
	}
	public void setN_OVER150DAY(double n_OVER150DAY) {
		N_OVER150DAY = n_OVER150DAY;
	}
	public double getN_OVER180DAY() {
		return N_OVER180DAY;
	}
	public void setN_OVER180DAY(double n_OVER180DAY) {
		N_OVER180DAY = n_OVER180DAY;
	}
	public double getN_OVER210DAY() {
		return N_OVER210DAY;
	}
	public void setN_OVER210DAY(double n_OVER210DAY) {
		N_OVER210DAY = n_OVER210DAY;
	}
	public byte getB_NLACT() {
		return B_NLACT;
	}
	public void setB_NLACT(byte b_NLACT) {
		B_NLACT = b_NLACT;
	}
	public double getN_RUNNINGBAL() {
		return N_RUNNINGBAL;
	}
	public void setN_RUNNINGBAL(double n_RUNNINGBAL) {
		N_RUNNINGBAL = n_RUNNINGBAL;
	}
	public double getN_CCLIMIT() {
		return N_CCLIMIT;
	}
	public void setN_CCLIMIT(double n_CCLIMIT) {
		N_CCLIMIT = n_CCLIMIT;
	}
	public Date getD_CCAPDATE() {
		return D_CCAPDATE;
	}
	public void setD_CCAPDATE(Date d_CCAPDATE) {
		D_CCAPDATE = d_CCAPDATE;
	}
	public Date getD_CCEXDATE() {
		return D_CCEXDATE;
	}
	public void setD_CCEXDATE(Date d_CCEXDATE) {
		D_CCEXDATE = d_CCEXDATE;
	}
	public double getN_CCLIMIT1() {
		return N_CCLIMIT1;
	}
	public void setN_CCLIMIT1(double n_CCLIMIT1) {
		N_CCLIMIT1 = n_CCLIMIT1;
	}
	public Date getD_CCAPDATE1() {
		return D_CCAPDATE1;
	}
	public void setD_CCAPDATE1(Date d_CCAPDATE1) {
		D_CCAPDATE1 = d_CCAPDATE1;
	}
	public Date getD_CCEXDATE1() {
		return D_CCEXDATE1;
	}
	public void setD_CCEXDATE1(Date d_CCEXDATE1) {
		D_CCEXDATE1 = d_CCEXDATE1;
	}
	public String getC_CONTACT() {
		return C_CONTACT;
	}
	public void setC_CONTACT(String c_CONTACT) {
		C_CONTACT = c_CONTACT;
	}
	public String getC_TELNO() {
		return C_TELNO;
	}
	public void setC_TELNO(String c_TELNO) {
		C_TELNO = c_TELNO;
	}
	public String getC_FAXNO() {
		return C_FAXNO;
	}
	public void setC_FAXNO(String c_FAXNO) {
		C_FAXNO = c_FAXNO;
	}
	public String getC_VERIFYEMAIL1() {
		return C_VERIFYEMAIL1;
	}
	public void setC_VERIFYEMAIL1(String c_VERIFYEMAIL1) {
		C_VERIFYEMAIL1 = c_VERIFYEMAIL1;
	}
	public String getC_VERIFYEMAIL2() {
		return C_VERIFYEMAIL2;
	}
	public void setC_VERIFYEMAIL2(String c_VERIFYEMAIL2) {
		C_VERIFYEMAIL2 = c_VERIFYEMAIL2;
	}
	public String getC_COLLECTCONTACT() {
		return C_COLLECTCONTACT;
	}
	public void setC_COLLECTCONTACT(String c_COLLECTCONTACT) {
		C_COLLECTCONTACT = c_COLLECTCONTACT;
	}
	public String getC_COLLECTTELNO() {
		return C_COLLECTTELNO;
	}
	public void setC_COLLECTTELNO(String c_COLLECTTELNO) {
		C_COLLECTTELNO = c_COLLECTTELNO;
	}
	public String getC_COLLECTFAXLNO() {
		return C_COLLECTFAXLNO;
	}
	public void setC_COLLECTFAXLNO(String c_COLLECTFAXLNO) {
		C_COLLECTFAXLNO = c_COLLECTFAXLNO;
	}
	public String getC_COLLECTEMAIL1() {
		return C_COLLECTEMAIL1;
	}
	public void setC_COLLECTEMAIL1(String c_COLLECTEMAIL1) {
		C_COLLECTEMAIL1 = c_COLLECTEMAIL1;
	}
	public String getC_COLLECTEMAIL2() {
		return C_COLLECTEMAIL2;
	}
	public void setC_COLLECTEMAIL2(String c_COLLECTEMAIL2) {
		C_COLLECTEMAIL2 = c_COLLECTEMAIL2;
	}
	public Date getD_CREATEDATE() {
		return D_CREATEDATE;
	}
	public void setD_CREATEDATE(Date d_CREATEDATE) {
		D_CREATEDATE = d_CREATEDATE;
	}
	public Date getD_LASTUPDATEDATE() {
		return D_LASTUPDATEDATE;
	}
	public void setD_LASTUPDATEDATE(Date d_LASTUPDATEDATE) {
		D_LASTUPDATEDATE = d_LASTUPDATEDATE;
	}
	public double getN_INELIGIBLEREC() {
		return N_INELIGIBLEREC;
	}
	public void setN_INELIGIBLEREC(double n_INELIGIBLEREC) {
		N_INELIGIBLEREC = n_INELIGIBLEREC;
	}
	public String getC_COLLECTADDRESS() {
		return C_COLLECTADDRESS;
	}
	public void setC_COLLECTADDRESS(String c_COLLECTADDRESS) {
		C_COLLECTADDRESS = c_COLLECTADDRESS;
	}
	public String getC_COLLECTTIME() {
		return C_COLLECTTIME;
	}
	public void setC_COLLECTTIME(String c_COLLECTTIME) {
		C_COLLECTTIME = c_COLLECTTIME;
	}

}
