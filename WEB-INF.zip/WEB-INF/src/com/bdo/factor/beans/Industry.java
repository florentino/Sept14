package com.bdo.factor.beans;

public class Industry {
	private String c_IndCode;
	private String c_IndName;
	private String c_Desc;
	
	public String getC_IndCode() {
		return c_IndCode;
	}
	public void setC_IndCode(String indCode) {
		c_IndCode = indCode;
	}
	public String getC_IndName() {
		return c_IndName;
	}
	public void setC_IndName(String indName) {
		c_IndName = indName;
	}
	
	public String getC_Desc() {
		return c_Desc;
	}
	public void setC_Desc(String c_Desc) {
		this.c_Desc = c_Desc;
	}
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_INDCODE=").append(c_IndCode);
		str.append(";C_INDNAME=").append(c_IndName);
		str.append (";C_Desc=").append(c_Desc);
		return str.toString();
	}
}
