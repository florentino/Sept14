package com.bdo.factor.beans;

public class WeeklyBookingSummary {
	private String weekOne;
	private String weekTwo;
	private String weekThree;
	private String weekFour;
	private String weekFive;
	private double invoiceAmt1stWeek;
	private double invoiceAmt2ndWeek;
	private double invoiceAmt3rdWeek;
	private double invoiceAmt4thWeek;
	private double invoiceAmt5thWeek;
	private double invoiceAmtMTD;
	private double invoiceAmtYTD;	
	private double totCollectionWk1;
	private double totCollectionWk2;
	private double totCollectionWk3;
	private double totCollectionWk4;
	private double totCollectionWk5;
	private double totCollectionMTD;
	private double totCollectionYTD;
	private double receivablesWk1;
	private double receivablesWk2;
	private double receivablesWk3;
	private double receivablesWk4;
	private double receivablesWk5;
	private double receivablesMTD;
	private double receivablesYTD;
	private double prepaymentWk1;
	private double prepaymentWk2;
	private double prepaymentWk3;
	private double prepaymentWk4;
	private double prepaymentWk5;
	private double prepaymentMTD;
	private double prepaymentYTD;
	private double dcWk1;
	private double dcWk2;
	private double dcWk3;
	private double dcWk4;
	private double dcWk5;
	private double dcMTD;
	private double dcYTD;
	private double dunningWk1;
	private double dunningWk2;
	private double dunningWk3;
	private double dunningWk4;
	private double dunningWk5;
	private double dunningMTD;
	private double dunningYTD;
	private double prepaymentPercentWk1;
	private double prepaymentPercentWk2;
	private double prepaymentPercentWk3;
	private double prepaymentPercentWk4;
	private double prepaymentPercentWk5;
	private double prepaymentPercentMTD;
	private double prepaymentPercentYTD;
	
	public double getPrepaymentPercentWk1() {
		return prepaymentPercentWk1;
	}
	public void setPrepaymentPercentWk1(double prepaymentPercentWk1) {
		this.prepaymentPercentWk1 = prepaymentPercentWk1;
	}
	public double getPrepaymentPercentWk2() {
		return prepaymentPercentWk2;
	}
	public void setPrepaymentPercentWk2(double prepaymentPercentWk2) {
		this.prepaymentPercentWk2 = prepaymentPercentWk2;
	}
	public double getPrepaymentPercentWk3() {
		return prepaymentPercentWk3;
	}
	public void setPrepaymentPercentWk3(double prepaymentPercentWk3) {
		this.prepaymentPercentWk3 = prepaymentPercentWk3;
	}
	public double getPrepaymentPercentWk4() {
		return prepaymentPercentWk4;
	}
	public void setPrepaymentPercentWk4(double prepaymentPercentWk4) {
		this.prepaymentPercentWk4 = prepaymentPercentWk4;
	}
	public double getPrepaymentPercentWk5() {
		return prepaymentPercentWk5;
	}
	public void setPrepaymentPercentWk5(double prepaymentPercentWk5) {
		this.prepaymentPercentWk5 = prepaymentPercentWk5;
	}
	public double getPrepaymentPercentMTD() {
		return prepaymentPercentMTD;
	}
	public void setPrepaymentPercentMTD(double prepaymentPercentMTD) {
		this.prepaymentPercentMTD = prepaymentPercentMTD;
	}
	public double getPrepaymentPercentYTD() {
		return prepaymentPercentYTD;
	}
	public void setPrepaymentPercentYTD(double prepaymentPercentYTD) {
		this.prepaymentPercentYTD = prepaymentPercentYTD;
	}
	public String getWeekOne() {
		return weekOne;
	}
	public void setWeekOne(String weekOne) {
		this.weekOne = weekOne;
	}
	public String getWeekTwo() {
		return weekTwo;
	}
	public void setWeekTwo(String weekTwo) {
		this.weekTwo = weekTwo;
	}
	public String getWeekThree() {
		return weekThree;
	}
	public void setWeekThree(String weekThree) {
		this.weekThree = weekThree;
	}
	public String getWeekFour() {
		return weekFour;
	}
	public void setWeekFour(String weekFour) {
		this.weekFour = weekFour;
	}
	public String getWeekFive() {
		return weekFive;
	}
	public void setWeekFive(String weekFive) {
		this.weekFive = weekFive;
	}
	public double getInvoiceAmt1stWeek() {
		return invoiceAmt1stWeek;
	}
	public void setInvoiceAmt1stWeek(double invoiceAmt1stWeek) {
		this.invoiceAmt1stWeek = invoiceAmt1stWeek;
	}
	public double getInvoiceAmt2ndWeek() {
		return invoiceAmt2ndWeek;
	}
	public void setInvoiceAmt2ndWeek(double invoiceAmt2ndWeek) {
		this.invoiceAmt2ndWeek = invoiceAmt2ndWeek;
	}
	public double getInvoiceAmt3rdWeek() {
		return invoiceAmt3rdWeek;
	}
	public void setInvoiceAmt3rdWeek(double invoiceAmt3rdWeek) {
		this.invoiceAmt3rdWeek = invoiceAmt3rdWeek;
	}
	public double getInvoiceAmt4thWeek() {
		return invoiceAmt4thWeek;
	}
	public void setInvoiceAmt4thWeek(double invoiceAmt4thWeek) {
		this.invoiceAmt4thWeek = invoiceAmt4thWeek;
	}
	public double getInvoiceAmt5thWeek() {
		return invoiceAmt5thWeek;
	}
	public void setInvoiceAmt5thWeek(double invoiceAmt5thWeek) {
		this.invoiceAmt5thWeek = invoiceAmt5thWeek;
	}
	public double getTotCollectionWk1() {
		return totCollectionWk1;
	}
	public void setTotCollectionWk1(double totCollectionWk1) {
		this.totCollectionWk1 = totCollectionWk1;
	}
	public double getTotCollectionWk2() {
		return totCollectionWk2;
	}
	public void setTotCollectionWk2(double totCollectionWk2) {
		this.totCollectionWk2 = totCollectionWk2;
	}
	public double getTotCollectionWk3() {
		return totCollectionWk3;
	}
	public void setTotCollectionWk3(double totCollectionWk3) {
		this.totCollectionWk3 = totCollectionWk3;
	}
	public double getTotCollectionWk4() {
		return totCollectionWk4;
	}
	public void setTotCollectionWk4(double totCollectionWk4) {
		this.totCollectionWk4 = totCollectionWk4;
	}
	public double getTotCollectionWk5() {
		return totCollectionWk5;
	}
	public void setTotCollectionWk5(double totCollectionWk5) {
		this.totCollectionWk5 = totCollectionWk5;
	}
	public double getTotCollectionYTD() {
		return totCollectionYTD;
	}
	public void setTotCollectionYTD(double totCollectionYTD) {
		this.totCollectionYTD = totCollectionYTD;
	}
	public double getReceivablesWk1() {
		return receivablesWk1;
	}
	public void setReceivablesWk1(double receivablesWk1) {
		this.receivablesWk1 = receivablesWk1;
	}
	public double getInvoiceAmtMTD() {
		return invoiceAmtMTD;
	}
	public void setInvoiceAmtMTD(double invoiceAmtMTD) {
		this.invoiceAmtMTD = invoiceAmtMTD;
	}
	public double getInvoiceAmtYTD() {
		return invoiceAmtYTD;
	}
	public void setInvoiceAmtYTD(double invoiceAmtYTD) {
		this.invoiceAmtYTD = invoiceAmtYTD;
	}
	public double getTotCollectionMTD() {
		return totCollectionMTD;
	}
	public void setTotCollectionMTD(double totCollectionMTD) {
		this.totCollectionMTD = totCollectionMTD;
	}
	public double getReceivablesMTD() {
		return receivablesMTD;
	}
	public void setReceivablesMTD(double receivablesMTD) {
		this.receivablesMTD = receivablesMTD;
	}
	public double getPrepaymentMTD() {
		return prepaymentMTD;
	}
	public void setPrepaymentMTD(double prepaymentMTD) {
		this.prepaymentMTD = prepaymentMTD;
	}
	public double getPrepaymentYTD() {
		return prepaymentYTD;
	}
	public void setPrepaymentYTD(double prepaymentYTD) {
		this.prepaymentYTD = prepaymentYTD;
	}
	public double getDcMTD() {
		return dcMTD;
	}
	public void setDcMTD(double dcMTD) {
		this.dcMTD = dcMTD;
	}
	public double getDcYTD() {
		return dcYTD;
	}
	public void setDcYTD(double dcYTD) {
		this.dcYTD = dcYTD;
	}
	public double getDunningMTD() {
		return dunningMTD;
	}
	public void setDunningMTD(double dunningMTD) {
		this.dunningMTD = dunningMTD;
	}
	public double getDunningYTD() {
		return dunningYTD;
	}
	public void setDunningYTD(double dunningYTD) {
		this.dunningYTD = dunningYTD;
	}
	public double getReceivablesWk2() {
		return receivablesWk2;
	}
	public void setReceivablesWk2(double receivablesWk2) {
		this.receivablesWk2 = receivablesWk2;
	}
	public double getReceivablesWk3() {
		return receivablesWk3;
	}
	public void setReceivablesWk3(double receivablesWk3) {
		this.receivablesWk3 = receivablesWk3;
	}
	public double getReceivablesWk4() {
		return receivablesWk4;
	}
	public void setReceivablesWk4(double receivablesWk4) {
		this.receivablesWk4 = receivablesWk4;
	}
	public double getReceivablesWk5() {
		return receivablesWk5;
	}
	public void setReceivablesWk5(double receivablesWk5) {
		this.receivablesWk5 = receivablesWk5;
	}
	public double getReceivablesYTD() {
		return receivablesYTD;
	}
	public void setReceivablesYTD(double receivablesYTD) {
		this.receivablesYTD = receivablesYTD;
	}
	public double getPrepaymentWk1() {
		return prepaymentWk1;
	}
	public void setPrepaymentWk1(double prepaymentWk1) {
		this.prepaymentWk1 = prepaymentWk1;
	}
	public double getPrepaymentWk2() {
		return prepaymentWk2;
	}
	public void setPrepaymentWk2(double prepaymentWk2) {
		this.prepaymentWk2 = prepaymentWk2;
	}
	public double getPrepaymentWk3() {
		return prepaymentWk3;
	}
	public void setPrepaymentWk3(double prepaymentWk3) {
		this.prepaymentWk3 = prepaymentWk3;
	}
	public double getPrepaymentWk4() {
		return prepaymentWk4;
	}
	public void setPrepaymentWk4(double prepaymentWk4) {
		this.prepaymentWk4 = prepaymentWk4;
	}
	public double getPrepaymentWk5() {
		return prepaymentWk5;
	}
	public void setPrepaymentWk5(double prepaymentWk5) {
		this.prepaymentWk5 = prepaymentWk5;
	}
	public double getDcWk1() {
		return dcWk1;
	}
	public void setDcWk1(double dcWk1) {
		this.dcWk1 = dcWk1;
	}
	public double getDcWk2() {
		return dcWk2;
	}
	public void setDcWk2(double dcWk2) {
		this.dcWk2 = dcWk2;
	}
	public double getDcWk3() {
		return dcWk3;
	}
	public void setDcWk3(double dcWk3) {
		this.dcWk3 = dcWk3;
	}
	public double getDcWk4() {
		return dcWk4;
	}
	public void setDcWk4(double dcWk4) {
		this.dcWk4 = dcWk4;
	}
	public double getDcWk5() {
		return dcWk5;
	}
	public void setDcWk5(double dcWk5) {
		this.dcWk5 = dcWk5;
	}
	public double getDunningWk1() {
		return dunningWk1;
	}
	public void setDunningWk1(double dunningWk1) {
		this.dunningWk1 = dunningWk1;
	}
	public double getDunningWk2() {
		return dunningWk2;
	}
	public void setDunningWk2(double dunningWk2) {
		this.dunningWk2 = dunningWk2;
	}
	public double getDunningWk3() {
		return dunningWk3;
	}
	public void setDunningWk3(double dunningWk3) {
		this.dunningWk3 = dunningWk3;
	}
	public double getDunningWk4() {
		return dunningWk4;
	}
	public void setDunningWk4(double dunningWk4) {
		this.dunningWk4 = dunningWk4;
	}
	public double getDunningWk5() {
		return dunningWk5;
	}
	public void setDunningWk5(double dunningWk5) {
		this.dunningWk5 = dunningWk5;
	}
	
	
}
