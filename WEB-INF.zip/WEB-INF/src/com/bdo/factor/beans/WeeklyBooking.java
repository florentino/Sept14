package com.bdo.factor.beans;

public class WeeklyBooking 
{
	private String weekOne;
	private String weekTwo;
	private String weekThree;
	private String weekFour;
	private String weekFive;
	private String accountOfficer;
	private String clientName;
	private double invoiceAmt1stWeek;
	private double invoiceAmt2ndWeek;
	private double invoiceAmt3rdWeek;
	private double invoiceAmt4thWeek;
	private double invoiceAmt5thWeek;
	private double advanceRatio;	
	private double ytd;
	private double dunOne;
	private double dunTwo;
	private double dunThree;
	private double dunFour;
	private double dunFive;
	private double percentOne;
	private double percentTwo;
	private double percentThree;
	private double percentFour;
	private double percentFive;
	private double dunMontly;
	private double dunYearly;
	private long clientCode;
	private double monthlyDC;
	private double yearlyDC;
	private double sfWkOne;
	private double sfWkTwo;
	private double sfWkThree;
	private double sfWkFour;
	private double sfWkFive;
	private double sfMtd;
	private double sfYtd;
	private double sfPercent;
	private double totCollectionWk1;
	private double totCollectionWk2;
	private double totCollectionWk3;
	private double totCollectionWk4;
	private double totCollectionWk5;
	private double totCollectionWkYTD;
	
	private double scOne;
	private double scTwo;
	private double scThree;
	private double scFour;
	private double scFive;

	private double monthlySC;
	private double yearlySC;

	private String scStatus;
	private String blrStatus;
	private String advanceRatioStatus;

	private int invCountOne;
	private int invCountTwo;
	private int invCountThree;
	private int invCountFour;
	private int invCountFive;
	private int invCountYTD;
	
	private String clientStatus;

	private String branchCode;

	public double getSfPercent() {
		return sfPercent;
	}
	public void setSfPercent(double sfPercent) {
		this.sfPercent = sfPercent;
	}
	public double getSfMtd() {
		return sfMtd;
	}
	public void setSfMtd(double sfMtd) {
		this.sfMtd = sfMtd;
	}
	public double getSfYtd() {
		return sfYtd;
	}
	public void setSfYtd(double sfYtd) {
		this.sfYtd = sfYtd;
	}
	public double getSfWkFive() {
		return sfWkFive;
	}
	public void setSfWkFive(double sfWkFive) {
		this.sfWkFive = sfWkFive;
	}
	public double getSfWkFour() {
		return sfWkFour;
	}
	public void setSfWkFour(double sfWkFour) {
		this.sfWkFour = sfWkFour;
	}
	public double getSfWkThree() {
		return sfWkThree;
	}
	public void setSfWkThree(double sfWkThree) {
		this.sfWkThree = sfWkThree;
	}
	public double getSfWkTwo() {
		return sfWkTwo;
	}
	public void setSfWkTwo(double sfWkTwo) {
		this.sfWkTwo = sfWkTwo;
	}
	public double getSfWkOne() {
		return sfWkOne;
	}
	public void setSfWkOne(double sfWkOne) {
		this.sfWkOne = sfWkOne;
	}
	public double getYearlyDC() {
		return yearlyDC;
	}
	public void setYearlyDC(double yearlyDC) {
		this.yearlyDC = yearlyDC;
	}
	public double getMonthlyDC() {
		return monthlyDC;
	}
	public void setMonthlyDC(double monthlyDC) {
		this.monthlyDC = monthlyDC;
	}
	public long getClientCode() {
		return clientCode;
	}
	public void setClientCode(long clientCode) {
		this.clientCode = clientCode;
	}
	public double getDunYearly() {
		return dunYearly;
	}
	public void setDunYearly(double dunYearly) {
		this.dunYearly = dunYearly;
	}
	public double getDunMontly() {
		return dunMontly;
	}
	public void setDunMontly(double dunMontly) {
		this.dunMontly = dunMontly;
	}
	public double getPercentFive() {
		return percentFive;
	}
	public void setPercentFive(double percentFive) {
		this.percentFive = percentFive;
	}
	public double getPercentFour() {
		return percentFour;
	}
	public void setPercentFour(double percentFour) {
		this.percentFour = percentFour;
	}
	public double getPercentThree() {
		return percentThree;
	}
	public void setPercentThree(double percentThree) {
		this.percentThree = percentThree;
	}
	public double getPercentTwo() {
		return percentTwo;
	}
	public void setPercentTwo(double percentTwo) {
		this.percentTwo = percentTwo;
	}
	public double getPercentOne() {
		return percentOne;
	}
	public void setPercentOne(double percentOne) {
		this.percentOne = percentOne;
	}	
	public double getDunOne() {
		return dunOne;
	}
	public void setDunOne(double dunOne) {
		this.dunOne = dunOne;
	}
	public double getDunTwo() {
		return dunTwo;
	}
	public void setDunTwo(double dunTwo) {
		this.dunTwo = dunTwo;
	}
	public double getDunThree() {
		return dunThree;
	}
	public void setDunThree(double dunThree) {
		this.dunThree = dunThree;
	}
	public double getDunFour() {
		return dunFour;
	}
	public void setDunFour(double dunFour) {
		this.dunFour = dunFour;
	}
	public double getDunFive() {
		return dunFive;
	}
	public void setDunFive(double dunFive) {
		this.dunFive = dunFive;
	}
	public double getYtd() {
		return ytd;
	}
	public void setYtd(double ytd) {
		this.ytd = ytd;
	}
	public double getInvoiceAmt1stWeek() {
		return invoiceAmt1stWeek;
	}
	public void setInvoiceAmt1stWeek(double invoiceAmt1stWeek) {
		this.invoiceAmt1stWeek = invoiceAmt1stWeek;
	}
	public double getInvoiceAmt2ndWeek() {
		return invoiceAmt2ndWeek;
	}
	public void setInvoiceAmt2ndWeek(double invoiceAmt2ndWeek) {
		this.invoiceAmt2ndWeek = invoiceAmt2ndWeek;
	}
	public double getInvoiceAmt3rdWeek() {
		return invoiceAmt3rdWeek;
	}
	public void setInvoiceAmt3rdWeek(double invoiceAmt3rdWeek) {
		this.invoiceAmt3rdWeek = invoiceAmt3rdWeek;
	}
	public double getInvoiceAmt4thWeek() {
		return invoiceAmt4thWeek;
	}
	public void setInvoiceAmt4thWeek(double invoiceAmt4thWeek) {
		this.invoiceAmt4thWeek = invoiceAmt4thWeek;
	}
	public double getInvoiceAmt5thWeek() {
		return invoiceAmt5thWeek;
	}
	public void setInvoiceAmt5thWeek(double invoiceAmt5thWeek) {
		this.invoiceAmt5thWeek = invoiceAmt5thWeek;
	}
	public double getAdvanceRatio() {
		return (advanceRatio/100);
	}
	public void setAdvanceRatio(double advanceRatio) {
		this.advanceRatio = advanceRatio;
	}
	public String getAccountOfficer() {
		return accountOfficer;
	}
	public void setAccountOfficer(String accountOfficer) {
		this.accountOfficer = accountOfficer;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getWeekOne() {
		return weekOne;
	}
	public void setWeekOne(String weekOne) {
		this.weekOne = weekOne;
	}
	public String getWeekTwo() {
		return weekTwo;
	}
	public void setWeekTwo(String weekTwo) {
		this.weekTwo = weekTwo;
	}
	public String getWeekThree() {
		return weekThree;
	}
	public void setWeekThree(String weekThree) {
		this.weekThree = weekThree;
	}
	public String getWeekFour() {
		return weekFour;
	}
	public void setWeekFour(String weekFour) {
		this.weekFour = weekFour;
	}
	public String getWeekFive() {
		return weekFive;
	}
	public void setWeekFive(String weekFive) {
		this.weekFive = weekFive;
	}
	public double getTotCollectionWk1() {
		return totCollectionWk1;
	}
	public void setTotCollectionWk1(double totCollectionWk1) {
		this.totCollectionWk1 = totCollectionWk1;
	}
	public double getTotCollectionWk2() {
		return totCollectionWk2;
	}
	public void setTotCollectionWk2(double totCollectionWk2) {
		this.totCollectionWk2 = totCollectionWk2;
	}
	public double getTotCollectionWk3() {
		return totCollectionWk3;
	}
	public void setTotCollectionWk3(double totCollectionWk3) {
		this.totCollectionWk3 = totCollectionWk3;
	}
	public double getTotCollectionWk4() {
		return totCollectionWk4;
	}
	public void setTotCollectionWk4(double totCollectionWk4) {
		this.totCollectionWk4 = totCollectionWk4;
	}
	public double getTotCollectionWk5() {
		return totCollectionWk5;
	}
	public void setTotCollectionWk5(double totCollectionWk5) {
		this.totCollectionWk5 = totCollectionWk5;
	}
	
	public double getTotCollectionWkYTD() {
		return totCollectionWkYTD;
	}
	public void setTotCollectionWkYTD(double totCollectionWkYTD) {
		this.totCollectionWkYTD = totCollectionWkYTD;
	}
	
	public double getScOne() {
		return scOne;
	}
	public void setScOne(double scOne) {
		this.scOne = scOne;
	}
	public double getScTwo() {
		return scTwo;
	}
	public void setScTwo(double scTwo) {
		this.scTwo = scTwo;
	}
	public double getScThree() {
		return scThree;
	}
	public void setScThree(double scThree) {
		this.scThree = scThree;
	}
	public double getScFour() {
		return scFour;
	}
	public void setScFour(double scFour) {
		this.scFour = scFour;
	}
	public double getScFive() {
		return scFive;
	}
	public void setScFive(double scFive) {
		this.scFive = scFive;
	}
	public double getMonthlySC() {
		return monthlySC;
	}
	public void setMonthlySC(double monthlySC) {
		this.monthlySC = monthlySC;
	}
	public double getYearlySC() {
		return yearlySC;
	}
	public void setYearlySC(double yearlySC) {
		this.yearlySC = yearlySC;
	}
	
	public String getScStatus() {
		return scStatus;
	}
	public void setScStatus(String scStatus) {
		this.scStatus = scStatus;
	}
	public String getBlrStatus() {
		return blrStatus;
	}
	public void setBlrStatus(String blrStatus) {
		this.blrStatus = blrStatus;
	}
	public String getAdvanceRatioStatus() {
		return advanceRatioStatus;
	}
	public void setAdvanceRatioStatus(String advanceRatioStatus) {
		this.advanceRatioStatus = advanceRatioStatus;
	}
	
	public int getInvCountOne() {
		return invCountOne;
	}
	public void setInvCountOne(int invCountOne) {
		this.invCountOne = invCountOne;
	}
	public int getInvCountTwo() {
		return invCountTwo;
	}
	public void setInvCountTwo(int invCountTwo) {
		this.invCountTwo = invCountTwo;
	}
	public int getInvCountThree() {
		return invCountThree;
	}
	public void setInvCountThree(int invCountThree) {
		this.invCountThree = invCountThree;
	}
	public int getInvCountFour() {
		return invCountFour;
	}
	public void setInvCountFour(int invCountFour) {
		this.invCountFour = invCountFour;
	}
	public int getInvCountFive() {
		return invCountFive;
	}
	public void setInvCountFive(int invCountFive) {
		this.invCountFive = invCountFive;
	}
	public int getInvCountYTD() {
		return invCountYTD;
	}
	public void setInvCountYTD(int invCountYTD) {
		this.invCountYTD = invCountYTD;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getClientStatus() {
		return clientStatus;
	}
	public void setClientStatus(String clientStatus) {
		this.clientStatus = clientStatus;
	}
	
	
}