package com.bdo.factor.beans;

import java.util.HashMap;
import java.util.Map;

public class AccountOfficer {
	private String c_BranchCode;
	private String c_AccountOfficerCode;
	private String c_Name;
	
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public String getC_AccountOfficerCode() {
		return c_AccountOfficerCode;
	}
	public void setC_AccountOfficerCode(String accountOfficerCode) {
		c_AccountOfficerCode = accountOfficerCode;
	}
	public String getC_Name() {
		return c_Name;
	}
	public void setC_Name(String name) {
		c_Name = name;
	}
	
	public void toObject(Map m) {
		HashMap map = (HashMap) m;
		
		this.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		this.setC_AccountOfficerCode((String) map.get("C_ACCOUNTOFFICERCODE"));
		this.setC_Name((String) map.get("C_NAME"));		
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(this.c_BranchCode);
		str.append(";C_ACCOUNTOFFICERCODE=").append(this.c_AccountOfficerCode);
		str.append(";C_NAME=").append(this.c_Name);
		
		return str.toString();
	}
	
	
}
