package com.bdo.factor.beans;

public class AdjustmentType{
	private String c_AdjCode;
	private String c_AdjDesc;
	
	public String getC_AdjCode() {
		return c_AdjCode;
	}

	public void setC_AdjCode(String adjCode) {
		c_AdjCode = adjCode;
	}

	public String getC_AdjDesc() {
		return c_AdjDesc;
	}

	public void setC_AdjDesc(String adjDesc) {
		c_AdjDesc = adjDesc;
	}

	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_ADJCODE=").append(c_AdjCode);
		str.append(";C_ADJDESC=").append(c_AdjDesc);
		
		return str.toString();
	}
	
	
	
	
}