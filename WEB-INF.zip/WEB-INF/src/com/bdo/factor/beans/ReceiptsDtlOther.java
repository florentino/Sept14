package com.bdo.factor.beans;

import java.util.Date;

public class ReceiptsDtlOther {

	private String c_description;
	private Double n_amount;
	private Date d_transactionDt;
	private long n_refNo;
	
	private int charge_type;
	private int charge_status;
	private double collected_amount;
	private double waived_amount;
	private int charge_deduction;
	private boolean is_net;
	
	public boolean isIs_net() {
		return is_net;
	}
	public void setIs_net(boolean is_net) {
		this.is_net = is_net;
	}
	public int getCharge_type() {
		return charge_type;
	}
	public void setCharge_type(int charge_type) {
		this.charge_type = charge_type;
	}
	public int getCharge_status() {
		return charge_status;
	}
	public void setCharge_status(int charge_status) {
		this.charge_status = charge_status;
	}
	public double getCollected_amount() {
		return collected_amount;
	}
	public void setCollected_amount(double collected_amount) {
		this.collected_amount = collected_amount;
	}
	public double getWaived_amount() {
		return waived_amount;
	}
	public void setWaived_amount(double waived_amount) {
		this.waived_amount = waived_amount;
	}
	public int getCharge_deduction() {
		return charge_deduction;
	}
	public void setCharge_deduction(int charge_deduction) {
		this.charge_deduction = charge_deduction;
	}

	public String getC_description() {
		return c_description;
	}
	public void setC_description(String c_description) {
		this.c_description = c_description;
	}
	public Double getN_amount() {
		return n_amount;
	}
	public void setN_amount(Double n_amount) {
		this.n_amount = n_amount;
	}
	public Date getD_transactionDt() {
		return d_transactionDt;
	}
	public void setD_transactionDt(Date d_transactionDt) {
		this.d_transactionDt = d_transactionDt;
	}
	public long getN_refNo() {
		return n_refNo;
	}
	public void setN_refNo(long n_refNo) {
		this.n_refNo = n_refNo;
	}
	 
	
}
