package com.bdo.factor.beans;

public class Holiday {
	private String c_BranchCode;
	private java.util.Date d_HolidayDate;
	private boolean b_StdHoliday;
	private String c_Description;
	
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public java.util.Date getD_HolidayDate() {
		return d_HolidayDate;
	}
	public void setD_HolidayDate(java.util.Date holidayDate) {
		d_HolidayDate = holidayDate;
	}
	public boolean isB_StdHoliday() {
		return b_StdHoliday;
	}
	public void setB_StdHoliday(boolean stdHoliday) {
		b_StdHoliday = stdHoliday;
	}
	public String getC_Description() {
		return c_Description;
	}
	public void setC_Description(String description) {
		c_Description = description;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(c_BranchCode);
		str.append(";D_HOLIDAYDATE=").append(d_HolidayDate);
		str.append(";B_STDHOLIDAY=").append(b_StdHoliday);
		str.append(";C_DESCRIPTION=").append(c_Description);
		
		return str.toString();
	}
}
