package com.bdo.factor.beans;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class DocStamp {

	private double N_DOCSTAMP;
	private Date D_TRANSACTIONDATE;
	private String C_USERID;
	private String C_BRANCHCODE;
			
	public double getN_DOCSTAMP() {
		return this.N_DOCSTAMP;
	}

	public void setN_DOCSTAMP(String N_DOCSTAMP) {
		N_DOCSTAMP = N_DOCSTAMP;
	}

	public Date getD_TRANSACTIONDATE() {
		return D_TRANSACTIONDATE;
	}

	public void setD_TRANSACTIONDATE(String D_TRANSACTIONDATE) {
		D_TRANSACTIONDATE = D_TRANSACTIONDATE;
	}

	public String getC_USERID() {
		return C_USERID;
	}

	public void setC_USERID(String C_USERID) {
		C_USERID = C_USERID;
	}

	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}

	public void setC_BRANCHCODE(String C_BRANCHCODE) {
		C_BRANCHCODE = C_BRANCHCODE;
	}

	public String toString() {
		StringBuilder strBank = new StringBuilder();
		strBank.append("N_DOCSTAMP=").append(N_DOCSTAMP);
		strBank.append(";D_TRANSACTIONDATE=").append(D_TRANSACTIONDATE);
		strBank.append(";C_USERID=").append(C_USERID);
		strBank.append(";C_BRANCHCODE=").append(C_BRANCHCODE);
		
		return strBank.toString();
	}
	
		
	
}
