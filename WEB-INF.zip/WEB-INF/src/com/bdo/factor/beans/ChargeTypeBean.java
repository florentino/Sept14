package com.bdo.factor.beans;

import java.util.List;

public class ChargeTypeBean {

	public static List<ChargeTypeBean> chargeTypeList; 
	public long id;
	public String description;
	public static List<ChargeTypeBean> getChargeTypeList() {
		return chargeTypeList;
	}
	public static void setChargeTypeList(List<ChargeTypeBean> chargeTypeList) {
		ChargeTypeBean.chargeTypeList = chargeTypeList;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
