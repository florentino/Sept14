package com.bdo.factor.beans;

import java.util.Date;
public class ReportField {
	
	private String asOfDate;
	private String clientCode;
	private String customerCode;	
	private String clientName;
	private String customerName;
	private String transactionDate;
	private String fullyPaidDate;
	private String accountOfficer;
	private String advanceRefNumber;	
	private String receiptNumber;
	private String invoiceNumber;
	private String invoiceDate;
	private String refundNumber;
	
	private String startDate;
	private String endDate;
	
	private String blrExpiryDate;
	
	private long nTerm;
	
	//--RLS(redd)  01/12/2011 add column term in sched of invoice
	private long invoiceTerm; 

	private double receiptAmount;
	private double invoiceAmount;
	private double creditNoteAmount;	
	private double blr;
	private double advanceRatio;
	private double dscRate;
	private double scrRate;
	private double serviceCharge;
	private double discountCharge;
	private double discChargeCollected;	
	private double oS_InvAmt;
	private double discAccrual;
	private double refundDiscCharge;
	private double refundAmount;
	
	
	//Monthly Charges
	/*
	 * discChargeAdvanceSum
	 * discChargeRefundSum
	 * totalDiscount
	 * serviceChargeAdvanceSum
	 * settingUpFee
	 * discChargeSettingUpFeeSum
	 * 
	 */
	
	private double discChargeAdvanceSum;
	private double discChargeRefundSum;
	private double totalDiscount;
	private double serviceChargeAdvanceSum;
	private double settingUpFee;
	private double discChargeSettingUpFeeSum;
	private double adjustmentAmountSum;
	
	
	
	//RLS(redd) 01/13/2011 Schedule of Advances fields 
	private String bankName;
	private String branchCode;
	private String branchName;
	private String bankCode;

	private String accountOfficerCode;
	private String bankAccountNo;
	private double advanceAmount;
	private double dcOfSettingUpFee;
	
	//RLS(redd) 01/19/2011 add to get sum of receivables per client in Schedule of Advances
	private double receivable;
	
	//CVG additional sched of advances total no. of invoices as of 02/22/15
	private int count_inv;
	//added by CVG as of 04-19-16  - total no. of advances
	private int cntAdvanceAmt;
	
	//for Schedule of Receipts
	private String paymentType;
	
	//RLS(redd) 01/21/2011 fields for activity log
	private long logId;
	private String logTime;
	private String userId;
	private String ipAddress;
	private String details;
	
	private Date currentDate;
	
	
	//Fully Paid Invoice CVG 05302017
	private String invoiceNo;
	private String datePaid;
	private String CASNumber;
	
	private String signatory;
	private String location;
	
	public ReportField(){		
	}
	
	public ReportField(String asOfDate){
		this.asOfDate =asOfDate;
	}	
	
	public ReportField(String startDate, String endDate){
		this.startDate =startDate;
		this.endDate =endDate;
	}
	
	public String getClientCode() {
		return clientCode;
	}
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getFullyPaidDate() {
		return fullyPaidDate;
	}
	public void setFullyPaidDate(String fullyPaidDate) {
		this.fullyPaidDate = fullyPaidDate;
	}
	public String getAccountOfficer() {
		return accountOfficer;
	}
	public void setAccountOfficer(String accountOfficer) {
		this.accountOfficer = accountOfficer;
	}
	public String getReceiptNumber() {
		return receiptNumber;
	}
	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public long getNTerm() {
		return nTerm;
	}
	public void setNTerm(long term) {
		nTerm = term;
	}
	public double getReceiptAmount() {
		return receiptAmount;
	}
	public void setReceiptAmount(double receiptAmount) {
		this.receiptAmount = receiptAmount;
	}
	public double getInvoiceAmount() {
		return invoiceAmount;
	}
	public void setInvoiceAmount(double invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	public double getCreditNoteAmount() {
		return creditNoteAmount;
	}
	public void setCreditNoteAmount(double creditNoteAmount) {
		this.creditNoteAmount = creditNoteAmount;
	}
	public double getBlr() {
		return blr;
	}
	public void setBlr(double blr) {
		this.blr = blr;
	}
	public double getAdvanceRatio() {
		return advanceRatio;
	}
	public void setAdvanceRatio(double advanceRatio) {
		this.advanceRatio = advanceRatio;
	}
	public double getDscRate() {
		return dscRate;
	}
	public void setDscRate(double dscRate) {
		this.dscRate = dscRate;
	}
	public double getScrRate() {
		return scrRate;
	}
	public void setScrRate(double scrRate) {
		this.scrRate = scrRate;
	}
	public double getServiceCharge() {
		return serviceCharge;
	}
	public void setServiceCharge(double serviceCharge) {
		this.serviceCharge = serviceCharge;
	}
	public double getDiscountCharge() {
		return discountCharge;
	}
	public void setDiscountCharge(double discountCharge) {
		this.discountCharge = discountCharge;
	}
	public double getDiscChargeCollected() {
		return discChargeCollected;
	}
	public void setDiscChargeCollected(double discChargeCollected) {
		this.discChargeCollected = discChargeCollected;
	}


	public String getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
	public double getOS_InvAmt() {
		return oS_InvAmt;
	}
	public void setOS_InvAmt(double invAmt) {
		oS_InvAmt = invAmt;
	}
	public String getAdvanceRefNumber() {
		return advanceRefNumber;
	}
	public void setAdvanceRefNumber(String advanceRefNumber) {
		this.advanceRefNumber = advanceRefNumber;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public double getDiscAccrual() {
		return discAccrual;
	}

	public void setDiscAccrual(double discAccrual) {
		this.discAccrual = discAccrual;
	}

	public double getDiscChargeAdvanceSum() {
		return discChargeAdvanceSum;
	}

	public void setDiscChargeAdvanceSum(double discChargeAdvanceSum) {
		this.discChargeAdvanceSum = discChargeAdvanceSum;
	}

	public double getDiscChargeRefundSum() {
		return discChargeRefundSum;
	}

	public void setDiscChargeRefundSum(double discChargeRefundSum) {
		this.discChargeRefundSum = discChargeRefundSum;
	}

	public double getTotalDiscount() {
		return totalDiscount;
	}

	public void setTotalDiscount(double totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public double getServiceChargeAdvanceSum() {
		return serviceChargeAdvanceSum;
	}

	public void setServiceChargeAdvanceSum(double serviceChargeAdvanceSum) {
		this.serviceChargeAdvanceSum = serviceChargeAdvanceSum;
	}

	public double getSettingUpFee() {
		return settingUpFee;
	}

	public void setSettingUpFee(double settingUpFee) {
		this.settingUpFee = settingUpFee;
	}

	public double getDiscChargeSettingUpFeeSum() {
		return discChargeSettingUpFeeSum;
	}

	public void setDiscChargeSettingUpFeeSum(double discChargeSettingUpFeeSum) {
		this.discChargeSettingUpFeeSum = discChargeSettingUpFeeSum;
	}

	public double getRefundDiscCharge() {
		return refundDiscCharge;
	}

	public void setRefundDiscCharge(double refundDiscCharge) {
		this.refundDiscCharge = refundDiscCharge;
	}

	public double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getRefundNumber() {
		return refundNumber;
	}

	public void setRefundNumber(String refundNumber) {
		this.refundNumber = refundNumber;
	}

	public double getAdjustmentAmountSum() {
		return adjustmentAmountSum;
	}

	public void setAdjustmentAmountSum(double adjustmentAmountSum) {
		this.adjustmentAmountSum = adjustmentAmountSum;
	}

	public String getBlrExpiryDate() {
		return blrExpiryDate;
	}

	public void setBlrExpiryDate(String blrExpiryDate) {
		this.blrExpiryDate = blrExpiryDate;
	}

	public long getInvoiceTerm() {
		return invoiceTerm;
	}

	public void setInvoiceTerm(long invoiceTerm) {
		this.invoiceTerm = invoiceTerm;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getAccountOfficerCode() {
		return accountOfficerCode;
	}

	public void setAccountOfficerCode(String accountOfficerCode) {
		this.accountOfficerCode = accountOfficerCode;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public double getAdvanceAmount() {
		return advanceAmount;
	}

	public void setAdvanceAmount(double advanceAmount) {
		this.advanceAmount = advanceAmount;
	}

	public double getDcOfSettingUpFee() {
		return dcOfSettingUpFee;
	}

	public void setDcOfSettingUpFee(double dcOfSettingUpFee) {
		this.dcOfSettingUpFee = dcOfSettingUpFee;
	}

	public double getReceivable() {
		return receivable;
	}

	public void setReceivable(double receivable) {
		this.receivable = receivable;
	}

	public long getLogId() {
		return logId;
	}

	public void setLogId(long logId) {
		this.logId = logId;
	}

	public String getLogTime() {
		return logTime;
	}

	public void setLogTime(String logTime) {
		this.logTime = logTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	//added by CVG as of 02/22/15
	public int getCount_inv() {
		return count_inv;
	}

	public void setCount_inv(int count_inv) {
		this.count_inv = count_inv;
	}
	
	
	//added by CVG as of 04-19-16
	public int getCntAdvanceAmt() {
		return cntAdvanceAmt;
	}

	public void setCntAdvanceAmt(int cntAdvanceAmt) {
		this.cntAdvanceAmt = cntAdvanceAmt;
	}

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getDatePaid() {
		return datePaid;
	}

	public void setDatePaid(String datePaid) {
		this.datePaid = datePaid;
	}

	public String getCASNumber() {
		return CASNumber;
	}

	public void setCASNumber(String cASNumber) {
		CASNumber = cASNumber;
	}

	public String getSignatory() {
		return signatory;
	}

	public void setSignatory(String signatory) {
		this.signatory = signatory;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	//point
	//public String getPaymentType() {
	//	return paymentType;
	//}

//	public void setPaymentType(String paymentType) {
	//	this.paymentType = paymentType;
	//}

	
	

	
	
	
	
}
