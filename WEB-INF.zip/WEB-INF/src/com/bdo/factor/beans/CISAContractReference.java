package com.bdo.factor.beans;

public class CISAContractReference {
	private String contractSource="FaMSC"; //client
	private int transID; //client
	
	public String getContractSource() {
		return contractSource;
	}
	public void setContractSource(String contractSource) {
		this.contractSource = contractSource;
	}
	public int getTransID() {
		return transID;
	}
	public void setTransID(int transID) {
		this.transID = transID;
	}
	
	
}
