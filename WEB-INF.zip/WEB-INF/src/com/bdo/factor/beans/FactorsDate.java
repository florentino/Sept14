package com.bdo.factor.beans;

public class FactorsDate {

}
