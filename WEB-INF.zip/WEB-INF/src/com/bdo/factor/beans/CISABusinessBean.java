package com.bdo.factor.beans;

public class CISABusinessBean {
	private int company_temp_id;
	private String party_id;
	private String account_officer;
	private String record_type;
	private String trade_name;
	private String address1_addressType;
	private String address1_fullAddress;
	private String identification1_type;
	private String identification1_number;
	private String text_log;
	private String source_data="Factors";
	private String contact1_contactType;
	private String contact1_contactValue;
	
	public int getCompany_temp_id() {
		return company_temp_id;
	}
	public void setCompany_temp_id(int company_temp_id) {
		this.company_temp_id = company_temp_id;
	}
	public String getParty_id() {
		return party_id;
	}
	public void setParty_id(String party_id) {
		this.party_id = party_id;
	}
	public String getAccount_officer() {
		return account_officer;
	}
	public void setAccount_officer(String account_officer) {
		this.account_officer = account_officer;
	}
	public String getRecord_type() {
		return record_type;
	}
	public void setRecord_type(String record_type) {
		this.record_type = record_type;
	}
	public String getTrade_name() {
		return trade_name;
	}
	public void setTrade_name(String trade_name) {
		this.trade_name = trade_name;
	}
	public String getAddress1_addressType() {
		return address1_addressType;
	}
	public void setAddress1_addressType(String address1_addressType) {
		this.address1_addressType = address1_addressType;
	}
	public String getAddress1_fullAddress() {
		return address1_fullAddress;
	}
	public void setAddress1_fullAddress(String address1_fullAddress) {
		this.address1_fullAddress = address1_fullAddress;
	}
	public String getIdentification1_type() {
		return identification1_type;
	}
	public void setIdentification1_type(String identification1_type) {
		this.identification1_type = identification1_type;
	}
	public String getIdentification1_number() {
		return identification1_number;
	}
	public void setIdentification1_number(String identification1_number) {
		this.identification1_number = identification1_number;
	}
	public String getText_log() {
		return text_log;
	}
	public void setText_log(String text_log) {
		this.text_log = text_log;
	}
	public String getSource_data() {
		return source_data;
	}
	public void setSource_data(String source_data) {
		this.source_data = source_data;
	}
	//

	public String getContact1_contactType() {
		return contact1_contactType;
	}
	public void setContact1_contactType(String contact1_contactType) {
		this.contact1_contactType = contact1_contactType;
	}
	public String getContact1_contactValue() {
		return contact1_contactValue;
	}
	public void setContact1_contactValue(String contact1_contactValue) {
		this.contact1_contactValue = contact1_contactValue;
	}
	
	
}
