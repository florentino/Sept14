package com.bdo.factor.beans;

import java.util.Date;
import java.util.Map;

public class Invoice {
	private String C_BRANCHCODE;
	private String C_CLNTCODE;
	private String C_CUSTCODE;
	private String C_NAME;
	private String C_CUSTNAME;
	private String C_INVOICENO;
	private Date D_INVOICEDATE;
	private Date D_INVOICEDUEDATE;
	private Date D_TRANSACTIONDATE;
	private double N_ORIGINVOICEAMT;
	private double N_RECEIPTAMT;
	private double CreditNote_N_AMOUNT;
	private double N_INVOICEAMT;
	private long N_TERM;
	private long CCTERM;
	private long N_DUNNINGDAYS;
	private String C_STATUS;
	private double N_OSInvAmt;
	private long N_INVNO;
	private String D_FULLYPAIDDATE;
	

	public Invoice(){
	}
	
	public Invoice(Map map){
		
		if(map.get("C_BRANCHCODE")!=null  && map.containsKey("C_BRANCHCODE") )
			this.setC_BRANCHCODE((String) map.get("C_BRANCHCODE"));
		
		if(map.get("C_CLNTCODE")!=null && map.containsKey("C_CLNTCODE"))
			this.setC_CLNTCODE(map.get("C_CLNTCODE").toString());
		
		if(map.get("C_CUSTCODE")!=null && map.containsKey("C_CUSTCODE"))
			this.setC_CUSTCODE( map.get("C_CUSTCODE").toString());
		
		if(map.get("C_NAME")!=null && map.containsKey("C_NAME"))
			this.setC_NAME((String) map.get("C_NAME"));
		
		if(map.get("C_CUSTNAME")!=null && map.containsKey("C_CUSTNAME"))
			this.setC_CUSTNAME((String) map.get("C_CUSTNAME"));
		
		if(map.get("C_INVOICENO")!=null && map.containsKey("C_INVOICENO"))
			this.setC_INVOICENO((String) map.get("C_INVOICENO"));
		
		if(map.get("D_INVOICEDATE")!=null && map.containsKey("D_INVOICEDATE"))
			this.setD_INVOICEDATE(new Date(map.get("D_INVOICEDATE").toString()));
		
		if(map.get("D_INVOICEDUEDATE")!=null && map.containsKey("D_INVOICEDUEDATE"))
			this.setD_INVOICEDUEDATE(new Date(map.get("D_INVOICEDUEDATE").toString()));
		
		if(map.get("D_TRANSACTIONDATE")!=null && map.containsKey("D_TRANSACTIONDATE"))
			this.setD_TRANSACTIONDATE(new Date(map.get("D_TRANSACTIONDATE").toString()));
		
		if(map.get("N_ORIGINVOICEAMT")!=null && map.containsKey("N_ORIGINVOICEAMT"))
			this.setN_ORIGINVOICEAMT(new Double (map.get("N_ORIGINVOICEAMT").toString()));
		
		if(map.get("N_INVOICEAMT")!=null && map.containsKey("N_INVOICEAMT"))
			this.setN_INVOICEAMT(Double.parseDouble(map.get("N_INVOICEAMT").toString()));
		
		if(map.get("N_TERM")!=null && map.containsKey("N_TERM"))
			this.setN_TERM(Long.parseLong(map.get("N_TERM").toString()));
		
		if(map.get("CCTERM")!=null && map.containsKey("CCTERM"))
			this.setCCTERM(Long.parseLong(map.get("CCTERM").toString()));
		
		if(map.get("N_DUNNINGDAYS")!=null && map.containsKey("N_DUNNINGDAYS"))
			this.setN_DUNNINGDAYS(Long.parseLong(map.get("N_DUNNINGDAYS").toString()));
		
		if(map.get("C_STATUS")!=null && map.containsKey("C_STATUS"))
			this.setC_STATUS((String) map.get("C_STATUS"));
	}
	
	
	public double getN_OSInvAmt() {
		return N_OSInvAmt;
	}
	public void setN_OSInvAmt(double invAmt) {
		N_OSInvAmt = invAmt;
	}

	private long ageing;
	private String asOfDate;
	private long ageByDunning;

	public double getN_RECEIPTAMT() {
		return N_RECEIPTAMT;
	}
	public void setN_RECEIPTAMT(double n_receiptamt) {
		N_RECEIPTAMT = n_receiptamt;
	}
	public double getCreditNote_N_AMOUNT() {
		return CreditNote_N_AMOUNT;
	}
	public void setCreditNote_N_AMOUNT(double creditNote_N_AMOUNT) {
		CreditNote_N_AMOUNT = creditNote_N_AMOUNT;
	}	
	
	private String invoiceDate;
	private String transactionDate;
	
	private String C_CURRENCYCODE;
	private double N_EXCHANGERATE;
	
	public String getC_CURRENCYCODE() {
		return C_CURRENCYCODE;
	}
	public void setC_CURRENCYCODE(String c_currencycode) {
		C_CURRENCYCODE = c_currencycode;
	}
	public double getN_EXCHANGERATE() {
		return N_EXCHANGERATE;
	}
	public void setN_EXCHANGERATE(double n_exchangerate) {
		N_EXCHANGERATE = n_exchangerate;
	}
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}
	public void setC_BRANCHCODE(String c_branchcode) {
		C_BRANCHCODE = c_branchcode;
	}
	public String getC_CLNTCODE() {
		return C_CLNTCODE;
	}
	public void setC_CLNTCODE(String c_clntcode) {
		C_CLNTCODE = c_clntcode;
	}
	public String getC_CUSTCODE() {
		return C_CUSTCODE;
	}
	public void setC_CUSTCODE(String c_custcode) {
		C_CUSTCODE = c_custcode;
	}
	public String getC_NAME() {
		return C_NAME;
	}
	public void setC_NAME(String c_name) {
		C_NAME = c_name;
	}
	public String getC_CUSTNAME() {
		return C_CUSTNAME;
	}
	public void setC_CUSTNAME(String c_custname) {
		C_CUSTNAME = c_custname;
	}
	public String getC_INVOICENO() {
		return C_INVOICENO;
	}
	public void setC_INVOICENO(String c_invoiceno) {
		C_INVOICENO = c_invoiceno;
	}
	public Date getD_INVOICEDATE() {
		return D_INVOICEDATE;
	}
	public void setD_INVOICEDATE(Date d_invoicedate) {
		D_INVOICEDATE = d_invoicedate;
	}
	public Date getD_INVOICEDUEDATE() {
		return D_INVOICEDUEDATE;
	}
	public void setD_INVOICEDUEDATE(Date d_invoiceduedate) {
		D_INVOICEDUEDATE = d_invoiceduedate;
	}
	public Date getD_TRANSACTIONDATE() {
		return D_TRANSACTIONDATE;
	}
	public void setD_TRANSACTIONDATE(Date d_transactiondate) {
		D_TRANSACTIONDATE = d_transactiondate;
	}
	public double getN_ORIGINVOICEAMT() {
		return N_ORIGINVOICEAMT;
	}
	public void setN_ORIGINVOICEAMT(double n_originvoiceamt) {
		N_ORIGINVOICEAMT = n_originvoiceamt;
	}
	public double getN_INVOICEAMT() {
		return N_INVOICEAMT;
	}
	public void setN_INVOICEAMT(double n_invoiceamt) {
		N_INVOICEAMT = n_invoiceamt;
	}
	public long getN_TERM() {
		return N_TERM;
	}
	public void setN_TERM(long n_term) {
		N_TERM = n_term;
	}
	public long getCCTERM() {
		return CCTERM;
	}
	public void setCCTERM(long ccterm) {
		CCTERM = ccterm;
	}
	public long getN_DUNNINGDAYS() {
		return N_DUNNINGDAYS;
	}
	public void setN_DUNNINGDAYS(long n_dunningdays) {
		N_DUNNINGDAYS = n_dunningdays;
	}
	public String getC_STATUS() {
		return C_STATUS;
	}
	public void setC_STATUS(String c_status) {
		C_STATUS = c_status;
	}
	
	public String getD_FULLYPAIDDATE() {
		return D_FULLYPAIDDATE;
	}

	public void setD_FULLYPAIDDATE(String d_FULLYPAIDDATE) {
		D_FULLYPAIDDATE = d_FULLYPAIDDATE;
	}

	public String toString(){
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(C_BRANCHCODE);
		str.append(";C_CLNTCODE=").append(C_CLNTCODE);
		str.append(";C_CUSTCODE=").append(C_CUSTCODE);
		str.append(";C_NAME=").append(C_NAME);
		str.append(";C_CUSTNAME=").append(C_CUSTNAME);
		str.append(";C_INVOICENO=").append(C_INVOICENO);
		str.append(";D_INVOICEDATE=").append(D_INVOICEDATE);
		str.append(";D_INVOICEDUEDATE=").append(D_INVOICEDUEDATE);
		str.append(";D_TRANSACTIONDATE=").append(D_TRANSACTIONDATE);
		str.append(";N_ORIGINVOICEAMT=").append(N_ORIGINVOICEAMT);
		str.append(";N_INVOICEAMT=").append(N_INVOICEAMT);
		str.append(";N_TERM=").append(N_TERM);
		str.append(";CCTERM=").append(CCTERM);
		str.append(";N_DUNNINGDAYS=").append(N_DUNNINGDAYS);
		str.append(";C_STATUS=").append(C_STATUS);
		str.append(";D_FULLYPAIDDATE=").append(D_FULLYPAIDDATE);
		return str.toString();
	}
	
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public long getAgeing() {
		return ageing;
	}
	public void setAgeing(long ageing) {
		this.ageing = ageing;
	}	
	public String getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
	public long getAgeByDunning() {
		return ageByDunning;
	}
	public void setAgeByDunning(long ageByDunning) {
		this.ageByDunning = ageByDunning;
	}
	public long getN_INVNO() {
		return N_INVNO;
	}
	public void setN_INVNO(long n_invno) {
		N_INVNO = n_invno;
	}	
}
