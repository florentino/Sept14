package com.bdo.factor.beans;

import java.util.Date;
import java.util.Map;

public class Adjustment{
	
	private String C_BRANCHCODE;
	private String N_REFNO;
	private String D_TRANSACTIONDATE;
	private String C_CLNTCODE;
	private String C_CUSTCODE;
	private String C_INVOICENO;
	private String D_INVOICEDATE;
	private String C_ADJCODE;
	private double N_AMOUNT;
	private String C_STATUS;
	private String C_MAKER;
	private String C_APPROVER;
	private String D_APPROVEDDATE;
	
	public Adjustment(){
	}
	
public Adjustment(Map map){
		
		if(map.get("C_BRANCHCODE")!=null  && map.containsKey("C_BRANCHCODE") )
			this.setC_BRANCHCODE((String) map.get("C_BRANCHCODE"));
		
		if(map.get("N_REFNO")!=null && map.containsKey("N_REFNO"))
			this.setN_REFNO(map.get("N_REFNO").toString());
		
		if(map.get("D_TRANSACTIONDATE")!=null && map.containsKey("D_TRANSACTIONDATE"))
			this.setD_TRANSACTIONDATE(map.get("D_TRANSACTIONDATE").toString());
		
		if(map.get("C_CLNTCODE")!=null && map.containsKey("C_CLNTCODE"))
			this.setC_CLNTCODE((String) map.get("C_NAME"));
		
		if(map.get("C_CUSTCODE")!=null && map.containsKey("C_CUSTCODE"))
			this.setC_CUSTCODE((String) map.get("C_CUSTCODE"));
		
		if(map.get("C_INVOICENO")!=null && map.containsKey("C_INVOICENO"))
			this.setC_INVOICENO((String) map.get("C_INVOICENO"));
		
		if(map.get("D_INVOICEDATE")!=null && map.containsKey("D_INVOICEDATE"))
			this.setD_INVOICEDATE(map.get("D_INVOICEDATE").toString());
			
		if(map.get("C_ADJCODE")!=null && map.containsKey("C_ADJCODE"))
			this.setC_ADJCODE(map.get("C_ADJCODE").toString());
		
		if(map.get("N_AMOUNT")!=null && map.containsKey("N_AMOUNT"))
			this.setN_AMOUNT(new Double (map.get("N_AMOUNT").toString()));
		
		if(map.get("C_STATUS")!=null && map.containsKey("C_STATUS"))
			this.setC_STATUS(map.get("C_STATUS").toString());
		
		if(map.get("C_MAKER")!=null && map.containsKey("C_MAKER"))
			this.setC_MAKER(map.get("C_MAKER").toString());
		
		if(map.get("C_APPROVER")!=null && map.containsKey("C_APPROVER"))
			this.setC_APPROVER(map.get("C_APPROVER").toString());
				
		if(map.get("D_APPROVEDDATE")!=null && map.containsKey("D_APPROVEDDATE"))
			this.setD_APPROVEDDATE(map.get("D_APPROVEDDATE").toString());
	}
	
	
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}

	public void setC_BRANCHCODE(String c_branchcode) {
		C_BRANCHCODE = c_branchcode;
	}
	
	public String getN_REFNO() {
		return N_REFNO;
	}

	public void setN_REFNO(String n_refno) {
		N_REFNO = n_refno;
	}

	public String getD_TRANSACTIONDATE() {
		return D_TRANSACTIONDATE;
	}

	public void setD_TRANSACTIONDATE(String d_transactiondate) {
		D_TRANSACTIONDATE = d_transactiondate;
	}

	public String getC_CLNTCODE() {
		return C_CLNTCODE;
	}

	public void setC_CLNTCODE(String c_clntcode) {
		C_CLNTCODE = c_clntcode;
	}

	public String getC_CUSTCODE() {
		return C_CUSTCODE;
	}

	public void setC_CUSTCODE(String c_custcode) {
		C_CUSTCODE = c_custcode;
	}

	public String getC_INVOICENO() {
		return C_INVOICENO;
	}

	public void setC_INVOICENO(String c_invoiceno) {
		C_INVOICENO = c_invoiceno;
	}

	public String getD_INVOICEDATE() {
		return D_INVOICEDATE;
	}

	public void setD_INVOICEDATE(String d_invoicedate) {
		D_INVOICEDATE = d_invoicedate;
	}

	public String getC_ADJCODE() {
		return C_ADJCODE;
	}

	public void setC_ADJCODE(String c_adjcode) {
		C_ADJCODE = c_adjcode;
	}

	public double getN_AMOUNT() {
		return N_AMOUNT;
	}

	public void setN_AMOUNT(double n_amount) {
		N_AMOUNT = n_amount;
	}

	public String getC_STATUS() {
		return C_STATUS;
	}

	public void setC_STATUS(String c_status) {
		C_STATUS = c_status;
	}

	public String getC_MAKER() {
		return C_MAKER;
	}

	public void setC_MAKER(String c_maker) {
		C_MAKER = c_maker;
	}

	public String getC_APPROVER() {
		return C_APPROVER;
	}

	public void setC_APPROVER(String c_approver) {
		C_APPROVER = c_approver;
	}

	public String getD_APPROVEDDATE() {
		return D_APPROVEDDATE;
	}

	public void setD_APPROVEDDATE(String d_approveddate) {
		D_APPROVEDDATE = d_approveddate;
	}

	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(C_BRANCHCODE);
		str.append(";N_REFNO=").append(N_REFNO);
		str.append(";D_TRANSACTIONDATE=").append(D_TRANSACTIONDATE);
		str.append(";C_CLNTCODE=").append(C_CLNTCODE);
		str.append(";C_CUSTCODE=").append(C_CUSTCODE);
		str.append(";C_CLNTCODE=").append(C_CLNTCODE);
		str.append(";C_INVOICENO=").append(C_INVOICENO);
		str.append(";D_INVOICEDATE=").append(D_INVOICEDATE);
		str.append(";C_ADJCODE=").append(C_ADJCODE);
		str.append(";N_AMOUNT=").append(N_AMOUNT);
		str.append(";C_STATUS=").append(C_STATUS);
		str.append(";C_MAKER=").append(C_MAKER);
		str.append(";C_APPROVER=").append(C_APPROVER);
		str.append(";D_APPROVEDDATE=").append(D_APPROVEDDATE);
	
		return str.toString();
	}
}
	