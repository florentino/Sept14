package com.bdo.factor.beans;

public class CisaCustomerReference {

	private String clientSource; //customer
	private int clientID; //customer
		
	public String getClientSource() {
		return clientSource;
	}
	public void setClientSource(String clientSource) {
		this.clientSource = clientSource;
	}

	public int getClientID() {
		return clientID;
	}
	public void setClientID(int clientID) {
		this.clientID = clientID;
	}

	
}
