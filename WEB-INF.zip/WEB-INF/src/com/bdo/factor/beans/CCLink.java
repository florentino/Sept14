package com.bdo.factor.beans;

import java.util.Date;
public class CCLink {
	private String c_BranchCode;
	private String c_ClntCode;
	private double n_ClLimit;
	private java.util.Date d_ApDate;
	private java.util.Date d_ExDate;
	private String c_TermCode;
	private String c_Currency;
	private byte b_Terminated;
	private int n_Term;
	private double n_CurInv;
	private double n_Over30Day;
	private double n_Over60Day;
	private double n_Over90Day;
	private double n_Over120Day;
	private double n_Over150Day;
	private double n_Over180Day;
	private double n_Over210Day;
	private java.util.Date d_MCreate;
	private java.util.Date d_MUpdate;
	private double n_CcLimit1;
	private java.util.Date d_CcApDate1;
	private double unapprovedReceivables;


	private java.util.Date d_CcExDate1;
	
	/*Added by Roldan Somontina
	* for aging analysis
	*
	*/
	private String clientName;
	private String customerName;
	private String asOfDate;
	private double n_Current;
	private double n_1to30;
	private double n_31to60;
	private double n_61to90;
	private double n_91to120;
	private double n_121to150;
	private double n_151to180;
	private double n_Over180;
	private double n_TotalOS;
	private int B_NLAct;
	private double n_CcLimit;
	private double fundLimit;
	private long c_Dunning;

	/*Added by Roldan Somontina
	* for ageing summary by client
	* Date: July 1, 2009
	*/
	private double percentCurrent=0.00;
	private double percent1to30=0.00;
	private double percent31to60=0.00;
	private double percent61to90=0.00;
	private double percent91to120=0.00;
	private double percent121to150=0.00;
	private double percent151to180=0.00;
	private double percentOver180=0.00;
	private double percentTotalOS=0.00;		
	
	private Date currentdate;

	public CCLink(String clientCode, String branchCode, String asOfDate){
		this.c_ClntCode=clientCode;
		this.c_BranchCode=branchCode;
		this.asOfDate=asOfDate;
	}
	
	public CCLink() {
		// TODO Auto-generated constructor stub
	}

	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public String getC_ClntCode() {
		return c_ClntCode;
	}
	public void setC_ClntCode(String clntCode) {
		c_ClntCode = clntCode;
	}
	public double getN_ClLimit() {
		return n_ClLimit;
	}
	public void setN_ClLimit(double clLimit) {
		n_ClLimit = clLimit;
	}
	public java.util.Date getD_ApDate() {
		return d_ApDate;
	}
	public void setD_ApDate(java.util.Date apDate) {
		d_ApDate = apDate;
	}
	public java.util.Date getD_ExDate() {
		return d_ExDate;
	}
	public void setD_ExDate(java.util.Date exDate) {
		d_ExDate = exDate;
	}
	public String getC_TermCode() {
		return c_TermCode;
	}
	public void setC_TermCode(String termCode) {
		c_TermCode = termCode;
	}
	public String getC_Currency() {
		return c_Currency;
	}
	public void setC_Currency(String currency) {
		c_Currency = currency;
	}
	public byte getB_Terminated() {
		return b_Terminated;
	}
	public void setB_Terminated(byte terminated) {
		b_Terminated = terminated;
	}
	public int getN_Term() {
		return n_Term;
	}
	public void setN_Term(int term) {
		n_Term = term;
	}
	public double getN_CurInv() {
		return n_CurInv;
	}
	public void setN_CurInv(double curInv) {
		n_CurInv = curInv;
	}
	public double getN_Over30Day() {
		return n_Over30Day;
	}
	public void setN_Over30Day(double over30Day) {
		n_Over30Day = over30Day;
	}
	public double getN_Over60Day() {
		return n_Over60Day;
	}
	public void setN_Over60Day(double over60Day) {
		n_Over60Day = over60Day;
	}
	public double getN_Over90Day() {
		return n_Over90Day;
	}
	public void setN_Over90Day(double over90Day) {
		n_Over90Day = over90Day;
	}
	public double getN_Over120Day() {
		return n_Over120Day;
	}
	public void setN_Over120Day(double over120Day) {
		n_Over120Day = over120Day;
	}
	public double getN_Over150Day() {
		return n_Over150Day;
	}
	public void setN_Over150Day(double over150Day) {
		n_Over150Day = over150Day;
	}
	public double getN_Over180Day() {
		return n_Over180Day;
	}
	public void setN_Over180Day(double over180Day) {
		n_Over180Day = over180Day;
	}
	public double getN_Over210Day() {
		return n_Over210Day;
	}
	public void setN_Over210Day(double over210Day) {
		n_Over210Day = over210Day;
	}
	public java.util.Date getD_MCreate() {
		return d_MCreate;
	}
	public void setD_MCreate(java.util.Date create) {
		d_MCreate = create;
	}
	public java.util.Date getD_MUpdate() {
		return d_MUpdate;
	}
	public void setD_MUpdate(java.util.Date update) {
		d_MUpdate = update;
	}
	public double getN_CcLimit1() {
		return n_CcLimit1;
	}
	public void setN_CcLimit1(double ccLimit1) {
		n_CcLimit1 = ccLimit1;
	}
	public java.util.Date getD_CcApDate1() {
		return d_CcApDate1;
	}
	public void setD_CcApDate1(java.util.Date ccApDate1) {
		d_CcApDate1 = ccApDate1;
	}
	public java.util.Date getD_CcExDate1() {
		return d_CcExDate1;
	}
	public void setD_CcExDate1(java.util.Date ccExDate1) {
		d_CcExDate1 = ccExDate1;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("C_BRANCHCODE=").append(c_BranchCode);
		str.append(";C_CLNTCODE=").append(c_ClntCode);
		str.append(";N_CLLIMIT=").append(n_ClLimit);
		str.append(";D_APDATE=").append(d_ApDate);
		str.append(";D_EXDATE=").append(d_ExDate);
		str.append(";C_TERMCODE=").append(c_TermCode);
		str.append(";C_CURRENCY=").append(c_Currency);
		str.append(";B_TERMINATED=").append(b_Terminated);
		str.append(";N_TERM=").append(n_Term);
		str.append(";N_CURINV=").append(n_CurInv);
		str.append(";N_OVER30DAY=").append(n_Over30Day);
		str.append(";N_OVER60DAY=").append(n_Over60Day);
		str.append(";N_OVER90DAY=").append(n_Over90Day);
		str.append(";N_OVER120DAY=").append(n_Over120Day);
		str.append(";N_OVER150DAY=").append(n_Over150Day);
		str.append(";N_OVER180DAY=").append(n_Over180Day);
		str.append(";N_OVER210DAY=").append(n_Over210Day);
		str.append(";D_MCREATE=").append(d_MCreate);
		str.append(";D_MUPDATE=").append(d_MUpdate);
		str.append(";N_CCLIMIT1=").append(n_CcLimit1);
		str.append(";D_CCAPDATE1=").append(d_CcApDate1);
		str.append(";D_CCEXDATE1=").append(d_CcExDate1);
		
		return str.toString();
	}
	
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
	public double getN_Current() {
		return n_Current;
	}
	public void setN_Current(double current) {
		n_Current = current;
	}
	public double getN_1to30() {
		return n_1to30;
	}
	public void setN_1to30(double n_1to30) {
		this.n_1to30 = n_1to30;
	}
	public double getN_31to60() {
		return n_31to60;
	}
	public void setN_31to60(double n_31to60) {
		this.n_31to60 = n_31to60;
	}
	public double getN_61to90() {
		return n_61to90;
	}
	public void setN_61to90(double n_61to90) {
		this.n_61to90 = n_61to90;
	}
	public double getN_91to120() {
		return n_91to120;
	}
	public void setN_91to120(double n_91to120) {
		this.n_91to120 = n_91to120;
	}
	public double getN_121to150() {
		return n_121to150;
	}
	public void setN_121to150(double n_121to150) {
		this.n_121to150 = n_121to150;
	}
	public double getN_151to180() {
		return n_151to180;
	}
	public void setN_151to180(double n_151to180) {
		this.n_151to180 = n_151to180;
	}
	public double getN_Over180() {
		return n_Over180;
	}
	public void setN_over180(double n_over180) {
		this.n_Over180 = n_over180;
	}
	public double getN_TotalOS() {
		return n_TotalOS;
	}
	public void setN_TotalOS(double totalOS) {
		n_TotalOS = totalOS;
	}
	public int getB_NLAct() {
		return B_NLAct;
	}
	public void setB_NLAct(int act) {
		B_NLAct = act;
	}
	public double getN_CcLimit() {
		return n_CcLimit;
	}
	public void setN_CcLimit(double ccLimit) {
		n_CcLimit = ccLimit;
	}
	public void setN_Over180(double over180) {
		n_Over180 = over180;
	}
	public double getFundLimit() {
		return fundLimit;
	}
	public void setFundLimit(double fundLimit) {
		this.fundLimit = fundLimit;
	}

	public long getC_Dunning() {
		return c_Dunning;
	}

	public void setC_Dunning(long dunning) {
		c_Dunning = dunning;
	}

	public double getPercentCurrent() {
		return percentCurrent;
	}

	public void setPercentCurrent(double percentCurrent) {
		this.percentCurrent = percentCurrent;
	}

	public double getPercent1to30() {
		return percent1to30;
	}

	public void setPercent1to30(double percent1to30) {
		this.percent1to30 = percent1to30;
	}

	public double getPercent31to60() {
		return percent31to60;
	}

	public void setPercent31to60(double percent31to60) {
		this.percent31to60 = percent31to60;
	}

	public double getPercent61to90() {
		return percent61to90;
	}

	public void setPercent61to90(double percent61to90) {
		this.percent61to90 = percent61to90;
	}

	public double getPercent91to120() {
		return percent91to120;
	}

	public void setPercent91to120(double percent91to120) {
		this.percent91to120 = percent91to120;
	}

	public double getPercent121to150() {
		return percent121to150;
	}

	public void setPercent121to150(double percent121to150) {
		this.percent121to150 = percent121to150;
	}

	public double getPercent151to180() {
		return percent151to180;
	}

	public void setPercent151to180(double percent151to180) {
		this.percent151to180 = percent151to180;
	}

	public double getPercentOver180() {
		return percentOver180;
	}

	public void setPercentOver180(double percentOver180) {
		this.percentOver180 = percentOver180;
	}

	public double getPercentTotalOS() {
		return percentTotalOS;
	}

	public void setPercentTotalOS(double percentTotalOS) {
		this.percentTotalOS = percentTotalOS;
	}

	public double getUnapprovedReceivables() {
		return unapprovedReceivables;
	}

	public void setUnapprovedReceivables(double unapprovedReceivables) {
		this.unapprovedReceivables = unapprovedReceivables;
	}
	public Date getCurrentdate() {
		return currentdate;
	}

	public void setCurrentdate(Date currentdate) {
		this.currentdate = currentdate;
	}

}
