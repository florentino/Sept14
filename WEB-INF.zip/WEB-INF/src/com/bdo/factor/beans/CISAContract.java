package com.bdo.factor.beans;

import java.util.Date;

public class CISAContract {
	private int contract_temp_id;
	private String account_officer;
	private String record_type;
	private String provider_subject_no;
	private String role;
	private String provider_contract_no;
	private String contract_type;
	private String contract_phase;
	private String currency;
	private String original_currency;
	private Date contract_start_date;
	private String transaction_type_sub_facility;
	private int outstanding_balance;
	private int overdue_payments_no;
	private int overdue_payments_amount;
	private int overdue_days;
	private String text_log;
	private String source_data="Factors";
	
	private Date contract_end_planned_date;
	private double financed_amount;
	private int installment_numbers;
	private String payment_periodicity;
	private double monthly_payment_amount;
	private double last_payment_amount;
	private int outstanding_payment_no;
	
	public int getContract_temp_id() {
		return contract_temp_id;
	}
	public void setContract_temp_id(int contract_temp_id) {
		this.contract_temp_id = contract_temp_id;
	}
	public String getAccount_officer() {
		return account_officer;
	}
	public void setAccount_officer(String account_officer) {
		this.account_officer = account_officer;
	}
	public String getRecord_type() {
		return record_type;
	}
	public void setRecord_type(String record_type) {
		this.record_type = record_type;
	}
	public String getProvider_subject_no() {
		return provider_subject_no;
	}
	public void setProvider_subject_no(String provider_subject_no) {
		this.provider_subject_no = provider_subject_no;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getProvider_contract_no() {
		return provider_contract_no;
	}
	public void setProvider_contract_no(String provider_contract_no) {
		this.provider_contract_no = provider_contract_no;
	}
	public String getContract_type() {
		return contract_type;
	}
	public void setContract_type(String contract_type) {
		this.contract_type = contract_type;
	}
	public String getContract_phase() {
		return contract_phase;
	}
	public void setContract_phase(String contract_phase) {
		this.contract_phase = contract_phase;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getOriginal_currency() {
		return original_currency;
	}
	public void setOriginal_currency(String original_currency) {
		this.original_currency = original_currency;
	}
	public Date getContract_start_date() {
		return contract_start_date;
	}
	public void setContract_start_date(Date contract_start_date) {
		this.contract_start_date = contract_start_date; 
	}
	public String getTransaction_type_sub_facility() {
		return transaction_type_sub_facility;
	}
	public void setTransaction_type_sub_facility(
			String transaction_type_sub_facility) {
		this.transaction_type_sub_facility = transaction_type_sub_facility;
	}
	public int getOutstanding_balance() {
		return outstanding_balance;
	}
	public void setOutstanding_balance(int outstanding_balance) {
		this.outstanding_balance = outstanding_balance;
	}
	public int getOverdue_payments_no() {
		return overdue_payments_no;
	}
	public void setOverdue_payments_no(int overdue_payments_no) {
		this.overdue_payments_no = overdue_payments_no;
	}
	public int getOverdue_payments_amount() {
		return overdue_payments_amount;
	}
	public void setOverdue_payments_amount(int overdue_payments_amount) {
		this.overdue_payments_amount = overdue_payments_amount;
	}
	public int getOverdue_days() {
		return overdue_days;
	}
	public void setOverdue_days(int overdue_days) {
		this.overdue_days = overdue_days;
	}
	public String getText_log() {
		return text_log;
	}
	public void setText_log(String text_log) {
		this.text_log = text_log;
	}
	public String getSource_data() {
		return source_data;
	}
	public void setSource_data(String source_data) {
		this.source_data = source_data;
	}
	
	//additional fields cvg
	public Date getContract_end_planned_date() {
		return contract_end_planned_date;
	}
	public void setContract_end_planned_date(Date contract_end_planned_date) {
		this.contract_end_planned_date = contract_end_planned_date;
	}
	public double getFinanced_amount() {
		return financed_amount;
	}
	public void setFinanced_amount(double financed_amount) {
		this.financed_amount = financed_amount;
	}
	public int getInstallment_numbers() {
		return installment_numbers;
	}
	public void setInstallment_numbers(int installment_numbers) {
		this.installment_numbers = installment_numbers;
	}
	public String getPayment_periodicity() {
		return payment_periodicity;
	}
	public void setPayment_periodicity(String payment_periodicity) {
		this.payment_periodicity = payment_periodicity;
	}
	
	public double getLast_payment_amount() {
		return last_payment_amount;
	}
	public void setLast_payment_amount(double last_payment_amount) {
		this.last_payment_amount = last_payment_amount;
	}
	public int getOutstanding_payment_no() {
		return outstanding_payment_no;
	}
	public void setOutstanding_payment_no(int outstanding_payment_no) {
		this.outstanding_payment_no = outstanding_payment_no;
	}
	public double getMonthly_payment_amount() {
		return monthly_payment_amount;
	}
	public void setMonthly_payment_amount(double monthly_payment_amount) {
		this.monthly_payment_amount = monthly_payment_amount;
	}
	
	

}
