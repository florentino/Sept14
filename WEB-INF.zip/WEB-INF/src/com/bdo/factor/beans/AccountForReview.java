package com.bdo.factor.beans;

import java.util.Date;

public class AccountForReview {
	private String clientName;
	private String customerName;
	private String cpsClassification;
	private double investmentLimit;
	private double outstandingAR;
	private String accountOfficer;
	private Date reviewDate;
	private Date currentDate;
	
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String cilentName) {
		this.clientName = cilentName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCpsClassification() {
		return cpsClassification;
	}
	public void setCpsClassification(String cpsClassification) {
		this.cpsClassification = cpsClassification;
	}
	public double getInvestmentLimit() {
		return investmentLimit;
	}
	public void setInvestmentLimit(double investmentLimit) {
		this.investmentLimit = investmentLimit;
	}
	public double getOutstandingAR() {
		return outstandingAR;
	}
	public void setOutstandingAR(double outstandingAR) {
		this.outstandingAR = outstandingAR;
	}
	public String getAccountOfficer() {
		return accountOfficer;
	}
	public void setAccountOfficer(String accountOfficer) {
		this.accountOfficer = accountOfficer;
	}
	public Date getReviewDate() {
		return reviewDate;
	}
	public void setReviewDate(Date reviewDate) {
		this.reviewDate = reviewDate;
	}
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	
	
	
}
