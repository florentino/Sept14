package com.bdo.factor.beans;

public class ExposureByIndustry 
{
	private double balanceOfFIU;
	private double balanceOfReceivables;
	private double balanceOfMTD;
	private double balanceOfYTD;
	private String indCd;
	private String header;
	private String detail;
	public double getBalanceOfFIU() {
		return balanceOfFIU;
	}
	public void setBalanceOfFIU(double balanceOfFIU) {
		this.balanceOfFIU = balanceOfFIU;
	}
	public double getBalanceOfReceivables() {
		return balanceOfReceivables;
	}
	public void setBalanceOfReceivables(double balanceOfReceivables) {
		this.balanceOfReceivables = balanceOfReceivables;
	}
	public double getBalanceOfMTD() {
		return balanceOfMTD;
	}
	public void setBalanceOfMTD(double balanceOfMTD) {
		this.balanceOfMTD = balanceOfMTD;
	}
	public double getBalanceOfYTD() {
		return balanceOfYTD;
	}
	public void setBalanceOfYTD(double balanceOfYTD) {
		this.balanceOfYTD = balanceOfYTD;
	}
	public String getIndCd() {
		return indCd;
	}
	public void setIndCd(String indCd) {
		this.indCd = indCd;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}			
}
