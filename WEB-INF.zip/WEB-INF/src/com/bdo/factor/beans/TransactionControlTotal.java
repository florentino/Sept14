package com.bdo.factor.beans;

public class TransactionControlTotal {
	private int invCount;
	private double invAmount;
	private int invCancelledCount;
	private double invCancelledAmount;
	private int svcChargeCount;
	private double svcChargeAmount;
	private int discChargeCount;
	private double discChargeAmount;
	private int cnCount;
	private double cnAmount;
	private int cnCancelledCount;
	private double cnCancelledAmount;
	private int receiptsChkCount;
	private double receiptsChkAmount;
	private int receiptsCashCount;
	private double receiptsCashAmount;
	private int receiptsCACount;
	private double receiptsCAAmount;
	private int dishonoredCheckCount;
	private double dishonoredCheckAmount;
	private int refund1Count;
	private double refund1Amount;
	private int refund2Count;
	private double refund2Amount;
	private int refund3Count;
	private double refund3Amount;
	private int refund4Count;
	private double refund4Amount;
	private int refundCancelledCount;
	private double refundCancelledAmount;
	private int cashDelayCount;
	private double cashDelayAmount;
	private double advancesAmount;
	private int advancesCount;
	private double advancesSettingUpFee;
	private int advancesSettingUpFeeCount;
	private double cancelledAdvances;
	private int cancelledAdvancesCount;
	private int cancelledReceiptsCACount;
	private int cancelledReceiptsCSHCount;
	private double cancelledReceiptsCA;
	private double cancelledReceiptsCSH;	
	
	public int getCancelledReceiptsCSHCount() {
		return cancelledReceiptsCSHCount;
	}
	public void setCancelledReceiptsCSHCount(int cancelledReceiptsCSHCount) {
		this.cancelledReceiptsCSHCount = cancelledReceiptsCSHCount;
	}	
	
	public double getCancelledReceiptsCA() {
		return cancelledReceiptsCA;
	}
	public void setCancelledReceiptsCA(double cancelledReceiptsCA) {
		this.cancelledReceiptsCA = cancelledReceiptsCA;
	}
	public double getCancelledReceiptsCSH() {
		return cancelledReceiptsCSH;
	}
	public void setCancelledReceiptsCSH(double cancelledReceiptsCSH) {
		this.cancelledReceiptsCSH = cancelledReceiptsCSH;
	}
	public int getInvCount() {
		return invCount;
	}
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	public int getCancelledReceiptsCACount() {
		return cancelledReceiptsCACount;
	}
	public void setCancelledReceiptsCACount(int cancelledReceiptsCACount) {
		this.cancelledReceiptsCACount = cancelledReceiptsCACount;
	}
	public double getInvAmount() {
		return invAmount;
	}
	public void setInvAmount(double invAmount) {
		this.invAmount = invAmount;
	}
	public int getInvCancelledCount() {
		return invCancelledCount;
	}
	public void setInvCancelledCount(int invCancelledCount) {
		this.invCancelledCount = invCancelledCount;
	}
	public double getInvCancelledAmount() {
		return invCancelledAmount;
	}
	public void setInvCancelledAmount(double invCancelledAmount) {
		this.invCancelledAmount = invCancelledAmount;
	}
	public int getSvcChargeCount() {
		return svcChargeCount;
	}
	public void setSvcChargeCount(int svcChargeCount) {
		this.svcChargeCount = svcChargeCount;
	}
	public double getSvcChargeAmount() {
		return svcChargeAmount;
	}
	public void setSvcChargeAmount(double svcChargeAmount) {
		this.svcChargeAmount = svcChargeAmount;
	}
	public int getDiscChargeCount() {
		return discChargeCount;
	}
	public void setDiscChargeCount(int discChargeCount) {
		this.discChargeCount = discChargeCount;
	}
	public double getDiscChargeAmount() {
		return discChargeAmount;
	}
	public void setDiscChargeAmount(double discChargeAmount) {
		this.discChargeAmount = discChargeAmount;
	}
	public int getCnCount() {
		return cnCount;
	}
	public void setCnCount(int cnCount) {
		this.cnCount = cnCount;
	}
	public double getCnAmount() {
		return cnAmount;
	}
	public void setCnAmount(double cnAmount) {
		this.cnAmount = cnAmount;
	}
	public int getCnCancelledCount() {
		return cnCancelledCount;
	}
	public void setCnCancelledCount(int cnCancelledCount) {
		this.cnCancelledCount = cnCancelledCount;
	}
	public double getCnCancelledAmount() {
		return cnCancelledAmount;
	}
	public void setCnCancelledAmount(double cnCancelledAmount) {
		this.cnCancelledAmount = cnCancelledAmount;
	}
	public int getReceiptsChkCount() {
		return receiptsChkCount;
	}
	public void setReceiptsChkCount(int receiptsChkCount) {
		this.receiptsChkCount = receiptsChkCount;
	}
	public double getReceiptsChkAmount() {
		return receiptsChkAmount;
	}
	public void setReceiptsChkAmount(double receiptsChkAmount) {
		this.receiptsChkAmount = receiptsChkAmount;
	}
	public int getReceiptsCashCount() {
		return receiptsCashCount;
	}
	public void setReceiptsCashCount(int receiptsCashCount) {
		this.receiptsCashCount = receiptsCashCount;
	}
	public double getReceiptsCashAmount() {
		return receiptsCashAmount;
	}
	public void setReceiptsCashAmount(double receiptsCashAmount) {
		this.receiptsCashAmount = receiptsCashAmount;
	}
	public int getReceiptsCACount() {
		return receiptsCACount;
	}
	public void setReceiptsCACount(int receiptsCACount) {
		this.receiptsCACount = receiptsCACount;
	}
	public double getReceiptsCAAmount() {
		return receiptsCAAmount;
	}
	public void setReceiptsCAAmount(double receiptsCAAmount) {
		this.receiptsCAAmount = receiptsCAAmount;
	}
	public int getDishonoredCheckCount() {
		return dishonoredCheckCount;
	}
	public void setDishonoredCheckCount(int dishonoredCheckCount) {
		this.dishonoredCheckCount = dishonoredCheckCount;
	}
	public double getDishonoredCheckAmount() {
		return dishonoredCheckAmount;
	}
	public void setDishonoredCheckAmount(double dishonoredCheckAmount) {
		this.dishonoredCheckAmount = dishonoredCheckAmount;
	}
	public int getRefund1Count() {
		return refund1Count;
	}
	public void setRefund1Count(int refund1Count) {
		this.refund1Count = refund1Count;
	}
	public double getRefund1Amount() {
		return refund1Amount;
	}
	public void setRefund1Amount(double refund1Amount) {
		this.refund1Amount = refund1Amount;
	}
	public int getRefund2Count() {
		return refund2Count;
	}
	public void setRefund2Count(int refund2Count) {
		this.refund2Count = refund2Count;
	}
	public double getRefund2Amount() {
		return refund2Amount;
	}
	public void setRefund2Amount(double refund2Amount) {
		this.refund2Amount = refund2Amount;
	}
	public int getRefund3Count() {
		return refund3Count;
	}
	public void setRefund3Count(int refund3Count) {
		this.refund3Count = refund3Count;
	}
	public double getRefund3Amount() {
		return refund3Amount;
	}
	public void setRefund3Amount(double refund3Amount) {
		this.refund3Amount = refund3Amount;
	}
	public int getRefund4Count() {
		return refund4Count;
	}
	public void setRefund4Count(int refund4Count) {
		this.refund4Count = refund4Count;
	}
	public double getRefund4Amount() {
		return refund4Amount;
	}
	public void setRefund4Amount(double refund4Amount) {
		this.refund4Amount = refund4Amount;
	}
	public int getRefundCancelledCount() {
		return refundCancelledCount;
	}
	public void setRefundCancelledCount(int refundCancelledCount) {
		this.refundCancelledCount = refundCancelledCount;
	}
	public double getRefundCancelledAmount() {
		return refundCancelledAmount;
	}
	public void setRefundCancelledAmount(double refundCancelledAmount) {
		this.refundCancelledAmount = refundCancelledAmount;
	}
	public int getCashDelayCount() {
		return cashDelayCount;
	}
	public void setCashDelayCount(int cashDelayCount) {
		this.cashDelayCount = cashDelayCount;
	}
	public double getCashDelayAmount() {
		return cashDelayAmount;
	}
	public void setCashDelayAmount(double cashDelayAmount) {
		this.cashDelayAmount = cashDelayAmount;
	}
	public double getAdvancesAmount() {
		return advancesAmount;
	}
	public void setAdvancesAmount(double advancesAmount) {
		this.advancesAmount = advancesAmount;
	}
	public int getAdvancesCount() {
		return advancesCount;
	}
	public void setAdvancesCount(int advancesCount) {
		this.advancesCount = advancesCount;
	}
	public double getAdvancesSettingUpFee() {
		return advancesSettingUpFee;
	}
	public void setAdvancesSettingUpFee(double advancesSettingUpFee) {
		this.advancesSettingUpFee = advancesSettingUpFee;
	}
	public int getAdvancesSettingUpFeeCount() {
		return advancesSettingUpFeeCount;
	}
	public void setAdvancesSettingUpFeeCount(int advancesSettingUpFeeCount) {
		this.advancesSettingUpFeeCount = advancesSettingUpFeeCount;
	}
	public double getCancelledAdvances() {
		return cancelledAdvances;
	}
	public void setCancelledAdvances(double cancelledAdvances) {
		this.cancelledAdvances = cancelledAdvances;
	}
	public int getCancelledAdvancesCount() {
		return cancelledAdvancesCount;
	}
	public void setCancelledAdvancesCount(int cancelledAdvancesCount) {
		this.cancelledAdvancesCount = cancelledAdvancesCount;
	}
	
	
}
