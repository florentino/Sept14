 package com.bdo.factor.beans;

import java.util.Map;

public class CCLinkClientMaster {

/////////////////////////////////////////////////////////////////////////////////

	
	private String C_BRANCHCODE;
	private String C_CLNTCODE;
	private String C_CUSTCODE;
	private String N_CCLIMIT;
	private String N_CCLIMIT1;
	private String D_CCAPDATE;
	private String D_CCAPDATE1;
	private String D_CCEXDATE;
	private String D_CCEXDATE1;
	private String N_TERM;
	private String B_NLACT;
	private String C_CONTACT;
	private String C_TELNO;   		       		
	private String C_FAXNO;
	private String C_VERIFYEMAIL1; 		       		
	private String C_VERIFYEMAIL2;
	private String C_COLLECTCONTACT;  		       		
	private String C_COLLECTTELNO;
	private String C_COLLECTFAXLNO;  		       		
	private String C_COLLECTEMAIL1;
	private String C_COLLECTEMAIL2;    		       		
	private String D_CREATEDATE;
	private String D_LASTUPDATEDATE;
	
	
/////////////////////////////////////////////////////////////////////////////////	

	public CCLinkClientMaster(){
	}

/////////////////////////////////////////////////////////////////////////////////	
	
	public CCLinkClientMaster(Map map){
		
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BRANCHCODE(map.get("C_BRANCHCODE").toString());
		
		if(map.containsKey("C_CLNTCODE") && map.get("C_CLNTCODE")!=null)
			this.setC_CLNTCODE(map.get("C_CLNTCODE").toString());
		
		if(map.containsKey("C_CUSTCODE") && map.get("C_CUSTCODE")!=null)
			this.setC_CUSTCODE(map.get("C_CUSTCODE").toString());
		
		if(map.containsKey("N_CCLIMIT") && map.get("N_CCLIMIT")!=null)
			this.setN_CCLIMIT(map.get("N_CCLIMIT").toString());
		
		if(map.containsKey("N_CCLIMIT1") && map.get("N_CCLIMIT1")!=null)
			this.setN_CCLIMIT1(map.get("N_CCLIMIT1").toString());
		
		if(map.containsKey("D_CCAPDATE") && map.get("D_CCAPDATE")!=null)
			this.setD_CCAPDATE(map.get("D_CCAPDATE").toString());
		
		if(map.containsKey("D_CCAPDATE1") && map.get("D_CCAPDATE1")!=null)
			this.setD_CCAPDATE1(map.get("D_CCAPDATE1").toString());
		
		if(map.containsKey("D_CCEXDATE") && map.get("D_CCEXDATE")!=null)
			this.setD_CCEXDATE(map.get("D_CCEXDATE").toString());
		
		if(map.containsKey("D_CCEXDATE1") && map.get("D_CCEXDATE1")!=null)
			this.setD_CCEXDATE1(map.get("D_CCEXDATE1").toString());
		
		if(map.containsKey("N_TERM") && map.get("N_TERM")!=null)
			this.setN_TERM(map.get("N_TERM").toString());
		
		if(map.containsKey("B_NLACT") && map.get("B_NLACT")!=null)
			this.setB_NLACT(map.get("B_NLACT").toString());
		
		if(map.containsKey("C_CONTACTVER") && map.get("C_CONTACTVER")!=null)
			this.setC_CONTACT(map.get("C_CONTACTVER").toString());
		
		if(map.containsKey("C_TELNOVER") && map.get("C_TELNOVER")!=null)
			this.setC_TELNO(map.get("C_TELNOVER").toString());
		
		if(map.containsKey("C_FAXNOVER") && map.get("C_FAXNOVER")!=null)
			this.setC_FAXNO(map.get("C_FAXNOVER").toString());
		
		if(map.containsKey("C_VERIFYEMAIL1") && map.get("C_VERIFYEMAIL1")!=null)
			this.setC_VERIFYEMAIL1(map.get("C_VERIFYEMAIL1").toString());
		
		if(map.containsKey("C_VERIFYEMAIL2") && map.get("C_VERIFYEMAIL2")!=null)
			this.setC_VERIFYEMAIL2(map.get("C_VERIFYEMAIL2").toString());
		
		if(map.containsKey("C_COLLECTCONTACT") && map.get("C_COLLECTCONTACT")!=null)
			this.setC_COLLECTCONTACT(map.get("C_COLLECTCONTACT").toString());
		
		if(map.containsKey("C_COLLECTTELNO") && map.get("C_COLLECTTELNO")!=null)
			this.setC_COLLECTTELNO(map.get("C_COLLECTTELNO").toString());
		
		if(map.containsKey("C_COLLECTFAXLNO") && map.get("C_COLLECTFAXLNO")!=null)
			this.setC_COLLECTFAXLNO(map.get("C_COLLECTFAXLNO").toString());
		
		if(map.containsKey("C_COLLECTEMAIL1") && map.get("C_COLLECTEMAIL1")!=null)
			this.setC_COLLECTEMAIL1(map.get("C_COLLECTEMAIL1").toString());
		
		if(map.containsKey("C_COLLECTEMAIL2") && map.get("C_COLLECTEMAIL2")!=null)
			this.setC_COLLECTEMAIL2(map.get("C_COLLECTEMAIL2").toString());

					
	}
/////////////////////////////////////////////////////////////////////////////////

	
	public CCLinkClientMaster(Map map,boolean addFlag){
		
		this.setC_BRANCHCODE(map.get("C_BRANCHCODE").toString());
		this.setC_CLNTCODE(map.get("C_CLNTCODE").toString());
		this.setC_CUSTCODE(map.get("C_CUSTCODE").toString());
		this.setN_CCLIMIT(map.get("N_CCLIMIT").toString());
		this.setN_CCLIMIT1(map.get("N_CCLIMIT1").toString());
		//this.setD_CCAPDATE(map.get("D_CCAPDATE").toString());
		//this.setD_CCAPDATE1(map.get("D_CCAPDATE1").toString());
		//this.setD_CCEXDATE(map.get("D_CCEXDATE").toString());
		//this.setD_CCEXDATE1(map.get("D_CCEXDATE1").toString());
		this.setN_TERM(map.get("N_TERM").toString());
		//this.setB_NLACT(map.get("B_NLACT").toString());
		this.setC_CONTACT(map.get("C_CONTACTVER").toString());
		this.setC_TELNO(map.get("C_TELNOVER").toString());
		this.setC_FAXNO(map.get("C_FAXNOVER").toString());
		this.setC_VERIFYEMAIL1(map.get("C_VERIFYEMAIL1").toString());
		this.setC_VERIFYEMAIL2(map.get("C_VERIFYEMAIL2").toString());
		this.setC_COLLECTCONTACT(map.get("C_COLLECTCONTACT").toString());
		this.setC_COLLECTTELNO(map.get("C_COLLECTTELNO").toString());
		this.setC_COLLECTFAXLNO(map.get("C_COLLECTFAXLNO").toString());
		this.setC_COLLECTEMAIL1(map.get("C_COLLECTEMAIL1").toString());
		this.setC_COLLECTEMAIL2(map.get("C_COLLECTEMAIL2").toString());

					
	}
/////////////////////////////////////////////////////////////////////////////////	
	public String toString() {
		
		StringBuilder strCCLinkClientMaster = new StringBuilder();
		
		strCCLinkClientMaster.append("C_BRANCHCODE=").append(C_BRANCHCODE);
		strCCLinkClientMaster.append(";C_CLNTCODE=").append(C_CLNTCODE);
		strCCLinkClientMaster.append(";C_CUSTCODE=").append(C_CUSTCODE);
		strCCLinkClientMaster.append(";N_CCLIMIT=").append(N_CCLIMIT);
		strCCLinkClientMaster.append(";N_CCLIMIT1=").append(N_CCLIMIT1);
		strCCLinkClientMaster.append(";D_CCAPDATE=").append(D_CCAPDATE);
		strCCLinkClientMaster.append(";D_CCAPDATE1=").append(D_CCAPDATE1);
		strCCLinkClientMaster.append(";D_CCEXDATE=").append(D_CCEXDATE);
		strCCLinkClientMaster.append(";D_CCEXDATE1=").append(D_CCEXDATE1);
		strCCLinkClientMaster.append(";N_TERM=").append(N_TERM);
		strCCLinkClientMaster.append(";B_NLACT=").append(B_NLACT);
		strCCLinkClientMaster.append(";C_CONTACT=").append(C_CONTACT);
		strCCLinkClientMaster.append(";C_TELNO=").append(C_TELNO);
		strCCLinkClientMaster.append(";C_FAXNO=").append(C_FAXNO);
		strCCLinkClientMaster.append(";C_VERIFYEMAIL1=").append(C_VERIFYEMAIL1);
		strCCLinkClientMaster.append(";C_VERIFYEMAIL2=").append(C_VERIFYEMAIL2);
		strCCLinkClientMaster.append(";C_COLLECTCONTACT=").append(C_COLLECTCONTACT);
		strCCLinkClientMaster.append(";C_COLLECTTELNO=").append(C_COLLECTTELNO);
		strCCLinkClientMaster.append(";C_COLLECTFAXLNO=").append(C_COLLECTFAXLNO);
		strCCLinkClientMaster.append(";C_COLLECTEMAIL1=").append(C_COLLECTEMAIL1);
		strCCLinkClientMaster.append(";C_COLLECTEMAIL2=").append(C_COLLECTEMAIL2);
		//strCCLinkClientMaster.append(";D_CREATEDATE=").append(D_CREATEDATE);
		//strCCLinkClientMaster.append(";D_LASTUPDATEDATE=").append(D_LASTUPDATEDATE);

		
		return strCCLinkClientMaster.toString();
	}
	

/////////////////////////////////////////////////////////////////////////////////	
	
	
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}
	public void setC_BRANCHCODE(String c_branchcode) {
		C_BRANCHCODE = c_branchcode;
	}
	public String getC_CLNTCODE() {
		return C_CLNTCODE;
	}
	public void setC_CLNTCODE(String c_clntcode) {
		C_CLNTCODE = c_clntcode;
	}
	public String getC_CUSTCODE() {
		return C_CUSTCODE;
	}
	public void setC_CUSTCODE(String c_custcode) {
		C_CUSTCODE = c_custcode;
	}
	public String getN_CCLIMIT() {
		return N_CCLIMIT;
	}
	public void setN_CCLIMIT(String n_cclimit) {
		N_CCLIMIT = n_cclimit;
	}
	public String getN_CCLIMIT1() {
		return N_CCLIMIT1;
	}
	public void setN_CCLIMIT1(String n_cclimit1) {
		N_CCLIMIT1 = n_cclimit1;
	}
	public String getD_CCAPDATE() {
		return D_CCAPDATE;
	}
	public void setD_CCAPDATE(String d_ccapdate) {
		D_CCAPDATE = d_ccapdate;
	}
	public String getD_CCAPDATE1() {
		return D_CCAPDATE1;
	}
	public void setD_CCAPDATE1(String d_ccapdate1) {
		D_CCAPDATE1 = d_ccapdate1;
	}
	public String getD_CCEXDATE() {
		return D_CCEXDATE;
	}
	public void setD_CCEXDATE(String d_ccexdate) {
		D_CCEXDATE = d_ccexdate;
	}
	public String getD_CCEXDATE1() {
		return D_CCEXDATE1;
	}
	public void setD_CCEXDATE1(String d_ccexdate1) {
		D_CCEXDATE1 = d_ccexdate1;
	}
	public String getN_TERM() {
		return N_TERM;
	}
	public void setN_TERM(String n_term) {
		N_TERM = n_term;
	}
	public String getB_NLACT() {
		return B_NLACT;
	}
	public void setB_NLACT(String b_nlact) {
		B_NLACT = b_nlact;
	}
	public String getC_CONTACT() {
		return C_CONTACT;
	}
	public void setC_CONTACT(String c_contact) {
		C_CONTACT = c_contact;
	}
	public String getC_TELNO() {
		return C_TELNO;
	}
	public void setC_TELNO(String c_telno) {
		C_TELNO = c_telno;
	}
	public String getC_FAXNO() {
		return C_FAXNO;
	}
	public void setC_FAXNO(String c_faxno) {
		C_FAXNO = c_faxno;
	}
	public String getC_VERIFYEMAIL1() {
		return C_VERIFYEMAIL1;
	}
	public void setC_VERIFYEMAIL1(String c_verifyemail1) {
		C_VERIFYEMAIL1 = c_verifyemail1;
	}
	public String getC_VERIFYEMAIL2() {
		return C_VERIFYEMAIL2;
	}
	public void setC_VERIFYEMAIL2(String c_verifyemail2) {
		C_VERIFYEMAIL2 = c_verifyemail2;
	}
	public String getC_COLLECTCONTACT() {
		return C_COLLECTCONTACT;
	}
	public void setC_COLLECTCONTACT(String c_collectcontact) {
		C_COLLECTCONTACT = c_collectcontact;
	}
	public String getC_COLLECTTELNO() {
		return C_COLLECTTELNO;
	}
	public void setC_COLLECTTELNO(String c_collecttelno) {
		C_COLLECTTELNO = c_collecttelno;
	}
	public String getC_COLLECTFAXLNO() {
		return C_COLLECTFAXLNO;
	}
	public void setC_COLLECTFAXLNO(String c_collectfaxlno) {
		C_COLLECTFAXLNO = c_collectfaxlno;
	}
	public String getC_COLLECTEMAIL1() {
		return C_COLLECTEMAIL1;
	}
	public void setC_COLLECTEMAIL1(String c_collectemail1) {
		C_COLLECTEMAIL1 = c_collectemail1;
	}
	public String getC_COLLECTEMAIL2() {
		return C_COLLECTEMAIL2;
	}
	public void setC_COLLECTEMAIL2(String c_collectemail2) {
		C_COLLECTEMAIL2 = c_collectemail2;
	}
	public String getD_CREATEDATE() {
		return D_CREATEDATE;
	}
	public void setD_CREATEDATE(String d_createdate) {
		D_CREATEDATE = d_createdate;
	}
	public String getD_LASTUPDATEDATE() {
		return D_LASTUPDATEDATE;
	}
	public void setD_LASTUPDATEDATE(String d_lastupdatedate) {
		D_LASTUPDATEDATE = d_lastupdatedate;
	}   


/////////////////////////////////////////////////////////////////////////////////	

	
	
}
