package com.bdo.factor.beans;

public class LDAPSConfiguration {
	private String WebServiceURL;
	private String app_user;
	private String app_password;
	private String Username;
	private String Hostname;
	private Boolean BypassSSL;
	private String EncryptionKey;
	private Boolean EnableLDAPS;
	private String AppEncryptionKey;
	private String AppKeySpecs;
	private String AppAlgorithm;
	private String KeySpecs;
	private String Algorithm;
	
	public String getAppEncryptionKey() {
		return AppEncryptionKey;
	}
	public void setAppEncryptionKey(String appEncryptionKey) {
		AppEncryptionKey = appEncryptionKey;
	}
	public String getAppKeySpecs() {
		return AppKeySpecs;
	}
	public void setAppKeySpecs(String appKeySpecs) {
		AppKeySpecs = appKeySpecs;
	}
	public String getAppAlgorithm() {
		return AppAlgorithm;
	}
	public void setAppAlgorithm(String appAlgorithm) {
		AppAlgorithm = appAlgorithm;
	}
	public String getKeySpecs() {
		return KeySpecs;
	}
	public void setKeySpecs(String keySpecs) {
		KeySpecs = keySpecs;
	}
	public String getAlgorithm() {
		return Algorithm;
	}
	public void setAlgorithm(String algorithm) {
		Algorithm = algorithm;
	}
	public String getWebServiceURL() {
		return WebServiceURL;
	}
	public void setWebServiceURL(String webServiceURL) {
		WebServiceURL = webServiceURL;
	}
	public String getApp_user() {
		return app_user;
	}
	public void setApp_user(String app_user) {
		this.app_user = app_user;
	}
	public String getApp_password() {
		return app_password;
	}
	public void setApp_password(String app_password) {
		this.app_password = app_password;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getHostname() {
		return Hostname;
	}
	public void setHostname(String hostname) {
		Hostname = hostname;
	}
	public Boolean getBypassSSL() {
		return BypassSSL;
	}
	public void setBypassSSL(Boolean bypassSSL) {
		BypassSSL = bypassSSL;
	}
	public String getEncryptionKey() {
		return EncryptionKey;
	}
	public void setEncryptionKey(String encryptionKey) {
		EncryptionKey = encryptionKey;
	}
	public Boolean getEnableLDAPS() {
		return EnableLDAPS;
	}
	public void setEnableLDAPS(Boolean enableLDAPS) {
		EnableLDAPS = enableLDAPS;
	}
}
