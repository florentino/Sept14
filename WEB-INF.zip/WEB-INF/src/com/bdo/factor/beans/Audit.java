package com.bdo.factor.beans;

public class Audit {
	private long auditID;
	private String userID;
	private String type;
	private String tableName;
	private String newValue;
	private java.util.Date updateDate;
	
	public long getAuditID() {
		return auditID;
	}
	public void setAuditID(long auditID) {
		this.auditID = auditID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
	public java.util.Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(java.util.Date updateDate) {
		this.updateDate = updateDate;
	}
	
	public String toString(){
		StringBuilder str = new StringBuilder();
		str.append("AUDITID=").append(auditID);
		str.append(";USERID=").append(userID);
		str.append(";TYPE=").append(type);
		str.append(";TABLENAME=").append(tableName);
		str.append(";NEWVALUE=").append(newValue);
		str.append(";UPDATEDATE=").append(updateDate);
		
		return str.toString();
	}
}
