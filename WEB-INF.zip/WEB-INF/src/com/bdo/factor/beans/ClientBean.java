package com.bdo.factor.beans;

import java.util.Date;
import java.util.Date;

public class ClientBean {
	private String C_BRANCHCODE;	 
	private long C_CLNTCODE;	 
	private String C_NAME;	 
	private String C_TELNO;	 
	private String C_GROUPCODE;	 
	private String C_ADDRESS;
	private String C_CONTACT;
	private String C_BLRTYPECODE;
	private double N_DCR;
	private double N_SCR;
	private String C_BNKACTNO;
	private String C_BANKCODE;
	private double N_CREDITLIMIT;
	private String C_ACCTOFFICERCODE;
	private String C_SERVICEOFFICERCODE;
	private double N_CREDAVAIL;
	private double N_FIU;
	private double N_FIUTRAN;
	private double N_RECEIVABLES;
	private double N_INELIGIBLEREC;
	private double N_INELIGIBLEADV;
	private double N_INELIGIBLEREF;
	private double N_FORCLEARING;
	private double N_RESERVES;
	private String C_BREGNO;
	private String C_CURRENCYCODE;
	private Date D_DATECREATE;
	private Date D_LASTUPDATE;
	private byte B_ACBANK;
	private double N_SETTLEMENT;
	private String C_INDUSTRYCODE;
	private double N_INVESTMENTLIMIT;
	private Date D_EFFDATE;
	private double N_HCR;
	private String N_TEL;
	private double N_ADVANCEDRATIO;
	private Date D_LASTADVDATE;
	private String C_RESTRCTDACCT;
	private String C_TIN;
	private double N_EFFYIELD;
	private String C_BNKACTNOUSD;
	private String C_BANKCODEUSD;
	private Date D_CPDATE;
	private Date D_REVIEWDATE;
	private Date D_CLIENTSINCE;
	private Date D_AUDITEDDATE;
	private Date D_INHOUSEDATE;
	private String C_RESTRCTDACCTUSD;
	private String C_BORWTYPE;
	private String C_BORWCODE;
	private String CreditRiskCd;
	private String IndCd;
	private byte C_STATUS;
	private Date D_BUSINESSDATEOFBIRTH;
	private String C_CLIENTCLASSIFICATION;
	private String C_SOURCEOFFUND;
	private String C_NATUREOFWORK;
	private String C_DIRECTORS;
	private double N_LIABILITIES;
	private double N_EQUITY;
	private double N_GROSSINCOME;
	private double N_EXPENSES;
	private double N_NETINCOME;
	private double N_ASSETS;
	private String C_DOSRI;
	private double N_NOTARIAL;
	private int N_EXTENSION;
	public String getC_BRANCHCODE() {
		return C_BRANCHCODE;
	}
	public void setC_BRANCHCODE(String c_BRANCHCODE) {
		C_BRANCHCODE = c_BRANCHCODE;
	}
	public long getC_CLNTCODE() {
		return C_CLNTCODE;
	}
	public void setC_CLNTCODE(long c_CLNTCODE) {
		C_CLNTCODE = c_CLNTCODE;
	}
	public String getC_NAME() {
		return C_NAME;
	}
	public void setC_NAME(String c_NAME) {
		C_NAME = c_NAME;
	}
	public String getC_TELNO() {
		return C_TELNO;
	}
	public void setC_TELNO(String c_TELNO) {
		C_TELNO = c_TELNO;
	}
	public String getC_GROUPCODE() {
		return C_GROUPCODE;
	}
	public void setC_GROUPCODE(String c_GROUPCODE) {
		C_GROUPCODE = c_GROUPCODE;
	}
	public String getC_ADDRESS() {
		return C_ADDRESS;
	}
	public void setC_ADDRESS(String c_ADDRESS) {
		C_ADDRESS = c_ADDRESS;
	}
	public String getC_CONTACT() {
		return C_CONTACT;
	}
	public void setC_CONTACT(String c_CONTACT) {
		C_CONTACT = c_CONTACT;
	}
	public String getC_BLRTYPECODE() {
		return C_BLRTYPECODE;
	}
	public void setC_BLRTYPECODE(String c_BLRTYPECODE) {
		C_BLRTYPECODE = c_BLRTYPECODE;
	}
	public double getN_DCR() {
		return N_DCR;
	}
	public void setN_DCR(double n_DCR) {
		N_DCR = n_DCR;
	}
	public double getN_SCR() {
		return N_SCR;
	}
	public void setN_SCR(double n_SCR) {
		N_SCR = n_SCR;
	}
	public String getC_BNKACTNO() {
		return C_BNKACTNO;
	}
	public void setC_BNKACTNO(String c_BNKACTNO) {
		C_BNKACTNO = c_BNKACTNO;
	}
	public String getC_BANKCODE() {
		return C_BANKCODE;
	}
	public void setC_BANKCODE(String c_BANKCODE) {
		C_BANKCODE = c_BANKCODE;
	}
	public double getN_CREDITLIMIT() {
		return N_CREDITLIMIT;
	}
	public void setN_CREDITLIMIT(double n_CREDITLIMIT) {
		N_CREDITLIMIT = n_CREDITLIMIT;
	}
	public String getC_ACCTOFFICERCODE() {
		return C_ACCTOFFICERCODE;
	}
	public void setC_ACCTOFFICERCODE(String c_ACCTOFFICERCODE) {
		C_ACCTOFFICERCODE = c_ACCTOFFICERCODE;
	}
	public String getC_SERVICEOFFICERCODE() {
		return C_SERVICEOFFICERCODE;
	}
	public void setC_SERVICEOFFICERCODE(String c_SERVICEOFFICERCODE) {
		C_SERVICEOFFICERCODE = c_SERVICEOFFICERCODE;
	}
	public double getN_CREDAVAIL() {
		return N_CREDAVAIL;
	}
	public void setN_CREDAVAIL(double n_CREDAVAIL) {
		N_CREDAVAIL = n_CREDAVAIL;
	}
	public double getN_FIU() {
		return N_FIU;
	}
	public void setN_FIU(double n_FIU) {
		N_FIU = n_FIU;
	}
	public double getN_FIUTRAN() {
		return N_FIUTRAN;
	}
	public void setN_FIUTRAN(double n_FIUTRAN) {
		N_FIUTRAN = n_FIUTRAN;
	}
	public double getN_RECEIVABLES() {
		return N_RECEIVABLES;
	}
	public void setN_RECEIVABLES(double n_RECEIVABLES) {
		N_RECEIVABLES = n_RECEIVABLES;
	}
	public double getN_INELIGIBLEREC() {
		return N_INELIGIBLEREC;
	}
	public void setN_INELIGIBLEREC(double n_INELIGIBLEREC) {
		N_INELIGIBLEREC = n_INELIGIBLEREC;
	}
	public double getN_INELIGIBLEADV() {
		return N_INELIGIBLEADV;
	}
	public void setN_INELIGIBLEADV(double n_INELIGIBLEADV) {
		N_INELIGIBLEADV = n_INELIGIBLEADV;
	}
	public double getN_INELIGIBLEREF() {
		return N_INELIGIBLEREF;
	}
	public void setN_INELIGIBLEREF(double n_INELIGIBLEREF) {
		N_INELIGIBLEREF = n_INELIGIBLEREF;
	}
	public double getN_FORCLEARING() {
		return N_FORCLEARING;
	}
	public void setN_FORCLEARING(double n_FORCLEARING) {
		N_FORCLEARING = n_FORCLEARING;
	}
	public double getN_RESERVES() {
		return N_RESERVES;
	}
	public void setN_RESERVES(double n_RESERVES) {
		N_RESERVES = n_RESERVES;
	}
	public String getC_BREGNO() {
		return C_BREGNO;
	}
	public void setC_BREGNO(String c_BREGNO) {
		C_BREGNO = c_BREGNO;
	}
	public String getC_CURRENCYCODE() {
		return C_CURRENCYCODE;
	}
	public void setC_CURRENCYCODE(String c_CURRENCYCODE) {
		C_CURRENCYCODE = c_CURRENCYCODE;
	}
	public Date getD_DATECREATE() {
		return D_DATECREATE;
	}
	public void setD_DATECREATE(Date d_DATECREATE) {
		D_DATECREATE = d_DATECREATE;
	}
	public Date getD_LASTUPDATE() {
		return D_LASTUPDATE;
	}
	public void setD_LASTUPDATE(Date d_LASTUPDATE) {
		D_LASTUPDATE = d_LASTUPDATE;
	}
	public byte getB_ACBANK() {
		return B_ACBANK;
	}
	public void setB_ACBANK(byte b_ACBANK) {
		B_ACBANK = b_ACBANK;
	}
	public double getN_SETTLEMENT() {
		return N_SETTLEMENT;
	}
	public void setN_SETTLEMENT(double n_SETTLEMENT) {
		N_SETTLEMENT = n_SETTLEMENT;
	}
	public String getC_INDUSTRYCODE() {
		return C_INDUSTRYCODE;
	}
	public void setC_INDUSTRYCODE(String c_INDUSTRYCODE) {
		C_INDUSTRYCODE = c_INDUSTRYCODE;
	}
	public double getN_INVESTMENTLIMIT() {
		return N_INVESTMENTLIMIT;
	}
	public void setN_INVESTMENTLIMIT(double n_INVESTMENTLIMIT) {
		N_INVESTMENTLIMIT = n_INVESTMENTLIMIT;
	}
	public Date getD_EFFDATE() {
		return D_EFFDATE;
	}
	public void setD_EFFDATE(Date d_EFFDATE) {
		D_EFFDATE = d_EFFDATE;
	}
	public double getN_HCR() {
		return N_HCR;
	}
	public void setN_HCR(double n_HCR) {
		N_HCR = n_HCR;
	}
	public String getN_TEL() {
		return N_TEL;
	}
	public void setN_TEL(String n_TEL) {
		N_TEL = n_TEL;
	}
	public double getN_ADVANCEDRATIO() {
		return N_ADVANCEDRATIO;
	}
	public void setN_ADVANCEDRATIO(double n_ADVANCEDRATIO) {
		N_ADVANCEDRATIO = n_ADVANCEDRATIO;
	}
	public Date getD_LASTADVDATE() {
		return D_LASTADVDATE;
	}
	public void setD_LASTADVDATE(Date d_LASTADVDATE) {
		D_LASTADVDATE = d_LASTADVDATE;
	}
	public String getC_RESTRCTDACCT() {
		return C_RESTRCTDACCT;
	}
	public void setC_RESTRCTDACCT(String c_RESTRCTDACCT) {
		C_RESTRCTDACCT = c_RESTRCTDACCT;
	}
	public String getC_TIN() {
		return C_TIN;
	}
	public void setC_TIN(String c_TIN) {
		C_TIN = c_TIN;
	}
	public double getN_EFFYIELD() {
		return N_EFFYIELD;
	}
	public void setN_EFFYIELD(double n_EFFYIELD) {
		N_EFFYIELD = n_EFFYIELD;
	}
	public String getC_BNKACTNOUSD() {
		return C_BNKACTNOUSD;
	}
	public void setC_BNKACTNOUSD(String c_BNKACTNOUSD) {
		C_BNKACTNOUSD = c_BNKACTNOUSD;
	}
	public String getC_BANKCODEUSD() {
		return C_BANKCODEUSD;
	}
	public void setC_BANKCODEUSD(String c_BANKCODEUSD) {
		C_BANKCODEUSD = c_BANKCODEUSD;
	}
	public Date getD_CPDATE() {
		return D_CPDATE;
	}
	public void setD_CPDATE(Date d_CPDATE) {
		D_CPDATE = d_CPDATE;
	}
	public Date getD_REVIEWDATE() {
		return D_REVIEWDATE;
	}
	public void setD_REVIEWDATE(Date d_REVIEWDATE) {
		D_REVIEWDATE = d_REVIEWDATE;
	}
	public Date getD_CLIENTSINCE() {
		return D_CLIENTSINCE;
	}
	public void setD_CLIENTSINCE(Date d_CLIENTSINCE) {
		D_CLIENTSINCE = d_CLIENTSINCE;
	}
	public Date getD_AUDITEDDATE() {
		return D_AUDITEDDATE;
	}
	public void setD_AUDITEDDATE(Date d_AUDITEDDATE) {
		D_AUDITEDDATE = d_AUDITEDDATE;
	}
	public Date getD_INHOUSEDATE() {
		return D_INHOUSEDATE;
	}
	public void setD_INHOUSEDATE(Date d_INHOUSEDATE) {
		D_INHOUSEDATE = d_INHOUSEDATE;
	}
	public String getC_RESTRCTDACCTUSD() {
		return C_RESTRCTDACCTUSD;
	}
	public void setC_RESTRCTDACCTUSD(String c_RESTRCTDACCTUSD) {
		C_RESTRCTDACCTUSD = c_RESTRCTDACCTUSD;
	}
	public String getC_BORWTYPE() {
		return C_BORWTYPE;
	}
	public void setC_BORWTYPE(String c_BORWTYPE) {
		C_BORWTYPE = c_BORWTYPE;
	}
	public String getC_BORWCODE() {
		return C_BORWCODE;
	}
	public void setC_BORWCODE(String c_BORWCODE) {
		C_BORWCODE = c_BORWCODE;
	}
	public String getCreditRiskCd() {
		return CreditRiskCd;
	}
	public void setCreditRiskCd(String creditRiskCd) {
		CreditRiskCd = creditRiskCd;
	}
	public String getIndCd() {
		return IndCd;
	}
	public void setIndCd(String indCd) {
		IndCd = indCd;
	}
	public byte getC_STATUS() {
		return C_STATUS;
	}
	public void setC_STATUS(byte c_STATUS) {
		C_STATUS = c_STATUS;
	}
	public Date getD_BUSINESSDATEOFBIRTH() {
		return D_BUSINESSDATEOFBIRTH;
	}
	public void setD_BUSINESSDATEOFBIRTH(Date d_BUSINESSDATEOFBIRTH) {
		D_BUSINESSDATEOFBIRTH = d_BUSINESSDATEOFBIRTH;
	}
	public String getC_CLIENTCLASSIFICATION() {
		return C_CLIENTCLASSIFICATION;
	}
	public void setC_CLIENTCLASSIFICATION(String c_CLIENTCLASSIFICATION) {
		C_CLIENTCLASSIFICATION = c_CLIENTCLASSIFICATION;
	}
	public String getC_SOURCEOFFUND() {
		return C_SOURCEOFFUND;
	}
	public void setC_SOURCEOFFUND(String c_SOURCEOFFUND) {
		C_SOURCEOFFUND = c_SOURCEOFFUND;
	}
	public String getC_NATUREOFWORK() {
		return C_NATUREOFWORK;
	}
	public void setC_NATUREOFWORK(String c_NATUREOFWORK) {
		C_NATUREOFWORK = c_NATUREOFWORK;
	}
	public String getC_DIRECTORS() {
		return C_DIRECTORS;
	}
	public void setC_DIRECTORS(String c_DIRECTORS) {
		C_DIRECTORS = c_DIRECTORS;
	}
	public double getN_LIABILITIES() {
		return N_LIABILITIES;
	}
	public void setN_LIABILITIES(double n_LIABILITIES) {
		N_LIABILITIES = n_LIABILITIES;
	}
	public double getN_EQUITY() {
		return N_EQUITY;
	}
	public void setN_EQUITY(double n_EQUITY) {
		N_EQUITY = n_EQUITY;
	}
	public double getN_GROSSINCOME() {
		return N_GROSSINCOME;
	}
	public void setN_GROSSINCOME(double n_GROSSINCOME) {
		N_GROSSINCOME = n_GROSSINCOME;
	}
	public double getN_EXPENSES() {
		return N_EXPENSES;
	}
	public void setN_EXPENSES(double n_EXPENSES) {
		N_EXPENSES = n_EXPENSES;
	}
	public double getN_NETINCOME() {
		return N_NETINCOME;
	}
	public void setN_NETINCOME(double n_NETINCOME) {
		N_NETINCOME = n_NETINCOME;
	}
	public double getN_ASSETS() {
		return N_ASSETS;
	}
	public void setN_ASSETS(double n_ASSETS) {
		N_ASSETS = n_ASSETS;
	}
	public String getC_DOSRI() {
		return C_DOSRI;
	}
	public void setC_DOSRI(String c_DOSRI) {
		C_DOSRI = c_DOSRI;
	}
	public double getN_NOTARIAL() {
		return N_NOTARIAL;
	}
	public void setN_NOTARIAL(double n_NOTARIAL) {
		N_NOTARIAL = n_NOTARIAL;
	}
	public int getN_EXTENSION() {
		return N_EXTENSION;
	}
	public void setN_EXTENSION(int n_EXTENSION) {
		N_EXTENSION = n_EXTENSION;
	}


}
