package com.bdo.factor.beans;

public class CISALink {
	private int link_betSubCustTemp_id;
	private String provider_subject_no_parent;
	private String role_of_parent;
	private String provider_subject_no_child;
	private String text_log;
	private String source_data= "Factors";
	public int getLink_betSubCustTemp_id() {
		return link_betSubCustTemp_id;
	}
	public void setLink_betSubCustTemp_id(int link_betSubCustTemp_id) {
		this.link_betSubCustTemp_id = link_betSubCustTemp_id;
	}
	public String getProvider_subject_no_parent() {
		return provider_subject_no_parent;
	}
	public void setProvider_subject_no_parent(String provider_subject_no_parent) {
		this.provider_subject_no_parent = provider_subject_no_parent;
	}
	public String getRole_of_parent() {
		return role_of_parent;
	}
	public void setRole_of_parent(String role_of_parent) {
		this.role_of_parent = role_of_parent;
	}
	public String getProvider_subject_no_child() {
		return provider_subject_no_child;
	}
	public void setProvider_subject_no_child(String provider_subject_no_child) {
		this.provider_subject_no_child = provider_subject_no_child;
	}
	public String getText_log() {
		return text_log;
	}
	public void setText_log(String text_log) {
		this.text_log = text_log;
	}
	public String getSource_data() {
		return source_data;
	}
	public void setSource_data(String source_data) {
		this.source_data = source_data;
	}
}
