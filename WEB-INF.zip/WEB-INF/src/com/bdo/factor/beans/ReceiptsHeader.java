package com.bdo.factor.beans;

import java.util.Map;

import com.bdo.factor.util.DateHelper;

public class ReceiptsHeader {
	private String c_BranchCode;
	private int n_RefNo;
	private java.util.Date d_TransactionDate;
	private long c_ClntCode;
	private long c_CustCode;
	private java.util.Date d_CheckDate;
	private String c_CheckNo;
	private String c_BankCode;
	private double n_Amount;
	private double n_OrigAmount;
	private String c_CurrencyCode;
	private double n_ExchangeRate;
	private double n_CashDelay;
	private String c_Status;
	private String c_CheckType;
	private java.util.Date d_ClearingDate;
	private String c_ReceiptType;
	private String c_Ams;
	private String b_FromPDC;
	private int n_RefundDays;
	
	public ReceiptsHeader(){
	}
	
	public ReceiptsHeader(Map map){

		if(map.containsKey("N_REFNO") && map.get("N_REFNO")!=null)
			this.setN_RefNo(new Integer(map.get("N_REFNO").toString()));
		
		if(map.containsKey("C_BRANCHCODE") && map.get("C_BRANCHCODE")!=null)
			this.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		
		if(map.containsKey("C_AMS") && map.get("C_AMS")!=null)
			this.setC_Ams((String) map.get("C_AMS"));
		
		if(map.containsKey("C_BANKCODE") && map.get("C_BANKCODE")!=null)
			this.setC_BankCode((String) map.get("C_BANKCODE"));
		
		if(map.containsKey("C_CHECKNO") && map.get("C_CHECKNO")!=null)
			this.setC_CheckNo((String) map.get("C_CHECKNO"));
		
		if(map.containsKey("C_CHECKTYPE") && map.get("C_CHECKTYPE")!=null)
			this.setC_CheckType((String) map.get("C_CHECKTYPE"));
		
		if(map.containsKey("C_CLNTCODE") && map.get("C_CLNTCODE")!=null)
			this.setC_ClntCode(Long.parseLong(map.get("C_CLNTCODE").toString()));
		
		if(map.containsKey("C_RECEIPTTYPEVAL") && map.get("C_RECEIPTTYPEVAL")!=null)
			this.setC_ReceiptType((String) map.get("C_RECEIPTTYPEVAL"));
		
		if(map.containsKey("C_CUSTCODE") && map.get("C_CUSTCODE")!=null)
			this.setC_CustCode(Long.parseLong(map.get("C_CUSTCODE").toString()));
		
		if(map.containsKey("C_STATUS") && map.get("C_STATUS")!=null)
			this.setC_Status((String) map.get("C_STATUS"));
		
		if(map.containsKey("B_FROMPDC") && map.get("B_FROMPDC")!=null)
			this.setB_FromPDC((String) map.get("B_FROMPDC"));
		
		if(map.containsKey("D_CHECKDATE") && map.get("D_CHECKDATE")!=null)
			this.setD_CheckDate(DateHelper.parse((String) map.get("D_CHECKDATE")));
		
		if(map.containsKey("D_CLEARINGDATE") && map.get("D_CLEARINGDATE")!=null)
			this.setD_ClearingDate(DateHelper.parse((String) map.get("D_CLEARINGDATE")));
		
		if(map.containsKey("D_TRANSACTIONDATE") && map.get("D_TRANSACTIONDATE")!=null)
			this.setD_TransactionDate(DateHelper.parse((String) map.get("D_TRANSACTIONDATE")));
		
		
		if(map.containsKey("N_AMOUNT") && map.get("N_AMOUNT")!=null)
			this.setN_Amount(Double.parseDouble(map.get("N_AMOUNT").toString().replaceAll(",", "")));		
		
		if(map.containsKey("N_ORIGAMOUNT") && map.get("N_ORIGAMOUNT")!=null)
			this.setN_OrigAmount(map.get("N_ORIGAMOUNT") != null ? Double.parseDouble(map.get("N_ORIGAMOUNT").toString().replaceAll(",", "")) : 0);
		
		if(map.containsKey("C_CURRENCYCODE") && map.get("C_CURRENCYCODE")!=null)
			this.setC_CurrencyCode(map.get("C_CURRENCYCODE") != null ? map.get("N_ORIGAMOUNT").toString() : null);
		
		if(map.containsKey("N_EXCHANGERATE") && map.get("N_EXCHANGERATE")!=null)
			this.setN_ExchangeRate(map.get("N_EXCHANGERATE") != null ? Double.parseDouble(map.get("N_EXCHANGERATE").toString()) : 0);		
		
		if(map.containsKey("C_NOOFDAYS") && map.get("C_NOOFDAYS")!=null)
			this.setN_CashDelay(Double.parseDouble(map.get("C_NOOFDAYS").toString()));
		
		if(map.containsKey("N_REFUNDDAYS") && map.get("N_REFUNDDAYS")!=null)
			this.setN_RefundDays(map.get("N_REFUNDDAYS") != null && map.get("N_REFUNDDAYS").toString().trim() != "" ? Integer.parseInt(map.get("N_REFUNDDAYS").toString()): 0);
	}
	
		
	public int getN_RefundDays() {
		return n_RefundDays;
	}
	public void setN_RefundDays(int refundDays) {
		n_RefundDays = refundDays;
	}
	public String getB_FromPDC() {
		return b_FromPDC;
	}
	public void setB_FromPDC(String fromPDC) {
		b_FromPDC = fromPDC;
	}
	public String getC_BranchCode() {
		return c_BranchCode;
	}
	public void setC_BranchCode(String branchCode) {
		c_BranchCode = branchCode;
	}
	public int getN_RefNo() {
		return n_RefNo;
	}
	public void setN_RefNo(int refNo) {
		n_RefNo = refNo;
	}
	public java.util.Date getD_TransactionDate() {
		return d_TransactionDate;
	}
	public void setD_TransactionDate(java.util.Date transactionDate) {
		d_TransactionDate = transactionDate;
	}
	public long getC_ClntCode() {
		return c_ClntCode;
	}
	public void setC_ClntCode(long clntCode) {
		c_ClntCode = clntCode;
	}
	public long getC_CustCode() {
		return c_CustCode;
	}
	public void setC_CustCode(long custCode) {
		c_CustCode = custCode;
	}
	public java.util.Date getD_CheckDate() {
		return d_CheckDate;
	}
	public void setD_CheckDate(java.util.Date checkDate) {
		d_CheckDate = checkDate;
	}
	public String getC_CheckNo() {
		return c_CheckNo;
	}
	public void setC_CheckNo(String checkNo) {
		c_CheckNo = checkNo;
	}
	public String getC_BankCode() {
		return c_BankCode;
	}
	public void setC_BankCode(String bankCode) {
		c_BankCode = bankCode;
	}
	public double getN_Amount() {
		return n_Amount;
	}
	public void setN_Amount(double amount) {
		n_Amount = amount;
	}
	public double getN_CashDelay() {
		return n_CashDelay;
	}
	public void setN_CashDelay(double cashDelay) {
		n_CashDelay = cashDelay;
	}
	public String getC_Status() {
		return c_Status;
	}
	public void setC_Status(String status) {
		c_Status = status;
	}
	public String getC_CheckType() {
		return c_CheckType;
	}
	public void setC_CheckType(String checkType) {
		c_CheckType = checkType;
	}
	public java.util.Date getD_ClearingDate() {
		return d_ClearingDate;
	}
	public void setD_ClearingDate(java.util.Date clearingDate) {
		d_ClearingDate = clearingDate;
	}
		
	public String getC_ReceiptType() {
		return c_ReceiptType;
	}
	public void setC_ReceiptType(String receiptType) {
		c_ReceiptType = receiptType;
	}
	public String getC_Ams() {
		return c_Ams;
	}
	public void setC_Ams(String ams) {
		c_Ams = ams;
	}	
	public double getN_OrigAmount() {
		return n_OrigAmount;
	}
	public void setN_OrigAmount(double origAmount) {
		n_OrigAmount = origAmount;
	}
	public String getC_CurrencyCode() {
		return c_CurrencyCode;
	}
	public void setC_CurrencyCode(String currencyCode) {
		c_CurrencyCode = currencyCode;
	}
	public double getN_ExchangeRate() {
		return n_ExchangeRate;
	}
	public void setN_ExchangeRate(double exchangeRate) {
		n_ExchangeRate = exchangeRate;
	}
	
	public String toString(){
		StringBuffer str = new StringBuffer();
		str.append("C_BRANCHCODE=").append(c_BranchCode);
		str.append(";N_REFNO=").append(n_RefNo);
		str.append(";D_TRANSACTIONDATE=").append(DateHelper.format(d_TransactionDate));
		str.append(";C_CLNTCODE=").append(c_ClntCode);
		str.append(";C_CUSTCODE=").append(c_CustCode);
		str.append(";D_CHECKDATE=").append(DateHelper.format(d_CheckDate));
		str.append(";C_CHECKNO=").append(c_CheckNo);
		str.append(";C_BANKCODE=").append(c_BankCode);
		str.append(";N_AMOUNT=").append(n_Amount);
		str.append(";N_ORIGAMOUNT=").append(n_OrigAmount);
		str.append(";C_CURRENCYCODE=").append(c_CurrencyCode);
		str.append(";N_EXCHANGERATE=").append(n_ExchangeRate);		
		str.append(";N_CASHDELAY=").append(n_CashDelay);
		str.append(";C_STATUS=").append(c_Status);
		str.append(";C_CHECKTYPE=").append(c_CheckType);
		str.append(";D_CLEARINGDATE=").append(DateHelper.format(d_ClearingDate));
		str.append(";C_RECEIPTTYPE=").append(c_ReceiptType);
		str.append(";C_AMS=").append(c_Ams);
		str.append(";N_REFUNDDAYS=").append(n_RefundDays);
		
		return str.toString();
	}
	
}
