package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.LDAPSConfiguration;
import com.bdo.factor.beans.SystemSettings;
import com.bdo.factor.beans.User;
import com.bdo.factor.dao.CISADAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.SystemSettingsDAO;
import com.bdo.factor.dao.UserDAO;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;
import com.bdo.factor.util.EncryptorUtil;
import com.bdo.factor.util.Validator;
import com.bdo.factor.service.SecurityService;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class UserService {
	private static Logger log = Logger.getLogger(UserService.class);
	//private static java.util.ResourceBundle rb = java.util.ResourceBundle.getBundle("_properties/fileLocation");
	SecurityService rb = SecurityService.getInstance();
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static UserService userServiceInstance = new UserService();
	
	public UserService() { }

	public static UserService getInstance() {
		return userServiceInstance;
	}
		
/////////////////////////////1/////////////////////////////////////////////////////////////////
	
	public User searchUser(String c_UserID, String c_PassW) {
		User u = null;		
		try {
			EncryptorUtil encryptor = new EncryptorUtil();
			UserDAO userDAO = (UserDAO) Persistence.getDAO("UserDAO");			
			System.out.println("userDAO" + userDAO);
			u = userDAO.searchUser(c_UserID, encryptor.getEncryptedPassword(c_PassW));			
		}
		catch (Throwable x) {

		}
		return u;
	}
	
	
	@SuppressWarnings("unchecked")
	public Map changeUserPass(Map user)
	{
		Map jsondata = new HashMap();		
		//Stack<String> passwordHistory = new Stack<String>();
		ServiceUtility.viewUserParameters(user);
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		EncryptorUtil encryptor = new EncryptorUtil();
		Validator validator = new Validator();
		
		if (user.get("c_PassW")==null){
			jsondata.put("status", "Current Password Empty");
			return jsondata;
		}
		if (user.get("oldPass")==null){
			jsondata.put("status", "Old Password Empty");
			return jsondata;
		}
		if (user.get("c_UserID")==null){
			jsondata.put("status", "User Id Empty");
			return jsondata;
		}
		if (user.get("con_passW")==null){
			jsondata.put("status", "Confirmation Password Empty");
			return jsondata;
		}
		
		String c_PassW  = user.get("c_PassW").toString().trim();
		String oldPass  = user.get("oldPass").toString().trim();
		String c_UserID = user.get("c_UserID").toString().trim();
		String con_passW  = user.get("con_passW").toString();
		
		boolean activation = (user.get("activation")!=null ? true : false);
		try{
			c_PassW=URLDecoder.decode(c_PassW, "UTF-8");
			oldPass=URLDecoder.decode(oldPass, "UTF-8");
			con_passW=URLDecoder.decode(con_passW, "UTF-8");
		}catch(UnsupportedEncodingException e){
			log.debug("Unsupported Format");
		}
		
		Map newData = new HashMap();				
		
		try
		{
			if (c_UserID.length() == 0 && activation)
			{
				jsondata.put("status", "User Id should not be empty");
				return jsondata;
			}
			else if (c_UserID.contains(" ") && activation)
			{
				jsondata.put("status", "User Id should not contain space/s");
				return jsondata;
			}			
			else if (!validator.nameIsValid(c_UserID.trim()) && activation)
			{
				jsondata.put("status", "Please enter a valid User ID.\n It should not contain special characters.");
				return jsondata;
			}
			else if (userDao.getUserCountByUserIdAndPass(c_UserID, encryptor.getEncryptedPassword(oldPass)) == 0)
			{
				jsondata.put("status", "Invalid Current Password!!!");
				return jsondata;
			}
			else if (c_PassW.length() < Integer.parseInt(rb.getPasswdMin()))
			{
				jsondata.put("status", "Password length should be greater than or equal to "+rb.getPasswdMin()+" characters.");
			}
			else if (c_PassW.trim().equalsIgnoreCase("password"))
			{
				jsondata.put("status", "Password is not allowed as user Password");
				return jsondata;
			}
			else if (c_PassW==null || !user.get("con_passW").toString().equals(c_PassW))
			{
				jsondata.put("status", "Invalid Password or Confirm Password \nand make sure that Confirm Password \nis Equal to New Password.");
				return jsondata;
			}
			else if (!validator.passwordIsValid(c_PassW))
			{
				jsondata.put("status", "Password should be a combination of Uppercase, Lowercase, numeric and special characters ! ! !");
				return jsondata;
			}
			else if (userDao.passwordInHistory(c_UserID, encryptor.getEncryptedPassword(c_PassW)))
			{
				jsondata.put("status", "Password has been used before. Please create a new one");
				return jsondata;
			}
			else
			{				
				/*User userData = userDao.getUserPasswordHistory(c_UserID);
				passwordHistory.push(encryptor.getEncryptedPassword(c_PassW));
				passwordHistory.push(userData.getC_PasswordHistory1());
				passwordHistory.push(userData.getC_PasswordHistory2());
				passwordHistory.push(userData.getC_PasswordHistory3());
				passwordHistory.push(userData.getC_PasswordHistory4());*/

				List<String> s =userDao.getUserPasswordHistoryList(c_UserID);
				String method = "";
				
				if(s.size()>=SecurityService.getInstance().getPasswdhistory()){
					method = "update";
				}
				else
				{
					method = "insert";
				}
				boolean success=false;
				
				success = userDao.changeUserPassword(c_UserID, encryptor.getEncryptedPassword(c_PassW),rb.getPasswdExpire());
				userDao.updatePasswordHistory(c_UserID, encryptor.getEncryptedPassword(oldPass),method);
				
				if (success)
				{

					try{
						
						AuditService as = AuditService.getInstance();
						newData = ServiceUtility.removeNulls(user);
						User usr = new User(newData,true);
						as.addAudit(newData.get("c_UserID").toString(),"U","USER",c_UserID+" changed password. User Account Activated");

					}catch(Throwable x){
						x.printStackTrace();
					}

					if (activation)
					{
						jsondata.put("status", "User account successfully activated...");
					}
					else
					{
						jsondata.put("status", "Change Password operation successfull...");
					}

				}
				else
				{
					jsondata.put("status", "Change Password operation fails...");
				}
			}
		}
		catch(Throwable e)
		{e.printStackTrace();}

		return jsondata;
	}


	@SuppressWarnings("unchecked")
	public Map createNewUser(Map user)
	{
		Map jsondata = new HashMap();		
		EncryptorUtil encryptor = new EncryptorUtil();
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		CISADAO CISADao = (CISADAO)Persistence.getDAO("CISADAO");
		Validator validator = new Validator();
		Map newData = new HashMap();
		
		String userID = (user.get("userID")==null ? "" : user.get("userID").toString().trim());
		String c_userid = (user.get("C_USERID")==null ? "" : user.get("C_USERID").toString().trim());
		String c_userName = (user.get("C_USERNAME")==null ? "" : user.get("C_USERNAME").toString().trim());
		String c_branchCode = (user.get("C_BRANCHCODE")==null ? "" : user.get("C_BRANCHCODE").toString().trim());
		String defaultPassW = (user.get("defaultPass") == null ? "" : user.get("defaultPass").toString().trim());
		String isDefaultPass = (user.get("isDefaultPass")==null ? "" :   user.get("isDefaultPass").toString().trim());
		String systemGeneratedPass = (user.get("SystemGeneratedPass") == null ? "" : user.get("SystemGeneratedPass").toString().trim());
		String c_role = (user.get("ROLE") == null ? "" : user.get("ROLE").toString().trim());		
		String c_passw = "";				
		
		try
		{	
			if (isDefaultPass.length() > 0)
			{
				if (isDefaultPass.equals("0")) c_passw = defaultPassW;
				else if (isDefaultPass.equals("1")) c_passw = systemGeneratedPass;
				else c_passw = "";
			}			
			if (c_userid.length() == 0)
			{
				jsondata.put("status", "User Id should not be empty");
				return jsondata;
			}
			else if (c_userid.contains(" "))
			{
				jsondata.put("status", "User Id should not contain space/s");
				return jsondata;
			}
			else if (c_userid.length() < Integer.parseInt(rb.getUseridMin()))
			{
				jsondata.put("status", "User Id should not be less than " + rb.getUseridMin());
				return jsondata;
			}
			else if (!validator.nameIsValid(c_userid.trim()))
			{
				jsondata.put("status", "Please enter a valid User ID.\n It should not contain special characters.");
				return jsondata;
			}
			else if (userDao.getUserCountByUserIdOrUserName(c_userid, "") > 0)
			{
				jsondata.put("status", "User ID already Exists.");
				return jsondata;
			}
			else if (!validator.nameIsValid(c_userName))
			{
				jsondata.put("status", "Please enter a valid User Name spaces, special characters and numbers are not allowed.");
				return jsondata;
			}
			else if (userDao.getUserCountByUserIdOrUserName("",c_userName.trim()) > 0)
			{
				jsondata.put("status", "User Name already exist.");
				return jsondata;
			}
			else if (c_role.length() == 0)
			{
				jsondata.put("status", "Please select User Role from the List. \nIf role is not defined please Define role first.");
				return jsondata;
			}
			else if (c_branchCode.length()==0)
			{
				jsondata.put("status", "Branch can't be Empty. Please select branch from the list. \nIf role is not defined please Define Branch first.");
				return jsondata;
			}
			else if (isDefaultPass.length() == 0)
			{
				jsondata.put("status", "Please choose between Default Password or System Generated Password.");
				return jsondata;
			}			
			else if (c_passw.equalsIgnoreCase("password"))
			{
				jsondata.put("status", "The word Password is not allowed as user password");
				return jsondata;
			}										
		}
		catch(Exception e)
		{e.printStackTrace();}
		
		user.put("C_USERID",c_userid);
		user.put("C_USERNAME", c_userName);
		user.put("ROLE", c_role);
		user.put("C_BRANCHCODE", c_branchCode);
		user.put("C_PASSW", encryptor.getEncryptedPassword(c_passw));		
		user.put("PWDEXPIRE",Integer.parseInt(rb.getPasswdExpire()));
		user.put("C_GENPASS",c_passw);
		user.put("ISDEFAULTPWD", isDefaultPass);
		
		SystemSettingsDAO _SystemSettingsDAO = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
		if(_SystemSettingsDAO.getIsCISAEnabled()){
			//code for checking if aaf user by CVG 09-09-16
			int addToAAF = userDao.checkUserRole(c_role);
			if (addToAAF > 0){
				//log.info("user role must be added to AAf" + user);
				CISADao.addAAFUser(c_userid,c_userName,c_role);
			}
			// end
		}
		boolean success = userDao.createUser(user);
		
		if (success)
		{			
			try{
				
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(user);
				StringBuilder str = new StringBuilder();
				str.append("New User ID created. User ID: "+c_userid+"; User Name:"+c_userName+"; Role: "+c_role+"; Branchcode: "+c_branchCode+"; Password: "+encryptor.getEncryptedPassword(c_passw));
				User usr = new User(newData);
				as.addAudit(userID,"I","USER",str.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			
			jsondata.put("status", "New User Profile Successfully Created...");
		}
		else
		{
			jsondata.put("status", "Unable to Create new User Profile. Please contact Administrator.");
		}
		
		log.info("[createNewUser][jsondata]:->" + jsondata.toString());
		
		return jsondata;
	}
	
	@SuppressWarnings("unchecked")
	public Map getUserByUserId(Map user)
	{
		Map jsondata = new HashMap();
		Map newData  = new HashMap();		
		List records = new ArrayList();
		
		try
		{
			UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
			records         = userDao.getUserByUserId(user);
			newData         = (HashMap) records.get(0);
			newData         = ServiceUtility.removeNulls(newData);
			records         = new ArrayList();
			records.add(newData);
			jsondata.put("returnData",newData);
			log.info("--->> getSystemSetting RECORD-SIZE: " + records.size());
		}
		catch(Throwable x)
		{}
		
		return jsondata;
	}	
	
	@SuppressWarnings("unchecked")
	public Map updateUser(Map user)
	{
		Map jsondata = new HashMap();		
		EncryptorUtil encryptor = new EncryptorUtil();
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		Stack<String> passwordHistory = new Stack<String>();
		Validator validator = new Validator();
		CISADAO CISADao = (CISADAO)Persistence.getDAO("CISADAO");
		
		
		String userID = (user.get("userID")==null ? "" : user.get("userID").toString().trim());
		String UserID       = user.get("C_USERID").toString() == null ? "" : user.get("C_USERID").toString().trim();
		String UserName     = user.get("C_USERNAME").toString() == null ? "" : user.get("C_USERNAME").toString().trim();
		String UserRole   = user.get("ROLE") == null  ? "" : user.get("ROLE").toString().trim();
		String branchCode   = user.get("C_BRANCHCODE") == null  ? "" : user.get("C_BRANCHCODE").toString().trim();
		String defaultPassW = (user.get("defaultPass") == null ? "" : user.get("defaultPass").toString().trim());
		String isDefaultPass = (user.get("isDefaultPass")==null ? "" :   user.get("isDefaultPass").toString().trim());
		String systemGeneratedPass = (user.get("SystemGeneratedPass") == null ? "" : user.get("SystemGeneratedPass").toString().trim());
		String c_passw = "";		
		User userRecord = userDao.getUser(UserID);
		try
		{	
			if (isDefaultPass.length() > 0)
			{
				if (isDefaultPass.equals("0")) c_passw = defaultPassW;
				else if (isDefaultPass.equals("1")) c_passw = systemGeneratedPass;
				else c_passw = "";
			}
			
			if (!validator.nameIsValid(UserName))
			{
				jsondata.put("status", "Please enter a valid User Name spaces, special characters and numbers are not allowed.");
			}
			else if (userDao.getUserCountByUserIdOrUserName("",UserName) > 0)
			{
				jsondata.put("status", "User Name already exist.");				
			}
			else if (UserRole.length() == 0)
			{
				jsondata.put("status", "Please select User Role from the List. \nIf role is not defined please Define role first.");
				return jsondata;
			}
			else if (branchCode.trim().length()==0)
			{
				jsondata.put("status", "Branch can't be Empty. Please select branch from the list. \nIf Branch is not defined please define Branch First.");				
			}
			else if (systemGeneratedPass.length() != 0 || defaultPassW.length()!= 0)
			{
				if (isDefaultPass.length() == 0)
				{
					jsondata.put("status", "Please choose between Default Password or System Generated Password.");					
				}			
				else if (c_passw.equalsIgnoreCase("password"))
				{
					jsondata.put("status", "The word Password is not allowed as user password");
				}				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();			
		}
		
		/*User userData = userDao.getUserPasswordHistory(UserID);
		passwordHistory.push(encryptor.getEncryptedPassword(c_passw));
		passwordHistory.push(userData.getC_PasswordHistory1());
		passwordHistory.push(userData.getC_PasswordHistory2());
		passwordHistory.push(userData.getC_PasswordHistory3());
		passwordHistory.push(userData.getC_PasswordHistory4());*/		
		
		List<String> s =userDao.getUserPasswordHistoryList(UserID);
		String method = "";
		
		if(s.size()>=SecurityService.getInstance().getPasswdhistory()){
			method = "update";
		}
		else
		{
			method = "insert";
		}
		boolean success1=false;
		if(c_passw!=null && c_passw.length()!=0)
		success1 = userDao.changeUserPassword(UserID, encryptor.getEncryptedPassword(c_passw),rb.getPasswdExpire());
		//userDao.updatePasswordHistory(UserID, encryptor.getEncryptedPassword(oldPass),method);
		
		user.put("C_PASSW", ((systemGeneratedPass.length() == 0 && defaultPassW.length()== 0) ? "" : encryptor.getEncryptedPassword(c_passw)));
		user.put("C_USERID",UserID);
		user.put("C_USERNAME", UserName);
		user.put("ROLE", UserRole);
		user.put("C_BRANCHCODE", branchCode);		
		user.put("L_MAINTAIN", "0");
		user.put("L_SUPER", "0");
		user.put("isLogged", "0");
	/*	user.put("C_PasswordHistory1", passwordHistory.get(0));				
		user.put("C_PasswordHistory2", passwordHistory.get(1));				
		user.put("C_PasswordHistory3", passwordHistory.get(2));
		user.put("C_PasswordHistory4", passwordHistory.get(3));
		user.put("C_PasswordHistory5", passwordHistory.get(4));	*/	
		user.put("PWDEXPIRE",Integer.parseInt(rb.getPasswdExpire()));
		user.put("C_GENPASS",((systemGeneratedPass.length() == 0 && defaultPassW.length()== 0) ? " NULL " : c_passw));
		user.put("ISDEFAULTPWD", ((systemGeneratedPass.length() == 0 && defaultPassW.length()== 0) ? " NULL " : isDefaultPass));
		
		SystemSettingsDAO _SystemSettingsDAO = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
		if(_SystemSettingsDAO.getIsCISAEnabled()){
		//code for checking if aaf user by CVG 09-09-16
				int checkIfExist = CISADao.checkIfUserExist(UserID);
				log.info("----------------------------->" + UserID);
				if (checkIfExist > 0){
					//check if user role edited is still a AAF user
					int addToAAF = userDao.checkUserRole(UserRole);
					if (addToAAF > 0){
						CISADao.updateAAFUser(UserID,UserName,UserRole);
					}else{
						CISADao.deleteAAFUser(UserID);
					}
				}else{
					int addToAAF = userDao.checkUserRole(UserRole);
					if (addToAAF > 0){
						CISADao.addAAFUser(UserID,UserName,UserRole);
					}
				}
					
				// end 
		}
		
		boolean success = userDao.updateUserProfile(user);
		
		if (success)
			
			{AuditService as = AuditService.getInstance();
		//	Map newData = ServiceUtility.removeBlankAndNulls(user);
			User usr = new User(user);
			as.addAudit(userID,"U","USER",usr.toAuditString(userRecord));
			if(usr.isReset())
			{
				jsondata.put("status", "User Password has been reset...");
			}
			else
				jsondata.put("status", "User Profile Successfully Modified...");			
		}
		else
		{
			jsondata.put("status", "Update on User Profile failed...");			
		}
		
		return jsondata;
	}
		
	public boolean getUserLoggedStatus(String c_UserID, String c_PassW)
	{			
		EncryptorUtil encryptor = new EncryptorUtil();
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");		
		boolean success = userDao.setUserLoggedStatus(c_UserID, encryptor.getEncryptedPassword(c_PassW));
				
		if(!success)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	public boolean getUserLoggedStatusLDAPS(String c_UserID)
	{			
		EncryptorUtil encryptor = new EncryptorUtil();
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");		
		boolean success = userDao.setUserLoggedStatusLDAPS(c_UserID);
				
		if(!success)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	public boolean getUserLoggedStatusAsOut(String c_UserID)
	{					
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");		
		boolean success = userDao.setUserLoggedStatusAsOut(c_UserID);
		
		if(!success)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public boolean lockedUser(String c_UserID)
	{
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");		
		boolean success = userDao.suspendUser(c_UserID, true, rb.getn_try());
		if(!success)
		{
			return false;
		}
		else
		{
			return true;
		}
	}	
	//changed toJSOn to toJSONGetList by Cherrie Garcia	
	@SuppressWarnings("unchecked")
	public Map getListOfRole(Map role)
	{
		System.out.println("--->> getListOfRole SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
		Map map = new HashMap();
		try{
			AccountingMaintenanceService AMS = AccountingMaintenanceService.getInstance();
			UserDAO userDAO = (UserDAO)Persistence.getDAO("UserDAO");
			List json = new ArrayList();
			json = userDAO.getRoleList(role); //get list correct
			map = AMS.toJSON(json); //map nagkapalit ang value
			
			//ServiceUtility.viewUserParameters(role);
			//UserDAO userDAO = (UserDAO)Persistence.getDAO("UserDAO");				
			//records = (ArrayList)userDAO.getRoleList(role);
			//resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"ROLE", "ROLE_DESC");
			//jsondata.put("AUTOCOMPLETE",resultString);
			//log.info("role----------------->" + role);
			//log.info("records----------------->" + records);
			//log.info("resultString----------------->" + resultString);
			//log.info("jsondata----------------->" + jsondata);
		}catch(Throwable x){
			map.put("status",x.getMessage()); //changed to map / before json data
			x.printStackTrace();
		}	
		
		return map; 
	}
	
	public int getUserCountByUserId(String userId)
	{		
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		return userDao.getUserCountByUserIdOrUserName(userId, null);		
	}
	
	public boolean isSuspended(String userId)
	{		
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		return (userDao.getUserCountIfSuspended(userId, rb.getn_try()) > 0 ? true : false);		
	}
	
	
	
	@SuppressWarnings("unchecked")
	public Map doDeleteUserProfile(Map user)
	{
		Map jsondata = new HashMap();
		
		String c_UserID = (user.get("c_UserID").toString().trim() == null ? "" : user.get("c_UserID").toString().trim());
		String userID = user.get("userID").toString();
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		CISADAO CISADao = (CISADAO)Persistence.getDAO("CISADAO");
		
		SystemSettingsDAO _SystemSettingsDAO = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
		if(_SystemSettingsDAO.getIsCISAEnabled()){
		//	added by CVG 09-12-16
		CISADao.deleteAAFUser(c_UserID);
		//end
		}
		
		boolean success = userDao.deleteUser(c_UserID);
		
		if (success)
		{	AuditService as = AuditService.getInstance();
			as.addAudit(userID,"D","USER",c_UserID +" is successfully deleted.");
			jsondata.put("status", "User Profile successfully delete.");			
		}
		else
		{
			jsondata.put("status", "Unable to delete User Profile.");
		}
		
		return jsondata;
	}
	
	@SuppressWarnings("unchecked")
	public Map unlockedUser(Map user)
	{
		Map jsondata = new HashMap();
		
		String c_UserID = (user.get("c_UserID").toString().trim() == null ? "" : user.get("c_UserID").toString().trim());
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		String userID = user.get("userID").toString();
		boolean success = userDao.suspendUser(c_UserID, false, rb.getn_try());
		
		if(!success)
		{
			jsondata.put("status", "User data cannot set to unlocked.");
		}
		else
		{
			AuditService as = AuditService.getInstance();
			as.addAudit(userID,"U","USER",c_UserID +" is successfully unlocked.");
			jsondata.put("status", "User data successfully unlocked.");
		}
		
		return jsondata;
	}
	
	@SuppressWarnings("unchecked")
	public Map unlockedAllUser(Map user)
	{						
		Map jsondata = new HashMap();
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		boolean success = false;
		String userID = user.get("userID").toString();
		if (userDao.countAllLockedUser() > 0)
		{
			success = userDao.unLockedAllUser();
			if(!success)
			{
				jsondata.put("status", "User data cannot set to unlocked.");
			}
			else
			{
				AuditService as = AuditService.getInstance();
				as.addAudit(userID,"U","USER","ALL users are successfully unlocked.");
				jsondata.put("status", "User data successfully unlocked.");
			}
		}
		else
		{
			jsondata.put("status", "There is no locked user in the database.");
		}
		
		return jsondata;
	}
		
	public boolean setNTry(String userId)
	{
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		return userDao.setNTry(userId);
	}
	
	public boolean resetNTry(String userId)
	{
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		return userDao.resetNTry(userId);
	}
	
	@SuppressWarnings("unchecked")
	public Map isPasswordExpired(Map user)
	{
		Map jsondata = new HashMap();
		
		if(user.get("c_UserID")==null){
			jsondata.put("status", "Requesting for this method without userid");
			jsondata.put("exp",true);
			return jsondata;
		}
		
		String UserID= user.get("c_UserID").toString() == null ? "" : user.get("c_UserID").toString().trim();
		log.info("---L>"+UserID);
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		int passwdWarningCtr = Integer.parseInt(rb.getPasswdParning());
		int expirationCtr = userDao.getPasswordExpirationCtr(UserID);
		
		LDAPSConfigurationService _LDAPSConfigurationService = new LDAPSConfigurationService();
		LDAPSConfiguration _LDAPSConfiguration = _LDAPSConfigurationService.getLDAPSConfiguration();
		log.info("---USer service >"+_LDAPSConfiguration.getEnableLDAPS());
		if (!_LDAPSConfiguration.getEnableLDAPS() && expirationCtr <= passwdWarningCtr && !(expirationCtr <= 0))
		{
			jsondata.put("status", "Your password is about to expire in " + expirationCtr + " days. You must change your password to avoid system in locking your account.	");
			jsondata.put("exp",true);
		}
		else {
			jsondata.put("status", "ok");
		}
			
		log.info("jsondata:" + jsondata.values());
		return jsondata;
	}
	
	@SuppressWarnings("unchecked")
	public String unchangedPwdWarning(String userID) {
		String result = null;
		@SuppressWarnings("unused")
		Map jsondata = new HashMap();
		
		Map user = new HashMap();
		user.put("c_UserID", userID);
		
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		HashMap mapResult = (HashMap) ((List)userDao.getUserByUserId(user)).get(0);
		
		String genPass = mapResult.get("C_GENPASS") != null ? mapResult.get("C_GENPASS").toString() : null;
		String isDefault = mapResult.get("ISDEFAULTPWD") != null ? mapResult.get("ISDEFAULTPWD").toString() : null;
		
		log.info("genPass: " + genPass + ":" + "isDefault: " + isDefault);
		
		if (genPass != null) {
			log.info("Please change your password to avoid system lock");
			result = "Please change your password to avoid system lock";				
		}			
		return result;
	}
	
	@SuppressWarnings("unchecked")
	public String deActivateUser(String userID) {				
		String returnStr = null;
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");		
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		Map user = new HashMap();
		user.put("c_UserID", userID);
		
		HashMap mapResult = (HashMap) ((List)userDao.getUserByUserId(user)).get(0);
		
		String genPass = mapResult.get("C_GENPASS") != null ? mapResult.get("C_GENPASS").toString() : null;
		String isDefault = mapResult.get("ISDEFAULTPWD") != null ? mapResult.get("ISDEFAULTPWD").toString() : null;
		String role = mapResult.get("ROLE") != null ? mapResult.get("ROLE").toString().trim() : "";
		
		log.info("genPass: " + genPass + ":" + "isDefault: " + isDefault);
		
		//if (!(role.equalsIgnoreCase("ADMIN"))) {
				
			if (genPass != null) {
				String d = mapResult.get("D_LASTPASSWMODIFIED").toString();
				int deActivatingPeriod = Integer.parseInt(rb.getDisable());
				log.info("disable date: " + deActivatingPeriod);
				log.info("date:" + d);
				
				log.info("d: " + DateHelper.parse(d));
				Date modifiedDate = DateHelper.parse(d);
				log.info("mapResult: " + mapResult.keySet());					
				Calendar cal = Calendar.getInstance();
				cal.setTime(modifiedDate);
				cal.add(Calendar.DATE, deActivatingPeriod);
				Date lockDate = cal.getTime();
				log.info("deactivation Date: " + lockDate);
				
				Calendar calCurrent = Calendar.getInstance();
				calCurrent.setTime(date.newDate()); //before:new date()
				
				int dateComparison = cal.compareTo(calCurrent); 
				log.info("dateComparison: " + dateComparison);
				
				if (dateComparison <= 0){
					if((Boolean)mapResult.get("C_STATUS")){
					user.put("C_STATUS", "0");
					userDao.updateStatus(user);
					log.info("Default/System Password remain unchanged for more than " + deActivatingPeriod + " day/s. User has been deactivated.  Please contact system administrator.");
					returnStr = "Default/System Password remain unchanged for more than " + deActivatingPeriod + " day/s. User has been deactivated.  Please contact system administrator.";
					return returnStr;
					}
					//jsondata.put("status", "Default/System Password remain unchanged for more than" + deActivatingPeriod + " days, User has been deactivated.  Please contact system administrator.");
				}												
			}			
			
			Date lastLogin = mapResult.get("D_LASTLOGIN") != null ? DateHelper.parse(mapResult.get("D_LASTLOGIN").toString()) : date.newDate(); //before: new date()
			log.info("lastLogin: " + lastLogin);
			
			int disablingPeriod = Integer.parseInt(rb.getDeactivate());
							
			Calendar cal = Calendar.getInstance();
			cal.setTime(lastLogin);
			cal.add(Calendar.DATE, disablingPeriod);
			Date lockDate = cal.getTime();	
			
			Calendar calCurrent = Calendar.getInstance();
			calCurrent.setTime(date.newDate()); //before: new date()
				
			int dateComparison = cal.compareTo(calCurrent); 
				
			if (dateComparison <= 0){
				if((Boolean)mapResult.get("C_STATUS")){
				user.put("C_STATUS", "0");
				userDao.updateStatus(user);
				//jsondata.put("status", "User ID was inactive for more than" + disablingPeriod + " days.  User has been disabled.  Please contact system administrator.");
				returnStr = "User ID was inactive for more than " + disablingPeriod + " day/s.  User has been deactivated.  Please contact system administrator.";
				log.info("User ID was inactive for more than " + disablingPeriod + " day/s.  User has been deactivated.  Please contact system administrator.");
				return returnStr;
			}	}
		//}
		return returnStr;
		
	}
	
	public boolean isPurgedUser(String userID) {
		String returnStr = null;
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");		
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		Map user = new HashMap();
		user.put("c_UserID", userID);
		
		HashMap mapResult = (HashMap) ((List)userDao.getUserByUserId(user)).get(0);
		
		String role = mapResult.get("ROLE") != null ? mapResult.get("ROLE").toString().trim() : "";
		
			if (!(role.equalsIgnoreCase("ADMIN"))) {
			Date lastLogin = mapResult.get("D_LASTLOGIN") != null ? DateHelper.parse(mapResult.get("D_LASTLOGIN").toString()) : date.newDate(); //before: new date()
			log.info("lastLogin: " + lastLogin);
			
			int purgingPeriod = Integer.parseInt(rb.getpurging());							
				Calendar cal = Calendar.getInstance();
				cal.setTime(lastLogin);
				cal.add(Calendar.DATE, purgingPeriod);
				Date lockDate = cal.getTime();	
				
				Calendar calCurrent = Calendar.getInstance();
				calCurrent.setTime(date.newDate()); //before: new date()
				
				int dateComparison = cal.compareTo(calCurrent);
				
				if (dateComparison <= 0){
					//user.put("C_STATUS", "0");
					//userDao.updateStatus(user);					
					log.info("User ID was inactive for more than " + purgingPeriod + " days.  User has been marked for purging.  Please contact system administrator.");
					return true;
				}
		}
		
		return false;
	}
	
	public void lockPassword2(String c_UserID)
	{
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		userDao.setLockedUser2(c_UserID);
	}
	
	public boolean isPasswordExpired(String userId)
	{
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		return (userDao.isPasswordExpired(userId) > 0) ? true : false;
	}
	
	public boolean isPasswordExpiredAndLocked(String userId)
	{
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		boolean isExpired = (userDao.isPasswordExpiredAndLocked(userId) > 0) ? true : false;
		
		if (isExpired)
		{
			userDao.setLockedUser2(userId);	
		}		
		return isExpired;
	}
	
	public boolean isUserActive(String UserId)
	{
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO"); 
		return (userDao.getIsUserActive(UserId) > 0) ? true : false;
	}
	
	@SuppressWarnings({ "unchecked", "null" })
	public Map getSystemDefaultPassword(Map user)
	{
		Map jsondata = new HashMap();
		
		String defaultPassword = rb.getDefaultPasswd().trim();
		
		if (defaultPassword != null)
		{
			jsondata.put("defaultPassword", defaultPassword);
		}
		else if (defaultPassword.trim().length()==0 || defaultPassword == null)
		{
			jsondata.put("defaultPassword", "");	
		}
		
		return jsondata;
	}
	
	@SuppressWarnings("unchecked")
	public Map setUserLoggedStatusAsOut(Map user)
	{								
		Map jsondata = new HashMap();
		String c_UserID = (user.get("c_UserID").toString().trim() == null ? "" : user.get("c_UserID").toString().trim());
		boolean success = getUserLoggedStatusAsOut(c_UserID);
		
		if(!success)
		{
			jsondata.put("status", "Unable to set user session to log out.");
		}
		else
		{
			jsondata.put("status", "User session successfully set to log out.");
		}
		
		return jsondata;
	}
	
	@SuppressWarnings("unchecked")
	public Map getUserList(Map userMap)
	{					
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String  totalRecords = "";
		//alert('<%=urlLoc %>' + "/GateWay.BDOFactor?classname=UserService&classmethod=getUserList&c_UserId="+vUserId+"&dStart="+vDStart+"&dEnd="+vDEnd+"orderBy="+index+"&sortOrder="+sortorder+"&page="+vPage);
		String c_UserId = userMap.get("c_UserId") == null ? "%" : userMap.get("c_UserId").toString().trim();
		String dStart = userMap.get("dStart") == null ? "" : userMap.get("dStart").toString().trim();
		String dEnd = userMap.get("dEnd") == null ? "" : userMap.get("dEnd").toString().trim();
		String orderBy = userMap.get("orderBy") == null ? "a.D_ISSUED" : userMap.get("orderBy").toString().trim();
		String sortOrder = userMap.get("sortOrder") == null ? "DESC" : userMap.get("sortOrder").toString().trim();
		String purging = rb.getpurging();
		userMap.put("c_UserId", c_UserId);
		userMap.put("dStart", dStart);
		userMap.put("dEnd", dEnd);
		userMap.put("orderBy", orderBy);
		userMap.put("sortOrder", sortOrder);
		userMap.put("purging", purging);
		
		ServiceUtility.viewUserParameters(userMap);		
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		totalRecords = Integer.toString(userDao.countAllUser(userMap));
		userMap = ServiceUtility.addPaging(userMap, totalRecords);
		records = userDao.getUserList(userMap);
		
		log.info("--->> get User List RECORD SIZE: "
				+ records.size());				
		
		if ((records != null) && (records.size() > 0)) {
			jsondata = JQGridJSONFormatter.formatDataToJSON(records,
					((String) userMap.get("records")),
					((String) userMap.get("page")), ((String) userMap
							.get("total")));
		} else {
			jsondata.put("status", "There seems to be no User Profile on the database... ");
		}
		
		return jsondata;
	}	
	
	@SuppressWarnings({ "unchecked", "null" })
	public Map getPasswordLength(Map user)
	{
		Map jsondata = new HashMap();
		
		String minLen = rb.getPasswdMin().trim();
		
		if (minLen != null)
		{
			jsondata.put("passWMinLen", minLen);
		}
		else if (minLen.trim().length()==0 || minLen == null)
		{
			jsondata.put("passWMinLen", "8");	
		}
		
		return jsondata;
	}
	
	public void setUserLoginDate(String c_userId)
	{
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		userDao.setUserDateLastLogin(c_userId);
	}
	
	@SuppressWarnings("unchecked")
	public Map activatUser(Map user)
	{
		Map jsondata = new HashMap();		
		String c_UserID = (user.get("c_UserID").toString().trim() == null ? "" : user.get("c_UserID").toString().trim());
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		user.put("c_UserID", c_UserID);
		String userID = user.get("userID").toString();
		boolean status = Boolean.parseBoolean(user.get("status").toString());
		boolean success = userDao.activateUser(user);
		
		try{
			AuditService as = AuditService.getInstance();
			if(success&&status){
				as.addAudit(userID,"U","USER",c_UserID +" is successfully deactivated.");
				jsondata.put("status", "User successfully deactivated.");
			}
			else if(success&&!status){
				as.addAudit(userID,"U","USER",c_UserID +" is successfully activated.");
				jsondata.put("status", "User successfully activated.");
			}
		}catch(Exception e){
			jsondata.put("status", "Operation Failed. Please Try Again.");
		}
		
		
		/*if(!success)
		{
			jsondata.put("status", "User Status successfully unlocked.");
		}
		else
		{
			jsondata.put("status", "User Status successfully unlocked.");
		}*/
		
		return jsondata;
	}
	
	public void updateUsers(){
		int count2=0;
		List user = new ArrayList();
		List reason = new ArrayList();
		UserDAO userDao = (UserDAO)Persistence.getDAO("UserDAO");
		Boolean updated;
		List<User> users = userDao.getAllUser();
		
		System.out.println("-------------------------------------->>>Updating FaMS users");
		
		for (int count =0 ; count<users.size();count++){
			updated=false;
			String c = deActivateUser(users.get(count).getC_UserID());
			if(c!=null){
					user.add(users.get(count).getC_UserID());
					reason.add(c.replace("User has been deactivated.  Please contact system administrator.", "User ID disabled."));
					updated=true;
			}
			
			if((userDao.isPasswordExpired(users.get(count).getC_UserID()) > 0) ? false : true){
				if(users.get(count).getL_Lock()==0){
						userDao.setLockedUser2(users.get(count).getC_UserID());
						user.add(users.get(count).getC_UserID());
						reason.add("Password expired. User ID locked");
						updated=true;
				}
			}
			
			if(updated)count2++;
		}
		
		for(int count=0;count<user.size();count++){
			System.out.println(user.get(count).toString()+"    "+reason.get(count).toString());
		}
		
		System.out.println("Updated "+count2+" records");
	}
	
	public String GetUserRole(String role){
		UserDAO _userDAO = (UserDAO)Persistence.getDAO("UserDAO");
		return _userDAO.GetUserRole(role);
	}

	public User searchUserOnly(String c_UserID) {
		User u = null;		
		try {
			EncryptorUtil encryptor = new EncryptorUtil();
			UserDAO userDAO = (UserDAO) Persistence.getDAO("UserDAO");			
			System.out.println("userDAO" + userDAO);
			u = userDAO.searchUserOnly(c_UserID);			
		}
		catch (Throwable x) {

		}
		return u;
	}
}
