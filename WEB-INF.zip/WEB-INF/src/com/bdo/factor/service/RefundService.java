package com.bdo.factor.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Refund;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.RefundDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class RefundService {
	private static Logger log = Logger.getLogger(RefundService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////

private static RefundService thisRefundService = new RefundService();

private RefundService() { }

public static RefundService getInstance() {

return thisRefundService;
}

@SuppressWarnings("unchecked")

public Map updateRefund(Map RefundForm){
	ServiceUtility.viewUserParameters(RefundForm);
	RefundDAO RefundDAO = (RefundDAO)Persistence.getDAO("RefundDAO");
	
	log.info("--->> updateRefund SERVICE ...");
	
	Map jsondata = new HashMap();
	
	FactorsDateDAO factorsDate = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
	//rr 04172012
	
	//java.util.Date date = new java.util.Date(); 
	java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy");
	String today = format.format(factorsDate.newDate()); //before date
	RefundForm.put("TODAY", today);
	

	Integer insertDiscountDetailCount =RefundDAO.insertDiscountDetailRefund(RefundForm);
	log.info("Insert discount detail sucessful!: "+insertDiscountDetailCount+" record(s)");
	
	
	Integer insertPenaltyDetailCount =RefundDAO.insertPenaltyDetailRefund(RefundForm);
	log.info("Insert penalty detail sucessful!: "+insertPenaltyDetailCount+" record(s)");
	//--
	
	boolean success = RefundDAO.updateRefundStatus(RefundForm);
	if(success) {
		//Refund refund = RefundUtility.getInstance().toObject(RefundForm);
		//String userID = (String) RefundForm.get("C_USERID");
		//AuditService as = AuditService.getInstance();
		//as.addAudit(userID, "U", "InvoiceTYPE", refund.toString());
		
		jsondata.put("status","updateRefundStatus Successful ...");
	}else{
		jsondata.put("status","updateRefundStatus Failed ... ");
	}
	return jsondata;

}

@SuppressWarnings("unchecked")
public Map addRefund(Map RefundForm){
	String clientCode = "";
	
	log.info("--->> addRefund SERVICE ...");
	//ServiceUtility.viewUserParameters(RefundForm);
	
	Map jsondata = new HashMap();
	Map newData = new HashMap();
	
	try{
		ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		clientCode = clientDAO.searchClientResolveToCode(RefundForm);
		if (clientCode == null){
			jsondata.put("status","addRefund Failed ... Invalid client");
			return jsondata;
		}
		RefundForm.put("C_CLNTCODE", clientCode);
		
		ServiceUtility.viewUserParameters(RefundForm);
		
		RefundDAO RefDAO = (RefundDAO)Persistence.getDAO("RefundDAO");
		boolean success;
		
		int n_refno = 0;
		ReceiptsHeaderService RHS = ReceiptsHeaderService.getInstance();
		
		boolean insertmode = RefundForm.get("mode").toString().equals("1");
		if (insertmode){
			n_refno = RefDAO.addRefund(RefundForm);
			success = n_refno!=0?true:false;
			RefundForm.put("N_REFPAYMENTNO", n_refno);
			RHS.receiptsFromTransaction(RefundForm.get(("invoiceString")).toString(), new HashMap(RefundForm));
		} else {
			if(RefundForm.get("B_CLNTRELEASE").toString().equals("true")){
				RefundForm.put("B_CLNTRELEASE", "1");
			} else {
				RefundForm.put("B_CLNTRELEASE", "0");
			}
			success = RefDAO.editRefund(RefundForm);
		}
		
		if(success){					
			
			AuditService as = AuditService.getInstance();
			newData = ServiceUtility.removeNulls(RefundForm);
			Refund refund = new Refund(newData);
			as.addAudit(newData.get("C_USERID").toString(), "I", "REFUND",refund.toString());
			if (insertmode) {
				jsondata.put("status","addRefund Successful ...");
			} else {
				jsondata.put("status","editRefund Successful ...");
			}
		}else{
			if (insertmode) {
				jsondata.put("status","addRefund Failed ... ");
			} else {
				jsondata.put("status","editRefund Failed ... ");
			}
		}
		
	}catch(Exception x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
		//return jsondata;
	}
	
	return jsondata;
}

@SuppressWarnings("unchecked")
public Map getRefund(Map RefundForm){
	
	FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");

	String clientCode = "";
	log.info("--->> getRefund SERVICE");
	Map jsondata = new HashMap();
	SimpleDateFormat UDF = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
	RefundForm.put("asOfDate", UDF.format(date.newDate())); //before: new date()
	try{
		ServiceUtility.viewUserParameters(RefundForm);
		RefundDAO refundDAO = (RefundDAO)Persistence.getDAO("RefundDAO");
		List records = new ArrayList();
		//List<String> list = new ArrayList();
		
		//log.info("--->> N_REFNO: "+RefundForm.get("C_REFNO").toString());
		
		//if (RefundForm!=null && RefundForm.containsKey("C_REFNO")){
		//	list =  Arrays.asList(RefundForm.get("C_REFNO").toString().split(","));
		//}
		log.info("--->> C_NAME: "+RefundForm.get("C_NAME"));
		log.info("--->> C_BRANCHCODE: "+RefundForm.get("C_BRANCHCODE"));
		if (RefundForm.get("C_NAME")!=null){
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientCode = clientDAO.searchClientResolveToCode(RefundForm);
			RefundForm.put("C_CLNTCODE", clientCode);
		}
		log.info("--->> clientcode: "+RefundForm.get("C_CLNTCODE"));
		
		records = refundDAO.getRefund(RefundForm);	
		
		ServiceUtility.viewUserParameters(RefundForm);
					
		log.info("--->> searchRefund RECORD-SIZE: "+records.size());
		
		if((records!=null) && (records.size()>0)){
			jsondata.put("returndata",records);
		}else{
			jsondata.put("status","getRefund Failed ... ");
		}
	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}
	return jsondata;
}

@SuppressWarnings("unchecked")
public Map searchRefund(Map RefundForm){
	
	log.info("--->> searchRefund SERVICE X...");
	
	Map jsondata = new HashMap();
	List records = new ArrayList();
	String totalRecords = "";
	String clientCode = "";

	try{
		
		ServiceUtility.viewUserParameters(RefundForm);
		log.info("--->> searchRefund 1");
			
		//BankDAO factorRefundDAO = (BankDAO)Persistence.getDAO("BankDAO");	
		RefundDAO refundDAO = (RefundDAO)Persistence.getDAO("RefundDAO");	
		
		//System.out.println("--->> searchRefund 2XX");
		log.info("--->> searchRefund 2");
		
		///////////////////////////////////////////////
		
		if (RefundForm.get("C_NAME")!=null){
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientCode = clientDAO.searchClientResolveToCode(RefundForm);
			RefundForm.put("C_CLNTCODE", clientCode);
		}
		///////////////////////////////////////////////
		log.info("--->> searchRefund 2");
		
		totalRecords = refundDAO.getTotalRecordsRefund(RefundForm);	
		//records = refundDAO.searchRefund(RefundForm);	
		
		ServiceUtility.viewUserParameters(RefundForm);
		log.info("--->> searchRefund 2 "+totalRecords);
		
		
		RefundForm = ServiceUtility.addPaging(RefundForm,totalRecords);
		
		records = refundDAO.searchRefund(RefundForm);	
	
		ServiceUtility.viewUserParameters(RefundForm);
		ServiceUtility.viewDataBaseRecords(records);
					
		log.info("--->> searchRefund RECORD-SIZE: "+records.size());
		
		if((records!=null) && (records.size()>0)){						
			jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)RefundForm.get("records")),((String)RefundForm.get("page")),((String)RefundForm.get("total")));
		}else{
			jsondata.put("status","searchRefund Failed ... ");
		}

	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}	
	
	return jsondata;
	
}

@SuppressWarnings("unchecked")
public Map searchReceipts(Map RefundForm){
	
	log.info("--->> searchReceipts SERVICE X...");
	
	Map jsondata = new HashMap();
	List records = new ArrayList();
	String totalRecords = "";
	String clientCode = "";

	try{
		
		ServiceUtility.viewUserParameters(RefundForm);
		log.info("--->> searchReceipts 1");
			
		RefundDAO refundDAO = (RefundDAO)Persistence.getDAO("RefundDAO");	
		
		log.info("--->> searchReceipts 2");
		
		///////////////////////////////////////////////
		if (RefundForm.get("C_NAME")!=null){
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientCode = clientDAO.searchClientResolveToCode(RefundForm);
			RefundForm.put("C_CLNTCODE", clientCode);
		}
		///////////////////////////////////////////////
		log.info("--->>clientCode"+clientCode);
		
		totalRecords = refundDAO.getTotalRecordsReceipts(RefundForm);	
		//records = refundDAO.searchReceipts(RefundForm);	
		
		ServiceUtility.viewUserParameters(RefundForm);
		log.info("--->> searchReceipts 3 "+totalRecords);
		
		RefundForm = ServiceUtility.addPaging(RefundForm,totalRecords);
		
		records = refundDAO.searchReceipts(RefundForm);	
	
		ServiceUtility.viewUserParameters(RefundForm);
					
		log.info("--->> searchReceipts RECORD-SIZE: "+records.size());
		
		if((records!=null) && (records.size()>0)){						
			jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)RefundForm.get("records")),((String)RefundForm.get("page")),((String)RefundForm.get("total")));
		}else{
			jsondata.put("status","searchReceipts Failed ... ");
		}

	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}	
	
	return jsondata;
	
}

public double searchRefundAmount(int n_RefNo) {
	RefundDAO refundDAO = (RefundDAO)Persistence.getDAO("RefundDAO");
	log.info("n_refNo: " + n_RefNo);
	return refundDAO.searchRefundAmountByRefNo(n_RefNo);
}

@SuppressWarnings("unchecked")
public boolean updateRefundStat(int n_RefNo, String status) {
	RefundDAO refundDAO = (RefundDAO)Persistence.getDAO("RefundDAO");
	Map map = new HashMap();
	map.put("N_REFNO", n_RefNo);
	map.put("C_STATUS", status);
	return refundDAO.updateRefundStat(map);
}
//////////////////////////////////////////////////////////////////////////////////////////////

}
