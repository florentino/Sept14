package com.bdo.factor.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.dao.PenChgDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.ServiceUtility;

public class PenChgService {
	private static Logger log = Logger.getLogger(PenChgService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////

private static PenChgService penChgService = new PenChgService();

private PenChgService() { }

public static PenChgService getInstance() {
	return penChgService;
}


public Map getPenaltyCharge(Map m){
	
	Map jsondata = new HashMap();
	
	PenChgDAO PCD = (PenChgDAO)Persistence.getDAO("PenChgDAO");
	jsondata = ServiceUtility.toJQGrid(PCD, "countPenaltyCharge", "getPenaltyCharge", m);
	
	
	return jsondata;
}

public Map addPenalty(Map penaltyMap){
	
	Map jsondata = new HashMap();
	
	ServiceUtility.viewUserParameters(penaltyMap);
	
	PenChgDAO PCD = (PenChgDAO)Persistence.getDAO("PenChgDAO");
	boolean success = PCD.addPenalty(penaltyMap);
	
	if(success){
		String userID = (String) penaltyMap.get("C_USERID");
		AuditService as = AuditService.getInstance();
		as.addAudit(userID, "I", "Penalty", "");
		
		jsondata.put("status","Add Penalty Successful ...");
	}else{
		jsondata.put("status","Add Penalty Failed ... ");
	}
	
	return jsondata;
}

}
