package com.bdo.factor.service;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;

import javax.crypto.SecretKey;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;




import org.w3c.dom.Document;
import org.xml.sax.InputSource;







import com.bdo.factor.beans.LDAPSConfiguration;
import com.bdo.factor.util.DecodeXML;
import com.bdo.factor.util.EncryptorUtil;
import com.bdo.factor.util.XMLParser;

public class WebServiceFactors {
	
	public static void main(String[] args) {
		
		 
	}
	
	
	private TrustManager[ ] get_trust_mgr(){
		TrustManager[ ] certs = new TrustManager[ ]{
			new X509TrustManager() {	//X509TrustManager						
			@Override
			public void checkClientTrusted(
					java.security.cert.X509Certificate[] arg0, String arg1)
					throws CertificateException {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void checkServerTrusted(
					java.security.cert.X509Certificate[] arg0, String arg1)
					throws CertificateException {
				// TODO Auto-generated method stub
				
			}
			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				// TODO Auto-generated method stub
				return null;
			}
		}
	};
		return certs;
	}
	
	public String[] testWebService(String user, String pass,LDAPSConfiguration _LDAPSConfiguration){ //insert userid and password as parameters
		
		String userID = "";
		String password = "";
		
		if (user.equals("powerusr")&&pass.equals("factorpass")){
			userID = "a025005334";
			password = "r@ym0nd12345678";
			
		}else {
			userID = user;
			password=pass;
		}
			

		WebServiceFactors test = new WebServiceFactors();
		String[]statusMessage = new String[2];	
		
		try {
			//XMLParser.getInstance().xmlDecoder("key");
			DecodeXML dx = new DecodeXML();
			
			EncryptorUtil encrypt = new EncryptorUtil();
			//SecretKey secKey= encrypt.generateSecretKey(_LDAPSConfiguration.getEncryptionKey());
			
			String encryptedPassword  = encrypt.encryptText2(password, _LDAPSConfiguration.getEncryptionKey(),_LDAPSConfiguration.getKeySpecs(),_LDAPSConfiguration.getAlgorithm());
			String encryptedCredential = encrypt.encryptText2(_LDAPSConfiguration.getApp_password(), _LDAPSConfiguration.getAppEncryptionKey(),_LDAPSConfiguration.getAppKeySpecs(),_LDAPSConfiguration.getAppAlgorithm());
			//String encryptedCredential = _LDAPSConfiguration.getApp_password();//Application Password
			//Get HostName of User
			System.out.println("ENCRYPTED APPLICATION PASSWORD: "+encryptedCredential);
			InetAddress addr = InetAddress.getLocalHost();
			String host = addr.getHostName();
			
			//System.out.println(dx.xmlDecoder("enableSSLVerification"));
			
			
			if(_LDAPSConfiguration.getBypassSSL()){
				//context that doesn't check certificates	
				
				SSLContext sc = SSLContext.getInstance("SSL");//change to apache jar
				TrustManager[ ] trust_mgr = test.get_trust_mgr();
				sc.init(null, trust_mgr, new SecureRandom());
							
				//for ssl handshake prob
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
				
				HostnameVerifier allHostsValid = new HostnameVerifier() {
					public boolean verify(String arg0, SSLSession arg1) {
						return true;
					}
				};

				HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
			}
			
			//start Connection
			URL url = new URL(_LDAPSConfiguration.getWebServiceURL());
			HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
			
			
			
			//Guard against "bad hostname" errors during handshake
			/*con.setHostnameVerifier(new HostnameVerifier(){
				@Override
				public boolean verify(String host, SSLSession sess) {
					if (host.equals(_LDAPSConfiguration.getWebServiceURL()) return true;
					else return false;
				}				
			});*/
		
			String urlParameters = "userId="+URLEncoder.encode(userID,"UTF-8") //
				+ "&password="+URLEncoder.encode(encryptedPassword,"UTF-8")
				+ "&domain="+URLEncoder.encode("HO","UTF-8");
		
		
			con.setRequestMethod("POST");		
			con.setRequestProperty("app-username", _LDAPSConfiguration.getApp_user());		
			//Encrypt app-password with no padding
			con.setRequestProperty("app-password", encryptedCredential);		
			con.addRequestProperty("hostname", host);
			con.addRequestProperty("username", userID);
			con.addRequestProperty("Content-Type",  "application/x-www-form-urlencoded");
			con.setRequestProperty("Content-Length", Integer.toString(urlParameters.getBytes().length));
			con.setRequestProperty("Content-Language", "en-US");
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setUseCaches(false);
				
	
			//send request 2
			DataOutputStream wr = new DataOutputStream (con.getOutputStream ());
			wr.writeBytes (urlParameters);
			wr.flush ();
			wr.close ();
		
			//catch other errors
			if(con.getResponseCode() == 401){
				statusMessage[0] = "01";
				statusMessage[1]="You are not authorized to access this function";
			
			}else if (con.getResponseCode() == 500){
				statusMessage[0] = "01";
				statusMessage[1]="Internal Server Error";
			}else if (con.getResponseCode() == 412){
				statusMessage[0] = "01";
				statusMessage[1]="Incomplete Header Parameters";
			}
			// System.out.println(status + " " + message );
		
			//Get Response	2
			InputStream is = con.getInputStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			String line;
			StringBuffer response = new StringBuffer(); 
		      while((line = rd.readLine()) != null) {
		    	  response.append(line);
		    	  response.append('\r');
		      }
		      		      
		      rd.close();
		
		      //parse Xml to String 
		      DocumentBuilderFactory docf = DocumentBuilderFactory.newInstance();
		      DocumentBuilder builder = docf.newDocumentBuilder();
		      InputSource src = new InputSource();
		      src.setCharacterStream(new StringReader(response.toString()));
		
		      Document doc = builder.parse(src);
		      statusMessage[0] = doc.getElementsByTagName("status").item(0).getTextContent();
		      statusMessage[1] = doc.getElementsByTagName("message").item(0).getTextContent();
		 
		}catch (MalformedURLException ex){
			statusMessage[0] = "01";
			statusMessage[1]="Web service URL invalid";
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return statusMessage;
		
	}
	

	
}
