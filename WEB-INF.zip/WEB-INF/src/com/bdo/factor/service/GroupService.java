package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Group;
import com.bdo.factor.dao.AuditDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.GroupUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class GroupService {
	private static Logger log = Logger.getLogger(GroupService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static GroupService thisGroupService = new GroupService();
	
	private GroupService() { }

	public static GroupService getInstance() {
		return thisGroupService;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public List searchGroupByGCode(String c_BranchCode, String c_GroupCode){
		log.info("--->> searchGroupByGCode SERVICE ...");
						
		GroupDAO groupDAO = (GroupDAO)Persistence.getDAO("GroupDAO");	
		return groupDAO.searchGroupByGCode(c_BranchCode, c_GroupCode);
				
	}	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchGroup(Map groupMap){
		
		Map jsondata = new HashMap();
		String totalRecords = "";
		String c_BranchCode = "";
		
		try {
			log.info("--->> searchGroup SERVICE ...");		
			
			GroupDAO groupDAO = (GroupDAO)Persistence.getDAO("GroupDAO");
			c_BranchCode = (String) groupMap.get("C_BRANCHCODE");
 			totalRecords = groupDAO.getTotalRecordsGroup(c_BranchCode);			
			groupMap = ServiceUtility.addPaging(groupMap,totalRecords);			
			List lGroup = groupDAO.searchGroup(groupMap);
			ServiceUtility.viewUserParameters(groupMap);
			
			log.info("--->> searchGroup RECORDS: "+lGroup.size());
			if((lGroup!=null) && (lGroup.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lGroup, ((String)groupMap.get("records")),((String)groupMap.get("page")),((String)groupMap.get("total")));
			}else{				
				jsondata.put("status","Search Group Failed ... ");
			}
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;			
	}	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map addGroup(Map group){		
		
		Map jsondata = new HashMap();
		Group g = GroupUtility.getInstance().toObject(group);
		
		try {
			
			ServiceUtility.viewUserParameters(group);
			
			String operation = (String) group.get("operation");
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {
				this.updateGroup(group);
			}
			else {
				GroupDAO groupDAO = (GroupDAO)Persistence.getDAO("GroupDAO");
				
				boolean duplicate = this.isDuplicate(g.getC_BranchCode(), g.getC_GroupCode());				
				if (duplicate) {
					jsondata.put("status","Failed to add Group. Record with same group and branch code already exists.");
					return jsondata;
				}	
				
				boolean success = groupDAO.addGroup(group);
				
				if(success){					
					log.info("adding audit log");
					String userID = (String) group.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "GROUP", g.toString());
					
					jsondata.put("status","Add Group Successful ...");					
				}else{
					jsondata.put("status","Add Group Failed ... ");
				}			
			}
			
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map updateGroup(Map group){
		Map jsondata = new HashMap();
		group.put("C_GROUPCODE", group.get("C_GROUPCODE_ORIG"));
		Group g = GroupUtility.getInstance().toObject(group);
		group.put("N_GRPLIMIT",g.getN_GrpLimit());
		group.put("N_ACCAMT",g.getN_AccAmt());
		try {				
			GroupDAO groupDAO = (GroupDAO)Persistence.getDAO("GroupDAO");			
						
			boolean success = groupDAO.updateGroup(group);
			ServiceUtility.viewUserParameters(group);
			
			if(success){
				log.info("adding audit log2");
				String userID = (String) group.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "GROUP", g.toString());
				
				jsondata.put("status","Update Group Successful ...");
			}
			else{				
				jsondata.put("status","Update Group Failed ... ");				
			}	
		}
		catch (Throwable x) {			
			jsondata.put("status","Update Group Failed ... " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
				
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map deleteGroup(Map group){
		Map jsondata = new HashMap();
		try {		
			Group g = GroupUtility.getInstance().toObject(group);
			
			GroupDAO groupDAO = (GroupDAO)Persistence.getDAO("GroupDAO");

			boolean success = groupDAO.deleteGroup(group);
			ServiceUtility.viewUserParameters(group);
			
			if(success){				
				String userID = (String) group.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "GROUP", g.toString());
				
				jsondata.put("status","Delete Group Successful ...");
			}else{
				jsondata.put("status","Delete Group Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	public boolean isDuplicate(String c_BranchCode, String c_GroupCode) {
		List l = this.searchGroupByGCode(c_BranchCode, c_GroupCode);
		if (l != null && l.size() > 0) {			
			return true;
		}
		return false;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchGroupServiceAutoComplete(Map groupForm){
		
		log.info("--->> searchGroupServiceAutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(groupForm);
			
			GroupDAO groupDAO = (GroupDAO)Persistence.getDAO("GroupDAO");				
			records = (ArrayList)groupDAO.searchGroupServiceAutoComplete(groupForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////		
	
	
	
	public static void main (String[] args) {
		GroupService gs = new GroupService();
		HashMap group = new HashMap();
		group.put("C_BRANCHCODE","11");
		group.put("C_GROUPCODE", "43");
		group.put("N_GRPLIMIT", new Integer(32));
		group.put("N_ACCAMT", new Integer(343));
		group.put("C_GROUPNAME", "name");
		group.put("C_GROUPCODEOLD", "77");
		group.put("C_BRANCHCODEOLD", "11");
		
		
		
		Map mResult = gs.addGroup(group);
		
		//log.info("group : " + g.toString());
		//Map mResult = gs.addGroup(group);
		//Map mResult = gs.searchGroup();
		log.info("result: " + mResult.values());
	
	}
}
