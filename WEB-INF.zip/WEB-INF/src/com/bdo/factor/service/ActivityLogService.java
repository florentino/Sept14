package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.ActivityLog;
import com.bdo.factor.beans.Bank;
import com.bdo.factor.beans.ReportField;
import com.bdo.factor.dao.ActivityLogDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.BankUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class ActivityLogService {
	private static Logger log = Logger.getLogger(ActivityLogService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
			
	private static ActivityLogService thisActivityLogService = new ActivityLogService();
	
	private ActivityLogService() { }

	public static ActivityLogService getInstance() {
		return thisActivityLogService;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////

	public Map addActivityLog(Map logMap){
		
		log.info("--->> addActivityLog SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{	
			ServiceUtility.viewUserParameters(logMap);
			ActivityLog activityLog = new ActivityLog();
			ActivityLogDAO activityLogDAO = (ActivityLogDAO)Persistence.getDAO("activityLogDAO");
			activityLogDAO.doInsertActivityLog(logMap);		
		
		}
		catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}		
		return jsondata;
	}
	
	public List<ReportField> getListActivityLog(Map logMap){
		
		log.info("--->> getListActivityLog SERVICE ...");

		List list = new ArrayList();	
		try{	
			ServiceUtility.viewUserParameters(logMap);
			ActivityLogDAO activityLogDAO = (ActivityLogDAO)Persistence.getDAO("activityLogDAO");
			list = activityLogDAO.getListActivityLog(logMap);		
		
		}
		catch(Throwable x){
			x.printStackTrace();
		}		
		return list;
	}	
		
}
