package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Industry;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.CNDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.IndustryUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class IndustryService {
	private static Logger log = Logger.getLogger(IndustryService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static IndustryService thisIndustryService = new IndustryService();
	
	private IndustryService() { }

	public static IndustryService getInstance() {
		return thisIndustryService;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map searchIND(Map INDForm){
		
		log.info("--->> searchIND SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
				
		try{
			
			ServiceUtility.viewUserParameters(INDForm);
			
			IndustryDAO indDAO = (IndustryDAO)Persistence.getDAO("IndustryDAO");				
			totalRecords = indDAO.getTotalRecordsIND();
			
			INDForm = ServiceUtility.addPaging(INDForm,totalRecords);
			
			if(INDForm.containsKey("page")){
				INDForm = ServiceUtility.addPaging(INDForm,totalRecords);
			}
			
			records = indDAO.searchIND(INDForm);	
		
			ServiceUtility.viewUserParameters(INDForm);
						
			log.info("--->> searchIND RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)INDForm.get("records")),((String)INDForm.get("page")),((String)INDForm.get("total")));
			}else{
				jsondata.put("status","searchIND Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map addIND(Map INDForm){
		
		log.info("--->> addIND SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{			
			ServiceUtility.viewUserParameters(INDForm);
			Industry industry = IndustryUtility.getInstance().toObject(INDForm);
			
			String operation = (String) INDForm.get("operation");
			if(operation !=null && operation.toString().trim().equalsIgnoreCase("update")){
				this.updateIND(INDForm);
			}
			else {			
				IndustryDAO ind = (IndustryDAO)Persistence.getDAO("IndustryDAO");
				String c_INDCode = (String) INDForm.get("C_INDCODE_ORIG");
				
				boolean duplicate = this.isDuplicate(industry.getC_IndCode());
				if (duplicate) {
					jsondata.put("status","Failed to Add Industry. Record with same industry code already exists.");
					return jsondata;
				}	
				
				boolean success = ind.addIND(INDForm);	
				
				if(success){
					String userID = (String) INDForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "INDUSTRY", industry.toString());
					
					jsondata.put("status","addIND Successful ...");
				}else{
					jsondata.put("status","addIND Failed ... ");
				}				
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map updateIND(Map INDForm){
		
		log.info("--->> updateIND SERVICE ...");
		
		Map jsondata = new HashMap();
		INDForm.put("C_INDCODE", INDForm.get("C_INDCODE_ORIG"));
		
		try{
			ServiceUtility.viewUserParameters(INDForm);
			
			Industry industry = IndustryUtility.getInstance().toObject(INDForm);
			
			IndustryDAO ind = (IndustryDAO)Persistence.getDAO("IndustryDAO");		
			boolean success = ind.updateIND(INDForm);
				
			if(success){
				String userID = (String) INDForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "INDUSTRY", industry.toString());
				
				jsondata.put("status","updateIND Successful ...");
			}else{
				jsondata.put("status","updateIND Failed ... ");
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map deleteIND(Map INDForm){
		
		log.info("--->> deleteIND SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			ServiceUtility.viewUserParameters(INDForm);
			
			Industry industry = IndustryUtility.getInstance().toObject(INDForm);
			
			IndustryDAO ind = (IndustryDAO)Persistence.getDAO("IndustryDAO");
			boolean success = ind.deleteIND(INDForm);
					
			if(success){
				String userID = (String) INDForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "INDUSTRY", industry.toString());
				
				jsondata.put("status","deleteIND Successful ...");
			}else{
				jsondata.put("status","deleteIND Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}		

		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchIndustryAutoComplete(Map INDForm){
		
		log.info("--->> searchIndustryAutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(INDForm);
			
			IndustryDAO indDAO = (IndustryDAO)Persistence.getDAO("IndustryDAO");				
			records = (ArrayList)indDAO.searchIndustryAutoComplete(INDForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public Map searchIndustryResolveToCode(Map INDForm){
		
		log.info("--->> searchIndustryResolveToCode SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(INDForm);
			
			IndustryDAO indDAO = (IndustryDAO)Persistence.getDAO("IndustryDAO");				
			resultString = indDAO.searchIndustryResolveToCode(INDForm);
			
			jsondata.put("resultString",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public boolean isDuplicate(String c_INDCode) {
		List l = this.searchINDByCode(c_INDCode);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}

	public List searchINDByCode(String INDCode) {
		log.info("--->> searchINDByCode SERVICE ...");		
		
		//CheckTypeDAO CheckTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
		IndustryDAO IndustryDAO = (IndustryDAO)Persistence.getDAO("IndustryDAO");
				
		//return CheckTypeDAO.searchCheckTypeByCode(c_CheckTypeCode);
		return IndustryDAO.searchINDByCode(INDCode);
	}
	
public List searchIndustryList(Map map){
	IndustryDAO IndustryDAO = (IndustryDAO)Persistence.getDAO("IndustryDAO");
		
		return IndustryDAO.searchIndustryList(map);
	}

public List searchIndustryList2(){
	IndustryDAO IndustryDAO = (IndustryDAO)Persistence.getDAO("IndustryDAO");
		
		return IndustryDAO.searchIndustryList2();
	}
	
}
