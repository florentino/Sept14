package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bdo.factor.beans.ChargeTypeBean;
import com.bdo.factor.dao.ChargeTypeDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class ChargeTypeService {

	private static ChargeTypeService thisChargeTypeService = new ChargeTypeService();
	private ChargeTypeService() { }

	public static ChargeTypeService getInstance() {
		return thisChargeTypeService;
	}
	
	public List<ChargeTypeBean> getAllChargeType(){
		return null;
	}
	
	public Map getChargeTypeSelection(Map data){
		 

		Map jsondata = new HashMap();
		List<HashMap> records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(data);
			
			ChargeTypeDAO chargeTypeDAO = (ChargeTypeDAO) Persistence.getDAO("ChargeTypeDAO");
			records = chargeTypeDAO.getChargeTypeSelection();
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"id","charge_description");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			 

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
}


