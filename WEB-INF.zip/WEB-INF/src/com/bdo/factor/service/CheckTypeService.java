package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CheckType;
import com.bdo.factor.beans.Group;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.CheckTypeUtility;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.DateUtils;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class CheckTypeService {
	private static Logger log = Logger.getLogger(CheckTypeService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static CheckTypeService thisCheckTypeService = new CheckTypeService();
	
	private CheckTypeService() { }

	public static CheckTypeService getInstance() {
		return thisCheckTypeService;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map searchCheckTypeByCode(String c_CheckTypeCode){		
		log.info("--->> searchCheckTypeByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		CheckTypeDAO CheckTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
				
		List records = CheckTypeDAO.searchCheckTypeByCode(c_CheckTypeCode);
		jsonData.put("result", records);
		
		return jsonData;
	}	
	
	public List searchCheckTypeByBCode(String c_CheckTypeCode){		
		log.info("--->> searchCheckTypeByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		CheckTypeDAO CheckTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
				
		return CheckTypeDAO.searchCheckTypeByCode(c_CheckTypeCode);
		
	}	
	
	public Map searchCheckTypeList(Map m){		
		log.info("--->> searchCheckTypeByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		CheckTypeDAO CheckTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
		ArrayList records = (ArrayList) CheckTypeDAO.searchCheckTypeList(m);
		
		//HashMap hm = (HashMap) records.get(0);		
		
		String resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"N_NOOFDAYS","C_DESCRIPTION");
		log.info("records: " + records.size());
		jsonData.put("AUTOCOMPLETE", resultString);
		
		return jsonData;
	}	
	
	public Map searchCheckTypeCodeList(Map m){		
		log.info("--->> searchCheckTypeCodeList SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		CheckTypeDAO CheckTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
		ArrayList records = (ArrayList) CheckTypeDAO.searchCheckTypeList(m);
		
		//HashMap hm = (HashMap) records.get(0);		
		
		String resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_DESCRIPTION","C_CHECKTYPECODE");
		//before records,"C_CHECKTYPECODE","C_DESCRIPTION" cvg081518
		log.info("records: " + records.size());
		log.info("resultString: " +resultString );
		jsonData.put("AUTOCOMPLETE", resultString);
		
		return jsonData;
	}	
	
	public Map searchDaysByCode(Map m){		
		log.info("--->> searchDaysByCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		try {
			CheckTypeDAO CheckTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
			String records = CheckTypeDAO.searchDaysByCode(m);
				
			log.info("records: " + records);
			jsonData.put("result", records);
		}
		catch(Exception e) {
			e.printStackTrace();
			jsonData.put("result", e.getMessage());
		}
		
		return jsonData;
	}	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchCheckType(Map checkTypeMap){
		
		Map jsondata = new HashMap();
		String totalRecords = "";
		
		log.info("--->> searchCheckType SERVICE ...");		
		try {			
			CheckTypeDAO CheckTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
			
			totalRecords = CheckTypeDAO.getTotalRecordsCheckType();	
			
			checkTypeMap = ServiceUtility.addPaging(checkTypeMap,totalRecords);
			
			List lCheckType = CheckTypeDAO.searchCheckType(checkTypeMap);
			ServiceUtility.viewUserParameters(checkTypeMap);
			
			log.info("--->> searchCheckType RECORDS: "+lCheckType.size());
			
			if((lCheckType!=null) && (lCheckType.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lCheckType,((String)checkTypeMap.get("records")),((String)checkTypeMap.get("page")),((String)checkTypeMap.get("total")));
			}else{				
				jsondata.put("status","Search Check Type Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;		
	}	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map addCheckType(Map checkTypeMap){		
		
		Map jsondata = new HashMap();
		try {			
			ServiceUtility.viewUserParameters(checkTypeMap);
			
			CheckType checkType = CheckTypeUtility.toObject(checkTypeMap);			
			String operation = (String) checkTypeMap.get("operation");
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {
				this.updateCheckType(checkTypeMap);
			}
			else {
				
				CheckTypeDAO checkTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
				String c_CheckTypeCodeOld = (String) checkTypeMap.get("C_CHECKTYPECODEOLD");
				
				
				boolean duplicate = this.isDuplicate(checkType.getC_CheckTypeCode());
				if (duplicate) {
					jsondata.put("status","Failed to Add Check Type. Record with same check type code already exists.");
					return jsondata;
				}				
				
				boolean success = checkTypeDAO.addCheckType(checkTypeMap);
				
				
				if(success){
					log.info("adding audit log2");
					String userID = (String) checkTypeMap.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "CHECKTYPE", checkType.toString());
					
					jsondata.put("status","Add Check Type Successful ...");
				}else{
					jsondata.put("status","Add Check Type Failed ... ");
				}
			}
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		
		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map updateCheckType(Map checkTypeMap){		
		Map jsondata = new HashMap();
		CheckType checkType = CheckTypeUtility.toObject(checkTypeMap);
		
		String c_CheckTypeCodeOld = (String) checkTypeMap.get("C_CHECKTYPECODEOLD");
		
		try {
			ServiceUtility.viewUserParameters(checkTypeMap);
					
			CheckTypeDAO ctDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
						
			boolean success = ctDAO.updateCheckType(checkTypeMap);
			ServiceUtility.viewUserParameters(checkTypeMap);
			
			if(success){				
				String userID = (String) checkTypeMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "CHECKTYPE", checkType.toString());
				
				jsondata.put("status","Update Check Type Successful ...");
			}
			else {
				jsondata.put("status","Update Check Type Failed ... ");				
			}
			
		}
		catch (Throwable x) {			
			jsondata.put("status","Update Check Type Failed. " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
				
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map deleteCheckType(Map checkTypeMap){
		
		Map jsondata = new HashMap();
		try {
			ServiceUtility.viewUserParameters(checkTypeMap);
			
			CheckType checkType = CheckTypeUtility.toObject(checkTypeMap);
			
			CheckTypeDAO CheckTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");

			boolean success = CheckTypeDAO.deleteCheckType(checkTypeMap);
						
			if(success){
				String userID = (String) checkTypeMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "CHECKTYPE", checkType.toString());
				
				jsondata.put("status","Delete Check Type Successful ...");
			}else{
				jsondata.put("status","Delete Check Type Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	public boolean isDuplicate(String c_CheckTypeCode) {
		List l = this.searchCheckTypeByBCode(c_CheckTypeCode);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchCheckTypeAutoComplete(Map checkTypeForm){
		
		log.info("--->> searchBankAutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(checkTypeForm);
			
			CheckTypeDAO checkTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");				
			records = (ArrayList)checkTypeDAO.searchCheckTypeAutoComplete(checkTypeForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}
	
	public Map computeClearingDays(Map clearingDateForm) {
		Map jsonData = new HashMap();
		ServiceUtility.viewUserParameters(clearingDateForm);
		log.debug("Values::::" + clearingDateForm.values());
		Date start = DateHelper.parse(clearingDateForm.get("D_TRANSDATE").toString());
		int days = Integer.parseInt(clearingDateForm.get("N_NOOFDAYS").toString());
		String branchCode = (String) clearingDateForm.get("C_BRANCHCODE");
				
		DateUtils dateUtil = DateUtils.getInstance();	
		Date result = dateUtil.addBusinessDay(start, days, branchCode);
		String formattedResult = DateHelper.format(result);
		
		jsonData.put("CLEARINGDATE", formattedResult);
		return jsonData;
	}
}
