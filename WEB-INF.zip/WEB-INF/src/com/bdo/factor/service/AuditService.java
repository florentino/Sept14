package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Audit;
import com.bdo.factor.beans.Group;
import com.bdo.factor.dao.AdvancesDAO;
import com.bdo.factor.dao.AuditDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.GroupUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class AuditService {
	
	private static Logger log = Logger.getLogger(AuditService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static AuditService AuditServiceInstance = new AuditService();
	
	private AuditService() { }

	public static AuditService getInstance() {
		return AuditServiceInstance;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	public void addAudit(String userID, String type, String tableName, String newValue){	
		 FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Audit audit = new Audit();
		audit.setUserID(userID);
		audit.setType(type.toUpperCase());
		audit.setTableName(tableName);
		audit.setNewValue(newValue);
		audit.setUpdateDate(date.newDate());
		
		try {					
			AuditDAO auditDAO = (AuditDAO)Persistence.getDAO("AuditDAO");
			boolean success = auditDAO.addAudit(audit);
			
			if(!success){				
				log.error("failed to add audit: " + audit.toString());	
			}			
		}
		catch (Throwable x) {			
			x.printStackTrace();
		}
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchAudit(Map AuditForm){
		
		log.info("--->> Search Audit SERVICE X...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		String customerCode = "";

		try{
			
			ServiceUtility.viewUserParameters(AuditForm);
			log.info("--->> searchaudit 1");
				
			AuditDAO auditDAO = (AuditDAO)Persistence.getDAO("AuditDAO");	
			
			log.info("--->> searchaudit 2");
			
			totalRecords = auditDAO.getTotalRecordsAudit(AuditForm);	
			//records = advancesDAO.searchAdvances(AuditForm);	
			
			ServiceUtility.viewUserParameters(AuditForm);
			log.info("--->> searchAudit 2 "+totalRecords);
			
			
			AuditForm = ServiceUtility.addPaging(AuditForm,totalRecords);
			
			String orderField = AuditForm.get("orderField") != null ? AuditForm.get("orderField").toString() : "";
			String sortField = AuditForm.get("sortField") != null ? AuditForm.get("sortField").toString() : "";
			
			if (orderField.trim().equalsIgnoreCase("")) {
				orderField = "desc";
			}
			
			if (sortField.trim().equalsIgnoreCase("")) {
				sortField = "updateDate";
			}
			
			AuditForm.put("sortField", sortField);
			AuditForm.put("orderField", orderField);
			
			records = auditDAO.searchAudit(AuditForm);	
		
			ServiceUtility.viewUserParameters(AuditForm);
						
			log.info("--->> searchAdvance RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)AuditForm.get("records")),((String)AuditForm.get("page")),((String)AuditForm.get("total")));
			}else{
				jsondata.put("status","searchAdvance Failed ... ");
			}

		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}
//////////////////////////////////////////////////////////////////////////////////////////////		
	public static void main(String[] args) {
		AuditService as = new AuditService();
		as.addAudit("sampleUser", "i", "sampleTable", "sampleValue");
	}
}
