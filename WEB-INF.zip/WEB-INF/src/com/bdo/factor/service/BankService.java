package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Bank;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.BankUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class BankService {
	private static Logger log = Logger.getLogger(BankService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
			
	private static BankService thisBankService = new BankService();
	
	private BankService() { }

	public static BankService getInstance() {
		return thisBankService;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map searchBank(Map bankForm){
		
		log.info("--->> searchBank SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(bankForm);
			
			BankDAO bankDAO = (BankDAO)Persistence.getDAO("BankDAO");				
			totalRecords = bankDAO.getTotalRecordsBank();	
			
			bankForm = ServiceUtility.addPaging(bankForm,totalRecords);
			
			records = bankDAO.searchBank(bankForm);	
		
			ServiceUtility.viewUserParameters(bankForm);
						
			System.out.println("--->> searchBank RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)bankForm.get("records")),((String)bankForm.get("page")),((String)bankForm.get("total")));
			}else{
				jsondata.put("status","Search Bank Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map addBank(Map bankForm){
		
		log.info("--->> addBank SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			Bank bank = BankUtility.toObject(bankForm);			
			ServiceUtility.viewUserParameters(bankForm);
			
			String operation = (String) bankForm.get("operation");			
			if(operation !=null && operation.trim().equalsIgnoreCase("update")){
				this.updateBank(bankForm);
			}
			else {				
				
				BankDAO bankDAO = (BankDAO)Persistence.getDAO("BankDAO");
				
				boolean duplicate = this.isDuplicate(bank.getC_BANKCODE());				
				if (duplicate) {
					jsondata.put("status","Failed to add Bank. Record with same bank and branch code already exists.");
					return jsondata;
				}
			
				boolean success = bankDAO.addBank(bankForm);
				
				
				if(success){
					String userID = (String) bankForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "BANK", bank.toString());
					
					jsondata.put("status","Add Bank Successful ...");
				}else{
					jsondata.put("status","Add Bank Failed ... ");
				}
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map updateBank(Map bankForm){
		
		log.info("--->> updateBank SERVICE ...");
		log.info("map:" + bankForm.values());
		
		Map jsondata = new HashMap();
		bankForm.put("C_BANKCODE", bankForm.get("C_BANKCODE_ORIG"));
				
		try{
			Bank bank = BankUtility.toObject(bankForm);	
			ServiceUtility.viewUserParameters(bankForm);
		    
		    BankDAO bankDAO = (BankDAO)Persistence.getDAO("BankDAO");	
		    boolean success = bankDAO.updateBank(bankForm);
		
			if(success){
			    String userID = (String) bankForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "BANK", bank.toString());
							
				jsondata.put("status","Update Bank Successful ...");
			}else{
				jsondata.put("status","Update Bank Failed ... ");
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map deleteBank(Map bankForm){
		
		log.info("--->> deleteBank SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			Bank bank = BankUtility.toObject(bankForm);
			ServiceUtility.viewUserParameters(bankForm);
			
			BankDAO bankDAO = (BankDAO)Persistence.getDAO("BankDAO");
			boolean success = bankDAO.deleteBank(bankForm);
			
			ServiceUtility.viewUserParameters(bankForm);
		
			if(success){
				String userID = (String) bankForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "BANK", bank.toString());
				
				jsondata.put("status","Delete Bank Successful ...");
			}else{
				jsondata.put("status","Delete Bank Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}		

		return jsondata;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////


	public Map searchBankAutoComplete(Map bankForm){
		
		log.info("--->> searchBankAutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(bankForm);
			
			BankDAO bankDAO = (BankDAO)Persistence.getDAO("BankDAO");				
			records = (ArrayList)bankDAO.searchBankAutoComplete(bankForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchBankByCode(String c_BankCode){
		log.info("--->> searchBankByCode SERVICE ...");
						
		BankDAO bankDAO = (BankDAO)Persistence.getDAO("BankDAO");	
		return bankDAO.searchBankByCode(c_BankCode);
				
	}	
	
	public Map searchBankList(Map m){		
		log.info("--->> searchBankList SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		BankDAO bankDAO = (BankDAO)Persistence.getDAO("BankDAO");
		ArrayList records = (ArrayList) bankDAO.searchBankList();
		
		//HashMap hm = (HashMap) records.get(0);		
		
		String resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_BANKCODE","C_BANKNAME");
		log.info("records: " + records.size());
		jsonData.put("AUTOCOMPLETE", resultString);
		
		return jsonData;
	}	
	
	//changed toJSOn to toJSONGetList by Cherrie Garcia
	public Map getBank(Map m){
		Map json = new HashMap();
		BankDAO BD = (BankDAO)Persistence.getDAO("BankDAO");
		AccountingMaintenanceService AMS = AccountingMaintenanceService.getInstance();
		json = AMS.toJSON(BD.getBank());
		log.info("json--------------->"+ json );
		return json;
	}
//////////////////////////////////////////////////////////////////////////////////////////////		
	public boolean isDuplicate(String c_BankCode) {
		List l = this.searchBankByCode(c_BankCode);
		if (l != null && l.size() > 0) {			
			return true;
		}
		return false;
	}
	
}
