package com.bdo.factor.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;
//import org.apache.poi.hssf.record.formula.functions.Request;






















import com.bdo.factor.beans.AccountOfficer;
import com.bdo.factor.beans.BLRFileClientMaster;
import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLinkClientMaster;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.ClientMaster;
import com.bdo.factor.dao.AccountOfficerDAO;
import com.bdo.factor.dao.BLRFileDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.CCLinkDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.CurrencyDAO;
import com.bdo.factor.dao.CustomerDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.MiscCodeDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.ReceiptsHeaderDAO;
import com.bdo.factor.dao.ServiceOfficerDAO;
import com.bdo.factor.dataSource.InvoiceDAO;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.SecurityUtil;
import com.bdo.factor.util.ServiceUtility;

public class ClientService {
	
	private static Logger log = Logger.getLogger(ClientService.class);
	
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////// 

	private static ClientService ClientServiceInstance = new ClientService();

	private ClientService() {}

	public static ClientService getInstance() {
		log.info("-->> ClientService getInstance...");
		return ClientServiceInstance;
	}

	//@@
	public Map searchCustomerClientClassificationList(Map customerMap) {

		log.info("--->> searchCustomerClientClassificationList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(customerMap);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			//records = clientDAO.searchClientClassificationList(customerMap); //point commented for testing
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"CodeObject","CodeDescription");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchCustomerClientClassificationList Resultstring: "+ resultString);
			log.info("--->> searchCustomerClientClassificationList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	//@@#
//////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchClient(Map clientForm) {
		
		log.info("--->> searchClient SERVICE 3...");

		Map jsondata = new HashMap();
		List records = new ArrayList();

		try{
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchClient(clientForm);
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		jsondata.put("returnData", records);

		log.info("--->> searchClient RECORD SIZE: " + records.size());

		return jsondata;
	}

	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchClientWithPaging(Map clientForm){
		
		log.info("--->> searchClientWithPaging SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		try{
			
			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");	
			totalRecords = clientDAO.searchClientCountForPaging(clientForm);					 
				
			clientForm = ServiceUtility.addPaging(clientForm,totalRecords);
			
			records = clientDAO.searchClientWithPaging(clientForm);	
		
			ServiceUtility.viewUserParameters(clientForm);
						
			System.out.println("--->> searchClientWithPaging RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)clientForm.get("records")),((String)clientForm.get("page")),((String)clientForm.get("total")));
			}else{
				jsondata.put("status","searchClientWithPaging Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchAccountClassificationList(Map clientForm) {

		log.info("--->> searchAccountClassificationList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchAccountClassificationList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"CreditRiskCd","CreditRiskDes");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchAccountClassificationList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	

////////////////////////////////////////////////////////////////////////////////////////////// BusInfoClientClassification
	
	public Map searchBorrowerTypeList(Map clientForm) {

		log.info("--->> searchBorrowerTypeList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchBorrowerTypeList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_BORWCODE","C_BORCLASS");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchBorrowerTypeList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchAssetSizeList(Map clientForm) {

		log.info("--->> searchAssetSizeList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchAssetSizeList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_BORWTYPE","C_DESC");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchBorrowerTypeList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
//added by CVG as of 04-12-16	
	
	public Map searchClientClassificationList(Map clientForm) {

		log.info("--->> searchIndustryList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchClientClassificationList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"Description","Description");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchIndustryList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	
	
	public Map searchIndustryList(Map clientForm) {

		log.info("--->> searchIndustryList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			//ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			IndustryService industryService = IndustryService.getInstance();
			records = industryService.searchIndustryList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"IndCd","C_Desc");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchIndustryList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public Map searchCurrencyListAjax(Map clientForm) {

		log.info("--->> searchCurrencyListAjax SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchCurrencyListAjax(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_CURRENCYCODE","C_DESCRIPTION");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchCurrencyListAjax RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchAccountOfficerList(Map clientForm) {

		log.info("--->> searchAccountOfficerList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchAccountOfficerList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_ACCTOFFICERCODE","C_NAME");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchAccountOfficerList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public Map searchServiceOfficerList(Map clientForm) {

		log.info("--->> searchServiceOfficerList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchServiceOfficerList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_SERVICEOFFICERCODE","C_NAME");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchServiceOfficerList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchGroupList(Map clientForm) {

		log.info("--->> searchGroupList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchGroupList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_GROUPCODE","C_GROUPNAME");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchGroupList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchBankList(Map clientForm) {

		log.info("--->> searchGroupList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchBankCustomerList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_BANKCODE","C_BANKNAME");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchGroupList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchClientRiskRatingList(Map clientForm) {

		log.info("--->> searchClientRiskRatingList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchClientRiskRatingList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_RISKID","C_RISK");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchClientRiskRatingList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
//////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchRPTClassificationList(Map clientForm) {

		log.info("--->> searchClientRiskRatingList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchRPTClassificationList(clientForm);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_RPTID","C_RPTNAME");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchClientRiskRatingList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	
	public Map searchClientByCode(Map clientForm) {

		log.info("--->> searchClientByCode SERVICE ...");
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		Map tmpHashMap = new HashMap();
		List records = new ArrayList();
		String C_CLIENTCLASSIFICATION = "";
		String industryDesc = "";
		String bankDesc = "";
		//String bankDescUSD = "";
		String currencyDesc = "";
		String groupDesc = "";
		String accountOfficerDesc = "";
		String serviceOfficerDesc = "";
		String riskRatingName = "";
		String rptName = "";
		String clientToDescription = "";
		
		String industryCodetoDesc ="";

		try {

			ServiceUtility.viewUserParameters(clientForm);

			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = clientDAO.searchClientByCode(clientForm);
			
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		
		
		
			///////////////////////////////////////////////////////////////////////
		
		

			try{
				newData = (HashMap) records.get(0);
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}

			///////////////////////////////////////////////////////////////////////
			
			log.info("-->> newDataX: "	+ (String) newData.get("C_INDUSTRYCODE"));
			//log.info("-->> newDataX: "	+ (String) newData.get("C_BANKCODE"));
			log.info("-->> newDataX: "	+ (String) newData.get("C_CURRENCYCODE"));
			//log.info("-->> newDataX: "	+ (String) newData.get("C_GROUPCODE"));
			//log.info("-->> newDataX: "	+ (String) newData.get("C_ACCTOFFICERCODE"));
			//log.info("-->> newDataX: "	+ (String) newData.get("C_SERVICEOFFICERCODE"));

			////////////////////////////////////////////////////////////////////////

			try{
				
				IndustryDAO indDAO = (IndustryDAO) Persistence.getDAO("IndustryDAO");
				industryDesc = indDAO.searchIndustryResolveToDesc(newData);
			
				industryCodetoDesc = indDAO.searchIndustryResolveToDesc2(newData);
				log.info("industryCodetoDesc---------->"+industryCodetoDesc);
				newData.put("C_Desc", industryCodetoDesc);
			
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				
				BankDAO bankDAO = (BankDAO) Persistence.getDAO("BankDAO");
				bankDesc = bankDAO.searchBankResolveToDesc(newData);
				
				tmpHashMap = newData;
				//tmpHashMap.put("C_BANKCODE", tmpHashMap.get("C_BANKCODEUSD"));
				//bankDescUSD = bankDAO.searchBankResolveToCode(tmpHashMap);

			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				CurrencyDAO currencyDAO = (CurrencyDAO) Persistence.getDAO("CurrencyDAO");
				currencyDesc = currencyDAO.searchCurrencyResolveToDesc(newData);
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				GroupDAO groupDAO = (GroupDAO) Persistence.getDAO("GroupDAO");
				groupDesc = groupDAO.searchGroupResolveToDesc(newData);
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				AccountOfficerDAO accountOfficerDAO = (AccountOfficerDAO) Persistence.getDAO("AccountOfficerDAO");
				accountOfficerDesc = accountOfficerDAO.searchAccountOfficerResolveToDesc(newData);
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				ServiceOfficerDAO serviceOfficerDAO = (ServiceOfficerDAO) Persistence.getDAO("ServiceOfficerDAO");
				serviceOfficerDesc = serviceOfficerDAO.searchServiceOfficerServiceResolveToDesc(newData);
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			//try by CVG
			try{
				Boolean res = (Boolean)newData.get("C_RESIDENT")!=null?(Boolean)newData.get("C_RESIDENT"):true;
				newData.put("C_RESIDENT",res );
				///if(res==false){
				//	String res2 = newData.get("C_RESIDENT")!=null?"0":"1";
				//	newData.put("C_RESIDENT",res2 );
				///}
				//
				//if(res==null||res.equals("null")){
				//	newData.put("C_RESIDENT",res );
				//	System.out.println("C_RESIDENT-------------->"+res);	
				//}
				
				
				

			
				
				
				MiscCodeDAO miscCodeDAO = (MiscCodeDAO)Persistence.getDAO("MiscCodeDAO");		
				clientToDescription = miscCodeDAO.getClientClassificationToCode(newData); // create searchClientClassificationToDesc
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			

			//end try
			
			////////////////////////////////////////////////////////////////////////
			
			newData.put("C_INDUSTRYCODE", industryDesc);
			//newData.put("C_BANKCODE", bankDesc);
			//newData.put("C_BANKCODEUSD", bankDescUSD);
			newData.put("C_CURRENCYCODE", currencyDesc);
			
			
			
			//newData.put("C_GROUP", groupDesc);
			//newData.put("C_ACCTOFFICERCODE", accountOfficerDesc);
			//newData.put("C_SERVICEOFFICERCODE", serviceOfficerDesc);
			
			/*
			clientForm.put("C_INDUSTRYCODE", industryCode);
			clientForm.put("C_BANKCODE", bankCode);
			clientForm.put("C_CURRENCYCODE", currencyCode);
			clientForm.put("C_ACCTOFFICERCODE", accountOfficerCode);
			clientForm.put("C_SERVICEOFFICERCODE", servicingOfficerCode);
			*/
			
			newData = ServiceUtility.removeNulls(newData);

			////////////////////////////////////////////////////////////////////////

			log.info("-->> newDataZ: "	+ (String) newData.get("C_INDUSTRYCODE"));
			//log.info("-->> newDataZ: "	+ (String) newData.get("C_BANKCODE"));
			log.info("-->> newDataZ: "	+ (String) newData.get("C_CURRENCYCODE"));
			//log.info("-->> newDataZ: "	+ (String) newData.get("C_GROUPCODE"));
			//log.info("-->> newDataZ: "	+ (String) newData.get("C_ACCTOFFICERCODE"));
			//log.info("-->> newDataZ: "	+ (String) newData.get("C_SERVICEOFFICERCODE"));

			////////////////////////////////////////////////////////////////////////

			log.info("\n+++++++++++++++++++++++++++++++++++++++++++");

			
			log.info("-->> C_CLIENTCLASSIFICATION: " + clientToDescription);
			log.info("-->> industryDesc: " + industryDesc);
			log.info("-->> bankDesc: " + bankDesc);
			//log.info("-->> bankDescUSD: " + bankDescUSD);
			log.info("-->> currencyDesc: " + currencyDesc);
			log.info("-->> groupDesc: " + groupDesc);
			log.info("-->> accountOfficerDesc: " + accountOfficerDesc);
			log.info("-->> serviceOfficerDesc: " + serviceOfficerDesc);
			

			log.info("\n+++++++++++++++++++++++++++++++++++++++++++");

			////////////////////////////////////////////////////////////////////////

			records = new ArrayList();
			records.add(newData);

			///////////////////////////////////////////////////////////////////////

			jsondata.put("returnData", records);

			log.info("--->> searchClientByCode RECORD-SIZE: "	+ records.size());

			///////////////////////////////////////////////////////////////////////


		return jsondata;

	}

	
/////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchClientCodeByBranchAndName(Map clientForm){
		
		log.info("--->> searchClientCodeByBranchAndName SERVICE ...");
		log.info("clientForm from report advances >>>>>>>>>>" + clientForm);	
		Map jsondata = new HashMap();
		List records = new ArrayList();
			
		try{
			
			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");				
			records = (ArrayList)clientDAO.searchClientCodeByBranchAndName(clientForm);	

		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
			log.info("--->> searchClientCodeByBranchAndName RECORD-SIZE: "+records.size());
			ServiceUtility.viewDataBaseRecords(records);
			
			jsondata.put("returnData", records);
			log.info("json data from report advances >>>>>>>>>>" + jsondata);	
			log.info("records data from report advances >>>>>>>>>>" + records);	
		return jsondata;
		
	}	
	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchClientServiceAutoComplete(Map clientForm) {

		log.info("--->> searchClientServiceAutoComplete SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
	
		String resultString = "";
	//	String decodeResult ="";
		try {

			ServiceUtility.viewUserParameters(clientForm);

			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			records = (ArrayList) clientDAO.searchClientServiceAutoComplete(clientForm);
			//
			resultString = JQGridJSONFormatter.formatListToString(records); //
		//	decodeResult =  SecurityUtil.decode(resultString);
			jsondata.put("AUTOCOMPLETE", resultString);
			
			
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
	
		System.out.println("jsondata >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + jsondata);
		return jsondata;

	}
//////////////////////////////////////////////////////////////////////////////////////////////filtered

	public Map searchClientServiceAutoCompleteFiltered(Map clientForm) {

		log.info("--->> searchClientServiceAutoComplete SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
	
		String resultString = "";
	//	String decodeResult ="";
		try {

			ServiceUtility.viewUserParameters(clientForm);
			 ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
				records = (ArrayList) clientDAO.searchClientServiceFilteredAutoComplete(clientForm);// edited 07182017 CVG 
				resultString = JQGridJSONFormatter.formatListToString(records); 
				jsondata.put("AUTOCOMPLETE", resultString);

			// option 2  removing last word of string
			//resultString = JQGridJSONFormatter.formatListToString2(records); option 2
			//	decodeResult =  SecurityUtil.decode(resultString);
			//String stringToJson = ServiceUtility.stringClientNameFilter(resultString); //ClientNameFilter CVG06132017 option 2
			//jsondata.put("AUTOCOMPLETE", stringToJson);

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
	
		System.out.println("jsondata >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + jsondata);
		return jsondata;

	}
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map mainClientMaster(Map clientForm) {

		Map jsondata = new HashMap();
		Map tmpHashMap = new HashMap();
		
		String industryCode = "";
		String industryCode2 = "";
		String bankCode = "";
		//String bankCode2 = "";
		String bankCodeUSD = "";
		String currencyCode = "";
		String groupCode = "";
		String currencyRateDate = "";
		String accountOfficerCode = "";
		String accountOfficerBranchCode = "";
		String servicingOfficerCode = "";
		
		//@@ Business Information added on: April 13, 2012: jgt
		String C_CLIENTCLASSIFICATION = "";
		String d_BUSINESSDATEOFBIRTH = "";
		String c_SOURCEOFFUND = "";
		String c_NATUREOFWORK = "";
		String c_DIRECTORS = "";
		
		//@@ end here
			
		//added by cvg
		//String c_DOSRI = "";
		String industryCodetoDesc = "";
		log.info("--->>> CALLED mainClientMaster...");
		ServiceUtility.viewUserParameters(clientForm);

		
			/////////////////////////////////////////////////////////////////////////
			
			/// clientcode is blrdode ... ///
			
			try{
				clientForm.put("C_BLRTYPECODE", ((String) clientForm.get("C_CLNTCODE")));
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			/////////////////////////////////////////////////////////////////////////
			/// resolve all look-ups ... ///
			
			
			try{
				IndustryDAO indDAO = (IndustryDAO) Persistence.getDAO("IndustryDAO");
				industryCode = indDAO.searchIndustryResolveToCode(clientForm);
				clientForm.put("C_INDUSTRYCODE", (String)clientForm.get("C_INDCODE"));
				
				industryCode2 = indDAO.searchIndustryResolveToCode2(clientForm);
				clientForm.put("IndCd", industryCode2);
				
				
				
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				BankDAO bankDAO = (BankDAO) Persistence.getDAO("BankDAO");
				bankCode = bankDAO.searchBankResolveToCode(clientForm);
				tmpHashMap = clientForm;
				//tmpHashMap.put("C_BANKCODE", tmpHashMap.get("C_BANKCODE2"));  C_INDUSTRYTYPE
				//bankCode2 = bankDAO.searchBankResolveToCode(tmpHashMap);
				
				//tmpHashMap.put("C_BANKCODE", tmpHashMap.get("C_BANKCODEUSD"));
				//bankCodeUSD = bankDAO.searchBankResolveToCode(tmpHashMap);
				
				

				/*if((bankCode==null || bankCode.toString().trim().length()==0)){
					jsondata.put("status","Invalid Bank ...");						
					return jsondata;
				}*/
				
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				CurrencyDAO currencyDAO = (CurrencyDAO) Persistence.getDAO("CurrencyDAO");
				currencyCode = currencyDAO.searchCurrencyResolveToCode(clientForm);
				currencyRateDate = currencyDAO.searchCurrencyResolveToRateDate(clientForm);
				
				/*if((currencyCode==null || currencyCode.toString().trim().length()==0)){
					jsondata.put("status","Invalid Currency ...");						
					return jsondata;
				}*/
				
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				GroupDAO groupDAO = (GroupDAO) Persistence.getDAO("GroupDAO");
				groupCode = groupDAO.searchGroupResolveToCode(clientForm);
				
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				ServiceOfficerDAO serviceOfficerDAO = (ServiceOfficerDAO) Persistence.getDAO("ServiceOfficerDAO");
				servicingOfficerCode = serviceOfficerDAO.searchServiceOfficerServiceResolveToCode(clientForm);
				
				/*if((servicingOfficerCode==null || servicingOfficerCode.toString().trim().length()==0)){
					jsondata.put("status","Invalid Service Officer ...");						
					return jsondata;
				}*/
				
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			try{
				AccountOfficerDAO accountOfficerDAO = (AccountOfficerDAO) Persistence.getDAO("AccountOfficerDAO");
				accountOfficerCode = accountOfficerDAO.searchAccountOfficerResolveToCode(clientForm);
				accountOfficerBranchCode = accountOfficerDAO.searchAccountOfficerResolveToBranchCode(clientForm);
				
				/*if((accountOfficerCode==null || accountOfficerCode.toString().trim().length()==0)){
					jsondata.put("status","Invalid Account Officer ...");						
					return jsondata;
				}*/
				
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			
			
			try{
				MiscCodeDAO miscCodeDAO = (MiscCodeDAO) Persistence.getDAO("MiscCodeDAO");
				C_CLIENTCLASSIFICATION = miscCodeDAO.getClientClassificationToCode(clientForm);
				log.info(C_CLIENTCLASSIFICATION);
				
				//String res2 = clientForm.get("C_RESIDENT").toString();
				//log.info("C_RESIDENT before--->" + res2);
				
				String res = clientForm.get("C_RESIDENT")!=null?"1":"0";
				clientForm.put("C_RESIDENT",res );
				
				
			//	accountOfficerBranchCode = accountOfficerDAO.searchAccountOfficerResolveToBranchCode(clientForm);
				
				/*if((accountOfficerCode==null || accountOfficerCode.toString().trim().length()==0)){
					jsondata.put("status","Invalid Account Officer ...");						
					return jsondata;
				}*/
				
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}

			
	
			
			/////////////////////////////////////////////////////////////////////////
			/// pirint all returned codes ... ///
			
			log.info("\n+++++++++++++++++++++++++++++++++++++++++++");
			
			
			log.info("-->> C_CLIENTCLASSIFICATION: " + C_CLIENTCLASSIFICATION);
			
			log.info("-->> industryCode: " + industryCode);
			log.info("-->> industryCode2: " + industryCode2);
			log.info("-->> bankCode: " + bankCode);
			//log.info("-->> bankCode2: " + bankCode2);
			log.info("-->> bankCodeUSD: " + bankCodeUSD);
			log.info("-->> currencyCode: " + currencyCode);
			log.info("-->> groupCode: " + groupCode);
			log.info("-->> servicingOfficerCode: " + servicingOfficerCode);
			log.info("-->> currencyRateDate: " + currencyRateDate);
			log.info("-->> accountOfficerCode: " + accountOfficerCode);
			log.info("-->> accountOfficerBranchCode: " + accountOfficerBranchCode);
			log.info("\n+++++++++++++++++++++++++++++++++++++++++++");

			/////////////////////////////////////////////////////////////////////////
			// / start of Adding ... ///

			clientForm.put("C_INDUSTRYCODE", industryCode);
			clientForm.put("C_INDCODE", industryCode2);
			//clientForm.put("C_BANKCODE", bankCode);
			//clientForm.put("C_BANKCODE2", bankCode2);
			//clientForm.put("C_BANKCODEUSD", bankCodeUSD);
			//clientForm.put("C_CURRENCYCODE", currencyCode);
			//clientForm.put("C_GROUP", groupCode);
			//clientForm.put("C_GROUPCODE", groupCode);
			//clientForm.put("C_ACCTOFFICERCODE", accountOfficerCode);
			//clientForm.put("C_SERVICEOFFICERCODE", servicingOfficerCode);
			
			/////////////////////////////////////////////////////////////////////////
			
			if (clientForm.containsKey("btn_addBRL")){
				
				return addBLR(clientForm);
				
			}else if (clientForm.containsKey("btn_updateBLR")){
				
				return updateBLR(clientForm);
				
			}else if (clientForm.containsKey("btn_saveClient")){
				
				return addClient(clientForm);
				
			}else if (clientForm.containsKey("btn_updateClient")) {
				
				return updateClient(clientForm);

			}else if (clientForm.containsKey("btn_addCustomer")) {
				
				return addCustomer(clientForm);
			
			}else if (clientForm.containsKey("btn_updateCustomer")) {
				
				return updateCustomer(clientForm);

			}else if (clientForm.containsKey("btn_updateClientTCInfo")) {
				
				return updateClientTCInfo(clientForm);

			}else if (clientForm.containsKey("btn_updateClientFinanceInfo")) {
				
				return updateClientFinanceInfo(clientForm);

			}else if (clientForm.containsKey("btn_updateCustomerPaymentSched")) {
				
				return saveSchedule(clientForm);

			}

			/////////////////////////////////////////////////////////////////////////

		return jsondata;
	}

	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	/// start of CRUD ... ////
	
	public Map addClient(Map clientForm) {

		Map jsondata = new HashMap();
		Map newData = new HashMap();
		List records = new ArrayList();
		String clientCode = "";
		boolean clientSuccess = false;
		boolean monthlyBalancesSuccess = false;
		boolean monthlyDCSuccess = false;

		try {
			
			log.info("--->>> addClient ...");
			ServiceUtility.viewUserParameters(clientForm);

			 if(clientForm.get("C_NAME")==null || clientForm.get("C_NAME").toString().trim().length()==0){
				 jsondata.put("status","Full Name Cannot be EMPTY ...");
				 return jsondata;
			 }else if(clientForm.get("C_ADDRESS")==null || clientForm.get("C_ADDRESS").toString().trim().length()==0){
				 jsondata.put("status","Address Cannot be EMPTY ...");
				 return jsondata;
			 }else if(clientForm.get("C_ACCTOFFICERCODE")==null || clientForm.get("C_ACCTOFFICERCODE").toString().trim().length()==0){
				 jsondata.put("status","Account Officer is Required, Please Select One ...");
				 return jsondata;
			 }

			 
			 	String res = clientForm.get("C_RESIDENT")!=null?"1":"0";
				clientForm.put("C_RESIDENT",res );
				//////////////////////////////////////////////////

//				try{
//						if((clientForm.get("D_EFFDT1").toString().trim().length() != 0) && (clientForm.get("D_EXPDT1").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Expiry Date 1...");
//							return jsondata;
//						}
//				
//						if((clientForm.get("D_EFFDT2").toString().trim().length() != 0) && (clientForm.get("D_EXPDT2").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Expiry Date 2...");
//							return jsondata;
//						}
//				
//						if((clientForm.get("D_EFFDT3").toString().trim().length() != 0) && (clientForm.get("D_EXPDT3").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Expiry Date 3...");
//							return jsondata;
//						}
//				
//						if((clientForm.get("D_EFFDT4").toString().trim().length() != 0) && (clientForm.get("D_EXPDT4").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Expiry Date 4...");
//							return jsondata;
//						}
//				
//						if((clientForm.get("D_EFFDT5").toString().trim().length() != 0) && (clientForm.get("D_EXPDT5").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Expiry Date 5...");
//							return jsondata;
//						}	
//				
//						//////////////////////////////////////////////////
//				
//						if((clientForm.get("D_EXPDT1").toString().trim().length() != 0) && (clientForm.get("D_EFFDT1").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Effective Date 1...");
//							return jsondata;
//						}			
//				
//						if((clientForm.get("D_EXPDT2").toString().trim().length() != 0) && (clientForm.get("D_EFFDT2").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Effective Date 2...");
//							return jsondata;
//						}	
//				
//						if((clientForm.get("D_EXPDT3").toString().trim().length() != 0) && (clientForm.get("D_EFFDT3").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Effective Date 3...");
//							return jsondata;
//						}
//				
//						if((clientForm.get("D_EXPDT4").toString().trim().length() != 0) && (clientForm.get("D_EFFDT4").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Effective Date 4...");
//							return jsondata;
//						}	
//				
//						if((clientForm.get("D_EXPDT5").toString().trim().length() != 0) && (clientForm.get("D_EFFDT5").toString().trim().length() == 0)){
//							jsondata.put("status","Please fill up Effective Date 5...");
//							return jsondata;
//						}
//						
//
//				}catch(Throwable x){}
			 
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");

		    records = clientDAO.checkClientExists(clientForm);
			 
			 if(records.size()!=0){
				 jsondata.put("status","Client Already Exists ...");
				 return jsondata;
			 }

			//clientForm.put("N_INVESTMENTLIMIT",clientForm.get("N_INVESTMENTLIMIT").toString().trim().replace(",",""));
			
			clientSuccess = clientDAO.addClient(clientForm);
			clientCode = clientDAO.searchLastClientCode(clientForm);
			
			
			clientForm.put("C_CLNTCODE", clientCode);
			ServiceUtility.viewUserParameters(clientForm);
			monthlyBalancesSuccess = clientDAO.addClientInMonthlyBalances(clientForm);
			
			monthlyDCSuccess = clientDAO.addClientInMonthlyDC(clientForm);
			
			//clientForm.put("C_BLRTYPECODE",clientCode); 
			//addBLR(clientForm);
			
			

		} catch (Throwable x) {
			clientSuccess = false;
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
try {
			
			
			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientSuccess = clientDAO.updateClientFinanceInfo(clientForm);
			//System.out.print("success");
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		 if(monthlyBalancesSuccess && monthlyDCSuccess){
			 jsondata.put("status","Added Client in Monthly Balances and Monthly DC Successful ...");
			 jsondata.put("formaction","addClient");			 
		 }
		 else{
			 jsondata.put("status","Failed to Add Client in Monthly Balances / Monthly DC...");
			 return jsondata;
		 }
		
		 
		if(clientSuccess){
			
			try{
			
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(clientForm);
				ClientMaster cm = new ClientMaster(newData);
				as.addAudit(newData.get("C_USERID").toString(),"I","CLIENT",cm.toStringClient());

			}catch(Throwable x){
				x.printStackTrace();
			}
			
			jsondata.put("status","Client Add Successful ...");
			jsondata.put("clientCode",(String)clientCode);
			jsondata.put("formaction","addClient");
			
		}else{
			jsondata.put("status","Failed to Add Client...");
		}


		return jsondata;
	}

	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map updateClient(Map clientForm) {

		Map jsondata = new HashMap();
		Map newData = new HashMap();
		boolean clientSuccess = false;
		
		try {
			
			log.info("--->>> updateClient ...");
			ServiceUtility.viewUserParameters(clientForm);
			
			if(clientForm.get("C_ACCTOFFICERCODE")==null || clientForm.get("C_ACCTOFFICERCODE").toString().trim().length()==0){
				 jsondata.put("status","Account Officer is Required, Please Select One ...");
				 return jsondata;
			}
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientSuccess = clientDAO.updateClient(clientForm);
			
		} catch (Throwable x) {
			clientSuccess = false;
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		 if(clientSuccess){
				
			 try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(clientForm);
					ClientMaster cm = new ClientMaster(newData);
					as.addAudit(newData.get("C_USERID").toString(),"U","CLIENT",cm.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			 
			 jsondata.put("status","Client Update Successful ...");
			 jsondata.put("formaction","updateClient");
		 }else{
			 jsondata.put("status","Failed to Update Client ...");
		 }

		return jsondata;
	}
	
	public Map updateClientTCInfo(Map clientForm) {

		Map jsondata = new HashMap();
		Map newData = new HashMap();
		boolean clientSuccess = false;

		
	
		try {
			
			log.info("--->>> updateClient ...");
			ServiceUtility.viewUserParameters(clientForm);

			clientForm.put("N_INVESTMENTLIMIT",clientForm.get("N_INVESTMENTLIMIT").toString().trim().replace(",",""));
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientSuccess = clientDAO.updateClientTCInfo(clientForm);
			
			String old_AdvanceRatio = clientForm.get("old_N_ADVANCEDRATIO").toString();
			String AdvRatio =clientForm.get("N_ADVANCEDRATIO").toString();
			
			if(!old_AdvanceRatio.contentEquals(AdvRatio)){
				clientForm.put("n_PrevValue",old_AdvanceRatio);
				clientForm.put("n_CurValue", AdvRatio.contentEquals("0")?"":AdvRatio );
				clientForm.put("c_Charge", "AdvRatio");
				clientDAO.updateRateHistory(clientForm);
			}
			
			String N_SCR = clientForm.get("N_SCR").toString();
			String old_N_SCR = clientForm.get("old_N_SCR").toString();
			
			if(!old_N_SCR.contentEquals(N_SCR)){
				clientForm.put("n_PrevValue",old_N_SCR);
				clientForm.put("n_CurValue", N_SCR.contentEquals("0")?"":N_SCR );
				clientForm.put("c_Charge", "SCR");
				clientDAO.updateRateHistory(clientForm);
			}
			
			String N_USCR = clientForm.get("N_USCR").toString();
			String old_N_USCR = clientForm.get("old_N_USCR").toString();
			
			if(!old_N_SCR.contentEquals(N_SCR)){
				clientForm.put("n_PrevValue",old_N_USCR);
				clientForm.put("n_CurValue", N_SCR.contentEquals("0")?"":N_USCR );
				clientForm.put("c_Charge", "USCR");
				clientDAO.updateRateHistory(clientForm);
			}
			//added by CVG as of 03-18-16
			//String N_NOTARIAL = clientForm.get("N_NOTARIAL").toString();
			//String N_EXTENSION = clientForm.get("N_EXTENSION").toString();
			//clientForm.put("N_NOTARIAL", N_NOTARIAL.contentEquals("0")?"":N_NOTARIAL );
			//clientForm.put("N_EXTENSION", N_NOTARIAL.contentEquals("0")?"":N_EXTENSION );
			//clientDAO.updateRateHistory(clientForm);
			
		} catch (Throwable x) {
			clientSuccess = false;
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		 if(clientSuccess){
				
			 try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(clientForm);
					ClientMaster cm = new ClientMaster(newData);
					as.addAudit(newData.get("C_USERID").toString(),"U","CLIENT",cm.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			 
			 jsondata.put("status","Client Update Successful ...");
			 jsondata.put("formaction","updateClient");
		 }else{
			 jsondata.put("status","Failed to Update Client ...");
		 }

		return jsondata;
	}
	
	public Map updateClientFinanceInfo(Map clientForm) {

		Map jsondata = new HashMap();
		Map newData = new HashMap();
		boolean clientSuccess = false;
		
		try {
			
			log.info("--->>> updateClient ...");
			ServiceUtility.viewUserParameters(clientForm);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientSuccess = clientDAO.updateClientFinanceInfo(clientForm);
			
		} catch (Throwable x) {
			clientSuccess = false;
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		 if(clientSuccess){
				
			 try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(clientForm);
					ClientMaster cm = new ClientMaster(newData);
					as.addAudit(newData.get("C_USERID").toString(),"U","CLIENT",cm.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			 
			 jsondata.put("status","Client Update Successful ...");
			 jsondata.put("formaction","updateClient");
		 }else{
			 jsondata.put("status","Failed to Update Client ...");
		 }

		return jsondata;
	}
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map addCustomer(Map clientForm) {

		Map jsondata = new HashMap();
		Map newData = new HashMap();
		List records = new ArrayList();
		List customerCode = new ArrayList();
		
		boolean customerSuccess = false;
		boolean ccLinkSuccess = false;
		boolean clientSuccess = false;
		String customerName = "";
		
		try {
			
			//clientForm.put("C_CUSTCODE","");
			
			if(clientForm.get("C_CLNTCODE")!=null && clientForm.get("C_CLNTCODE").toString().trim().length()==0)
			{
				 jsondata.put("status","Please select a Client ...");
				 return jsondata;
			}
			
			 if(clientForm.get("C_CUSTNAME")==null || clientForm.get("C_CUSTNAME").toString().trim().length()==0){
				 jsondata.put("status","Please select a Customer ...");
				 return jsondata;
			 }
			 

			
			CustomerDAO customerDAO = (CustomerDAO)Persistence.getDAO("CustomerDAO");
			customerName = customerDAO.searchCustomerNameByCustomerCode((String)clientForm.get("C_CUSTCODE"));
			
			clientForm.put("C_CUSTNAME",customerName);
			
			System.out.println("-->> CHECK ...");
			ServiceUtility.viewUserParameters(clientForm);
			records = customerDAO.checkCustomerExists(clientForm);
			
			if(records.size()==0){
				
				clientForm.put("C_CUSTNAME",customerName);
				System.out.println("-->> HERE ...");
				ServiceUtility.viewUserParameters(clientForm);
				//customerSuccess = customerDAO.addCustomer(clientForm);
			}else{
				jsondata.put("status","Customer Already Exists ...");
				return jsondata;
			}

			//customerSuccess = customerDAO.addCustomer(clientForm);
			//if(customerSuccess){
				customerCode = customerDAO.searchCustomerByCode(clientForm);
			//}else{
				//jsondata.put("status","Failed to Add Customer ...");
				//return jsondata;
			//}
			 
			
		} catch (Throwable x) {
			customerSuccess = false;
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		try{
			
			log.info("--->>> addCustomer: "+customerSuccess + " : "+ccLinkSuccess);
			log.info("-->> CCLINK C_CUSTCODE: "+((HashMap)customerCode.get(0)).get("C_CUSTCODE"));
		
			clientForm.put("C_CUSTCODE", ((HashMap)customerCode.get(0)).get("C_CUSTCODE"));
			CCLinkDAO ccLinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
			ccLinkSuccess = ccLinkDAO.addCCLink(clientForm);
			
			 if(!ccLinkSuccess){
				 jsondata.put("status","Failed to Add Customer in CCLink ...");
				 return jsondata;			 
			 }
			 else{
				 
				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(clientForm);
					CCLinkClientMaster cm = new CCLinkClientMaster(newData,true);
					as.addAudit(newData.get("C_USERID").toString(),"I","CCLink",cm.toString());

				}catch(Throwable x){
					x.printStackTrace();
				}
				 
				 jsondata.put("status","Customer Linked Successful...");
				 jsondata.put("formaction","addCustomer");
				 return jsondata;
			 }
			
		} catch (Throwable x) {
			ccLinkSuccess = false;
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		
		
		//jsondata.put("status","Customer Link Successful...");
		jsondata.put("formaction","addCustomer");

		return jsondata;
	}

	
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map saveSchedule(Map clientForm){
		Map jsondata = new HashMap();
		Map custjsondata = new HashMap();
		
		StringBuilder s = new StringBuilder();
		boolean ccLinkSuccess = false;
		boolean success = true;
		ServiceUtility.viewUserParameters(clientForm);
		
		s.append("C_BRANCHCODE="+clientForm.get("C_BRANCHCODE").toString()).append(";C_CLNTCODE="+clientForm.get("C_CLNTCODE").toString()).append(";C_CUSTCODE="+clientForm.get("C_CUSTCODE").toString());
		
		try{
		if(clientForm.get("btn_updateCustomerPaymentSched")!=null){
			CCLinkDAO ccLinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
			ccLinkDAO.updateCollectionDetails(clientForm);
			s.append("C_COLLECTADDRESS="+clientForm.get("C_COLLECTADDRESS").toString()).append(";C_COLLECTTIME="+clientForm.get("C_COLLECTTIME").toString());
		}
		}
		catch(Throwable x){
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
			return jsondata;
		}	
		
////////////////////////////////ADD SCHEDULE
		try{
			String payment= "payment";
			System.out.print("<----------Adding Payment Schedule");
			if(clientForm.get("schedDate") !=null && !clientForm.get("schedDate").toString().contentEquals("1")){
				for(int x=1;x<Integer.parseInt(clientForm.get("schedDate").toString());x++){
					if(clientForm.get(payment.concat(String.valueOf(x))) !=null){
						clientForm.put("payment", clientForm.get(payment.concat(String.valueOf(x))));
						try{
							CCLinkDAO ccLinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
							ccLinkSuccess = ccLinkDAO.updatePaymentSchedule(clientForm);
							s.append(";Added=").append(clientForm.get("payment").toString());
								}
								catch(Exception e){}
					}}
				}
				
				
			if(!ccLinkSuccess){
				System.out.println("<----------No Schedule to add");
						 
			}
			}
			catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
				success =false;
			}
		////////////////////////////////END OF SCHEDULE ADDING
			
		///////////////////////////////REMOVING SCHEDULE 
			try{
				ccLinkSuccess = false;
				String payment= "idForRemoval";
				System.out.print("<----------Removing Payment Schedule");
				if(clientForm.get("forRemoval").toString()!=null  && !clientForm.get("forRemoval").toString().contentEquals("1")){
					for(int x=1;x<Integer.parseInt(clientForm.get("forRemoval").toString());x++){
						if(clientForm.get(payment.concat(String.valueOf(x))) !=null && !clientForm.get(payment.concat(String.valueOf(x))).toString().contentEquals("")){
							clientForm.put("Removal", Integer.parseInt(clientForm.get(payment.concat(String.valueOf(x))).toString()));
							try{
								CCLinkDAO ccLinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
								ccLinkSuccess = ccLinkDAO.removePaymentSchedule(clientForm);
								s.append(";Removed=").append(clientForm.get("Removal").toString());
								}
									catch(Exception e){}
						}
					  }
				 }
					
					
				if(!ccLinkSuccess){
					System.out.println("<----------No Schedule to remove");							 
				}
				}
				catch (Throwable x) {
					jsondata.put("status", x.getMessage());
					x.printStackTrace();
					success =false;
				}
		///////////////////////////////END OF SCHEDULE REMOVAL	
				if(success){
					try{
						jsondata.put("status","Schedule Updated");
						if(!s.toString().contentEquals("")){
							AuditService as = AuditService.getInstance();						
							as.addAudit(clientForm.get("C_USERID").toString(),"U","CCLINKSCHEDULE",s.toString());
						}
					}catch(Throwable x){
						x.printStackTrace();
					}
					
					if(clientForm.containsKey("updateAllCCLinkDetails")){
						jsondata = updateCustomer(clientForm);
						
					}
					
					jsondata.put("formaction","updateCustomerSchedule");
				}
				else
					jsondata.put("status","Schedule Adding Failed");
		return jsondata;
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map updateCustomer(Map clientForm) {
		System.out.print("FDFD");
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		List records = new ArrayList();
	
		
		Map cclinkDates = new HashMap();
		int cclinkCount = 0;
		boolean customerSuccess = false;
		boolean ccLinkSuccess = false;
		

		try {
			
			log.info("--->>> XXX");
			
			ServiceUtility.viewUserParameters(clientForm);

			
			if((clientForm.get("N_CCLIMIT").toString().trim().length() == 0)){
				jsondata.put("status","Please fill up Funding Limit 1...");
				return jsondata;
			}

			if((clientForm.get("D_CCAPDATE").toString().trim().length() == 0)){
				jsondata.put("status","Please fill up Application Date 1...");
				return jsondata;
			}	
			
			if((clientForm.get("D_CCEXDATE").toString().trim().length() == 0)){
				jsondata.put("status","Please fill up Expiry Date 1...");
				return jsondata;
			}		
			
			clientForm.put("N_CCLIMIT",clientForm.get("N_CCLIMIT").toString().trim().replace(",",""));
			clientForm.put("N_CCLIMIT1",clientForm.get("N_CCLIMIT1").toString().trim().replace(",",""));

			if((clientForm.get("D_CCAPDATE").toString().trim().length() != 0) && (clientForm.get("D_CCEXDATE").toString().trim().length() == 0)){
				jsondata.put("status","Please fill up Expiry Date 1...");
				return jsondata;
			}


			if((clientForm.get("D_CCEXDATE").toString().trim().length() != 0) && (clientForm.get("D_CCAPDATE").toString().trim().length() == 0)){
				jsondata.put("status","Please fill up Application Date 1...");
				return jsondata;
			}				 

			if((clientForm.get("D_CCAPDATE1").toString().trim().length() != 0) && (clientForm.get("D_CCEXDATE1").toString().trim().length() == 0)){
				jsondata.put("status","Please fill up Expiry Date 2...");
				return jsondata;
			}


			if((clientForm.get("D_CCEXDATE1").toString().trim().length() != 0) && (clientForm.get("D_CCAPDATE1").toString().trim().length() == 0)){
				jsondata.put("status","Please fill up Application Date 2...");
				return jsondata;
			}
			
			
			if(clientForm.containsKey("D_CCAPDATE") && clientForm.get("D_CCAPDATE")!=null && clientForm.get("D_CCAPDATE").toString().trim().length()!=0){
				cclinkCount =  cclinkCount +1;
			}

			if(clientForm.containsKey("D_CCAPDATE1") && clientForm.get("D_CCAPDATE1")!=null && clientForm.get("D_CCAPDATE1").toString().trim().length()!=0){
				cclinkCount =  cclinkCount +1;
			}
			
			try{
				
						cclinkDates.put("D_CCAPDATE1",new Date(clientForm.get("D_CCAPDATE").toString()).getTime());
						cclinkDates.put("D_CCEXDATE1", new Date(clientForm.get("D_CCEXDATE").toString()).getTime());

						cclinkDates.put("D_CCAPDATE2",new Date(clientForm.get("D_CCAPDATE1").toString()).getTime());
						cclinkDates.put("D_CCEXDATE2", new Date(clientForm.get("D_CCEXDATE1").toString()).getTime());



						for(int cnt=1;cnt<=cclinkCount;cnt++){
							
							for(int innerCnt=1;innerCnt<=cclinkCount;innerCnt++){
								
								if(cnt!=innerCnt){
									if(((Long)cclinkDates.get("D_CCAPDATE"+cnt)) >= ((Long)cclinkDates.get("D_CCAPDATE"+innerCnt)) && ((Long)cclinkDates.get("D_CCAPDATE"+cnt)) <= ((Long)cclinkDates.get("D_CCEXDATE"+innerCnt))){
										 //System.out.println("--->>> CONFLICT ON: "+cnt);
										 jsondata.put("status","Application Date "+cnt+" had Conflict with other Application/Expiry Dates,CCLink Update Failed ...");
										 jsondata.put("formaction","updateCustomer");
										 return jsondata;
									}
			
									if(((Long)cclinkDates.get("D_CCEXDATE"+cnt)) >= ((Long)cclinkDates.get("D_CCAPDATE"+innerCnt)) && ((Long)cclinkDates.get("D_CCEXDATE"+cnt)) <= ((Long)cclinkDates.get("D_CCEXDATE"+innerCnt))){
										 //System.out.println("--->>> CONFLICT ON: "+cnt);
										 jsondata.put("status","Expiry Date "+cnt+" had Conflict with Application/Expiry Dates,CCLink Update Failed ...");								 
										 jsondata.put("formaction","updateCustomer");
										 return jsondata;
			
									}
			
								
								}
								
							}
						}

			
			}catch(Throwable x){
				x.printStackTrace();
			}	
			
			
			/*
			clientForm.put("C_BANKCODE", clientForm.get("C_BANKCODE2").toString());
			 
			 CustomerDAO customerDAO = (CustomerDAO)Persistence.getDAO("CustomerDAO");
			 customerSuccess = customerDAO.updateCustomer(clientForm);
			 
			if(!customerSuccess){
				jsondata.put("status","Failed to Update Customer ...");
				return jsondata;
			}
			*/
			
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
				
		try{
			
			
			CCLinkDAO ccLinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
			ccLinkSuccess = ccLinkDAO.updateCCLink(clientForm);
			
			boolean ir = ccLinkDAO.updateCustIneligible(clientForm);
			log.info("updateCustIneligible:"+ir);
			ir = ccLinkDAO.updateClientIneligible(clientForm);
			log.info("updateClientIneligible:"+ir);
			
			if(!ccLinkSuccess){
				jsondata.put("status","Failed to Update Customer in CCLink ...");
				return jsondata;			 
			}else{
				
				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(clientForm);
					CCLinkClientMaster cm = new CCLinkClientMaster(newData);
					as.addAudit(newData.get("C_USERID").toString(),"U","CCLink",cm.toString());

				}catch(Throwable x){
					x.printStackTrace();
				}
				
				jsondata.put("status","Customer Update Successful...");
				jsondata.put("formaction","updateCustomer");

				return jsondata;
			}
			 
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		jsondata.put("status","Customer Update Successful...");
		jsondata.put("formaction","updateCustomer");

		return jsondata;
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////

	public Map addBLR(Map clientForm) {

		Map jsondata = new HashMap();
		Map newData = new HashMap();
		boolean blrSuccess = false;
		
		Map blrDates = new HashMap();
		int blrCount = 0;
		
		boolean flagBlr1 = false;
		boolean flagBlr2 = false;
		boolean flagBlr3 = false;
		boolean flagBlr4 = false;
		boolean flagBlr5 = false;

		long blrEff1 = 0;
		long blrExp1 = 0;

		long blrEff2 = 0;
		long blrExp2 = 0;

		long blrEff3 = 0;
		long blrExp3 = 0;

		long blrEff4 = 0;
		long blrExp4 = 0;

		long blrEff5 = 0;
		long blrExp5 = 0;
		
		//////////////////////////////////////////////////

		try{
				if((clientForm.get("D_EFFDT1").toString().trim().length() != 0) && (clientForm.get("D_EXPDT1").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 1...");
					return jsondata;
				}
		
				if((clientForm.get("D_EFFDT2").toString().trim().length() != 0) && (clientForm.get("D_EXPDT2").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 2...");
					return jsondata;
				}
		
				if((clientForm.get("D_EFFDT3").toString().trim().length() != 0) && (clientForm.get("D_EXPDT3").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 3...");
					return jsondata;
				}
		
				if((clientForm.get("D_EFFDT4").toString().trim().length() != 0) && (clientForm.get("D_EXPDT4").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 4...");
					return jsondata;
				}
		
				if((clientForm.get("D_EFFDT5").toString().trim().length() != 0) && (clientForm.get("D_EXPDT5").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 5...");
					return jsondata;
				}	
		
				//////////////////////////////////////////////////
		
				if((clientForm.get("D_EXPDT1").toString().trim().length() != 0) && (clientForm.get("D_EFFDT1").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 1...");
					return jsondata;
				}			
		
				if((clientForm.get("D_EXPDT2").toString().trim().length() != 0) && (clientForm.get("D_EFFDT2").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 2...");
					return jsondata;
				}	
		
				if((clientForm.get("D_EXPDT3").toString().trim().length() != 0) && (clientForm.get("D_EFFDT3").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 3...");
					return jsondata;
				}
		
				if((clientForm.get("D_EXPDT4").toString().trim().length() != 0) && (clientForm.get("D_EFFDT4").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 4...");
					return jsondata;
				}	
		
				if((clientForm.get("D_EXPDT5").toString().trim().length() != 0) && (clientForm.get("D_EFFDT5").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 5...");
					return jsondata;
				}
				

		}catch(Throwable x){}	
		
		////////////////////////////////////////////////////////////////////////////////////
		
		if(clientForm.containsKey("D_EFFDT1") && clientForm.get("D_EFFDT1")!=null && clientForm.get("D_EFFDT1").toString().trim().length()!=0){
			blrCount =  blrCount +1;
		}

		if(clientForm.containsKey("D_EFFDT2") && clientForm.get("D_EFFDT2")!=null && clientForm.get("D_EFFDT2").toString().trim().length()!=0){
			blrCount =  blrCount +1;
		}

		if(clientForm.containsKey("D_EFFDT3") && clientForm.get("D_EFFDT3")!=null && clientForm.get("D_EFFDT3").toString().trim().length()!=0){
			blrCount =  blrCount +1;
		}

		if(clientForm.containsKey("D_EFFDT4") && clientForm.get("D_EFFDT4")!=null && clientForm.get("D_EFFDT4").toString().trim().length()!=0){
			blrCount =  blrCount +1;
		}

		if(clientForm.containsKey("D_EFFDT5") && clientForm.get("D_EFFDT5")!=null && clientForm.get("D_EFFDT5").toString().trim().length()!=0){
			blrCount =  blrCount +1;
		}

		////////////////////////////////////////////////////////////////////////////////////
	
		try{
			
			blrEff1 = new Date(clientForm.get("D_EFFDT1").toString()).getTime();
			blrExp1 = new Date(clientForm.get("D_EXPDT1").toString()).getTime();
			
			flagBlr1 = true;
			
			blrDates.put("D_EFFDT1", blrEff1);
			blrDates.put("D_EXPDT1", blrExp1);
			
		}catch(Throwable x){
			flagBlr1 = false;
		}
		
		/*
		System.out.println("-->> blrEff1: "+blrEff1);
		System.out.println("-->> blrExp1: "+blrExp1);
		System.out.println("-->> flagBlr1: "+flagBlr1);
		*/
		
		////////////////////////////////////////////////////////////////////////////////////
		
		try{
			
			blrEff2 = new Date(clientForm.get("D_EFFDT2").toString()).getTime();
			blrExp2 = new Date(clientForm.get("D_EXPDT2").toString()).getTime();
			
			flagBlr2 = true;
			
			blrDates.put("D_EFFDT2", blrEff2);
			blrDates.put("D_EXPDT2", blrExp2);				
			
		}catch(Throwable x){
			flagBlr2 = false;
		}
		
		/*
		System.out.println("-->> blrEff2: "+blrEff2);
		System.out.println("-->> blrExp2: "+blrExp2);
		System.out.println("-->> flagBlr2: "+flagBlr2);			
		*/
		
		////////////////////////////////////////////////////////////////////////////////////
		
		try{
			
			blrEff3 = new Date(clientForm.get("D_EFFDT3").toString()).getTime();
			blrExp3 = new Date(clientForm.get("D_EXPDT3").toString()).getTime();
			
			flagBlr3 = true;
			
			blrDates.put("D_EFFDT3", blrEff3);
			blrDates.put("D_EXPDT3", blrExp3);
			
		}catch(Throwable x){
			flagBlr3 = false;
		}
		
		/*
		System.out.println("-->> blrEff3: "+blrEff3);
		System.out.println("-->> blrExp3: "+blrExp3);
		System.out.println("-->> flagBlr3: "+flagBlr3);			
		*/
		
		////////////////////////////////////////////////////////////////////////////////////
		
		try{
			
			blrEff4 = new Date(clientForm.get("D_EFFDT4").toString()).getTime();
			blrExp4 = new Date(clientForm.get("D_EXPDT4").toString()).getTime();
			
			flagBlr4 = true;
			
			blrDates.put("D_EFFDT4", blrEff4);
			blrDates.put("D_EXPDT4", blrExp4);
			
		}catch(Throwable x){
			flagBlr4 = false;
		}
		
		/*
		System.out.println("-->> blrEff4: "+blrEff4);
		System.out.println("-->> blrExp4: "+blrExp4);
		System.out.println("-->> flagBlr4: "+flagBlr4);			
		*/
		
		////////////////////////////////////////////////////////////////////////////////////

		try{
			
			blrEff5 = new Date(clientForm.get("D_EFFDT5").toString()).getTime();
			blrExp5 = new Date(clientForm.get("D_EXPDT5").toString()).getTime();
			
			flagBlr5 = true;
			
			blrDates.put("D_EFFDT5", blrEff5);
			blrDates.put("D_EXPDT5", blrExp5);
			
		}catch(Throwable x){
			flagBlr5 = false;
		}
		
		
		/*
		System.out.println("-->> blrEff5: "+blrEff5);
		System.out.println("-->> blrExp5: "+blrExp5);
		System.out.println("-->> flagBlr5: "+flagBlr5);			
		*/
		////////////////////////////////////////////////////////////////////////////////////
		
			for(int cnt=1;cnt<=blrCount;cnt++){
				
					for(int innerCnt=1;innerCnt<=blrCount;innerCnt++){
						
						if(cnt!=innerCnt){
							if(((Long)blrDates.get("D_EFFDT"+cnt)) >= ((Long)blrDates.get("D_EFFDT"+innerCnt)) && ((Long)blrDates.get("D_EFFDT"+cnt)) <= ((Long)blrDates.get("D_EXPDT"+innerCnt))){
								 //System.out.println("--->>> CONFLICT ON: "+cnt);
								 jsondata.put("status","Effective Date "+cnt+" had Conflict on other Dates,BLR Add Failed ...");
								 jsondata.put("formaction","addBLR");
								 return jsondata;
							}
	
							if(((Long)blrDates.get("D_EXPDT"+cnt)) >= ((Long)blrDates.get("D_EFFDT"+innerCnt)) && ((Long)blrDates.get("D_EXPDT"+cnt)) <= ((Long)blrDates.get("D_EXPDT"+innerCnt))){
								 //System.out.println("--->>> CONFLICT ON: "+cnt);
								 jsondata.put("status","Expiry Date "+cnt+" had Conflict on other Dates,BLR Add Failed ...");								 
								 jsondata.put("formaction","addBLR");
								 return jsondata;
	
							}
	
						
						}
						
					}
			}
		
		
		
		try {
			
			log.info("--->>> addBLR ...");
			ServiceUtility.viewUserParameters(clientForm);

			BLRFileDAO addBLRFileDAO = (BLRFileDAO) Persistence.getDAO("BLRFileDAO");
			blrSuccess = addBLRFileDAO.addBLRFile(clientForm);

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		 if(blrSuccess){
			 
			try{
				
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(clientForm);
				BLRFileClientMaster blrfile = new BLRFileClientMaster(newData);
				as.addAudit(newData.get("C_USERID").toString(),"I","BLRFile",blrfile.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			 
			 jsondata.put("status","BLR Add Successful ...");
			 jsondata.put("formaction","addBLR");
		 }else{
			 jsondata.put("status","Failed to Add BLR ...");
		 }
		
		return jsondata;
	}

	
	
//////////////////////////////////////////////////////////////////////////////////////////////

	public Map updateBLR(Map clientForm) {

		Map jsondata = new HashMap();
		Map newData = new HashMap();
		Map blrDates = new HashMap();
		List<Map<String,String>> prevValList= new ArrayList<Map<String,String>>();
		boolean blrSuccess = false;
		int blrCount = 0;

		boolean flagBlr1 = false;
		boolean flagBlr2 = false;
		boolean flagBlr3 = false;
		boolean flagBlr4 = false;
		boolean flagBlr5 = false;

		long blrEff1 = 0;
		long blrExp1 = 0;

		long blrEff2 = 0;
		long blrExp2 = 0;

		long blrEff3 = 0;
		long blrExp3 = 0;

		long blrEff4 = 0;
		long blrExp4 = 0;

		long blrEff5 = 0;
		long blrExp5 = 0;

		String old_N_BLR1 = clientForm.get("old_N_BLR1").toString();
		String old_N_BLR2 =	clientForm.get("old_N_BLR2").toString();
		String old_N_BLR3 =	clientForm.get("old_N_BLR3").toString();
		String old_N_BLR4 =	clientForm.get("old_N_BLR4").toString();
		String old_N_BLR5 =	clientForm.get("old_N_BLR5").toString();
		
		String old_D_EFFDT1 =	clientForm.get("old_D_EFFDT1").toString();
		String old_D_EFFDT2 =	clientForm.get("old_D_EFFDT2").toString();
		String old_D_EFFDT3 =	clientForm.get("old_D_EFFDT3").toString();
		String old_D_EFFDT4 =	clientForm.get("old_D_EFFDT4").toString();
		String old_D_EFFDT5 =	clientForm.get("old_D_EFFDT5").toString();
		
		String old_D_EXPDT1 =	clientForm.get("old_D_EXPDT1").toString();
		String old_D_EXPDT2 =	clientForm.get("old_D_EXPDT2").toString();
		String old_D_EXPDT3 =	clientForm.get("old_D_EXPDT3").toString();
		String old_D_EXPDT4 =	clientForm.get("old_D_EXPDT4").toString();
		String old_D_EXPDT5 =	clientForm.get("old_D_EXPDT5").toString();
		
		String N_BLR1 = clientForm.get("N_BLR1").toString();
		String N_BLR2 =	clientForm.get("N_BLR2").toString();
		String N_BLR3 =	clientForm.get("N_BLR3").toString();
		String N_BLR4 =	clientForm.get("N_BLR4").toString();
		String N_BLR5 =	clientForm.get("N_BLR5").toString();
		
		String D_EFFDT1 =	clientForm.get("D_EFFDT1").toString();
		String D_EFFDT2 =	clientForm.get("D_EFFDT2").toString();
		String D_EFFDT3 =	clientForm.get("D_EFFDT3").toString();
		String D_EFFDT4 =	clientForm.get("D_EFFDT4").toString();
		String D_EFFDT5 =	clientForm.get("D_EFFDT5").toString();
		
		String D_EXPDT1 =	clientForm.get("D_EXPDT1").toString();
		String D_EXPDT2 =	clientForm.get("D_EXPDT2").toString();
		String D_EXPDT3 =	clientForm.get("D_EXPDT3").toString();
		String D_EXPDT4 =	clientForm.get("D_EXPDT4").toString();
		String D_EXPDT5 =	clientForm.get("D_EXPDT5").toString();
		Map<String,String> valueMap= new HashMap<String,String>();
		if(!old_N_BLR1.contentEquals(N_BLR1)||!old_D_EFFDT1.contentEquals(D_EFFDT1)||!old_D_EXPDT1.contentEquals(D_EXPDT1)){
			valueMap = new HashMap<String,String>();
			valueMap.put("d_PrevBLRFrom", old_D_EFFDT1);
			valueMap.put("d_PrevBLRTo", old_D_EXPDT1);
			valueMap.put("n_BLRNo", "1");
			valueMap.put("n_PrevValue", old_N_BLR1);
			valueMap.put("n_CurValue", N_BLR1);
			valueMap.put("d_CurBLRFrom", D_EFFDT1);
			valueMap.put("d_CurBLRTo", D_EXPDT1);
			prevValList.add(valueMap);
			
		}
		if(!old_N_BLR2.contentEquals(N_BLR2)||!old_D_EFFDT2.contentEquals(D_EFFDT2)||!old_D_EXPDT2.contentEquals(D_EXPDT2)){
			valueMap = new HashMap<String,String>();
			valueMap.put("d_PrevBLRFrom", old_D_EFFDT2);
			valueMap.put("d_PrevBLRTo", old_D_EXPDT2);
			valueMap.put("n_BLRNo", "2");
			valueMap.put("n_PrevValue", old_N_BLR2);
			valueMap.put("n_CurValue", N_BLR2);
			valueMap.put("d_CurBLRFrom", D_EFFDT2);
			valueMap.put("d_CurBLRTo", D_EXPDT2);
			prevValList.add(valueMap);
		}
		if(!old_N_BLR3.contentEquals(N_BLR3)||!old_D_EFFDT3.contentEquals(D_EFFDT3)||!old_D_EXPDT3.contentEquals(D_EXPDT3)){
			valueMap = new HashMap<String,String>();
			valueMap.put("d_PrevBLRFrom", old_D_EFFDT3);
			valueMap.put("d_PrevBLRTo", old_D_EXPDT3);
			valueMap.put("n_BLRNo", "3");
			valueMap.put("n_PrevValue", old_N_BLR3);
			valueMap.put("n_CurValue", N_BLR3);
			valueMap.put("d_CurBLRFrom", D_EFFDT3);
			valueMap.put("d_CurBLRTo", D_EXPDT3);
			prevValList.add(valueMap);
		}
		if(!old_N_BLR4.contentEquals(N_BLR4)||!old_D_EFFDT4.contentEquals(D_EFFDT4)||!old_D_EXPDT4.contentEquals(D_EXPDT4)){
			valueMap = new HashMap<String,String>();
			valueMap.put("d_PrevBLRFrom", old_D_EFFDT4);
			valueMap.put("d_PrevBLRTo", old_D_EXPDT4);
			valueMap.put("n_BLRNo", "4");
			valueMap.put("n_PrevValue", old_N_BLR4);
			valueMap.put("n_CurValue", N_BLR4);
			valueMap.put("d_CurBLRFrom", D_EFFDT4);
			valueMap.put("d_CurBLRTo", D_EXPDT4);
			prevValList.add(valueMap);
		}
		if(!old_N_BLR5.contentEquals(N_BLR5)||!old_D_EFFDT5.contentEquals(D_EFFDT5)||!old_D_EXPDT5.contentEquals(D_EXPDT5)){
			valueMap = new HashMap<String,String>();
			valueMap.put("d_PrevBLRFrom", old_D_EFFDT5);
			valueMap.put("d_PrevBLRTo", old_D_EXPDT5);
			valueMap.put("n_BLRNo", "5");
			valueMap.put("n_PrevValue", old_N_BLR5);
			valueMap.put("n_CurValue", N_BLR5);
			valueMap.put("d_CurBLRFrom", D_EFFDT5);
			valueMap.put("d_CurBLRTo", D_EXPDT5);
			prevValList.add(valueMap);
		}
		//////////////////////////////////////////////////

		try{
				if((clientForm.get("D_EFFDT1").toString().trim().length() != 0) && (clientForm.get("D_EXPDT1").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 1...");
					return jsondata;
				}
		
				if((clientForm.get("D_EFFDT2").toString().trim().length() != 0) && (clientForm.get("D_EXPDT2").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 2...");
					return jsondata;
				}
		
				if((clientForm.get("D_EFFDT3").toString().trim().length() != 0) && (clientForm.get("D_EXPDT3").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 3...");
					return jsondata;
				}
		
				if((clientForm.get("D_EFFDT4").toString().trim().length() != 0) && (clientForm.get("D_EXPDT4").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 4...");
					return jsondata;
				}
		
				if((clientForm.get("D_EFFDT5").toString().trim().length() != 0) && (clientForm.get("D_EXPDT5").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Expiry Date 5...");
					return jsondata;
				}	
		
				//////////////////////////////////////////////////
		
				if((clientForm.get("D_EXPDT1").toString().trim().length() != 0) && (clientForm.get("D_EFFDT1").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 1...");
					return jsondata;
				}			
		
				if((clientForm.get("D_EXPDT2").toString().trim().length() != 0) && (clientForm.get("D_EFFDT2").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 2...");
					return jsondata;
				}	
		
				if((clientForm.get("D_EXPDT3").toString().trim().length() != 0) && (clientForm.get("D_EFFDT3").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 3...");
					return jsondata;
				}
		
				if((clientForm.get("D_EXPDT4").toString().trim().length() != 0) && (clientForm.get("D_EFFDT4").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 4...");
					return jsondata;
				}	
		
				if((clientForm.get("D_EXPDT5").toString().trim().length() != 0) && (clientForm.get("D_EFFDT5").toString().trim().length() == 0)){
					jsondata.put("status","Please fill up Effective Date 5...");
					return jsondata;
				}
				
		
		}catch(Throwable x){}
		
		
		
			////////////////////////////////////////////////////////////////////////////////////
		
			if(clientForm.containsKey("D_EFFDT1") && clientForm.get("D_EFFDT1")!=null && clientForm.get("D_EFFDT1").toString().trim().length()!=0){
				blrCount = 1;
			}

			if(clientForm.containsKey("D_EFFDT2") && clientForm.get("D_EFFDT2")!=null && clientForm.get("D_EFFDT2").toString().trim().length()!=0){
				blrCount =  2;
			}

			if(clientForm.containsKey("D_EFFDT3") && clientForm.get("D_EFFDT3")!=null && clientForm.get("D_EFFDT3").toString().trim().length()!=0){
				blrCount =  3;
			}

			if(clientForm.containsKey("D_EFFDT4") && clientForm.get("D_EFFDT4")!=null && clientForm.get("D_EFFDT4").toString().trim().length()!=0){
				blrCount =  4;
			}

			if(clientForm.containsKey("D_EFFDT5") && clientForm.get("D_EFFDT5")!=null && clientForm.get("D_EFFDT5").toString().trim().length()!=0){
				blrCount =  5;
			}
		

			////////////////////////////////////////////////////////////////////////////////////
		
		
			try{
				
				blrEff1 = new Date(clientForm.get("D_EFFDT1").toString()).getTime();
				blrExp1 = new Date(clientForm.get("D_EXPDT1").toString()).getTime();
				
				flagBlr1 = true;
				
				blrDates.put("D_EFFDT1", blrEff1);
				blrDates.put("D_EXPDT1", blrExp1);
				
			}catch(Throwable x){
				flagBlr1 = false;
			}
			
			/*
			System.out.println("-->> blrEff1: "+blrEff1);
			System.out.println("-->> blrExp1: "+blrExp1);
			System.out.println("-->> flagBlr1: "+flagBlr1);
			*/
			
			////////////////////////////////////////////////////////////////////////////////////
			
			try{
				
				blrEff2 = new Date(clientForm.get("D_EFFDT2").toString()).getTime();
				blrExp2 = new Date(clientForm.get("D_EXPDT2").toString()).getTime();
				
				flagBlr2 = true;
				
				blrDates.put("D_EFFDT2", blrEff2);
				blrDates.put("D_EXPDT2", blrExp2);				
				
			}catch(Throwable x){
				flagBlr2 = false;
			}
			
			/*
			System.out.println("-->> blrEff2: "+blrEff2);
			System.out.println("-->> blrExp2: "+blrExp2);
			System.out.println("-->> flagBlr2: "+flagBlr2);			
			*/
			
			////////////////////////////////////////////////////////////////////////////////////
			
			try{
				
				blrEff3 = new Date(clientForm.get("D_EFFDT3").toString()).getTime();
				blrExp3 = new Date(clientForm.get("D_EXPDT3").toString()).getTime();
				
				flagBlr3 = true;
				
				blrDates.put("D_EFFDT3", blrEff3);
				blrDates.put("D_EXPDT3", blrExp3);
				
			}catch(Throwable x){
				flagBlr3 = false;
			}
			
			/*
			System.out.println("-->> blrEff3: "+blrEff3);
			System.out.println("-->> blrExp3: "+blrExp3);
			System.out.println("-->> flagBlr3: "+flagBlr3);			
			*/
			
			////////////////////////////////////////////////////////////////////////////////////
			
			try{
				
				blrEff4 = new Date(clientForm.get("D_EFFDT4").toString()).getTime();
				blrExp4 = new Date(clientForm.get("D_EXPDT4").toString()).getTime();
				
				flagBlr4 = true;
				
				blrDates.put("D_EFFDT4", blrEff4);
				blrDates.put("D_EXPDT4", blrExp4);
				
			}catch(Throwable x){
				flagBlr4 = false;
			}
			
			/*
			System.out.println("-->> blrEff4: "+blrEff4);
			System.out.println("-->> blrExp4: "+blrExp4);
			System.out.println("-->> flagBlr4: "+flagBlr4);			
			*/
			
			////////////////////////////////////////////////////////////////////////////////////

			try{
				
				blrEff5 = new Date(clientForm.get("D_EFFDT5").toString()).getTime();
				blrExp5 = new Date(clientForm.get("D_EXPDT5").toString()).getTime();
				
				flagBlr5 = true;
				
				blrDates.put("D_EFFDT5", blrEff5);
				blrDates.put("D_EXPDT5", blrExp5);
				
			}catch(Throwable x){
				flagBlr5 = false;
			}
			
			
			/*
			System.out.println("-->> blrEff5: "+blrEff5);
			System.out.println("-->> blrExp5: "+blrExp5);
			System.out.println("-->> flagBlr5: "+flagBlr5);			
			*/
			////////////////////////////////////////////////////////////////////////////////////
			
					for(int cnt=1;cnt<=blrCount;cnt++){
						
							for(int innerCnt=1;innerCnt<=blrCount;innerCnt++){
								
								try{
									
									System.out.println("--->>> cnt: "+cnt+" innerCnt:"+innerCnt);
									if(cnt!=innerCnt){
										if(((Long)blrDates.get("D_EFFDT"+cnt)) >= ((Long)blrDates.get("D_EFFDT"+innerCnt)) && ((Long)blrDates.get("D_EFFDT"+cnt)) <= ((Long)blrDates.get("D_EXPDT"+innerCnt))){
											 //System.out.println("--->>> CONFLICT ON: "+cnt);
											 jsondata.put("status","Effective Date "+cnt+" had Conflict on other Dates,BLR Update Failed ...");
											 jsondata.put("formaction","updateBLR");
											 return jsondata;
										}
			
										if(((Long)blrDates.get("D_EXPDT"+cnt)) >= ((Long)blrDates.get("D_EFFDT"+innerCnt)) && ((Long)blrDates.get("D_EXPDT"+cnt)) <= ((Long)blrDates.get("D_EXPDT"+innerCnt))){
											 //System.out.println("--->>> CONFLICT ON: "+cnt);
											 jsondata.put("status","Expiry Date "+cnt+" had Conflict on other Dates,BLR Update Failed ...");								 
											 jsondata.put("formaction","updateBLR");
											 return jsondata;
			
										}
			
									
									}
								
								}catch(Throwable x){}
							}
					}
			
			
		
		try {
			
			log.info("--->>> updateBLR ...");
			ServiceUtility.viewUserParameters(clientForm);

			BLRFileDAO addBLRFileDAO = (BLRFileDAO) Persistence.getDAO("BLRFileDAO");
			blrSuccess = addBLRFileDAO.updateBLRFile(clientForm);
			ClientDAO updateDiscCharge = (ClientDAO) Persistence.getDAO("ClientDAO");
			
			for(int x=0;x<=prevValList.size()-1;x++){
				prevValList.get(x).put("C_CLNTCODE", clientForm.get("C_BLRTYPECODE").toString());
				prevValList.get(x).put("c_Charge",	"BLR");
				updateDiscCharge.updateRateHistory(prevValList.get(x));
			}
		} catch (Throwable x) {
			blrSuccess = false;
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		Boolean updateDC;//Update Discount Charge
		try{
			String old_N_DCR = clientForm.containsKey("old_N_DCR")?clientForm.get("old_N_DCR").toString():null;
			String N_DCR = clientForm.containsKey("N_DCR")?clientForm.get("N_DCR").toString():null;
			
			clientForm.put("old_N_DCR", old_N_DCR.contentEquals("")?null:old_N_DCR);
			clientForm.put("N_DCR", N_DCR.contentEquals("")?null:N_DCR);
			updateDC=false;
			
				ClientDAO updateDiscCharge = (ClientDAO) Persistence.getDAO("ClientDAO");
				updateDC = updateDiscCharge.updateDiscountCharge(clientForm);
				updateDC=true;
			
			if(!old_N_DCR.contentEquals(N_DCR)){
				clientForm.put("n_PrevValue", old_N_DCR);
				clientForm.put("n_CurValue", N_DCR);
				clientForm.put("c_Charge", "DCR");
				updateDiscCharge.updateRateHistory(clientForm);
			}
		}catch(Exception e){
			updateDC=false;
			jsondata.put("status", e.getMessage());
			e.printStackTrace();
		}
		
		
		
		 if(blrSuccess && updateDC){
			 
			try{
				
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(clientForm);
				BLRFileClientMaster blrfile = new BLRFileClientMaster(newData);
				as.addAudit(newData.get("C_USERID").toString(),"U","BLRFile",blrfile.toString().concat(";N_DCR=").concat(clientForm.get("N_DCR").toString()));

			}catch(Throwable x){
				x.printStackTrace();
			}			 
			 
			 jsondata.put("status","BLR Update Successful ...");
			 jsondata.put("formaction","updateBLR");
		 }else{
			 jsondata.put("status","Failed to Update BLR ...");
		 }
		
			
			
			
		return jsondata;
	}

	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchClientByCustomer(Map clientForm) {

		Map jsondata = new HashMap();
		// clientForm.put("C_CUSTCODE" , "CUS01");
		CCLinkDAO ccLinkDAO = (CCLinkDAO) Persistence.getDAO("CCLinkDAO");
		List ccLinkResult = ccLinkDAO.searchCCLinkByCode(clientForm);
		Iterator iter = ccLinkResult.iterator();
		if (ccLinkResult.size() > 0) {
			StringBuilder cClntCodeArr = new StringBuilder("(");
			while (iter.hasNext()) {
				Map ccLink = (HashMap) iter.next();
				cClntCodeArr.append("'").append(
						ccLink.get("C_CLNTCODE").toString()).append("'")
						.append(",");
			}
			String cClntCodeStr = cClntCodeArr.toString();
			cClntCodeStr = cClntCodeStr.substring(0, cClntCodeStr.length() - 1)
					+ ")";

			clientForm.put("C_CLNTCODEARR", cClntCodeStr);
		}

		ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
		List lClient = clientDAO.searchClientByCode(clientForm);
		if ((lClient != null) && (lClient.size() > 0)) {
			// jsondata = JQGridJSONFormatter.formatDataToJSON(lClient,
			// ((String)clientForm.get("records")),((String)clientForm.get("page")),((String)clientForm.get("total")));
			jsondata = JQGridJSONFormatter
					.formatDataToJSON(lClient, "", "", "");
		} else {
			jsondata.put("status", "searchBank Failed ... ");
		}

		log.info("--->> searchClient RECORD SIZE: " + lClient.size());
		return jsondata;
	}

	
//////////////////////////////////////////////////////////////////////////////////////////////

	public boolean updateFIUTransAmount(Map receiptsForm) {
		boolean success = false;
		log.debug("updateFIUTransAmount");
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			String addDesc = receiptsForm.get("DESCRIPTION") != null ? receiptsForm.get("DESCRIPTION").toString().trim() : "";
			double receiptAmount = ((String) receiptsForm.get("N_RECEIPTAMT") != null ? Double.parseDouble((String) receiptsForm.get("N_RECEIPTAMT")) : 0);
			double opAmount  = ((String) receiptsForm.get("N_OPAMT") != null ? Double.parseDouble((String) receiptsForm.get("N_OPAMT")) : 0);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			log.info("lSize: " + lClientTransAmount.size());
			
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			//double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN").toString() !=null ? mClient.get("N_FIUTRAN").toString() : "0");			
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING").toString() !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			
			//nFiuTran = nFiuTran - receiptAmount;
			receiptAmount = (receiptAmount * ((100 - nAdvancedRatio)/100));
			log.info("receiptAmount: " + receiptAmount);
			log.info("opAmount: " + opAmount);
			log.info("nForClearing: " + nForClearing);
			nForClearing = nForClearing - receiptAmount - opAmount;			
			
			//receiptsForm.put("N_FIUTRAN", nFiuTran);			
			receiptsForm.put("N_FORCLEARING", nForClearing);
			
			success = clientDAO.updateFIUTransAmount(receiptsForm);	
			if (success) {
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);				
				//description.append(";N_FIUTRAN=").append(nFiuTran);				
				description.append(";N_FORCLEARING=").append(nForClearing);
				description.append(addDesc);
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());				
			}
			
		}
		catch (Throwable x) {
			x.printStackTrace();
		}
		return success;		
	}

	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public synchronized boolean updateClientTransAmountForCN(Map receiptsForm) {
		Map jsonData = new HashMap();
		boolean success = false;
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			String receiptType = ((String) receiptsForm.get("C_RECEIPTTYPE") != null ? (String) receiptsForm.get("C_RECEIPTTYPE") : "").trim();
			double checkAmount = ((String) receiptsForm.get("N_CHECKAMOUNT") != null ? Double.parseDouble((String) receiptsForm.get("N_CHECKAMOUNT")) : 0);
			String addDesc = receiptsForm.get("DESCRIPTION") != null ? receiptsForm.get("DESCRIPTION").toString().trim() : "";
			double opAmount = (receiptsForm.get("N_OPAMT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMT").toString()) : 0);
			double invAmount = (receiptsForm.get("N_TOTINVAMT") != null ? Double.parseDouble(receiptsForm.get("N_TOTINVAMT").toString()) : 0);
			String oldOPAmountStr = receiptsForm.get("N_OLDOPAMT") != null ? receiptsForm.get("N_OLDOPAMT").toString() : null;
			double checkAmount2 = checkAmount;
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			
			log.info("lSize: " + lClientTransAmount.size());
									
			nReceivables = nReceivables - checkAmount;
			log.info("nReserves: " + nReserves);
			nReserves = nReserves - checkAmount;
			log.info("nReserves: " + nReserves);
			
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
				
			success = clientDAO.updateClientTransAmount(receiptsForm);			
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);
				description.append(addDesc);
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return success;
	}
	
	public boolean updateClientTransAmountForNoInv(Map receiptsForm) {
		log.info("updateClientTransAmountUpdateType2");
		Map jsonData = new HashMap();
		boolean success = false;
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			String receiptType = (String) receiptsForm.get("C_RECEIPTTYPE");
			double checkAmount = (receiptsForm.get("N_CHECKAMOUNT") != null ? Double.parseDouble(receiptsForm.get("N_CHECKAMOUNT").toString()) : 0);
			double totalBalance = (receiptsForm.get("N_TOTINVAMT") != null ? Double.parseDouble(receiptsForm.get("N_TOTINVAMT").toString()) : 0);
			double opAmount = (receiptsForm.get("N_OPAMT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMT").toString()) : 0);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");			
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			
			if (receiptType.equalsIgnoreCase("2")) {
				nReserves = nReserves - checkAmount;
				nFiuTran = nFiuTran + checkAmount;				
			}
			else if (receiptType.equalsIgnoreCase("3")) {
				nReceivables = nReceivables - totalBalance;
				nReserves = nReserves - totalBalance;
			}
			else if (receiptType.equalsIgnoreCase("1")) {
				nReserves = nReserves - checkAmount;
				nFiuTran = nFiuTran + checkAmount;
				nForClearing = nForClearing - checkAmount;
			}
			
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
			
			success = clientDAO.updateClientTransAmount(receiptsForm);
							
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);				
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return success;
	}
	
	public boolean updateClientTransAmountCancelType2(Map receiptsForm) {
		log.info("updateClientTransAmountUpdateType2");
		Map jsonData = new HashMap();
		boolean success = false;
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			String receiptType = (String) receiptsForm.get("C_RECEIPTTYPE");
			double checkAmount = (receiptsForm.get("N_CHECKAMOUNT") != null ? Double.parseDouble(receiptsForm.get("N_CHECKAMOUNT").toString()) : 0);
			double totalBalance = (receiptsForm.get("N_TOTINVAMT") != null ? Double.parseDouble(receiptsForm.get("N_TOTINVAMT").toString()) : 0);
			double opAmount = (receiptsForm.get("N_OPAMT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMT").toString()) : 0);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");			
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			
			if (receiptType.equalsIgnoreCase("2")) {
				if (opAmount > 0) {
					nReserves = nReserves - opAmount;
				}
			
				nReceivables = nReceivables + totalBalance;
				if (checkAmount == 0) {
					nFiuTran = nFiuTran - opAmount;
				}
				else {
					nFiuTran = nFiuTran - checkAmount;
				}
				
			}
			//else if (receiptType.equalsIgnoreCase("3")) {		//rdc07282010
			else if (receiptType.equalsIgnoreCase("3")||receiptType.equalsIgnoreCase("4")) {
				nReceivables = nReceivables + totalBalance;
				nReserves = nReserves + totalBalance;
			}
			
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
			
			success = clientDAO.updateClientTransAmount(receiptsForm);
							
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);				
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return success;
	}
	
	public boolean updateClientTransAmountUpdateType2(Map receiptsForm) {
		log.info("updateClientTransAmountUpdateType2");
		Map jsonData = new HashMap();
		boolean success = false;
		
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			double checkAmount = ((String) receiptsForm.get("N_CHECKAMOUNT") != null ? Double.parseDouble((String) receiptsForm.get("N_CHECKAMOUNT")) : 0);
			double opAmount = (receiptsForm.get("N_OPAMT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMT").toString()) : 0);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");			
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			
			log.info("n_receivables: " + nReceivables);
			log.info("n_fiuTran: " + nFiuTran);
			log.info("n_Reserves: " + nReserves);
			log.info("n_ForClearing: " + nForClearing);
			log.info("n_AdvancedRatio: " + nAdvancedRatio);
			log.info("checkAmount: " + checkAmount);
			log.info("opAmount:" + opAmount);
			
			nReserves = nReserves + opAmount;
			nFiuTran = nFiuTran - checkAmount;
			nReceivables = nReceivables - checkAmount;	
			
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
				
			success = clientDAO.updateClientTransAmount(receiptsForm);			
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);				
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return success;
	}
	
	public boolean updateClientTransAmountUpdateType3(Map receiptsForm) {
		log.info("updateClientTransAmountUpdateType3");
		Map jsonData = new HashMap();
		boolean success = false;
		
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			double checkAmount = ((String) receiptsForm.get("N_CHECKAMOUNT") != null ? Double.parseDouble((String) receiptsForm.get("N_CHECKAMOUNT")) : 0);
			double opAmount = (receiptsForm.get("N_OPAMT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMT").toString()) : 0);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");			
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			
			log.info("n_receivables: " + nReceivables);
			log.info("n_fiuTran: " + nFiuTran);
			log.info("n_Reserves: " + nReserves);
			log.info("n_ForClearing: " + nForClearing);
			log.info("n_AdvancedRatio: " + nAdvancedRatio);
			log.info("checkAmount: " + checkAmount);
			log.info("opAmount:" + opAmount);
						
			nReserves = nReserves - checkAmount;
			if (checkAmount == 0) {
				nReserves = nReserves + opAmount;
			}
			nReceivables = nReceivables - checkAmount;	
			
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
				
			success = clientDAO.updateClientTransAmount(receiptsForm);			
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);				
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return success;
	}
	
	public boolean updateClientTransAmountCheckOP(Map receiptsForm) {
		log.info("updateClientTransAmountUpdateType3");
		Map jsonData = new HashMap();
		boolean success = false;
		
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			double checkAmount = ((String) receiptsForm.get("N_CHECKAMOUNT") != null ? Double.parseDouble((String) receiptsForm.get("N_CHECKAMOUNT")) : 0);
			double opAmount = (receiptsForm.get("N_OPAMT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMT").toString()) : 0);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");			
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			
			log.info("n_receivables: " + nReceivables);
			log.info("n_fiuTran: " + nFiuTran);
			log.info("n_Reserves: " + nReserves);
			log.info("n_ForClearing: " + nForClearing);
			log.info("n_AdvancedRatio: " + nAdvancedRatio);
			log.info("checkAmount: " + checkAmount);
			log.info("opAmount:" + opAmount);

			if (opAmount > 0) {
				nReserves = nReserves + opAmount;
				nFiuTran = nFiuTran - checkAmount;
				nForClearing = nForClearing + opAmount;
			}
			else {
				nReserves = nReserves + opAmount + checkAmount;
				nFiuTran = nFiuTran - checkAmount;
				nForClearing = nForClearing + opAmount + checkAmount;
				//nReceivables = nReceivables - checkAmount;	
			}
			
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
				
			success = clientDAO.updateClientTransAmount(receiptsForm);			
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);				
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return success;
	}
	
	public synchronized boolean updateClientTransAmountForCancelledCN(Map receiptsForm) {
		log.info("updateClientTransAmountForCancelledCN");
		Map jsonData = new HashMap();
		boolean success = false;
		
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			double checkAmount = ((String) receiptsForm.get("N_CHECKAMOUNT") != null ? Double.parseDouble((String) receiptsForm.get("N_CHECKAMOUNT")) : 0);
			double opAmount = (receiptsForm.get("N_OPAMT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMT").toString()) : 0);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");			
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			
			log.info("n_receivables: " + nReceivables);
			log.info("n_fiuTran: " + nFiuTran);
			log.info("n_Reserves: " + nReserves);
			log.info("n_ForClearing: " + nForClearing);
			log.info("n_AdvancedRatio: " + nAdvancedRatio);
			log.info("checkAmount: " + checkAmount);
			log.info("opAmount:" + opAmount);

			nReserves = nReserves - checkAmount;
			nReceivables = nReceivables - checkAmount;	
						
			
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
				
			success = clientDAO.updateClientTransAmount(receiptsForm);			
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);				
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return success;
	}
	
	
	public boolean updateClientTransAmountRefund(Map receiptsForm) {
		log.info("updateClientTransAmountRefund");
		Map jsonData = new HashMap();
		boolean success = false;
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			double refundAmount = (receiptsForm.get("N_REFUNDAMOUNT") != null ? Double.parseDouble(receiptsForm.get("N_REFUNDAMOUNT").toString()) : 0);
			String type = (String) receiptsForm.get("TYPE");			
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");			
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			
			log.info("n_receivables: " + nReceivables);
			log.info("n_fiuTran: " + nFiuTran);
			log.info("n_Reserves: " + nReserves);
			log.info("n_ForClearing: " + nForClearing);
			log.info("n_AdvancedRatio: " + nAdvancedRatio);
			log.info("refundAmount: " + refundAmount);
			
			if (type.equalsIgnoreCase("REFUND")) {
				nReserves = nReserves + refundAmount;
				nFiuTran = nFiuTran - refundAmount;
			}
			else if (type.equalsIgnoreCase("OPAMOUNT")) {
				double opAmount = (receiptsForm.get("N_OPAMOUNT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMOUNT").toString()) : 0);
				
				nReceivables = nReceivables - opAmount;
				nReserves = nReserves - opAmount;
			}
			
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
			
			success = clientDAO.updateClientTransAmount(receiptsForm);			
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);				
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
		}
		catch (Exception e) {
			e.printStackTrace();			
		}
		return success;		
	}


	public boolean updateClientTransAmount(Map receiptsForm) {
		log.info("updateClientTransAmount");
		Map jsonData = new HashMap();
		boolean success = false;
		try {
			String c_ClntCode = (String) receiptsForm.get("C_CLNTCODE");
			String receiptType = ((String) receiptsForm.get("C_RECEIPTTYPE") != null ? (String) receiptsForm.get("C_RECEIPTTYPE") : "").trim();
			double checkAmount = ((String) receiptsForm.get("N_CHECKAMOUNT") != null ? Double.parseDouble((String) receiptsForm.get("N_CHECKAMOUNT")) : 0);
			String addDesc = receiptsForm.get("DESCRIPTION") != null ? receiptsForm.get("DESCRIPTION").toString().trim() : "";
			double opAmount = (receiptsForm.get("N_OPAMT") != null ? Double.parseDouble(receiptsForm.get("N_OPAMT").toString()) : 0);
			double invAmount = (receiptsForm.get("N_TOTINVAMT") != null ? Double.parseDouble(receiptsForm.get("N_TOTINVAMT").toString()) : 0);
			String oldOPAmountStr = receiptsForm.get("N_OLDOPAMT") != null ? receiptsForm.get("N_OLDOPAMT").toString() : null;
			double checkAmount2 = checkAmount;
						
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");	
			
			List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
			log.info("lSize: " + lClientTransAmount.size());
			
			HashMap mClient = (HashMap) lClientTransAmount.get(0);
			double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
			double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
			double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
			double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
			double nForClearing2 = .9999;
			double nForClearing3 = .9999;
			double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
			double nReserves2 = .9999;
			
			log.info("n_receivables: " + nReceivables);
			log.info("n_fiuTran: " + nFiuTran);
			log.info("n_Reserves: " + nReserves);
			log.info("n_ForClearing: " + nForClearing);
			log.info("n_AdvancedRatio: " + nAdvancedRatio);
			log.info("checkAmount: " + checkAmount);
			log.info("opAmount:" + opAmount);
			log.info("invoiceAmount:" + invAmount);
			
			if (oldOPAmountStr != null) {
				log.info("oldOPAMountSTR: " + oldOPAmountStr);
				double oldOPAmount = Double.parseDouble(oldOPAmountStr);
				nForClearing3 = nForClearing - oldOPAmount;
				log.info("nForClearing3: " + (nForClearing - oldOPAmount));
				double newInvAmount = checkAmount - opAmount;
				double invPercentage = newInvAmount * ((100 - nAdvancedRatio)/100);
				double newOPAdd = opAmount - newInvAmount;
				nForClearing3 = nForClearing3 + newInvAmount + invPercentage + newOPAdd;
				log.info("inv% : " + invPercentage + ";; newOPAdd : " + newOPAdd);				
				log.info("nForClearing3: " + nForClearing3);
				checkAmount = checkAmount - oldOPAmount;
			}
			
			else if (receiptsForm.get("N_TOTINVAMT") != null && invAmount < (checkAmount)) {			
				nForClearing2 = nForClearing + ((invAmount * ((100 - nAdvancedRatio)/100)) + opAmount);	
				log.info("compute!!! " + ((invAmount * ((100 - nAdvancedRatio)/100))));
				log.info("compute!!! " + ((invAmount * ((100 - nAdvancedRatio)/100)) + opAmount));
				log.info("compute!!! " + (nForClearing + ((invAmount * ((100 - nAdvancedRatio)/100)) + opAmount)));
				log.info("compute!!! " + (nForClearing + ((invAmount * ((100 - nAdvancedRatio)/100)) + opAmount)));
				log.info("new checkAmount:" + checkAmount);
			}
			
			//for Delete operation
			else if (receiptsForm.get("OPERATION") != null && receiptsForm.get("OPERATION").toString().equalsIgnoreCase("DELETE") && receiptsForm.get("N_TOTINVAMT") != null && invAmount < (checkAmount * -1)) {			
				nForClearing2 = nForClearing - (invAmount * ((100 - nAdvancedRatio)/100)) - opAmount;				
				log.info("compute!!! " + ((invAmount * ((100 - nAdvancedRatio)/100))));
				log.info("compute!!! " + ((invAmount * ((100 - nAdvancedRatio)/100)) + opAmount));
				log.info("compute!!! " + (nForClearing - (invAmount * ((100 - nAdvancedRatio)/100)) - opAmount));
				log.info("compute!!! " + (nForClearing - (invAmount * ((100 - nAdvancedRatio)/100)) - opAmount));				
			}
			
			else if (receiptsForm.get("OPERATION") != null && receiptsForm.get("OPERATION").toString().equalsIgnoreCase("DELETE")) {
				nReserves2 = nReserves - opAmount;
			}
							
			if (receiptType.equalsIgnoreCase("1")) {
				log.info("****1****");
				log.info("nReceivables: " + nReceivables + ": checkAmount: " + checkAmount2 + ": opAmount: " + opAmount);
				log.info("nReceivables1: " + (nReceivables - checkAmount2));
				log.info("nReceivables2: " + (nReceivables - checkAmount2 + opAmount));
				if (receiptsForm.get("OPERATION") != null && receiptsForm.get("OPERATION").toString().equalsIgnoreCase("DELETE")) {
					nReceivables = nReceivables - checkAmount2 - opAmount;
					nReserves = nReserves - opAmount;
				}
				else if (receiptsForm.get("OPERATION") != null && receiptsForm.get("OPERATION").toString().equalsIgnoreCase("UPDATE")) {
					nReceivables = nReceivables - checkAmount2 + opAmount;					
					nReserves = nReserves - opAmount;
				}
				else {
					nReceivables = nReceivables - checkAmount2 + opAmount;	
					nReserves = nReserves - (checkAmount2 - opAmount);
				}
				nFiuTran = nFiuTran - checkAmount;
				if (nForClearing2 != .9999) {
					nForClearing = nForClearing2;					
				}					
				else if (nForClearing3 != .9999) {
					nForClearing = nForClearing3;
					log.info("nForClearing3: " + nForClearing3);
				}
				else {
					nForClearing = nForClearing + (checkAmount * ((100 - nAdvancedRatio)/100));					
				}
				if (nReserves2 != .9999) {
					log.info("nReserves2: " + nReserves2);
					nReserves = nReserves2;
				}
											
			}
			else if (receiptType.equalsIgnoreCase("1b")) {
				log.info("1b");
				nReceivables = nReceivables - checkAmount2 + opAmount;
				nFiuTran = nFiuTran - checkAmount;
				nReserves = nReserves + opAmount;
				nForClearing = nForClearing + checkAmount;
			}
			else if (receiptType.equalsIgnoreCase("2")) {
				nFiuTran = nFiuTran - checkAmount;	
				
				if (invAmount > checkAmount && invAmount > 0) {
					checkAmount = checkAmount2;
				} else if (invAmount < checkAmount && invAmount > 0){
					checkAmount = invAmount;
				}
				
				if (invAmount == 0) {
					checkAmount = 0;
					nReserves = nReserves + opAmount;
				}
				else {
					log.info("checkAmount2:" + checkAmount2);					
					nReserves = nReserves - (checkAmount2 - opAmount);
					log.info("nReserves:" + nReserves);
				}
				nReceivables = nReceivables - checkAmount2 + opAmount;
							
			}	
			else if (receiptType.equalsIgnoreCase("2b")) {
				nFiuTran = nFiuTran - checkAmount;	
				
				if (invAmount > checkAmount && invAmount > 0) {
					checkAmount = checkAmount2;
				} else if (invAmount < checkAmount && invAmount > 0){
					checkAmount = invAmount;
				}
				
				nReserves = nReserves + opAmount;				
				nReceivables = nReceivables - checkAmount2 + opAmount;
							
			}	
			else if (receiptType.equalsIgnoreCase("3")) {
				if (invAmount > checkAmount && invAmount > 0) {
					checkAmount = checkAmount2;
				} else if (invAmount < checkAmount && invAmount > 0){
					checkAmount = invAmount;
				}
				else if (invAmount == 0) {
					checkAmount = 0;
				}
				
				nReceivables = nReceivables - checkAmount2 + opAmount;
				log.info("checkAmount: " + checkAmount);
				nReserves = nReserves - checkAmount - checkAmount;
			}
			else if (receiptType.equalsIgnoreCase("3b")) {
				if (invAmount > checkAmount && invAmount > 0) {
					checkAmount = checkAmount2;
				} else if (invAmount < checkAmount && invAmount > 0){
					checkAmount = invAmount;
				}
				else if (invAmount == 0) {
					checkAmount = 0;
				}
				
				nReceivables = nReceivables - checkAmount2 + opAmount;
				nReserves = nReserves - checkAmount;
			}
			else if (receiptType.equalsIgnoreCase("4")) {
				double forReceivables = Double.parseDouble(receiptsForm.get("FOR_RECEIVABLES")!=null ? receiptsForm.get("FOR_RECEIVABLES").toString():"0");
				double forReserves = Double.parseDouble(receiptsForm.get("FOR_RESERVES")!=null ? receiptsForm.get("FOR_RESERVES").toString():"0");
				log.info("forReserves: " + forReserves);
				log.info("forReceivables: " + forReceivables);
				log.info("opAmount: " + opAmount);
				if (forReceivables == 0) {
					nReceivables = nReceivables;
				}
				else {
					nReceivables = nReceivables - checkAmount2 + opAmount;
				}
				nFiuTran = nFiuTran - forReceivables;
				nReserves = nReserves - forReserves;
			}
			//receipt to update only the clearing amount since reserves or fiu was already updated
			//upon creation of receiptsheader.
			//need to update receivables... op amount is not included in receivables computation.
			else if (receiptType.equalsIgnoreCase("5")) {
				log.info("5");
				String receiptTypeVal = receiptsForm.get("C_RECEIPTTYPEVAL") !=null? receiptsForm.get("C_RECEIPTTYPEVAL").toString() : "";
				double forReverse = Double.parseDouble(receiptsForm.get("forReverse")!=null ? receiptsForm.get("forReverse").toString():"0");
				double forReceivables = Double.parseDouble(receiptsForm.get("forReceivables")!=null ? receiptsForm.get("forReceivables").toString():"0");
								
				log.info("receiptTypeVal:" + receiptTypeVal); 
				if (receiptTypeVal.equalsIgnoreCase("1")) {
					log.info("forReceivables: " + forReceivables);
					if (nForClearing2 != .9999) {
						nForClearing = nForClearing2;
					}				
					else if (nForClearing3 != .9999) {
						nForClearing = nForClearing3;
						log.info("nForClearing3: " + nForClearing3);
					}
					else {
						nForClearing = nForClearing + (checkAmount * ((100 - nAdvancedRatio)/100));					
					}
					nForClearing = nForClearing - forReverse;
				}			
				nReceivables = nReceivables - forReceivables;				
				if (receiptTypeVal.equalsIgnoreCase("3")) {
					if (invAmount > checkAmount) {
						//nReserves = nReserves - checkAmount - checkAmount + opAmount;  
						nReserves = nReserves - checkAmount;
					}
					else {
						//nReserves = nReserves - checkAmount - invAmount + opAmount;
						nReserves = nReserves - invAmount;
					}
				}
				else {
					nReserves = nReserves - forReceivables;
				}
			}
			else if (receiptType.equals("1z")) {
				log.info("****1****");
				log.info("nReceivables: " + nReceivables + ": checkAmount: " + checkAmount2 + ": opAmount: " + opAmount);
				log.info("nReceivables1: " + (nReceivables - checkAmount2));
				log.info("nReceivables2: " + (nReceivables - checkAmount2 + opAmount));
				if (receiptsForm.get("OPERATION") != null && receiptsForm.get("OPERATION").toString().equalsIgnoreCase("DELETE")) {
					nReceivables = nReceivables - checkAmount2 - opAmount;
					nReserves = nReserves - opAmount;
				}
				else if (receiptsForm.get("OPERATION") != null && receiptsForm.get("OPERATION").toString().equalsIgnoreCase("UPDATE")) {
					nReceivables = nReceivables - checkAmount2 + opAmount;					
					nReserves = nReserves - opAmount;
				}
				else {
					nReceivables = nReceivables - checkAmount2 + opAmount;	
					nReserves = nReserves - (checkAmount2 - opAmount);
				}
				nFiuTran = nFiuTran - checkAmount;				
			}
			else if (receiptType.equalsIgnoreCase("1zb")) {
				log.info("1b");
				nReceivables = nReceivables - checkAmount2 + opAmount;
				nFiuTran = nFiuTran - checkAmount;
				nReserves = nReserves + opAmount;				
			}
						
			receiptsForm.put("N_RECEIVABLES", nReceivables);
			receiptsForm.put("N_FIUTRAN", nFiuTran);
			receiptsForm.put("N_RESERVES", nReserves);
			receiptsForm.put("N_FORCLEARING", nForClearing);
				
			success = clientDAO.updateClientTransAmount(receiptsForm);			
			if (success) {								
				String userID = (String) receiptsForm.get("C_USERID") != null ? (String) receiptsForm.get("C_USERID") : "";
				StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
				description.append(";N_RECEIVABLES=").append(nReceivables);
				description.append(";N_FIUTRAN=").append(nFiuTran);
				description.append(";N_RESERVES=").append(nReserves);
				description.append(";N_FORCLEARING=").append(nForClearing);
				description.append(addDesc);
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "CLIENT", description.toString());		
				log.info("end..");
			}
			
		}
		catch (Throwable x) {
			x.printStackTrace();
		}
		return success;
	}
	
			
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchClientList(Map CurrencyForm){
		
		log.info("--->> searchClientList SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(CurrencyForm);
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");				
			records = (ArrayList)clientDAO.searchClient(CurrencyForm);
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_CLNTCODE","C_NAME");
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	

	
//////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchClientNameByCode(Map clientForm) {
		log.info("--->> searchClientNameByCode SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(clientForm);
			String c_ClntCode = clientForm.get("C_CLNTCODE") != null ? clientForm.get("C_CLNTCODE").toString() : "0"; 
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");			
			records = (ArrayList) clientDAO.searchClientNameByCode(c_ClntCode);
			resultString = JQGridJSONFormatter.formatListToString(records);
			jsondata.put("result",resultString);
								
		}catch(Throwable x){
			jsondata.put("result",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;		
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////		

	public Map searchClientCustomer(Map clientForm){
		
		log.info("--->> searchClientCustomer SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		HashMap tmpHashMap = new HashMap();
		String xmlData = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(clientForm);
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
			
			
			if(clientForm.get("nodeid")!=null && clientForm.get("nodeid").toString().trim().length() > 0){
				clientForm.put("C_CLNTCODE",clientForm.get("nodeid").toString());
				records = customerDAO.searchCustomerServiceList(clientForm);
				xmlData = JQGridJSONFormatter.formatDataToXML(records, "", "C_CUSTNAME", "C_CLNTCODE", "2",true,true);
			}else{
				records = (ArrayList)clientDAO.searchClient(clientForm);
				xmlData = JQGridJSONFormatter.formatDataToXML(records, "C_CLNTCODE", "C_NAME", "", "0",false,false);
			}
			
			System.out.println("--->> XML DATA: "+xmlData);
			System.out.println("--->> searchClientCustomer RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){
				
				jsondata.put("XML",xmlData);
				
				//jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)bankForm.get("records")),((String)bankForm.get("page")),((String)bankForm.get("total")));
			}else{
				jsondata.put("status","searchClientCustomer Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		
		
		return jsondata;
		
	}	

//////////////////////////////////////////////////////////////////////////////////////////////


	public Map searchClientACStatus(Map clientForm){
		
		log.info("--->> searchClientACStatus SERVICE ...");
		
		int dateMinusOne = 0;
		Map jsondata = new HashMap();
		List records = new ArrayList();
		
		Map mbMap = new HashMap();
		List mbList = new ArrayList();
		
		Map newMap = new HashMap();
		List newList = new ArrayList();
		
		
		String totalRecords = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(clientForm);
			
			String[] statementDate = clientForm.get("D_EFFDATE").toString().split("/");
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			System.out.println("-->>> date: "+(String)clientForm.get("D_EFFDATE"));
			
			clientForm.put("D_EFFDATE","");
			records = clientDAO.searchClientByCode(clientForm);	
			log.info("--->> searchClientACStatus RECORD-SIZE: "+records.size());
			
			mbList = clientDAO.searchClientACStatus(clientForm);
			log.info("--->> mbList RECORD-SIZE: "+mbList.size());
			
			if(Integer.parseInt(statementDate[0]) == 1){
				dateMinusOne = 12;
			}else{
				dateMinusOne = Integer.parseInt(statementDate[0])-1;
			}
			
			/*
			System.out.println("-->>> dateMinusOne: "+dateMinusOne);
			System.out.println("-->>> date: "+statementDate[0]);
			System.out.println("-->>> date: "+statementDate[1]);
			System.out.println("-->>> date: "+statementDate[2]);
			
			System.out.println("-->>> data: "+((HashMap)mbList.get(0)).get("N_JANFIU"));
			System.out.println("-->>> data: "+((HashMap)mbList.get(0)).get("N_PREVJANFIU"));
			System.out.println("-->>> data: "+((HashMap)mbList.get(0)).get("N_JANREC"));
			System.out.println("-->>> data: "+((HashMap)records.get(0)).get("C_CLNTCODE"));
			*/
			
			if(mbList.size()>0)
			{
					switch (dateMinusOne) {
			            case 1:  
			            		newMap.put("one",((HashMap)mbList.get(0)).get("N_JANREC").toString());
			            		newMap.put("two",((HashMap)mbList.get(0)).get("N_JANRES").toString());
			            		newMap.put("three",((HashMap)mbList.get(0)).get("N_JANFIU").toString());
			            		break;
			            case 2:  
		            			newMap.put("one",((HashMap)mbList.get(0)).get("N_FEBREC").toString());
		            			newMap.put("two",((HashMap)mbList.get(0)).get("N_FEBRES").toString());
		            			newMap.put("three",((HashMap)mbList.get(0)).get("N_FEBFIU").toString());
			            		break;
			            case 3:  
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_MARREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_MARRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_MARFIU").toString());
			            		break;
			            case 4:  
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_APRREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_APRRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_APRFIU").toString());
			            		break;
			            case 5:  
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_MAYREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_MAYRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_MAYFIU").toString());
			            		break;
			            case 6:  
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_JUNREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_JUNRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_JUNFIU").toString());
			            		break;
			            case 7:  
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_JULREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_JULRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_JULFIU").toString());
			            		break;
			            case 8:  
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_AUGREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_AUGRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_AUGFIU").toString());
			            		break;
			            case 9:  
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_SEPREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_SEPRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_SEPFIU").toString());
			            		break;
			            case 10: 
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_OCTREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_OCTRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_OCTFIU").toString());
			            		break;
			            case 11: 
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_NOVREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_NOVRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_NOVFIU").toString());
			            		break;
			            case 12: 
			        			newMap.put("one",((HashMap)mbList.get(0)).get("N_DECREC").toString());
			        			newMap.put("two",((HashMap)mbList.get(0)).get("N_DECRES").toString());
			        			newMap.put("three",((HashMap)mbList.get(0)).get("N_DECFIU").toString());
			            		break;
					}
			
			}else{
    			newMap.put("one","0.00");
    			newMap.put("two","0.00");
    			newMap.put("three","0.00");
			}
			
			newList.add(newMap);
			
			if((records!=null) && (records.size()>0)){						
				jsondata.put("returnData", records);
				jsondata.put("mbList", newList);
			}else{
				jsondata.put("status","searchClientACStatus Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}		

	
//////////////////////////////////////////////////////////////////////////////////////////////
	

	public Map searchClientMasterList(Map clientForm){
		
		log.info("--->> searchClientMasterList SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		String c_BranchCode = "";
		String c_Clnt = "";
		
		try{
			
			ServiceUtility.viewUserParameters(clientForm);
			c_Clnt = (String) clientForm.get("clientfilter");
			if (c_Clnt == null){
				c_Clnt = "";
			}
			c_BranchCode = (String) clientForm.get("C_BRANCHCODE") + ";" + c_Clnt + "%";
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			totalRecords = clientDAO.getTotalRecordsClientMasterList(c_BranchCode);	
			
			clientForm = ServiceUtility.addPaging(clientForm,totalRecords);			
			
			records = clientDAO.searchClientMasterList(clientForm);	
		
			ServiceUtility.viewUserParameters(clientForm);
						
			log.info("--->> searchClientMasterList RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)clientForm.get("records")),((String)clientForm.get("page")),((String)clientForm.get("total")));
			}else{
				jsondata.put("status","searchClientMasterList Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}	
	
	
//////////////////////////////////////////////////////////////////////////////////////////////	

	public Map checkClientExists(Map clientForm) {

		Map jsondata = new HashMap();
		List records = new ArrayList();

		try {
			
			log.info("--->>> checkClientExists ...");
			ServiceUtility.viewUserParameters(clientForm);
			 
			//////////////////////////////////////////////////
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		    records = clientDAO.checkClientExists(clientForm);
			 
			 if(records.size()!=0){
				 
				 jsondata.put("status","1");
				 return jsondata;
				 
			 }else{
				 
				 jsondata.put("status","0");
				 return jsondata;
			 }

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}

	
//////////////////////////////////////////////////////////////////////////////////////////////

	public String searchClientCurrency(String c_ClntCode){
		String result = null;
		try {
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			result = clientDAO.searchClientCurrency(c_ClntCode);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public Map getClientSelect(Map m){
		 
			ClientDAO CD = (ClientDAO)Persistence.getDAO("ClientDAO");
			AccountingMaintenanceService AMS = AccountingMaintenanceService.getInstance();
			Map map = new HashMap();
			List<Map> json = new ArrayList<Map>();
			json = CD.getClientSelect();
			map = AMS.toJSON(json);
			log.info("json--->"+ json);
			log.info("map--->"+ map);
			return map;
		 
	}
	
	public Map searchCALimit(Map m) {
		Map jsonData = new HashMap();
		try {
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			m.put("D_PROCDATE", DateHelper.parse(m.get("D_PROCDATE").toString()));
			ServiceUtility.viewUserParameters(m);
			double caLimit = clientDAO.searchCALimit(m);
			jsonData.put("result", caLimit);
		}
		catch(Exception e) {
			e.printStackTrace();
			jsonData.put("result", "searchCALimit failed.");
		}
		return jsonData;
	}
	
	public boolean updateIneligibleRec (String clientCode, double amount) {
		return this.updateIneligibleRec(clientCode, amount, "-");
	}
	
	public boolean updateIneligibleRec (String clientCode, double amount, String userID) {
		boolean result = false;
		try {
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");;	
			double ineligibleRec = clientDAO.searchIneligibleRecByClient(clientCode);
			double oldIneligibleRec = ineligibleRec;
			log.info("old ineligibleRec: " + ineligibleRec);
			ineligibleRec = ineligibleRec - amount;
			if (ineligibleRec < 0) {
				ineligibleRec = 0;
			}
			log.info("new ineligibleRec: " + ineligibleRec);
			
			Map map = new HashMap();
			map.put("C_CLNTCODE", clientCode);			
			map.put("N_INELIGIBLEREC", ineligibleRec);		
			result = clientDAO.updateIneligibleRecByClient(map);
			
			AuditService as = AuditService.getInstance();
			StringBuilder sb = new StringBuilder("C_CLNTCODE=").append(clientCode).append(";");			
			sb.append("OLD N_INELIGIBLEREC=").append(oldIneligibleRec).append(";");
			sb.append("NEW N_INELIGIBLEREC=").append(ineligibleRec).append(";");
						
			as.addAudit(userID, "U", "CLIENT", sb.toString());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
//////////////////////////////////////////////////////////////////////////////////////////////
	public static void main(String[] args) {
		String s = null;
		if (s == null) { s = "10.5785122"; }
		double d = Double.parseDouble(s);		
		d = Math.round(d * 100);
		d = d / 100;
		System.out.println("result: " + d);
	}
	
	public Map TagClientRMU(Map data){
		ServiceUtility.viewUserParameters(data);
		
		ClientDAO _ClientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		String operation = (String) data.get("status");
		Boolean is_RMU = false;
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		
		int status_RMU = 0;
		Map insertData = new HashMap();
		switch(operation){
			case "save":
				status_RMU =1;
				break;
			case "approve":
				status_RMU = 2;
				is_RMU = true;
				break;
			case "reject":
				status_RMU =3;
				break;
		}
		insertData.put("status_RMU", status_RMU);
		insertData.put("c_clntcode",data.get("c_clntcode"));
		insertData.put("date_tagged_RMU", date.newDate());
		insertData.put("is_RMU", is_RMU);
		 
		try{
			if(is_RMU){
			 InvoiceDAO invoiceDAO = (InvoiceDAO)Persistence.getDAO("invoiceDao");
			 Double CE = invoiceDAO.getClientCE(data.get("c_clntcode").toString());
			 SubHeaderService SHS = SubHeaderService.getInstance();
			 SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
			 insertData.put("N_REFNO", data.get("c_clntcode").toString());
			 insertData.put("ClEq", CE);
			 insertData.put("particular", "Reversal of Client's Equity");
			 insertData.put("C_Type","D");
			 insertData.put("C_TransactionType", "A");
			 insertData.put("C_BRANCHCODE", "01");
			 insertData.put("C_CLNTCODE",data.get("c_clntcode"));
			 insertData.put("N_Amount",CE);
			 insertData.put("C_User", data.get("userId"));
			 insertData.put("D_TRANSACTIONDATE", SDF.format(date.newDate()));
			// FactorsDateDAO date2 = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
			 insertData.put("amount_reversed", CE);
			 //Long headerRefNo = SHS.createSubHeader(insertData, "Client", SDF.format(date.newDate()),  "Client");
			 //SubHeaderService.getInstance().createLedgerEntry2(insertData, "Client",headerRefNo);
			}
			 
			_ClientDAO.TagClientRMU(insertData);
			data.put("success", true);
		}catch(Exception e){
			e.printStackTrace();
			data.put("success", false);
		}
		return data;
	}
	
	public List getAllClient(String branchCode){
		ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		return clientDAO.getAllClient(branchCode);
		
	} 
	public String searchClientNameByCodeString(String c_ClntCode){
		ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		return clientDAO.searchClientNameByCodeString(c_ClntCode);
		
	} 
	
	
	
}
