package com.bdo.factor.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.BLR;
import com.bdo.factor.constant.Status;
import com.bdo.factor.dao.BLRDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.ServiceUtility;
import com.sun.corba.se.impl.orbutil.closure.Constant;

public class BLRService {
	private static Logger log = Logger.getLogger(BankService.class);
	private BLRDAO blrDAO = (BLRDAO)Persistence.getDAO("BLRDAO");
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////

	private static BLRService thisBLRService = new BLRService();

	private BLRService() { }

	public static BLRService getInstance() {
		return thisBLRService;
	}
	
	public Map getBLRGrid(Map data){
		return ServiceUtility.toJQGrid(blrDAO, "countBLRGrid", "getBLRGrid", data);
	}
	
	public Map createBLR(Map data){
		Map returnMap = new HashMap<>();
		try {
			BLR _BLR = new BLR();
			_BLR.setC_clntCode(Long.parseLong(data.get("C_CLNTCODE").toString()));
			_BLR.setN_blr(Double.parseDouble(data.get("N_BLR").toString()));
			_BLR.setD_effDt(sdf.parse(data.get("D_EFFDT").toString()));
			_BLR.setD_expDt(sdf.parse(data.get("D_EXPDT").toString()));
			_BLR.setD_createdDt(new Date());
			_BLR.setC_userid(data.get("C_USERID").toString());
			_BLR.setC_status("2");
			
			if(blrDAO.getBLRConflict(_BLR)>0){
				returnMap.put("status", Status.failInsert);
				returnMap.put("message", "BLR dates are conflict");
				return returnMap;
			}
			
			if(_BLR.getD_effDt().after(_BLR.getD_expDt())){
				returnMap.put("status", Status.failInsert);
				returnMap.put("message", "Effective date should be before expiry date");
				return returnMap;
			}
			
			Long result = blrDAO.createBLR(_BLR);
			if(result!=0){
				returnMap.put("status", Status.successInsert);
				Map rateHistoryMap = new HashMap();
				rateHistoryMap.put("C_CLNTCODE", _BLR.getC_clntCode());
				rateHistoryMap.put("n_CurValue", _BLR.getN_blr());
				rateHistoryMap.put("d_CurBLRFrom", _BLR.getD_effDt());
				rateHistoryMap.put("d_CurBLRTo", _BLR.getD_expDt());
				rateHistoryMap.put("c_Charge", "BLR");
				rateHistoryMap.put("n_BLRNo", _BLR.getC_status());//will be used for status
				BLR PreviousBLR = blrDAO.getPreviousRate(_BLR);
				if(PreviousBLR !=null){
					rateHistoryMap.put("d_PrevBLRFrom", PreviousBLR.getD_effDt()!=null?PreviousBLR.getD_effDt():null);
					rateHistoryMap.put("d_PrevBLRTo", PreviousBLR.getD_expDt()!=null?PreviousBLR.getD_expDt():null);
					rateHistoryMap.put("n_PrevValue", PreviousBLR.getN_blr()!=null?PreviousBLR.getN_blr():null);
				}
				ClientDAO _clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
				_clientDAO.updateRateHistory(rateHistoryMap);
			}
			else{
				returnMap.put("status", Status.failInsert);
				returnMap.put("message", "Error inserting record");
			}
		} catch (ParseException e) {
			returnMap.put("status", Status.failInsert);
			returnMap.put("message", "Error inserting record");
			e.printStackTrace();
		}
		 
		return 	returnMap;
	}
	
	public Boolean updateBLR(BLR blr){
		return blrDAO.updateBLR(blr);
	}
	
	public BLR getPreviousRate(BLR blr){
		return blrDAO.getPreviousRate(blr);
	}
	
	
	
	public BLR readBLR(Long refNo){
		return blrDAO.readBLR(refNo);
	}
	
	public Map updateBLR(Map data){
		Long refNo =Long.parseLong( data.get("N_REFNO").toString());
		BLR _BLR = blrDAO.readBLR(refNo);
		Map rateHistoryMap = new HashMap();
		rateHistoryMap.put("d_PrevBLRFrom",_BLR.getD_effDt());
		rateHistoryMap.put("d_PrevBLRTo",_BLR.getD_expDt());

		try{
			_BLR.setN_blr(Double.parseDouble(data.get("N_BLR").toString()));
			_BLR.setD_effDt(sdf.parse(data.get("D_EFFDT").toString()));
			_BLR.setD_expDt(sdf.parse(data.get("D_EXPDT").toString()));
			_BLR.setC_status(data.get("C_STATUS").toString());
			if(updateBLR(_BLR)){
				data.put("status", Status.successInsert);
				rateHistoryMap.put("n_BLRNo", _BLR.getC_status());//will be used for status
				rateHistoryMap.put("C_CLNTCODE", _BLR.getC_clntCode());
				rateHistoryMap.put("n_CurValue", _BLR.getN_blr());
				rateHistoryMap.put("d_CurBLRFrom", _BLR.getD_effDt());
				rateHistoryMap.put("d_CurBLRTo", _BLR.getD_expDt());
				rateHistoryMap.put("c_Charge", "BLR");
				ClientDAO _clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
				_clientDAO.updateRateHistory(rateHistoryMap);
			}
			else
				data.put("status",Status.failInsert);	
		}catch(Exception e){
			e.printStackTrace();
			data.put("status",Status.failInsert);
		}
		return data;
	}
	
	public List<BLR> readBLRGeneric(Map blrData){
		return blrDAO.readBLRGeneric(blrData);
	}
	
	public String readBLRSOAString(Map blrData){
		StringBuilder sb = new StringBuilder();
		
		ListIterator<BLR> blrList = blrDAO.readBLRGeneric(blrData).listIterator();
		while(blrList.hasNext()){
			BLR blr = blrList.next();
			sb = sb.append(sdf.format(blr.getD_effDt())+"        "+sdf.format(blr.getD_expDt())+"         "+blr.getN_blr()+"\n");
		}
		
		return sb.toString();
	}
}
