package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CnType;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.CNDAO;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.CNTypeUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class CNService {
	private static Logger log = Logger.getLogger(CNService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static CNService thisCNService = new CNService();
	
	private CNService() { }

	public static CNService getInstance() {
		return thisCNService;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map searchCN(Map CNForm){
		
		System.out.println("--->> searchCN SERVICE X...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(CNForm);
			
			CNDAO cnDAO = (CNDAO)Persistence.getDAO("CNDAO");	
			
			log.info("--->> searchCN 1");
			
			totalRecords = cnDAO.getTotalRecordsCN();	
			records = cnDAO.searchCN(CNForm);	
			
			ServiceUtility.viewUserParameters(CNForm);
			log.info("--->> searchCN 2 "+totalRecords);
			
			
			CNForm = ServiceUtility.addPaging(CNForm,totalRecords);
			
			records = cnDAO.searchCN(CNForm);	
		
			ServiceUtility.viewUserParameters(CNForm);
						
			log.info("--->> searchCN RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)CNForm.get("records")),((String)CNForm.get("page")),((String)CNForm.get("total")));
			}else{
				jsondata.put("status","Search CN Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}
	
	public List searchCNTypeByCode(String c_CNTypeCode){
		log.info("--->> searchCheckTypeByBCode SERVICE ...");		
		
		CNDAO cnDAO = (CNDAO)Persistence.getDAO("CNDAO");
				
		return cnDAO.searchCNTypeByCode(c_CNTypeCode);		
	}
	
	public Map searchCNTypeDescByCode(Map cnForm){
		Map jsonData = new HashMap();
		log.info("--->> searchCNTypeDescByBCode SERVICE ...");		
		
		CNDAO cnDAO = (CNDAO)Persistence.getDAO("CNDAO");
		String c_CNTypeCode = cnForm.get("C_CNTYPECODE") != null ? cnForm.get("C_CNTYPECODE").toString() : "0"; 
		
		String result =  cnDAO.searchCNTypeDescByCode(c_CNTypeCode);
		jsonData.put("result", result);
		
		return jsonData;
	}
	
	public Map searchCNTypeList(Map m){		
		log.info("--->> searchCNTypeList SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		CNDAO cnDAO = (CNDAO)Persistence.getDAO("CNDAO");
		ArrayList records = (ArrayList) cnDAO.searchCNTypeList();
		
		//HashMap hm = (HashMap) records.get(0);		
		
		String resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_CNTYPECODE","C_DESCRIPTION");
		log.info("records: " + records.size());
		jsonData.put("AUTOCOMPLETE", resultString);
		
		return jsonData;
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map addCN(Map CNForm){
		
		log.info("--->> addCN SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{			
			ServiceUtility.viewUserParameters(CNForm);
			
			CnType cn = CNTypeUtility.getInstance().toObject(CNForm);  
			
			String operation = (String) CNForm.get("operation");
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {				
				this.updateCN(CNForm);
			}
			else {
				
				boolean duplicate = this.isDuplicate(cn.getC_CnTypeCode());
				if (duplicate) {
					jsondata.put("status","Failed to Add Check Type. Record with same check type code already exists.");
					return jsondata;
				}
				
				CNDAO CNDAO = (CNDAO)Persistence.getDAO("CNDAO");			
				boolean success = CNDAO.addCN(CNForm);				
				
				if(success){					
					String userID = (String) CNForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "CNTYPE", cn.toString().trim());
					
					jsondata.put("status","Add CN Successful ...");
				}else{
					jsondata.put("status","Add CN Failed ... ");
				}
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map updateCN(Map CNForm){
		
		log.info("--->> updateCN SERVICE ...");
		
		Map jsondata = new HashMap();
		CNForm.put("C_CNTYPECODE", CNForm.get("C_CNTYPECODE_ORIG"));
		CnType cnType = CNTypeUtility.getInstance().toObject(CNForm);
		
		try{
			ServiceUtility.viewUserParameters(CNForm);			
			
			CNDAO CNDAO = (CNDAO)Persistence.getDAO("CNDAO");		
			boolean success = CNDAO.updateCN(CNForm);
			
			if(success){
				String userID = (String) CNForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "CNTYPE", cnType.toString());
				
				jsondata.put("status","Update CN Successful ...");
			}else{
				jsondata.put("status","Update CN Failed ... ");
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map deleteCN(Map CNForm){
		
		log.info("--->> deleteCN SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			ServiceUtility.viewUserParameters(CNForm);
			
			CnType cn = CNTypeUtility.getInstance().toObject(CNForm);
			CNDAO CNDAO = (CNDAO)Persistence.getDAO("CNDAO");
			
			boolean success = CNDAO.deleteCN(CNForm);			
		
			if(success){
				String userID = (String) CNForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "CNTYPE", cn.toString());
				
				jsondata.put("status","Delete CN Successful ...");
			}else{
				jsondata.put("status","Delete CN Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}		

		return jsondata;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////
	public boolean isDuplicate(String c_CNTypeCode) {
		List l = this.searchCNTypeByCode(c_CNTypeCode);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}


}
