package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.SystemSettings;
import com.bdo.factor.dao.SystemSettingsDAO;
import com.bdo.factor.dao.Persistence;
import com.sun.jndi.url.ldap.ldapURLContextFactory;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;
import com.bdo.factor.util.Validator;

public class SystemSettingService 
{
	private static Logger log = Logger.getLogger(SystemSettingService.class);
	private static SystemSettingService systemSettingService = new SystemSettingService();	
	public SystemSettingService(){};
	
	public static SystemSettingService getInstance()
	{
		return systemSettingService;		
	}
		
	
	@SuppressWarnings("unchecked")
	public Map getSystemSetting(Map map)
	{		
		log.info("--->> getSystemSetting SERVICE ...");
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		List records = new ArrayList();
		try
		{
			SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
			records = systemSettingDao.getSystemSetting();		
			newData = (HashMap) records.get(0);		
			newData = ServiceUtility.removeNulls(newData);		
			records = new ArrayList();
			records.add(newData);
					
			jsondata.put("returnData", records);		
			log.info("--->> getSystemSetting RECORD-SIZE: " + records.size());
		}
		catch(Throwable x)
		{
			x.printStackTrace();
		}
		return jsondata;
		
	}
	
	public Map getSystemSettingsCurrency(Map map)
	{		
		log.info("--->> getSystemSettingsCurrency SERVICE ...");
		Map jsondata = new HashMap();
		Map newData = new HashMap();		
		try
		{
			SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
			String records = systemSettingDao.getSystemSettingsCurrency();					
			jsondata.put("returnData", records);			
		}
		catch(Throwable x)
		{
			x.printStackTrace();
		}
		return jsondata;
		
	}
		
	public int getSystemSettingsCnt()
	{
		SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
		System.out.println("[SystemSettingService]->[getSystemSettingsCnt][debug]: [systemSettingDao] = " + systemSettingDao);
		int retval = systemSettingDao.getSystemSettingsCount();
		return retval;
	}
	
	@SuppressWarnings("unchecked")
	public Map updateSystemSetting(Map systemSetting)
	{
		Map jsondata                                       = new HashMap();
		ServiceUtility.viewUserParameters(systemSetting);
		SystemSettingsDAO systemSettingDao                 = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
		Validator validator = new Validator();
		if(systemSetting.get("C_SYSTEMNAME")==null || systemSetting.get("C_SYSTEMNAME").toString().trim().length()==0){
			jsondata.put("status", "System Name can't be empty.");
			return jsondata;
		}
		else if(systemSetting.get("C_COMPANYNAME")==null || systemSetting.get("C_COMPANYNAME").toString().trim().length()==0){
			jsondata.put("status", "Company Name can't be empty.");
			return jsondata;
		}
		else if(systemSetting.get("C_COMPANYSHORTNAME")==null || systemSetting.get("C_COMPANYSHORTNAME").toString().trim().length()==0){
			jsondata.put("status", "Company Short Name can't be empty.");
			return jsondata;
		}
		else if(systemSetting.get("C_ADDRESS1")==null || systemSetting.get("C_ADDRESS1").toString().trim().length()==0){
			jsondata.put("status", "Company Address 1 can't be empty.");
			return jsondata;
		}
		else if(systemSetting.get("C_ADDRESS2")==null || systemSetting.get("C_ADDRESS2").toString().trim().length()==0){
			jsondata.put("status", "Company Address 2 can't be empty.");
			return jsondata;
		}
		else if(systemSetting.get("C_ADDRESS3")==null || systemSetting.get("C_ADDRESS3").toString().trim().length()==0){
			jsondata.put("status", "Company Address 3 can't be empty.");
			return jsondata;
		}
		else if(systemSetting.get("C_BANKACCOUNT")==null || systemSetting.get("C_BANKACCOUNT").toString().trim().length()==0){
			jsondata.put("status", "Bank Account can't be Empty.");
			return jsondata;
		}
		else if(systemSetting.get("C_APPROVER")==null || systemSetting.get("C_APPROVER").toString().trim().length()==0){
			jsondata.put("status", "Approver can't be empty.");
			return jsondata;
		}				
		else if(systemSetting.get("C_CURRENCYCODE")==null || systemSetting.get("C_CURRENCYCODE").toString().trim().length()==0){
			jsondata.put("status", "Default Currency Code can't be empty. Please select one from the list.");
			return jsondata;
		}
		else if(systemSetting.get("N_SETUPFEE")==null || systemSetting.get("N_SETUPFEE").toString().trim().length()==0||!validator.isNumeric(systemSetting.get("N_SETUPFEE").toString())){
			jsondata.put("status", "Invalid Setting-Up Fee.");
			return jsondata;
		}
		else if(systemSetting.get("N_CURRADJ")==null || systemSetting.get("N_CURRADJ").toString().trim().length()==0 ||!validator.isNumeric(systemSetting.get("N_CURRADJ").toString()) ){
			jsondata.put("status", "Invalid Current Adjustment.");
			return jsondata;
		}
		/*
		else if(systemSetting.get("N_PASSWORDEXP")==null || systemSetting.get("N_PASSWORDEXP").toString().trim().length()==0){
			jsondata.put("status", "Password Expiration can't be empty.");
			return jsondata;
		}
		*/
		
		boolean success = systemSettingDao.updateSystemSettings(systemSetting);
		
		if (success)
		{
			jsondata.put("status", "System Settings Successfully Created...");
		}
		else
		{
			jsondata.put("status", "System Settings Creation fails...");
		}
		
		return jsondata;
	}
	
	/*@SuppressWarnings("unchecked")
	
	public static void main(String args[])
	{
	
	}*/
}
