package com.bdo.factor.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jfree.util.Log;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bdo.factor.dao.AccountingMaintenanceDAO;
import com.bdo.factor.dao.AdjustmentTypeDAO;
import com.bdo.factor.dao.ChartOfAccountDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.SubHeaderDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.ServiceUtility;
import com.bdo.factor.util.XMLParser;

public class SubHeaderService {
	private static Logger log = Logger.getLogger(SubHeaderService.class);
	
	private static SubHeaderService SubHeaderServiceInstance = new SubHeaderService();
	
		private SubHeaderService() { }

		public static SubHeaderService getInstance() {
			return SubHeaderServiceInstance;
		}

	private enum operation{ ADVANCES , REFUND , COLLECTION , DISHONORED }
	
	
	public Boolean createLedgerlEntry(Map mapForm, String glcode, Object value, String account,Long N_TRANSACTIONNO)throws SQLException{
		Boolean result;
		
		AccountingMaintenanceDAO AMD = (AccountingMaintenanceDAO)Persistence.getDAO("AccountingMaintenanceDAO");
		SubHeaderDAO JD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		
		Map o = AMD.getChart(glcode);
		mapForm.put("N_CostCenter",o.get("N_CostCenter"));
		mapForm.put("C_ACCOUNTNAME", o.get("C_AccountName"));
		mapForm.put("C_REFERENCE", o.get("C_ICBSGLCode"));
		mapForm.put("Account",account);
		mapForm.put("value", value);
		mapForm.put("N_CODE",account.contentEquals("N_DEBIT")?81:10);
		mapForm.put("N_TRANSACTIONNO",N_TRANSACTIONNO);
		
	    result = JD.addLedger(mapForm);
	    
		return result;
	}

	public Map getDetails(Map m){
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		return SHD.getDetails(m);
	}

	public String toString(Map map,String name,Long TransactionNo,String Transactiondate, String invoices,String N_REFNO){
		StringBuffer SB = new StringBuffer();
		String particular = invoices.toString().replaceAll("c_invoiceno=", "").replaceAll("\\{", "").replaceAll("\\}", "").replaceAll("\\[", "").replaceAll("\\]", "");
			SB.append(name);//NAME
			SB.append("-"+N_REFNO +":");//TRANSACTION NO
			SB.append(map.get("CLIENTDETAIL")!=null?map.get("CLIENTDETAIL"):"");
			SB.append("("+particular+")");
			SB.append(";"+Transactiondate+";");//TRANSACTION DATE
			SB.append(map.get("AO")!=null?map.get("AO"):"");//AO
			 
			/*
			SB.append(map.get("N_ADVANCEDRATIO")!=null?";"+map.get("N_ADVANCEDRATIO").toString():"");//ADVANCE RATIO
			SB.append(map.get("CE")!=null?";"+map.get("CE").toString():"");//CE RATE
			SB.append(map.get("DC")!=null?";"+map.get("DC").toString():"");//DC RATE
			SB.append(map.get("N_SCR")!=null?";"+map.get("N_SCR").toString():"");//SC RATE
			SB.append(";?");//INVOICE OF DC ?
			SB.append(";?");//INVOICE FOR PAYMENT
			SB.append(map.get("PENRATE")!=null?";"+map.get("PENRATE").toString():"");//PENALTY RATE
			
			SB.append(";?");//OR #
			*/
			
		return (String) SB.toString().subSequence(0, SB.toString().length()>=230?230:SB.toString().length());
	}
	
	public Long createSubHeader(Map SubHeaderMap,  String name,String Transactiondate, String transaction){
		
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		
		Long x = SHD.createSubHeader(SubHeaderMap);
		
		String particular = (String) SubHeaderMap.get("particular");
		
		if(x!=0){
			particular = particular==null?toString(getDetails(SubHeaderMap),name,x,Transactiondate,createInvoiceString(transaction,SubHeaderMap),SubHeaderMap.get("N_REFNO")!=null?SubHeaderMap.get("N_REFNO").toString():""):particular;
			SubHeaderMap.put("N_TRANSACTIONNO", x);
			SubHeaderMap.put("C_PARTICULAR", particular);
			SHD.updateParticulars(SubHeaderMap);
		}
		else
			return (long) 0;
		
		return x; 
	}

	public Boolean updateForCN(Map m,Long TransactionNo){
		m.put("N_TRANSACTIONNO", TransactionNo);
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		String[] s = SHD.getParticular(m).split(":");
		
		m.put("C_PARTICULAR", "COLLECTION with Credit Note - "+m.get("C_RECEIPTNO")+":"+s[1]);
		SHD.updateParticulars(m);
		return SHD.updateForCN(m);
	}
	
	public Boolean createLedgerEntry2(Map map, String module,Long TransactionNo){
		//Boolean loop= false;
		map.put("N_TRANSACTIONNO", TransactionNo);
		map.put("C_USERID", map.get("C_USERID"));
		String[][] methods = XMLParser.getInstance().getMyMethods(module); // module is - advance, collection.....
		try{
			for(int outer=0;outer<=methods.length;outer++){
				if(methods[outer][0]==null)
					break;
				if(Boolean.parseBoolean(methods[outer][3])){
					List<String[]> invoice = (List<String[]>) map.get(methods[outer][2]); 
					if(!invoice.isEmpty()){
						for(int x=0;x<invoice.size();x++){
							String[] inv = invoice.get(x);
							map.put("N_RefNo",inv[0]);
							log.info(inv.length);
							
							if(inv.length>=3){
								if(Double.parseDouble(inv[2])==0&&Double.parseDouble(inv[3])==0){									
										map.put("N_RefNo",null);
										map.put("N_RecBalance",null);
								}
								else{
									map.put("N_RecBalance",inv[2]);
								}
							}
							createLedger(map,methods[outer][0],methods[outer][1],inv[1]);
							map.remove("N_RefNo");
							map.remove("N_RecBalance");
						}
					}
				}
				else
					createLedger(map,methods[outer][0],methods[outer][1],map.get(methods[outer][2]));
			}
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public Boolean createLedger(Map map,String code,String field, Object value)throws Exception{
		
			if(value!=null &&Double.parseDouble(value.toString())!=0){
				
				Map LedgerMap = (HashMap)XMLParser.getCOAMap().get(code);
				SubHeaderDAO JD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
				map.put("N_CostCenter",LedgerMap.get("CostCenter")); //CostCenter
				map.put("C_REFERENCE",LedgerMap.get("GLCode"));//GLCode
				map.put("C_ACCOUNTNAME",LedgerMap.get("GLName"));//Account Name
				map.put("N_CODE",field.contentEquals("N_DEBIT")?81:10);//CODE
				map.put("Account",field);//DEBIT OR CREDIT
				map.put("value", value);//Value
			  JD.addLedger(map);
			}
		
		return true;
	}
	
	//added by CVG 05-31-16
	public Boolean createLedgerEntry3(Map map, String module,Long TransactionNo){
		//Boolean loop= false;
		map.put("N_TRANSACTIONNO", TransactionNo);
		map.put("C_USERID", map.get("C_USERID"));
		String[][] methods = XMLParser.getInstance().getMyMethods(module); // module is - advance, collection.....
		try{
			for(int outer=0;outer<=methods.length;outer++){
				if(methods[outer][0]==null)
					break;
				if(Boolean.parseBoolean(methods[outer][3])){
					List<String[]> invoice = (List<String[]>) map.get(methods[outer][2]); 
					if(!invoice.isEmpty()){
						for(int x=0;x<invoice.size();x++){
							String[] inv = invoice.get(x);
							map.put("N_RefNo",inv[0]);
							log.info(inv.length);
							
							if(inv.length>=3){
								if(Double.parseDouble(inv[2])==0&&Double.parseDouble(inv[3])==0){									
										map.put("N_RefNo",null);
										map.put("N_RecBalance",null);
								}
								else{
									map.put("N_RecBalance",inv[2]);
								}
							}
							createLedgerForCN(map,methods[outer][0],methods[outer][1],inv[1]);
							map.remove("N_RefNo");
							map.remove("N_RecBalance");
						}
					}
				}
				else
					createLedgerForCN(map,methods[outer][0],methods[outer][1],map.get(methods[outer][2]));
			}
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	

	public Boolean createLedgerForCN(Map map,String code,String field, Object value)throws Exception{
		
		if(value!=null &&Double.parseDouble(value.toString())!=0){
			
			Map LedgerMap = (HashMap)XMLParser.getCOAMap().get(code);
			SubHeaderDAO JD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
			map.put("N_CostCenter",LedgerMap.get("CostCenter")); //CostCenter
			map.put("C_REFERENCE",LedgerMap.get("GLCode"));//GLCode
			map.put("C_ACCOUNTNAME",LedgerMap.get("GLName"));//Account Name
			map.put("N_CODE",field.contentEquals("N_DEBIT")?81:10);//CODE
			map.put("Account",field);//DEBIT OR CREDIT
			map.put("value", value);//Value
			
		  JD.updateLedgerForCN(map);
		}
	
	return true;
}
	
	//end

	public Boolean createAdjustmentEntry(Map map,Long TransactionNo){
		AdjustmentTypeDAO adjDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
		ServiceUtility.viewUserParameters(map);
		Log.info("Creating Adjusment Entry......");
		List<Map> adjustments = adjDAO.getAdjustmentList(map);
		
		
		
		SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		
		for (int x=0;x<adjustments.size();x++){
			Map thisAdjustment = (Map)adjustments.get(x);
			
			thisAdjustment.put("interestAdj", thisAdjustment.get("n_amount"));
			thisAdjustment.put("ClEq", thisAdjustment.get("n_amount"));
			thisAdjustment.put("D_TRANSACTIONDATE",SDF.format(date.newDate())); //before:new date()

			try {
				
				String debitToClient =thisAdjustment.get("c_debit").toString();
				Integer effectOnReserve =Integer.parseInt(thisAdjustment.get("c_adjres").toString());
				
				//  cDebitToClient equal to 1 and 2 (Yes/N0)
				if (!debitToClient.equalsIgnoreCase("2")){
					
					if (debitToClient.equalsIgnoreCase("1")){ //debitToClient=1 (Yes)
						createLedgerlEntry(map, thisAdjustment.get("C_GLCODE").toString(), thisAdjustment.get("n_amount"), "N_CREDIT",TransactionNo);
						log.info("Normal accounting entry of adjustment has been created!");
					}else{
						createLedgerlEntry(map, thisAdjustment.get("C_GLCODE").toString(), thisAdjustment.get("n_amount"), "N_DEBIT",TransactionNo);
						log.info("Accounting entry of adjustment [Add Reserve] with credit to client has been created!");
					}
					
					
				}else{ //debitToClient = 2 (No Effect)
					
					switch(effectOnReserve){
				
					case 2: // Less on Reserve [Normal Balance of Client's Equity (credit)]
						
						SubHeaderService.getInstance().createLedgerEntry2(thisAdjustment, "ADJ-LESS-RESERVE-NO-EFFECT", TransactionNo);
						log.info("Accounting entry of adjustment [Less Reserve] with no effect on release has been created!");
						break;
					case 1: // Add on Reserve [Normal Balance of Client's Equity (credit)]
						SubHeaderService.getInstance().createLedgerEntry2(thisAdjustment, "ADJ-ADD-RESERVE-NO-EFFECT", TransactionNo);
						log.info("Accounting entry of adjustment [Add Reserve] with no effect on release has been created!");
						break;				
					}
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
			
		}
		
		return true;
	}
	
	public Boolean cancelSubHeaderEntry(Map m){
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		
		return SHD.cancelSubHeaderEntry(m);
	}
	
	public Map getSubHeader(Map m){
		Map jsondata = new HashMap();
		
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		jsondata = ServiceUtility.toJQGrid(SHD, "countSubHeader", "getSubHeader", m);
		
		return jsondata;
	}
	
	public Map getInfoByTransactionNo(Map m){
		ServiceUtility.viewUserParameters(m);
		Map jsondata = new HashMap();
		
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		jsondata = SHD.getInfoByTransactionNo(m);
		
		return jsondata;
		
	}
	
	public Map getSubLedgerTransactionNo(Map m){
		Map jsondata = new HashMap();
		
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		jsondata = ServiceUtility.toJQGrid(SHD, "countSubLedger", "getSubLedger", m);
		
		return jsondata;
		
	}

	public String createInvoiceString(String operations,Map m){
		Integer num;
		List<String> stringBuild = new ArrayList<String>();
		List<String> whereBuild = new ArrayList<String>();
		List ma = new ArrayList();
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		
		if(operations!=null&&!operations.contentEquals("")){
			num = operation.valueOf(operations).ordinal();
			
			String sql="";
			
			switch(num){
				case 0:
						log.info("ADVANCES");
						sql ="SELECT DISTINCT(inv.c_custcode),cc.n_dunning  FROM invoice inv "+
									"INNER JOIN cclink cc ON inv.c_custcode=cc.c_custcode AND inv.c_clntcode=cc.c_clntcode "+
									"WHERE inv.c_clntcode='"+m.get("C_CLNTCODE")+"' AND inv.c_status='2'";
						log.info(sql);					
						ma = SHD.getQueryMap(sql);
						if(ma!=null&&ma.size()!=0){ 
							for(int loop=0;loop<ma.size();loop++){
								Map sa= (Map) ma.get(loop);
								sql = "SELECT c_invoiceno FROM invoice WHERE c_status=2 AND c_clntcode='"+m.get("C_CLNTCODE")+"'AND c_custcode="+sa.get("c_custcode");
								log.info(sql);
								List<String> s = SHD.getQueryString(sql);
								log.info(sa.get("n_dunning")+"("+s.toString()+")");
								stringBuild.add(sa.get("n_dunning")+"("+s.toString()+")");
							}
						}
						break;
						
				case 1:
						log.info("REFUND");
						sql ="SELECT DISTINCT(n_refno) FROM receiptsdtl WHERE n_refno IN(SELECT n_refno FROM receiptshdr WHERE  N_REFUNDREFNO IS NULL AND C_STATUS='2' AND c_receipttype <> '3' AND C_CLNTCODE='"+m.get("C_CLNTCODE")+"' )";
						log.info(sql);
						whereBuild = SHD.getQueryString(sql);
						 
						if(whereBuild!=null&&whereBuild.size()!=0){
							sql = "SELECT DISTINCT(cc.c_custcode),cc.n_dunning FROM receiptsdtl rd "+
								  "INNER JOIN invoice inv ON rd.n_invno=inv.n_invno "+
								  "INNER JOIN cclink cc ON inv.c_custcode=cc.c_custcode AND inv.c_clntcode=cc.c_clntcode "+
								  "WHERE n_refno IN( "+(whereBuild.toString()).replaceAll("[\\{\\}\\[\\]n_refno=]","")+")";						
							ma = SHD.getQueryMap(sql);
							
							if(ma!=null&&ma.size()!=0){ 
								for(int loop=0;loop<ma.size();loop++){
									Map sa= (Map) ma.get(loop);
									sql = "SELECT c_invoiceno FROM (SELECT DISTINCT(rd.n_invno),inv.c_invoiceno FROM receiptsdtl rd "+
										  "INNER JOIN invoice inv ON rd.n_invno=inv.n_invno "+
										  "INNER JOIN cclink cc ON inv.c_custcode=cc.c_custcode AND inv.c_clntcode=cc.c_clntcode "+
										  "WHERE n_refno IN( "+(whereBuild.toString()).replaceAll("[\\{\\}\\[\\]n_refno=]","")+") " +
										  "AND cc.c_custcode="+sa.get("c_custcode")+")q1";
									log.info(sql);
									List<String> s = SHD.getQueryString(sql);
									log.info(sa.get("n_dunning")+"("+s.toString()+")");
									stringBuild.add(sa.get("n_dunning")+"("+s.toString()+")");
								}
							}
						}
						break;
						
				case 2:	
						log.info("COLLECTION");
						sql="SELECT  c_clntcode, c_custcode,n_dunning FROM cclink WHERE C_CUSTCODE='"+m.get("C_CUSTCODE").toString()+"'AND C_CLNTCODE='"+m.get("C_CLNTCODE").toString()+"'";
						log.info(sql);
						Map sa = SHD.getQueryMap(sql).get(0);
						if(m.get("invoices2")!=null){
							stringBuild.add(sa.get("n_dunning")+"("+m.get("invoices2").toString()+")");
						}
						else
							stringBuild.add(sa.get("n_dunning")+"(N/A)");
						break;
					
				case 3:
						log.info("DISHONORED COLLECTION");
						sql="SELECT  c_clntcode, c_custcode,n_dunning FROM cclink WHERE C_CUSTCODE='"+m.get("C_CUSTCODE").toString()+"'AND C_CLNTCODE='"+m.get("C_CLNTCODE").toString()+"'";
						log.info(sql);
						Map sa2 = SHD.getQueryMap(sql).get(0);
						sql = "SELECT rd.c_invoiceno FROM receiptshdr rh " +
							  "INNER JOIN receiptsdtl rd on rh.n_refno = rd.n_refno "+
							  "WHERE rh.n_refno ='"+m.get("N_REFNO")+"'";
						log.info(sql);
						List<String> s = SHD.getQueryString(sql);
						log.info(sa2.get("n_dunning")+"("+s.toString()+")");
						stringBuild.add(sa2.get("n_dunning")+"("+s.toString()+")");
						break;
			}
	}
		return stringBuild.toString();
	}

	public Map getCollectionRefHeader(int n_RefNo){
		SubHeaderDAO SHD  = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		Map map = SHD.getCollectionRefHeader(n_RefNo);
		return map;
	}
	
	public List<Map> getCollectionRefLedger(int n_RefNo){
		SubHeaderDAO SHD  = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		List<Map> listMap = SHD.getCollectionRefLedger(n_RefNo);
		return listMap;
	}
	
	public List<Map> getCreditNotes(int n_RefNo){
		SubHeaderDAO SHD  = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		List<Map> listMap = SHD.getCreditNotes(n_RefNo);
		return listMap;
	}
	
	public List<Map> getReceipsDtl(int n_RefNo){
		SubHeaderDAO SHD  = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		List<Map> listMap = SHD.getReceipsDtl(n_RefNo);
		return listMap;
	}
	
	public Map addManualEntry(Map mapForm){
		Boolean result;
		Map jsonData = new HashMap();
		SimpleDateFormat SDF = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat UDF = new SimpleDateFormat("yyyy/MM/dd");
		AccountingMaintenanceDAO AMD = (AccountingMaintenanceDAO)Persistence.getDAO("AccountingMaintenanceDAO");
		SubHeaderDAO JD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		if(mapForm.get("C_GLCODE")!=null&&!mapForm.get("C_GLCODE").toString().contentEquals("")){
			try{
				Map o = AMD.getChart(mapForm.get("C_GLCODE").toString());
				try {
					mapForm.put("D_TRANSACTIONDATE", UDF.format(SDF.parse(mapForm.get("D_TRANSACTIONDATE").toString())));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mapForm.put("N_CostCenter",o.get("N_CostCenter"));
				mapForm.put("C_ACCOUNTNAME", o.get("C_AccountName"));
				mapForm.put("C_REFERENCE", o.get("C_ICBSGLCode"));
				mapForm.put("Account",mapForm.get("NBALANCE"));//NORMAL BALANCE
				mapForm.put("value", mapForm.get("BALANCE"));//AMOUNT
				mapForm.put("N_CODE",mapForm.get("NBALANCE").toString().contentEquals("N_DEBIT")?81:10);
				mapForm.put("N_TRANSACTIONNO",mapForm.get("N_TRANSACTIONNO"));
			    result = JD.addLedger(mapForm);
			    jsonData.put("success", "New Entry Added");
			}catch(Exception e){
				jsonData.put("failed", "Invalid or Empty Field");
			}
		}
		else
			jsonData.put("failed", "Invalid or Empty GLCode");
		return jsonData;
	}
	
	public Map editEntry(Map map){
		Map json =new HashMap();
		SubHeaderDAO JD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		try{
			if(JD.editEntry(map))
				json.put("success", "Record Updated");
		}catch(Exception e){
			json.put("failed","Invalid Format or Empty Field");
			e.printStackTrace();
		}
			
		return json;
	}
	
	public Map deleteEntry(Map map){
		Map json =new HashMap();
		SubHeaderDAO JD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		if(JD.deleteEntry(map))
			json.put("success", "Record Deleted");
		return json;
	}
	
	public Map addManualheader(Map headerMap){
		Map json = new HashMap();
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
		headerMap.put("D_TRANSACTIONDATE", SDF.format(date.newDate())); //before: new date()
		
		AccountingMaintenanceDAO AMS  = (AccountingMaintenanceDAO)Persistence.getDAO("AccountingMaintenanceDAO");
		headerMap.put("C_CLIENTCODE", AMS.getClientCode(headerMap));
		if(headerMap.get("C_CLIENTCODE")!=null){
			try{
				if(SHD.addManualheader(headerMap)){
					json.put("success", "New Record Added");
				}
			}catch(Exception e){
				json.put("failed", "Format Error or Empty Field");
			}
		}else
				json.put("failed", "Invalid or Empty Client");
		return json;
	}
	
	public Map updateHeader(Map headerMap){
		Map json = new HashMap();
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		try{
			if(SHD.updateHeader(headerMap)){
				json.put("success", "Record Updated");
			}
		}catch(Exception e){
			json.put("failed", "Format Error or Empty Field");
		}
		return json;
	}
	
	public Map deleteHeader(Map headerMap){
		Map json = new HashMap();
		SubHeaderDAO SHD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
		if(SHD.deleteHeader(headerMap)){
			json.put("success", "Record Deleted");
		}
		return json;
	}
	
	

}
