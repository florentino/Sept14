package com.bdo.factor.service;

import com.bdo.factor.beans.LDAPSConfiguration;
import com.bdo.factor.dao.LDAPSConfigurationDAO;
import com.bdo.factor.dao.Persistence;

public class LDAPSConfigurationService {
	public LDAPSConfigurationDAO _LDAPSConfigurationDAO = (LDAPSConfigurationDAO)Persistence.getDAO("LDAPSConfigurationDAO"); 
	public LDAPSConfiguration getLDAPSConfiguration(){
		return _LDAPSConfigurationDAO.getLDAPSConfiguration();
	}
}
