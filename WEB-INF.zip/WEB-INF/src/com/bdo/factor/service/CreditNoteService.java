package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CreditNote;
import com.bdo.factor.beans.ReceiptsDtl;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.CreditNoteDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.ReceiptsDtlDAO;
import com.bdo.factor.util.CreditNoteUtility;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ReceiptsDtlUtility;
import com.bdo.factor.util.ServiceUtility;

public class CreditNoteService {
	private static Logger log = Logger.getLogger(CreditNoteService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static CreditNoteService cnService = new CreditNoteService();
	
	private CreditNoteService() { }

	public static CreditNoteService getInstance() {
		return cnService;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map addCreditNote(Map creditNoteForm) {
		Map jsonData = new HashMap();
		
		//creditNoteForm.put("D_TRANSACTIONDATE", DateHelper.format(new Date()));
		
		ServiceUtility.viewUserParameters(creditNoteForm);		
		CreditNote cn = CreditNoteUtility.getInstance().toObject(creditNoteForm);
				
		try {
			
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
			log.info("search if Credit Note is already added...");
			String source = creditNoteForm.get("C_SOURCE") != null ? creditNoteForm.get("C_SOURCE").toString().trim() : null;
			int count = 0;
			if (source == null) {
				count = this.searchCreditNoteCountByInvoice(creditNoteForm);
			}
			else if (source.equalsIgnoreCase("collectionsDetail")) {
				count = this.searchCreditNoteCountByReceipts(creditNoteForm);
			}
			log.info("count... :" + count);
			if (count > 0) {
				jsonData.put("status", "Credit Note Already Exists.");
				return jsonData;
			}
			int success = cnDAO.addCreditNote(creditNoteForm);
			
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			boolean is_rmu = clientDAO.GetClientStatus(cn.getC_CLNTCODE());
			if(is_rmu)
				creditNoteForm.put("RMUCNAmount", cn.getN_AMOUNT());
			else
				creditNoteForm.put("CNAmount", cn.getN_AMOUNT());
			
			SubHeaderService JS = SubHeaderService.getInstance();
			//try overwrite yung unang insert sa  subledger..
			//changed from createLedgerEntry2 to createLedgerEntry3
			if(JS.createLedgerEntry3(creditNoteForm, "Credit-Note", Long.parseLong(creditNoteForm.get("N_TRANSACTIONNO").toString())))
				//pag nakacomment yung particulars is 'partial payment' hindi 'with creditnote'
				JS.updateForCN(creditNoteForm,Long.parseLong(creditNoteForm.get("N_TRANSACTIONNO").toString()));
			
			
//			JS.createLedgerlEntry(creditNoteForm, "143001004001", cn.getN_AMOUNT(), "N_DEBIT",Long.parseLong(creditNoteForm.get("N_TRANSACTIONNO").toString()));
//			JS.createLedgerlEntry(creditNoteForm, "110602201000", cn.getN_AMOUNT(), "N_CREDIT",Long.parseLong(creditNoteForm.get("N_TRANSACTIONNO").toString()));
			
			if (success > 0) {
				cn.setN_REFNO(success);
				
				String userID = creditNoteForm.get("C_USERID").toString();
				String receiptAmount = creditNoteForm.get("N_RECEIPTAMOUNT").toString() != null ? creditNoteForm.get("N_RECEIPTAMOUNT").toString() : "0";
				String amount = creditNoteForm.get("N_AMOUNT").toString() != null ? creditNoteForm.get("N_AMOUNT").toString().replaceAll(",", "") : "0";
				
				Map receiptsForm = new HashMap();
				receiptsForm.put("C_CLNTCODE", cn.getC_CLNTCODE() + "");
				//receiptsForm.put("N_CHECKAMOUNT", receiptAmount);
				receiptsForm.put("N_CHECKAMOUNT", amount);
				receiptsForm.put("C_RECEIPTTYPE", "3");
				receiptsForm.put("C_USERID", userID);				
				
				boolean result = ClientService.getInstance().updateClientTransAmountForCN(receiptsForm);
											
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "I", "CREDITNOTE", cn.toString());
						
				//rdc06162010 update running balance in cclink
				String clntCode = cn.getC_CLNTCODE();
				String custCode = cn.getC_CUSTCODE();
				boolean result2 = CCLinkService.getInstance().updateRunningBalance(clntCode, custCode,  Double.parseDouble(amount), userID);
				log.info("Cancel CN updateRunningBalance: "+ result2);
				
				jsonData.put("status", "Credit Note Added");				
			}
		}
		catch (Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		return jsonData;	
	}
	
	public Map creditNoteForCNForm(Map creditNoteForm) {
		Map jsonData = new HashMap();
		String mode = creditNoteForm.get("mode") != null ? creditNoteForm.get("mode").toString() : "0";
		if (mode.trim().equalsIgnoreCase("add")) {
			return this.addCreditNoteForCNForm(creditNoteForm);
		}
		else if(mode.trim().equalsIgnoreCase("update")) {
			return this.updateCreditNoteForCNForm(creditNoteForm);
		}
		return jsonData;
		
		
	}
	
	private Map updateCreditNoteForCNForm(Map creditNoteForm) {
		Map jsonData = new HashMap();
		
		ServiceUtility.viewUserParameters(creditNoteForm);
		CreditNote cn = CreditNoteUtility.getInstance().toObject(creditNoteForm);
		try {
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");			
			creditNoteForm.put("N_AMOUNT", creditNoteForm.get("N_AMOUNT") != null ? Double.parseDouble(creditNoteForm.get("N_AMOUNT").toString().replaceAll(",", "")) : 0);
			boolean success = cnDAO.updateCreditNote(creditNoteForm);
			if (success) {
				double cnAmount = creditNoteForm.get("N_AMOUNT") != null ? Double.parseDouble(creditNoteForm.get("N_AMOUNT").toString().replaceAll(",", "")) : 0;
				double cnAmountOld = creditNoteForm.get("N_AMOUNT_OLD") != null ? Double.parseDouble(creditNoteForm.get("N_AMOUNT_OLD").toString().replaceAll(",", "")) : 0;
							
				String userID = creditNoteForm.get("C_USERID").toString();
				String status = creditNoteForm.get("C_STATUS") != null ? creditNoteForm.get("C_STATUS").toString() : "0";
								
				if (cnAmount != cnAmountOld && status.trim().equals("2")) {
					double updatedAmount = cnAmount - cnAmountOld;
					
					Map receiptsForm = new HashMap();
					receiptsForm.put("C_CLNTCODE", cn.getC_CLNTCODE() + "");
					receiptsForm.put("N_CHECKAMOUNT", updatedAmount + "");
					receiptsForm.put("C_RECEIPTTYPE", "3");
					receiptsForm.put("C_USERID", userID);
					
					boolean result = ClientService.getInstance().updateClientTransAmountForCN(receiptsForm);
				}
				
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "CREDITNOTE", cn.toString());
												
				jsonData.put("status", "Credit Note Updated");
			}
		}
		catch (Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		return jsonData;
	}	
	
	public Map updateCreditNoteStatus(Map creditNoteForm) {
		Map jsonData = new HashMap();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		AuditService as = AuditService.getInstance();
		ServiceUtility.viewUserParameters(creditNoteForm);		
		try {
			String status = creditNoteForm.get("C_STATUS") != null ? creditNoteForm.get("C_STATUS").toString() : "0";
			creditNoteForm.put("C_STATUS", "3");
			
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
			creditNoteForm.put("D_CANCELLEDDATE", date.newDate()); //before: new Date()
			boolean success = cnDAO.updateCreditNoteStatus(creditNoteForm);
			if (success) {
				double cnAmount = creditNoteForm.get("N_AMOUNT") != null ? Double.parseDouble(creditNoteForm.get("N_AMOUNT").toString().replaceAll(",","")) : 0;
				String clientCode = creditNoteForm.get("C_CLNTCODE") != null ? creditNoteForm.get("C_CLNTCODE").toString() : "0";
				String custCode = creditNoteForm.get("C_CUSTCODE") != null ? creditNoteForm.get("C_CUSTCODE").toString() : "0";
				String refNo = creditNoteForm.get("N_REFNO") != null ? creditNoteForm.get("N_REFNO").toString() : "0";				
				String c_InvoiceNo	= creditNoteForm.get("C_INVOICENO") != null ? creditNoteForm.get("C_INVOICENO").toString() : "";								
				String userID = creditNoteForm.get("C_USERID").toString();
				
				//if (status.trim().equalsIgnoreCase("2")){
					Map receiptsForm = new HashMap();
					receiptsForm.put("C_CLNTCODE", clientCode);
					receiptsForm.put("N_CHECKAMOUNT", "-" + cnAmount);
					receiptsForm.put("C_RECEIPTTYPE", "3");
					receiptsForm.put("C_USERID", userID);
				
					//boolean result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
			//	}
				boolean result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
				
				//rdc04222010 reset cn/invoice status
				String cstatus ="0";
				ReceiptsDtlService rds = ReceiptsDtlService.getInstance();
				int invCount = rds.searchReceiptsDetailByInvoice(0,c_InvoiceNo);
				if (invCount>0) {
					cstatus = "4";
					Map CNForm = new HashMap();
					CNForm.put("C_INVOICENO", c_InvoiceNo);
					CNForm.put("C_TYPE", "2");
					ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
					boolean ctypestat = rDetailDAO.updateCheckTypePartial(CNForm);
					log.info(">>>>>>>>>>>>>>>ctypestat : " + ctypestat + ",C_INVOICENO:"+c_InvoiceNo);
				} else {
					cstatus = "3";
				}
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				boolean updateInvoiceStat = invoiceDAO.updateInvoiceStatusByInvoiceOnly(c_InvoiceNo, cstatus, null);
				if (updateInvoiceStat) {						
					as.addAudit(userID, "U", "INVOICE", "INVOICES: " + c_InvoiceNo + "STATUS: " + cstatus + "D_FULLYPAIDATE: null");
				}
				log.info("invCount : " + invCount + " updateInvoiceStat : " +updateInvoiceStat);
				//end reset cn/invoice status			
				
				StringBuilder str = new StringBuilder();
				str.append("Cancel CN:");
				str.append("N_REFNO = ").append(refNo);
				str.append("C_CLNTCODE = ").append(clientCode);
				str.append("C_STATUS = ").append(status);
				str.append("N_AMOUNT = ").append(cnAmount);
				
				as.addAudit(userID, "D", "CREDITNOTE", str.toString());
							
				//rdc06162010 update running balance in cclink
				boolean result2 = CCLinkService.getInstance().cancelRunningBalance(clientCode, custCode, cnAmount, userID);
				log.info("Cancel CN updateRunningBalance: "+ result2);
				
				jsonData.put("status", "Credit Note Updated");
			}
		}
		catch (Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		return jsonData;
	}
	
	public boolean updateCreditNoteStatusByBatch(Map creditNoteForm) {
		boolean success = false;		
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		ServiceUtility.viewUserParameters(creditNoteForm);
		try {
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
			String cnStatus = creditNoteForm.get("C_RECEIPTTYPE") != null ? creditNoteForm.get("C_RECEIPTTYPE").toString().trim() : null;
			if (cnStatus.equals("3")) {
				creditNoteForm.put("D_CANCELLEDDATE", date.newDate());
			}
			else {
				creditNoteForm.put("D_CANCELLEDDATE", null);
			}
			
			success = cnDAO.updateCreditNoteStatusAndDateByBatch(creditNoteForm);
			
			if (success) {
				boolean result = false;
				if (cnStatus.equals("3")) {
					result = ClientService.getInstance().updateClientTransAmountForCancelledCN(creditNoteForm);
				}
				else {
					result = ClientService.getInstance().updateClientTransAmount(creditNoteForm);
				}
				
				String refNo = creditNoteForm.get("N"
						+ "_REFNO").toString();
				String clientCode = creditNoteForm.get("C_CLNTCODE").toString();
				String status = "3";
				String cnAmount = creditNoteForm.get("N_CHECKAMOUNT").toString();
				String userID = creditNoteForm.get("C_USERID").toString();
				
				AuditService as = AuditService.getInstance();
				StringBuilder str = new StringBuilder();
				str.append("Cancel CN - Dishonored Check:");
				str.append("N_REFNO = ").append(refNo);
				str.append("C_CLNTCODE = ").append(clientCode);
				str.append("C_STATUS = ").append(status);
				str.append("N_AMOUNT = ").append(cnAmount);
				
				as.addAudit(userID, "D", "CREDITNOTE", str.toString());
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return success;
	}	
	
	public boolean updateStatusBatch(Map creditNoteForm) {
		boolean success = false;		
		ServiceUtility.viewUserParameters(creditNoteForm);
		try {
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
			success = cnDAO.updateCreditNoteStatusByBatch(creditNoteForm);				
			
		}
		catch (Throwable x) {
			x.printStackTrace();
		}
		return success;
	}

	public Map addCreditNoteForCNForm(Map creditNoteForm) {
		Map jsonData = new HashMap();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		creditNoteForm.put("D_TRANSACTIONDATE", DateHelper.format(date.newDate())); //before: new Date()
		creditNoteForm.put("D_APPLICATIONDATE", DateHelper.format(date.newDate())); //before: new Date()
		creditNoteForm.put("C_STATUS", "2");
		
		ServiceUtility.viewUserParameters(creditNoteForm);		
		CreditNote cn = CreditNoteUtility.getInstance().toObject(creditNoteForm);
				
		try {
			
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
			creditNoteForm.put("N_AMOUNT", creditNoteForm.get("N_AMOUNT").toString() != null ? creditNoteForm.get("N_AMOUNT").toString().replaceAll(",", ""): null);
			int success = cnDAO.addCreditNote(creditNoteForm);
			
			if (success > 0) {
				cn.setN_REFNO(success);
				
				String userID = creditNoteForm.get("C_USERID").toString();
				String amount = creditNoteForm.get("N_AMOUNT").toString() != null ? creditNoteForm.get("N_AMOUNT").toString().replaceAll(",", "") : "0";
				
				Map receiptsForm = new HashMap();
				receiptsForm.put("C_CLNTCODE", cn.getC_CLNTCODE() + "");
				receiptsForm.put("N_CHECKAMOUNT", amount);
				receiptsForm.put("C_RECEIPTTYPE", "3");
				receiptsForm.put("C_USERID", userID);
				
				boolean result = ClientService.getInstance().updateClientTransAmountForCN(receiptsForm);
											
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "I", "CREDITNOTE", cn.toString());
												
				jsonData.put("status", "Credit Note Added");				
			}
		}
		catch (Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		return jsonData;
	}
	
	public int searchCreditNoteCountByInvoice(Map creditNoteForm) {
		CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
		return cnDAO.searchCreditNoteCountByInvoice(creditNoteForm);
	}
	
	public int searchCreditNoteCountByReceipts(Map creditNoteForm) {
		CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
		return cnDAO.searchCreditNoteCountByReceipts(creditNoteForm);
	}
	
	public Map searchCreditNoteByBranchCode(Map cnMap){
		
		Map jsondata = new HashMap();
		String totalRecords = "";
		String c_BranchCode = "";
		
		try {
			log.info("--->> searchCreditNoteByBranchCode SERVICE ...");		
			
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
			c_BranchCode = (String) cnMap.get("C_BRANCHCODE");
			String n_RefNo = (String) cnMap.get("N_REFNO");
 			totalRecords = cnDAO.getTotalCreditNoteRecordsByBranch(cnMap);			
			cnMap = ServiceUtility.addPaging(cnMap,totalRecords);			
			List lCN = cnDAO.searchCreditNoteByBranch(cnMap);
			ServiceUtility.viewUserParameters(cnMap);
			
			log.info("--->> searchGroup RECORDS: "+lCN.size());
			if((lCN!=null) && (lCN.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lCN, ((String)cnMap.get("records")),((String)cnMap.get("page")),((String)cnMap.get("total")));
			}else{				
				jsondata.put("status","Search Credit Note By Branch Code Failed ... ");				
			}
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;			
	}	
	
	public Map searchCreditNoteByRefNo(Map cnMap) {
		Map jsondata = new HashMap();
		String totalRecords = "";
		
		try {
			
			log.info("--->> searchCreditNoteByRefNo SERVICE ...");		
			ServiceUtility.viewUserParameters(cnMap);
			
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");		
			List lCN = cnDAO.searchCreditNoteByRefNo(cnMap);
 			totalRecords = ""+lCN.size();			
			cnMap = ServiceUtility.addPaging(cnMap,totalRecords);			
			
			if((lCN!=null) && (lCN.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lCN, ((String)cnMap.get("records")),((String)cnMap.get("page")),((String)cnMap.get("total")));
			}else{				
				jsondata.put("status","Search Credit Note By RefNo Failed ... ");				
			}
			
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;	
	}
	
	public Map searchCreditNoteByReceiptNo(Map cnMap) {
		Map jsondata = new HashMap();
		String totalRecords = "";
		
		try {
			
			log.info("--->> searchCreditNoteByReceiptNo SERVICE ...");		
			ServiceUtility.viewUserParameters(cnMap);
			
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");		
			List lCN = cnDAO.searchCreditNoteByReceiptNo(cnMap);
			log.info("size: lCN >> " + lCN.size());
			
			if((lCN!=null) && (lCN.size()>0)){
				jsondata.put("status", "successful");
				jsondata.put("returnData", lCN);
				
			}			
			else{				
				jsondata.put("status","No Data Found.");				
			}
			
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;	
	}
	
	public List searchCreditNoteByReceiptNoList(String receiptNo) {		
		String totalRecords = "";
		
		try {			
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
			Map map = new HashMap();
			map.put("C_RECEIPTNO", receiptNo);
			List lCN = cnDAO.searchCreditNoteByReceiptNo(map);
			return lCN;
			
		}
		catch(Throwable x) {			
			x.printStackTrace();
		}
		return null;
			
	}
	

	/// added by: m.gonzalez ///
	public Map searchScheduleCreditNote(Map cnMap){
		
		Map jsondata = new HashMap();
		Map newRecordsMap = new HashMap();
		String totalRecords = "";
		List records = new ArrayList();
		
		try {
			
			ServiceUtility.viewUserParameters(cnMap);
			
			CreditNoteDAO cnDAO = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");
			records = cnDAO.searchScheduleCreditNote(cnMap);
			totalRecords = records.size()+"";
			
			cnMap = ServiceUtility.addPaging(cnMap,totalRecords);
			
			records = cnDAO.searchScheduleCreditNote(cnMap);	
		
			ServiceUtility.viewUserParameters(cnMap);
						
			System.out.println("--->> searchBank RECORD-SIZE: "+records.size());
			System.out.println("--->> records: "+((String)cnMap.get("records")));
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)cnMap.get("records")),((String)cnMap.get("page")),((String)cnMap.get("total")));
			}else{
				newRecordsMap = new HashMap();
				records = new ArrayList();
				newRecordsMap.put("D_APPLICATIONDATE", "No Records Found ...");
				records.add(newRecordsMap);
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, "","","");
				jsondata.put("status","Search Bank Failed ... ");
			}
			
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;			
	}		
	
	

}
