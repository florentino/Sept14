package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.AdjustmentType;
import com.bdo.factor.beans.Branch;
import com.bdo.factor.beans.PostDate;
import com.bdo.factor.dao.AdjustmentTypeDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.CurrencyDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.PostDateDAO;
import com.bdo.factor.util.AdjustmentTypeUtility;
import com.bdo.factor.util.BranchUtility;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class BranchService {
	private static Logger log = Logger.getLogger(BranchService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static BranchService branchServiceInstance = new BranchService();
	
	public BranchService() { }

	public static BranchService getInstance() {
		return branchServiceInstance;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public String searchBranchByCode(String c_BrCode){
		String branch = null;
		
		log.info("--->> searchBranchByCode SERVICE ...");
			
		try{			
			BranchDAO branchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");						
			branch = branchDAO.searchBranchByCode(c_BrCode);
			
		}catch(Throwable x){
			
			x.printStackTrace();
		}	
		
		return branch;
		
	}	
	
	public Map searchBranchByCodeAComplete(String c_BrCode){		
		log.info("--->> searchBranchByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		BranchDAO BranchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");
				
		List records = BranchDAO.searchBranchByCodeAComplete(c_BrCode);
		jsonData.put("result", records);
		
		return jsonData;
	}
	
	
	
//?StringXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	
	public List searchBranchByBCode(String c_BrCode){		
		log.info("--->> searchBranchByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		BranchDAO BranchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");
				
		return BranchDAO.searchBranchByCodeAComplete(c_BrCode);
		
	}	
//?C_NameXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	
	public Map searchBranchList(Map m){		
		log.info("--->> searchBranchByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		BranchDAO BranchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");
		ArrayList records = (ArrayList) BranchDAO.searchBranchList(m);
		
		//HashMap hm = (HashMap) records.get(0);		
		
		String resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_Name","C_Name");
		log.info("records: " + records.size());
		jsonData.put("AUTOCOMPLETE", resultString);
		
		return jsonData;
	}	
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	

//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchBranch(Map branchMap){
		
		Map jsondata = new HashMap();
		String totalRecords = "";
		
		log.info("--->> searchCheckType SERVICE ...");		
		try {			
			BranchDAO BranchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");
			
			totalRecords = BranchDAO.getTotalRecordsBranch();	
			
			branchMap = ServiceUtility.addPaging(branchMap,totalRecords);
			
			List lBranch = BranchDAO.searchBranch(branchMap);
			ServiceUtility.viewUserParameters(branchMap);
			
			log.info("--->> searchBranch RECORDS: "+lBranch.size());
			
			if((lBranch!=null) && (lBranch.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lBranch,((String)branchMap.get("records")),((String)branchMap.get("page")),((String)branchMap.get("total")));
			}else{				
				jsondata.put("status","Search Branch Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;		
	}	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map addBranch(Map branchMap){		
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map jsondata = new HashMap();
		try {			
			ServiceUtility.viewUserParameters(branchMap);
			
			Branch branch = BranchUtility.toObject(branchMap);			
			String operation = (String) branchMap.get("operation");
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {
				this.updateBranch(branchMap);
			}
			else {
				
				BranchDAO branchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");
				String c_BranchCodeOld = (String) branchMap.get("C_BRANCHCODEOLD");
				
				boolean duplicate = this.isDuplicate(branch.getC_BrCode());
				if (duplicate) {
					jsondata.put("status","Failed to Add Branch. Record with same branch code already exists.");
					return jsondata;
				}				
				
				boolean success = branchDAO.addBranch(branchMap);
				
				
				if(success){
					log.info("adding audit log2");
					String userID = (String) branchMap.get("C_USERID");
					String branchCode = (String) branchMap.get("C_BRANCHCODE");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "BRANCH", branch.toString());
					
					//PostDateService pDS = PostDateService.getInstance();
					//pDS.insertPostDateFromBranch(new Date(), new Date(), 07/31/2009, "88", 12/31/2008);
					
					Date dt = date.newDate();//before:new Date();
								
					Map pd = new HashMap();
					GregorianCalendar gc = new GregorianCalendar();	
					gc.setTime(dt);
					log.info("Generated date "+gc.getTime());

					pd.put("D_INITIALIZE", DateHelper.format(gc.getTime()));
					gc.add(GregorianCalendar.DAY_OF_MONTH, -1);	
					log.info("Generated date minus one day "+gc.getTime());					
					pd.put("D_DAYEND", DateHelper.format(gc.getTime()));
					
					gc.add(GregorianCalendar.MONTH, -1);
					gc.set(GregorianCalendar.DAY_OF_MONTH, gc.getActualMaximum(GregorianCalendar.DAY_OF_MONTH));					
					
					pd.put("D_MONTHEND",DateHelper.format(gc.getTime()));
					
							
					gc.add(GregorianCalendar.YEAR, -1);
					gc.set(GregorianCalendar.MONTH, 11);
					gc.set(GregorianCalendar.DAY_OF_MONTH, 31);
					
					pd.put("D_YEAREND",DateHelper.format(gc.getTime()));
					pd.put("C_BRANCHCODE", branchCode);
					pd.put("C_USERID", userID);
					
					PostDate postDate = new PostDate(pd);
										
					PostDateDAO postDateDAO = (PostDateDAO)Persistence.getDAO("PostDateDAO");
					boolean updatePDsuccess = postDateDAO.insertPostDateFromBranch(pd);
						if (updatePDsuccess){
							System.out.println("----->>>New branch created..PostDate successfully update. ");
							as.addAudit(postDate.getC_USERID(), "I", "POSTDATE",postDate.toString());
						}else{
							System.out.println("----->>>New branch created..PostDate failed to update. ");
						}
					
					
					jsondata.put("status","Add Branch Successful ...");
				}else{
					jsondata.put("status","Add Branch Failed ... ");
				}
			}
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		
		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map updateBranch(Map branchMap){		
		Map jsondata = new HashMap();
		Branch branch = BranchUtility.toObject(branchMap);
		
		String c_BranchCodeOld = (String) branchMap.get("C_BRANCHCODEOLD");
		
		try {
			ServiceUtility.viewUserParameters(branchMap);
					
			BranchDAO branchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");
						
			boolean success = branchDAO.updateBranch(branchMap);
			ServiceUtility.viewUserParameters(branchMap);
			
			if(success){				
				String userID = (String) branchMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "BRANCH", branch.toString());
				
				jsondata.put("status","Update Branch Successful ...");
			}
			else {
				jsondata.put("status","Update Branch Failed ... ");				
			}
			
		}
		catch (Throwable x) {			
			jsondata.put("status","Update Branch Failed. " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
				
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map deleteBranch(Map branchMap){
		
		Map jsondata = new HashMap();
		try {
			ServiceUtility.viewUserParameters(branchMap);
			
			Branch branch = BranchUtility.toObject(branchMap);
			
			BranchDAO BranchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");

			boolean success = BranchDAO.deleteBranch(branchMap);
						
			if(success){
				String userID = (String) branchMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "BRANCH", branch.toString());
				
				jsondata.put("status","Delete Branch Successful ...");
			}else{
				jsondata.put("status","Delete Branch Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	public boolean isDuplicate(String c_BrCode) {
		List l = this.searchBranchByBCode(c_BrCode);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchBranchAutoComplete(Map branchForm){
		
		log.info("--->> search Branch AutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(branchForm);
			
			BranchDAO branchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");				
			records = (ArrayList)branchDAO.searchBranchAutoComplete(branchForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
		
			//ServiceUtility.viewUserParameters(role);			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}
	
	public Map getListOfBranch(Map branch)
	{
		System.out.println("--->> getListOfBranch SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(branch);
			BranchDAO branchDAO = (BranchDAO)Persistence.getDAO("BranchDAO");				
			records = (ArrayList)branchDAO.getListBranch(branch);
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_BRANCHCODE", "C_BRANCHNAME");
			jsondata.put("AUTOCOMPLETE",resultString);
					
			
			log.info("records----------------->" + records);
			log.info("resultString----------------->" + resultString);
			log.info("jsondata----------------->" + jsondata);
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
	
	
}
