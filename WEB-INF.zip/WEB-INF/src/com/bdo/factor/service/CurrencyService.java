package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Currency;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.CurrencyDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.CurrencyUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class CurrencyService {
	private static Logger log = Logger.getLogger(CurrencyService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static CurrencyService thisCurrencyService = new CurrencyService();
	
	private CurrencyService() { }

	public static CurrencyService getInstance() {
		return thisCurrencyService;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map searchCurrency(Map currencyForm){
		
		log.info("--->> searchCurrency SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(currencyForm);
			
			CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");				
			totalRecords = currencyDAO.getTotalRecordsCurrency();	
			
			currencyForm = ServiceUtility.addPaging(currencyForm,totalRecords);
			
			records = currencyDAO.searchCurrency(currencyForm);	
		
			ServiceUtility.viewUserParameters(currencyForm);
						
			log.info("--->> searchcurrency RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)currencyForm.get("records")),((String)currencyForm.get("page")),((String)currencyForm.get("total")));
			}else{
				jsondata.put("status","Search Currency Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public List searchCurrencyByCode(String c_CurrencyCode, String d_RateDate){
		log.info("--->> searchCurrencyByCode SERVICE ...");		
		
		CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");
				
		return currencyDAO.searchCurrencyByCode(c_CurrencyCode, d_RateDate);		
	}	
	
	public Map searchCurrencyByCurrencyCode(Map m){
		Map jsonData = new HashMap();
		String c_CurrencyCode = m.get("C_CURRENCYCODE").toString();
		
		log.info("--->> searchCurrencyByCode SERVICE ...");		
		
		CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");
		List lResult = currencyDAO.searchCurrencyByCurrencyCode(c_CurrencyCode);
		jsonData.put("resultData", lResult);
		
		return jsonData;
	}	
	
	public Map searchCurrencyCode(Map currencyForm){
		Map resultData = new HashMap();
		
		log.info("--->> searchCurrencyByCode SERVICE ...");
		
		String c_CurrencyCode = currencyForm.get("C_CURRENCYCODE") != null ? currencyForm.get("C_CURRENCYCODE").toString().trim() : ""; 
		
		CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");
		String currencyCode = currencyDAO.searchCurrencyCode(c_CurrencyCode);
		resultData.put("resultData", currencyCode);		
		 
		return resultData;
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map addCurrency(Map currencyForm){
		
		log.info("--->> addBank SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{			
			ServiceUtility.viewUserParameters(currencyForm);
			Currency currency = CurrencyUtility.getInstance().toObject(currencyForm);
			
			String operation = (String) currencyForm.get("operation");
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {
				this.updateCurrency(currencyForm);
			}
			else {
//				boolean duplicate = this.isDuplicate(currency.getC_CurrencyCode(), currency.getD_RateDate());
				boolean duplicate = this.isDuplicate(currency.getC_CurrencyCode(), (String) currencyForm.get("D_RATEDATE"));
				if (duplicate) {
					jsondata.put("status","Failed to Add Currency. Record with same currency code already exists.");
					return jsondata;
				}	
				
				CurrencyDAO CurrencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");	
				boolean success = CurrencyDAO.addCurrency(currencyForm);
							
				if(success){
					String userID = (String) currencyForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "CURRENCY", currency.toString());
					
					jsondata.put("status","Add Currency Successful ...");
				}else{
					jsondata.put("status","Add Currency Failed ... ");
				}
			} 
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map updateCurrency(Map currencyForm){		
		Map jsondata = new HashMap();		
		currencyForm.put("C_CURRENCYCODE", currencyForm.get("C_CURRENCYCODE_ORIG"));
		Currency currency = CurrencyUtility.getInstance().toObject(currencyForm);		
		
		try {
			//Currency cu = CurrencyUtility.getInstance().toObject(CurrencyForm);
			CurrencyDAO CurrencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");

			log.info("--->> updateCurrency SERVICE ...");
			
			boolean success = CurrencyDAO.updateCurrency(currencyForm);
			
			if(success){
				String userID = (String) currencyForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "CURRENCY", currency.toString());
				
				jsondata.put("status","Update Currency Successful ...");
			}else{
				jsondata.put("status","Update Currency Failed ... ");
			}			
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}		
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map deleteCurrency(Map currencyForm){
		
		Map jsondata = new HashMap();
		try {
			Currency currency = CurrencyUtility.getInstance().toObject(currencyForm);
			CurrencyDAO CurrencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");

			boolean success = CurrencyDAO.deleteCurrency(currencyForm);
			
			if(success){
				String userID = (String) currencyForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "CURRENCY", currency.toString());
				
				jsondata.put("status","Delete Currency Successful ...");
			}else{
				jsondata.put("status","Delete Currency Failed ... ");
			}
	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
				
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchCurrencyAutoComplete(Map currencyForm){
		
		log.info("--->> searchCurrencyAutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(currencyForm);
			
			CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");				
			records = (ArrayList)currencyDAO.searchCurrencyAutoComplete(currencyForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public boolean isDuplicate(String c_CurrencyCode, String d_RateDate) {
		List l = this.searchCurrencyByCode(c_CurrencyCode, d_RateDate);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map searchCurrencyList(Map CurrencyForm){
		
		System.out.println("--->> searchCurrencyList SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(CurrencyForm);
			CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");				
			records = (ArrayList)currencyDAO.searchCurrencyList(CurrencyForm);
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_CURRENCYCODE","C_DESCRIPTION");
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchData(Map Form){
		System.out.println("--->> searchData SERVICE ...");		

		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(Form);
			
			CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");				
			resultString = currencyDAO.searchData(Form);	
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
	
	public Map getSystemCurrency(Map data){
		Map returnMap = new HashMap();
		CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");
		returnMap = currencyDAO.getSystemCurrency();
		returnMap.put("success", true);
		return returnMap;
		
		
	}
}
