package com.bdo.factor.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.dao.BLRFileDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class BLRFileService {
	private static Logger log = Logger.getLogger(BLRFileService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static BLRFileService thisBLRFileService = new BLRFileService();
	
	private BLRFileService() { }

	public static BLRFileService getInstance() {
		return thisBLRFileService;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	

	public Map searchBLRFile(Map blrFileForm){
		
		log.info("--->> searchBLRFile SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		
		try{
			
			BLRFileDAO blrFileDAO = (BLRFileDAO)Persistence.getDAO("BLRFileDAO");				
				
			ServiceUtility.viewUserParameters(blrFileForm);
			
			totalRecords = blrFileDAO.getTotalRecordsBLRFile();	
			
			blrFileForm = ServiceUtility.addPaging(blrFileForm,totalRecords);
			
			records = blrFileDAO.searchBLRFile(blrFileForm);	
		
			ServiceUtility.viewUserParameters(blrFileForm);
						
			log.info("--->> searchBLRFile RECORD-SIZE: "+records.size());
		
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)blrFileForm.get("records")),((String)blrFileForm.get("page")),((String)blrFileForm.get("total")));
			}else{
				jsondata.put("status","searchBank Failed ... ");
			}
			
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchBLRFileByTypeCode(Map blrFileForm){
		
		log.info("--->> searchBLRFileByTypeCode SERVICE ...");
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		List records = new ArrayList();
		
		try{
			
			BLRFileDAO blrFileDAO = (BLRFileDAO)Persistence.getDAO("BLRFileDAO");				
			records = blrFileDAO.searchBLRFileByTypeCode(blrFileForm);

			try{
				newData = (HashMap) records.get(0);
			} catch (Throwable x) {
				
				blrFileForm.put("oper","add");

				boolean success = blrFileDAO.addBLRFile(blrFileForm);
				
				
				if(success){
					records = blrFileDAO.searchBLRFileByTypeCode(blrFileForm);
					newData = (HashMap) records.get(0);
				}else{
					jsondata.put("status","updateBLRFile Failed ... ");
				}
				
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			newData = ServiceUtility.removeNulls(newData);
			
			records = new ArrayList();
			records.add(newData);
			
			jsondata.put("returnDataSize",""+records.size());
			jsondata.put("returnData",records);
				
			System.out.println("--->> searchBLRFileByTypeCode RECORD-SIZE: "+records.size());
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
	
//////////////////////////////////////////////////////////////////////////////////////////////	
		
	public Map addBLRFile(Map blrFileForm){
		
		log.info("--->> addBLRFile SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			
			ServiceUtility.viewUserParameters(blrFileForm);
			
			if(blrFileForm.get("oper")!=null && blrFileForm.get("oper").toString().trim().equalsIgnoreCase("add")){
			
				BLRFileDAO addBLRFileDAO = (BLRFileDAO)Persistence.getDAO("BLRFileDAO");	
				boolean success = addBLRFileDAO.addBLRFile(blrFileForm);
				
				
				if(success){
					jsondata.put("status","addBLRFile Successful ...");
				}else{
					jsondata.put("status","addBLRFile Failed ... ");
				}
			}else{
				this.updateBLRFile(blrFileForm);
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map updateBLRFile(Map blrFileForm){
		
		System.out.println("--->> updateBLRFile SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			
			BLRFileDAO blrFileDAO = (BLRFileDAO)Persistence.getDAO("BLRFileDAO");		
			boolean success = blrFileDAO.updateBLRFile(blrFileForm);
			
			ServiceUtility.viewUserParameters(blrFileForm);
		
			if(success){
				jsondata.put("status","updateBLRFile Successful ...");
			}else{
				jsondata.put("status","updateBLRFile Failed ... ");
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map deleteBLRFile(Map blrFileForm){
		
		log.info("--->> deleteBLRFile SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			
			BLRFileDAO blrFileDAO = (BLRFileDAO)Persistence.getDAO("BLRFileDAO");
			boolean success = blrFileDAO.deleteBLRFile(blrFileForm);
			
			ServiceUtility.viewUserParameters(blrFileForm);
		
			if(success){
				jsondata.put("status","deleteBLRFile Successful ...");
			}else{
				jsondata.put("status","deleteBLRFile Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}		

		return jsondata;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////


	
	
	public Map searchBLRInquiry(Map blrFileForm){
		
		log.info("--->> searchBLRInquiry SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		Map newRecordsMap = new HashMap();
		List newRecordsList = new ArrayList();
		List blr = new ArrayList();
		String totalRecords = "";
		String strBLR = "";
		String nBLR = "";
		String effectiveDate = "";
		String expiryDate = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(blrFileForm);

			BLRFileDAO blrFileDAO = (BLRFileDAO)Persistence.getDAO("BLRFileDAO");
			
			newRecordsMap.put("C_BLRTYPECODE", blrFileForm.get("C_CLNTCODE").toString());
			
			for(int cntInner=1;cntInner<=5;cntInner++)
			{
				strBLR = "D_TRANSACTIONDATE"+cntInner;
				newRecordsMap.put(strBLR,blrFileForm.get("D_BLRINQUIRYDATE_START").toString());
				
				blr = blrFileDAO.searchDiscountChargeBLRFile(newRecordsMap);
				System.out.println("--->>> BLR SIZE: "+blr.size());
				
				newRecordsMap.remove(strBLR);
				
				if(blr.size()>0){
					System.out.println("-->>> BLR: "+cntInner);
					if(cntInner == 1){
						nBLR = ((HashMap)blr.get(0)).get("N_BLR1").toString();
						effectiveDate = ((HashMap)blr.get(0)).get("D_EFFDT1").toString();
						expiryDate = ((HashMap)blr.get(0)).get("D_EXPDT1").toString();
					}
					if(cntInner == 2){
						nBLR = ((HashMap)blr.get(0)).get("N_BLR2").toString();
						effectiveDate = ((HashMap)blr.get(0)).get("D_EFFDT2").toString();
						expiryDate = ((HashMap)blr.get(0)).get("D_EXPDT2").toString();
					}
					if(cntInner == 3){
						nBLR = ((HashMap)blr.get(0)).get("N_BLR3").toString();
						effectiveDate = ((HashMap)blr.get(0)).get("D_EFFDT3").toString();
						expiryDate = ((HashMap)blr.get(0)).get("D_EXPDT3").toString();	
					}
					if(cntInner == 4){
						nBLR = ((HashMap)blr.get(0)).get("N_BLR4").toString();
						effectiveDate = ((HashMap)blr.get(0)).get("D_EFFDT4").toString();
						expiryDate = ((HashMap)blr.get(0)).get("D_EXPDT4").toString();
					}
					if(cntInner == 5){
						nBLR = ((HashMap)blr.get(0)).get("N_BLR5").toString();
						effectiveDate = ((HashMap)blr.get(0)).get("D_EFFDT5").toString();
						expiryDate = ((HashMap)blr.get(0)).get("D_EXPDT5").toString();
					}
					break;
				}
				
			}
			
			newRecordsMap.put("N_BLR", nBLR);
			newRecordsMap.put("D_EFFDT", effectiveDate);
			newRecordsMap.put("D_EXPDT", expiryDate);
			
			if((nBLR!=null && nBLR.trim().length()>0) || (effectiveDate!=null && effectiveDate.trim().length()>0) || (expiryDate!=null && expiryDate.trim().length()>0)){
				newRecordsList.add(newRecordsMap);
			}
			

			ServiceUtility.viewUserParameters(newRecordsMap);
			log.info("--->> searchBLRInquiry RECORD-SIZE: "+records.size());
		
			if((newRecordsList!=null) && (newRecordsList.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(newRecordsList, "","","");
			}else{
				newRecordsMap.put("N_BLR", "No Records Found ...");
				newRecordsList.add(newRecordsMap);
				jsondata = JQGridJSONFormatter.formatDataToJSON(newRecordsList, "","","");
				jsondata.put("status","searchBLRInquiry Failed ... ");
			}
			
			ServiceUtility.viewUserParameters(newRecordsMap);
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////	
}
