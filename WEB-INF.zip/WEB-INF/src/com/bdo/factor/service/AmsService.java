package com.bdo.factor.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.dao.AmsDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.Persistence;

public class AmsService {
	private static Logger log = Logger.getLogger(BankService.class);

	private static AmsService thisAmsService = new AmsService();

	private AmsService() { }

	public static AmsService getInstance() {
		return thisAmsService;
	}
	
	public boolean addAMS(Map AMSForm) {
		boolean result = false;
		Map jsonData = new HashMap();
		int refNo = 0;
		try {
			AmsDAO amsDAO = (AmsDAO)Persistence.getDAO("AmsDAO");
			result = amsDAO.addAMS(AMSForm);		
			
		}
		catch (Exception e) {
			e.printStackTrace();			
		}
		return result;
	}
}
