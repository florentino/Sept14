package com.bdo.factor.service;

public class ChargeType {

}
