package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.bdo.factor.dao.AccountingMaintenanceDAO;
import com.bdo.factor.dao.PenChgDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.ServiceUtility;
import com.bdo.factor.util.XMLParser;

public class AccountingMaintenanceService implements AccountingMaintenanceServiceInterface{
	
	private static AccountingMaintenanceDAO AMD;
	
	private static Logger log = Logger.getLogger(AccountingMaintenanceService.class);

	private static AccountingMaintenanceService AccountingMaintenanceServiceInstance = new AccountingMaintenanceService();
	
		private AccountingMaintenanceService() { }

		public static AccountingMaintenanceService getInstance() {
			return AccountingMaintenanceServiceInstance;
		}

//CHART		OF		ACCOUNT		METHODS
	@Override
	public Map getChartOfAccount(Map m) {
		return ServiceUtility.toJQGrid(getPersistence(), "countChartOfAccount", "getChartOfAccount", m);
	}

	@Override
	public Map addChartOfAccount(Map m) {
		Map json = new HashMap();
		
		ServiceUtility.viewUserParameters(m);
		if(m.get("GLCode")!=null&&!m.get("GLCode").toString().trim().contentEquals("")){
			if(getPersistence().checkGLDuplicate(m.get("GLCode").toString())){
				json.put("success", getPersistence().addChartOfAccount(m));
				try {
					XMLParser.getInstance().startUpdate(m.get("C_ICBSGLCodeOld").toString(), m);
				} catch (TransformerException e) {
					e.printStackTrace();
				}
			}
			else
				json.put("failed", "Duplicate GLCode");
		}else
			json.put("failed", "Invalid GLCode");
		return json;
	}
	
	@Override
	public Map editChartOfAccount(Map m) {
		Map json = new HashMap();
		json.put("success", getPersistence().editChartOfAccount(m)?true:false);
		try {
			XMLParser.getInstance().startUpdate(m.get("C_ICBSGLCodeOld").toString(), m);
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public Map deleteChartOfAccount(Map m) {
		Map json = new HashMap();
		json.put("success", getPersistence().deleteChartOfAccount(m)?true:false);
		try {
			XMLParser.getInstance().startUpdate(m.get("C_ICBSGLCodeOld").toString(), m);
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public Map getChartList(Map m){
		Map map = new HashMap();
		List<Map> json = new ArrayList<Map>();
		json = getPersistence().getChartList();
		
		map = toJSON(json);
		
		map.put("","");
		log.info("json get chart List --------------->"+json);
		log.info("map get chart List--------------->"+map);
		return map;
	}

	@Override
	public List getGLList(){
		return getPersistence().getGLList();
	}
	
	@Override
	public Double getAmount(String GLCode){
		return getPersistence().getAmount(GLCode);
	}

	public Map searchJournalChartEntry(Map m){
		m.put("operation", "EXIST");
		try {
			XMLParser.getInstance().searchJournalChartEntry(m.get("c_icbsglcode").toString());
			m.put("success", XMLParser.getInstance().getExString());
		} catch (TransformerException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return m;
	}
	
//COST		CENTER		METHODS
	@Override
	public Map getCostCenter(Map m) {
		return ServiceUtility.toJQGrid(getPersistence(), "countCostCenter", "getCostCenter", m);
	}

	@Override
	public Map addCostCenter(Map m) {
		Map json = new HashMap(); 
		
		ServiceUtility.viewUserParameters(m);
		if(m.get("N_CODE")!=null&&!m.get("N_CODE").toString().trim().contentEquals("")){
			if(getPersistence().checkCostCenterDuplicate(m.get("N_CODE").toString())){
				json.put("success", getPersistence().addCostCenter(m));
			}
			else
				json.put("failed", "Duplicate Cost Center Code");
		}
		else
			json.put("failed", "Invalid Cost Center Code");
		
		return json;	
	}
	
	@Override
	public Map editCostCenter(Map m) {
		Map json = new HashMap();
		json.put("success", getPersistence().editCostCenter(m)?true:false);
		return json;	
	}

	@Override
	public Map deleteCostCenter(Map m) {
		Map json = new HashMap();
		json.put("success", getPersistence().deleteCostCenter(m)?true:false);
		return json;	

	}

	public Map getCostCenterList(Map m){
		Map map = new HashMap();
		List<Map> json = new ArrayList<Map>();
		json = getPersistence().getCostCenterList();
		map = toJSONCostCenter(json);
		log.info("json getCostCenterList--------------->"+json);
		log.info("map getCostCenterList--------------->"+map);
		return map;
		 
	}
	
	//public List getCostCenterList(){
		//Map map = new HashMap();
		//List<Map> json = new ArrayList<Map>();
		//json = getPersistence().getCostCenterList();
		//map = toJSONCostCenter(json);
		///log.info("json getCostCenterList--------------->"+json);
		//log.info("map getCostCenterList--------------->"+map);
		//return getPersistence().getGLList();
		 
	//}
	
	
//PENALTY	CHARGES		METHODS
	@Override
	public Map getPenaltyCharge(Map m) {
		Map jsondata = new HashMap();
		
		//AccountingMaintenanceDAO AMD = (AccountingMaintenanceDAO)Persistence.getDAO("AccountingMaintenanceDAO");
		jsondata = ServiceUtility.toJQGrid(getPersistence(), "countPenaltyCharge", "getPenaltyCharge", m);
		
		return jsondata;
	}

	@Override
	public Map addPenChg(Map penaltyMap) {
		Map jsondata = new HashMap();
		
		ServiceUtility.viewUserParameters(penaltyMap);
		
		AccountingMaintenanceDAO AMD = (AccountingMaintenanceDAO)Persistence.getDAO("AccountingMaintenanceDAO");
		boolean success = AMD.addPenalty(penaltyMap);
		
		if(success){
			String userID = (String) penaltyMap.get("C_USERID");
			AuditService as = AuditService.getInstance();
			as.addAudit(userID, "I", "Penalty", "");
			
			jsondata.put("status","Add Penalty Successful ...");
		}else{
			jsondata.put("status","Add Penalty Failed ... ");
		}
		
		return jsondata;
	}
	
	public AccountingMaintenanceDAO getPersistence(){
		if (AMD ==null)
			 return AMD = (AccountingMaintenanceDAO)Persistence.getDAO("AccountingMaintenanceDAO");
		return AMD;
	}

	
	 
//OTHER METHODS
	@Override
	public Map getClientCode(Map m){
		Map map = new HashMap();
		map.put("client", getPersistence().getClientCode(m));
		
		return map;
	}
	
	@Override
	public Boolean saveTransactionRate(Map m){
		return getPersistence().saveTransactionRate(m);
	}

	public void xml(Map m){
ServiceUtility.viewUserParameters(m); }

	public Object queryForObject(String sql) {
		AccountingMaintenanceDAO AMD = (AccountingMaintenanceDAO)Persistence.getDAO("AccountingMaintenanceDAO");
		
		return AMD.queryForObject(sql);
	}
	//changed the value of array index. Changed the key to 0, by Cherrie Garcia 10/19/15
	public Map toJSON(List<Map> m){
		Map JSON = new HashMap();
		if(!m.isEmpty()){
			for(int x =0 ; x<m.size();x++){
				Map map = (Map)m.get(x);
				
				Object[] s =  (Object[]) map.keySet().toArray();
				
				String key = s.length==2&&!s[0].toString().contentEquals("")?map.get(s[0].toString()).toString():String.valueOf(x);
				String value = s[1].toString();
				JSON.put(key, map.get(value));
				
			}
			
		}
		
		return JSON;
	}
	
	//for GetCostCenterList, original value of array index,  by Cherrie Garcia 10/19/15
		public Map toJSONCostCenter(List<Map> m){
			Map JSON = new HashMap();
			if(!m.isEmpty()){
				for(int x =0 ; x<m.size();x++){
					Map map = (Map)m.get(x);
					
					Object[] s =  (Object[]) map.keySet().toArray();
					
					String key = s.length==2&&!s[1].toString().contentEquals("")?map.get(s[1].toString()).toString():String.valueOf(x);
					String value = s[0].toString();
					JSON.put(key, map.get(value));
					
				}
				
			}
			
			return JSON;
		}
	
	
}
