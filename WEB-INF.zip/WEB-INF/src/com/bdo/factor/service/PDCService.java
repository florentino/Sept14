package com.bdo.factor.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CreditNote;
import com.bdo.factor.beans.Group;
import com.bdo.factor.beans.PDC;
import com.bdo.factor.dao.CreditNoteDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.PdcDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.CreditNoteUtility;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.GroupUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.PdcUtility;
import com.bdo.factor.util.ServiceUtility;

public class PDCService {
	private static Logger log = Logger.getLogger(PDCService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static PDCService pdcService = new PDCService();
	
	private PDCService() { }

	public static PDCService getInstance() {
		return pdcService;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map processPDC(Map pdcForm) {		
		Map jsonData = new HashMap();
		
		String mode = pdcForm.get("mode") != null ? pdcForm.get("mode").toString() : "0";		
		if (mode.trim().equalsIgnoreCase("add")) {
			return this.addPDC(pdcForm);
		}
		else if(mode.trim().equalsIgnoreCase("update")) {
			return this.updatePDC(pdcForm);
		}
		return jsonData;
	}
	
	public Map addPDC(Map pdcForm) {
		Map jsonData = new HashMap();		
		
		ServiceUtility.viewUserParameters(pdcForm);		
		PDC pdc = PdcUtility.getInstance().toObject(pdcForm);
				
		try {
			
			PdcDAO pdcDAO = (PdcDAO)Persistence.getDAO("PdcDAO");
			pdcForm.put("N_CHECKAMT", pdcForm.get("N_CHECKAMT") != null ? pdcForm.get("N_CHECKAMT").toString().replaceAll(",", "") : null);
			
			int success = pdcDAO.addPDC(pdcForm);
			
			if (success > 0) {
				pdc.setN_RefNo(success);
				String userID = pdcForm.get("C_USERID").toString();
															
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "I", "PDC", pdc.toString());
												
				jsonData.put("status", "PDC Added");				
			}
		}
		catch (Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		return jsonData;	
	}
	
	public Map updatePDC(Map pdcForm) {
		Map jsonData = new HashMap();	
		
		ServiceUtility.viewUserParameters(pdcForm);		
		PDC pdc = PdcUtility.getInstance().toObject(pdcForm);
		
		try {
			
			PdcDAO pdcDAO = (PdcDAO)Persistence.getDAO("PdcDAO");
			String nCheckAmount = pdcForm.get("N_CHECKAMT") != null ? pdcForm.get("N_CHECKAMT").toString().replaceAll(",", "") : "0";
			pdcForm.put("N_CHECKAMT", Double.parseDouble(nCheckAmount));
			boolean success = pdcDAO.updatePDC(pdcForm);
			if (success) {
				String userID = pdcForm.get("C_USERID").toString();
				
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "PDC", pdc.toString());
												
				jsonData.put("status", "PDC Updated");	
			}
		}
		catch(Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		
		return jsonData;
	}
	
	public Map updatePDCStatus(Map pdcForm) {
		Map jsonData = new HashMap();	
		
		ServiceUtility.viewUserParameters(pdcForm);	
		
		try {
			
			PdcDAO pdcDAO = (PdcDAO)Persistence.getDAO("PdcDAO");
			boolean success = pdcDAO.updatePDCStatus(pdcForm);
			if (success) {
				String userID = pdcForm.get("C_USERID").toString();
				
				StringBuilder pdc = new StringBuilder("Update PDC B_PROCESSED:");
				pdc.append("C_CLNTCODE=").append(pdcForm.get("C_CLNTCODE"));
				pdc.append(";C_CUSTCODE=").append(pdcForm.get("C_CUSTCODE"));
				pdc.append(";C_BANKCODE=").append(pdcForm.get("C_BANKCODE"));
				pdc.append(";D_CHECKDATE=").append(pdcForm.get("D_CHECKDATE"));
				pdc.append(";B_PROCESSED=").append(pdcForm.get("B_PROCESSED"));
				
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "PDC", pdc.toString());
												
				jsonData.put("status", "PDC Updated");	
			}
		}
		catch(Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		
		return jsonData;
	}
	
	public Map deletePDC(Map pdcForm){
		Map jsondata = new HashMap();
		
		ServiceUtility.viewUserParameters(pdcForm);		
		PDC pdc = PdcUtility.getInstance().toObject(pdcForm);
		
		try {		
			PdcDAO pdcDAO = (PdcDAO)Persistence.getDAO("PdcDAO");

			boolean success = pdcDAO.deletePDC(pdcForm);
			
			if(success){				
				String userID = (String) pdcForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "PDC", pdc.toString());
				
				jsondata.put("status","PDC Deleted");
			}else{
				jsondata.put("status","PDC Delete Failed");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status","exception: " + x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	public Map searchPDC(Map pdcMap){
		
		Map jsondata = new HashMap();
		String totalRecords = "";		
		
		try {
			log.info("--->> searchPDC SERVICE ...");		
			String c_BranchCode = pdcMap.get("C_BRANCHCODE") != null ? pdcMap.get("C_BRANCHCODE").toString().trim() : "";
			PdcDAO pdcDAO = (PdcDAO)Persistence.getDAO("PdcDAO");			
 			totalRecords = pdcDAO.getTotalPDCRecords(c_BranchCode);			
			pdcMap = ServiceUtility.addPaging(pdcMap,totalRecords);			
			List lPDC = pdcDAO.searchPDC(pdcMap);
			ServiceUtility.viewUserParameters(pdcMap);
			
			log.info("--->> searchGroup RECORDS: "+lPDC.size());
			if((lPDC!=null) && (lPDC.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lPDC, ((String)pdcMap.get("records")),((String)pdcMap.get("page")),((String)pdcMap.get("total")));
			}else{				
				jsondata.put("status","searchPDC Failed ... ");				
			}
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;			
	}	
	
public Map searchPDCByCustomer(Map pdcMap){
		
	Map jsondata = new HashMap();
	String totalRecords = "";		
	
	try {
		log.info("--->> searchPDC SERVICE ...");		
		
		PdcDAO pdcDAO = (PdcDAO)Persistence.getDAO("PdcDAO");			
		totalRecords = pdcDAO.getTotalPDCRecordsByCustomer(pdcMap);			
		pdcMap = ServiceUtility.addPaging(pdcMap,totalRecords);			
		List lPDC = pdcDAO.searchPDCByCustomer(pdcMap);
		ServiceUtility.viewUserParameters(pdcMap);
		
		log.info("--->> searchPDCByCustomer RECORDS: "+lPDC.size());
		if((lPDC!=null) && (lPDC.size()>0)){
			jsondata = JQGridJSONFormatter.formatDataToJSON(lPDC, ((String)pdcMap.get("records")),((String)pdcMap.get("page")),((String)pdcMap.get("total")));
		}else{				
			jsondata.put("status","searchPDC Failed ... ");				
		}
	}
	catch(Throwable x) {
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}
	
	return jsondata;			
	}	
}
