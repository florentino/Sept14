package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.DocStamp;
import com.bdo.factor.dao.DocStampDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.DocStampUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class DocStampService {
	private static Logger log = Logger.getLogger(DocStampService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////

private static DocStampService thisDocStampService = new DocStampService();

private DocStampService() { }

public static DocStampService getInstance() {
return thisDocStampService;
}

//////////////////////////////////////////////////////////////////////////////////////////////

public Map searchDocStamp(Map DocStampForm){

log.info("--->> searchDocStamp SERVICE ...");

Map jsondata = new HashMap();
List records = new ArrayList();
String totalRecords = "";


try{

ServiceUtility.viewUserParameters(DocStampForm);

DocStampDAO DOCSTAMPDAO = (DocStampDAO)Persistence.getDAO("docStampDAO");				
totalRecords = DOCSTAMPDAO.getTotalRecordsDocStamp();	

DocStampForm = ServiceUtility.addPaging(DocStampForm,totalRecords);

records = DOCSTAMPDAO.searchDocStamp(DocStampForm);	

ServiceUtility.viewUserParameters(DocStampForm);

System.out.println("--->> searchDocStamp RECORD-SIZE: "+records.size());

if((records!=null) && (records.size()>0)){						
jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)DocStampForm.get("records")),((String)DocStampForm.get("page")),((String)DocStampForm.get("total")));
}else{
jsondata.put("status","searchDocStamp Failed ... ");
}

}catch(Throwable x){
jsondata.put("status",x.getMessage());
x.printStackTrace();
}	

return jsondata;

}	

//////////////////////////////////////////////////////////////////////////////////////////////

public Map addDocStamp(Map docstampForm){

log.info("--->> addDocStamp SERVICE ...");

Map jsondata = new HashMap();

try{
DocStamp docstamp = DocStampUtility.toObject(docstampForm);			
ServiceUtility.viewUserParameters(docstampForm);

DocStampDAO docstampDAO = (DocStampDAO)Persistence.getDAO("docStampDAO");


boolean success = docstampDAO.addDocStamp(docstampForm);


if(success){
jsondata.put("status","Add DocStamp Successful ...");
}else{
jsondata.put("status","Add DocStamp Failed ... ");
}

}catch(Throwable x){
jsondata.put("status",x.getMessage());
x.printStackTrace();
}

return jsondata;
}

//////////////////////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////////////////////////////////////////////////////////////



}
