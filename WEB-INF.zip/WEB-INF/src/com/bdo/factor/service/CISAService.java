package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.dao.CISADAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.beans.*;

public class CISAService {
	private static CISADAO _CISADAO = (CISADAO)Persistence.getDAO("CISADAO");
	
	private static Logger log = Logger.getLogger(CISAService.class);
	private static CISAService CISAServiceInstance = new CISAService();
	private CISAService() { }

	public static CISAService getInstance() {
		return CISAServiceInstance;
	}
	
	
	public CISAIndividualBean getCISAIndividualBeanByPartyId(){
		return null;
	}
	public List<CISAIndividualBean> getCISAIndividualBean(){
		return null;
	}
	
	public CISABusinessBean getCISABusinessBeanByPartyId(){
		return null;
	}
	
	public List<CISABusinessBean> getCISABusinessBean(){
		return null;
	}
	
	public void AddCISAIndividualBean(CISAIndividualBean _CISAIndividualBean){
		_CISADAO.AddCISAIndividualBean(_CISAIndividualBean);
	}
	
	public void AddCISABusinessBean(CISABusinessBean _CISABusinessBean){
		_CISADAO.AddCISABusinessBean(_CISABusinessBean);
	}
	
	public void AddCISALink (CISALink _CISALink){
		_CISADAO.AddCISALink(_CISALink);
	}
	
	public void AddCISALinkList (Map<String,List<CISALink>> _CISALink){
		_CISADAO.AddCISALinkList(_CISALink);
	}
	
	public void ADDCISAContract(CISAContract _CISAContract){
		_CISADAO.AddContract(_CISAContract);
	}
	
	public void AddCISALinkListReferenceClient (Map<String,List<CISAContractReference>> _CISAContractReferenceList){
		_CISADAO.AddLinkListReferenceClient(_CISAContractReferenceList);
	}
	
	public void AddCISALinkListReferenceCustomer (Map<String,List<CisaCustomerReference>> _CisaCustomerReference){
		_CISADAO.AddLinkListReferenceCustomer(_CisaCustomerReference);
	}
}
