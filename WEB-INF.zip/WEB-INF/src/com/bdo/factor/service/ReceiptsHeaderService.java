package com.bdo.factor.service;

import java.math.BigDecimal;


import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.bdo.factor.beans.Invoice;
import com.bdo.factor.beans.ReceiptsDtlOther;
import com.bdo.factor.beans.ReceiptsHeader;
import com.bdo.factor.beans.User;
import com.bdo.factor.dao.AdvancesDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.BLRFileDAO;
import com.bdo.factor.dao.CreditNoteDAO;
import com.bdo.factor.dao.CustomerDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.SubHeaderDAO;
import com.bdo.factor.dao.PdcDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.ReceiptsDtlDAO;
import com.bdo.factor.dao.ReceiptsHeaderDAO;
import com.bdo.factor.dao.RefundDAO;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ReceiptsHeaderUtility;
import com.bdo.factor.util.ServiceUtility;
import com.bdo.factor.dao.CCLinkDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.util.Money;

public class ReceiptsHeaderService {
	private static Logger log = Logger.getLogger(ReceiptsHeaderService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static ReceiptsHeaderService rHeaderInstance = new ReceiptsHeaderService();
	
	private ReceiptsHeaderService() { }

	public static ReceiptsHeaderService getInstance() {
		return rHeaderInstance;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map addReceiptsHeaderPDC(Map receiptsHeaderForm) {
		receiptsHeaderForm.put("C_CHECKNO", receiptsHeaderForm.get("C_CHECKNOPDC"));
		receiptsHeaderForm.put("D_CHECKDATE", receiptsHeaderForm.get("D_CHECKDATEPDC"));
		receiptsHeaderForm.put("C_BANKNAME", receiptsHeaderForm.get("C_BANKNAMEPDC"));
		String nAmountPDC = receiptsHeaderForm.get("N_AMOUNTPDC") != null ? receiptsHeaderForm.get("N_AMOUNTPDC").toString().replaceAll(",", "") : "0";
		receiptsHeaderForm.put("N_AMOUNT", Double.parseDouble(nAmountPDC));				
		receiptsHeaderForm.put("C_DESCRIPTION", receiptsHeaderForm.get("C_DESCRIPTIONPDC"));
		receiptsHeaderForm.put("C_NOOFDAYSPDC", receiptsHeaderForm.get("C_NOOFDAYSPDC"));
		receiptsHeaderForm.put("D_CLEARINGDATEPDC", receiptsHeaderForm.get("D_CLEARINGDATEPDC"));
		receiptsHeaderForm.put("C_CHECKTYPE", receiptsHeaderForm.get("C_CHECKTYPECODE"));
		receiptsHeaderForm.put("B_FROMPDC", "1");
				
		receiptsHeaderForm.remove("C_CHECKNOPDC");
		receiptsHeaderForm.remove("D_CHECKDATEPDC");
		receiptsHeaderForm.remove("C_BANKNAMEPDC");
		receiptsHeaderForm.remove("N_AMOUNTPDC");
		receiptsHeaderForm.remove("C_DESCRIPTIONPDC");
		receiptsHeaderForm.remove("C_NOOFDAYSPDC");
		receiptsHeaderForm.remove("D_CLEARINGDATEPDC");
				
		return receiptsHeaderForm;
	}
	
	@SuppressWarnings(value = { "unchecked" }) 
	public Map addReceiptsHeader(Map receiptsHeaderForm) {
		 FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map jsonData = new HashMap();
		
		ServiceUtility.viewUserParameters(receiptsHeaderForm);
		String mode = receiptsHeaderForm.get("mode") != null ? receiptsHeaderForm.get("mode").toString() : "";
		 
		if (mode.equalsIgnoreCase("PDC")) {
			this.addReceiptsHeaderPDC(receiptsHeaderForm);			
		}
		else {
			CheckTypeDAO checkTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
			//String checkType = checkTypeDAO.searchCtypeCodeByName(receiptsHeaderForm);
			String checkType = receiptsHeaderForm.get("C_CHECKTYPECODE") != null ? receiptsHeaderForm.get("C_CHECKTYPECODE").toString() : null;
			receiptsHeaderForm.put("C_CHECKTYPE", checkType);
			receiptsHeaderForm.put("B_FROMPDC", "0");
		}
		ServiceUtility.viewUserParameters(receiptsHeaderForm);
		ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		
		String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPEVAL").toString();
		if (receiptType.equals("1")) {
			int checkCount = rHeaderDAO.searchCheckNo(receiptsHeaderForm);
			if (checkCount > 0) {
				jsonData.put("status", "Check Number already exists.");
				return jsonData;
			}			
		}
		
		CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
		
		//String currDate = DateHelper.format(new java.util.Date());
		String currDate = receiptsHeaderForm.get("D_TRANSDATE").toString();
		receiptsHeaderForm.put("D_TRANSACTIONDATE", currDate);
		
		receiptsHeaderForm.put("C_DESCRIPTION", (String) receiptsHeaderForm.get("C_DESCRIPTION2"));
		log.info("C_DESCRIPTION: " + receiptsHeaderForm.get("C_DESCRIPTION"));
		
		
		if (receiptType.trim().equalsIgnoreCase("2") || receiptType.trim().equalsIgnoreCase("3") || receiptType.trim().equalsIgnoreCase("4")) {			
			receiptsHeaderForm.put("N_AMOUNT", receiptsHeaderForm.get("N_AMOUNT2").toString().replaceAll(",", ""));
			receiptsHeaderForm.put("C_NOOFDAYS", "0");
			receiptsHeaderForm.put("D_CLEARINGDATE", currDate);
			receiptsHeaderForm.put("C_STATUS", "2");	
			receiptsHeaderForm.put("D_CHECKDATE", receiptsHeaderForm.get("D_CREDITDATE"));
			receiptsHeaderForm.put("N_ORIGAMOUNT",  receiptsHeaderForm.get("N_ORIGAMOUNT2").toString().replaceAll(",", ""));
			receiptsHeaderForm.put("B_CLEARED", "1");
		}
		
		//insert n_refundDays for receipt type 1 and 2
		if (receiptType.trim().equalsIgnoreCase("1")) {
			receiptsHeaderForm.put("N_REFUNDDAYS", receiptsHeaderForm.get("N_REFUNDDAYS"));
			receiptsHeaderForm.put("B_CLEARED", "0");
		}
		else if (receiptType.trim().equalsIgnoreCase("2")) {
			receiptsHeaderForm.put("N_REFUNDDAYS", receiptsHeaderForm.get("N_REFUNDDAYS2"));
		}
		else if (receiptType.trim().equalsIgnoreCase("3") || receiptType.trim().equalsIgnoreCase("4")) {			
			receiptsHeaderForm.put("N_REFUNDDAYS", null);
		}
		double origAmt1 =  receiptsHeaderForm.get("N_ORIGAMOUNT") != null ?Double.parseDouble(receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", "")):0;
		double discChg1 =  receiptsHeaderForm.get("N_DISCCHG") != null ? Double.parseDouble(receiptsHeaderForm.get("N_DISCCHG").toString().replaceAll(",", "")):0;
		double penalty1 =  receiptsHeaderForm.get("N_PENALTYCHG") != null ?Double.parseDouble (receiptsHeaderForm.get("N_PENALTYCHG").toString().replaceAll(",", "")):0;
		
		
		double n_orig = origAmt1+discChg1+penalty1;
		receiptsHeaderForm.put("N_ORIGAMOUNT", n_orig);
		receiptsHeaderForm.put("N_AMOUNT", receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", ""));
		receiptsHeaderForm.put("N_Amount", receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", ""));
		receiptsHeaderForm.put("opmt", receiptsHeaderForm.get("opmt").toString().replaceAll(",", ""));
		ServiceUtility.viewUserParameters(receiptsHeaderForm);
		log.info(">>>>>>N_Amount:"+ receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", "")+", N_Origamount"+ receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", ""));
		ReceiptsHeader receiptsHeader = ReceiptsHeaderUtility.toObject(receiptsHeaderForm);
		
		
		String dateBouncedStr = receiptsHeaderForm.get("D_CHECKDATE").toString();
		if (dateBouncedStr.length() == 8) {
			String dateBouncedYear = dateBouncedStr.substring(6,8);
			dateBouncedYear = "20" + dateBouncedYear;
			dateBouncedStr = dateBouncedStr.substring(0,6) + dateBouncedYear;			
		}
		receiptsHeaderForm.put("D_CHECKDATE", dateBouncedStr);
		
		log.info("REceiptType: " + receiptsHeader.getC_ReceiptType());
		log.info("CashDelay: " + receiptsHeader.getN_CashDelay());
		
		if (receiptsHeader.getC_ReceiptType().equals("1") && receiptsHeader.getN_CashDelay() == 0) {			
			receiptsHeader.setC_Status("2");
			receiptsHeaderForm.put("C_STATUS", "2");
			receiptsHeaderForm.put("B_CLEARED", "1");
		}
		try {			
			Map map = new HashMap();
			int success = 0;
			Long n_reference = new Long(0);
			String c_status = (String) receiptsHeaderForm.get("C_STATUS");
			receiptsHeaderForm.put("C_STATUS", "0");
			if (receiptsHeader.getC_ReceiptType().trim().equals("1")) {								
				log.info("REceiptsHeader to be saved: ");
				ServiceUtility.viewUserParameters(receiptsHeaderForm);
				success = rHeaderDAO.addReceiptsHeader(receiptsHeaderForm);
			}
			else {
				log.info("receiptType: 3/4");
				if(receiptType.trim().equalsIgnoreCase("3") || receiptType.trim().equalsIgnoreCase("4")) {
					map.put("N_REFFORCANCEL", receiptsHeaderForm.get("N_REFUNDREFNO").toString());
					receiptsHeaderForm.put("N_REFFORCANCEL", receiptsHeaderForm.get("N_REFUNDREFNO").toString());
					log.info("N_REFFORCANCEL:"+receiptsHeaderForm.get("N_REFUNDREFNO").toString());
				}
				success = rHeaderDAO.addReceiptsHeaderStatus2(receiptsHeaderForm);
			}
			if (success > 0) {
				receiptsHeader.setN_RefNo(success);
				//get Reference Number from Ledger
			//	SubHeaderDAO JD = (SubHeaderDAO)Persistence.getDAO("SubHeaderDAO");
			//	n_reference = JD.getNumberSeries(); 
				
				//update selected receipt for refund --rdc05202010
				String userID = receiptsHeaderForm.get("C_USERID").toString();
				map.put("C_STATUS", "4");
				map.put("C_APPROVER", userID);
				map.put("N_REFNO", receiptsHeaderForm.get("N_REFUNDREFNO").toString());
				if(receiptType.trim().equalsIgnoreCase("4")) {
					RefundDAO refundDAO = (RefundDAO)Persistence.getDAO("RefundDAO");
					boolean success4 = refundDAO.updateRefundStatus(map);
					if (success4) {
						AuditService as = AuditService.getInstance();				
						as.addAudit(receiptsHeaderForm.get("C_USERID").toString(), "U", "REFUND", "C_STATUS=4,N_REFUNDREFNO="+success+"");	
					}
				} else if(receiptType.trim().equalsIgnoreCase("3")) {
					//map.put("N_REFNO", receiptsHeaderForm.get("N_REFNO").toString());
					AdvancesDAO advancesDAO = (AdvancesDAO)Persistence.getDAO("AdvancesDAO");
					boolean success3 = advancesDAO.updateReceiptAdvanceStatus(map);
					if (success3) {
						AuditService as = AuditService.getInstance();				
						as.addAudit(receiptsHeaderForm.get("C_USERID").toString(), "U", "ADVANCES", "C_STATUS=4,N_REFUNDREFNO="+success+"");	
					}
				}
				
				 
				receiptsHeaderForm.put("N_TOTINVAMT", "0");
				receiptsHeaderForm.put("N_OPAMT", receiptsHeader.getN_Amount());
				receiptsHeaderForm.put("N_REFNO", receiptsHeader.getN_RefNo());
				receiptsHeaderForm.put("CD", receiptsHeader.getN_CashDelay());
				receiptsHeaderForm.put("C_RECEIPTTYPE", receiptType);
				receiptsHeaderForm.put("USERID", userID);
				receiptsHeaderForm.put("N_TRANSACTIONNO",n_reference);
				receiptsHeaderForm.put("C_Type", "P");
				receiptsHeaderForm.put("C_TransactionType", "P");
				updateReceiptsTotalInvAmount(receiptsHeaderForm);
				 
				if (receiptType.equals("1")) { 
					receiptsHeaderForm.put("C_BankName", receiptsHeaderForm.get("C_BANKCODE")!=null?receiptsHeaderForm.get("C_BANKCODE"):null);
					receiptsHeaderForm.put("C_CheckNo", receiptsHeaderForm.get("C_CHECKNO")!=null?receiptsHeaderForm.get("C_CHECKNO"):null);
					receiptsHeaderForm.put("D_DepositedDate", receiptsHeaderForm.get("D_TRANSACTIONDATE")!=null?receiptsHeaderForm.get("D_TRANSACTIONDATE"):null);
				}
				SubHeaderService JS = SubHeaderService.getInstance();
				n_reference= JS.createSubHeader(receiptsHeaderForm, receiptsHeaderForm.get("opmt")!=null &&!receiptsHeaderForm.get("opmt").toString().contentEquals("0")?"COLLECTION with Overpayment":Boolean.parseBoolean(receiptsHeaderForm.get("partial").toString())?"COLLECTION with partial payment":"COLLECTION", currDate,"COLLECTION");
			
				//check differences 
				ServiceUtility.viewUserParameters(receiptsHeaderForm);
				//
				int x =0 ;
				//String var = "invoice"+x;
				//changed getValue to N_totInv from invoices for summing amount in Acct Entries -CVG 05/31/16
				List<String[]> invoicess = new ArrayList();
				//while(receiptsHeaderForm.get("N_totInv")!=null){
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				if(receiptsHeaderForm.get("unfactoredInvoices")!=null&&!receiptsHeaderForm.get("unfactoredInvoices").toString().contentEquals("")){
					
					ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
					String[] unfactoredInvoicesArray = receiptsHeaderForm.get("unfactoredInvoices").toString().split(";");
					for(int index=0;index<=unfactoredInvoicesArray.length-1;index++){
						ReceiptsDtlOther _ReceiptsDtlOther = new ReceiptsDtlOther();
						_ReceiptsDtlOther.setC_description(unfactoredInvoicesArray[index].split(",")[0]);
						_ReceiptsDtlOther.setN_amount(Double.parseDouble(unfactoredInvoicesArray[index].split(",")[1]));
						_ReceiptsDtlOther.setD_transactionDt(sdf.parse(unfactoredInvoicesArray[index].split(",")[2]));
						_ReceiptsDtlOther.setN_refNo(receiptsHeader.getN_RefNo());
						_ReceiptsDtlOther.setCollected_amount(_ReceiptsDtlOther.getN_amount());
						_ReceiptsDtlOther.setWaived_amount(0);
						_ReceiptsDtlOther.setCharge_type(2);
						_ReceiptsDtlOther.setIs_net(Boolean.parseBoolean(unfactoredInvoicesArray[index].split(",")[3]));
						try{
							_ReceiptsDtlOtherService.insertReceiptsDtlOther(_ReceiptsDtlOther);
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				}

				double otherChargesAmount = 0.0;
				//OTHER CHARGES
				double chargesDC =  0.0;
				double unfactoredServiceCharge = 0.0;
				double penaltyCharges = 0.0; 
				
				if(receiptsHeaderForm.get("otherCharges")!=null&&!receiptsHeaderForm.get("otherCharges").toString().contentEquals("")){

					ReceiptsDtlOtherService _ReceiptsDtlOtherService = ReceiptsDtlOtherService.getInstance();
					String[] unfactoredInvoicesArray = receiptsHeaderForm.get("otherCharges").toString().split(";");
					for(int index=0;index<=unfactoredInvoicesArray.length-1;index++){
						String[] data = unfactoredInvoicesArray[index].split(",");
						ReceiptsDtlOther _ReceiptsDtlOther = new ReceiptsDtlOther();
						_ReceiptsDtlOther.setCharge_type((Integer.parseInt(data[0])));
						_ReceiptsDtlOther.setC_description(data[1]);
						_ReceiptsDtlOther.setCharge_type(Integer.parseInt( data[3]));
						_ReceiptsDtlOther.setD_transactionDt(date.newDate());
						_ReceiptsDtlOther.setN_amount(Double.parseDouble(data[7]));
						_ReceiptsDtlOther.setCollected_amount(Double.parseDouble(data[4].isEmpty()?"0":data[4]));
						_ReceiptsDtlOther.setWaived_amount(Double.parseDouble(data[5].isEmpty()?"0":data[5]));
						_ReceiptsDtlOther.setCharge_deduction(Integer.parseInt(data[6]));
						_ReceiptsDtlOther.setN_refNo(receiptsHeader.getN_RefNo());
						
						switch(_ReceiptsDtlOther.getCharge_type()){
						case 1:
							chargesDC += _ReceiptsDtlOther.getCollected_amount();
							break;
						case 2:
							unfactoredServiceCharge += _ReceiptsDtlOther.getCollected_amount();
							break;
						case 3:
							penaltyCharges += _ReceiptsDtlOther.getCollected_amount();
							break;
						case 4:
							//Not Implemented
							break;
						default:
							//Not Implemented
							break;
							
						}
						
						if((_ReceiptsDtlOther.getN_amount() - _ReceiptsDtlOther.getCollected_amount())==0){
							_ReceiptsDtlOther.setCharge_status(1);
						}else if((_ReceiptsDtlOther.getN_amount() - (_ReceiptsDtlOther.getCollected_amount()+ _ReceiptsDtlOther.getWaived_amount()))==0){
							_ReceiptsDtlOther.setCharge_status(4);
						}else if((_ReceiptsDtlOther.getN_amount() - _ReceiptsDtlOther.getWaived_amount())==0){
							_ReceiptsDtlOther.setCharge_status(3);
						}else if((_ReceiptsDtlOther.getN_amount() - (_ReceiptsDtlOther.getCollected_amount()+ _ReceiptsDtlOther.getWaived_amount()))!=0){
							_ReceiptsDtlOther.setCharge_status(2);
						}
						otherChargesAmount = otherChargesAmount+_ReceiptsDtlOther.getCollected_amount();
						try{
							_ReceiptsDtlOtherService.insertReceiptsDtlOther(_ReceiptsDtlOther);
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				}
				receiptsHeaderForm.put("penaltyCharges", penaltyCharges);
				receiptsHeaderForm.put("chargesDC", chargesDC);

				//END OTHER CHARGES
				if(receiptsHeaderForm.get("N_totInv")!=null){
					 String[] thisInvoice = receiptsHeaderForm.get("N_totInv").toString().split(",");
					 invoicess.add(thisInvoice);
				}
					
				receiptsHeaderForm.put("invoicess", invoicess); 
				receiptsHeaderForm.put("ClEq",receiptsHeaderForm.get("opmt"));
				
				//--------------added by CVG as of 06-07-16
				receiptsHeaderForm.put("n_discchg1",receiptsHeaderForm.get("N_DISCCHG"));
				receiptsHeaderForm.put("penalty",receiptsHeaderForm.get("N_PENALTYCHG"));
				double origAmt =  receiptsHeaderForm.get("N_ORIGAMOUNT") != null ?Double.parseDouble(receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", "")):0;
				double discChg =  receiptsHeaderForm.get("N_DISCCHG") != null ? Double.parseDouble(receiptsHeaderForm.get("N_DISCCHG").toString().replaceAll(",", "")):0;
				double penalty =  receiptsHeaderForm.get("N_PENALTYCHG") != null ?Double.parseDouble (receiptsHeaderForm.get("N_PENALTYCHG").toString().replaceAll(",", "")):0;
				
				Double origAmount = origAmt -otherChargesAmount;
				receiptsHeaderForm.put("N_ORIGAMOUNT", origAmount + otherChargesAmount);
				ServiceUtility.viewUserParameters(receiptsHeaderForm);
				// --------------end
				double ClEqCharges = discChg+penalty;
				receiptsHeaderForm.put("ClEqCharges", ClEqCharges);
				//String ctr = receiptsHeaderForm.get("N_INVCTR") != null ? receiptsHeaderForm.get("N_INVCTR").toString() : "";
				JS.createLedgerEntry2(receiptsHeaderForm, "Collection", n_reference);
				
				//------------added by CVG as of 06-07-16
				//java.util.Date date = new java.util.Date(); 
				java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy");
				String today = format.format(date.newDate());
				receiptsHeaderForm.put("TODAY", today);
				Integer insertDiscountDetailCount =rHeaderDAO.insertDiscountDetailReceipt(receiptsHeaderForm);
			    log.info("Insert discount detail sucessful!: "+insertDiscountDetailCount+" record(s)");
				
				Integer insertPenaltyDetailCount =rHeaderDAO.insertPenaltyDetailReceipt(receiptsHeaderForm);
				log.info("Insert penalty detail sucessful!: "+insertPenaltyDetailCount+" record(s)");
				//--------------end
				ReceiptsHeaderDAO _ReceiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
				if(receiptType.trim().equalsIgnoreCase("1")||receiptType.trim().equalsIgnoreCase("2")){
					receiptsHeaderForm.put("C_CLNTCODE",receiptsHeader.getC_ClntCode());
					receiptsHeaderForm.put("N_REFNO",receiptsHeader.getN_RefNo());
					AccountingMaintenanceService AMS = AccountingMaintenanceService.getInstance();
					
					AMS.saveTransactionRate(_ReceiptsHeaderDAO.getTransactionRateReceipts(receiptsHeaderForm));
					
					_ReceiptsHeaderDAO.updateReceiptsStatusByBatch(c_status,"("+String.valueOf(success)+")");
				}
				
				
//				if(receiptsHeaderForm.get("opmt")!=null &&!receiptsHeaderForm.get("opmt").toString().contentEquals("0") ){
//					JS.createLedgerlEntry(receiptsHeaderForm, "110602201000",receiptsHeaderForm.get("opmt") , "N_DEBIT",n_reference);
//					JS.createLedgerlEntry(receiptsHeaderForm, "255001101000",receiptsHeaderForm.get("opmt") , "n_credit",n_reference);
//				}
				
				if (mode.equalsIgnoreCase("PDC")) {
					
					PDCService pdcService = PDCService.getInstance();
					Map pdcForm = new HashMap();
					pdcForm.put("C_CLNTCODE", receiptsHeader.getC_ClntCode());
					pdcForm.put("C_CUSTCODE", receiptsHeader.getC_CustCode());
					pdcForm.put("C_BANKCODE", receiptsHeader.getC_BankCode());
					pdcForm.put("D_CHECKDATE", receiptsHeader.getD_CheckDate());
					pdcForm.put("B_PROCESSED", receiptsHeader.getB_FromPDC());
					pdcForm.put("N_CHECKNO", receiptsHeader.getC_CheckNo());
					pdcForm.put("C_USERID", userID);
					
					pdcService.updatePDCStatus(pdcForm);
				}
				
				/*
				  //insert data to AMS if receiptType is 1 or 2
				if (receiptType.equalsIgnoreCase("1") || receiptType.equalsIgnoreCase("2")) {
					AmsService amsService = AmsService.getInstance();
					Map amsForm = new HashMap();
					amsForm.put("D_TRANSACTIONDATE", receiptsHeader.getD_TransactionDate());
					amsForm.put("C_CLNTCODE", receiptsHeader.getC_ClntCode());
					amsForm.put("N_AMOUNT", receiptsHeader.getN_Amount());
					amsForm.put("C_TYPE", "P");
					amsForm.put("C_BRANCHCODE", receiptsHeader.getC_BranchCode());
					amsForm.put("B_PROCESSED", "0");
					amsForm.put("N_REFNO", success + "");
					if (receiptType.equalsIgnoreCase("1")) {
						amsForm.put("C_REFERENCE", receiptsHeader.getC_CheckNo());
						amsForm.put("C_PAYMENTTYPE", "CP");
					}
					else {
						amsForm.put("C_REFERENCE", null);
						amsForm.put("C_PAYMENTTYPE", "DC");						
					}
					
					boolean insertAMS = amsService.addAMS(amsForm);
					
					if (insertAMS) {					
						StringBuilder sb = new StringBuilder("D_TRANSACTIONDATE=").append(receiptsHeader.getD_TransactionDate()).append(";");
						sb.append("C_CLNTCODE=").append(receiptsHeader.getC_ClntCode()).append(";");
						sb.append("N_AMOUNT=").append(receiptsHeader.getN_Amount()).append(";");
						sb.append("C_TYPE=P;");
						sb.append("C_BRANCHCODE=").append(receiptsHeader.getC_BranchCode()).append(";");
						sb.append("B_PROCESSED=0;");
						sb.append("N_REFNO=").append(success).append(";");
						if (receiptType.equalsIgnoreCase("1")) {
							sb.append("C_REFERENCE=").append(receiptsHeader.getC_CheckNo()).append(";");
							sb.append("C_PAYMENTTYPE = CP;");
						}
						else {
							sb.append("C_PAYMENTTYPE = DC;");
						}
						
						AuditService as = AuditService.getInstance();				
						as.addAudit(userID, "I", "AMS", sb.toString());
					}
					
					
					
				}*/
				
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "I", "RECEIPTSHDR", receiptsHeader.toString());				
				

				
				jsonData.put("status", "Receipts Header Added");				
				jsonData.put("refNo", success);
				jsonData.put("custCode", receiptsHeaderForm.get("C_CUSTCODE"));
				jsonData.put("N_TRANSACTIONNO",n_reference);
			}
		}
		catch (Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		return jsonData;
	}
	
	public Map addReceiptsHeader2(Map receiptsHeaderForm) {
		Map jsonData = new HashMap();
		
		log.info("ServiceUtility 1 ------>");
		ServiceUtility.viewUserParameters(receiptsHeaderForm);
		String mode = receiptsHeaderForm.get("mode") != null ? receiptsHeaderForm.get("mode").toString() : "";
		if (mode.equalsIgnoreCase("PDC")) {
			this.addReceiptsHeaderPDC(receiptsHeaderForm);			
		}
		else {
			CheckTypeDAO checkTypeDAO = (CheckTypeDAO)Persistence.getDAO("CheckTypeDAO");
			//String checkType = checkTypeDAO.searchCtypeCodeByName(receiptsHeaderForm);
			String checkType = receiptsHeaderForm.get("C_CHECKTYPECODE") != null ? receiptsHeaderForm.get("C_CHECKTYPECODE").toString() : "";
			//rdc String checkType = receiptsHeaderForm.get("C_CHECKTYPE") != null ? receiptsHeaderForm.get("C_CHECKTYPE").toString() : "";
			receiptsHeaderForm.put("C_CHECKTYPE", checkType);
			receiptsHeaderForm.put("B_FROMPDC", "0");
		}
		log.info("ServiceUtility 2 ------>");
		ServiceUtility.viewUserParameters(receiptsHeaderForm);
		ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		
		String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPEVAL").toString();
		//rdc String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPE").toString();
		if (receiptType.equals("1")) {
			int checkCount = rHeaderDAO.searchCheckNo(receiptsHeaderForm);
			if (checkCount > 0) {
				jsonData.put("status", "Check Number already exists.");
				return jsonData;
			}			
		}
		
		CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
		
		//String currDate = DateHelper.format(new java.util.Date());
		String currDate = receiptsHeaderForm.get("D_TRANSDATE").toString();
		//rdc String currDate = receiptsHeaderForm.get("D_TRANSACTIONDATE").toString();
		receiptsHeaderForm.put("D_TRANSACTIONDATE", currDate);
		
		receiptsHeaderForm.put("C_DESCRIPTION", (String) receiptsHeaderForm.get("C_DESCRIPTION2"));
		log.info("C_DESCRIPTION: " + receiptsHeaderForm.get("C_DESCRIPTION"));
		
		
		if (receiptType.trim().equalsIgnoreCase("2") || receiptType.trim().equalsIgnoreCase("3") || receiptType.trim().equalsIgnoreCase("4")) {			
			receiptsHeaderForm.put("N_AMOUNT", receiptsHeaderForm.get("N_AMOUNT2").toString().replaceAll(",", ""));
			//rdc receiptsHeaderForm.put("N_AMOUNT", receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", ""));
			receiptsHeaderForm.put("C_NOOFDAYS", "0");
			receiptsHeaderForm.put("D_CLEARINGDATE", currDate);
			receiptsHeaderForm.put("C_STATUS", "2");
			receiptsHeaderForm.put("D_CHECKDATE", receiptsHeaderForm.get("D_CREDITDATE"));
			receiptsHeaderForm.put("N_ORIGAMOUNT", (String) receiptsHeaderForm.get("N_ORIGAMOUNT2"));
			receiptsHeaderForm.put("B_CLEARED", "1");
		}
		
		//insert n_refundDays for receipt type 1 and 2
		if (receiptType.trim().equalsIgnoreCase("1")) {
			receiptsHeaderForm.put("N_REFUNDDAYS", receiptsHeaderForm.get("N_REFUNDDAYS"));
			receiptsHeaderForm.put("B_CLEARED", "0");
		}
		else if (receiptType.trim().equalsIgnoreCase("2")) {
			receiptsHeaderForm.put("N_REFUNDDAYS", receiptsHeaderForm.get("N_REFUNDDAYS2"));
		}
		else if (receiptType.trim().equalsIgnoreCase("3") || receiptType.trim().equalsIgnoreCase("4")) {			
			receiptsHeaderForm.put("N_REFUNDDAYS", null);
		}
		
		ServiceUtility.viewUserParameters(receiptsHeaderForm);
		//rdc - ReceiptsHeader receiptsHeader = ReceiptsHeaderUtility.toObject(receiptsHeaderForm);
		receiptsHeaderForm.put("N_ORIGAMOUNT", receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", ""));
		receiptsHeaderForm.put("N_AMOUNT", receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", ""));
		ReceiptsHeader receiptsHeader = ReceiptsHeaderUtility.toObject(receiptsHeaderForm);
		String dateBouncedStr = receiptsHeaderForm.get("D_CHECKDATE").toString();
		if (dateBouncedStr.length() == 8) {
			String dateBouncedYear = dateBouncedStr.substring(6,8);
			dateBouncedYear = "20" + dateBouncedYear;
			dateBouncedStr = dateBouncedStr.substring(0,6) + dateBouncedYear;			
		}
		receiptsHeaderForm.put("D_CHECKDATE", dateBouncedStr);
		
		log.info("REceiptType: " + receiptsHeader.getC_ReceiptType());
		log.info("CashDelay: " + receiptsHeader.getN_CashDelay());
		
		if (receiptsHeader.getC_ReceiptType().equals("1") && receiptsHeader.getN_CashDelay() == 0) {			
			receiptsHeader.setC_Status("2");
			receiptsHeaderForm.put("C_STATUS", "2");
			receiptsHeaderForm.put("B_CLEARED", "1");
		}
		try {			
			int success = 0;
			if (receiptsHeader.getC_ReceiptType().trim().equals("1")) {								
				log.info("REceiptsHeader to be saved: ");
				ServiceUtility.viewUserParameters(receiptsHeaderForm);
				//success = rHeaderDAO.addReceiptsHeader(receiptsHeaderForm);
			}
			else {
				//success = rHeaderDAO.addReceiptsHeaderStatus2(receiptsHeaderForm);
			}
			
			//if (success > 0) {
				receiptsHeader.setN_RefNo(success);
				String userID = receiptsHeaderForm.get("C_USERID").toString();
				//int refNo = success;
				//receiptsHeader.setN_RefNo(refNo);
				
								
				//update Client Transaction Amount; 
				// **** Do not update it yet. to be updated after invoice was chosen.
				/*Map receiptsForm = new HashMap();
				receiptsForm.put("C_CLNTCODE", receiptsHeader.getC_ClntCode() + "");
				receiptsForm.put("N_CHECKAMOUNT", receiptsHeader.getN_Amount() + "");
				receiptsForm.put("C_RECEIPTTYPE", receiptType);
				receiptsForm.put("C_USERID", userID);
				log.info("updateClientTransactionAmount");
				boolean result = ClientService.getInstance().updateClientTransAmount(receiptsForm);*/
				receiptsHeaderForm.put("N_TOTINVAMT", "0");
				receiptsHeaderForm.put("N_OPAMT", receiptsHeader.getN_Amount());
				receiptsHeaderForm.put("N_REFNO", receiptsHeader.getN_RefNo());
				receiptsHeaderForm.put("CD", receiptsHeader.getN_CashDelay());
				receiptsHeaderForm.put("C_RECEIPTTYPE", receiptType);
				receiptsHeaderForm.put("USERID", userID);
				//updateReceiptsTotalInvAmount(receiptsHeaderForm);
				
				if (mode.equalsIgnoreCase("PDC")) {
					
					PDCService pdcService = PDCService.getInstance();
					Map pdcForm = new HashMap();
					pdcForm.put("C_CLNTCODE", receiptsHeader.getC_ClntCode());
					pdcForm.put("C_CUSTCODE", receiptsHeader.getC_CustCode());
					pdcForm.put("C_BANKCODE", receiptsHeader.getC_BankCode());
					pdcForm.put("D_CHECKDATE", receiptsHeader.getD_CheckDate());
					pdcForm.put("B_PROCESSED", receiptsHeader.getB_FromPDC());
					pdcForm.put("N_CHECKNO", receiptsHeader.getC_CheckNo());
					pdcForm.put("C_USERID", userID);
					
					//pdcService.updatePDCStatus(pdcForm);
				}
						
				
				jsonData.put("status", "Receipts Header Added");				
				jsonData.put("refNo", success);
				jsonData.put("custCode", receiptsHeaderForm.get("C_CUSTCODE"));
				jsonData.put("checkDate", receiptsHeaderForm.get("D_CHECKDATE"));
				
		}
		catch (Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		return jsonData;
	}
	
	public int searchNRefNo(Map receiptsHeaderForm, String status){
		log.info("--->> searchNRefNo SERVICE ...");
						
		ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");		
		if (status == "1") {
			return rHeaderDAO.searchNRefNo(receiptsHeaderForm);
		}
		else {
			return rHeaderDAO.searchNRefNoStatus2(receiptsHeaderForm);			
		}
				
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchScheduleReceiptsHeader(Map receiptsHeaderForm){
		
		log.info("--->> searchScheduleReceiptsHeader SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		List newRecordsList = new ArrayList();
		Map newRecordsMap = new HashMap();
		ArrayList receiptsDetails = new ArrayList();
		String totalRecords = "";
		BigDecimal totalAmount = new BigDecimal("0.00");
		
		
		
		try{
			
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");				
			
			records = receiptsHeaderDAO.searchScheduleReceiptsHeader(receiptsHeaderForm);	
		
			for(int cnt=0;cnt<records.size();cnt++)
			{
				newRecordsMap = new HashMap();
				receiptsDetails = new ArrayList();
				receiptsDetails = (ArrayList)receiptsHeaderDAO.searchScheduleReceiptsDetail(((HashMap)records.get(cnt)));
				//newRecordsMap = ((HashMap)records.get(cnt));
				totalAmount = new BigDecimal("0.00");
				
				for(int cntInner=0;cntInner<receiptsDetails.size();cntInner++)
				{
					totalAmount = totalAmount.add(((BigDecimal)((HashMap)receiptsDetails.get(cntInner)).get("N_RECEIPTAMT"))).setScale(2, BigDecimal.ROUND_HALF_UP);
				}
				
				newRecordsMap.put("totals", totalAmount.toPlainString());
				newRecordsMap.put("details", receiptsDetails);
				newRecordsList.add(newRecordsMap);
				//newRecordsList.add(receiptsDetails);
			}
			
			
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
						
			log.info("--->> searchScheduleReceiptsHeader RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				//jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)receiptsHeaderForm.get("records")),((String)receiptsHeaderForm.get("page")),((String)receiptsHeaderForm.get("total")));
				jsondata.put("returnData", records);
				jsondata.put("returnDataDetails", newRecordsList);
			}else{
				jsondata.put("status","searchScheduleReceiptsHeader Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map searchScheduleReceiptsDetail(Map receiptsHeaderForm){
		
		log.info("--->> searchScheduleReceiptsDetail SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");				
			
			records = receiptsHeaderDAO.searchScheduleReceiptsDetail(receiptsHeaderForm);	
		
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
						
			log.info("--->> searchScheduleReceiptsDetail RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				//jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)receiptsHeaderForm.get("records")),((String)receiptsHeaderForm.get("page")),((String)receiptsHeaderForm.get("total")));
				jsondata.put("returnData", records);
			}else{
				jsondata.put("status","searchScheduleReceiptsDetail Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
	public Map searchReceiptsHdrByCustomer(Map receiptsHeaderForm){
		
		log.info("--->> searchReceiptsHdrByCustomer SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");				
			
			totalRecords = receiptsHeaderDAO.getTotalReceiptsHdrByCustomer(receiptsHeaderForm);			
			receiptsHeaderForm = ServiceUtility.addPaging(receiptsHeaderForm,totalRecords);			
			List lHeader = receiptsHeaderDAO.searchReceiptsHdrByCustomer(receiptsHeaderForm);			
			
			log.info("--->> searchReceiptsHdrByCustomer RECORDS: "+lHeader.size());
			if((lHeader!=null) && (lHeader.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lHeader, ((String)receiptsHeaderForm.get("records")),((String)receiptsHeaderForm.get("page")),((String)receiptsHeaderForm.get("total")));
			}else{				
				jsondata.put("status","searchReceiptsHdrByCustomer Failed ... ");
			}			
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}
	
	public boolean updateReceiptsBouncedCheck(int n_RefNo, String status, Date dateBounced) {
		return updateReceiptsBouncedCheck(n_RefNo, status, dateBounced, "-");
	}
	
	public boolean updateReceiptsBouncedCheck(int n_RefNo, String status, Date dateBounced, String userID) {
		
		boolean success = false;
		String dCReceiptAmount="";
		
		Map m = new HashMap();
		Map newData = new HashMap();
		m.put("N_REFNO", n_RefNo);
		m.put("C_STATUS", status);
		m.put("D_DATEBOUNCED", dateBounced);
		m.put("C_USERID", userID);
		m.get("N_REFNO");
		
		ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		
		dCReceiptAmount = receiptsHeaderDAO.getReceiptsDCReversal(n_RefNo);
		
		m.put("N_DCREVERSAL", dCReceiptAmount);
		
		success = receiptsHeaderDAO.updateReceiptsBouncedCheck(m);
		
		if(success){
			
			try{
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(m);
				ReceiptsHeader rcpth = new ReceiptsHeader(newData);
				as.addAudit(userID,"U","RECEIPTSHDR",rcpth.toString());
	
			}catch(Throwable x){
				x.printStackTrace();
			}
		}
				
		return success;
	}
	
	public Map processDishonoredChecks(Map receiptsHeaderForm) {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map jsonData = new HashMap();
		Map newData = new HashMap();
		ServiceUtility.viewUserParameters(receiptsHeaderForm);
		String receiptAmount = "";
		double totalAmount = 0;
		
		try {
		
		int n_RefNo = Integer.parseInt(receiptsHeaderForm.get("N_REFNO").toString());
			
		//getReceiptHeaderInfo
		ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		List lReceipts = receiptsHeaderDAO.searchReceiptsByNRefNo(n_RefNo);
		log.info("receiptsSize:" + lReceipts.size());
		Map m = (HashMap) lReceipts.get(0);
		String receiptStatus = (String) m.get("C_STATUS");
		double rOpAmount = m.get("N_OPAMT") != null ? Double.parseDouble(m.get("N_OPAMT").toString()) : 0;
		int refundRefNo = m.get("N_REFUNDREFNO") != null ? Integer.parseInt(m.get("N_REFUNDREFNO").toString()) : 0;
			
		log.info("receiptStatus:" + receiptStatus);
		log.info("opAmount:" + rOpAmount);
		log.info("refundRefNo:" + refundRefNo);
		
		//update ReceiptsHeader		
		String status = "3";
		String transDate = receiptsHeaderForm.get("D_transactiondate").toString();
		if (transDate.length() == 8) {
			String dateBouncedYear = transDate.substring(6,8);
			dateBouncedYear = "20" + dateBouncedYear;
			transDate = transDate.substring(0,6) + dateBouncedYear;			
		}
		
		String dateBouncedStr = receiptsHeaderForm.get("D_DATEBOUNCED").toString();
		if (dateBouncedStr.length() == 8) {
			String dateBouncedYear = dateBouncedStr.substring(6,8);
			dateBouncedYear = "20" + dateBouncedYear;
			dateBouncedStr = dateBouncedStr.substring(0,6) + dateBouncedYear;			
		}
		
	 
		
		String chckdateStr  = receiptsHeaderForm.get("D_CHECKDATE").toString();
		if (chckdateStr.length() == 8) {
			String dateBouncedYear = dateBouncedStr.substring(6,8);
			dateBouncedYear = "20" + dateBouncedYear;
			chckdateStr = dateBouncedStr.substring(0,6) + dateBouncedYear;			
		}
	
		Date dateBounced = DateHelper.parse(dateBouncedStr);
		Date checkDate = DateHelper.parse(chckdateStr);
		Date TransDate = DateHelper.parse(transDate);
		log.info(dateBounced.compareTo(checkDate));
		String checkNo = receiptsHeaderForm.get("C_CHECKNO").toString();
		String bankCode = receiptsHeaderForm.get("C_BANK").toString();
		String amount = receiptsHeaderForm.get("N_AMOUNT").toString();
		amount = amount.replaceAll(",", "");
		String clntCode = receiptsHeaderForm.get("C_CLNTCODE").toString();
		String custCode = receiptsHeaderForm.get("C_CUSTCODE").toString();
		String userID = receiptsHeaderForm.get("C_USERID").toString();
		
		this.updateReceiptsBouncedCheck(n_RefNo, status, dateBounced, userID);
		//CREATE ENTRY
		SimpleDateFormat SDF = new SimpleDateFormat ("yyyy/MM/dd");
		String currDate = SDF.format(date.newDate()); // before: new date()
		Date CurrDate = SDF.parse(SDF.format(date.newDate())); //before: new date()
		Date CheckDate = SDF.parse(SDF.format(TransDate));
		if(CheckDate.compareTo(CurrDate)!=0){
			SubHeaderService JS = SubHeaderService.getInstance();
			List<String[]> creditNote =new ArrayList();
			List<Map> CNs = JS.getCreditNotes(n_RefNo);
			
			for(int loop=0;loop<CNs.size();loop++){
				Map CN = CNs.get(loop);
				String[] credits = new String[2];
				credits[0] = CN.get("n_invno").toString();
				credits[1] = CN.get("n_amount").toString();
				creditNote.add(credits);
			}
			
			List<String[]> invoicess =new ArrayList();
			CNs = JS.getReceipsDtl(n_RefNo);
			
			for(int loop=0;loop<CNs.size();loop++){
				Map CN = CNs.get(loop);
				String[] invoices = new String[2];
				invoices[0] = CN.get("n_invno").toString();
				invoices[1] = CN.get("n_receiptamt").toString();
				invoicess.add(invoices);
			}
			
			SimpleDateFormat UDF = new SimpleDateFormat ("MM/dd/yyyy");
			Map headerMap = JS.getCollectionRefHeader(n_RefNo);
			Long n_reference = new Long(0);
			
			if(headerMap!=null){
				//receiptsHeaderForm.put("C_TRANSACTIONTYPE", "P");
				//JS.cancelSubHeaderEntry(receiptsHeaderForm);
				headerMap.put("D_TRANSACTIONDATE", currDate);
				headerMap.put("D_CancelledDate",null);
				headerMap.put("B_Cancelled",null);
				headerMap.put("C_USERID", receiptsHeaderForm.get("C_USERID").toString());
				headerMap.put("particular","(DISHONORED) "+ headerMap.get("particular").toString());
				n_reference= JS.createSubHeader(headerMap, "", UDF.format(date.newDate()),""); //before: new date()
			}
			
			else{
				ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
				headerMap = rHeaderDAO.getReceiptsHdrMap(receiptsHeaderForm);
				headerMap.put("D_TRANSACTIONDATE", currDate);
				headerMap.put("C_BRANCHCODE", receiptsHeaderForm.get("C_BRANCHCODE"));
				headerMap.put("C_USERID", userID);
				n_reference= JS.createSubHeader(headerMap, "(DISHONORED) COLLECTION", UDF.format(date.newDate()),"DISHONORED"); //before: new date()
			}
			receiptsHeaderForm.put("N_ORIGAMOUNT", headerMap.get("N_Amount"));
			receiptsHeaderForm.put("creditNote", creditNote);
			receiptsHeaderForm.put("invoicess", invoicess);
			receiptsHeaderForm.put("ClEq", headerMap.get("N_OPAMT"));
			receiptsHeaderForm.put("D_TRANSACTIONDATE", currDate);
				
			JS.createLedgerEntry2(receiptsHeaderForm, "Dishonored", n_reference);
		}
		else{
			SubHeaderService JS = SubHeaderService.getInstance();
			receiptsHeaderForm.put("C_TRANSACTIONTYPE", "P");
			JS.cancelSubHeaderEntry(receiptsHeaderForm);
		}
			
		
		
		
		//update DateBounced if from PDC
		String fromPDC = receiptsHeaderForm.get("B_FROMPDC") != null ? receiptsHeaderForm.get("B_FROMPDC").toString().trim() : "0";
		if (fromPDC.equalsIgnoreCase("TRUE")) {
			Map pdcForm = new HashMap();
			pdcForm.put("D_DATEBOUNCED", dateBounced);
			pdcForm.put("N_CHECKNO", checkNo);
			pdcForm.put("C_BANKCODE", bankCode);
			pdcForm.put("N_CHECKAMT", amount);
			pdcForm.put("C_CLNTCODE", clntCode);
			pdcForm.put("C_CUSTCODE", custCode);
			
			PdcDAO pdcDAO = (PdcDAO)Persistence.getDAO("PdcDAO");			
			pdcDAO.updatePDCBouncedDate(pdcForm);
			
			AuditService aService = AuditService.getInstance();
			StringBuilder sb = new StringBuilder();
			sb.append("D_DATEBOUNCED=").append(dateBounced);
			sb.append("N_CHECKNO=").append(checkNo);
			sb.append("C_BANKCODE=").append(bankCode);
			sb.append("N_CHECKAMT=").append(amount);
			sb.append("C_CLNTCODE=").append(clntCode);
			sb.append("C_CUSTCODE=").append(custCode);
			aService.addAudit(userID, "U", "PDC", sb.toString());
		}
						
		//updateClient receivables (Receipts)
		String invoices = receiptsHeaderForm.get("invoices") != null ? receiptsHeaderForm.get("invoices").toString().trim() : null;
		String invNos = receiptsHeaderForm.get("N_INVNO") != null ? receiptsHeaderForm.get("N_INVNO").toString().trim() : null;
		
		if (invoices != null && invoices.trim().length() > 0) {
			
			
			ArrayList lInvoices = new ArrayList();
			ArrayList lAmount = new ArrayList();
			
			invoices = invoices.substring(0, invoices.length() - 1);
			invNos = invNos.substring(0, invNos.length() - 1);
			//StringTokenizer st = new StringTokenizer(invoices, ",");
			//while (st.hasMoreTokens()) {
			//	lInvoices.add(st.nextToken());
			//}
			
			receiptAmount = receiptsHeaderForm.get("invoicesAmt") != null ? receiptsHeaderForm.get("invoicesAmt").toString().trim() : null;
			if (receiptAmount != null && receiptAmount.trim().length() > 0) {
				receiptAmount = receiptAmount.substring(0, receiptAmount.length() - 1);
				StringTokenizer st2 = new StringTokenizer(receiptAmount, ",");
				while (st2.hasMoreTokens()) {
					lAmount.add(st2.nextToken());
				}
				
				Iterator it = lAmount.iterator();
				while (it.hasNext()) {
					totalAmount = totalAmount + Double.parseDouble(it.next().toString());
				}
			}
			
		}
		
		else{
			receiptAmount = receiptsHeaderForm.get("N_AMOUNT") != null ? receiptsHeaderForm.get("N_AMOUNT").toString().trim().replaceAll(",", "") : "0";
			totalAmount = Double.parseDouble(receiptAmount);
		}
		
		String totalInvoiceAmountStr = receiptsHeaderForm.get("invoicesAmt") != null ? receiptsHeaderForm.get("invoicesAmt").toString().trim() : null;
		
		double amountCheck = receiptsHeaderForm.get("N_AMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT").toString().trim().replaceAll(",", "")) : 0;
		
		double totalInvoiceAmount = 0;
				
		if (totalInvoiceAmountStr != null) {
			log.info("receiptAmount: " + amount);
			
			double receiptAmt = Double.parseDouble(amount);
									
			if (receiptAmt > totalAmount) {
				totalAmount = totalAmount;
			}
			
			ArrayList lInvoiceAmountStr = new ArrayList();
			
			
			if (totalInvoiceAmountStr.length() > 0) {
				totalInvoiceAmountStr = totalInvoiceAmountStr.substring(0, totalInvoiceAmountStr.length() - 1);
				StringTokenizer st2 = new StringTokenizer(totalInvoiceAmountStr, ",");
				while (st2.hasMoreTokens()) {
					lInvoiceAmountStr.add(st2.nextToken());
				}
				
				Iterator it = lInvoiceAmountStr.iterator();
				while (it.hasNext()) {
					totalInvoiceAmount = totalInvoiceAmount + Double.parseDouble(it.next().toString());
				}	
			}
		}
		
		log.info("totalInvoiceAmount : " + totalInvoiceAmount);
		log.info("amountCheck: " + amountCheck );
		log.info("amount: " + totalInvoiceAmountStr );
		double reserves = (amountCheck - totalInvoiceAmount);
		log.info("reserves: " + reserves);
		
		Map receiptsForm = new HashMap();
		receiptsForm.put("C_CLNTCODE", clntCode);
		receiptsForm.put("N_CHECKAMOUNT", "-" + totalAmount + "");
		if (totalInvoiceAmount > 0) {
			receiptsForm.put("FOR_RECEIVABLES", "-" + amount );
		}
		else if (totalInvoiceAmount == 0) {
			receiptsForm.put("FOR_RECEIVABLES", 0 );
		}
		receiptsForm.put("FOR_RESERVES", reserves + "");
		receiptsForm.put("C_RECEIPTTYPE", "4");
		receiptsForm.put("C_USERID", userID);
		receiptsForm.put("DESCRIPTION", "Bounced Check Reversal:" + checkNo);
		boolean result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
		
		String amountRunningBalance = "-" + totalInvoiceAmount;
		CCLinkService.getInstance().updateRunningBalance(clntCode, custCode,  Double.parseDouble(amountRunningBalance), userID);
		//ClientService.getInstance().updateIneligibleRec(clntCode, Double.parseDouble(amountRunningBalance), userID);
				
		//update Client receivables and reserves (Credit Note)
		String cnRefNo = receiptsHeaderForm.get("cnRefNo") != null ? receiptsHeaderForm.get("cnRefNo").toString().trim() : null;
		if (cnRefNo != null && cnRefNo.trim().length() > 0) {
			
			ArrayList lCNAmount = new ArrayList();
			double totalCnAmount = 0;
			
			cnRefNo = cnRefNo.substring(0, cnRefNo.length() - 1);
			cnRefNo = "(" + cnRefNo + ")";
									
			String cnAmount = receiptsHeaderForm.get("cnAmt") != null ? receiptsHeaderForm.get("cnAmt").toString().trim() : null;
			if (cnAmount != null && cnAmount.trim().length() > 0) { 
				cnAmount = cnAmount.substring(0, cnAmount.length() - 1);
				StringTokenizer st2 = new StringTokenizer(cnAmount, ",");
				while (st2.hasMoreTokens()) {
					lCNAmount.add(st2.nextToken());
				}
				
				Iterator it = lCNAmount.iterator();
				while (it.hasNext()) {
					totalCnAmount = totalCnAmount + Double.parseDouble(it.next().toString());
				}	
				
				Map creditNoteForm = new HashMap();
				creditNoteForm.put("C_STATUS", "3");
				creditNoteForm.put("N_REFNO", cnRefNo);
				creditNoteForm.put("C_CLNTCODE", clntCode);
				creditNoteForm.put("N_CHECKAMOUNT", "-" + totalCnAmount);
				creditNoteForm.put("C_RECEIPTTYPE", "3");
				creditNoteForm.put("C_USERID", userID);
										
				CreditNoteService cnService = CreditNoteService.getInstance();
				cnService.updateCreditNoteStatusByBatch(creditNoteForm);
			}
		}
		
		//update Invoice Status to 3 and fullyPaidDate to null
		if (invNos.trim().length() > 0) {
			INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
		
			invoices = "(" + invoices + ")";
			invNos = "(" + invNos + ")";
			boolean updateInvoice = invoiceDAO.updateInvoiceStatusAndDateByCode(invNos, "3", null);
			
			if(updateInvoice){
				try{
					Map map = new HashMap();
					map.put("invoices", invNos);		
					map.put("C_STATUS", "3");
					map.put("D_FULLYPAIDDATE", "");
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(map);
					Invoice invoice = new Invoice(newData);
					as.addAudit(userID,"U","INVOICE",invoice.toString());
		
				}catch(Throwable x){
					x.printStackTrace();
				}
			}
		}
		
		//check if refunded		
		if (receiptStatus.equalsIgnoreCase("4")) {
			processRefundedDishonored(refundRefNo, rOpAmount, clntCode, userID);
		}
			receiptsHeaderForm.put("N_AMOUNT", (Double) totalAmount);
			receiptsHeaderForm.put("N_INVNO", invNos);
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");	
		
			//update n_ineligiblerec in cclink/client
			CCLinkDAO cclinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			String ineligible1 = cclinkDAO.searchIneligibleByClient(receiptsHeaderForm)+ "";
			String clientIneligible = clientDAO.searchIneligibleRecByClient(clntCode)+"";
			
			boolean success3 = rHeaderDAO.updateReceiptsIneligible(receiptsHeaderForm);
			String ineligible2 = cclinkDAO.searchIneligibleByClient(receiptsHeaderForm)+ "";
			double ine1and2 = Money.doRoundOff(Double.parseDouble(ineligible2)-Double.parseDouble(ineligible1));
			receiptsHeaderForm.put("N_INELIGIBLEREC", Double.parseDouble(clientIneligible)+ine1and2);
			
			boolean updateclientIne = clientDAO.updateIneligibleRecByClient(receiptsHeaderForm);
			if (success3 && updateclientIne){
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "CCLINK", "C_CLNTCODE=" +receiptsHeaderForm.get("C_CLNTCODE").toString() + ", C_CUSTCODE=" +receiptsHeaderForm.get("C_CUSTCODE").toString() +", N_INELIGIBLEREC+"+receiptsHeaderForm.get("N_AMOUNT").toString());
				as.addAudit(userID, "U", "CLIENT", "N_INELIGIBLEREC+"+ine1and2);
			}
			log.info("ineligible1:"+ineligible1);
			log.info("ineligible2:"+ineligible2);
			log.info("clientIneligible:"+clientIneligible);
			log.info("ine1and2:"+ine1and2);
			log.info("updateReceiptsCancelIneligible:"+success3);
			log.info("updateclientIne:"+updateclientIne);
			//end-update n_ineligiblerec in cclink/client
		
			jsonData.put("status", "Processing of Dishonored Checks Successful.");
		}
		catch (Throwable x) {
			x.printStackTrace();
			jsonData.put("status", "Processing of Dishonored Checks Failed.");
		}
		
		return jsonData;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	public boolean processRefundedDishonored(int refundRefNo, double opAmount, String clientCode, String userID) {
		boolean result = false;
		
		//search refund Amount
		RefundService refundSvc = RefundService.getInstance();		
		double refundAmount = refundSvc.searchRefundAmount(refundRefNo);
		log.info("refundAmount: " + refundAmount);
		
		//update reserves (+), fiu (-) 
		Map receiptsForm = new HashMap();
		receiptsForm.put("C_CLNTCODE", clientCode);
		receiptsForm.put("N_REFUNDAMOUNT", refundAmount);
		receiptsForm.put("C_USERID", userID);
		receiptsForm.put("DESCRIPTION", "Bounced Check Reversal - Refund:" + refundRefNo);
		receiptsForm.put("TYPE", "REFUND");
		result = ClientService.getInstance().updateClientTransAmountRefund(receiptsForm);
		
		if (opAmount > 0) {
			//update OP 
			Map receiptsForm2 = new HashMap();
			receiptsForm2.put("C_CLNTCODE", clientCode);
			receiptsForm2.put("N_OPAMOUNT", opAmount);
			receiptsForm2.put("C_USERID", userID);
			receiptsForm2.put("DESCRIPTION", "Bounced Check Reversal - OP Refund:" + refundRefNo);
			receiptsForm2.put("TYPE", "OPAMOUNT");
			result = ClientService.getInstance().updateClientTransAmountRefund(receiptsForm2);
		}
		
		//update refund status to cancelled (4) - no need..
		//refundSvc.updateRefundStat(refundRefNo, "4");
				
		return result;
	}
	
	
	public Map searchDiscountChargeReceiptsDetail(Map receiptsHeaderForm){
		
		System.out.println("--->> searchDiscountChargeReceiptsDetail SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		List client = new ArrayList();
		List blr = new ArrayList();
		String strBLR = "";
		String totalRecords = "";
		List newRecordsList = new ArrayList();
		Map newRecordsMap = new HashMap();
		BigDecimal totalCharge = new BigDecimal("0.00");
		
		BigDecimal nAmount;
		BigDecimal nOPAmount;
		BigDecimal clientBLR = new BigDecimal("0.00");;
		BigDecimal discountChargeRate = new BigDecimal("0.00");
		BigDecimal consThreeSixty = new BigDecimal("360.00");
		BigDecimal delay;
		BigDecimal total1;
		BigDecimal total2;
		BigDecimal total3 = new BigDecimal("0.00");
		
		double currency;
		String currencyNAmount;
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
	    NumberFormat numberFormatter = NumberFormat.getInstance();

		
		try{
			
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");							
			records = receiptsHeaderDAO.searchDiscountChargeReceiptsDetail(receiptsHeaderForm);	
			
			ClientDAO clientDAO = (ClientDAO) Persistence.getDAO("ClientDAO");
			client = clientDAO.searchClientByCode(receiptsHeaderForm);
			
			BLRFileDAO blrFileDAO = (BLRFileDAO)Persistence.getDAO("BLRFileDAO");				
	
			discountChargeRate = new BigDecimal((((HashMap)client.get(0)).get("N_DCR")).toString());
			
			System.out.println("--->>> CLIENT SIZE: "+client.size());
			System.out.println("--->>> CLIENT SIZE: "+(((HashMap)client.get(0)).get("N_DCR")).toString());
			
			for(int cnt=0;cnt<records.size();cnt++)
			{
				newRecordsMap = new HashMap();
				newRecordsMap = ServiceUtility.removeNulls(((HashMap)records.get(cnt)));
				newRecordsMap.put("C_BLRTYPECODE", receiptsHeaderForm.get("C_CLNTCODE").toString());
		        
		        
		        if(newRecordsMap.get("N_OPAMT")!=null){
		        	nOPAmount = new BigDecimal(newRecordsMap.get("N_OPAMT").toString());
		        }else{
		        	nOPAmount = new BigDecimal("0");
		        }
		        
		        System.out.println("--->>> nOPAmount: "+nOPAmount);
		        
		        if(newRecordsMap.get("N_AMOUNT")!=null){
		        	nAmount = new BigDecimal(newRecordsMap.get("N_AMOUNT").toString());
		        }else{
		        	nAmount = new BigDecimal("0");
		        }

		        System.out.println("--->>> nAmount: "+nAmount);

		        if(nAmount.compareTo(nOPAmount)>=0.00){
		        	nAmount = nAmount.subtract(nOPAmount); 
		        }else{
		        	nAmount = new BigDecimal("0");
		        }
		        
		        System.out.println("--->>> nAmount: "+nAmount);
		        	
		        if(newRecordsMap.get("N_CASHDELAY")!=null){
		        	delay = new BigDecimal(newRecordsMap.get("N_CASHDELAY").toString());
		        }else{
		        	delay = new BigDecimal("0");
		        }
		        
				currency=nAmount.doubleValue();
				
				System.out.println("--->>> currency: "+currency);
				 
		        currencyNAmount=currencyFormatter.format(currency);
		        
		        System.out.println("--->>> currency: "+currencyNAmount);
		        
				currencyNAmount = currencyNAmount.substring(0,0)+currencyNAmount.substring(1);
				
				System.out.println("--->>> currencyNAmount: "+currencyNAmount);
				
				newRecordsMap.put("N_AMOUNT",currencyNAmount);
				
				for(int cntInner=1;cntInner<=5;cntInner++)
				{
					strBLR = "D_TRANSACTIONDATE"+cntInner;
					newRecordsMap.put(strBLR,newRecordsMap.get("D_TRANSACTIONDATE").toString());
					
					blr = blrFileDAO.searchDiscountChargeBLRFile(newRecordsMap);
					System.out.println("--->>> BLR SIZE: "+blr.size());
					
					newRecordsMap.remove(strBLR);
					
					if(blr.size()>0){
						System.out.println("-->>> BLR: "+cntInner);
						if(cntInner == 1){clientBLR = new BigDecimal(((HashMap)blr.get(0)).get("N_BLR1").toString());}
						if(cntInner == 2){clientBLR = new BigDecimal(((HashMap)blr.get(0)).get("N_BLR2").toString());}
						if(cntInner == 3){clientBLR = new BigDecimal(((HashMap)blr.get(0)).get("N_BLR3").toString());}
						if(cntInner == 4){clientBLR = new BigDecimal(((HashMap)blr.get(0)).get("N_BLR4").toString());}
						if(cntInner == 5){clientBLR = new BigDecimal(((HashMap)blr.get(0)).get("N_BLR5").toString());}
						break;
					}
					
				}
				
				
				try{
					
					clientBLR = clientBLR.divide(new BigDecimal("100"),6,BigDecimal.ROUND_HALF_UP);
					discountChargeRate = new BigDecimal((((HashMap)client.get(0)).get("N_DCR")).toString());
					discountChargeRate = discountChargeRate.divide(new BigDecimal("100"),6,BigDecimal.ROUND_HALF_UP);
						
						
					System.out.println("-->>> Amount: "+nAmount.toPlainString());
					System.out.println("-->>> Client-BLR: "+clientBLR.toPlainString());
					System.out.println("-->>> Discount Charge Rate: "+discountChargeRate.toPlainString());
					System.out.println("-->>> 360: "+consThreeSixty.toPlainString());
					System.out.println("-->>> delay: "+delay.toPlainString());
					
					total1 = (nAmount.multiply((clientBLR.add(discountChargeRate))));
					
					total2 =  (total1.divide(consThreeSixty,2,BigDecimal.ROUND_HALF_UP));
					
					total3 = (total2.multiply(delay));
					
					//total3 =  (total1.divide(total2,2,BigDecimal.ROUND_HALF_UP));

					
					//System.out.println("-->>> total1: "+total1.toPlainString());
					//System.out.println("-->>> total2: "+total2.toPlainString());
					//System.out.println("-->>> total3: "+total3.toPlainString());
					
					if(total3.intValue() >= 1){
						totalCharge = totalCharge.add(total3);
					}
					
					
					
					newRecordsMap.put("CHARGE", total3);
					
					System.out.println("--->>> total3: "+total3);
					System.out.println("--->>> total3: "+Double.parseDouble(newRecordsMap.get("CHARGE").toString()));
					
					if(total3.intValue() >= 1){
						System.out.println("-->>> TRUE ...");
						newRecordsList.add(newRecordsMap);
					}
					
				}catch(Throwable x){x.printStackTrace();}

			}	
			
				newRecordsMap = new HashMap();
				newRecordsMap.put("C_CUSTCODE","");
				newRecordsMap.put("D_TRANSACTIONDATE","");
				newRecordsMap.put("N_REFNO","");
				newRecordsMap.put("N_AMOUNT","");
				newRecordsMap.put("N_CASHDELAY","Total: ");
				
				if(totalCharge.intValue() >= 1){
					newRecordsMap.put("CHARGE", totalCharge.toPlainString());
				}else{
					newRecordsMap.put("CHARGE","");
					newRecordsMap.put("C_CUSTNAME", "No Records Found ...");
				}
				
				newRecordsList.add(newRecordsMap);
			
			
			
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
						
			System.out.println("--->> totalCharge: "+ totalCharge.toPlainString());
			System.out.println("--->> searchDiscountChargeReceiptsDetail RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(newRecordsList, ((String)receiptsHeaderForm.get("records")),((String)receiptsHeaderForm.get("page")),""+newRecordsList.size());
				jsondata.put("totalCharge", totalCharge.toPlainString());
				//jsondata.put("returnDataDetails", newRecordsList);
			}else{
				newRecordsMap = new HashMap();
				newRecordsList = new ArrayList();
				newRecordsMap.put("C_CUSTNAME", "No Records Found ...");
				newRecordsList.add(newRecordsMap);
				jsondata = JQGridJSONFormatter.formatDataToJSON(newRecordsList, "","","");
				jsondata.put("status","searchScheduleReceiptsHeader Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
	public List searchReceiptsForClearing(Date processingDate, String branchCode){		
		StringBuilder strRefNo = new StringBuilder();
		ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		
		Map map = new HashMap();
		map.put("C_BRANCHCODE", branchCode);
		map.put("C_STATUS", "(1,4)");
		map.put("D_CLEARINGDATE", processingDate);
		map.put("B_CLEARED", "0");
		
		List lReceipts = receiptsHeaderDAO.searchReceiptsForClearing(map);
		
		return lReceipts;
	}
	
	public boolean updateReceiptsStatusByBatch(String c_Status, String n_RefNo) {
		
		boolean updateFlag;
		Map newData = new HashMap();
		Map receiptsHeaderForm = new HashMap();
		ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		
		updateFlag = receiptsHeaderDAO.updateReceiptsStatusByBatch(c_Status,n_RefNo);
		
		if(updateFlag){
		
			try{
				receiptsHeaderForm.put("C_STATUS", c_Status);
				receiptsHeaderForm.put("N_REFNO", n_RefNo);
				
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(receiptsHeaderForm);
				//ReceiptsHeader rcpth = new ReceiptsHeader(newData);
				//as.addAudit(newData.get("c_UserID").toString(),"U","RECEIPTSHDR",rcpth.toString());
	
			}catch(Throwable x){
				x.printStackTrace();
			}
			
		}
		
		return updateFlag; 
	}
	
	public boolean updateBClearedByBatch(String b_Cleared, String n_RefNo) {
		
		boolean updateFlag;
		Map newData = new HashMap();
		Map receiptsHeaderForm = new HashMap();
		ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		
		updateFlag = receiptsHeaderDAO.updateBClearedByBatch(b_Cleared,n_RefNo);
		
		if(updateFlag){
		
			try{
				receiptsHeaderForm.put("B_CLEARED", b_Cleared);
				receiptsHeaderForm.put("N_REFNO", n_RefNo);
				
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(receiptsHeaderForm);
				//ReceiptsHeader rcpth = new ReceiptsHeader(newData);
				//as.addAudit(newData.get("c_UserID").toString(),"U","RECEIPTSHDR",rcpth.toString());
	
			}catch(Throwable x){
				x.printStackTrace();
			}
			
		}
		
		return updateFlag; 
	}
	
	public Map updateReceiptsTotalInvAmount(Map m) {
		Map jsonData = new HashMap();
		boolean success = false;
		
		log.info("updateReceiptsTotalInvAmount");				
		ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		m.put("N_OPAMT", Double.parseDouble(m.get("N_OPAMT").toString().replaceAll(",", "")));
		success = receiptsHeaderDAO.updateReceiptsTotalInvAmount(m);
		double totalInvoiceAmount = m.get("N_TOTINVAMT") != null ? Double.parseDouble(m.get("N_TOTINVAMT").toString().replaceAll(",", "")) : 0;
		double receiptAmount = m.get("N_AMOUNT") != null ? Double.parseDouble(m.get("N_AMOUNT").toString().replaceAll(",", "")) : 0;
		double opAmount = m.get("N_OPAMT") != null ? Double.parseDouble(m.get("N_OPAMT").toString().replaceAll(",", "")) : 0;
		String receiptType = m.get("C_RECEIPTTYPE").toString().trim();
		String receiptTypeVal = receiptType;
		String cd = m.get("CD").toString().trim(); 
		String clientCode = m.get("C_CLNTCODE") != null ? m.get("C_CLNTCODE").toString() : null;
		String custCode = m.get("C_CUSTCODE") != null ? m.get("C_CUSTCODE").toString() : null;
		
		ServiceUtility.viewUserParameters(m);
		
		log.info("CD: " + cd);
		if (receiptType.equals("1") && (cd.equals("0.0") || cd.equals("0") )) {
			receiptType = "1z";
		}
		else if (receiptType.equals("1") && (cd.equals("0.0") || cd.equals("0") ) && totalInvoiceAmount == 0 && opAmount > 0) {
			receiptType = "1zb";
		}
		else if (receiptType.equals("1") && totalInvoiceAmount == 0 && opAmount > 0) {
			receiptType = "1b";
		}
		//update Client Transaction Amount
		Map receiptsForm = new HashMap();
		receiptsForm.put("C_CLNTCODE", m.get("C_CLNTCODE").toString() + "");		
		if (totalInvoiceAmount == 0 && opAmount > 0) {
			receiptsForm.put("N_CHECKAMOUNT", opAmount + "");
			receiptsForm.put("N_OPAMT", opAmount + "");
		}
		else {
			receiptsForm.put("N_CHECKAMOUNT", receiptAmount + "");
			receiptsForm.put("N_OPAMT", opAmount + "");
			receiptsForm.put("N_TOTINVAMT", totalInvoiceAmount + "");
			
		}	
		receiptsForm.put("C_RECEIPTTYPE", receiptType);
		receiptsForm.put("C_USERID", m.get("USERID").toString());
		
		log.info("updateClientTransactionAmount");
		boolean result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
				
		
		if (success) {
			CCLinkService cclinkSvc = CCLinkService.getInstance();
			ClientService cService = ClientService.getInstance();
			if (receiptTypeVal.equalsIgnoreCase("1") || receiptTypeVal.equalsIgnoreCase("2")) {
				if (totalInvoiceAmount > 0 && totalInvoiceAmount < receiptAmount) {				
					cclinkSvc.updateRunningBalance(clientCode, custCode, totalInvoiceAmount);
					cService.updateIneligibleRec(clientCode, totalInvoiceAmount);
				}
				else if (totalInvoiceAmount > 0 && !(totalInvoiceAmount < receiptAmount)) {
					cclinkSvc.updateRunningBalance(clientCode, custCode, receiptAmount);
					cService.updateIneligibleRec(clientCode, receiptAmount);
				}
			}			
			jsonData.put("status", "Updating of Receipts Total Invoice Amt Successful.");
		}
		else {
			jsonData.put("status","Updating of Receipts Total Invoice Amt Failed. ");
		}
		return jsonData;
	}	
		
	public Map updateReceiptsTotalInvAmount2(Map m) {
		Map jsonData = new HashMap();
		boolean success = false;
		
		ServiceUtility.viewUserParameters(m);
		
		log.info("updateReceiptsTotalInvAmount");				
		ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		m.put("N_OPAMT", Double.parseDouble(m.get("N_OPAMT").toString().replaceAll(",", "")));
		success = receiptsHeaderDAO.updateReceiptsTotalInvAmount(m);
		
		double oldInvoiceAmount = m.get("N_OLDINVAMT") != null ? Double.parseDouble(m.get("N_OLDINVAMT").toString().trim().replaceAll(",", "")) : 0;
		double totalInvoiceAmount = m.get("N_TOTINVAMT") != null ? Double.parseDouble(m.get("N_TOTINVAMT").toString().replaceAll(",", "")) : 0;
		
		totalInvoiceAmount = totalInvoiceAmount - oldInvoiceAmount;
		
		double receiptAmount = m.get("N_AMOUNT") != null ? Double.parseDouble(m.get("N_AMOUNT").toString().replaceAll(",", "")) : 0;
		double opAmount = m.get("N_OPAMT") != null ? Double.parseDouble(m.get("N_OPAMT").toString().replaceAll(",", "")) : 0;
		String receiptType = m.get("C_RECEIPTTYPE").toString().trim();
		String receiptTypeVal = receiptType;
		String cd = m.get("CD").toString().trim(); 
		String clientCode = m.get("C_CLNTCODE") != null ? m.get("C_CLNTCODE").toString() : null;
		String custCode = m.get("C_CUSTCODE") != null ? m.get("C_CUSTCODE").toString() : null;
				
		
		if (receiptType.equals("1") && (cd.equals("0.0") || cd.equals("0") )) {
			receiptType = "1z";
		}
		else if (receiptType.equals("1") && (cd.equals("0.0") || cd.equals("0") ) && totalInvoiceAmount == 0 && opAmount > 0) {
			receiptType = "1zb";
		}
		else if (receiptType.equals("1") && totalInvoiceAmount == 0 && opAmount > 0) {
			receiptType = "1b";
		}
		//update Client Transaction Amount
		
		if (receiptType.equals("3")) {
			
			double checkAmount = receiptAmount - opAmount;
			log.info("receiptAmount: " + checkAmount);
						
			Map receiptsForm = new HashMap();
			receiptsForm.put("C_CLNTCODE", m.get("C_CLNTCODE").toString() + "");	
			receiptsForm.put("C_USERID", m.get("USERID").toString());
			receiptsForm.put("N_CHECKAMOUNT", checkAmount + "");
			receiptsForm.put("N_OPAMT", opAmount + "");
			
			boolean result = ClientService.getInstance().updateClientTransAmountUpdateType3(receiptsForm);			
		}
		else {
			Map receiptsForm = new HashMap();
			receiptsForm.put("C_CLNTCODE", m.get("C_CLNTCODE").toString() + "");		
			if (totalInvoiceAmount == 0 && opAmount > 0) {
				receiptsForm.put("N_CHECKAMOUNT", opAmount + "");			
			}
			else {
				log.info("totalInvoiceAMount: " + totalInvoiceAmount);
				receiptsForm.put("N_CHECKAMOUNT", receiptAmount + "");
				receiptsForm.put("N_OPAMT", opAmount + "");
				receiptsForm.put("N_TOTINVAMT", totalInvoiceAmount + "");
			}	
			receiptsForm.put("C_RECEIPTTYPE", receiptType);
			receiptsForm.put("C_USERID", m.get("USERID").toString());
			receiptsForm.put("N_OLDOPAMT", receiptAmount);
			
			log.info("updateClientTransactionAmount");
			boolean result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
				
			log.info("result: >>>>>>>>>>>" + result);
			//if (result) {
				CCLinkService cclinkSvc = CCLinkService.getInstance();
				ClientService cService = ClientService.getInstance();
				if (receiptTypeVal.equalsIgnoreCase("1") || receiptTypeVal.equalsIgnoreCase("2")) {
					if (totalInvoiceAmount > 0 && totalInvoiceAmount < receiptAmount) {				
						cclinkSvc.updateRunningBalance(clientCode, custCode, totalInvoiceAmount);
						cService.updateIneligibleRec(clientCode, totalInvoiceAmount);
					}
					else if (totalInvoiceAmount > 0 && !(totalInvoiceAmount < receiptAmount)) {
						cclinkSvc.updateRunningBalance(clientCode, custCode, receiptAmount);
						cService.updateIneligibleRec(clientCode, receiptAmount);
				}
				else {
					if (opAmount > 0) {
						cclinkSvc.updateRunningBalance(clientCode, custCode, (receiptAmount - opAmount));
						cService.updateIneligibleRec(clientCode, (receiptAmount - opAmount));
					}
				}
			}
		}
		jsonData.put("status", "Updating of Receipts Total Invoice Amt Successful.");
		
		//}
		//else {
		//	jsonData.put("status","Updating of Receipts Total Invoice Amt Failed. ");
		//}
		return jsonData;
	}
	
	public Map updateClearingAndRunningBalance(Map m) {
		log.info("update Clearing and Running Balance.... " );
		Map jsonData = new HashMap();
		boolean success = false;
		
		ServiceUtility.viewUserParameters(m);
		
		ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		m.put("N_OPAMT", Double.parseDouble(m.get("N_OPAMT").toString().replaceAll(",", "")));
		success = receiptsHeaderDAO.updateReceiptsTotalInvAmount(m);
		success = receiptsHeaderDAO.updateReceiptsAmount(m);	//rdc04232010
		double totalInvoiceAmount = m.get("N_TOTINVAMT") != null ? Double.parseDouble(m.get("N_TOTINVAMT").toString().replaceAll(",", "")) : 0;
		double receiptAmount = m.get("N_AMOUNT") != null ? Double.parseDouble(m.get("N_AMOUNT").toString().replaceAll(",", "")) : 0;
		double opAmount = m.get("N_OPAMT") != null ? Double.parseDouble(m.get("N_OPAMT").toString().replaceAll(",", "")) : 0;
		double oldInvoiceAmount = m.get("N_OLDINVAMT") != null ? Double.parseDouble(m.get("N_OLDINVAMT").toString().replaceAll(",", "")) : 0;
		String receiptType = m.get("C_RECEIPTTYPE").toString().trim();
		String receiptTypeVal = receiptType;
		String cd = m.get("CD").toString().trim(); 
		String clientCode = m.get("C_CLNTCODE") != null ? m.get("C_CLNTCODE").toString() : null;
		String custCode = m.get("C_CUSTCODE") != null ? m.get("C_CUSTCODE").toString() : null;
		String nRefNo = m.get("N_REFNO") != null ? m.get("N_REFNO").toString() : null;
		String userID = m.get("USERID").toString();
		
		log.info("totalInvoiceAmount: " + totalInvoiceAmount);
		log.info("oldInvoiceAmount: " + oldInvoiceAmount);
		log.info("receiptAmount: " + receiptAmount);
		
		double newInvAmount = 0;
		if (receiptAmount < totalInvoiceAmount) {
			newInvAmount = receiptAmount;
		}
		else {
			newInvAmount = totalInvoiceAmount - oldInvoiceAmount;
		}
		
		//update Client Transaction Amount
		Map receiptsForm = new HashMap();
		receiptsForm.put("C_CLNTCODE", m.get("C_CLNTCODE").toString() + "");		
		if (totalInvoiceAmount == 0 && opAmount > 0) {
			receiptsForm.put("N_CHECKAMOUNT", opAmount + "");			
		}
		else {
			receiptsForm.put("N_CHECKAMOUNT", receiptAmount + "");
			receiptsForm.put("N_OPAMT", opAmount + "");
			receiptsForm.put("N_TOTINVAMT", totalInvoiceAmount + "");			
		}	
		receiptsForm.put("C_RECEIPTTYPE", "5");
		receiptsForm.put("C_RECEIPTTYPEVAL", receiptTypeVal);
		receiptsForm.put("C_USERID", m.get("USERID").toString());
		receiptsForm.put("forReverse", receiptAmount);
		receiptsForm.put("forReceivables", newInvAmount);
		
		log.info("updateClientTransactionAmount");
		//check if cash delay s zero; if it is, no need to update n_clearingamt
		
		List l = receiptsHeaderDAO.searchCDByNRefNo(Integer.parseInt(nRefNo));
		Map mapCD = (Map) l.get(0);
		cd = mapCD.get("N_CASHDELAY").toString();
		double dCD = Double.parseDouble(cd);
		log.info("cd:" + cd);
		if (dCD > 0) {
			boolean result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
		}
		else {
			receiptsForm.put("C_RECEIPTTYPEVAL", "1z");
			boolean result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
		}
				
		
		if (success) {
			CCLinkService cclinkSvc = CCLinkService.getInstance();
			ClientService cService = ClientService.getInstance();
			
			//rdc 07022010 this to update cclink running balance for all types of receipts
			//if (receiptTypeVal.equalsIgnoreCase("1") || receiptTypeVal.equalsIgnoreCase("2")) {
				if (totalInvoiceAmount > 0 && totalInvoiceAmount < receiptAmount) {				
					cclinkSvc.updateRunningBalance(clientCode, custCode, totalInvoiceAmount, userID);
					//cService.updateIneligibleRec(clientCode, totalInvoiceAmount, userID);					
					
				}
				else if (totalInvoiceAmount > 0 && !(totalInvoiceAmount < receiptAmount)) {
					cclinkSvc.updateRunningBalance(clientCode, custCode, receiptAmount, userID);
					//cService.updateIneligibleRec(clientCode, receiptAmount, userID);
				}
		//	}	
			
			//update n_ineligiblerec in cclink/client
			ServiceUtility.viewUserParameters(m);
			CCLinkDAO cclinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			String ineligible1 = cclinkDAO.searchIneligibleByClient(m)+ "";
			String clientIneligible = clientDAO.searchIneligibleRecByClient(clientCode)+"";
						
			boolean success3 = receiptsHeaderDAO.updateReceiptsIneligible(m);
			String ineligible2 = cclinkDAO.searchIneligibleByClient(m)+ "";
			double ine1and2 = Money.doRoundOff(Double.parseDouble(ineligible1)-Double.parseDouble(ineligible2));
			m.put("N_INELIGIBLEREC", Double.parseDouble(clientIneligible)-ine1and2);
			
			boolean updateclientIne = clientDAO.updateIneligibleRecByClient(m);
			if (success3 && updateclientIne) {
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "CCLINK", "N_INELIGIBLEREC-"+ine1and2);
				as.addAudit(userID, "U", "CLIENT", "N_INELIGIBLEREC-"+ine1and2);
			}
			log.info("ineligible1:"+ineligible1);
			log.info("ineligible2:"+ineligible2);
			log.info("ine1and2:"+ine1and2);
			log.info("clientIneligible:"+clientIneligible);
			log.info("updateReceiptsIneligible:"+success3);
			log.info("updateclientIne:"+updateclientIne);
			//end-update n_ineligiblerec in cclink/client
			
			jsonData.put("status", "Updating of Receipts Total Invoice Amt Successful.");
		}
		else {
			jsonData.put("status","Updating of Receipts Total Invoice Amt Failed. ");
		}
		return jsonData;
	}
	
	public Map searchReceiptsByBranch(Map m) {
		Map jsonData = new HashMap();
		String totalRecords = null;
		try {
			ServiceUtility.viewUserParameters(m);
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			
			totalRecords = receiptsHeaderDAO.getTotalReceiptsHdrByBranch(m);			
			m = ServiceUtility.addPaging(m,totalRecords);			
			List lResult = receiptsHeaderDAO.searchReceiptsByBranch(m);
			ServiceUtility.viewUserParameters(m);
			log.info("--->> searchReceiptsByBranch RECORD-SIZE: "+lResult.size());
			if((lResult!=null) && (lResult.size()>0)){
				jsonData = JQGridJSONFormatter.formatDataToJSON(lResult, ((String)m.get("records")),((String)m.get("page")),((String)m.get("total")));
			}else{				
				jsonData.put("status","Search Receipts Failed ... ");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status","Search Receipts Failed ... ");
			return jsonData;
		}
		return jsonData;
	}
	
	public Map cancelReceipts(Map receiptsHeaderForm) {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map jsonData = new HashMap();
		Map newData = new HashMap();
		ServiceUtility.viewUserParameters(receiptsHeaderForm);		
		double totalAmount = 0, cnAmountTotal = 0, totalBalance = 0;
		String invNos = "";
		String cnRefNos = "";
		boolean result = false;
		
		try {
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			
			//update ReceiptsHeader
			int n_RefNo = Integer.parseInt(receiptsHeaderForm.get("N_REFNO").toString());
			String status = "3";			
			Date dateBounced = DateHelper.parse(DateHelper.format(date.newDate())); //before: new date()
			String amount = receiptsHeaderForm.get("N_AMOUNT").toString();
			amount = amount.replaceAll(",", "");
			String clntCode = receiptsHeaderForm.get("C_CLNTCODE").toString();
			String custCode = receiptsHeaderForm.get("C_CUSTCODE").toString();
			String userID = receiptsHeaderForm.get("C_USERID").toString();
			String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPE").toString().trim();
			String receiptStatus = receiptsHeaderForm.get("C_STATUS").toString().trim();
			if (receiptType.equals("1") && receiptStatus.equals("2")) {
				jsonData.put("status", "Cannot delete check receipts with Cleared status. Please proceed to Dishonored Checks.");
				return jsonData;
			}
			
			this.updateReceiptsBouncedCheck(n_RefNo, status, dateBounced,userID);
			
			//get ReceiptDetails
			ReceiptsDtlService rd = ReceiptsDtlService.getInstance();
			List lReceiptDetails = rd.searchReceiptsDetailByCodeList(n_RefNo);
			
			for (int i=0; i< lReceiptDetails.size(); i++) {
				Map m = new HashMap();
				m = (Map) lReceiptDetails.get(i);
				String invNo = m.get("N_INVNO").toString();
				double nReceiptAmount = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
				log.info("receiptAmt:" + nReceiptAmount);
				totalBalance = totalBalance + nReceiptAmount;
				invNos = invNo + "," + invNos;				
			}
			
			log.info("totalBalance:" + totalBalance);
			//updateClient receivables (Receipts)						
			if (invNos != null && invNos.trim().length() > 0) {				
				
				ArrayList lInvoices = new ArrayList();
				ArrayList lAmount = new ArrayList();
				
				invNos = invNos.substring(0, invNos.length() - 1);
				totalAmount = Double.parseDouble(amount);
									
				Map receiptsForm = new HashMap();
				receiptsForm.put("C_CLNTCODE", clntCode);
				receiptsForm.put("N_CHECKAMOUNT", "-" + totalAmount + "");
				receiptsForm.put("C_RECEIPTTYPE", receiptType);
				receiptsForm.put("C_USERID", userID);
				receiptsForm.put("DESCRIPTION", "Deleted Receipts:" + n_RefNo);
				receiptsForm.put("N_TOTINVAMT", totalBalance);
				receiptsForm.put("N_OPAMT", (Double.parseDouble(amount) - totalBalance) + "");
				receiptsForm.put("OPERATION", "DELETE");
				
				log.info(">>>>>>Cancel Receipt - Receipt Type:" + receiptType);
				if (receiptType.equalsIgnoreCase("2") || receiptType.equalsIgnoreCase("3") || receiptType.equalsIgnoreCase("4")) {
					result = ClientService.getInstance().updateClientTransAmountCancelType2(receiptsForm);
					//rdc07282010
					//rdc 09132010
					//if (receiptType.equalsIgnoreCase("4")) {
//					if (receiptType.equalsIgnoreCase("4")|| receiptType.equalsIgnoreCase("3")) {
//						ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
//						boolean success2 = rHeaderDAO.updateReceiptsStatusByCARefund("2",null,n_RefNo+"");
//						log.info("cancel - updateReceiptsStatusByCARefund : " + success2);
//						if (success2) {
//							AuditService as = AuditService.getInstance();				
//							as.addAudit(receiptsHeaderForm.get("C_USERID").toString(), "U", "RECEIPTSHDR", "C_STATUS=2,N_REFUNDREFNO="+n_RefNo+"");
//						}
//					}
					Map map = new HashMap();
					map.put("C_STATUS", "2");
					map.put("C_APPROVER", userID);
					map.put("N_REFNO", receiptsHeaderForm.get("N_REFFORCANCEL").toString());
					log.info("N_REFFORCANCEL:"+receiptsHeaderForm.get("N_REFFORCANCEL").toString());
					if(receiptType.trim().equalsIgnoreCase("4")) {
						RefundDAO refundDAO = (RefundDAO)Persistence.getDAO("RefundDAO");
						boolean success4 = refundDAO.updateRefundStatus(map);
						log.info("success4:"+success4);
						if (success4) {
							AuditService as = AuditService.getInstance();				
							as.addAudit(receiptsHeaderForm.get("C_USERID").toString(), "U", "REFUND", "C_STATUS=2,N_REFNO="+receiptsHeaderForm.get("N_REFFORCANCEL").toString()+"");	
						}
					} else if(receiptType.trim().equalsIgnoreCase("3")) {
						AdvancesDAO advancesDAO = (AdvancesDAO)Persistence.getDAO("AdvancesDAO");
						boolean success3 = advancesDAO.updateReceiptAdvanceStatus(map);
						log.info("success3:"+success3);
						if (success3) {
							AuditService as = AuditService.getInstance();				
							as.addAudit(receiptsHeaderForm.get("C_USERID").toString(), "U", "ADVANCES", "C_STATUS=2,N_REFNO="+receiptsHeaderForm.get("N_REFFORCANCEL").toString()+"");	
						}
					}
				}
				else {
					result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
				}
				
				//rdc05272010 if (receiptType.equalsIgnoreCase("1") || receiptType.equalsIgnoreCase("2")) {				
					CCLinkService ccLinkSvc = CCLinkService.getInstance();
					ccLinkSvc.updateRunningBalance(clntCode, custCode, totalBalance * -1, userID);
					
					ClientService cService = ClientService.getInstance();
					//cService.updateIneligibleRec(clntCode, totalBalance * -1, userID);
				//}
			}
			else {
				Map receiptsForm = new HashMap();
				receiptsForm.put("C_CLNTCODE", clntCode);
				receiptsForm.put("N_CHECKAMOUNT", amount + "");
				receiptsForm.put("C_RECEIPTTYPE", receiptType);
				receiptsForm.put("C_USERID", userID);
				receiptsForm.put("DESCRIPTION", "Deleted Receipts:" + n_RefNo);				
				receiptsForm.put("OPERATION", "DELETE");
				result = ClientService.getInstance().updateClientTransAmountForNoInv(receiptsForm);
			}
			
			//cancel corresponding CN
			//update Client receivables and reserves (Credit Note)
			List lCN = CreditNoteService.getInstance().searchCreditNoteByReceiptNoList(n_RefNo + "");
			for (int i=0; i< lCN.size(); i++) {
				Map m = new HashMap();
				m = (Map) lCN.get(i);
				String cnRefNo = m.get("N_REFNO").toString();
				
				//double cnAmount = Double.parseDouble(m.get("N_AMOUNT").toString());
				String cnStatus = m.get("C_STATUS").toString();
				double cnAmount = 0;
				if (!cnStatus.trim().equalsIgnoreCase("Cancelled")) {
					cnAmount = Double.parseDouble(m.get("N_AMOUNT").toString());	//rdc04292010
				}	
				cnRefNos = cnRefNo + "," + cnRefNos;
				cnAmountTotal = cnAmount + cnAmountTotal;		
				log.info("CNStatus:" +m.get("C_STATUS").toString() + ", cnAmountTotal:" + cnAmountTotal);
						
			}
			
			if (cnRefNos != null && cnRefNos.trim().length() > 0) {			
								
				cnRefNos = cnRefNos.substring(0, cnRefNos.length() - 1);
				cnRefNos = "(" + cnRefNos + ")";
										
				Map creditNoteForm = new HashMap();
				creditNoteForm.put("C_STATUS", "3");
				creditNoteForm.put("N_REFNO", cnRefNos);
				creditNoteForm.put("C_CLNTCODE", clntCode);
				creditNoteForm.put("N_CHECKAMOUNT", "-" + cnAmountTotal);
				creditNoteForm.put("C_RECEIPTTYPE", "3");
				creditNoteForm.put("C_USERID", userID);
											
				CreditNoteService cnService = CreditNoteService.getInstance();
				cnService.updateCreditNoteStatusByBatch(creditNoteForm);
				
				//rdc06162010 update running balance in cclink
				boolean result2 = CCLinkService.getInstance().cancelRunningBalance(clntCode, custCode, cnAmountTotal, userID);
				log.info("Cancel CN updateRunningBalance: "+ result2);
			}
			
			
			//update Invoice Status to 3 and fullyPaidDate to null
			if (invNos.trim().length() > 0) {
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			
				//invoices = "(" + invoices + ")";
				invNos = "(" + invNos + ")";
				boolean updateInvoice = invoiceDAO.updateInvoiceStatusAndDateByCode(invNos, "3", null);
				
				if(updateInvoice){
					try{
						Map map = new HashMap();
						map.put("invoices", invNos);		
						map.put("C_STATUS", "3");
						map.put("D_FULLYPAIDDATE", "");
						
						AuditService as = AuditService.getInstance();
						newData = ServiceUtility.removeNulls(map);
						Invoice invoice = new Invoice(newData);
						as.addAudit(userID,"U","INVOICE",invoice.toString());
			
					}catch(Throwable x){
						x.printStackTrace();
					}
				}
				
				
			}
			
			//CANCEL SUBHEADER ENTRY
			receiptsHeaderForm.put("C_TRANSACTIONTYPE", "P");
			receiptsHeaderForm.put("N_REFNO", n_RefNo);
			SubHeaderService SHS =  SubHeaderService.getInstance();
			SHS.cancelSubHeaderEntry(receiptsHeaderForm);
			
			//CCLinkService.getInstance().updateRunningBalance(clntCode, custCode, totalBalance);
			receiptsHeaderForm.put("N_AMOUNT", (Double) totalBalance);
			receiptsHeaderForm.put("N_INVNO", invNos);
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");

			//update n_ineligiblerec in cclink/client
			CCLinkDAO cclinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			String ineligible1 = cclinkDAO.searchIneligibleByClient(receiptsHeaderForm)+ "";
			String clientIneligible = clientDAO.searchIneligibleRecByClient(clntCode)+"";
			
			boolean success3 = rHeaderDAO.updateReceiptsIneligible(receiptsHeaderForm);
			String ineligible2 = cclinkDAO.searchIneligibleByClient(receiptsHeaderForm)+ "";
			double ine1and2 = Money.doRoundOff(Double.parseDouble(ineligible2)-Double.parseDouble(ineligible1));
			receiptsHeaderForm.put("N_INELIGIBLEREC", Double.parseDouble(clientIneligible)+ine1and2);
			
			boolean updateclientIne = clientDAO.updateIneligibleRecByClient(receiptsHeaderForm);
			if (success3 && updateclientIne){
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "CCLINK", "C_CLNTCODE=" +receiptsHeaderForm.get("C_CLNTCODE").toString() + ", C_CUSTCODE=" +receiptsHeaderForm.get("C_CUSTCODE").toString() +", N_INELIGIBLEREC+"+receiptsHeaderForm.get("N_AMOUNT").toString());
				as.addAudit(userID, "U", "CLIENT", "N_INELIGIBLEREC+"+ine1and2);
			}
			log.info("ineligible1:"+ineligible1);
			log.info("ineligible2:"+ineligible2);
			log.info("clientIneligible:"+clientIneligible);
			log.info("ine1and2:"+ine1and2);
			log.info("updateReceiptsCancelIneligible:"+success3);
			log.info("updateclientIne:"+updateclientIne);
			//end-update n_ineligiblerec in cclink/client
		
			jsonData.put("status", "Delete Receipts Successful.");
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status", "Delete Receipts Failed...");
			return jsonData;
		}
		return jsonData;
	}
	
	public Map updateReceiptsHeaderType2(Map receiptsHeaderForm) {
		Map jsonData = new HashMap();
		double collectedAmount = 0;
		double invoiceAmount = 0;
		double invAmount = 0;
		int refNo = 0;
		double n_amount = 0, n_origAmount = 0;
		double balance = 0, totalBalance = 0;
		double overAllCollected = 0;
		double newCollected = 0;
		
		try {
			log.info("UpdateReceiptsHeaderType2::");
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			
			receiptsHeaderForm.put("D_TRANSACTIONDATE", receiptsHeaderForm.get("D_TRANSDATE2").toString());
			
			receiptsHeaderForm.put("N_AMOUNT", receiptsHeaderForm.get("N_AMOUNT2"));
			receiptsHeaderForm.put("N_ORIGAMOUNT", receiptsHeaderForm.get("N_ORIGAMOUNT2"));
			receiptsHeaderForm.put("N_REFNO", receiptsHeaderForm.get("N_REFNO2"));
			//receiptsHeaderForm.put("N_EXCHANGERATE", receiptsHeaderForm.get("N_EXCHAGERATE2"));
			receiptsHeaderForm.put("C_CUSTNAME", receiptsHeaderForm.get("C_CUSTNAME2"));
			receiptsHeaderForm.put("D_CHECKDATE", receiptsHeaderForm.get("D_CHECKDATE2"));
			receiptsHeaderForm.put("C_CURRENCYDESC", receiptsHeaderForm.get("C_CURRENCYDESC2"));
			receiptsHeaderForm.put("D_CLEARINGDATE", receiptsHeaderForm.get("D_CLEARINGDATE2"));
			receiptsHeaderForm.put("N_REFUNDDAYS", receiptsHeaderForm.get("N_REFUNDDAYS2"));
			receiptsHeaderForm.put("C_NAME", receiptsHeaderForm.get("C_NAME2"));
			receiptsHeaderForm.put("N_EXCHANGERATE", receiptsHeaderForm.get("N_EXCHANGERATE2"));
			
			receiptsHeaderForm.put("C_STATUS", "2");
			receiptsHeaderForm.put("C_NOOFDAYS", "0");
							
			log.info("N_EXCHANGERATE: " + receiptsHeaderForm.get("N_EXCHANGERATE").toString());
			
			n_amount = receiptsHeaderForm.get("N_AMOUNT") != null && receiptsHeaderForm.get("N_AMOUNT").toString().trim() != "" ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", "").trim()) : 0;
			n_origAmount = receiptsHeaderForm.get("N_ORIGAMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", "").trim()) : 0;
			refNo = Integer.parseInt(receiptsHeaderForm.get("N_REFNO").toString());
			receiptsHeaderForm.put("D_TRANSACTIONDATE", receiptsHeaderForm.get("D_TRANSDATE").toString());
			
			double receiptAmountNew = n_amount;
			
			String sInvAmount = receiptsHeaderForm.get("N_TOTINVAMT") != null ? (receiptsHeaderForm.get("N_TOTINVAMT").toString().trim()) : "";
			//double invAmount = sInvAmount.equals("") ? 0 : Double.parseDouble(receiptsHeaderForm.get("N_TOTINVAMT").toString());
			double oldAmount = receiptsHeaderForm.get("N_AMOUNT_OLD") != null ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT_OLD").toString().replaceAll(",", "").trim()) : 0; 
			String userID = receiptsHeaderForm.get("USERID").toString().trim();
			String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPE") != null ? receiptsHeaderForm.get("C_RECEIPTTYPE").toString().trim() : null;
			
			log.info("receiptType: " + receiptType);
			
			ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			double oldOPAmt = rHeaderDAO.searchReceiptsOPByRefNo(refNo);
			
			receiptsHeaderForm.put("N_AMOUNT", n_amount);
			receiptsHeaderForm.put("N_ORIGAMOUNT", n_origAmount);
						
			if (receiptAmountNew == oldAmount) {
				jsonData = updateReceiptsHeaderExAmount(receiptsHeaderForm);
			}
			else {
				ReceiptsHeader receiptsHeader = ReceiptsHeaderUtility.toObject(receiptsHeaderForm);
				receiptsHeader.setN_RefNo(refNo);
			
				ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			
				Map map = new HashMap();
				map.put("N_REFNO",refNo);
				List lResult = rDetailDAO.searchReceiptsDetailByCode(map);
				
				//get collected Receipt 
				if (lResult != null && lResult.size() > 0) {
					for (int i = 0; i < lResult.size(); i++) {
						Map m = new HashMap();
						m = (Map)lResult.get(i);
						double totalCollected = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
						log.info("totalCollected: " + totalCollected);						
						collectedAmount = totalCollected + collectedAmount;
						double invoiceA = Double.parseDouble(m.get("N_AMTINV").toString());
						invAmount = invAmount + invoiceA;
						
						double collectedAmnt = Double.parseDouble(m.get("totalCollected").toString());
						balance = invoiceA - (collectedAmnt - totalCollected);
						totalBalance = totalBalance + balance;
						log.info("totalBalance:" + totalBalance);
					}					
				}
				log.info("invAmount:" + invAmount);
				log.info("collectedAmount:" + collectedAmount);
							
				double overPayment = n_amount - collectedAmount;
				DecimalFormat df = new DecimalFormat("0.00");
				overPayment = Double.parseDouble(df.format(overPayment));
				log.info("overPayment:" + overPayment);
			
				if (overPayment < 0) {
					overPayment = 0;
				}				
				receiptsHeaderForm.put("N_OPAMT", overPayment);						
				boolean result = receiptsHeaderDAO.updateReceiptsHeader(receiptsHeaderForm);
				
				if (result == true) {	
					AuditService as = AuditService.getInstance();				
					as.addAudit(userID, "U", "RECEIPTSHDR", receiptsHeader.toString());
					
					//update Receipt Detail Amount
					if (lResult != null && lResult.size() > 0) {
						for (int i = 0; i < lResult.size(); i++) {
							Map m = new HashMap();
							m = (Map)lResult.get(i);
																								
							int invNo = Integer.parseInt(m.get("N_INVNO").toString());
							invoiceAmount = Double.parseDouble(m.get("N_AMTINV").toString());	
							
							double collectedAmnt = Double.parseDouble(m.get("totalCollected").toString());
							double totalCollected = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
							balance = invoiceAmount - (collectedAmnt - totalCollected);
							
							double rAmount = n_amount - overPayment; 
							double receiptAmount = ((invoiceAmount - (collectedAmnt - totalCollected)) / totalBalance) * rAmount;
							newCollected = newCollected + receiptAmount;
							
							Map receiptDetailForm = new HashMap();
							receiptDetailForm.put("N_REFNO", refNo);
							receiptDetailForm.put("N_INVNO", invNo);
							receiptDetailForm.put("N_RECEIPTAMT", receiptAmount);
							
							result = rDetailDAO.updateReceiptDetailAmount(receiptDetailForm);
							
							AuditService as1 = AuditService.getInstance();
							StringBuilder str = new StringBuilder();							
							str.append("N_REFNO = ").append(refNo);
							str.append(";N_INVNO = ").append(invNo);
							str.append(";N_RECEIPTAMT = ").append(receiptAmount);
							
							
							as1.addAudit(userID, "U", "RECEIPTDTL", str.toString());
						}
					}	
					
					//update Client Transaction Amount
					Map receiptsForm = new HashMap();			
					receiptsForm.put("C_CLNTCODE", receiptsHeader.getC_ClntCode() + "");
					receiptsForm.put("N_CHECKAMOUNT", newCollected - collectedAmount + "");
					receiptsForm.put("N_TOTINVAMT", totalBalance);
					receiptsForm.put("N_OPAMT", overPayment - oldOPAmt);
					
					receiptsForm.put("C_RECEIPTTYPE", receiptType);
					receiptsForm.put("C_USERID", userID);
					receiptsForm.put("OPERATION", "UPDATE");
					log.info("updateClientTransactionAmount");
					log.info("receiptType: " + receiptType);	
					//rdc 05272010 if (receiptType.equalsIgnoreCase("Direct Credit/Cash")) {
						result = ClientService.getInstance().updateClientTransAmountUpdateType2(receiptsForm);
										
						CCLinkService.getInstance().updateRunningBalance(receiptsHeader.getC_ClntCode() + "", receiptsHeader.getC_CustCode() + "", newCollected - collectedAmount, userID);
						ClientService.getInstance().updateIneligibleRec(receiptsHeader.getC_ClntCode() + "", newCollected - collectedAmount, userID);
					//}
					//else
					if (receiptType.equalsIgnoreCase("Receipts from Advances") || receiptType.equalsIgnoreCase("Receipts from Refunds")) {
						result = ClientService.getInstance().updateClientTransAmountUpdateType3(receiptsForm);
					}
					
					if (result) {
						jsonData.put("status", "Updated Receipts.");
					}
					else {
						jsonData.put("status", "Update of Receipts Detail Failed.");
					}					
				}
				
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status", "Update Receipts Failed.");
		}
		return jsonData;
	}
	
	public Map updateReceiptsHeaderAndDetail(Map receiptsHeaderForm) {
		Map jsonData = new HashMap();
		double collectedAmount = 0;
		double invoiceAmount = 0;
		double invAmount = 0;
		int refNo = 0;
		double n_amount = 0, n_origAmount = 0;
		double balance = 0, totalBalance = 0;
		double overAllCollected = 0;
		double newCollected = 0;
		
		try {
			log.info("UpdateReceiptsHeaderType1::");
			ServiceUtility.viewUserParameters(receiptsHeaderForm);
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
								
			n_amount = receiptsHeaderForm.get("N_AMOUNT") != null && receiptsHeaderForm.get("N_AMOUNT").toString().trim() != "" ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", "").trim()) : 0;
			n_origAmount = receiptsHeaderForm.get("N_ORIGAMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", "").trim()) : 0;
			refNo = Integer.parseInt(receiptsHeaderForm.get("N_REFNO").toString());
			receiptsHeaderForm.put("D_TRANSACTIONDATE", receiptsHeaderForm.get("D_TRANSDATE").toString());
			
			double receiptAmountNew = n_amount;
			
			String sInvAmount = receiptsHeaderForm.get("N_TOTINVAMT") != null ? (receiptsHeaderForm.get("N_TOTINVAMT").toString().trim()) : "";
			//double invAmount = sInvAmount.equals("") ? 0 : Double.parseDouble(receiptsHeaderForm.get("N_TOTINVAMT").toString());
			double oldAmount = receiptsHeaderForm.get("N_AMOUNT_OLD") != null ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT_OLD").toString().replaceAll(",", "").trim()) : 0; 
			String userID = receiptsHeaderForm.get("USERID").toString().trim();
			String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPE") != null ? receiptsHeaderForm.get("C_RECEIPTTYPE").toString().trim() : null;
			
			log.info("receiptType: " + receiptType);
			
			ReceiptsHeaderDAO rHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			double oldOPAmt = rHeaderDAO.searchReceiptsOPByRefNo(refNo);
			
			receiptsHeaderForm.put("N_AMOUNT", n_amount);
			receiptsHeaderForm.put("N_ORIGAMOUNT", n_origAmount);
						
			if (receiptAmountNew == oldAmount) {
				jsonData = updateReceiptsHeaderExAmount(receiptsHeaderForm);
			}
			else {
				ReceiptsHeader receiptsHeader = ReceiptsHeaderUtility.toObject(receiptsHeaderForm);
				receiptsHeader.setN_RefNo(refNo);
			
				ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			
				Map map = new HashMap();
				map.put("N_REFNO",refNo);
				List lResult = rDetailDAO.searchReceiptsDetailByCode(map);
				
				//get collected Receipt 
				if (lResult != null && lResult.size() > 0) {
					for (int i = 0; i < lResult.size(); i++) {
						Map m = new HashMap();
						m = (Map)lResult.get(i);
						double totalCollected = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
						log.info("totalCollected: " + totalCollected);						
						collectedAmount = totalCollected + collectedAmount;
						double invoiceA = Double.parseDouble(m.get("N_AMTINV").toString());
						invAmount = invAmount + invoiceA;
						
						double collectedAmnt = Double.parseDouble(m.get("totalCollected").toString());
						balance = invoiceA - (collectedAmnt - totalCollected);
						totalBalance = totalBalance + balance;
						log.info("totalBalance:" + totalBalance);
					}					
				}
				log.info("invAmount:" + invAmount);
				log.info("collectedAmount:" + collectedAmount);
							
				double overPayment = n_amount - collectedAmount;
				DecimalFormat df = new DecimalFormat("0.00");
				overPayment = Double.parseDouble(df.format(overPayment));
				log.info("overPayment:" + overPayment);
			
				if (overPayment < 0) {
					overPayment = 0;
				}				
				receiptsHeaderForm.put("N_OPAMT", overPayment);						
				boolean result = receiptsHeaderDAO.updateReceiptsHeader(receiptsHeaderForm);
				
				
				if (result == true) {	
					AuditService as = AuditService.getInstance();				
					as.addAudit(userID, "U", "RECEIPTSHDR", receiptsHeader.toString());
					
					//update Receipt Detail Amount
					if (lResult != null && lResult.size() > 0) {
						for (int i = 0; i < lResult.size(); i++) {
							Map m = new HashMap();
							m = (Map)lResult.get(i);
																								
							int invNo = Integer.parseInt(m.get("N_INVNO").toString());
							invoiceAmount = Double.parseDouble(m.get("N_AMTINV").toString());	
							
							double collectedAmnt = Double.parseDouble(m.get("totalCollected").toString());
							double totalCollected = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
							balance = invoiceAmount - (collectedAmnt - totalCollected);
							
							double rAmount = n_amount - overPayment; 
							double receiptAmount = ((invoiceAmount - (collectedAmnt - totalCollected)) / totalBalance) * rAmount;
							newCollected = newCollected + receiptAmount;
							
							Map receiptDetailForm = new HashMap();
							receiptDetailForm.put("N_REFNO", refNo);
							receiptDetailForm.put("N_INVNO", invNo);
							receiptDetailForm.put("N_RECEIPTAMT", receiptAmount);
							
							AuditService as1 = AuditService.getInstance();
							StringBuilder str = new StringBuilder();							
							str.append("N_REFNO = ").append(refNo);
							str.append(";N_INVNO = ").append(invNo);
							str.append(";N_RECEIPTAMT = ").append(receiptAmount);
							
							
							as1.addAudit(userID, "U", "RECEIPTDTL", str.toString());
							
							result = rDetailDAO.updateReceiptDetailAmount(receiptDetailForm);
						}
					}				
				}				
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status", "Update Receipts Failed.");
		}
		return jsonData;
	}
		
	public Map updateReceiptsHeader(Map receiptsHeaderForm) {
		Map jsonData = new HashMap();
		double collectedAmount = 0;
		double invoiceAmount = 0;
		double invAmount = 0;
		double totalreceiptAmount = 0;	//rdc05062010
		int refNo = 0;
		log.info(">>>>>Just Here Only");
		try {
			String receiptTypeDesc = receiptsHeaderForm.get("C_RECEIPTTYPE").toString().trim();
			String cNoDays = receiptsHeaderForm.get("C_NOOFDAYS").toString().trim();
			if (receiptTypeDesc.equalsIgnoreCase("Direct Credit/Cash") || receiptTypeDesc.equalsIgnoreCase("Receipt from Advances")|| receiptTypeDesc.equalsIgnoreCase("Receipt from Refunds")) {
				jsonData = this.updateReceiptsHeaderType2(receiptsHeaderForm);
			}
			else {
			ServiceUtility.viewUserParameters(receiptsHeaderForm);	
			log.info(">>>>>Just Here 1");
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			
			//String receiptTypeDesc = receiptsHeaderForm.get("C_RECEIPTTYPE").toString().trim();
			double n_amount = 0, n_origAmount = 0;
			if (receiptTypeDesc.equalsIgnoreCase("Direct Credit/Cash") || receiptTypeDesc.equalsIgnoreCase("Receipt from Advances")|| receiptTypeDesc.equalsIgnoreCase("Receipt from Refunds")) {
				//log.info("Client Availability");
				receiptsHeaderForm.put("D_TRANSACTIONDATE", receiptsHeaderForm.get("D_TRANSDATE2").toString());
				
				receiptsHeaderForm.put("N_AMOUNT", receiptsHeaderForm.get("N_AMOUNT2"));
				receiptsHeaderForm.put("N_ORIGAMOUNT", receiptsHeaderForm.get("N_ORIGAMOUNT2"));
				receiptsHeaderForm.put("N_REFNO", receiptsHeaderForm.get("N_REFNO2"));
				//receiptsHeaderForm.put("N_EXCHANGERATE", receiptsHeaderForm.get("N_EXCHAGERATE2"));
				receiptsHeaderForm.put("C_CUSTNAME", receiptsHeaderForm.get("C_CUSTNAME2"));
				receiptsHeaderForm.put("D_CHECKDATE", receiptsHeaderForm.get("D_CHECKDATE2"));
				receiptsHeaderForm.put("C_CURRENCYDESC", receiptsHeaderForm.get("C_CURRENCYDESC2"));
				receiptsHeaderForm.put("D_CLEARINGDATE", receiptsHeaderForm.get("D_CLEARINGDATE2"));
				receiptsHeaderForm.put("N_REFUNDDAYS", receiptsHeaderForm.get("N_REFUNDDAYS2"));
				receiptsHeaderForm.put("C_NAME", receiptsHeaderForm.get("C_NAME2"));
				receiptsHeaderForm.put("N_EXCHANGERATE", receiptsHeaderForm.get("N_EXCHANGERATE2"));
				
				receiptsHeaderForm.put("C_STATUS", "2");
				receiptsHeaderForm.put("C_NOOFDAYS", "0");
								
				log.info("N_EXCHANGERATE: " + receiptsHeaderForm.get("N_EXCHANGERATE").toString());
			}
			log.info(">>>>>Just Here 1A");
			n_amount = receiptsHeaderForm.get("N_AMOUNT") != null && receiptsHeaderForm.get("N_AMOUNT").toString().trim() != "" ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", "").trim()) : 0;
			n_origAmount = receiptsHeaderForm.get("N_ORIGAMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", "").trim()) : 0;
			refNo = Integer.parseInt(receiptsHeaderForm.get("N_REFNO").toString());
			receiptsHeaderForm.put("D_TRANSACTIONDATE", receiptsHeaderForm.get("D_TRANSDATE").toString());
			
			double receiptAmountNew = n_amount;
			
			String sInvAmount = receiptsHeaderForm.get("N_TOTINVAMT") != null ? (receiptsHeaderForm.get("N_TOTINVAMT").toString().trim()) : "";
			//double invAmount = sInvAmount.equals("") ? 0 : Double.parseDouble(receiptsHeaderForm.get("N_TOTINVAMT").toString());
			double oldAmount = receiptsHeaderForm.get("N_AMOUNT_OLD") != null ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT_OLD").toString().replaceAll(",", "").trim()) : 0; 
			String userID = receiptsHeaderForm.get("USERID").toString().trim();
			String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPE") != null ? receiptsHeaderForm.get("C_RECEIPTTYPE").toString().trim() : null; 
			
			
			receiptsHeaderForm.put("N_AMOUNT", n_amount);
			receiptsHeaderForm.put("N_ORIGAMOUNT", n_origAmount);
						
			if (receiptAmountNew == oldAmount) {
				jsonData = updateReceiptsHeaderExAmount(receiptsHeaderForm);
			}
			else {
									
			ReceiptsHeader receiptsHeader = ReceiptsHeaderUtility.toObject(receiptsHeaderForm);
			receiptsHeader.setN_RefNo(refNo);
			
			
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			
			Map map = new HashMap();
			map.put("N_REFNO",refNo);
			
			double previousBal = 0;
			
			List lResult = rDetailDAO.searchReceiptsDetailByCode(map);
			log.info(">>>>>Just Here 1B");
			if (lResult != null && lResult.size() > 0) {
				for (int i = 0; i < lResult.size(); i++) {
					Map m = new HashMap();
					m = (Map)lResult.get(i);
					double totalCollected = Double.parseDouble(m.get("totalCollected").toString());
					log.info("totalCollected: " + totalCollected);						
					collectedAmount = totalCollected + collectedAmount;
					double invoiceA = Double.parseDouble(m.get("N_AMTINV").toString());
					invAmount = invAmount + invoiceA;
					//rdc05062010
					double receiptAmount = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
					totalreceiptAmount = totalreceiptAmount + receiptAmount;
					
				}				
				collectedAmount = collectedAmount - oldAmount;
			}
			log.info(">>>>>Just Here 2");
			log.info("invAmount:" + invAmount);
			log.info("collectedAmount:" + collectedAmount);
			log.info("totalreceiptAmount:" + totalreceiptAmount);
			log.info("receiptAmountNew:" + receiptAmountNew);
			double totalBalance = invAmount - collectedAmount;
			//double totalBalance = n_amount;
			double overPayment = n_amount - totalBalance;
			//***added***//
			if (oldAmount > Double.parseDouble(sInvAmount)) {
				overPayment = overPayment + (oldAmount - Double.parseDouble(sInvAmount));
			}
			//**added **//
			
			log.info("totalBalance:" + totalBalance);
			log.info("overPayment:" + overPayment);
			
			if (overPayment < 0) {
				overPayment = 0;
			}
			else {
				//n_amount = totalBalance - overPayment;				
				n_amount = n_amount - overPayment;
				
			}
			
			receiptsHeaderForm.put("N_OPAMT", overPayment);
			//Date clearDate = DateHelper.parse(DateHelper.format(new Date()));
			//if (cNoDays.equals("0")) receiptsHeaderForm.put("D_CLEARINGDATE", clearDate.toString());
			
			boolean result = receiptsHeaderDAO.updateReceiptsHeader(receiptsHeaderForm);
			log.info(">>>>>Just Here 3");
			log.info("**********updateReceiptsHeader:" + result);
			if (result == true) {				
								
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "RECEIPTSHDR", receiptsHeader.toString());				 
				
				if (lResult != null && lResult.size() > 0) {
					for (int i = 0; i < lResult.size(); i++) {
						Map m = new HashMap();
						m = (Map)lResult.get(i);
																							
						int invNo = Integer.parseInt(m.get("N_INVNO").toString());
						invoiceAmount = Double.parseDouble(m.get("N_AMTINV").toString());	
						double totalCollected = Double.parseDouble(m.get("totalCollected").toString());
						double receiptAmt = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
						
						double receiptAmount = ((invoiceAmount - (totalCollected - receiptAmt)) / totalBalance) * n_amount;
						log.info("**********receiptAmount:" + receiptAmount);
						
						Map receiptDetailForm = new HashMap();
						receiptDetailForm.put("N_REFNO", refNo);
						receiptDetailForm.put("N_INVNO", invNo);
						receiptDetailForm.put("N_RECEIPTAMT", receiptAmount);
						
						//result = rDetailDAO.updateReceiptDetailAmount(receiptDetailForm);
						this.updateReceiptsHeaderAndDetail(receiptsHeaderForm);
						
						AuditService as1 = AuditService.getInstance();
						StringBuilder str = new StringBuilder();							
						str.append("N_REFNO = ").append(refNo);
						str.append(";N_INVNO = ").append(invNo);
						str.append(";N_RECEIPTAMT = ").append(receiptAmount);
						
						
						as1.addAudit(userID, "U", "RECEIPTDTL", str.toString());
					}
				}
				log.info(">>>>>Just Here 4");
				log.info(">>>>receiptType: " + receiptType);
				if (receiptType.equalsIgnoreCase("Check Payment")) {
					receiptType = "1";
				}
				else if (receiptType.equalsIgnoreCase("Direct Credit/Cash")) {
					receiptType = "2b";
				}
				else if (receiptType.equalsIgnoreCase("Client Availability")) {
					receiptType = "3b";						
				}
				
				if (receiptType.equals("1") && receiptsHeader.getN_CashDelay() == 0) {
					receiptType = "4";
				}
				else if (receiptType.equalsIgnoreCase("Receipt from Advances")) {
					receiptType = "3";
				}
				else if (receiptType.equalsIgnoreCase("Receipts from Refunds")) {
					receiptType = "4";						
				}
				log.info(">>>>>Just Here 5");
				if (totalBalance == oldAmount) {
					Map receiptsForm = new HashMap();			
					receiptsForm.put("C_CLNTCODE", receiptsHeader.getC_ClntCode() + "");
					receiptsForm.put("N_CHECKAMOUNT", receiptAmountNew - oldAmount + "");
					if (sInvAmount != "") {
						receiptsForm.put("N_OPAMT", overPayment);
					}
					receiptsForm.put("C_RECEIPTTYPE", receiptType);
					receiptsForm.put("C_USERID", userID);
					receiptsForm.put("OPERATION", "UPDATE");
					log.info("updateClientTransAmountCheckOP");
					log.info("receiptType: " + receiptType);	
					result = ClientService.getInstance().updateClientTransAmountCheckOP(receiptsForm);
				}
				else {
					//update Client Transaction Amount
					Map receiptsForm = new HashMap();			
					receiptsForm.put("C_CLNTCODE", receiptsHeader.getC_ClntCode() + "");
					receiptsForm.put("N_CHECKAMOUNT", receiptAmountNew - oldAmount + "");
					if (sInvAmount != "") {
						receiptsForm.put("N_TOTINVAMT", totalBalance);
						receiptsForm.put("N_OPAMT", overPayment);
					}
					receiptsForm.put("C_RECEIPTTYPE", receiptType);
					receiptsForm.put("C_USERID", userID);
					receiptsForm.put("OPERATION", "UPDATE");
					log.info("updateClientTransactionAmount");
					log.info("receiptType: " + receiptType);	
					result = ClientService.getInstance().updateClientTransAmount(receiptsForm);
				
					CCLinkService.getInstance().updateRunningBalance(receiptsHeader.getC_ClntCode() + "", receiptsHeader.getC_CustCode() + "", receiptAmountNew - oldAmount, userID);
					ClientService.getInstance().updateIneligibleRec(receiptsHeader.getC_ClntCode() + "", receiptAmountNew - oldAmount, userID);
				}
				log.info(">>>>>Just Here 6");
				if (result) {
					jsonData.put("status", "Updated Receipts.");
				}
				else {
					jsonData.put("status", "Update of Receipts Detail Failed.");
				}				
			}
			}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status", "Update Receipts Failed.");
		}
		return jsonData;
	}
	
	public Map updateReceiptsHeaderExAmount(Map receiptsHeaderForm) {
		Map jsonData = new HashMap();
		double collectedAmount = 0;
		double invoiceAmount = 0;
		double totalreceiptAmount = 0;	//rdc05062010
		try {
			
			ServiceUtility.viewUserParameters(receiptsHeaderForm);	
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			
			double n_amount = receiptsHeaderForm.get("N_AMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", "").trim()) : 0;
			double receiptAmountNew = n_amount;
			double n_origAmount = receiptsHeaderForm.get("N_ORIGAMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", "").trim()) : 0;
			String sInvAmount = receiptsHeaderForm.get("N_TOTINVAMT") != null ? (receiptsHeaderForm.get("N_TOTINVAMT").toString().trim()) : "";
			double invAmount = sInvAmount.equals("") ? 0 : Double.parseDouble(receiptsHeaderForm.get("N_TOTINVAMT").toString());
			double oldAmount = receiptsHeaderForm.get("N_AMOUNT_OLD") != null ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT_OLD").toString().replaceAll(",", "").trim()) : 0; 
			String userID = receiptsHeaderForm.get("USERID").toString().trim();
			String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPEVAL") != null ? receiptsHeaderForm.get("C_RECEIPTTYPEVAL").toString().trim() : null; 
			int refNo = Integer.parseInt(receiptsHeaderForm.get("N_REFNO").toString());
			String cashDelay = receiptsHeaderForm.get("C_NOOFDAYS") != null ? receiptsHeaderForm.get("C_NOOFDAYS").toString().trim() : null;  	//rdc05042010
			
			receiptsHeaderForm.put("N_AMOUNT", n_amount);
			receiptsHeaderForm.put("N_ORIGAMOUNT", n_origAmount);
			receiptsHeaderForm.put("D_TRANSACTIONDATE", receiptsHeaderForm.get("D_TRANSDATE").toString());
									
			ReceiptsHeader receiptsHeader = ReceiptsHeaderUtility.toObject(receiptsHeaderForm);
			receiptsHeader.setN_RefNo(refNo);
			
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			
			Map map = new HashMap();
			map.put("N_REFNO",refNo);
			List lResult = rDetailDAO.searchReceiptsDetailByCode(map);
			
			if (lResult != null && lResult.size() > 0) {
				for (int i = 0; i < lResult.size(); i++) {
					Map m = new HashMap();
					m = (Map)lResult.get(i);
					double totalCollected = Double.parseDouble(m.get("totalCollected").toString());
					collectedAmount = totalCollected + collectedAmount - oldAmount;	
					//rdc05062010
					double receiptAmount = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
					totalreceiptAmount = totalreceiptAmount + receiptAmount;
				}
			}
			log.info("invAmount:" + invAmount);
			log.info("collectedAmount:" + collectedAmount);
			log.info("totalreceiptAmount:" + totalreceiptAmount);
			log.info("receiptAmountNew:" + receiptAmountNew);
			
			double totalBalance = invAmount - collectedAmount;
			double overPayment = n_amount - invAmount;
			
			log.info("totalBalance:" + totalBalance);
			log.info("overPayment:" + overPayment);
			
			if (overPayment < 0) {
				overPayment = 0;
			}
			else {
				n_amount = totalBalance;
			}
			
			receiptsHeaderForm.put("N_OPAMT", overPayment);
						
			boolean result = receiptsHeaderDAO.updateReceiptsHeader(receiptsHeaderForm);
			if (result == true) {				
								
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "RECEIPTSHDR", receiptsHeader.toString());			
			}
			
			if (result) {
				jsonData.put("status", "Updated Receipts.");
			}
			else {
				jsonData.put("status", "Update of Receipts Detail Failed.");
			}	
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status", "Update Receipts Failed.");
		}
		return jsonData;
	}
		
	public Map updateReceiptStatus(Map receiptsHeaderForm) {
		//rdc05062010
		Map jsonData = new HashMap();
		double collectedAmount = 0;
		double totalreceiptAmount = 0;	//rdc05062010
		
		ServiceUtility.viewUserParameters(receiptsHeaderForm);
		String clearing = receiptsHeaderForm.get("CLEARING") != null ? receiptsHeaderForm.get("CLEARING").toString().trim() : null;  	//rdc05042010
		String receiptType = receiptsHeaderForm.get("C_RECEIPTTYPEVAL") != null ? receiptsHeaderForm.get("C_RECEIPTTYPEVAL").toString().trim() : null; 
		int refNo = Integer.parseInt(receiptsHeaderForm.get("N_REFNO").toString());
		String cashDelay = receiptsHeaderForm.get("C_NOOFDAYS") != null ? receiptsHeaderForm.get("C_NOOFDAYS").toString().trim() : null;  	//rdc05042010
		double n_amount = receiptsHeaderForm.get("N_AMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", "").trim()) : 0;
		double receiptAmountNew = n_amount;
		double n_origAmount = receiptsHeaderForm.get("N_ORIGAMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_ORIGAMOUNT").toString().replaceAll(",", "").trim()) : 0;
		//double receiptAmountNew = receiptsHeaderForm.get("N_AMOUNT") != null ? Double.parseDouble(receiptsHeaderForm.get("N_AMOUNT").toString().replaceAll(",", "").trim()) : 0;
		String userID = receiptsHeaderForm.get("USERID").toString().trim();
		
		try {	
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			Map map = new HashMap();
			map.put("N_REFNO",refNo);
			List lResult = rDetailDAO.searchReceiptsDetailByCode(map);
			
			if (lResult != null && lResult.size() > 0) {
				for (int i = 0; i < lResult.size(); i++) {
					Map m = new HashMap();
					m = (Map)lResult.get(i);
					//rdc05062010
					double receiptAmount = Double.parseDouble(m.get("N_RECEIPTAMT").toString());
					totalreceiptAmount = totalreceiptAmount + receiptAmount;
				}
			}
			
			double opmt = receiptAmountNew - totalreceiptAmount;
			receiptsHeaderForm.put("N_OPAMT", opmt);
			receiptsHeaderForm.put("N_AMOUNT", n_amount);
			receiptsHeaderForm.put("N_ORIGAMOUNT", n_origAmount);
			
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			boolean result = receiptsHeaderDAO.updateReceiptsHeader(receiptsHeaderForm);
			if (result) {
			
				log.info("receiptType : " +receiptType  + ", cashDelay : " +cashDelay + ", clearing : " + clearing);
				if (receiptType.equals("1") && cashDelay.equals("0") && clearing.equals("1")) {
					String c_ClntCode = receiptsHeaderForm.get("C_CLNTCODE") != null ? (receiptsHeaderForm.get("C_CLNTCODE").toString().trim()) : "";
					ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");	
					List lClientTransAmount = clientDAO.searchClientTransAmount(c_ClntCode);
					HashMap mClient = (HashMap) lClientTransAmount.get(0);
					double nForClearing = Double.parseDouble(mClient.get("N_FORCLEARING") !=null ? mClient.get("N_FORCLEARING").toString() : "0");
					double nReserves = Double.parseDouble(mClient.get("N_RESERVES")!=null ? mClient.get("N_RESERVES").toString() : "0");
					double nReceivables = Double.parseDouble(mClient.get("N_RECEIVABLES") !=null ? mClient.get("N_RECEIVABLES").toString():"0");
					double nFiuTran = Double.parseDouble(mClient.get("N_FIUTRAN") !=null ? mClient.get("N_FIUTRAN").toString() : "0");
					double nAdvancedRatio = Double.parseDouble(mClient.get("N_ADVANCEDRATIO") != null ? mClient.get("N_ADVANCEDRATIO").toString() : "0");
					
					
						
						log.info("nForClearing B4: " +nForClearing);
						nForClearing = nForClearing - totalreceiptAmount * ((100 - nAdvancedRatio)/100) - opmt;
						log.info("nForClearing After: " +nForClearing);
						
						map.put("N_RESERVES",nReserves);
						map.put("N_FIUTRAN",nFiuTran);
						map.put("N_RECEIVABLES",nReceivables);
						map.put("N_FORCLEARING",nForClearing);
						map.put("C_CLNTCODE",c_ClntCode);
						
						boolean resultClient  = clientDAO.updateClientTransAmount(map);
						log.info("resultClient : " +resultClient);	
						if (resultClient){
							StringBuilder description = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
							description.append(";N_RECEIVABLES=").append(nReceivables);
							description.append(";N_FIUTRAN=").append(nFiuTran);
							description.append(";N_RESERVES=").append(nReserves);
							description.append(";N_FORCLEARING=").append(nForClearing);
							
							AuditService as = AuditService.getInstance();				
							as.addAudit(userID, "U", "CLIENT", description.toString());		
						
							ReceiptsHeaderDAO rhDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
							boolean resultRHStatus  = rhDAO.updateReceiptsStatusBCleared("2", "1", refNo);
							log.info("resultRHStatus : " +resultRHStatus);
							
							if (resultRHStatus){
								StringBuilder description2 = new StringBuilder("CLIENTCODE=").append(c_ClntCode);
								description2.append(";N_REFNO=").append(refNo);
								description2.append(";C_STATUS=").append("2");
								description2.append(";B_CLEARED=").append("1");

								AuditService as2 = AuditService.getInstance();				
								as.addAudit(userID, "U", "RECEIPTSHDR", description.toString());
								
								jsonData.put("status", "Updated Receipts.");
							}
							else {
								jsonData.put("status", "Update Receipts Failed.");
							}	
						}
						else {
							jsonData.put("status", "Update Receipts Failed.");
						}		
				}			
				else {
					jsonData.put("status", "Updated Receipts.");
				}
				ReceiptsHeader receiptsHeader = ReceiptsHeaderUtility.toObject(receiptsHeaderForm);
				AuditService as = AuditService.getInstance();				
				as.addAudit(userID, "U", "RECEIPTSHDR", receiptsHeader.toString());			
			}
			else {
				jsonData.put("status", "Update Receipts Failed.");
			}		
					
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status", "Update Receipts Failed.");
		}
		return jsonData;
	}
	public Map searchReceiptsForRefund(Map m) {
		Map jsonData = new HashMap();
		String totalRecords = null;
		try {
			ServiceUtility.viewUserParameters(m);
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			m.put("C_RECEIPTTYPE", "('1','2')");
			totalRecords = receiptsHeaderDAO.getTotalReceiptsForRefund(m);			
			m = ServiceUtility.addPaging(m,totalRecords);			
			List lResult = receiptsHeaderDAO.searchReceiptsForRefund(m);
			log.info(">>>>>lResult.size():"+lResult.size() + ", totalRecords:" +totalRecords );
			if((lResult!=null) && (lResult.size()>0)){
				jsonData = JQGridJSONFormatter.formatDataToJSON(lResult, ((String)m.get("records")),((String)m.get("page")),((String)m.get("total")));
			}else{				
				jsonData.put("status","Search Receipts Failed ... ");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status","Search Receipts Failed ... ");
			return jsonData;
		}
		return jsonData;
	}
	
	public Map searchReceiptsFromRefunds(Map m) {
		Map jsonData = new HashMap();
		String totalRecords = null;
		try {
			ServiceUtility.viewUserParameters(m);
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			//m.put("C_RECEIPTTYPE", "('1','2')");
			totalRecords = receiptsHeaderDAO.getTotalReceiptsFromRefunds(m);			
			m = ServiceUtility.addPaging(m,totalRecords);			
			List lResult = receiptsHeaderDAO.searchReceiptsFromRefunds(m);
			log.info(">>>>>lResult.size():"+lResult.size() + ", totalRecords:" +totalRecords );
			if((lResult!=null) && (lResult.size()>0)){
				jsonData = JQGridJSONFormatter.formatDataToJSON(lResult, ((String)m.get("records")),((String)m.get("page")),((String)m.get("total")));
			}else{				
				jsonData.put("status","Search Receipts Failed ... ");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status","Search Receipts Failed ... ");
			return jsonData;
		}
		return jsonData;
	}
	
	public Map searchReceiptsFromAdvances(Map m) {
		Map jsonData = new HashMap();
		String totalRecords = null;
		try {
			ServiceUtility.viewUserParameters(m);
			ReceiptsHeaderDAO receiptsHeaderDAO = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			//m.put("C_RECEIPTTYPE", "('1','2')");
			totalRecords = receiptsHeaderDAO.getTotalReceiptsFromAdvances(m);			
			m = ServiceUtility.addPaging(m,totalRecords);			
			List lResult = receiptsHeaderDAO.searchReceiptsFromAdvances(m);
			log.info(">>>>>lResult.size():"+lResult.size() + ", totalRecords:" +totalRecords );
			if((lResult!=null) && (lResult.size()>0)){
				jsonData = JQGridJSONFormatter.formatDataToJSON(lResult, ((String)m.get("records")),((String)m.get("page")),((String)m.get("total")));
			}else{				
				jsonData.put("status","Search Receipts Failed ... ");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			jsonData.put("status","Search Receipts Failed ... ");
			return jsonData;
		}
		return jsonData;
	}
	/*
	public static void main (String [] args) {
		String clientCode = "101";
		
		CCLinkDAO cclinkDAO = (CCLinkDAO)Persistence.getDAO("CCLinkDAO");
		ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		String sumIneligible = cclinkDAO.searchSumIneligibleByClient(m)+ "";
		String ineligible = clientDAO.searchIneligibleRecByClient(clientCode)+"";
		System.out.println("sumIneligible:"+sumIneligible);
		System.out.println("Ineligible:"+ineligible);
		System.out.println("totalIneligible:"+Money.doRoundOff((Double.parseDouble(sumIneligible)-Double.parseDouble(ineligible))));
	}
	*/
	public boolean receiptsFromTransaction(String invoiceString, Map headerMap ){
		double totalInvoiceAmount=0.0;
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");

		String[] tempArray = new String[2];
		List<String[]> invoiceList = new ArrayList<String[]>();
		List invoiceNumberList = new ArrayList();
		int clntSize = invoiceString.split("\\}").length;//GET NUMBER OF CLIENT CODES
		int invCounter;

		SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
		Date d_transactiondate = date.newDate(); //before: new date()
		headerMap.put("D_TRANSACTIONDATE",SDF.format(d_transactiondate));

		for(int clntCounter=0;clntCounter<clntSize;clntCounter++){

	 		headerMap.put("C_CUSTCODE", invoiceString.split("\\}")[clntCounter].split("\\{")[0]);//EXTRACT CLIENT CODE FROM STRING

	 		totalInvoiceAmount=0.0;
	 		 invoiceList.clear();
	 		try{
				invCounter =  invoiceString.split("\\}")[clntCounter].split("\\{")[1].split("]").length;//GET NUMBER OF INVOICES
			}catch(ArrayIndexOutOfBoundsException e){
				invCounter =0;
			}

			if(invCounter !=0){
				for(int x=0 ; x<invCounter;x++){
					tempArray = invoiceString.split("\\}")[clntCounter].split("\\{")[1].replace("[", "").split("]")[x].split(",");//EXTRACT INVOICE PAYMENT
					invoiceList.add(tempArray);
				}

				ReceiptsHeaderDAO RHD = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");

				headerMap.put("C_RECEIPTTYPE",headerMap.containsKey("N_ADVPAYMENTNO")?3:4);

				//CREATE RECEIPTS DETAIL
				for(int x=0;x<invoiceList.size();x++){
					tempArray = invoiceList.get(x);

					headerMap.put("N_INVNO",tempArray[0] );//ELEMENT 0 POINTS TO N_INVNO
					headerMap.put("C_INVOICENO", tempArray[1]);//ELEMENT 1 POINTS TO C_INVOICENO
					headerMap.put("N_COLLECTED", tempArray[2]);//ELEMENT 2 POINTS TO COLLECTED AMOUNT
					headerMap.put("D_INVOICEDATE", tempArray[3]);//ELEMENT 3 POINTS TO INVOICE DATE
					headerMap.put("N_INVOICEAMT", tempArray[4]);//ELEMENT 4 POINTS TO ORIGINAL INVOICE AMOUNT
					
					if(tempArray.length==6){
						headerMap.put("N_CREDITNOTEAMT", tempArray[5]);//ELEMENT 5 POINTS TO CREDIT NOTE **fully paid only
					}else
						headerMap.put("N_CREDITNOTEAMT",0);
					invoiceNumberList.add(tempArray[0]);
					RHD.createTempReceipt(headerMap);	
				}
				
				headerMap.put("invoiceList", invoiceNumberList);
				InvoiceService IS = InvoiceService.getInstance();
				headerMap.put("B_FROMTRANSACTION", 1);
				
				IS.updateInvoiceTransaction(headerMap);

			}
	 	}	
		return true;
	}

	public boolean createReceiptPayment(Map p){
		ReceiptsHeaderDAO RH = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		RH.createReceiptsHeader(p);
		//GET CUSTOMER CODES FROM RECORD 
	return true; 
	}
	 
	
	public boolean receiptsFromTransaction_bak(String invoiceString, Map headerMap ){
		double totalInvoiceAmount=0.0;
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		String[] tempArray = new String[2];
		List<String[]> invoiceList = new ArrayList<String[]>();

		int clntSize = invoiceString.split("\\}").length;//GET NUMBER OF CLIENT CODES
		int invCounter;

		SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
		Date d_transactiondate = date.newDate(); // before: new date()

		List fullyPaidList = new ArrayList();
		List partiallyPaidList = new ArrayList();
		List invoices2 =  new ArrayList();
		List<String[]> invoicess= new ArrayList<String[]>();
		String[] invoiceArray = new String[2]; 
		int N_REFNO=0;
	 	long headerRef = 0; 
	 	double CNAmount2 = 0.0;
		for(int clntCounter=0;clntCounter<clntSize;clntCounter++){

	 		headerMap.put("C_CUSTCODE", invoiceString.split("\\}")[clntCounter].split("\\{")[0]);//EXTRACT CLIENT CODE FROM STRING

	 		totalInvoiceAmount=0.0;
	 		invoiceList.clear();
	 		invoices2.clear();
	 		
	 		try{
				invCounter =  invoiceString.split("\\}")[clntCounter].split("\\{")[1].split("]").length;//GET NUMBER OF INVOICES
			}catch(ArrayIndexOutOfBoundsException e){
				invCounter =0;
			}

			if(invCounter !=0){
				for(int x=0 ; x<invCounter;x++){
					tempArray = invoiceString.split("\\}")[clntCounter].split("\\{")[1].replace("[", "").split("]")[x].split(",");//EXTRACT INVOICE PAYMENT
					totalInvoiceAmount += Double.parseDouble(tempArray[2]);
					if(tempArray.length==6){
						CNAmount2 +=Double.parseDouble(tempArray[5]);
					}
					invoiceList.add(tempArray);
					invoices2.add(tempArray[0]);
				}


				ReceiptsHeaderDAO RHD = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
				headerMap.put("N_ORIGAMOUNT", totalInvoiceAmount);
				headerMap.put("N_AMOUNT", totalInvoiceAmount);
				headerMap.put("N_TOTINVAMT", totalInvoiceAmount);
				headerMap.put("D_TRANSACTIONDATE", SDF.format(d_transactiondate));
				headerMap.put("C_BRANCHCODE","01");
				headerMap.put("N_EXCHANGERATE",1.00);
				headerMap.put("C_CURRENCYCODE","PHP");

				headerMap.put("C_RECEIPTTYPE",headerMap.containsKey("N_ADVPAYMENTNO")?3:4);
				headerMap.put("C_STATUS",CNAmount2!=0?4:2);
				
				//CREATE RECEIPTS HEADER
				N_REFNO = RHD.receiptsFromTransaction(headerMap);
				headerMap.put("N_REFNO", N_REFNO);

				ReceiptsDtlDAO RD = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
				CreditNoteDAO CN = (CreditNoteDAO)Persistence.getDAO("CreditNoteDAO");

				boolean partialPayment = false;
				headerMap.put("partial", partialPayment);
				
				headerMap.put("N_Amount", totalInvoiceAmount);
				
				headerMap.put("C_Type","P");
				headerMap.put("C_TransactionType","P");
				SubHeaderService JS = SubHeaderService.getInstance();
				headerRef= JS.createSubHeader(headerMap, Boolean.parseBoolean(headerMap.get("partial").toString())?"COLLECTION with partial payment":"COLLECTION", SDF.format(d_transactiondate),"COLLECTION");
				
				if(CNAmount2!=0){
					headerMap.put("CNAmount2", CNAmount2);
					JS.createLedgerEntry2(headerMap, "ReceiptsFromTransaction",headerRef);
				}
				
				//CREATE RECEIPTS DETAIL
				for(int x=0;x<invoiceList.size();x++){
					tempArray = invoiceList.get(x);

					headerMap.put("N_INVNO",tempArray[0] );//ELEMENT 0 POINTS TO N_INVNO
					headerMap.put("C_INVOICENO", tempArray[1]);//ELEMENT 1 POINTS TO C_INVOICENO
					headerMap.put("N_RECEIPTAMT", tempArray[2]);//ELEMENT 2 POINTS TO COLLECTED AMOUNT
					headerMap.put("D_INVOICEDATE", tempArray[3]);//ELEMENT 3 POINTS TO INVOICE DATE
					headerMap.put("N_AMTINV", tempArray[4]);//ELEMENT 4 POINTS TO ORIGINAL INVOICE AMOUNT
					RD.receiptsDetailFromTransaction(headerMap);
					
					invoiceArray = new String[4];
					invoiceArray[0]=tempArray[0];
					invoiceArray[1]=tempArray[2];
					invoiceArray[2]="0";
					invoiceArray[3]="0";
					invoicess.add(invoiceArray);
					
					if(tempArray.length==6){
						headerMap.put("N_AMOUNT", tempArray[5]);//ELEMENT 5 POINTS TO CREDIT NOTE **fully paid only
						CN.creditNoteFromTransaction(headerMap);
						fullyPaidList.add(tempArray[0]);
						headerMap.put("CNAmount", tempArray[5]);
						JS.createLedgerEntry2(headerMap, "Credit-Note",headerRef);
					}
					else{
						partiallyPaidList.add(tempArray[0]);
						headerMap.put("partial", true);
					}
					
				}
				
				headerMap.put("N_ORIGAMOUNT", totalInvoiceAmount);
				
				headerMap.put("invoicess", invoicess);
				
				headerMap.put("invoices2", invoices2);
				
				JS.createLedgerEntry2(headerMap, "Collection", headerRef);

			}
	 	}
	 	INVOICEDAO ID = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
	 	if(fullyPaidList.size()!=0){
			headerMap.put("invoiceList", fullyPaidList);
			headerMap.put("C_STATUS", 5);
			headerMap.put("D_FULLYPAIDDATE", SDF.format(d_transactiondate));
			ID.updateInvoiceFromTransaction(headerMap);
			headerMap.remove("D_FULLYPAIDDATE");
		}

		//UPDATE STATUS OF PARTIALLY PAID INVOICE
		if(partiallyPaidList.size()!=0){
			headerMap.put("invoiceList", partiallyPaidList);
			headerMap.put("C_STATUS", 4);
			headerMap.put("D_PARTIALPAIDDATE", SDF.format(d_transactiondate));
			headerMap.put("N_PARTIALREFERENCE", N_REFNO);
			ID.updateInvoiceFromTransaction(headerMap);
		}
		return true;
	}

	public void cancelFromTransaction(String N_REFNO, String transactionType){
		ReceiptsHeaderDAO RH  = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
		RH.cancelFromTransaction(N_REFNO,transactionType);
	}
	
	public boolean updateStatus(){
		return true;
	} 
	
	public Map getReceiptsPenalty(Map receiptsData){
		Map penaltyMap = new HashMap();
	
		if(receiptsData.get("selInvNos")!=null){
			FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
			SimpleDateFormat SDF = new SimpleDateFormat ("yyyy/MM/dd");
			String currDate = SDF.format(date.newDate());
			String invoices = receiptsData.get("selInvNos").toString();
			Map data = new HashMap<>();
			data.put("clientCode", receiptsData.get("clientCode").toString());
			data.put("custCode", receiptsData.get("custCode").toString());
			data.put("invNos", invoices);
			data.put("tranDate", currDate);
			data.put("paymentReceivedDate", receiptsData.get("paymentReceivedDate").toString());
			data.put("sumClientPenalty", receiptsData.get("sumClientPenalty"));
			ReceiptsHeaderDAO rh = (ReceiptsHeaderDAO)Persistence.getDAO("ReceiptsHeaderDAO");
			penaltyMap = rh.getReceiptsPenalty(data);		
			penaltyMap.put("status", "SUCCESS");
			//System.out.println("SDDSDSDSDSDSDSDDSD");
			//System.out.println(invoices);
		}
			
		
		return penaltyMap;
	}
}


