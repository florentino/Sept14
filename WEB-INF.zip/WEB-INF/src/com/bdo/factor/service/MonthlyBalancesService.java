package com.bdo.factor.service;

import java.util.Map;

import org.apache.log4j.Logger;

public class MonthlyBalancesService {
	
	private static Logger log = Logger.getLogger(MonthlyBalancesService.class);
	
	private static MonthlyBalancesService monthlyBalances = new MonthlyBalancesService();
	
	public static MonthlyBalancesService  getInstance(){
		return monthlyBalances;
	}
	
	public Map checkIfAlreadyUpdated(Map map){
		return map;
		
	}
	

}
