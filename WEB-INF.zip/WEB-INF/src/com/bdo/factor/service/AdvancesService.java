package com.bdo.factor.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Advances;
import com.bdo.factor.beans.CreditNote;
import com.bdo.factor.dao.AdjustmentTypeDAO;
import com.bdo.factor.dao.AdvancesDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.CustomerDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class AdvancesService {
	private static Logger log = Logger.getLogger(AdvancesService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////

private static AdvancesService thisAdvancesService = new AdvancesService();

private AdvancesService() { }

public static AdvancesService getInstance() {

return thisAdvancesService;
}

@SuppressWarnings("unchecked")

public Map updateAdvance(Map AdvanceForm) throws IOException, SQLException{
	String customerCode = "";
	String clientCode = "";
	AdvancesDAO AdvanceDAO = (AdvancesDAO)Persistence.getDAO("advanceDao");
	
	 FactorsDateDAO factorsDate = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
	
	ServiceUtility.viewUserParameters(AdvanceForm);
	log.info("--->> updateAdvance SERVICE ...");
	
	Map jsondata = new HashMap();
	Map newData = new HashMap();
	
	if (AdvanceForm.get("stat").equals("1")){ //update advance status

		//rr 04172012
		java.util.Date date = new java.util.Date(); 
		java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy");
		String today = format.format(factorsDate.newDate());
		AdvanceForm.put("TODAY", today);
		
		Integer insertDiscountDetailCount =AdvanceDAO.insertDiscountDetail(AdvanceForm);
	    log.info("Insert discount detail sucessful!: "+insertDiscountDetailCount+" record(s)");
		
		Integer insertPenaltyDetailCount =AdvanceDAO.insertPenaltyDetail(AdvanceForm);
		log.info("Insert penalty detail sucessful!: "+insertPenaltyDetailCount+" record(s)");
		
		//--
		
		
		boolean success = AdvanceDAO.updateAdvanceStatus(AdvanceForm); // changed the status
		//boolean success = true;
		if(success) {
			try{
				
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(AdvanceForm);
				log.info("C_USERID==>"+newData.get("C_USERID").toString());
				Advances cn = new Advances(newData);
				as.addAudit(newData.get("C_USERID").toString(),"U","ADVANCES",cn.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			
			jsondata.put("status","Update Advance Status Successful ...");
		}else{
			jsondata.put("status","Update Advance Status Failed ... "+AdvanceDAO.getReturnmsg());
		}
		return jsondata;
	}
	
	try{
		AdvanceForm.put("N_COMPUTEDAMT", AdvanceForm.get("N_COMPUTEDAMT").toString().replaceAll(",", ""));
		AdvanceForm.put("N_ADVAMT", AdvanceForm.get("N_ADVAMT").toString().replaceAll(",", ""));
		AdvanceForm.put("N_SVCCHG", AdvanceForm.get("N_SVCCHG").toString().replaceAll(",", ""));
		AdvanceForm.put("N_DISCCHG1", AdvanceForm.get("N_DISCCHG1").toString().replaceAll(",", ""));
		AdvanceForm.put("N_DISCCHG2", AdvanceForm.get("N_DISCCHG2").toString().replaceAll(",", ""));
		//ADDED BY CVG AS OF 03-15-16
		AdvanceForm.put("N_NOTARIAL", AdvanceForm.get("N_NOTARIAL").toString().replaceAll(",", ""));
		
		
		ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		clientCode = clientDAO.searchClientResolveToCode(AdvanceForm);
		if (clientCode == null){
			jsondata.put("status","Update Advance Failed ... Invalid Client");
			return jsondata;
		}
		AdvanceForm.put("C_CLNTCODE", clientCode);
		
		ServiceUtility.viewUserParameters(AdvanceForm);
		
		boolean success = AdvanceDAO.updateAdvance(AdvanceForm);
		if(success) {
			
			try{
				
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(AdvanceForm);
				Advances cn = new Advances(newData);
				as.addAudit(newData.get("C_USERID").toString(),"U","ADVANCES",cn.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			
			jsondata.put("status","Update Advance Successful ...");
		}else{
			jsondata.put("status","Update Advance Failed ... ");
		}
		
	}catch(Exception x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}	
	
	return jsondata;
}

public Map addAdvance(Map AdvanceForm){
	String customerCode = "";
	String clientCode = "";
	
	log.info("--->> updateAdvance SERVICE ...");
	
	Map jsondata = new HashMap();
	Map newData = new HashMap();
	
	try{
		ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		clientCode = clientDAO.searchClientResolveToCode(AdvanceForm);
		if (clientCode == null){
			jsondata.put("status","Add Advance Failed ... Invalid Client");
			return jsondata;
		}
		AdvanceForm.put("C_CLNTCODE", clientCode);
		
		ServiceUtility.viewUserParameters(AdvanceForm);
		
		AdvancesDAO AdvDAO = (AdvancesDAO)Persistence.getDAO("advanceDao");
		double computedAmount = AdvanceForm.get("N_COMPUTEDAMT") != null ? Double.parseDouble(AdvanceForm.get("N_COMPUTEDAMT").toString().trim().replaceAll(",", "")) : 0;
		double advanceAmount = AdvanceForm.get("N_ADVAMT") != null ? Double.parseDouble(AdvanceForm.get("N_ADVAMT").toString().trim().replaceAll(",", "")) : 0;
		///set ticker of  net and gross amt
		AdvanceForm.put("N_COMPUTEDAMT", computedAmount);
		AdvanceForm.put("N_ADVAMT", advanceAmount);
		
		int success = AdvDAO.addAdvance(AdvanceForm);				

		///CREATE RECEIPTS HEADER FOR DELINQUENT INVOICE
		if(AdvanceForm.get("invoiceString")!=null&&!AdvanceForm.get("invoiceString").toString().contentEquals(""))
		{
			ReceiptsHeaderService RHS = ReceiptsHeaderService.getInstance();
			AdvanceForm.put("N_ADVPAYMENTNO", success);
			RHS.receiptsFromTransaction(AdvanceForm.get("invoiceString").toString(), new HashMap(AdvanceForm));
		}
		
		if(success!=0){
			
			try{
				
				AuditService as = AuditService.getInstance();
				
				newData = ServiceUtility.removeNulls(AdvanceForm);
				Advances cn = new Advances(newData);
				as.addAudit(newData.get("C_USERID").toString(),"I","ADVANCES",cn.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}

			jsondata.put("status","Add Advance Successful ...");
		}else{
			jsondata.put("status","Add Advance Failed ... ");
		}
		
	}catch(Exception x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
		//return jsondata;
	}
	
	return jsondata;
}

public Map GetDocStampAmount(Map data){
	AdvancesDAO _AdvancesDAO = (AdvancesDAO)Persistence.getDAO("AdvancesDAO");
	data.put("rv", _AdvancesDAO.GetDocStampAmount(data));
	return data;
}

public Map searchAdvances(Map AdvancesForm){
	
	log.info("--->> Search Advances SERVICE X...");
	
	Map jsondata = new HashMap();
	List records = new ArrayList();
	String totalRecords = "";
	String customerCode = "";
	String clientCode = "";

	try{
		
		ServiceUtility.viewUserParameters(AdvancesForm);
		log.info("--->> searchAdvances 1");
			
		//BankDAO factorAdvancesDAO = (BankDAO)Persistence.getDAO("BankDAO");	
		AdvancesDAO advancesDAO = (AdvancesDAO)Persistence.getDAO("advanceDao");	
		
		System.out.println("--->> searchAdvances 2XX");
		log.info("--->> searchAdvances 2");
		
		///////////////////////////////////////////////
		if (AdvancesForm.get("C_NAME")!=null){
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientCode = clientDAO.searchClientResolveToCode(AdvancesForm);
			AdvancesForm.put("C_CLNTCODE", clientCode);
		}
		///////////////////////////////////////////////
		log.info("--->> searchAdvance 2");
		
		totalRecords = advancesDAO.getTotalRecordsAdvances(AdvancesForm);	
		//records = advancesDAO.searchAdvances(AdvancesForm);	
		
		ServiceUtility.viewUserParameters(AdvancesForm);
		log.info("--->> searchAdvance 2 "+totalRecords);
		
		
		AdvancesForm = ServiceUtility.addPaging(AdvancesForm,totalRecords);
		
		records = advancesDAO.searchAdvances(AdvancesForm);	
	
		ServiceUtility.viewUserParameters(AdvancesForm);
					
		log.info("--->> searchAdvance RECORD-SIZE: "+records.size());
		
		if((records!=null) && (records.size()>0)){						
			jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)AdvancesForm.get("records")),((String)AdvancesForm.get("page")),((String)AdvancesForm.get("total")));
		}else{
			jsondata.put("status","searchAdvance Failed ... ");
		}

	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}	
	
	return jsondata;
	
}

public int getAdvancesSettingUpRefNo(int n_RefNo) {
	int result = 0;
	try {
		AdvancesDAO advancesDAO = (AdvancesDAO)Persistence.getDAO("AdvancesDAO");	
		result = advancesDAO.getAdvancesSettingUpRefNo(n_RefNo);
	}
	catch (Throwable x) {
		x.printStackTrace();
	}
	return result;
}

public int getAdvancesReportSize(int n_RefNo) {
	int result = 0;
	try {
		AdvancesDAO advancesDAO = (AdvancesDAO)Persistence.getDAO("AdvancesDAO");	
		result = advancesDAO.getAdvancesReportSize(n_RefNo);
	}
	catch (Throwable x) {
		x.printStackTrace();
	}
	return result;
}

 


public static void main(String[] args) {
	AdvancesService svc = AdvancesService.getInstance();
	int result = svc.getAdvancesSettingUpRefNo(6);
	System.out.println("result: " + result);
}
//////////////////////////////////////////////////////////////////////////////////////////////
}
