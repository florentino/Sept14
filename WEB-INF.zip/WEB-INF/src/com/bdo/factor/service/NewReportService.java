package com.bdo.factor.service;
import java.io.File;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;

import com.bdo.factor.beans.ActualDunningBean;
import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.CCLink;
import com.bdo.factor.beans.SystemSettings;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.SystemSettingsDAO;
import com.bdo.factor.dataSource.AccountForReviewField;
import com.bdo.factor.dataSource.ActualDunningFields;
import com.bdo.factor.dataSource.AdvicesReport;
import com.bdo.factor.dataSource.AdvicesSummaryField;
import com.bdo.factor.dataSource.AgeingSummaryField;
import com.bdo.factor.dataSource.CCAgingAnalysisField;
import com.bdo.factor.dataSource.ClientActivityField;
import com.bdo.factor.dataSource.ClientConcentrationDS;
import com.bdo.factor.dataSource.ClientDebtTurnField;
import com.bdo.factor.dataSource.ClientSalesAnalysisField;
import com.bdo.factor.dataSource.ClientStatisticsField;
import com.bdo.factor.dataSource.CustomerConcentrationField;
import com.bdo.factor.dataSource.CustomerStatementOfAccountFields;
import com.bdo.factor.dataSource.CustomerStatementOfAcctDAO;
import com.bdo.factor.dataSource.DiscountChargeOnCashDelayDS;
import com.bdo.factor.dataSource.DueInvoiceField;
import com.bdo.factor.dataSource.FactoringManagementField;
import com.bdo.factor.dataSource.FactoringStatsDAO;
import com.bdo.factor.dataSource.FactoringStatsFields;
import com.bdo.factor.dataSource.PDCRegistryField;
import com.bdo.factor.dataSource.PDODelinquentDatasource;
import com.bdo.factor.dataSource.PDOInvoiceDS;
import com.bdo.factor.dataSource.PartialPaymentField;
import com.bdo.factor.dataSource.RPTClassificationFields;
import com.bdo.factor.dataSource.ScheduleOfCreditNotes;
import com.bdo.factor.dataSource.TransactionControlTotalField;
import com.bdo.factor.dataSource.VerifyInvoiceField;
import com.bdo.factor.util.FactorConnection;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRRuntimeException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.j2ee.servlets.BaseHttpServlet;

import net.sf.jasperreports.engine.util.*;
import net.sf.jasperreports.engine.export.*;
import net.sf.jasperreports.j2ee.servlets.*;

public class NewReportService {

	
	public void buildReport(HttpServletRequest request, Map mm) throws JRException, SQLException{
		try{
			mm.get("reportOption");
			mm.get("ds");
			mm.get("listSize");
			mm.get("operation");
			mm.get("jasper");
			mm.get("sSQL");
			mm.get("optionJP");
			mm.get("cc");
			mm.get("title");
			mm.get("map");
			
		Map m = (Map)mm.get("map");	
			
		}catch(Exception e){}
		
		
		
		
		String clientCode 	= mm.get("clientCode")!=null?mm.get("clientCode").toString():"";
		String startDate  	= mm.get("startDate")!=null?mm.get("startDate").toString():"";
		String endDate    	= mm.get("endDate")!=null?mm.get("endDate").toString():"";
		String sSQL    		= mm.get("sSQL")!=null?mm.get("sSQL").toString():"";
		String userName    	= request.getSession().getAttribute("userName")!=null?(String)request.getSession().getAttribute("userName"):"Redd";
		String branchName	= request.getSession().getAttribute("branchName")!=null?(String)request.getSession().getAttribute("branchName"):"Leasing IT Devt";
		String branchCode	= request.getSession().getAttribute("branchCode")!=null?(String)request.getSession().getAttribute("branchCode"):"00";
		String clientName	= mm.get("clientName")!=null?mm.get("clientName").toString():"";
		String optionJP		= mm.get("optionJP")!=null?mm.get("optionJP").toString():"";
		String asOfDate		= mm.get("asOfDate")!=null?mm.get("asOfDate").toString():"";
		String monthYear    = mm.get("monthYear")!=null?mm.get("monthYear").toString():"";
		String clientCodeClause = mm.get("clientCodeClause")!=null?mm.get("clientCodeClause").toString():"";
		String customerCode = mm.get("customerCode")!=null?mm.get("customerCode").toString():"";
		String status       = mm.get("status")!=null?mm.get("status").toString():"";
		String title        = mm.get("title")!=null?mm.get("title").toString():"";
		String whereClause  = mm.get("whereClause")!=null?mm.get("whereClause").toString():"";
		String paymentType  = mm.get("paymentType")!=null?mm.get("paymentType").toString():"";
		JasperPrint jasperPrint = null;
		
		HttpSession a = request.getSession(true);
		ServletContext context = a.getServletContext();
			
		
		
		String reportOption = mm.get("reportOption")!=null ? (String) mm.get("reportOption") : "PDF";
		CC cc = (CC)mm.get("cc");
		if(cc.getStartDate()!=null)startDate = cc.getStartDate();
		if(cc.getEndDate()!=null)endDate = cc.getEndDate();
		if(cc.getStatus()!=null)status = cc.getStatus();
		if(cc.getAsOfDate()!=null)asOfDate = cc.getAsOfDate();
		if(cc.getBranchCode()!=null)branchCode = cc.getBranchCode();
		if(cc.getClientCode()!=null)clientCode = cc.getClientCode();
		
		/*COMMON VARIABLE*/	
		String msg=mm.get("msg")!=null?mm.get("msg").toString():"";
		long listSize=mm.get("listSize")!=null?Long.parseLong(mm.get("listSize").toString()):0;
		String operation = mm.get("operation")!=null?((String)mm.get("operation")).trim():"";
		String jasper = mm.get("jasper")!=null?(String)mm.get("jasper"):"";
		String reportFileName = context.getRealPath(jasper);
		System.out.println(reportFileName);
		
		
		
		Map param =mm.get("map")!=null ?(Map)mm.get("map"):new HashMap();
		if(!startDate.equals(""))param.put("startDate",startDate);
		if(!endDate.equals(""))param.put("endDate",endDate);
		param.put("userName",userName);
		param.put("branchName",branchName);
		param.put("branchCode",branchCode);
		param.put("clientCode",param.get("clientCode")!=null?(String)param.get("clientCode"):clientCode);
		param.put("sSQL",sSQL);	
		param.put("clientName",clientName);
		param.put("asOfDate",param.get("asOfDate")!=null?(String)param.get("asOfDate"):asOfDate);
		param.put("SUBREPORT_DIR",context.getRealPath("/report")+"/");
		param.put("monthYear",monthYear);
		param.put("status",status);
		param.put("clientCodeClause", clientCodeClause);
		param.put("title",title);
		param.put("whereClause",whereClause);
		param.put("paymentType",paymentType);
		SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
		SystemSettings systemSettings = systemSettingDao.getSystemSettings();
		param.put("systemName", systemSettings.getC_SYSTEMNAME());
		param.put("currencyCode", systemSettings.getC_CURRENCYCODE());
		param.put("bankCode", systemSettings.getC_BANKCODE());
		
		param.put("bankAccount",systemSettings.getC_BANKACCOUNT());
		param.put("approver",systemSettings.getC_APPROVER());
		param.put("address",systemSettings.getC_ADDRESS());
		param.put("companyName",systemSettings.getC_COMPANYNAME());
		param.put("bankName",systemSettings.getC_BANKNAME());
		param.put("branchManager",systemSettings.getC_BM());
		
		
		System.out.println("Report PDF startDate "+startDate);
		System.out.println("Report PDF endDate "+endDate);
		System.out.println("Report PDF Jasper Print Option "+optionJP);
		System.out.println("Report PDF jasper "+jasper);
		System.out.println("Report PDF listSize "+listSize);
		System.out.println("Report PDF reportFileName "+reportFileName);
		System.out.println("Report PDF sSQL=>: "+sSQL);
		System.out.println("Report PDF as of date=>: "+asOfDate);
		System.out.println("Report PDF SubReport Directory=>: "+param.get("SUBREPORT_DIR").toString());
		System.out.println("Report PDF reportOption=>: "+reportOption);
		System.out.println("Report PDF operation=>:  "+operation);
		
		/*END COMMON VARIABLE*/
		if(listSize>0)
		{
			FactorConnection factor= new FactorConnection();
			JRDataSource ds= null;
			if(operation.equalsIgnoreCase("reportAudit"))
			{
				//ds = new AuditTrailField(startDate,endDate);        
			}
			else if (operation.equalsIgnoreCase("schedOfCreditNote") || operation.equalsIgnoreCase("schedOfCanceledCreditNote"))
			{	
				int Status = 2;
				if (operation.equalsIgnoreCase("schedOfCreditNote"))
				{
					Status = 2;
				}
				else if (operation.equalsIgnoreCase("schedOfCanceledCreditNote"))
				{
					Status = 3;
				}
				ScheduleOfCreditNotes creditNoteDS = new ScheduleOfCreditNotes(branchCode, clientCode, startDate, endDate, Status); 
				ds = creditNoteDS;
				creditNoteDS.setBranchName(branchName);
				creditNoteDS.setUserID(userName);
			}
			else if (operation.equalsIgnoreCase("customerStmtOfAcct"))
			{					
				long custCode   = mm.get("custCode") !=null ? (Long)mm.get("custCode"):0;
				Boolean flag = (Boolean) (mm.get("filter")!= null?mm.get("filter"):false);
				CustomerStatementOfAcctDAO custStmtOfAcct = (CustomerStatementOfAcctDAO)Persistence.getDAO("customerStmtOfAcctDao");
				
				//CustomerStatementOfAccounts customerStmtDS = new CustomerStatementOfAccounts(clientCode, custCode, asOfDate, branchCode);
				CustomerStatementOfAccountFields customerStmtDS = new CustomerStatementOfAccountFields(clientCode, custCode, asOfDate, branchCode,flag);
				ds = customerStmtDS;
				customerStmtDS.setBranchName(branchName);
				customerStmtDS.setUserID(userName);
				
			}
			else if (operation.equalsIgnoreCase("actualDunningReport"))
			{					
				long custCode   = mm.get("custCode") !=null ? (Long)mm.get("custCode"):0;
				
				 
				
				//CustomerStatementOfAccounts customerStmtDS = new CustomerStatementOfAccounts(clientCode, custCode, asOfDate, branchCode);
			 
				ds = new ActualDunningFields(mm);
				param.put("datasource1", new ActualDunningFields(mm));
				param.put("record", new ActualDunningFields().getRecords());
				/*customerStmtDS.setBranchName(branchName);
				customerStmtDS.setUserID(userName);*/
				
			}
			
			else if (operation.equalsIgnoreCase("verifyInvoiceList")){
				System.out.println("verifyInvoiceList datasource");
				ds = new VerifyInvoiceField(startDate, endDate);
			}
			else if (operation.equalsIgnoreCase("dueInvoiceList")){
				System.out.println("dueInvoiceList datasource");
				ds = new DueInvoiceField(startDate, endDate);	
			}
			else if (operation.equalsIgnoreCase("ccAgingAnalysisList")||operation.equalsIgnoreCase("ccAgingByDunningList")){
				System.out.println("ccAgingAnalysisList datasource");
				CCLink ccLink = new CCLink(clientCode,branchCode,asOfDate);
				ds = new CCAgingAnalysisField(ccLink,operation);	
			}
			else if (operation.equalsIgnoreCase("exposureByIndustry"))
			{
				String monthAndYear = (String)mm.get("monthAndYear");
				param.put("monthAndYear", monthAndYear);
			}						
			else if (operation.equalsIgnoreCase("clientActivityList")){
				System.out.println("clientActivityList datasource");
				ds = new ClientActivityField(clientCode,asOfDate);	
			}
			else if (operation.equalsIgnoreCase("rptClassification")){
				System.out.println("RPTClassification datasource");
				Boolean includeZero = Boolean.parseBoolean(mm.get("includeZero").toString()); 
				ds = new RPTClassificationFields(branchCode,asOfDate,includeZero);	
			}
			else if (operation.equalsIgnoreCase("clientSalesAnalysisList")){
				System.out.println("clientSalesAnalysisList datasource");
				ds = new ClientSalesAnalysisField(cc);	
			}
			else if (operation.equalsIgnoreCase("ScheduleOfCreditNoteAllCancelledClient"))
			{			
				param.put("c_status", "3");			
			}
			else if (operation.equalsIgnoreCase("ScheduleOfCreditNoteAllClient"))
			{
				param.put("c_status", "2");
			}
			else if (operation.equalsIgnoreCase("clientDebtTurnReport")){

				ds = new ClientDebtTurnField(clientCode, customerCode, "('5','6')", startDate, endDate);	
			}
			else if (operation.equalsIgnoreCase("ageingSummaryByClient")||operation.equalsIgnoreCase("ageingClientByDunning")){
				ds = new AgeingSummaryField(cc,operation);	
			}
			else if (operation.equalsIgnoreCase("clientStatisticsRevReport")){

				ds = new ClientStatisticsField(clientCode, asOfDate);	
			}
			else if (operation.equalsIgnoreCase("factorStatisticsReport"))
			{			
				FactoringStatsDAO factoringStatsDAO      = (FactoringStatsDAO)Persistence.getDAO("factoringStatsDao");
				FactoringStatsFields factoringStatsField = new FactoringStatsFields(branchCode, clientCode, monthYear);
				ds 										 = factoringStatsField;
				factoringStatsField.setUserId(userName);
				factoringStatsField.setBranchName(branchName);				
			}
			else if (operation.equalsIgnoreCase("transactionCtrlTotals")){

				ds = new TransactionControlTotalField(startDate, endDate, branchCode);	
			}
			else if (operation.equalsIgnoreCase("accountsForReview")){

				ds = new AccountForReviewField(startDate, endDate, branchCode);	
			}
			else if (operation.equalsIgnoreCase("customerConcentration")||operation.equalsIgnoreCase("customerConcentrationAll")){

				ds = new CustomerConcentrationField(cc);	
			}	
			else if (operation.equalsIgnoreCase("pdcRegistry")){

				ds = new PDCRegistryField(clientCode, branchCode, startDate, endDate);	
			}
			else if (operation.equalsIgnoreCase("pdcRegistryAllClient")){
				clientCode = null;
				ds = new PDCRegistryField(clientCode, branchCode, startDate, endDate);	
			}
			else if (operation.equalsIgnoreCase("partialPayment")){

				ds = new PartialPaymentField(clientCode, branchCode, startDate, endDate);	
			}
			else if (operation.equalsIgnoreCase("partialPaymentAllClient")){
				clientCode = null;
				ds = new PartialPaymentField(clientCode, branchCode, startDate, endDate);	
			}		
			else if (operation.equalsIgnoreCase("advices")){
				List<AdvicesReport> list= (List) mm.get("list");
				ds = new AdvicesSummaryField(list);	
			}	
			else if (operation.equalsIgnoreCase("factoringManagement")) {
				ds = new FactoringManagementField(asOfDate, branchCode);	
			}
			else if (operation.equalsIgnoreCase("FactoredReceivable")) {
				ds = new FactoringManagementField(asOfDate, branchCode,"FactoredReceivable",false);	
			}else if (operation.equalsIgnoreCase("FactoredReceivableCredex")) {
				Boolean filter = mm.containsKey("filter")?mm.get("filter").toString().equals("FRFilterStatus"):false;
				ds = new FactoringManagementField(asOfDate, branchCode,"FactoredReceivableCredex",filter);	
			}
			else if (operation.equalsIgnoreCase("PDOInvoices"))
			{	
				String id =mm.get("id")!=null?mm.get("id").toString():"";
				String reportType =mm.get("reportType")!=null?mm.get("reportType").toString():"";
				param.put("dateAsOf", asOfDate);
				
				if(reportType.contentEquals("acctgPDO")){
					ds = new PDODelinquentDatasource(asOfDate, branchCode,id);
				}
				else if (reportType.contentEquals("mktgPDO")){
					ds = new PDODelinquentDatasource(asOfDate, branchCode);
					JRDataSource ds2 = new PDODelinquentDatasource();
					param.put("parameter1", ds2);
				}
				else if (reportType.contentEquals("lpcPDO")){
					ds = new PDODelinquentDatasource(asOfDate, branchCode);
				}
			}		
			else if (operation.equalsIgnoreCase("discountChargeOnCashDelay"))
			{
				ds = new DiscountChargeOnCashDelayDS(startDate,endDate,branchCode);
			}
			else if (operation.equalsIgnoreCase("clientConcentrationRep"))
			{
				ds = new ClientConcentrationDS(branchCode);
			}
			else if (operation.equalsIgnoreCase("AdvRefTransaction"))
			{
				optionJP="1";
				param.put("startDate", startDate);
				param.put("endDate", endDate);
			}
			else if (operation.equalsIgnoreCase("scheduleOfInvoiceEditList") 
					  || operation.equalsIgnoreCase("schedofinvoiceeditlistAllClient") 
					  || operation.equalsIgnoreCase("monthlyCharges")
					  || operation.equalsIgnoreCase("refundClientList")
					  || operation.equalsIgnoreCase("advancesList")
					  || operation.equalsIgnoreCase("advancesListAllClient") //added by Cherrie
					  || operation.equalsIgnoreCase("activityLogReport")
					){
				ds = (JRDataSource)mm.get("ds");
				System.out.println("under ds operation");
			}
			if(operation.equalsIgnoreCase("advancesList")||operation.equalsIgnoreCase("advancesListAllClient"))param.put("REPORT_CONNECTION",factor.getConnection()); //AdvanceListAllClient added by Cherrie
			
			File reportFile = new File(reportFileName);
			if (!reportFile.exists()) {
				System.out.println("No source File");
				System.out.println(reportFileName +" Not Found");
				throw new JRRuntimeException("File WebappReport.jasper not found. The report design must be compiled first.");
			}
			
			if(optionJP.equalsIgnoreCase("1")){
				jasperPrint = JasperFillManager.fillReport(reportFileName,param,factor.getConnection());			
			}
			else if(optionJP.equalsIgnoreCase("2")){
				jasperPrint = JasperFillManager.fillReport(reportFileName,param,factor.getConnectionCIF());
			}
			else{			
				jasperPrint = JasperFillManager.fillReport(reportFileName,param,ds);
			}
			 
		}
		
		a.setAttribute(BaseHttpServlet.DEFAULT_JASPER_PRINT_SESSION_ATTRIBUTE, jasperPrint);
		
		
		 
	}
	
	 
}
