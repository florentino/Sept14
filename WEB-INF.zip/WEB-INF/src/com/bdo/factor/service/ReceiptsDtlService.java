package com.bdo.factor.service;

import java.util.ArrayList;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.bdo.factor.beans.CreditNote;
import com.bdo.factor.beans.Group;
import com.bdo.factor.beans.ReceiptsDtl;
import com.bdo.factor.beans.ReceiptsHeader;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.CreditNoteDAO;
import com.bdo.factor.dao.CustomerDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.SubHeaderDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.ReceiptsDtlDAO;
import com.bdo.factor.dao.ReceiptsHeaderDAO;
import com.bdo.factor.util.CreditNoteUtility;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.GroupUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ReceiptsDtlUtility;
import com.bdo.factor.util.ReceiptsHeaderUtility;
import com.bdo.factor.util.ServiceUtility;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class ReceiptsDtlService{
	private static Logger log = Logger.getLogger(ReceiptsDtlService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static ReceiptsDtlService rDetailInstance = new ReceiptsDtlService();
	
	private ReceiptsDtlService() { }

	public static ReceiptsDtlService getInstance() {
		return rDetailInstance;
	}
		
//////////////////////////////////////////////////////////////////////////////////////////////

	public Map addReceiptsDetail(Map receiptsDetailForm) {
		Map jsonData = new HashMap();
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");		
		ServiceUtility.viewUserParameters(receiptsDetailForm);
		ReceiptsDtl receiptsDtl = ReceiptsDtlUtility.getInstance().toObject(receiptsDetailForm);
		receiptsDetailForm.put("D_TRANSACTIONDATE", date.newDate()); //before:new Date()
		Long N_TRANSACTIONNO = Long.parseLong(receiptsDetailForm.get("N_TRANSACTIONNO").toString());
		//receiptsDetailForm.put("C_CLNTCODE", arg1);
		
		try {
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			int count = this.searchReceiptsDetailByInvoice(receiptsDtl.getN_RefNo(), receiptsDtl.getC_InvoiceNo());
			if (count > 0) {
				jsonData.put("status", "Record with same ref no and invoice already exists!");
				return jsonData;
			}
			boolean success = rDetailDAO.addReceiptsDtl(receiptsDetailForm);
			
			//Ledger Entries
//			SubHeaderService JS = SubHeaderService.getInstance();
//			if(receiptsDetailForm.get("remBalance")!=null){
//				//FULL PAYMENT
//				if(receiptsDetailForm.get("remBalance").toString().contentEquals("0")){//FULL PAYMENT
//					System.out.println("FULL PAYMENT");
//					JS.createLedgerlEntry(receiptsDetailForm,  "110400202000" , receiptsDetailForm.get("N_RECEIPTAMT"), "N_DEBIT",N_TRANSACTIONNO);
//					JS.createLedgerlEntry(receiptsDetailForm,  "110602201000" , receiptsDetailForm.get("N_RECEIPTAMT"), "N_CREDIT",N_TRANSACTIONNO);	
//				}
//				else{//Partial Payment
//					System.out.println("PARTIAL PAYMENT");
//					JS.createLedgerlEntry(receiptsDetailForm,  "110400202000" , receiptsDetailForm.get("N_RECEIPTAMT"), "N_DEBIT",N_TRANSACTIONNO);
//					JS.createLedgerlEntry(receiptsDetailForm,  "110602201000" , receiptsDetailForm.get("N_RECEIPTAMT"), "N_CREDIT",N_TRANSACTIONNO);
//					//JS.createLedgerlEntry(receiptsDetailForm,  "255001101000" , receiptsDetailForm.get("remBalance"), "N_CREDIT",N_TRANSACTIONNO);
//				}
//			}
			
			if (success) {				
				String userID = receiptsDetailForm.get("C_USERID").toString();				
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "I", "RECEIPTSDTL", receiptsDtl.toString());
												
				jsonData.put("status", "Receipts Detail Added");				
			}
		}
		catch (Exception e) {
			jsonData.put("status", "exception: " + e.getMessage());
			e.printStackTrace();
		}
		return jsonData;
	}
	
	public Map updateReceiptsDetail(Map receiptsDetailForm) {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map jsondata = new HashMap();		
		try {			
			ServiceUtility.viewUserParameters(receiptsDetailForm);			
			receiptsDetailForm.put("N_ORIGINVOICEAMT", receiptsDetailForm.get("N_AMTINV").toString().replaceAll(",", ""));
			receiptsDetailForm.put("N_RECEIPTAMT", receiptsDetailForm.get("N_RECEIPTAMT").toString().replaceAll(",", ""));
			ReceiptsDtl rDetail = ReceiptsDtlUtility.getInstance().toObject(receiptsDetailForm);			
			
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");						
			boolean success = rDetailDAO.updateReceiptsDetail(receiptsDetailForm);
										
			if(success){
				String c_Status = (String) receiptsDetailForm.get("C_TYPE");
				String userID = (String) receiptsDetailForm.get("C_USERID");
				String nRefNo = receiptsDetailForm.get("N_REFNO") != null ? receiptsDetailForm.get("N_REFNO").toString().trim(): null; 
				AuditService as = AuditService.getInstance();
				
				if (receiptsDetailForm.get("receiptType").toString().trim().equals("2") || receiptsDetailForm.get("receiptType").toString().trim().equals("3")) {
					INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
					log.info("C_STATUS" + c_Status);
					if (c_Status.trim().equals("1")) {
						c_Status = "5";
					} else if (c_Status.trim().equals("2")){
						c_Status = "4";
					}
					String invoiceStr = "('" + rDetail.getC_InvoiceNo() + "')";
					String invoiceNoStr = "('" + rDetail.getN_InvNo() + "')";
					boolean updateInvoiceStat = invoiceDAO.updateInvoiceStatusByInvNo(invoiceNoStr, c_Status,nRefNo,date.newDate()); //before: new Date() 
					if (updateInvoiceStat) {						
						as.addAudit(userID, "U", "INVOICE", "INVOICES: " + invoiceStr + "STATUS: " + c_Status);
					}
				}
				
				
				
				as.addAudit(userID, "U", "RECEIPTSDTL", rDetail.toString());
				
				jsondata.put("status","Update Successful ...");
			}
			else{				
				jsondata.put("status","Update ReceiptsDtl Failed ... " + success);				
			}
						
		}
		catch (Throwable x) {			
			jsondata.put("status","Update ReceiptsDtl Failed ... " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
				
		return jsondata;
	}
	
	public Map searchReceiptsDetailByCode(Map receiptsDetailForm) {
		Map jsondata = new HashMap();
		String totalRecords = "";
		String n_RefNo = "";
		
		try {
			log.info("--->> searchGroup SERVICE ...");		
			ServiceUtility.viewUserParameters(receiptsDetailForm);
			
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			n_RefNo = (String) receiptsDetailForm.get("N_REFNO");
 			totalRecords = rDetailDAO.getTotalRecordsReceiptDetail(n_RefNo);			
			receiptsDetailForm = ServiceUtility.addPaging(receiptsDetailForm,totalRecords);			
			List lResult = rDetailDAO.searchReceiptsDetailByCode(receiptsDetailForm);
						
			log.info("--->> searchReceiptsDetail RECORDS: "+lResult.size());
			if((lResult!=null) && (lResult.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lResult, ((String)receiptsDetailForm.get("records")),((String)receiptsDetailForm.get("page")),((String)receiptsDetailForm.get("total")));
			}else{				
				jsondata.put("status","searchBank Failed ... ");
			}
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;	
	}
	
	
	public Map searchReceiptsDetailByRefNo(Map receiptsDetailForm) {
		Map jsondata = new HashMap();
		String totalRecords = "";
		
		try {
			log.info("--->> searchGroup SERVICE ...");		
			ServiceUtility.viewUserParameters(receiptsDetailForm);
			
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");			
			List lResult = rDetailDAO.searchReceiptsDetailByCode(receiptsDetailForm);
						
			log.info("--->> searchReceiptsDetail RECORDS: "+lResult.size());
			if((lResult!=null) && (lResult.size()>0)){
				jsondata.put("returnData", lResult);
				jsondata.put("status", "successful");
			}else{				
				jsondata.put("status","No Data Found.");
			}
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;	
	}
	
	public int searchReceiptsDetailByInvoice(int n_RefNo, String c_InvoiceNo) {
		Map jsondata = new HashMap();		
		int count = 0;
		try {
			log.info("--->> searchReceiptsDetailByInvoice SERVICE ...");			
			
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			if (n_RefNo > 0) {
				count = rDetailDAO.searchReceiptsDetailByInvoice(n_RefNo, c_InvoiceNo);	
			} else {
				count = rDetailDAO.searchReceiptsDetailByInvoiceOnly(c_InvoiceNo);
			}
		}
		catch(Throwable x) {			
			x.printStackTrace();
		}	
		return count;
	}
	//testing CVG
	public Map updateStatusByInvoice(Map receiptsDetailForm) {
		 FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map jsondata = new HashMap();		
		try {			
			ServiceUtility.viewUserParameters(receiptsDetailForm);					
			
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			StringBuffer invoices = new StringBuffer("(");
			//invoices.append((String)receiptsDetailForm.get("C_INVOICE"));
			invoices.append((String)receiptsDetailForm.get("N_INVNO"));
			String invoiceStr = invoices.toString();
			invoiceStr = invoiceStr.substring(0, invoiceStr.length()-1) + ")";
			
			StringBuilder invNos = new StringBuilder("(");
			invNos.append((String) receiptsDetailForm.get("N_INVNO"));
			String invNoStr = invNos.toString();
			invNoStr = invNoStr.substring(0, invNoStr.length() - 1) + ")";
			String nRefNo = receiptsDetailForm.get("N_REFNO") != null ? receiptsDetailForm.get("N_REFNO").toString().trim(): null; 
			//check this one
			String invoiceNo = (String)receiptsDetailForm.get("N_INVNO");
			
			String invNo = (String) receiptsDetailForm.get("N_INVNO");
			//
			log.info("C_INVOICENO > " + invoiceStr);
						
			receiptsDetailForm.put("C_INVOICENO", invoiceNo); //changed from invoiceStr to invoiceNo
			receiptsDetailForm.put("N_INVNO", invNo);//changed from invNoStr to invNo
			
			boolean success = rDetailDAO.updateStatusByInvoice(receiptsDetailForm);			
			System.out.println("success: " + success);			
			if(success){
				boolean updatefullypaid = rDetailDAO.updateCheckTypeByInvoiceNoFullyPaidNew(receiptsDetailForm);	//rdc 03262010
				String rceiptType = ((String) receiptsDetailForm.get("receiptType")).trim();
				String cType = ((String) receiptsDetailForm.get("C_TYPE")).trim();
				String receiptType = receiptsDetailForm.get("C_RECEIPTTYPE") != null ? receiptsDetailForm.get("C_RECEIPTTYPE").toString().trim() : ""; 
				InvoiceService invoiceService = InvoiceService.getInstance();
				//update fully paid date if type = fullypaid and not check payment; update even if check payment
				log.info("CTYPE>>>>>>>>>>" + cType);
				if (cType.equals("1")){
					log.info("updateFullyPaidDateByCodeNew");
					invoiceService.updateInvoiceFullyPaidDateByCodeNew(invNo, date.newDate()); //changed invNoStr from to invNo //before: new Date()
				}
				//set fully paid date to null if type = partial payment and not check payment
				//update even if check payment
				//if (cType.equals("2") && !receiptType.equals("1")){
				if (cType.equals("2")){
					log.info("updateFullyPaidDateByCodeNew");
					invoiceService.updateInvoiceFullyPaidDateByCodeNew(invNo, null); //changed invNoStr from to invNo
				}
				
				
				String userID = (String) receiptsDetailForm.get("C_USERID");
				String c_Status = (String) receiptsDetailForm.get("C_TYPE");
				
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "RECEIPTSDTL", "CHECKTYPE OF INVOICES: " + invNo + "STATUS: " + c_Status); //changed invNoStr from to invNo
				
				log.info("RECEIPTTYPE::: " + rceiptType);
				//update invoice status if not check payment
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				if (rceiptType.equals("1") || rceiptType.equals("2") || rceiptType.equals("3") || rceiptType.equals("4")) {
					
					if (c_Status.trim().equals("1")) {
						c_Status = "5";
						log.info("here1 : " + c_Status );
					} else if (c_Status.trim().equals("2")){
						c_Status = "4";
						log.info("here2 : " + c_Status);
					}
					else {
						log.info("here3" + c_Status.trim());
					}
					boolean updateInvoiceStat = invoiceDAO.updateInvoiceStatusByInvNoNew(invNo, c_Status,nRefNo,date.newDate()); //invNoStr from to invNo //before:new Date() 
					if (updateInvoiceStat) {						
						as.addAudit(userID, "U", "INVOICE", "INVOICES: " + invNo + "STATUS: " + c_Status); //invNoStr from to invNo
					}
				}
				else {
					log.info("receiptType: " + receiptsDetailForm.get("receiptType").toString().trim());
				}
				//update all fully paid invoices --- rdc04202010
				c_Status = "5";
				boolean updateInvoiceFullyPaid = invoiceDAO.updateInvoiceFullyPaidNew(invNo, c_Status,date.newDate()); //invNoStr from to invNo //before: new Date()
				if (updateInvoiceFullyPaid) {						
					as.addAudit(userID, "U", "INVOICE", "INVOICES: " + invNo + "STATUS: " + c_Status); //invNoStr from to invNo
				}
				
				jsondata.put("status","Update Successful ...");
			}
			else{				
				jsondata.put("status","Update ReceiptsDtl Failed ... " + success);				
			}			
			
		}
		catch (Throwable x) {			
			jsondata.put("status","Update ReceiptsDtl Failed ... " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
				
		return jsondata;
	}
		
	//end
	
	public Map updateCheckTypeByInvoice(Map receiptsDetailForm) {
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map jsondata = new HashMap();		
		try {			
			ServiceUtility.viewUserParameters(receiptsDetailForm);					
			
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			StringBuffer invoices = new StringBuffer("(");
			//invoices.append((String)receiptsDetailForm.get("C_INVOICE"));
			invoices.append((String)receiptsDetailForm.get("N_INVNO"));
			String invoiceStr = invoices.toString();
			invoiceStr = invoiceStr.substring(0, invoiceStr.length()-1) + ")";
			
			StringBuilder invNos = new StringBuilder("(");
			invNos.append((String) receiptsDetailForm.get("N_INVNO"));
			String invNoStr = invNos.toString();
			invNoStr = invNoStr.substring(0, invNoStr.length() - 1) + ")";
			String nRefNo = receiptsDetailForm.get("N_REFNO") != null ? receiptsDetailForm.get("N_REFNO").toString().trim(): null; 
			log.info("C_INVOICENO > " + invoiceStr);
						
			receiptsDetailForm.put("C_INVOICENO", invoiceStr);
			receiptsDetailForm.put("N_INVNO", invNoStr);
			
			boolean success = rDetailDAO.updateCheckTypeByInvoiceNo(receiptsDetailForm);			
			System.out.println("success: " + success);			
			if(success){
				boolean updatefullypaid = rDetailDAO.updateCheckTypeByInvoiceNoFullyPaid(receiptsDetailForm);	//rdc 03262010
				String rceiptType = ((String) receiptsDetailForm.get("receiptType")).trim();
				String cType = ((String) receiptsDetailForm.get("C_TYPE")).trim();
				String receiptType = receiptsDetailForm.get("C_RECEIPTTYPE") != null ? receiptsDetailForm.get("C_RECEIPTTYPE").toString().trim() : ""; 
				InvoiceService invoiceService = InvoiceService.getInstance();
				//update fully paid date if type = fullypaid and not check payment; update even if check payment
				log.info("CTYPE>>>>>>>>>>" + cType);
				if (cType.equals("1")){
					log.info("updateFullyPaidDateByCode");
					invoiceService.updateInvoiceFullyPaidDateByCode(invNoStr, date.newDate()); //before: new Date()
				}
				//set fully paid date to null if type = partial payment and not check payment
				//update even if check payment
				//if (cType.equals("2") && !receiptType.equals("1")){
				if (cType.equals("2")){
					log.info("updateFullyPaidDateByCode");
					invoiceService.updateInvoiceFullyPaidDateByCode(invNoStr, null);
				}
							
				String userID = (String) receiptsDetailForm.get("C_USERID");
				String c_Status = (String) receiptsDetailForm.get("C_TYPE");
				
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "RECEIPTSDTL", "CHECKTYPE OF INVOICES: " + invNoStr + "STATUS: " + c_Status);
				
				log.info("RECEIPTTYPE::: " + rceiptType);
				//update invoice status if not check payment
				INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
				if (rceiptType.equals("1") || rceiptType.equals("2") || rceiptType.equals("3") || rceiptType.equals("4")) {
					
					if (c_Status.trim().equals("1")) {
						c_Status = "5";
						log.info("here1 : " + c_Status );
					} else if (c_Status.trim().equals("2")){
						c_Status = "4";
						log.info("here2 : " + c_Status);
					}
					else {
						log.info("here3" + c_Status.trim());
					}
					boolean updateInvoiceStat = invoiceDAO.updateInvoiceStatusByInvNo(invNoStr, c_Status,nRefNo,date.newDate()); //before: new Date() 
					if (updateInvoiceStat) {						
						as.addAudit(userID, "U", "INVOICE", "INVOICES: " + invNoStr + "STATUS: " + c_Status);
					}
				}
				else {
					log.info("receiptType: " + receiptsDetailForm.get("receiptType").toString().trim());
				}
				//update all fully paid invoices --- rdc04202010
				c_Status = "5";
				boolean updateInvoiceFullyPaid = invoiceDAO.updateInvoiceFullyPaid(invNoStr, c_Status,date.newDate()); //before: new Date() 
				if (updateInvoiceFullyPaid) {						
					as.addAudit(userID, "U", "INVOICE", "INVOICES: " + invNoStr + "STATUS: " + c_Status);
				}
				
				jsondata.put("status","Update Successful ...");
			}
			else{				
				jsondata.put("status","Update ReceiptsDtl Failed ... " + success);				
			}			
			
		}
		catch (Throwable x) {			
			jsondata.put("status","Update ReceiptsDtl Failed ... " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
				
		return jsondata;
	}
	
	public List searchReceiptsDetailByCodeList(int n_refNo) {
		List lResult = new ArrayList();
		
		try {
			Map receiptsDetailForm = new HashMap();
			receiptsDetailForm.put("N_REFNO", new Integer(n_refNo));
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");				
			lResult = rDetailDAO.searchReceiptsDetailByCode(receiptsDetailForm);
			
		}
		catch(Throwable x) {			
			x.printStackTrace();
			return null;
		}
		
		return lResult;
	}
	
	public boolean updateReceiptDetails(int refNo, double totalReceiptAmount, double totalInvoiceAmount) {
		boolean result = false;
		try {
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			
			Map map = new HashMap();
			map.put("N_REFNO",refNo);
			List lResult = rDetailDAO.searchReceiptsDetailByCode(map);
			
			if (lResult != null && lResult.size() > 0) {
				for (int i = 0; i < lResult.size(); i++) {
					Map m = new HashMap();
					m = (Map)lResult.get(i);
					int invNo = Integer.parseInt(m.get("N_INVNO").toString());
					double invoiceAmount = Double.parseDouble(m.get("N_AMTINV").toString());					
					double receiptAmount = (invoiceAmount / totalInvoiceAmount) * totalReceiptAmount;
					
					Map receiptDetailForm = new HashMap();
					receiptDetailForm.put("N_REFNO", refNo);
					receiptDetailForm.put("N_INVNO", invNo);
					receiptDetailForm.put("N_RECEIPTAMT", receiptAmount);
					
					result = rDetailDAO.updateReceiptDetailAmount(receiptDetailForm);
					
					StringBuilder sb = new StringBuilder();
					sb.append("N_REFNO=").append(refNo);
					sb.append("N_INVNO=").append(invNo);
					sb.append("N_RECEIPTAMT=").append(receiptAmount);
					
					AuditService as = AuditService.getInstance();
					as.addAudit("-", "U", "RECEIPTDTL", sb.toString());
				}
			}
			return result;
		}
		catch (Exception e) {
			e.printStackTrace();			
		}
		return result;
	}
	
	public Map getTotalRecordsReceiptDetail(Map m) {
		Map jsonData = new HashMap();
		ServiceUtility.viewUserParameters(m);		
		try {
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
			String nRefNo = m.get("N_REFNO") != null ? m.get("N_REFNO").toString().trim(): null; 
			String totalRec = rDetailDAO.getTotalRecordsReceiptDetail(nRefNo);
			log.info("totalRecords: " + totalRec);
			
			jsonData.put("result", totalRec);
		}
		catch (Exception e) {
			jsonData.put("result", "Get Total Records of Receipt Detail Failed.");
		}
		return jsonData;
	}
	
	public Map getTotalReceiptAmount(Map m) {
		Map jsonData = new HashMap();
		ServiceUtility.viewUserParameters(m);
		try {
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO) Persistence.getDAO("ReceiptsDtlDAO");
			double totalAmount = rDetailDAO.getTotalReceiptAmount(m);
			jsonData.put("result", totalAmount);
		}
		catch (Exception e) {
			jsonData.put("result", "Get Total Receipt Amount Failed.");
		}
		return jsonData;
	}
	
	public Map getTotalReceiptAmountWithCN(Map m) {
		Map jsonData = new HashMap();
		ServiceUtility.viewUserParameters(m);
		try {
			ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO) Persistence.getDAO("ReceiptsDtlDAO");
			double totalAmount = rDetailDAO.getTotalReceiptAmountWithCN(m);
			jsonData.put("result", totalAmount);
		}
		catch (Exception e) {
			jsonData.put("result", "Get Total Receipt Amount Failed.");
		}
		return jsonData;
	}
	
	//public static void main(String[] args) {
		/*
		ReceiptsDtlService rd = ReceiptsDtlService.getInstance();
		Map receipts = new HashMap();
		receipts.put("C_INVOICE", "1232,");
		receipts.put("C_TYPE", "1");
		receipts.put("N_REFNO", "125");
		receipts.put("receiptType", "1");
		rd.updateCheckTypeByInvoice(receipts);
		*/		
}
