package com.bdo.factor.service;

import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.ReceiptsDtlOther;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.ReceiptsDtlOtherDAO;


public class ReceiptsDtlOtherService {
	private static Logger log = Logger.getLogger(ReceiptsDtlOtherService.class);
	private static ReceiptsDtlOtherService thisReceiptsDtlOtherService = new ReceiptsDtlOtherService();
	//private ReceiptsDtlOtherDAO _ReceiptsDtlOtherDAO=(ReceiptsDtlOtherDAO)Persistence.getDAO("ReceiptsDtlOtherDAO");
	public static ReceiptsDtlOtherService getInstance(){
		return thisReceiptsDtlOtherService;
	}
	
	public String insertReceiptsDtlOther(ReceiptsDtlOther m) {
		ReceiptsDtlOtherDAO _ReceiptsDtlOtherDAO=(ReceiptsDtlOtherDAO)Persistence.getDAO("ReceiptsDtlOtherDAO");
		 return _ReceiptsDtlOtherDAO.insertReceiptsDtlOther(m);
	}
	
	public Double sumAllDtlOther(Long refNo){
		ReceiptsDtlOtherDAO _ReceiptsDtlOtherDAO=(ReceiptsDtlOtherDAO)Persistence.getDAO("ReceiptsDtlOtherDAO");
		return _ReceiptsDtlOtherDAO.sumAllDtlOther(refNo);
	}
	
	public Double sumAllDtlOtherDC(Long refNo){
		ReceiptsDtlOtherDAO _ReceiptsDtlOtherDAO=(ReceiptsDtlOtherDAO)Persistence.getDAO("ReceiptsDtlOtherDAO");
		return _ReceiptsDtlOtherDAO.sumAllDtlOtherDC(refNo);
	}
	public Double sumAllDtlOtherPenalty(Long refNo){
		ReceiptsDtlOtherDAO _ReceiptsDtlOtherDAO=(ReceiptsDtlOtherDAO)Persistence.getDAO("ReceiptsDtlOtherDAO");
		return _ReceiptsDtlOtherDAO.sumAllDtlOtherPenalty(refNo);
	}
}
