package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.bdo.factor.dao.ReportsDAO;
import com.bdo.factor.beans.CnType;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.AccountOfficerDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.CNDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.CurrencyDAO;
import com.bdo.factor.dao.CustomerDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dataSource.InvoiceDAO;
import com.bdo.factor.util.CNTypeUtility;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.InvoiceUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class ReportsService {
	private static Logger log = Logger.getLogger(InvoiceService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static ReportsService thisReportsService = new ReportsService();
	
	private ReportsService() { }

	public static ReportsService getInstance() {
		
		return thisReportsService;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	

	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchReports(Map reportsForm){
	
			
			log.info("--->> searchReports SERVICE ...");
			
			Map jsondata = new HashMap();
			List records = new ArrayList();
			String totalRecords = "";
			String c_BranchCode = "";
			
			try{
				
				ServiceUtility.viewUserParameters(reportsForm);
				c_BranchCode = (String) reportsForm.get("C_BRANCHCODE");
										
				ReportsDAO reportsDAO = (ReportsDAO)Persistence.getDAO("ReportsDAO");				
				totalRecords = reportsDAO.getTotalReports(c_BranchCode);	
				
				reportsForm = ServiceUtility.addPaging(reportsForm,totalRecords);			
				
				records = reportsDAO.searchReports(reportsForm);	
			
				ServiceUtility.viewUserParameters(reportsForm);
							
				log.info("--->> searchReports RECORD-SIZE: "+records.size());
				
				if((records!=null) && (records.size()>0)){						
					jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)reportsForm.get("records")),((String)reportsForm.get("page")),((String)reportsForm.get("total")));
				}else{
					jsondata.put("status","Search Reports Failed ... ");
				}
			
			}catch(Throwable x){
				jsondata.put("status",x.getMessage());
				x.printStackTrace();
			}	
			
			return jsondata;
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////


}
