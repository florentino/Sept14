package com.bdo.factor.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.CC;
import com.bdo.factor.beans.Client;
import com.bdo.factor.beans.CreditNote;
import com.bdo.factor.beans.MonthlyBalances;
import com.bdo.factor.beans.PostDate;
import com.bdo.factor.beans.User;
import com.bdo.factor.dao.CreditNoteDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.PostDateDAO;
import com.bdo.factor.dao.ReceiptsDtlDAO;
import com.bdo.factor.dataSource.ClientDAO;
import com.bdo.factor.dataSource.MonthlyBalancesDAO;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.DateUtils;
import com.bdo.factor.util.ServiceUtility;
@SuppressWarnings("unchecked")
public class PostDateService {
	private static Logger log = Logger.getLogger(PostDateService.class);

	private static PostDateService postDateInstance = new PostDateService();

	private PostDateService() { }

	public static PostDateService getInstance() {
		return postDateInstance;
	}
	@SuppressWarnings("unchecked")
	public Map initializeProcess(Map postDateForm) {	
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		Map jsonData = new HashMap();
		Date currentDate = null;
		String endDate = null;
		Map newData = new HashMap();
		
		if (postDateForm.get("isAdmin").toString().equals("0")) {
			currentDate = DateHelper.parse(DateHelper.format(date.newDate())); //before:new java.util.Date()
		}
		else {
			currentDate = postDateForm.get("D_TRANSDATE_ADMIN") != null ? DateHelper.parse(postDateForm.get("D_TRANSDATE_ADMIN").toString()) : new java.util.Date(); 
		}
		StringBuilder strRefNo = new StringBuilder();
		StringBuilder strRefNoRef = new StringBuilder();
		StringBuilder strRefNoForClearing = new StringBuilder();
		double totalReceiptAmount = 0;
		double totalOPAmount = 0;

		PostDateDAO postDateDAO = (PostDateDAO)Persistence.getDAO("PostDateDAO");
		String c_BranchCode = postDateForm.get("C_BRANCHCODE").toString();

		Date previousDate = DateUtils.getInstance().getPreviousBusinessDay(currentDate, c_BranchCode);
		String prevDate = DateHelper.format(previousDate);

		Date dayEnd = null;
		String dInitialize = null;
		boolean isNew = false;
		//get Processing Dates
		PostDate pDate = postDateDAO.searchProcessingDates(c_BranchCode);
		if (pDate == null ) {
			postDateDAO.insertPostDate(postDateForm);	
			isNew = true;
		}
		else {
			dayEnd = pDate.getD_DayEnd();
			dInitialize = pDate.getD_Initialize() != null ? DateHelper.format(pDate.getD_Initialize()) : null;
		}
		if (dayEnd != null) {
			endDate = DateHelper.format(dayEnd);
		}

		System.out.println("previousDate: " + previousDate);
		System.out.println("dayEnd: " + dayEnd);
		
		String currDate = DateHelper.format(currentDate);
		if (isNew == false && dInitialize.equals(currDate)) {
			jsonData.put("status", "Error. Initialization process has already been executed.");
			return jsonData;
		}
		
		if (dInitialize != null && dayEnd != null && isNew == false) {
			Calendar iniDate = new GregorianCalendar();
			iniDate.setTime(DateHelper.parse(dInitialize));
			
			Calendar endDte = new GregorianCalendar();
			endDte.setTime(dayEnd);		
			
			if (iniDate.after(endDte)) {
				jsonData.put("status", "Cannot proceed with Initialization Process, Day End Transaction has not yet completed.");
				return jsonData;
			}
			
			/*if (!prevDate.equals(endDate) && isNew == false) {
				Calendar prevDateCal = new GregorianCalendar();
				prevDateCal.setTime(DateHelper.parse(prevDate));				
				
				/*if (prevDateCal.after(endDte)) {			
					jsonData.put("status", "2Cannot proceed with Initialization Process, Day End process not yet completed.");
					return jsonData;
				}
			}*/
		
		}		
			Date monthEnd = DateUtils.getInstance().getMonthEnd(currentDate, c_BranchCode);
			//Calendar moCal = new GregorianCalendar();
			//moCal.setTime(monthEnd);
			//moCal.add(Calendar.DATE, +1);
			//Date afterMoEnd = moCal.getTime();
			
			Date afterMoEnd = DateUtils.getInstance().getNextBusinessDay(monthEnd, c_BranchCode);

			//&& !(pDate.getD_MonthEnd().equals(monthEnd))
			if (isNew==false && afterMoEnd.equals(currentDate) && pDate.getD_MonthEnd() != null )  {
				jsonData.put("status", "Error. Cannot proceed with Initialization Process, Month End process has not yet completed.");
				return jsonData;
			}		
	///////////REVERSAL OF MONTHLY DC_ACCRUAL
				SimpleDateFormat SDF = new SimpleDateFormat("yyyy/MM/dd");
				SimpleDateFormat UDF = new SimpleDateFormat ("yyyy-MM");
				Calendar myDate = Calendar.getInstance();
				PostDateDAO PDD = (PostDateDAO)Persistence.getDAO("PostDateDAO");
				
				try {
					myDate.clear();
					myDate.setTime(UDF.parse(UDF.format(currentDate)));
					log.info(myDate);
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				postDateForm.put("month", UDF.format(currentDate).split("-")[1]);
				postDateForm.put("year", UDF.format(currentDate).split("-")[0]);
				String newDate = Integer.parseInt(postDateForm.get("month").toString())+1+"/"+"1"+"/"+postDateForm.get("year");
				postDateForm.put("fromDate", newDate);
				postDateForm.put("D_TRANSACTIONDATE", SDF.format(date.newDate())); //before: new Date()
				 
				
				
				
				if(!(postDateDAO.isInitialized(postDateForm)>0)) {
					//postDateDAO.deleteInitializedEntry(postDateForm);
				
				List<Map> clientList= PDD.getClientProceeds(postDateForm);
				
				//SUBHEADER
				for(int loop=0;loop<clientList.size();loop++){
					Map p = (Map) clientList.get(loop);
					postDateForm.put("N_Amount", p.get("N_Amount"));
					//postDateForm.put("proceedsDC", p.get("proceedsDC"));
					postDateForm.put("C_CLNTCODE", p.get("C_ClientCode"));
					postDateForm.put("C_Type", "A");
					//postDateForm.put("interest", postDateDAO.getPDInterest(p));
					postDateForm.put("C_TransactionType","I");
					SubHeaderService SHS = SubHeaderService.getInstance();
					Long ref = SHS.createSubHeader(postDateForm, "REVERSAL OF MONTHLY DC ACCRUAL OF INCOME", postDateForm.get("D_TRANSACTIONDATE").toString(), "");
					p.put("ref", ref);
					PDD.setAccrualLedger(p);
					//SHS.createLedgerEntry2(postDateForm, "Reversal-DC-Accrual", ref);
				}
				}
	///////////END
			//get Receipts For Clearing
			ReceiptsHeaderService receiptsSvc = ReceiptsHeaderService.getInstance();

			List lResult = receiptsSvc.searchReceiptsForClearing(DateHelper.parse(currDate), c_BranchCode);
			log.info("lResult: " + lResult);
			Set sClntCode = new HashSet();
			for (int i = 0; i < lResult.size(); i++) {
				Map m = (HashMap) lResult.get(i);
				if (m.get("C_STATUS").toString() != null && m.get("C_STATUS").toString().trim().equalsIgnoreCase("1")) {
					strRefNoForClearing.append(m.get("N_REFNO").toString()).append(",");
				}
				else {
					strRefNoRef.append(m.get("N_REFNO").toString()).append(",");
				}
				strRefNo.append(m.get("N_REFNO").toString()).append(",");
				sClntCode.add(m.get("C_CLNTCODE").toString());
			}

			String nRefNos = strRefNo.toString();			
			if (nRefNos != null && !nRefNos.trim().equals("")) {
				nRefNos = nRefNos.substring(0, nRefNos.length() - 1);
				
				//update b_Cleared from 0 to 1
				boolean updateBCleared = receiptsSvc.updateBClearedByBatch("1","(" + nRefNos + ")");
				
				String nRefNosForClearing = strRefNoForClearing.toString();				
				//update Receipt Status from 1- clearing to 2- cleared
				if (nRefNosForClearing != null && !nRefNosForClearing.trim().equals("")) {
					nRefNosForClearing = nRefNosForClearing.substring(0, nRefNosForClearing.length() - 1);
					boolean updateReceiptStatus = receiptsSvc.updateReceiptsStatusByBatch("2", "(" + nRefNosForClearing + ")");
				}							
				
				//update CN status from 1-pending to 2-applied
				CreditNoteDAO cnDAO = (CreditNoteDAO) Persistence.getDAO("CreditNoteDAO");
				Map creditNoteForm = new HashMap();
				creditNoteForm.put("C_STATUS", "2");
				creditNoteForm.put("N_REFNO", "(" + nRefNos + ")");
				
				
				//cnDAO.updateCreditNoteStatusByBatch(creditNoteForm);
				if(cnDAO.updateCreditNoteStatusByBatch(creditNoteForm)){
					
					try{
						AuditService as = AuditService.getInstance();
						newData = ServiceUtility.removeNulls(creditNoteForm);
						CreditNote cn = new CreditNote(newData);
						as.addAudit(newData.get("C_USERID").toString(),"U","CREDITNOTE",cn.toString());

					}catch(Throwable x){
						x.printStackTrace();
					}
				}
				
				
				//update Client FIU 
				Iterator sClientIterator = sClntCode.iterator();
				while (sClientIterator.hasNext()) {				
					String clientCode = (String) sClientIterator.next();
					for (int i = 0; i < lResult.size(); i++) {
						Map mapAmount = (HashMap) lResult.get(i);
						if (clientCode.equalsIgnoreCase(mapAmount.get("C_CLNTCODE").toString())) { 
							double nreceiptAmount = mapAmount.get("N_RECEIPTAMT") != null ? Double.parseDouble(mapAmount.get("N_RECEIPTAMT").toString()) : 0;
							double opAmount =  mapAmount.get("N_OPAMT") != null? Double.parseDouble(mapAmount.get("N_OPAMT").toString()): 0 ;
							System.out.println("nReceiptAmount: " + nreceiptAmount);
							totalReceiptAmount = totalReceiptAmount + nreceiptAmount;
							totalOPAmount = totalOPAmount + opAmount;						
						}
					}
					log.info("totalReceiptAmount: " + totalReceiptAmount);
					log.info("totalOPAmount: " + totalOPAmount);
					
					Map receiptsForm = new HashMap();
					receiptsForm.put("C_CLNTCODE", clientCode);
					receiptsForm.put("N_RECEIPTAMT", totalReceiptAmount + "");
					receiptsForm.put("N_OPAMT", totalOPAmount + "");
					
					receiptsForm.put("DESCRIPTION", "Initialize Process For " + currentDate);

					boolean updateFIUTrans = ClientService.getInstance().updateFIUTransAmount(receiptsForm);
					totalReceiptAmount = 0;
					totalOPAmount = 0;
					
				}

				//update Invoice from 3- released advances to 4- partially paid or 5- fully paid/for refund
				//** no need to update. already done during receipts transaction ** //
				/*log.info("update Invoice Status...");
				ReceiptsDtlDAO rDetailDAO = (ReceiptsDtlDAO)Persistence.getDAO("ReceiptsDtlDAO");
				List lInvoices = rDetailDAO.searchReceiptsDetailByBatch("(" + nRefNos + ")");

				StringBuilder strInvoicesCType1 = new StringBuilder();			
				StringBuilder strInvoicesCType2 = new StringBuilder();

				String invoicesCType1 = "";
				String invoicesCType2 = "";
				boolean updateInvStat1 = false;
				boolean updateInvStat2 = false;
				boolean updatePaidDate = false;

				for (int i = 0; i < lInvoices.size(); i++) {
					Map mapInvoices = (HashMap) lInvoices.get(i);
					if (mapInvoices.get("C_TYPE").equals("1")) {					
						strInvoicesCType1.append(mapInvoices.get("C_INVOICENO").toString()).append(",");					
					}
					else if(mapInvoices.get("C_TYPE").equals("2")) {
						strInvoicesCType2.append(mapInvoices.get("C_INVOICENO").toString()).append(",");
					}				
				}

				if (strInvoicesCType1 != null && strInvoicesCType1.toString().trim().length() > 0) {
					invoicesCType1 = strInvoicesCType1.toString();
					invoicesCType1 = invoicesCType1.substring(0,invoicesCType1.length() - 1);
					invoicesCType1 = "(" + invoicesCType1 + ")";

					INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
					updateInvStat1 = invoiceDAO.updateInvoiceStatusByCode(invoicesCType1, "5");
					updatePaidDate = invoiceDAO.updateInvoiceFullyPaidDateByCode(invoicesCType1, currentDate);
				}

				if (strInvoicesCType2 != null && strInvoicesCType2.toString().trim().length() > 0) {
					invoicesCType2 = strInvoicesCType2.toString();
					invoicesCType2 = invoicesCType2.substring(0,invoicesCType2.length() - 1);
					invoicesCType2 = "(" + invoicesCType2 + ")";

					INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
					updateInvStat2 = invoiceDAO.updateInvoiceStatusByCode(invoicesCType2, "4");
				}*/

				jsonData.put("status", "Initialization Process Completed.");
			}
			else {				
				jsonData.put("status", "Initialization Process Completed. No Receipts Found.");				
			}

			Map updateDInitializeMap = new HashMap();
			updateDInitializeMap.put("C_BRANCHCODE", c_BranchCode);
			updateDInitializeMap.put("D_INITIALIZE", currentDate);
			updateDInitializeMap.put("C_USERID", postDateForm.get("C_USERID"));
			//postDateDAO.updateDInitialize(updateDInitializeMap);
			if(postDateDAO.updateDInitialize(updateDInitializeMap)){
				
				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(updateDInitializeMap);
					PostDate cn = new PostDate(newData);
					as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());

				}catch(Throwable x){
					x.printStackTrace();
				}				
				
			}
				

		return jsonData;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map monthEndProcess(Map map){

		Calendar myDate = Calendar.getInstance();
		Calendar c = DateUtils.getMonthEndDate(map);
		Map resultMap = new HashMap();
		log.info(c.getTime());
		log.info(" date "+c.getTime());
		//c.add(Calendar.DATE, c.getActualMaximum(Calendar.DAY_OF_MONTH));
		Map jsonData = new HashMap();
		//Date date = DateUtils.getInstance().getPreviousBusinessDay(c.getTime(), map.get("C_BRANCHCODE").toString());
		Date date = DateHelper.parse(DateHelper.format(c.getTime()));

		log.info("Actual Date to be process "+date);
		PostDateDAO postDateDAO = (PostDateDAO)Persistence.getDAO("PostDateDAO");

		Map postData = (HashMap)(((List)postDateDAO.getPostDateByBranchCode(map)).get(0));
		Date monthEnd=null;
		Date dayEnd=null;
		Date initialize=null;
		Date dayEndTesting=null;

		if(postData.get("D_INITIALIZE")!=null){
			initialize= (Date)postData.get("D_INITIALIZE");
			initialize = DateHelper.parse(DateHelper.format(initialize));
		}		
		if(postData.get("D_DAYEND")!=null){
			dayEnd= (Date)postData.get("D_DAYEND");
			dayEnd = DateHelper.parse(DateHelper.format(dayEnd));
		}		
		if(postData.get("D_MONTHEND")!=null){
			monthEnd= (Date)postData.get("D_MONTHEND");
			monthEnd = DateHelper.parse(DateHelper.format(monthEnd));
			Map m = new HashMap();
			Calendar d = new GregorianCalendar();
			d.setTime(dayEnd);		
			m.put("month", d.get(Calendar.MONTH));
			m.put("year", d.get(Calendar.YEAR));
			d=DateUtils.getMonthEndDate(m);
			log.info("dayEnd month=> "+d.get(Calendar.MONTH));
			log.info("dayEnd day=> "+d.get(Calendar.DAY_OF_MONTH));
			log.info("dayEnd year=> "+d.get(Calendar.YEAR));		
			dayEndTesting =DateHelper.parse(DateHelper.format(DateUtils.getInstance().getPreviousBusinessDay(d.getTime(), map.get("C_BRANCHCODE").toString())));
		}

		log.info("dayEndTesting "+dayEndTesting);	
		log.info("date to be tested=> "+date);
		log.info("monthEnd=> "+monthEnd);
		log.info("dayEnd=> "+dayEnd);
		log.info("initialize=> "+initialize);			

		GregorianCalendar nextDate = new GregorianCalendar();
		nextDate.setTime(monthEnd);
		nextDate.add(GregorianCalendar.MONTH, 1);		
		
		String nextMonth = DateUtils.getMonthName(nextDate.getTime());
		Integer monthInitialize = DateUtils.getDateMonth(initialize);
		Integer prevMonthInitialize = DateUtils.getDateMonth(initialize,-1);
		Integer monthDayend = DateUtils.getDateMonth(dayEnd);
		Integer monthMonthEnd = DateUtils.getDateMonth(monthEnd,1);
		Integer monthNow = DateUtils.getDateMonth(date);
		 		
		/*if(dayEnd==null){
			if(dayEnd==null)jsonData.put("status", "Cannot proceed with Month End Process, Day End process has not yet completed");
			log.info("Not yet process");			
		}*/
		
		DateUtils DT = DateUtils.getInstance();
		Integer lastWorkingDay = postDateDAO.getLastWorkingDay();
		Calendar d_transactiondate = Calendar.getInstance();
		d_transactiondate.setTime(date);
		while(!DT.isBusinessDay(d_transactiondate.getTime(), "01")){
			d_transactiondate.add(Calendar.DAY_OF_MONTH, -1);
		}
		
		
		map.put("D_TRANSACTIONDATE", d_transactiondate.getTime());
		if(myDate.get(5)!=lastWorkingDay){
			jsonData.put("status", "Month End Should be Done on the End Of the Month");
		}
		
		if(monthEnd.equals(date)){
			jsonData.put("status", "You have already processed month end for this month! Please select "+nextMonth);
			log.info("The month end of your branch is already been processed");				
		}
		
		
		
		if(prevMonthInitialize==monthMonthEnd&&monthMonthEnd==monthNow){
			 resultMap = processMonthEnd(map,myDate,date);
			 if((Boolean)resultMap.get("updateStatus")){
				 jsonData.put("status", "Month end has successfully completed");
			 }
			 else
				 jsonData.put("status", "Error updating Month End");
			 return jsonData;
		}
		
		if((monthInitialize!=monthDayend)||(monthMonthEnd!=monthInitialize)||(monthInitialize!=monthNow)){
			jsonData.put("status", "Month End Should be Done on the End Of "+ nextMonth);
			return jsonData;
		}
		else if(monthEnd==null||monthEnd.before(date)){
			if (dayEnd.equals(date)){//IF DAY END EQUALS CURRENT DAY	
				 resultMap = processMonthEnd(map,myDate,date);
				 if((Boolean)resultMap.get("updateStatus")){
					 if((Boolean)resultMap.get("cisaStatus")){
						 jsonData.put("status", "Month end and CISA extraction has successfully completed");
					 }else
						 jsonData.put("status", "Month end successfully complete. CISA Encountered an error");
				 }
				 else
					 jsonData.put("status", "Error updating Month End"); 
			}
			else if (dayEnd.before(date)){//DAY END IS BEFORE CURRENT DAY
				Date nextBusinessDay = DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(dayEnd,map.get("C_BRANCHCODE").toString())));
				GregorianCalendar date1 = new GregorianCalendar();
				date1.setTime(date);
				log.info(date1.getTime());				
				GregorianCalendar date2 = new GregorianCalendar();
				log.info(date2.getTime());
				date2.setTime(nextBusinessDay);	
				GregorianCalendar date3 = new GregorianCalendar();
				date3.setTime(DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(date2.getTime(),map.get("C_BRANCHCODE").toString()))));

				if(date2.after(date1)||(date2.get(GregorianCalendar.MONTH)!=date3.get(GregorianCalendar.MONTH))){
					resultMap = processMonthEnd(map,myDate,date);
					 if((Boolean)resultMap.get("updateStatus")){
						 if((Boolean)resultMap.get("cisaStatus")){
							 jsonData.put("status", "Month end and CISA extraction has successfully completed");
						 }else
							 jsonData.put("status", "Month end successfully complete. CISA Encountered an error");
						 //jsonData.put("status", "Month end and CISA extraction has successfully completed");
					 }
					 else
						 jsonData.put("status", "Error updating Month End"); 
				}
				else if(date2.before(date1)){

					if((date1.get(GregorianCalendar.MONTH)==nextDate.get(GregorianCalendar.MONTH))&&(date1.get(GregorianCalendar.YEAR)==nextDate.get(GregorianCalendar.YEAR))){
						jsonData.put("status", "Cannot proceed with Month End process! Day End should be on the last business day of the Month of "+nextMonth);				
						log.info("yMonth End Process is invalid! Day End should be last Business day of the Month of "+nextMonth);							
					}
					else if((date1.get(GregorianCalendar.MONTH)==date2.get(GregorianCalendar.MONTH))&&(date1.get(GregorianCalendar.YEAR)==date2.get(GregorianCalendar.YEAR))){
						log.info("nextDate "+nextDate.getTime());
						log.info("nextMonth "+nextMonth);
						jsonData.put("status", "Invalid Date Please select "+nextMonth+" for Month End Process");				
						log.info("*Month End Process is invalid! The Day End date is not yet End Business day of the Month of "+nextMonth);						
					}					
					else{
						jsonData.put("status", "Invalid Date Please select "+nextMonth+" for Month End Process");
						if(dayEnd.equals(monthEnd))jsonData.put("status","Month end has already been processed! Please specify "+nextMonth+" for Month End Process");
						log.info("zInvalid Date Please specify "+nextMonth+" for Month End Process");						
					}									
				}
				else{
					jsonData.put("status", "Cannot proceed with Month End process! Day End should be on the last business day of the Month of "+nextMonth);				
					log.info("xMonth End Process is invalid! The Day End date is not yet End day of the Month of "+nextMonth);							
				}
			}
			else{//
				jsonData.put("status", "Invalid date please select "+nextMonth+" for Month End Process");
				log.info("yInvalid Date Please specify "+nextMonth+" for Month End Process");			}
		}
		else if(monthEnd.after(date)){			
			jsonData.put("status","You have already processed month end for this month. Please select "+nextMonth+" for Month End Process");
			if(dayEnd.equals(monthEnd))jsonData.put("status","You have already processed month end for this month. Please select "+nextMonth+" for Month End Process");
			log.info("=The month end of your branch has already been processed! Please select "+nextMonth+" for Month End Process");
		}


		//log.info("(date.getTime()==dayEnd.getTime())=> "+(date.getTime()==dayEnd.getTime()));
		//log.info("date.equals(dayEnd)=> "+date.after(monthEnd));

		/**Start of Old Month End - September 23, 2009
		if(initialize==null||dayEnd==null){
			if(initialize==null)jsonData.put("status", "Your branch is not yet initialize");
			if(dayEnd==null)jsonData.put("status", "Your branch's day end is not yet process");
			log.info("Not yet process ever since");			
		}
		else if(initialize.equals(date)){
			if(initialize.after(dayEnd)){
				if(dayEnd==null)jsonData.put("status", "Your branch's day end is not yet process");
			}
			else if(initialize.equals(dayEnd)){
				if((monthEnd==null || initialize.after(monthEnd))&&!date.equals(monthEnd)){
					//process
					log.info("The month end is about to process");
					jsonData.put("startStatus", "The month end is about to process. Please wait until the next prompt message");
					map.put("D_MONTHEND", DateHelper.format(date));
					ListIterator li = postDateDAO.getAllClientFromCC(map).listIterator();
					while(li.hasNext()){
						CC cc=(CC)li.next();
						ClientDAO clientDao = new ClientDAO();
						clientDao.updateClientMonthEnd(cc.getClientCode(), DateHelper.format(date));
					}
					boolean update=postDateDAO.updateMonthEnd(map);
					if(update){

						try{

							AuditService as = AuditService.getInstance();
							newData = ServiceUtility.removeNulls(map);
							PostDate cn = new PostDate(newData);
							as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());

						}catch(Throwable x){
							x.printStackTrace();
						}		

						jsonData.put("status", "The month end for your branch has successfully updated");
					}else{
						jsonData.put("status", "Error in updating PostDate");
					}					
				}
				else if (initialize.equals(monthEnd)||date.equals(monthEnd)){
					Date nextBusinessDay = DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(initialize,map.get("C_BRANCHCODE").toString())));					
					jsonData.put("status", "The month end of your branch is already been processed! Try to process Month End of "+DateUtils.getMonthName(nextBusinessDay));
					log.info("NThe month end of your branch is already been processed");							
					//already process
				}

			}			
		}
		else if(initialize.before(date)){
			Date nextBusinessDay = DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(initialize,map.get("C_BRANCHCODE").toString())));
			GregorianCalendar date1 = new GregorianCalendar();
			GregorianCalendar date2 = new GregorianCalendar();
			GregorianCalendar date3 = new GregorianCalendar();
			date1.setTime(initialize);
			date2.setTime(date);
			date3.setTime(nextBusinessDay);
			if(nextBusinessDay.after(date)){
				if((initialize.equals(dayEnd)|| initialize.after(monthEnd))&&!date.equals(monthEnd)){
					//process
					log.info("The month end is about to process");
					map.put("D_MONTHEND", DateHelper.format(date));
					jsonData.put("startStatus", "The month end is about to process. Please wait until the next prompt message");
					ListIterator li = postDateDAO.getAllClientFromCC(map).listIterator();
					while(li.hasNext()){
						CC cc=(CC)li.next();
						ClientDAO clientDao = new ClientDAO();
						clientDao.updateClientMonthEnd(cc.getClientCode(), DateHelper.format(date));
					}
					boolean update=postDateDAO.updateMonthEnd(map);
					if(update){

						try{

							AuditService as = AuditService.getInstance();
							newData = ServiceUtility.removeNulls(map);
							PostDate cn = new PostDate(newData);
							as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());

						}catch(Throwable x){
							x.printStackTrace();
						}							

						jsonData.put("status", "The month end for your branch has successfully updated");
					}else{
						jsonData.put("status", "Error in updating PostDate");
					}
				}
				else if((dayEnd==null||initialize.after(dayEnd))&&!date.equals(monthEnd)){					
					jsonData.put("status", "Your branch's day end is not yet process. Please process the day end for  the date "+DateHelper.format(initialize));
				}
				else if (initialize.equals(monthEnd)||date.equals(monthEnd)){
					jsonData.put("status", "The month end of your branch is already been processed! Try to process Month End of "+DateUtils.getMonthName(nextBusinessDay));
					log.info("The month end of your branch is already been processed");							
					//already process
				}
			}
			else if((date1.get(GregorianCalendar.MONTH)==date2.get(GregorianCalendar.MONTH))&&(date1.get(GregorianCalendar.YEAR)==date2.get(GregorianCalendar.YEAR))){
				jsonData.put("status", "Month End Process is invalid! The initialization date is not yet End day of the Month of "+DateUtils.getMonthName(dayEnd));				
				log.info("Month End Process is invalid! The initialization date is not yet End day of the Month of "+DateUtils.getMonthName(dayEnd));				
			}
			else{
				if(monthEnd==null||initialize.after(monthEnd)){
					jsonData.put("status", "You must first process the month end of "+DateUtils.getMonthName(initialize));
					log.info("You must first process the month end of "+DateUtils.getMonthName(initialize));					
				}
				else if ((date2.get(GregorianCalendar.MONTH)==date3.get(GregorianCalendar.MONTH))&&(date2.get(GregorianCalendar.YEAR)==date3.get(GregorianCalendar.YEAR))){
					jsonData.put("status", "Month End Process is invalid! The initialization date is not yet End day of the Month of "+DateUtils.getMonthName(nextBusinessDay));				
					log.info("Month End Process is invalid! The initialization date is not yet End day of the Month of "+DateUtils.getMonthName(nextBusinessDay));				
				}
				else{
					jsonData.put("status", "You must first process the month end of "+DateUtils.getMonthName(nextBusinessDay));
					log.info("You must first process the month end of "+DateUtils.getMonthName(nextBusinessDay));					
				}
				//already process

			}


		}	
		else if(initialize.after(date)){
			if(monthEnd==null || date.after(monthEnd)){
				map.put("D_MONTHEND", DateHelper.format(date));
				jsonData.put("startStatus", "The month end is about to process. Please wait until the next prompt message");
				ListIterator li = postDateDAO.getAllClientFromCC(map).listIterator();
				while(li.hasNext()){
					CC cc=(CC)li.next();
					ClientDAO clientDao = new ClientDAO();
					clientDao.updateClientMonthEnd(cc.getClientCode(), DateHelper.format(date));
				}
				boolean update=postDateDAO.updateMonthEnd(map);
				if(update){

					try{

						AuditService as = AuditService.getInstance();
						newData = ServiceUtility.removeNulls(map);
						PostDate cn = new PostDate(newData);
						as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());

					}catch(Throwable x){
						x.printStackTrace();
					}							

					jsonData.put("status", "The month end for your branch has successfully updated");
				}else{
					jsonData.put("status", "Error in updating PostDate");
				}				

				jsonData.put("status", "Invalid date! the month end to be process is "+DateUtils.getMonthName(dayEnd));
				log.info("Invalid date! the month end to be process is "+DateUtils.getMonthName(dayEnd));	

			}

			else if(initialize.before(monthEnd)||initialize.equals(monthEnd)){
				Date nextBusinessDay = DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(initialize,map.get("C_BRANCHCODE").toString())));
				jsonData.put("status", "The month end of your branch is already been processed! Try to process Month End of "+DateUtils.getMonthName(nextBusinessDay));
				log.info("The month end of your branch is already been processed! Try to process Month End of "+DateUtils.getMonthName(nextBusinessDay));						
			}


		}
End of Old Month End - September 23, 2009		
		 */		


		return jsonData;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map processMonthEnd(Map map, Calendar myDate,Date date){
		FactorsDateDAO factorsDate = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		SimpleDateFormat SDF = new SimpleDateFormat("yyyy/MM/dd");
		SimpleDateFormat UDF = new SimpleDateFormat ("yyyy-MM");
		SimpleDateFormat TDF = new SimpleDateFormat ("MM/dd/yyyy");
		Map jsonData = new HashMap();
		Map newData = new HashMap();
		PostDateDAO postDateDAO = (PostDateDAO)Persistence.getDAO("PostDateDAO");
		
		try {
			myDate.clear();
			myDate.setTime(UDF.parse(map.get("year")+"-"+(Integer.parseInt(map.get("month").toString())+1)));
			log.info(myDate);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String newDate = Integer.parseInt(map.get("month").toString())+1+"/"+myDate.getActualMaximum(5)+"/"+map.get("year");
		map.put("fromDate", newDate);
		/*map.put("D_TRANSACTIONDATE", SDF.format(new Date()));
		map.put("D_TRANSACTIONDATE", SDF.format(new Date()));*/
		 
		
		List<Map> clientList= postDateDAO.getClientProceedsMonthEnd(map);
		
		
		//ACCOUNTING  BALANCE
		AccountingMaintenanceService AMS = AccountingMaintenanceService.getInstance();
		
		Map AcctgBal = new HashMap();
			
			AcctgBal.put("C_BranchCode", map.get("C_BRANCHCODE"));
			AcctgBal.put("C_Month", Integer.parseInt(map.get("month").toString())+1);
			AcctgBal.put("N_Year", map.get("year"));
			AcctgBal.put("C_UserID", map.get("C_USERID"));
			AcctgBal.put("D_DateProcessed", SDF.format(factorsDate.newDate())); //before: new Date
			
		if (postDateDAO.isProcessed(AcctgBal)>0){
			if(postDateDAO.deleteAccountBalance(AcctgBal))
				log.info("Successfully deleted Old Record");
			log.info("Failed to remove Old Record");
		}
		
		//SUBHEADER
		for(int loop=0;loop<clientList.size();loop++){
			Map p = (Map) clientList.get(loop);
			p.put("fromDate", newDate);
			map.put("N_Amount", p.get("proceedsDC"));
			map.put("proceedsDC", p.get("proceedsDC"));
			map.put("C_CLNTCODE", p.get("c_clntcode"));
			map.put("interest", postDateDAO.getPDInterest(p));
			map.put("C_Type", "A");
			map.put("C_TransactionType","M");
			map.put("C_UserID", map.get("C_USERID"));
			SubHeaderService SHS = SubHeaderService.getInstance();
			Long ref = SHS.createSubHeader(map, "MONTHLY DC ACCRUAL OF INCOME", TDF.format(factorsDate.newDate()), ""); //before: new Date()
			SHS.createLedgerEntry2(map, "DC-Accrual", ref);
		}
		
		List GLList = AMS.getGLList();
			
		for (int loop=0;loop<GLList.size();loop++){
			Double n_amount = AMS.getAmount(GLList.get(loop).toString());
			
			AcctgBal.put("N_Amount", n_amount);
			AcctgBal.put("C_GLCode", GLList.get(loop).toString());
		
			postDateDAO.saveAccountBalance(AcctgBal);
		}
		
		
		log.info("The month end is about to process =>(monthEnd==null||monthEnd.before(date))");
		//jsonData.put("startStatus", "The month end is about to process. Please wait until the next prompt message");
		map.put("D_MONTHEND", DateHelper.format(date));
		ListIterator li = postDateDAO.getAllClientFromCC(map).listIterator();
		Map<String, Object> clientMap = new HashMap<String,Object>();
		Boolean cisaFlag = true;
		while(li.hasNext()){
			CC cc=(CC)li.next();
			ClientDAO clientDao = new ClientDAO();
			clientMap = clientDao.updateClientMonthEnd(cc.getClientCode(), DateHelper.format(date),map);
			if(cisaFlag){
				cisaFlag = clientMap.containsKey("cisaExtract")?(Boolean)clientMap.get("cisaExtract"):false;
			}
		}
		boolean update=postDateDAO.updateMonthEnd(map);
		if(update){

			try{

				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(map);
				PostDate cn = new PostDate(newData);
				as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}		

			jsonData.put("status", "Month end and CISA extraction has successfully completed");
			jsonData.put("cisaStatus",cisaFlag);
			jsonData.put("updateStatus",true);
		}else{
			jsonData.put("status", "Error updating Month End");
			jsonData.put("updateStatus",false);
			log.info("Error updating Month end in PostDate table");
			
		}
		return jsonData;
	}

	public Map dayEndProcess(Map map){
		Map jsonData = new HashMap();
		Map newData = new HashMap();
		Date transactionDate=map.get("isAdmin").toString().equals("0")?DateHelper.parse(map.get("D_TRANSDATE").toString()):DateHelper.parse(map.get("D_TRANSDATE_ADMIN").toString());

		//Date date = DateUtils.getInstance().getPreviousBusinessDay(DateHelper.parse(map.get("D_TRANDATE").toString()), map.get("C_BRANCHCODE").toString());
		//date = DateHelper.parse(DateHelper.format(date));
		PostDateDAO postDateDAO = (PostDateDAO)Persistence.getDAO("PostDateDAO");

		Map postData = (HashMap)(((List)postDateDAO.getPostDateByBranchCode(map)).get(0));

		Date dayEnd=null;
		Date initialize=null;
		Date monthEnd=null;

		if(postData.get("D_DAYEND")!=null){
			dayEnd= (Date)postData.get("D_DAYEND");
			dayEnd = DateHelper.parse(DateHelper.format(dayEnd));
		}
		if(postData.get("D_INITIALIZE")!=null){
			initialize= (Date)postData.get("D_INITIALIZE");
			initialize = DateHelper.parse(DateHelper.format(initialize));
		}
		if(postData.get("D_MONTHEND")!=null){
			monthEnd= (Date)postData.get("D_MONTHEND");
			monthEnd = DateHelper.parse(DateHelper.format(monthEnd));
		}

		log.info("dayEnd=> "+dayEnd);
		log.info("initialize=> "+initialize);
		log.info("monthEnd=> "+monthEnd);
		GregorianCalendar monthEndTest = new GregorianCalendar();
		monthEndTest.setTime(monthEnd);
		monthEndTest.add(GregorianCalendar.MONTH, 1);
		GregorianCalendar initializeTest = new GregorianCalendar();
		initializeTest.setTime(initialize);
		if(initializeTest.get(GregorianCalendar.MONTH)==monthEndTest.get(GregorianCalendar.MONTH)){
				if(initialize==null){
					jsonData.put("status", "Cannot process Day End, Branch has not yet initialized");
				}
				else if(initialize.equals(transactionDate)){
					if(dayEnd==null || initialize.after(dayEnd)){
						map.put("D_DAYEND", DateHelper.format(transactionDate));
						ListIterator li = postDateDAO.getAllClientFromCC(map).listIterator();
						while(li.hasNext()){
							CC cc=(CC)li.next();
							ClientDAO clientDao = new ClientDAO();
							clientDao.updateClientDailyFIU(cc.getClientCode(), DateHelper.format(transactionDate),map);
						}							
						boolean update=postDateDAO.updateDayEnd(map);
						if(update){
	
							try{
	
								AuditService as = AuditService.getInstance();
								newData = ServiceUtility.removeNulls(map);
								PostDate cn = new PostDate(newData);
								as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());
	
							}catch(Throwable x){
								x.printStackTrace();
							}	
	
							jsonData.put("status", "Day End has successfully completed");
						}
						else{
							jsonData.put("status", "Error in updating PostDate");
						}				
					}
					else if(initialize.equals(dayEnd)){
						jsonData.put("status", "Day End has already processed");
					}
					else if(initialize.before(dayEnd)){
						jsonData.put("status", "Invalid Day End date");				
					}			
				}
				else if(initialize.after(transactionDate)){
					String d =DateHelper.format(initialize);
					Date nextBusinessDay =DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(initialize,map.get("C_BRANCHCODE").toString())));
					if(initialize.equals(dayEnd)){
						d=DateHelper.format(nextBusinessDay);				
					}			
					jsonData.put("status", "Transaction Date you specify has already processed! Date should be "+d);			
	
				}
				else{
					String d =DateHelper.format(initialize);
					Date nextBusinessDay =DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(initialize,map.get("C_BRANCHCODE").toString())));
					if(initialize.equals(dayEnd)&& transactionDate.equals(nextBusinessDay)){
						jsonData.put("status", "Branch has not yet initialized");
					}else{
						if(initialize.equals(dayEnd)&& !transactionDate.equals(nextBusinessDay))d=DateHelper.format(nextBusinessDay);
						jsonData.put("status", "Invalid date! Date should be "+d);
					}
	
				}			
		}
		else{
			jsonData.put("status", "Cannot Proceed Day End Process. Month End has not yet processed for the month of "+DateUtils.getMonthName(monthEndTest.getTime()));
		}

		/*
		else if(initialize.before(transactionDate)){
			if(dayEnd==null){
				jsonData.put("status", "Day End is about to process");
			}
			else if(dayEnd.equals(transactionDate)){
				jsonData.put("status", "Day End is already processed");
			}			
			else if(dayEnd.before(transactionDate) || dayEnd.after(transactionDate)){
				jsonData.put("status", "Invalid generating transaction date");				
			}			
		}
		else if(initialize.after(transactionDate)){
			if(dayEnd==null){
				jsonData.put("status", "Day End is about to process");
			}
			else if(dayEnd.equals(transactionDate)){
				jsonData.put("status", "Day End is already processed");
			}			
			else if(dayEnd.before(transactionDate) || dayEnd.after(transactionDate)){
				jsonData.put("status", "Invalid generating transaction date");				
			}			
		}		
		 */

		return jsonData;
	}

	public Map yearEndProcess(Map map){
		Map jsonData = new HashMap();
		Map newData = new HashMap();
		map.put("month", 11);
		Calendar c = DateUtils.getMonthEndDate(map);			
		Date checkYearDate=DateHelper.parse(DateHelper.format(c.getTime()));
		log.info("checkYearDate: "+checkYearDate);
		log.info("is businessday "+DateUtils.getInstance().isBusinessDay(checkYearDate,  map.get("C_BRANCHCODE").toString()));
		Date yearEndInput=DateUtils.getInstance().isBusinessDay(checkYearDate,  map.get("C_BRANCHCODE").toString())?DateHelper.parse(DateHelper.format(checkYearDate)):DateHelper.parse(DateHelper.format(DateUtils.getInstance().getPreviousBusinessDay(checkYearDate, map.get("C_BRANCHCODE").toString())));
		log.info("yearEndInput: "+yearEndInput);
		PostDateDAO postDateDAO = (PostDateDAO)Persistence.getDAO("PostDateDAO");
		Map postData = (HashMap)(((List)postDateDAO.getPostDateByBranchCode(map)).get(0));

		Date dayEnd=null;
		Date monthEnd=null;
		Date yearEnd=null;
		if(postData.get("D_DAYEND")!=null){
			dayEnd= (Date)postData.get("D_DAYEND");
			dayEnd = DateHelper.parse(DateHelper.format(dayEnd));
		}		
		
		if(postData.get("D_MONTHEND")!=null){
			monthEnd= (Date)postData.get("D_MONTHEND");
			monthEnd = DateHelper.parse(DateHelper.format(monthEnd));
		}
		if(postData.get("D_YEAREND")!=null){
			yearEnd= (Date)postData.get("D_YEAREND");
			yearEnd = DateHelper.parse(DateHelper.format(yearEnd));
		}		
		if(monthEnd==null){
			jsonData.put("status", "Month End has not yet processed");
			log.info("Month End has not yet processed");
		}
		else if(monthEnd!=null && yearEnd==null){
			Date nextBusinessDay = DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(monthEnd,map.get("C_BRANCHCODE").toString())));
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(monthEnd);
			GregorianCalendar gc2 = new GregorianCalendar();
			gc2.setTime(yearEndInput);			
			if(monthEnd.before(yearEndInput)){
				if((nextBusinessDay.before(yearEndInput)||nextBusinessDay.equals(yearEndInput))&&(gc.get(GregorianCalendar.YEAR)==gc2.get(GregorianCalendar.YEAR))){
					jsonData.put("status", "Cannot proceed Year End, Month End for the month of December "+map.get("year").toString()+" has not yet processed"); //for The Year "+map.get("year").toString());
					log.info("The month end of your branch is not yet End Day of Year "+map.get("year").toString());					
				}
				else{
					jsonData.put("status", "Invalid Date! Year should be "+gc.get(GregorianCalendar.YEAR));
					log.info("xInvalid Year! Please try Year: "+gc.get(GregorianCalendar.YEAR));						
				}

			}
			else if(monthEnd.equals(yearEndInput)){
				map.put("D_YEAREND", DateHelper.format(yearEndInput));
				CC cc = new CC();
				cc.setBranchCode(map.get("C_BRANCHCODE").toString());
				ClientDAO clientDao = new ClientDAO();
				boolean update = clientDao.doUpdateYearEnd(cc);
				if(!update){
					jsonData.put("status", "Error processing year end. Please try again");
					return jsonData;
				}
				ListIterator li = postDateDAO.getAllClientFromCC(map).listIterator();
				while(li.hasNext()){
					CC cc2=(CC)li.next();
					Map newData2 = new HashMap();
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(map);
					MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
					MonthlyBalances mb = (MonthlyBalances) mbDAO.getYearEndMonthlyBalances(cc2);
					as.addAudit(newData2.get("C_USERID").toString(),"U","MonthlyBalances",mb.toString());					
				}

				if(postDateDAO.updateYearEnd(map)){

					try{

						AuditService as = AuditService.getInstance();
						newData = ServiceUtility.removeNulls(map);
						PostDate cn = new PostDate(newData);
						as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());

					}catch(Throwable x){
						x.printStackTrace();
					}		

					jsonData.put("status", "Month End has successfully completed");
				}else{
					jsonData.put("status", "Error in updating PostDate");
				}					
				jsonData.put("status", "Year End has successfully completed for the Year "+map.get("year").toString());
				log.info("The month end of your branch is not yet End Day of Year "+map.get("year").toString());					
			}
			else if(monthEnd.after(yearEndInput)){
				jsonData.put("status", "Invalid date! Year should be "+gc.get(GregorianCalendar.YEAR));
				log.info("yInvalid Year! Please try Year: "+gc.get(GregorianCalendar.YEAR));					
			}			


		}		
		else if(monthEnd!=null && yearEnd!=null){



			Date nextBusinessDay = DateHelper.parse(DateHelper.format(DateUtils.getInstance().getNextBusinessDay(monthEnd,map.get("C_BRANCHCODE").toString())));
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(monthEnd);
			GregorianCalendar gc2 = new GregorianCalendar();
			gc2.setTime(yearEndInput);
			GregorianCalendar gc3 = new GregorianCalendar();
			gc3.setTime(nextBusinessDay);
			if(yearEnd.equals(yearEndInput)){
				gc2.add(GregorianCalendar.YEAR, 1);
				jsonData.put("status", map.get("year").toString()+ " has already completed. Year should be "+gc2.get(GregorianCalendar.YEAR));
				log.info("The Year End of your branch is already Updated for the Year: "+map.get("year").toString()+"\n Please Try Year: "+gc2.get(GregorianCalendar.YEAR));				
			}			
			else if(monthEnd.before(yearEndInput)&&yearEnd.before(yearEndInput)){
				if((monthEnd.equals(yearEnd)&&(gc2.get(GregorianCalendar.YEAR)==gc3.get(GregorianCalendar.YEAR)))||
						((nextBusinessDay.before(yearEndInput)||nextBusinessDay.equals(yearEndInput))&&(gc.get(GregorianCalendar.YEAR)==gc2.get(GregorianCalendar.YEAR)))){
					//jsonData.put("status", "The Month End of your branch is not yet End Day for The Year "+map.get("year").toString());
					jsonData.put("status", "Cannot proceed Year End, Month End for the month of December "+map.get("year").toString()+" has not yet processed");
					log.info("The month end of your branch is not yet End Day of Year "+map.get("year").toString());					
				}
				
				else if(monthEnd.after(yearEnd)){					
					jsonData.put("status", "Invalid date! Year should be "+gc.get(GregorianCalendar.YEAR));
					log.info("zInvalid Year! Please try Year: "+gc.get(GregorianCalendar.YEAR));						
				}
				else{
					jsonData.put("status", "Invalid date! Year should be "+gc3.get(GregorianCalendar.YEAR));
					log.info("iInvalid Year! Please try Year: "+gc3.get(GregorianCalendar.YEAR));						
				}

			}
			else if(monthEnd.equals(yearEndInput)&& monthEnd.after(yearEnd)){
				map.put("D_YEAREND", DateHelper.format(yearEndInput));
				CC cc = new CC();
				cc.setBranchCode(map.get("C_BRANCHCODE").toString());
				ClientDAO clientDao = new ClientDAO();
				boolean update = clientDao.doUpdateYearEnd(cc);
				if(!update){
					jsonData.put("status", "Error processing year end. Please try again");
					return jsonData;
				}
				ListIterator li = postDateDAO.getAllClientFromCC(map).listIterator();
				while(li.hasNext()){
					CC cc2=(CC)li.next();
					Map newData2 = new HashMap();
					AuditService as = AuditService.getInstance();
					newData2 = ServiceUtility.removeNulls(map);
					MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
					MonthlyBalances mb = (MonthlyBalances)mbDAO.getYearEndMonthlyBalances(cc2);
					log.info("mb.toString()=>  "+mb.toString());
					as.addAudit(newData2.get("C_USERID").toString(),"U","MonthlyBalances",mb.toString());					
				}

				if(postDateDAO.updateYearEnd(map)){

					try{

						AuditService as = AuditService.getInstance();
						newData = ServiceUtility.removeNulls(map);
						PostDate cn = new PostDate(newData);
						as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());

					}catch(Throwable x){
						x.printStackTrace();
					}		

					jsonData.put("status", "Year End has successfully completed");
				}else{
					jsonData.put("status", "Error in updating PostDate");
				}					
				jsonData.put("status", "Year End has successfully completed");// for the Year "+map.get("year").toString());

			}
			else if(monthEnd.after(yearEndInput)){
				if(dayEnd.equals(yearEndInput)){
					map.put("D_YEAREND", DateHelper.format(yearEndInput));
					CC cc = new CC();
					cc.setBranchCode(map.get("C_BRANCHCODE").toString());
					ClientDAO clientDao = new ClientDAO();
					boolean update = clientDao.doUpdateYearEnd(cc);
					if(!update){
						jsonData.put("status", "Error processing year end. Please try again");
						return jsonData;
					}
					ListIterator li = postDateDAO.getAllClientFromCC(map).listIterator();
					while(li.hasNext()){
						CC cc2=(CC)li.next();
						Map newData2 = new HashMap();
						AuditService as = AuditService.getInstance();
						newData2 = ServiceUtility.removeNulls(map);
						MonthlyBalancesDAO mbDAO = new MonthlyBalancesDAO();
						MonthlyBalances mb = (MonthlyBalances)mbDAO.getYearEndMonthlyBalances(cc2);
						log.info("mb.toString()=>  "+mb.toString());
						as.addAudit(newData2.get("C_USERID").toString(),"U","MonthlyBalances",mb.toString());					
					}

					if(postDateDAO.updateYearEnd(map)){

						try{

							AuditService as = AuditService.getInstance();
							newData = ServiceUtility.removeNulls(map);
							PostDate cn = new PostDate(newData);
							as.addAudit(newData.get("C_USERID").toString(),"U","POSTDATE",cn.toString());

						}catch(Throwable x){
							x.printStackTrace();
						}		

						jsonData.put("status", "Year End has successfully completed");
					}else{
						jsonData.put("status", "Error in updating PostDate");
					}					
					jsonData.put("status", "Year End has successfully completed");// for the Year "+map.get("year").toString());
				}
				else{
					if(monthEnd.equals(yearEnd))
						gc.add(GregorianCalendar.YEAR, 1);
					jsonData.put("status", "Invalid date! Year should be "+gc.get(GregorianCalendar.YEAR));
					log.info("aInvalid Year! Please try Year: "+gc.get(GregorianCalendar.YEAR));
				}
									
			}			


		}

		return jsonData;
	}



	public static void main(String[] args) {

		Map postDateForm = new HashMap();
		postDateForm.put("C_BRANCHCODE", "67");
		postDateForm.put("C_USERID", "hunks");
		//postDateForm.put("month", 11);
		postDateForm.put("year", 2009);
		PostDateService pds = PostDateService.getInstance();
		//pds.monthEndProcess(postDateForm);
		log.info("pds.yearEndProcess(postDateForm).get(status).toString()=> "+pds.yearEndProcess(postDateForm).get("status").toString());
		//pds.initializeProcess(postDateForm);


	}



}
