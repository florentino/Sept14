package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;


import com.bdo.factor.beans.Holiday;
import com.bdo.factor.dao.HolidayDAO;
import com.bdo.factor.dao.Persistence;

import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.GroupUtility;
import com.bdo.factor.util.HolidayUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class HolidayService {
	private static Logger log = Logger.getLogger(HolidayService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static HolidayService thisHolidayService = new HolidayService();
	
	private HolidayService() { }

	public static HolidayService getInstance() {
		return thisHolidayService;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public List searchHolidayByGCode(String c_BranchCode, String d_HolidayDate){
		log.info("--->> searchHolidayByGCode SERVICE ...");
						
		HolidayDAO groupDAO = (HolidayDAO)Persistence.getDAO("HolidayDAO");	
		return groupDAO.searchHolidayByGCode(c_BranchCode, d_HolidayDate);
				
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public int getHolidayCountByDate(java.util.Date start, java.util.Date end, String branchCode){
		log.info("--->> searchHolidayByGCode SERVICE ...");
		int weekendCount = 0, holidayCount = 0;
		
						
		HolidayDAO holidayDAO = (HolidayDAO)Persistence.getDAO("HolidayDAO");
		ArrayList lHoliday = (ArrayList) holidayDAO.getHolidayCountByDate(start, end, branchCode);
		if (lHoliday != null && lHoliday.size() > 0) {
			HashMap hMap = new HashMap();
		
			for(int outerCnt=0;outerCnt<lHoliday.size();outerCnt++){
				hMap = (HashMap)lHoliday.get(outerCnt);
				log.info("hMap Values: " + hMap.keySet());
				Date d = (Date) hMap.get("D_HOLIDAYDATE");
				log.info("date: " + d);	    	
				Calendar cal = Calendar.getInstance();
				cal.setTime(d);
				int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
				if ((dayOfWeek == Calendar.SATURDAY) || (dayOfWeek == Calendar.SUNDAY)) {
					weekendCount++;
				}			
			}
		
			holidayCount = lHoliday.size() - weekendCount;
		}
		
		return holidayCount;				
	}
	
	public boolean isHoliday(java.util.Date processingDate, String branchCode) {
		
		HolidayDAO holidayDAO = (HolidayDAO)Persistence.getDAO("HolidayDAO");
		ArrayList lResult = (ArrayList) holidayDAO.getHolidayCountByDate(processingDate, processingDate, branchCode);
		if (lResult != null && lResult.size() > 0) {
			return true;
		}
		return false;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchHoliday(Map holidayMap){
		
		Map jsondata = new HashMap();
		String totalRecords = "";		
		String c_BranchCode = "";
		
		try {
			log.info("--->> searchHoliday SERVICE ...");		
			
			HolidayDAO holidayDAO = (HolidayDAO)Persistence.getDAO("HolidayDAO");
			c_BranchCode = (String) holidayMap.get("C_BRANCHCODE");
			
			totalRecords = holidayDAO.getTotalRecordsHoliday(c_BranchCode);			
			holidayMap = ServiceUtility.addPaging(holidayMap,totalRecords);			
			List lHoliday = holidayDAO.searchHoliday(holidayMap);
			ServiceUtility.viewUserParameters(holidayMap);
			
			log.info("--->> searchHoliday RECORDS: "+lHoliday.size());
						
			if((lHoliday!=null) && (lHoliday.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lHoliday, ((String)holidayMap.get("records")),((String)holidayMap.get("page")),((String)holidayMap.get("total")));
			}else{				
				jsondata.put("status","Search Holiday Failed ... ");
			}
		}
		catch(Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;			
	}	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map addHoliday(Map holiday){		
		
		Map jsondata = new HashMap();
		Holiday g = HolidayUtility.getInstance().toObject(holiday);
		
		try {			
				ServiceUtility.viewUserParameters(holiday);				
			
				HolidayDAO holidayDAO = (HolidayDAO)Persistence.getDAO("HolidayDAO");
				
//				boolean duplicate = this.isDuplicate(g.getC_BranchCode(), DateHelper.format(g.getD_HolidayDate()));				
				boolean duplicate = this.isDuplicate(g.getC_BranchCode(),(String) holiday.get("D_HOLIDAYDATE"));	
				if (duplicate) {
					jsondata.put("status","Failed to add Holiday. Record with same holiday and branch code already exists.");
					return jsondata;
				}	
				
				boolean success = holidayDAO.addHoliday(holiday);
				
				if(success){					
					log.info("adding audit log");
					String userID = (String) holiday.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "HOLIDAY", g.toString());
					
					jsondata.put("status","Add Holiday Successful ...");					
				}else{
					jsondata.put("status","Add Holiday Failed ... ");
				}
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		//TODO: uncomment below statment once done with users
		//String userID = holiday.get("USERID");
		
		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map updateHoliday(Map holiday){
		Map jsondata = new HashMap();
		Holiday g = HolidayUtility.getInstance().toObject(holiday);
		try {				
			HolidayDAO holidayDAO = (HolidayDAO)Persistence.getDAO("HolidayDAO");
			String d_HolidayDate = (String) holiday.get("D_HOLIDAYDATE");
			String c_BranchCodeOld = (String) holiday.get("C_BRANCHCODEOLD");
			String d_HolidayDateOld = (String) holiday.get("D_HOLIDAYDATE_ORIG");		
						
			if (!((DateHelper.format(g.getD_HolidayDate())).trim().equalsIgnoreCase(d_HolidayDateOld.trim())) || !(g.getC_BranchCode().trim().equalsIgnoreCase(c_BranchCodeOld.trim()))) {
//				boolean duplicate = this.isDuplicate(g.getC_BranchCode(), DateHelper.format(g.getD_HolidayDate()));				
				boolean duplicate = this.isDuplicate(g.getC_BranchCode(),(String) holiday.get("D_HOLIDAYDATE"));
				if (duplicate) {
					jsondata.put("status","Failed to update Holiday. Record with same holiday and branch code already exists.");
					return jsondata;
				}
			}
			log.info("update...");
			
			boolean success = holidayDAO.updateHoliday(holiday);
			log.info("sucess: " + success);			
			
			if(success){
				log.info("adding audit log2");
				String userID = (String) holiday.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "HOLIDAY", g.toString());
				
				jsondata.put("status","Update Holiday Successful ...");
			}
			else{				
				jsondata.put("status","Update Holiday Failed ... ");				
			}	
		}
		catch (Throwable x) {			
			jsondata.put("status","Update Holiday Failed ... " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
				
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map deleteHoliday(Map holiday){
		Map jsondata = new HashMap();
		try {
			ServiceUtility.viewUserParameters(holiday);			
			Holiday g = HolidayUtility.getInstance().toObject(holiday);
			
			HolidayDAO holidayDAO = (HolidayDAO)Persistence.getDAO("HolidayDAO");

			boolean success = holidayDAO.deleteHoliday(holiday);			
			
			if(success){				
				String userID = (String) holiday.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "HOLIDAY", g.toString());
				
				jsondata.put("status","Delete Holiday Successful ...");
			}else{
				jsondata.put("status","Delete Holiday Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	public boolean isDuplicate(String c_BranchCode, String d_HolidayDate) {
		List l = this.searchHolidayByGCode(c_BranchCode, d_HolidayDate);
		if (l != null && l.size() > 0) {			
			return true;
		}
		return false;
	}
	
	public static void main (String[] args) {
		HolidayService gs = new HolidayService();
		HashMap holiday = new HashMap();
		holiday.put("C_BRANCHCODE","11");
		holiday.put("D_HOLIDAYDATE", "01/01/1987");
		holiday.put("B_STDHOLIDAY", new Integer(32));
		holiday.put("C_DESC", "DESCRIPTION");
		holiday.put("C_BRANCHCODEOLD", "11");
		holiday.put("D_HOLIDAYDATEOLD", "01/01/2009");	
		
		
		Map mResult = gs.updateHoliday(holiday);
		
		//log.info("holiday : " + g.toString());
		//Map mResult = gs.addHoliday(holiday);
		//Map mResult = gs.searchHoliday();
		log.info("result: " + mResult.values());
	
	}
}
