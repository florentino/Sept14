package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.dao.AdvancesDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.PdoDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class PDOService {
	private static Logger log = Logger.getLogger(PDOService.class);

	private static PDOService PDOServiceInstance = new PDOService();
	
		private PDOService() { }

		public static PDOService getInstance() {
			return PDOServiceInstance;
		}

	public Map getPDO(Map pdoMap){
		
		Map jsondata = new HashMap();
		
		PdoDAO PdoDAO = (PdoDAO)Persistence.getDAO("PdoDAO");
		
		jsondata= ServiceUtility.toJQGrid(PdoDAO, "countPDO", "getPDO", pdoMap);
		
		
		return jsondata;
		
	}
		
		
}
