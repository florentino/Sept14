package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Adjustment;
import com.bdo.factor.beans.AdjustmentType;
import com.bdo.factor.beans.CheckType;
import com.bdo.factor.beans.Group;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.AdjustmentTypeDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.AdjustmentTypeUtility;
import com.bdo.factor.util.CheckTypeUtility;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.DateUtils;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class AdjustmentTypeService {
	private static Logger log = Logger.getLogger(AdjustmentTypeService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static AdjustmentTypeService thisAdjustmentTypeService = new AdjustmentTypeService();
	
	private AdjustmentTypeService() { }

	public static AdjustmentTypeService getInstance() {
		return thisAdjustmentTypeService;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map searchAdjustmentTypeByCode(String c_AdjustmentTypeCode){		
		log.info("--->> searchAdjustmentTypeByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjusmentTypeDAO");
				
		List records = AdjustmentTypeDAO.searchAdjustmentTypeByCode(c_AdjustmentTypeCode);
		jsonData.put("result", records);
		
		return jsonData;
	}	
	
	public List searchAdjustmentTypeByBCode(String c_AdjustmentTypeCode){		
		log.info("--->> searchAdjustmentTypeByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
				
		return AdjustmentTypeDAO.searchAdjustmentTypeByCode(c_AdjustmentTypeCode);
		
	}	
	
	public Map searchAdjustmentTypeList(Map m){		
		log.info("--->> searchCheckTypeByBCode SERVICE ...");
		
		HashMap jsonData = new HashMap();
		
		AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
		ArrayList records = (ArrayList) AdjustmentTypeDAO.searchAdjustmentTypeList(m);
		
		//HashMap hm = (HashMap) records.get(0);		
		
		String resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_Name","C_Name");
		log.info("records: " + records.size());
		jsonData.put("AUTOCOMPLETE", resultString);
		
		return jsonData;
	}	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchAdjustmentType(Map adjustmentTypeMap){
		
		Map jsondata = new HashMap();
		String totalRecords = "";
		
		log.info("--->> searchCheckType SERVICE ...");		
		try {			
			AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
			
			totalRecords = AdjustmentTypeDAO.getTotalRecordsAdjustmentType();	
			
			adjustmentTypeMap = ServiceUtility.addPaging(adjustmentTypeMap,totalRecords);
			
			List lAdjustmentType = AdjustmentTypeDAO.searchAdjustmentType(adjustmentTypeMap);
			ServiceUtility.viewUserParameters(adjustmentTypeMap);
			
			log.info("--->> searchAdjustmentType RECORDS: "+lAdjustmentType.size());
			
			if((lAdjustmentType!=null) && (lAdjustmentType.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lAdjustmentType,((String)adjustmentTypeMap.get("records")),((String)adjustmentTypeMap.get("page")),((String)adjustmentTypeMap.get("total")));
			}else{				
				jsondata.put("status","Search Adjustment Type Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;		
	}	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchAdjustment(Map adjustmentMap){
		
		Map jsondata = new HashMap();
		String totalRecords = "";
		
		log.info("--->> [bin10]searchAdjustment SERVICE ...");		
		try {			
			AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
			
			totalRecords = AdjustmentTypeDAO.getTotalRecordsAdjustment();	
			adjustmentMap = ServiceUtility.addPaging(adjustmentMap,totalRecords);
			//adjustmentMap.put("C_BRANCHCODE", adjustmentMap.get("C_BRANCHCODE"));
			
			List lAdjustment = AdjustmentTypeDAO.searchAdjustment(adjustmentMap);
			ServiceUtility.viewUserParameters(adjustmentMap);
			
			log.info("--->> searchAdjustment RECORDS: "+lAdjustment.size());
			
			if((lAdjustment!=null) && (lAdjustment.size()>0)){
				jsondata = JQGridJSONFormatter.formatDataToJSON(lAdjustment,((String)adjustmentMap.get("records")),((String)adjustmentMap.get("page")),((String)adjustmentMap.get("total")));
			}else{				
				jsondata.put("status","Search Adjustment Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;		
	}	
	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchAdjustmentCode(Map adjustmentCodeMap){
		
		Map jsondata = new HashMap();
		List lAdjustment= new ArrayList();
		String resultString="";
		String totalRecords = "";
		
		log.info("--->> [bin10]searchAdjustmentCode SERVICE ...");		
		try {			
			AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
			
			////totalRecords = AdjustmentTypeDAO.getTotalRecordsAdjustment();	
		//	//adjustmentCodeMap = ServiceUtility.addPaging(adjustmentCodeMap,totalRecords);
			//adjustmentMap.put("C_BRANCHCODE", adjustmentMap.get("C_BRANCHCODE"));
			ServiceUtility.viewUserParameters(adjustmentCodeMap);
			lAdjustment = AdjustmentTypeDAO.searchAdjustmentCode(adjustmentCodeMap);
			
			
			log.info("--->> searchAdjustmentCode RECORDS: "+lAdjustment.size());
			log.info("--->> searchAdjustmentCode RECORDS: "+lAdjustment.toString());
			
			//if((lAdjustment!=null) && (lAdjustment.size()>0)){
				//jsondata = JQGridJSONFormatter.formatDataToJSON(lAdjustment,((String)adjustmentCodeMap.get("records")),((String)adjustmentCodeMap.get("page")),((String)adjustmentCodeMap.get("total")));
				resultString = JQGridJSONFormatter.formatListToJSONSelect(lAdjustment,"C_ADJCODE","C_ADJDESC");
				jsondata.put("AUTOCOMPLETE",resultString);
			//}else{				
			//	jsondata.put("status","Search Adjustment Code Failed ... ");
			//}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;		
	}	
		
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	
	
	public Map addAdjustmentType(Map adjustmentTypeMap){		
		
		Map jsondata = new HashMap();
		try {			
			ServiceUtility.viewUserParameters(adjustmentTypeMap);
			
			AdjustmentType adjustmentType = AdjustmentTypeUtility.toObject(adjustmentTypeMap);			
			String operation = (String) adjustmentTypeMap.get("operation");
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {
				String glCode =  (String) adjustmentTypeMap.get("C_ACCOUNTNAME");
				String adjRec =  (String) adjustmentTypeMap.get("C_ADJREC");
				String adjRes =  (String) adjustmentTypeMap.get("C_ADJRES");
				String adjFiu =  (String) adjustmentTypeMap.get("C_ADJFIU");
				String adjFiuBal =  (String) adjustmentTypeMap.get("C_ADJFIUBAL");
				String included =  (String) adjustmentTypeMap.get("B_INCLUDED");
				String debit =  (String) adjustmentTypeMap.get("C_DEBIT");
				
				if (glCode.isEmpty()){
					adjustmentTypeMap.put("C_ACCOUNTNAME", null);
				}
				if (adjRec.isEmpty()){
					adjustmentTypeMap.put("C_ADJREC", null);
				}
				if (adjRes.isEmpty()){
					adjustmentTypeMap.put("C_ADJRES", null);
				}
				if (adjFiu.isEmpty()){
					adjustmentTypeMap.put("C_ADJFIU", null);
				}
				if (adjFiuBal.isEmpty()){
					adjustmentTypeMap.put("C_ADJFIUBAL", null);
				}
				if (included.isEmpty()){
					adjustmentTypeMap.put("B_INCLUDED", null);
				}
				if (debit.isEmpty()){
					adjustmentTypeMap.put("C_DEBIT", null);
				}
				
				this.updateAdjustmentType(adjustmentTypeMap);
			}
			else {
				
				AdjustmentTypeDAO adjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
				String c_AdjustmentTypeCodeOld = (String) adjustmentTypeMap.get("C_ADJUSTMENTTYPECODEOLD");
				
				boolean duplicate = this.isDuplicate(adjustmentType.getC_AdjCode());
				if (duplicate) {
					jsondata.put("status","Failed to Add Adjustment Type. Record with same code already exists.");
					return jsondata;
				}				
				
				boolean success = adjustmentTypeDAO.addAdjustmentType(adjustmentTypeMap);
				
				
				if(success){
					log.info("adding audit log2");
					String userID = (String) adjustmentTypeMap.get("C_USERID");
					AuditService as = AuditService.getInstance();
					
					as.addAudit(userID, "I", "ADJUSTMENTTYPE", adjustmentType.toString());
					
					jsondata.put("status","Add Adjustment Type Successful ...");
				}else{
					jsondata.put("status","AddAdjustment Type Failed ... ");
				}
			}
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		
		return jsondata;
	}
	

//////////////////////////////////////////////////////////////////////////////////////////////
public Map addAdjustment(Map adjustmentMap){
		
		log.info("--->>[bin10] addAdjustment SERVICE ...");
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		boolean success=false;
		
		try{			
			ServiceUtility.viewUserParameters(adjustmentMap);
			
			//Invoice invoice = InvoiceUtility.getInstance().toObject(InvoiceForm);  
			
			AdjustmentTypeDAO adjustmentDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
			//log.info("***" + InvoiceForm.get("C_CURRENCYCODE"));
			
			if (adjustmentMap.get("mode").toString().equals("2")){
				success = adjustmentDAO.updateAdjustment(adjustmentMap);		
			}else{
			
				success = adjustmentDAO.addAdjustment(adjustmentMap);
			}
			
			if(success){					

				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(adjustmentMap);
					Adjustment adjustment = new Adjustment(newData);
					as.addAudit(newData.get("C_USERID").toString(),"I","Adjustment",adjustment.toString());

				}catch(Throwable x){
					x.printStackTrace();
				}
				
				jsondata.put("status","Add Adjustment Successful ...");
				log.info("cn..."+adjustmentMap.get("C_CLNTCODE"));
				//?????????????????jsondata.put("clientfilter", InvoiceForm.get("C_NAME"));
				//?????????????????log.info("cf..."+InvoiceForm.get("clientfilter"));
				//?????????????????InvoiceForm.put("clientfilter", InvoiceForm.get("C_NAME"));
			}else{
				jsondata.put("status","Add Invoice Failed ... ");
			}
			
		}catch(Exception x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
			//return jsondata;
		}
		
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map updateAdjustmentType(Map adjustmentTypeMap){		
		Map jsondata = new HashMap();
		adjustmentTypeMap.put("C_ADJCODE", adjustmentTypeMap.get("C_ADJCODE_ORIG"));
		AdjustmentType adjustmentType = AdjustmentTypeUtility.toObject(adjustmentTypeMap);
		
		String c_AdjustmentTypeCodeOld = (String) adjustmentTypeMap.get("C_ADJUSTMENTTYPECODEOLD");
		//SET OLD VALUE
		System.out.println(adjustmentTypeMap.get("C_ADJCODE_ORIG"));
		
		
		try {
			ServiceUtility.viewUserParameters(adjustmentTypeMap);
					
			AdjustmentTypeDAO atDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
						
			boolean success = atDAO.updateAdjustmentType(adjustmentTypeMap);
			ServiceUtility.viewUserParameters(adjustmentTypeMap);
			
			if(success){				
				String userID = (String) adjustmentTypeMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				System.out.println(adjustmentTypeMap.toString());
				as.addAudit(userID, "U", "ADJUSTMENTTYPE", adjustmentType.toString());
				
				jsondata.put("status","Update Adjustment Type Successful ...");
			}
			else {
				jsondata.put("status","Update Adjustment Type Failed ... ");				
			}
			
		}
		catch (Throwable x) {			
			jsondata.put("status","Update Adjustment Type Failed. " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
				
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public Map updateAdjustmentStatus(Map adjustmentStatusMap){		
		Map jsondata = new HashMap();
		boolean success = false;
		//adjustmentStatusMap.put("N_REFNOS", Long.parseLong(adjustmentStatusMap.get("N_REFNOS").toString()));
		
		
		try {
			ServiceUtility.viewUserParameters(adjustmentStatusMap);
					
			AdjustmentTypeDAO atDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
						
			success = atDAO.updateAdjustmentStatus(adjustmentStatusMap);
			ServiceUtility.viewUserParameters(adjustmentStatusMap);
			
			if(success){				
				String userID = (String) adjustmentStatusMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "ADJUSTMENTTYPE", adjustmentStatusMap.toString());
				
				jsondata.put("status","Update Adjustment Type Successful ...");
			}
			else {
				jsondata.put("status","Update Adjustment Type Failed ... ");				
			}
			
		}
		catch (Throwable x) {			
			jsondata.put("status","Update Adjustment Type Failed. " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
		
		if (success) {
			jsondata.put("rv", "true");
		} else {
			jsondata.put("rv", "false");
		}
		//return returnMap;
				
		return jsondata;
	}
	

	
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map updateAdjustmentToCancel(Map adjustmentToCancelMap){		
		Map jsondata = new HashMap();
		boolean success = false;
		//adjustmentStatusMap.put("N_REFNOS", Long.parseLong(adjustmentStatusMap.get("N_REFNOS").toString()));
		
		
		try {
			ServiceUtility.viewUserParameters(adjustmentToCancelMap);
					
			AdjustmentTypeDAO atDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
						
			success = atDAO.updateAdjustmentToCancel(adjustmentToCancelMap);
			ServiceUtility.viewUserParameters(adjustmentToCancelMap);
			
			if(success){				
				String userID = (String) adjustmentToCancelMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "ADJUSTMENTTYPE", adjustmentToCancelMap.toString());
				
				jsondata.put("status","Update Adjustment to Cancel Successful ...");
			}
			else {
				jsondata.put("status","Update Adjustment to Cancel Failed ... ");				
			}
			
		}
		catch (Throwable x) {			
			jsondata.put("status","Update Adjustment to Cancel Failed. " + x.getMessage());
			x.printStackTrace();
			return jsondata;
		}
		
		if (success) {
			jsondata.put("rv", "true");
		} else {
			jsondata.put("rv", "false");
		}
		//return returnMap;
				
		return jsondata;
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	
	public Map deleteAdjustmentType(Map adjustmentTypeMap){
		
		Map jsondata = new HashMap();
		try {
			ServiceUtility.viewUserParameters(adjustmentTypeMap);
			
			AdjustmentType adjustmentType = AdjustmentTypeUtility.toObject(adjustmentTypeMap);
			
			AdjustmentTypeDAO AdjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");

			boolean success = AdjustmentTypeDAO.deleteAdjustmentType(adjustmentTypeMap);
						
			if(success){
				String userID = (String) adjustmentTypeMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "ADJUSTMENTTYPE", adjustmentType.toString());
				
				jsondata.put("status","Delete Adjustment Type Successful ...");
			}else{
				jsondata.put("status","Delete Adjustment Type Failed ... ");
			}	
		}
		catch (Throwable x) {
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	public boolean isDuplicate(String c_AdjustmentTypeCode) {
		List l = this.searchAdjustmentTypeByBCode(c_AdjustmentTypeCode);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchAdjustmentTypeAutoComplete(Map adjustmentTypeForm){
		
		log.info("--->> search AdjustmentType AutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(adjustmentTypeForm);
			
			AdjustmentTypeDAO adjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");				
			records = (ArrayList)adjustmentTypeDAO.searchAdjustmentTypeAutoComplete(adjustmentTypeForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}
/////////////////////////////////////////////////////////////////////////////////
public Map invoiceAutoComplete(Map adjustmentTypeForm){
		
		log.info("--->> search AdjustmentType AutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		
		List records = new ArrayList();
		String resultString = "";
		
		try{
			
			ServiceUtility.viewUserParameters(adjustmentTypeForm);
			
			AdjustmentTypeDAO adjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");				
			records = (ArrayList)adjustmentTypeDAO.searchInvoiceAuto(adjustmentTypeForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			if(resultString.isEmpty()){jsondata.put("AUTOCOMPLETE", "NO ENTRY FOUND");}
			else
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}
public Map invoiceValidation(Map adjustmentTypeForm){	
	log.info("--->> search invoices SERVICE ...");
	
	Map jsondata = new HashMap();
	
	List records = new ArrayList();
	String resultString = "";
	
	try{
		
		ServiceUtility.viewUserParameters(adjustmentTypeForm);
		
		AdjustmentTypeDAO adjustmentTypeDAO = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");				
		records = (ArrayList)adjustmentTypeDAO.invoiceValidation(adjustmentTypeForm);
		resultString = JQGridJSONFormatter.formatListToString(records);
		System.out.println(resultString.isEmpty());
		if(resultString.isEmpty()){
		jsondata.put("rv","No Entry Found");}
							
	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}	
	
	return jsondata;
	
}

////mogz added
public List<Map> getAdjustmentList(Map m){
	AdjustmentTypeDAO AD = (AdjustmentTypeDAO)Persistence.getDAO("AdjustmentTypeDAO");
	return AD.getAdjustmentList(m);
}	

//	public Map computeClearingDays(Map clearingDateForm) {
//		Map jsonData = new HashMap();
//		ServiceUtility.viewUserParameters(clearingDateForm);
//		log.debug("Values::::" + clearingDateForm.values());
//		Date start = new java.util.Date();
//		int days = Integer.parseInt(clearingDateForm.get("N_NOOFDAYS").toString());
//		String branchCode = (String) clearingDateForm.get("C_BRANCHCODE");
//		
//		DateUtils dateUtil = DateUtils.getInstance();	
//		Date result = dateUtil.addBusinessDay(start, days, branchCode);
//		String formattedResult = DateHelper.format(result);
//		
//		jsonData.put("CLEARINGDATE", formattedResult);
//		return jsonData;
//	}
}
