package com.bdo.factor.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bdo.factor.beans.ActualDunningBean;
import com.bdo.factor.dao.ActualDunningDAO;
import com.bdo.factor.dao.Persistence;

public class ActualDunningService {

	/**
	 * @param args
	 */
	public List<ActualDunningBean> getFields(Long c_clntcode,Long c_custcode,String startDate,String endDate){
		 ActualDunningDAO ADD = (ActualDunningDAO)Persistence.getDAO("ActualDunningDAO");
		 Map data = new HashMap();
		 data.put("c_clntcode", c_clntcode.toString());
		 data.put("c_custcode", c_custcode.toString());
		 data.put("startDate", startDate);
		 data.put("endDate", endDate);
		 List<ActualDunningBean> pop =ADD.getFields(data); 
		return pop;
	}

}
