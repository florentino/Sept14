package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Advances;
import com.bdo.factor.beans.CnType;
import com.bdo.factor.beans.Invoice;
import com.bdo.factor.dao.AdvancesDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.CNDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.CurrencyDAO;
import com.bdo.factor.dao.CustomerDAO;
import com.bdo.factor.dao.FactorsDateDAO;
import com.bdo.factor.dao.INVOICEDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dataSource.InvoiceDAO;
import com.bdo.factor.util.CNTypeUtility;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.InvoiceUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class InvoiceService {
	private static Logger log = Logger.getLogger(InvoiceService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static InvoiceService thisInvoiceService = new InvoiceService();
	
	private InvoiceService() { }

	public static InvoiceService getInstance() {
		
		return thisInvoiceService;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchInvoice(Map InvoiceForm){
		
		log.info("--->> searchInvoice SERVICE X...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		String customerCode = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(InvoiceForm);
			log.info("--->> searchInvoice 1");
				
			//BankDAO factorInvoiceDAO = (BankDAO)Persistence.getDAO("BankDAO");	
			INVOICEDAO InvoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");	
			
			System.out.println("--->> searchInvoice 2XX");
			log.info("--->> searchInvoice 2");
			
			//log.info("cf..."+InvoiceForm.get("clfilter"));
			/*if ((String) InvoiceForm.get("clfilter")=="" && (String) InvoiceForm.get("cufilter")=="" && (String) InvoiceForm.get("stfilter")==""){
				InvoiceForm.put("clfilter", "A");
				InvoiceForm.put("clientfilter", "A");
			}*/
			///////////////////////////////////////////////
			CustomerDAO customerDAO = (CustomerDAO)Persistence.getDAO("CustomerDAO");
			customerCode = customerDAO.searchCustomerCodeByClientName(InvoiceForm);
			InvoiceForm.put("C_CUSTCODE", customerCode);
			///////////////////////////////////////////////
			log.info("--->> searchInvoice 2");
			
			totalRecords = InvoiceDAO.getTotalRecordsInvoice(InvoiceForm);	
			//records = InvoiceDAO.searchInvoice(InvoiceForm);	
			
			ServiceUtility.viewUserParameters(InvoiceForm);
			log.info("--->> searchInvoice 2 "+totalRecords);
			
			
			InvoiceForm = ServiceUtility.addPaging(InvoiceForm,totalRecords);
			
			records = InvoiceDAO.searchInvoice(InvoiceForm);	
		
			ServiceUtility.viewUserParameters(InvoiceForm);
						
			log.info("--->> searchInvoice RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)InvoiceForm.get("records")),((String)InvoiceForm.get("page")),((String)InvoiceForm.get("total")));
			}else{
				jsondata.put("status","Search Invoice Failed ... ");
			}
	
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
	public Map searchInvoiceByStatus(Map invoiceForm){
		
		log.info("--->> searchInvoice SERVICE X...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(invoiceForm);
			log.info("--->> searchInvoice 1");
			
			INVOICEDAO InvoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			
			totalRecords = InvoiceDAO.getTotalRecordsInvoiceByStatus(invoiceForm);	
			invoiceForm = ServiceUtility.addPaging(invoiceForm,totalRecords);	
			
				
			records = InvoiceDAO.searchInvoiceByStatus(invoiceForm);							
			log.info("--->> searchInvoice RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)invoiceForm.get("records")),((String)invoiceForm.get("page")),((String)invoiceForm.get("total")));
			}else{
				jsondata.put("status","Search Invoice Failed ... ");
			}
	
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	@SuppressWarnings("unchecked")
	public Map mainInvoice(Map InvoiceForm){
		ServiceUtility.viewUserParameters(InvoiceForm);
		InvoiceDAO inv = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		Map returnMap = new HashMap();
		//Map jsondata = new HashMap();
		//ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
		//CustomerDAO customerDAO = (CustomerDAO)Persistence.getDAO("CustomerDAO");
		CurrencyDAO currencyDAO = (CurrencyDAO)Persistence.getDAO("CurrencyDAO");
		
		//String ClientCode = "";
		String cname = InvoiceForm.get("C_NAME").toString().replaceAll("'", "''");
		String cuname = InvoiceForm.get("C_CUSTNAME").toString().replaceAll("'", "''");
		String clntcode = "";
		String custcode = "";
		if (cname!=""){
			String whr="C_BRANCHCODE='"+InvoiceForm.get("C_BRANCHCODE")+"' and C_NAME='"+cname+"' and C_CUSTNAME='"+cuname+"'";
			clntcode=inv.getField("C_CLNTCODE", "CC", whr);
			custcode=inv.getField("C_CUSTCODE", "CC", whr);
			InvoiceForm.put("C_CLNTCODE",clntcode);
			InvoiceForm.put("C_CUSTCODE",custcode);
			//ClientCode = clientDAO.searchClientResolveToCode(InvoiceForm);
			//InvoiceForm.put("C_CLNTCODE", ClientCode);
			
			//List customerCode = new ArrayList();
			//customerCode = customerDAO.searchCustomerByCode(InvoiceForm);
			//InvoiceForm.put("C_CUSTCODE", ((HashMap)customerCode.get(0)).get("C_CUSTCODE"));
		}
		
		//String CurrencyCode = currencyDAO.searchCurrencyResolveToCode(InvoiceForm);
		//InvoiceForm.put("C_CURRENCYCODE", CurrencyCode);
		
		log.info("--->> mainInvoice SERVICE ...");
		ServiceUtility.viewUserParameters(InvoiceForm);
		
		log.info("mode>>>>>"+InvoiceForm.get("mode").toString());
		
		if (InvoiceForm.get("mode").toString().equals("1") || InvoiceForm.get("mode").toString().equals("2")){
			String rv = ServiceUtility.ValidateForm(InvoiceForm);
			if (rv != ""){
				InvoiceForm.put("status", rv);
				return InvoiceForm;
			}
			Date start = DateHelper.parse(InvoiceForm.get("D_INVOICEDATE").toString());
			Calendar cal2 = Calendar.getInstance();
	    	cal2.setTime(start);
	    	cal2.add(Calendar.DATE, Integer.parseInt(InvoiceForm.get("N_TERM").toString()));
	    	if (cal2.get(Calendar.YEAR)<2000){
	    		cal2.set(Calendar.YEAR, cal2.get(Calendar.YEAR)+2000);
	    	}
	    	InvoiceForm.put("D_INVOICEDUEDATE", DateHelper.format(cal2.getTime())) ;
			System.out.println("date>>>>>"+InvoiceForm.get("D_INVOICEDUEDATE").toString());
		} 
		
		if(InvoiceForm.get("mode").toString().trim().equalsIgnoreCase("1")){
			String c=inv.getField("count(*)", "invoice", "c_clntcode="+clntcode+" and c_custcode="+custcode+" and c_invoiceno='"+InvoiceForm.get("C_INVOICENO").toString()+"'");
			if (c.equals("0")){
				returnMap = addInvoice(InvoiceForm);
			}else{
				InvoiceForm.put("status", "Error: Duplicate invoice found");
				returnMap = InvoiceForm;
			}
		} 
		else if (InvoiceForm.get("mode").toString().trim().equalsIgnoreCase("2")){
			returnMap = updateInvoice(InvoiceForm);
		} 
		else if (InvoiceForm.get("mode").toString().trim().equalsIgnoreCase("3")){
			String where = InvoiceForm.get("rowkeys").toString();
			String where2 = InvoiceForm.get("clist").toString();
			String where3 = InvoiceForm.get("clist2").toString();
			String stat = InvoiceForm.get("stat").toString();

			boolean isUpdate=inv.updateInvoiceStatus(stat, where, where2, where3,InvoiceForm.get("C_USERID").toString());
			if(isUpdate){
				InvoiceForm.put("status", "Status updated");
			}
			else{
				InvoiceForm.put("status", "Error updating status");
			}
			
			returnMap = InvoiceForm;
		}
		//else if (InvoiceForm.get("mode").toString().trim().equalsIgnoreCase("4")){
		//	InvoiceForm = searchInvoice(InvoiceForm);
		//	InvoiceForm.put("status", "");
		//	System.out.println("filter:"+InvoiceForm.get("filter"));
		//	returnMap = InvoiceForm;
		//}
		return returnMap;
		
		/*
		if(InvoiceForm.get("mode")!=null && InvoiceForm.get("mode").toString().trim().equalsIgnoreCase("2")){
			return updateInvoice(InvoiceForm);
		}else {
			return addInvoice(InvoiceForm);
		}
		*/

	}

//////////////////////////////////////////////////////////////////////////////////////////////
	@SuppressWarnings("unchecked")
	public Map addInvoice(Map InvoiceForm){
		
		log.info("--->> addInvoice SERVICE ...");
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		
		try{			
			ServiceUtility.viewUserParameters(InvoiceForm);
			
			//Invoice invoice = InvoiceUtility.getInstance().toObject(InvoiceForm);  
			INVOICEDAO INVOICEDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			log.info("***" + InvoiceForm.get("C_CURRENCYCODE"));
			boolean success = INVOICEDAO.addInvoice(InvoiceForm);				
			
			if(success){					

				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(InvoiceForm);
					Invoice invoice = new Invoice(newData);
					as.addAudit(newData.get("C_USERID").toString(),"I","INVOICE",invoice.toString());

				}catch(Throwable x){
					x.printStackTrace();
				}
				
				jsondata.put("status","Add Invoice Successful ...");
				log.info("cn..."+InvoiceForm.get("C_NAME"));
				jsondata.put("clientfilter", InvoiceForm.get("C_NAME"));
				//InvoiceForm.put("clientfilter", InvoiceForm.get("C_NAME"));
				log.info("cf..."+InvoiceForm.get("clientfilter"));
				InvoiceForm.put("clientfilter", InvoiceForm.get("C_NAME"));
			}else{
				jsondata.put("status","Add Invoice Failed ... ");
			}
			
		}catch(Exception x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
			//return jsondata;
		}
		
		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
public String repl(String s){
	String t=s;
	if (t.contains("^1"))
		t = t.replace("^1", "select c_clntcode from dbcif.dbo.client where c_name=");
	if(t.contains("^2"))
		t = t.replace("^2", "AND(N_ADVREFNO IS NULL OR N_ADVREFNO=0)AND(B_ADVANCES=0)AND");
	if(t.contains("^3"))
		t = t.replace("^3", "dbCIF.dbo.Client");
	if(t.contains("^4"))
		t = t.replace("^4", "SELECT C_CURRENCYCODE FROM dbCIF.dbo.Client WHERE (C_NAME = ");
	if(t.contains("^5"))
		t = t.replace("^5", "AND c_status=1 and c_type<>'2'");
	if(t.contains("^6"))
		t = t.replace("^6", "dbo.invoicedc(c_clntcode)");
	if(t.contains("^7"))
		t = t.replace("^7", "dbo.GetClientScr(C_CLNTCODE,(select [currentdate] FROM [factorsGetDate]),1)-dbo.GetDC(C_CLNTCODE,(select [currentdate] FROM [factorsGetDate]),1)"); //before: getDate()
	if(t.contains("^8"))
		t = t.replace("^8", "and c_status = '2' and c_type = '1'");
	if(t.contains("^9"))
		t = t.replace("^9", "dbo.GetClientReceivables(C_CLNTCODE,(select [currentdate] FROM [factorsGetDate]))-dbo.GetClientFIU(C_CLNTCODE,(select [currentdate] FROM [factorsGetDate]))+dbo.GetNFR(C_CLNTCODE,(select [currentdate] FROM [factorsGetDate]))+dbo.GetDCUR(C_CLNTCODE,(select [currentdate] FROM [factorsGetDate]))");
	if(t.contains("^A"))
		t = t.replace("^A", " INNER JOIN ");
	if(t.contains("^B"))
		t = t.replace("^B", "dbo.GetProceeds(C_CLNTCODE,(select [currentdate] FROM [factorsGetDate]))"); //edited for testing //before: getDate()
	if(t.contains("^C"))
		t = t.replace("^C", "dbo.GetProceedsDC(C_CLNTCODE,(select [currentdate] FROM [factorsGetDate]))");  //edited for testing //before: getDate()
	if(t.contains("^D"))
		t = t.replace("^D", "sum(isnull(N_DISCCHG2,0))");
	if(t.contains("^E"))
		t = t.replace("^E", "n_investmentlimit*(select top 1 n_docstamp from docstamp order by d_transactiondate desc)/100");
	//added by CVG
	if(t.contains("^F")){
		t = t.replace("^F", "*(select  top 1 CCLink.N_DUNNING from Invoice"
				+ " inner join dbCIF.dbo.Client on dbCIF.dbo.Client.C_CLNTCODE = Invoice.C_CLNTCODE "
				+ " inner join   CCLink on CCLink.C_custcode = Invoice.C_custcode"
				+ " where Invoice.C_STATUS = '2' and dbCIF.dbo.Client.C_CLNTCODE = CCLink.C_CLNTCODE and dbCIF.dbo.Client.C_NAME =  ");}
				//+ " inner join dbCIF.dbo.Client on dbCIF.dbo.Client.C_CLNTCODE = CCLink.C_CLNTCODE where  dbCIF.dbo.Client.C_NAME ="
	if(t.contains("^G"))
		t = t.replace("^G", " order by CCLink.N_DUNNING desc)");
	if(t.contains("^H"))
		t = t.replace("^H", "(select top 1 sum([N_INVOICEAMT]) over() from [Invoice]  inner join dbCIF.dbo.Client on dbCIF.dbo.Client.[C_CLNTCODE] = [Invoice].[C_CLNTCODE]  where [Invoice].[C_STATUS] = '2' and dbCIF.dbo.Client.[C_NAME] = ");
	if(t.contains("^I"))
		t = t.replace("^I", "N_EXTENSION");
	if(t.contains("^J"))
		t = t.replace("^J", "DATEDIFF(day,(select [currentdate] FROM [factorsGetDate]),[N_END_EXTENSION])");
	if(t.contains("^K"))
		t = t.replace("^K", "N_NOTARIAL");
	if(t.contains("^L"))
		t = t.replace("^L", "dbCIF.dbo.Client_View");
	if(t.contains("^M"))
		t = t.replace("^M", "N_END_EXTENSION>(select [currentdate] FROM [factorsGetDate]) AND "); //before: getDate()
	if(t.contains("^N"))
		t = t.replace("^N", " * (select [N_ADVANCEDRATIO] / 100 from dbCIF.dbo.Client where  dbCIF.dbo.Client.[C_NAME] =  ");
	if(t.contains("^O"))
		t = t.replace("^O", "dbo.ServiceChargeNetAmount(c_clntcode)");
	//<-- pattern
	
	//
	log.info("repl->"+t);
	return t;
}
	
	@SuppressWarnings("unchecked")
public Map qryDb(Map InvoiceForm){
	ServiceUtility.viewUserParameters(InvoiceForm);
	Map returnMap = new HashMap();
	System.out.println("--->> qryDb SERVICE ...");
	
	ServiceUtility.viewUserParameters(InvoiceForm);
	
	String fld = repl(InvoiceForm.get("fld").toString());
	String tbl = repl(InvoiceForm.get("tbl").toString());
	String whr = repl(InvoiceForm.get("whr").toString());
	InvoiceDAO inv = (InvoiceDAO)Persistence.getDAO("invoiceDao");
	//BankDAO inv = (BankDAO)Persistence.getDAO("BankDAO");
	String rv=inv.getField(fld, tbl, whr);
	InvoiceForm.put("rv", rv);
	
	returnMap = InvoiceForm;
	
	return returnMap;
}

@SuppressWarnings("unchecked")
public Map cancelInvoice(Map InvoiceForm) {
	long InvNo=Integer.parseInt(InvoiceForm.get("InvNo").toString());
	boolean result = false;
	Map returnMap = new HashMap();
	Map newData = new HashMap();
	
	
	try {
		newData = ServiceUtility.removeNulls(InvoiceForm);
		newData.put("C_STATUS", "7");
		InvoiceDAO invoiceDAO = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		result = invoiceDAO.cancelInvoice(InvNo,newData.get("C_USERID").toString());
		
		if(result){
	
			try{
				
				AuditService as = AuditService.getInstance();
				Invoice invoice = new Invoice(newData);
				log.info("UID=>"+newData.get("C_USERID").toString());
				log.info("invoice=>"+invoice.toString());
				as.addAudit(newData.get("C_USERID").toString(),"U","INVOICE",invoice.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}	
			
		}
	}
	catch (Exception e) {			
		e.printStackTrace();
	}
	if (result){
		returnMap.put("rv", "true");
	} else {
		returnMap.put("rv", "false");
	}
	return returnMap;
}
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map updateInvoice(Map InvoiceForm){
		
		log.info("--->> updateInvoice SERVICE ...");
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		
		try{
			ServiceUtility.viewUserParameters(InvoiceForm);
			//Invoice invoice = InvoiceUtility.getInstance().toObject(InvoiceForm);
			
			INVOICEDAO InvoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");		
			
			
			boolean success = InvoiceDAO.updateInvoice(InvoiceForm);
			System.out.println("+++++++++++"+success);
			if(success) {

				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(InvoiceForm);
					Invoice invoice = new Invoice(newData);
					as.addAudit(newData.get("C_USERID").toString(),"U","INVOICE",invoice.toString());

				}catch(Throwable x){
					x.printStackTrace();
				}
				
				jsondata.put("status","Update Invoice Successful ...");
			}else{
				jsondata.put("status","Update Invoice Failed ... ");
			}
			
		}catch(Exception x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
	
public Map updateInvoice2(Map InvoiceForm){
		
		log.info("--->> updateInvoice2 SERVICE ...");
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		
		try{
			Date start = DateHelper.parse(InvoiceForm.get("D_INVOICEDATE").toString());
			Calendar cal2 = Calendar.getInstance();
	    	cal2.setTime(start);
	    	cal2.add(Calendar.DATE, Integer.parseInt(InvoiceForm.get("N_TERM").toString()));
	    	if (cal2.get(Calendar.YEAR)<2000){
	    		cal2.set(Calendar.YEAR, cal2.get(Calendar.YEAR)+2000);
	    	}
	    	InvoiceForm.put("D_INVOICEDUEDATE", DateHelper.format(cal2.getTime())) ;
	    	
	    	if(InvoiceForm.containsKey("D_ACTUALPAIDDATE")&&InvoiceForm.get("D_ACTUALPAIDDATE").toString().contentEquals("null")){
	    		InvoiceForm.put("D_ACTUALPAIDDATE",null);
	    	}
	    	
			ServiceUtility.viewUserParameters(InvoiceForm);
			//Invoice invoice = InvoiceUtility.getInstance().toObject(InvoiceForm);
			
			INVOICEDAO InvoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");		
			
			
			boolean success = InvoiceDAO.updateInvoice2(InvoiceForm);
			log.info("+++++++++++"+success);
			if(success) {

				try{
					
					AuditService as = AuditService.getInstance();
					newData = ServiceUtility.removeNulls(InvoiceForm);
					Invoice invoice = new Invoice(newData);
					as.addAudit(newData.get("C_USERID").toString(),"U","INVOICE",invoice.toString());

				}catch(Throwable x){
					x.printStackTrace();
				}
				
				jsondata.put("status","Update Invoice Successful ...");
			}else{
				jsondata.put("status","Update Invoice Failed ... ");
			}
			
		}catch(Exception x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
	
	public boolean updateInvoiceStatusByCode(String invoices, String c_Status) {
		
		boolean result = false;
		
		try {
			INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			result = invoiceDAO.updateInvoiceStatusByCode(invoices, c_Status);
			
		}
		catch (Exception e) {			
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean updateInvoiceFullyPaidDateByCode(String invoices, Date fullyPaidDate) {
		
		boolean result = false;

		
		try {
			INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			result = invoiceDAO.updateInvoiceFullyPaidDateByCode(invoices, fullyPaidDate);
			
		}
		catch (Exception e) {			
			e.printStackTrace();
		}
		return result;
	}
	
	// added BY CVG as of 04-14-16 for Invoice Status (C_status / C_type) bug-----------------
	
public boolean updateInvoiceFullyPaidDateByCodeNew(String invoices, Date fullyPaidDate) {
		
		boolean result = false;
		try {
			INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			result = invoiceDAO.updateInvoiceFullyPaidDateByCodeNew(invoices, fullyPaidDate);
		}
		catch (Exception e) {			
			e.printStackTrace();
		}
		return result;
	}
	
	// end-----------------------------------------------------------------
	
	
	
	
	
	public boolean updateInvoiceStatusAndDateByCode(String invoices, String c_Status, Date fullyPaidDate) {
		
		boolean result = false;
	
		
		try {
			INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
			result = invoiceDAO.updateInvoiceStatusAndDateByCode(invoices, c_Status, fullyPaidDate);
			
		}
		catch (Exception e) {			
			e.printStackTrace();
		}
		return result;
	}
	
	public Map getPenaltyCharge(Map m){
		System.out.println("--->>entering getPenaltyCharge...");
		ServiceUtility.viewUserParameters(m);
		Map map = new HashMap();
		InvoiceDAO ID = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		map = ID.getPenaltyCharge(m);
		ServiceUtility.viewUserParameters(map);
		return map;
	}
	
	public Map getPreviousPartial(Map m){
		System.out.println("--->>entering getPenaltyCharge...");
		ServiceUtility.viewUserParameters(m);
		 String map = "";
		InvoiceDAO ID = (InvoiceDAO)Persistence.getDAO("invoiceDao");
		map = ID.getPreviousPartial(m);
	    Map returnData = new HashMap();
	    returnData.put("otherCharges", map);
	    System.out.println(map);
		return returnData;
	}

	

	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchScheduleInvoice(Map InvoiceForm){
		
		System.out.println("--->> searchScheduleInvoice xxx...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		String customerCode = "";
		
		
		try{
			
			ServiceUtility.viewUserParameters(InvoiceForm);
			System.out.println("--->> searchInvoice 1");

			INVOICEDAO InvoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");	
			String recordSize = InvoiceDAO.getScheduleOfInvoicesCount(InvoiceForm);	
			totalRecords = recordSize;
			
			System.out.println("--->> totalRecords RECORD-SIZE: "+totalRecords);
			
			InvoiceForm = ServiceUtility.addPaging(InvoiceForm,totalRecords);
			records = InvoiceDAO.searchScheduleInvoice(InvoiceForm);	
						
			System.out.println("--->> searchInvoice RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)InvoiceForm.get("records")),((String)InvoiceForm.get("page")),((String)InvoiceForm.get("total")));
			}else{
				jsondata.put("status","Search Invoice Failed ... ");
			}
	
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////

	//////added October 03, 2012//////
	public Map searchDelinquent(Map webData){
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		log.info("--->> searchDelinquent SERVICE X...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		String customerCode = "";
		String clientCode = "";
		webData.put("d_transactionDate", date.newDate()); //before: new Date()
		
		
		try{
			
			ServiceUtility.viewUserParameters(webData);
			log.info("--->> searchDelinquent 1");
					
			INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");	
			
			System.out.println("--->> searchClientResolveToCode 2XX");
			
			///////////////////////////////////////////////
			if (webData.get("C_NAME")!=null){
				ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
				clientCode = clientDAO.searchClientResolveToCode(webData);
				webData.put("C_CLNTCODE", clientCode);
			}
		
			totalRecords = invoiceDAO.getTotalDelinquent(webData);	
			
			ServiceUtility.viewUserParameters(webData);
			log.info("--->> searchDelinquent 2 "+totalRecords);

			webData = ServiceUtility.addPaging(webData,totalRecords);
			
			records = invoiceDAO.searchDelinquent(webData);	
		
			ServiceUtility.viewUserParameters(webData);
						
			log.info("--->> searchDelinquent RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)webData.get("records")),((String)webData.get("page")),((String)webData.get("total")));
			}else{
				jsondata.put("status","searchDelinquent Failed ... ");
			}

		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}

	public Map getAmountDelinquent(Map map){
		FactorsDateDAO date = (FactorsDateDAO)Persistence.getDAO("FactorsDateDAO");
		String clientCode;
		map.put("d_transactionDate", date.newDate()); //before: new Date()
		if (map.get("C_NAME")!=null){
			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientCode = clientDAO.searchClientResolveToCode(map);
			map.put("C_CLNTCODE", clientCode);
		}
		
		INVOICEDAO invoiceDAO = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
		
		Double total =  Double.parseDouble(invoiceDAO.getAmountDelinquent(map));
		
		map.put("rv", total>0?total:0);
		map.put("rv2",total>0?"There are delinquent invoice(s) for this client":0);
		return map;
	}
	
	public Map getDelinquentForEdit(Map dataMap){
		Map data = new HashMap();
		INVOICEDAO ID = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
		data = ServiceUtility.toJQGrid2(ID, "getDelinquentForEdit", dataMap); 
		return data;
	}
	
	
	public boolean updateInvoiceTransaction(Map dataMap){
		INVOICEDAO ID = (INVOICEDAO)Persistence.getDAO("INVOICEDAO");
		return ID.updateInvoiceTransaction(dataMap);
		
	}

}
