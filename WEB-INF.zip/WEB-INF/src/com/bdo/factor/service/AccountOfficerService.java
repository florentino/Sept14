package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.AccountOfficer;
import com.bdo.factor.dao.AccountOfficerDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.AccountOfficerUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class AccountOfficerService {
	
	private static Logger log = Logger.getLogger(AccountOfficerService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static AccountOfficerService thisAccountOfficerService = new AccountOfficerService();
	
	private AccountOfficerService() { }

	public static AccountOfficerService getInstance() {
		return thisAccountOfficerService;
	}
	
	public AccountOfficer getAccountOfficerByCode(String C_ACCTOFFICERCODE){
		AccountOfficerDAO AccountOfficerDAO = (AccountOfficerDAO)Persistence.getDAO("AccountOfficerDAO");
		return AccountOfficerDAO.getAccountOfficerByCode (C_ACCTOFFICERCODE);
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////	
	public List searchAccountOfficerByAOCode(String c_accountofficercode){
		log.info("--->> searchAcctOffcrByAOCode SERVICE ...");
		
		AccountOfficerDAO AccountOfficerDAO = (AccountOfficerDAO)Persistence.getDAO("AccountOfficerDAO");
				
		return AccountOfficerDAO.searchAccountOfficerByAOCode(c_accountofficercode);		
	}	
	
	public List searchAccountOfficerByCode(String c_accountofficercode, String c_BranchCode){
		log.info("--->> searchAcctOffcrByAOCode SERVICE ...");		
		Map map = new HashMap();
		map.put("C_ACCTOFFICERCODE", c_accountofficercode);
		map.put("C_BRANCHCODE", c_BranchCode);
		
		AccountOfficerDAO AccountOfficerDAO = (AccountOfficerDAO)Persistence.getDAO("AccountOfficerDAO");
				
		return AccountOfficerDAO.searchAccountOfficerByCode(map);		
	}	
//////////////////////////////////////////////////////////////////////////////////////////////
	
		
	public Map searchAccountOfficer(Map accountOfficerForm){
		
		log.info("--->> searchAccountOfficer SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		String c_BranchCode = "";
		
		try{
			
			ServiceUtility.viewUserParameters(accountOfficerForm);
			c_BranchCode = (String) accountOfficerForm.get("C_BRANCHCODE");
									
			AccountOfficerDAO accountOfficerDAO = (AccountOfficerDAO)Persistence.getDAO("AccountOfficerDAO");				
			totalRecords = accountOfficerDAO.getTotalRecordsAccountOfficer(c_BranchCode);	
			
			accountOfficerForm = ServiceUtility.addPaging(accountOfficerForm,totalRecords);			
			
			records = accountOfficerDAO.searchAccountOfficer(accountOfficerForm);	
		
			ServiceUtility.viewUserParameters(accountOfficerForm);
						
			log.info("--->> searchAccountOfficer RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)accountOfficerForm.get("records")),((String)accountOfficerForm.get("page")),((String)accountOfficerForm.get("total")));
			}else{
				jsondata.put("status","searchAccountOfficer Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
	public Map addAccountOfficer(Map accountOfficerForm){
		
		log.info("--->> addAccountOfficer SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			
			ServiceUtility.viewUserParameters(accountOfficerForm);
			
			AccountOfficer aOfficer = AccountOfficerUtility.toObject(accountOfficerForm);
			log.info("ao:" + aOfficer.toString());
			
			String operation = (String) accountOfficerForm.get("operation");			
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {				
				this.updateAccountOfficer(accountOfficerForm);
			}
			else {
			
				AccountOfficerDAO accountOfficerDAO = (AccountOfficerDAO)Persistence.getDAO("AccountOfficerDAO");	
				
				boolean duplicate = this.isDuplicate(aOfficer.getC_AccountOfficerCode(), aOfficer.getC_BranchCode());
				if (duplicate) {
					jsondata.put("status","Failed to Add Account Officer. Record with same account officer code already exists.");
					return jsondata;
				}		
				
				boolean success = accountOfficerDAO.addAccountOfficer(accountOfficerForm);
				
				
				if(success){
					String userID = (String) accountOfficerForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "ACCOUNTOFFICER", aOfficer.toString());
					
					jsondata.put("status","Add Account Officer Successful ...");
				}else{
					jsondata.put("status","Add Account Officer Failed ... ");
				}
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map updateAccountOfficer(Map accountOfficerForm){
		
		log.info("--->> updateAccountOfficer SERVICE ...");
		log.debug("map: " + accountOfficerForm.values());
		
		Map jsondata = new HashMap();
		accountOfficerForm.put("C_ACCTOFFICERCODE", accountOfficerForm.get("C_ACCTOFFICERCODE_ORIG"));
		
		try{
			AccountOfficer aOfficer = AccountOfficerUtility.toObject(accountOfficerForm);
			ServiceUtility.viewUserParameters(accountOfficerForm);		
			
			AccountOfficerDAO accountOfficerDAO = (AccountOfficerDAO)Persistence.getDAO("AccountOfficerDAO");
						
			boolean success = accountOfficerDAO.updateAccountOfficer(accountOfficerForm);
					
			if(success){
				String userID = (String) accountOfficerForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "ACCOUNTOFFICER", aOfficer.toString());
				
				jsondata.put("status","Update Account Officer Successful ...");
			}else{
				jsondata.put("status","Update Account Officer Failed ... ");
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
			
	public Map deleteAccountOfficer(Map accountOfficerForm){
		
		log.info("--->> deleteAccountOfficer SERVICE ...");
		
		Map jsondata = new HashMap();
		accountOfficerForm.put("C_BRANCHCODE", accountOfficerForm.get("C_BRANCHCODE_ORIG"));
		accountOfficerForm.put("C_ACCTOFFICERCODE", accountOfficerForm.get("C_ACCTOFFICERCODE_ORIG"));
		
		try{
			AccountOfficer aOfficer = AccountOfficerUtility.toObject(accountOfficerForm);
			ServiceUtility.viewUserParameters(accountOfficerForm);
			
			AccountOfficerDAO accountOfficerDAO = (AccountOfficerDAO)Persistence.getDAO("AccountOfficerDAO");
			boolean success = accountOfficerDAO.deleteAccountOfficer(accountOfficerForm);
			
					
			if(success){
				String userID = (String) accountOfficerForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "ACCOUNTOFFICER", aOfficer.toString());
				
				jsondata.put("status","Delete Account Officer Successful ...");
			}else{
				jsondata.put("status","Delete Account Officer Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}		

		return jsondata;
	}
	
	public boolean isDuplicate(String c_AccountOfficerCode, String c_BranchCode) {
		List l = this.searchAccountOfficerByCode(c_AccountOfficerCode, c_BranchCode);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
		
//////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchAccountOfficerAutoComplete(Map accountOfficerForm){
		
		System.out.println("--->> searchAccountOfficerAutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(accountOfficerForm);
			
			AccountOfficerDAO accountOfficerDAO = (AccountOfficerDAO)Persistence.getDAO("AccountOfficerDAO");				
			records = (ArrayList)accountOfficerDAO.searchAccountOfficerAutoComplete(accountOfficerForm);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////		
	
	
	
	
}
