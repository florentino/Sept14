
 

package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Bank;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.CheckTypeDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.RepSubledgerDAO;
import com.bdo.factor.util.BankUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;


public class ReportSubledgerService {
	private static Logger log = Logger.getLogger(ReportSubledgerService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	private static ReportSubledgerService thisGLCodeService = new ReportSubledgerService();
			
	
	private ReportSubledgerService() { }

	public static ReportSubledgerService getInstance() {
		return thisGLCodeService;
	}
	
	public Map searchGLCodeAutoComplete(Map GLCode){
		ServiceUtility.viewUserParameters(GLCode);
		
		log.info("--->> searchGLCodeAutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
		
			RepSubledgerDAO repSubledgerDAO = (RepSubledgerDAO)Persistence.getDAO("RepSubledgerDAO");				
			records = (ArrayList)repSubledgerDAO.searchGLCodeAutoComplete(GLCode);
			resultString = JQGridJSONFormatter.formatListToString(records);
			jsondata.put("AUTOCOMPLETE",resultString);
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		return jsondata;
	}	
	
	
public Map searchGLCodeDescription(Map GLDescToGLCode) {
		
		log.info("--->> searchGLCodeDescription SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();

		try{
			RepSubledgerDAO repSubledgerDAO = (RepSubledgerDAO) Persistence.getDAO("RepSubledgerDAO");
			records = repSubledgerDAO.searchGLDescriptionToGLCode(GLDescToGLCode);
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		
		jsondata.put("returnData", records);

		log.info("--->> searchGLCodeDescription RECORD SIZE: " + records.size());

		return jsondata;
	}

	
	
	
public Map getFieldsSubLedgerReport(Map form){
		ServiceUtility.viewUserParameters(form);
		
		log.info("--->> getFieldsSubLedgerReport SERVICE ...");
		
		log.info("map: " + form.values());
		log.info("map: " + form.get("clientName").toString().trim());
		log.info("map: " + form.get("asOfDate").toString().trim());
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		return jsondata;
	}

//select element option
public Map searchAccountName(Map clientForm) {

	log.info("--->> searchAccountName SERVICE ...");
	

	Map jsondata = new HashMap();
	List<Map> records = new ArrayList();
	String resultString = "";

	try {

		ServiceUtility.viewUserParameters(clientForm);
		
		RepSubledgerDAO repSubledgerDAO = (RepSubledgerDAO) Persistence.getDAO("RepSubledgerDAO");
		//records = ;
		/*
		resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_ACCOUNTNAME","C_ACCOUNTNAME");
		jsondata.put("AUTOCOMPLETE",resultString);
		
		log.info("--->> searchIndustryList RECORD-SIZE: "+ records.size());*/
 
		//change to toJSONGetList to correct keyMaps Cherrie Garcia
		AccountingMaintenanceService AMS = AccountingMaintenanceService.getInstance();
		jsondata = AMS.toJSON(repSubledgerDAO.searchGLCodeAutoComplete(clientForm));
	} catch (Throwable x) {
		jsondata.put("status", x.getMessage());
		x.printStackTrace();
	}

	return jsondata;
}


}

