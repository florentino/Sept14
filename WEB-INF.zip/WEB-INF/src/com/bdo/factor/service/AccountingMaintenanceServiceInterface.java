package com.bdo.factor.service;

import java.util.List;
import java.util.Map;

public interface AccountingMaintenanceServiceInterface {
	
	//CHART OF ACCOUNTS
	public Map getChartOfAccount(Map m);
	public Map addChartOfAccount(Map m);
	public Map editChartOfAccount(Map m);
	public Map deleteChartOfAccount(Map m);
	public Map getChartList(Map m);
	public List getGLList();
	public Double getAmount(String GLCode);
	public Map searchJournalChartEntry(Map m);
	
	//COST CENTER
	public Map getCostCenter(Map m);
	public Map addCostCenter(Map m);
	public Map editCostCenter(Map m);
	public Map deleteCostCenter(Map m);
	//previous code public Map getCostCenterList(Map m);
	public Map getCostCenterList(Map m);
	
	//PENALTY CHARGES
	public Map getPenaltyCharge(Map m);
	public Map addPenChg(Map m);
	
	//EXTRA
	public Map getClientCode(Map m);
 
	public Boolean saveTransactionRate(Map m);
	public Object queryForObject(String sql);
}
