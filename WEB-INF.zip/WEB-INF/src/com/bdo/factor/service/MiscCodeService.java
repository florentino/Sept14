package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import org.apache.log4j.Logger;

import com.bdo.factor.beans.User;
import com.bdo.factor.dao.MiscCodeDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.UserDAO;
import com.bdo.factor.util.DateHelper;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;
import com.bdo.factor.util.EncryptorUtil;
import com.bdo.factor.util.Validator;
import com.bdo.factor.service.SecurityService;


public class MiscCodeService {
	private static Logger log = Logger.getLogger(MiscCodeService.class);
	//private static java.util.ResourceBundle rb = java.util.ResourceBundle.getBundle("_properties/fileLocation");
	SecurityService rb = SecurityService.getInstance();
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static MiscCodeService miscCodeServiceInstance = new MiscCodeService();
	
	public MiscCodeService() { }

	public static MiscCodeService getInstance() {
		return miscCodeServiceInstance;
	}
		
/////////////////////////////1/////////////////////////////////////////////////////////////////
	

	
	@SuppressWarnings("unchecked")
	public Map getClientClassificationServiceToDecription(Map role)
	{
		System.out.println("--->> @@getClientClassificationServiceToDecription SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(role);
			MiscCodeDAO miscCodeDAO = (MiscCodeDAO)Persistence.getDAO("MiscCodeDAO");				
			records = miscCodeDAO.getClientClassificationToDescription(role);
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"DESCRIPTION", "DESCRIPTION");
			jsondata.put("AUTOCOMPLETE",resultString);
			log.info(" ----- > @@ getClientClassificationServiceToDecription" + resultString);					
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
	
	

	@SuppressWarnings("unchecked")
	public Map getBusinessIndustryService(Map role)
	{
		System.out.println("--->> @@getBusinessIndustryService SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(role);
			MiscCodeDAO miscCodeDAO = (MiscCodeDAO)Persistence.getDAO("MiscCodeDAO");				
			records = (ArrayList)miscCodeDAO.getBusinessIndustry(role);
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"DESCRIPTION", "DESCRIPTION");
			jsondata.put("AUTOCOMPLETE",resultString);
			log.info(" ----- > @@ getBusinessIndustry" + resultString);					
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
	
	
	@SuppressWarnings("unchecked")
	public Map getBusinessClassificationService(Map role)
	{
		System.out.println("--->> @@getBusinessClassificationService SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(role);
			MiscCodeDAO miscCodeDAO = (MiscCodeDAO)Persistence.getDAO("MiscCodeDAO");				
			records = (ArrayList)miscCodeDAO.getBusinessClassification(role);
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"DESCRIPTION", "DESCRIPTION");
			jsondata.put("AUTOCOMPLETE",resultString);
			log.info(" ----- > @@ getBusinessIndustry" + resultString);					
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
}
