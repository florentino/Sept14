package com.bdo.factor.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.AccountOfficer;
import com.bdo.factor.dao.AccountOfficerDAO;
import com.bdo.factor.dao.BranchDAO;
import com.bdo.factor.dao.CCLinkDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class CCLinkService {
	private static Logger log = Logger.getLogger(CCLinkService.class);
/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static CCLinkService CCLinkServiceServiceInstance = new CCLinkService();
	
	private CCLinkService() { }

	public static CCLinkService getInstance() {
		log.info("-->> CCLinkService getInstance...");
		return CCLinkServiceServiceInstance;
	}

//////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public Map searchCCLink(Map ccLinkForm) {

		log.info("--->> searchCCLink SERVICE 1...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		
		CCLinkDAO ccLinkDAO = (CCLinkDAO) Persistence.getDAO("CCLinkDAO");
		records = ccLinkDAO.searchCCLink(ccLinkForm);
				
		jsondata.put("returnData",records);
		
		log.info("--->> searchClient RECORD SIZE: "+records.size());
		
		return jsondata;
	}

	
//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map searchCCLinkByCode(Map ccLinkForm){
		
		log.info("--->> searchCCLinkByCode SERVICE ...");
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		List records = new ArrayList();
		
		try{
			
			CCLinkDAO ccLinkDAO = (CCLinkDAO) Persistence.getDAO("CCLinkDAO");			
			records = ccLinkDAO.searchCCLinkByCode(ccLinkForm);
			
			try{
				newData = (HashMap) records.get(0);
			} catch (Throwable x) {
				jsondata.put("status", x.getMessage());
				x.printStackTrace();
			}
			
			newData = ServiceUtility.removeNulls(newData);
			
			records = new ArrayList();
			records.add(newData);
			
			jsondata.put("returnData",records);
				
			log.info("--->> searchCCLinkByCode RECORD-SIZE: "+records.size());
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
	public boolean updateRunningBalance (String clientCode, String custCode, double amount, String userID) {
		boolean result = false;
		try {
			CCLinkDAO ccLinkDAO = (CCLinkDAO) Persistence.getDAO("CCLinkDAO");	
			double runningBalance = ccLinkDAO.searchRunningBalByCustomer(clientCode, custCode);
			double oldRunningBal = runningBalance;
			log.info("old RunningBalance: " + runningBalance);
			runningBalance = runningBalance - amount;
			log.info("new RunningBalance: " + runningBalance);
			
			Map map = new HashMap();
			map.put("C_CLNTCODE", clientCode);
			map.put("C_CUSTCODE", custCode);
			map.put("N_RUNNINGBAL", runningBalance);		
			result = ccLinkDAO.updateRunningBalByClient(map);
			
			AuditService as = AuditService.getInstance();
			StringBuilder sb = new StringBuilder("C_CLNTCODE=").append(clientCode).append(";");
			sb.append("C_CUSTCODE=").append(custCode).append(";");
			sb.append("OLD N_RUNNINGBAL=").append(oldRunningBal).append(";");
			sb.append("NEW N_RUNNINGBAL=").append(runningBalance).append(";");
						
			as.addAudit(userID, "U", "CCLINK", sb.toString());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	//rdc06162010
	public boolean cancelRunningBalance (String clientCode, String custCode, double amount, String userID) {
		boolean result = false;
		try {
			CCLinkDAO ccLinkDAO = (CCLinkDAO) Persistence.getDAO("CCLinkDAO");	
			double runningBalance = ccLinkDAO.searchRunningBalByCustomer(clientCode, custCode);
			double oldRunningBal = runningBalance;
			log.info("old RunningBalance: " + runningBalance);
			runningBalance = runningBalance + amount;
			log.info("new RunningBalance: " + runningBalance);
			
			Map map = new HashMap();
			map.put("C_CLNTCODE", clientCode);
			map.put("C_CUSTCODE", custCode);
			map.put("N_RUNNINGBAL", runningBalance);		
			result = ccLinkDAO.updateRunningBalByClient(map);
			
			AuditService as = AuditService.getInstance();
			StringBuilder sb = new StringBuilder("C_CLNTCODE=").append(clientCode).append(";");
			sb.append("C_CUSTCODE=").append(custCode).append(";");
			sb.append("OLD N_RUNNINGBAL=").append(oldRunningBal).append(";");
			sb.append("NEW N_RUNNINGBAL=").append(runningBalance).append(";");
						
			as.addAudit(userID, "U", "CCLINK", sb.toString());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean updateRunningBalance (String clientCode, String custCode, double amount) {
		return this.updateRunningBalance(clientCode, custCode, amount, "-");
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	/*
	public Map addCCLink(CCLink acctOfficer) {

		Map jsondata = new HashMap();
		CCLinkDAO acctOfficerDAO = (CCLinkDAO) Persistence
				.getDAO("CCLinkDAO");

		boolean success = acctOfficerDAO.addCCLink(acctOfficer);

		if (success) {
			jsondata.put("status", "addCCLink Successful ...");
		} else {
			jsondata.put("status", "addCCLink Failed ... ");
		}

		return jsondata;
	}

//////////////////////////////////////////////////////////////////////////////////////////////

	public Map updateCCLink(CCLink acctOfficer) {
		Map jsondata = new HashMap();

		CCLinkDAO acctOfficerDAO = (CCLinkDAO) Persistence
				.getDAO("CCLinkDAO");
		boolean success = acctOfficerDAO.updateCCLink(acctOfficer);

		if (success) {
			jsondata.put("status", "Update Successful ...");
		} else {
			jsondata.put("status", "updateCCLink Failed ... ");
		}

		return jsondata;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Map deleteCCLink(String c_CCLinkCode) {
		Map jsondata = new HashMap();

		CCLinkDAO acctOfficerDAO = (CCLinkDAO) Persistence
				.getDAO("CCLinkDAO");

		boolean success = acctOfficerDAO
				.deleteCCLink(c_CCLinkCode);

		if (success) {
			jsondata.put("status", "deleteCCLink Successful ...");
		} else {
			jsondata.put("status", "deleteCCLink Failed ... ");
		}
		return jsondata;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////
	public Map toMap(CCLink ccLink) {
		Map map = new HashMap();
		map.put("C_BRANCHCODE", ccLink.getC_BranchCode());
		map.put("B_TERMINATED", ccLink.getB_Terminated());
		map.put("C_CLNTCODE", ccLink.getC_ClntCode());
		map.put("C_CURRENCY", ccLink.getC_Currency());
		map.put("C_TERMCODE", ccLink.getC_TermCode());
		map.put("N_CCLIMIT1", ccLink.getN_CcLimit1());
		map.put("N_CLLIMIT", ccLink.getN_ClLimit());
		map.put("N_CURINV", ccLink.getN_CurInv());
		map.put("N_OVER120DAY", ccLink.getN_Over120Day());
		map.put("N_OVER150DAY", ccLink.getN_Over150Day());
		map.put("N_OVER180DAY", ccLink.getN_Over180Day());
		map.put("N_OVER210DAY", ccLink.getN_Over210Day());
		map.put("N_OVER30DAY", ccLink.getN_Over30Day());
		map.put("N_OVER60DAY", ccLink.getN_Over60Day());
		map.put("N_OVER90DAY", ccLink.getN_Over90Day());
		
		return map;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////
		
	public CCLink toObject(Map m) {

		HashMap map = (HashMap) m;
		CCLink ccLink = new CCLink();

		ccLink.setC_BranchCode((String) map.get("C_BRANCHCODE"));
		ccLink.setB_Terminated(Byte.parseByte(map.get("B_TERMINATED").toString()));
		ccLink.setC_ClntCode(map.get("C_CLNTCODE").toString());
		ccLink.setC_Currency(map.get("C_CURRENCY").toString());
		ccLink.setC_TermCode(map.get("C_TERMCODE").toString());
		ccLink.setN_CcLimit1(Double.parseDouble(map.get("N_CCLIMIT1").toString()));
		ccLink.setN_ClLimit(Double.parseDouble(map.get("N_CLLIMIT").toString()));
		ccLink.setN_CurInv(Double.parseDouble(map.get("N_CURINV").toString()));
		ccLink.setN_Over120Day(Double.parseDouble(map.get("N_OVER120DAY").toString()));
		ccLink.setN_Over150Day(Double.parseDouble(map.get("N_OVER150DAY").toString()));
		ccLink.setN_Over180Day(Double.parseDouble(map.get("N_OVER180DAY").toString()));
		ccLink.setN_Over210Day(Double.parseDouble(map.get("N_OVER210DAY").toString()));
		ccLink.setN_Over30Day(Double.parseDouble(map.get("N_OVER30DAY").toString()));
		ccLink.setN_Over60Day(Double.parseDouble(map.get("N_OVER60DAY").toString()));
		ccLink.setN_Over90Day(Double.parseDouble(map.get("N_OVER90DAY").toString()));
		
		return ccLink;

	}

	public static void main(String[] args) {
	
	}
	
	*/
}
