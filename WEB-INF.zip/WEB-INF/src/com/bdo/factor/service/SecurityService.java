package com.bdo.factor.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.crypto.SecretKey;
import javax.print.DocFlavor.URL;

import org.apache.log4j.Logger;

import com.bdo.factor.controller.LogOnFormController;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.SecurityDAO;
import com.bdo.factor.dao.SystemSettingsDAO;
import com.bdo.factor.dao.UserDAO;
import com.bdo.factor.util.DecryptorUtil;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;
import com.bdo.factor.util.Validator;
import com.bdo.factor.beans.ClassReference;
import com.bdo.factor.beans.ParameterSettings;
import com.bdo.factor.util.ClassReferenceUtility;
import com.bdo.factor.beans.ModuleReference;
import com.bdo.factor.util.ModuleReferenceUtility;
import com.bdo.factor.beans.ModuleClass;
import com.bdo.factor.util.ModuleClassUtility;
import com.bdo.factor.beans.RoleReference;
import com.bdo.factor.util.RoleReferenceUtility;
import com.bdo.factor.beans.RoleModule;
import com.bdo.factor.util.RoleModuleUtility;
import com.lowagie.text.pdf.codec.Base64.InputStream;



public class SecurityService extends LogOnFormController {
	
	private static Logger log = Logger.getLogger(SecurityService.class);

/////////////////////////////////// SINGLETON ////////////////////////////////////////////////
	
	private static SecurityService securityService = new SecurityService();
	private static Map PSettings;
	private static String  defaultpasswd;
	private static String  useridmin;
	private static String  passwdmin;		
	private static String  passwdexpire;
	private static String  passwdwarning;
	private static String  deactivate;
	private static String  disable;
	private static String  purging;
	private static String n_try;
	private static Map form;
	private static String testMsg = null;
	private static int passwdhistory;
	private static int sessionTimeout;
	
	private SecurityService() { }

	public static SecurityService getInstance() {
		return securityService;
	}
	
	public Map searchClasses(Map classesForm){
		
		log.info("--->> searchClasses SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		try{
			
			ServiceUtility.viewUserParameters(classesForm);
									
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");
			totalRecords = securityDAO.getTotalRecordsClasses();
			
			classesForm = ServiceUtility.addPaging(classesForm,totalRecords);
			
			String orderField = classesForm.get("orderField") != null ? classesForm.get("orderField").toString() : "";
			String sortField = classesForm.get("sortField") != null ? classesForm.get("sortField").toString() : "";
			
			if (orderField.trim().equalsIgnoreCase("")) {
				orderField = "asc";
			}
			
			if (sortField.trim().equalsIgnoreCase("")) {
				sortField = "CLASS_NAME";
			}
			
			classesForm.put("sortField", sortField);
			classesForm.put("orderField", orderField);					
			
			
			records = securityDAO.searchClasses(classesForm);	
		
			ServiceUtility.viewUserParameters(classesForm);
						
			log.info("--->> searchClasses RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)classesForm.get("records")),((String)classesForm.get("page")),((String)classesForm.get("total")));
			}else{
				jsondata.put("status","Search Classes Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
				
	public List searchClassesByCode(String class_name){
		log.info("--->> searchClassesByCode SERVICE ...");		
		Map map = new HashMap();
		map.put("CLASS_NAME", class_name);
		
		SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");
				
		return securityDAO.searchClassesByCode(map);		
				
	}
	
	public Map addClasses(Map classesForm){
		
		log.info("--->> addClasses SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			
			ServiceUtility.viewUserParameters(classesForm);
			
			ClassReference classreference = ClassReferenceUtility.toObject(classesForm);
			log.info("cr:" + classreference.toString());
			
			
			
			String operation = (String) classesForm.get("operation");			
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {
				if (!classesForm.containsKey("CLASS_NAME_ORIG")||classesForm.get("CLASS_NAME_ORIG").toString().length()==0){
					jsondata.put("status","Update Class Reference Failed ...");
					return jsondata;
				}
				this.updateClasses(classesForm);
			}
			else {
				if (!classesForm.containsKey("CLASS_NAME")||classesForm.get("CLASS_NAME").toString().length()==0){
					jsondata.put("status","Add Class Reference Failed ...");
					return jsondata;
				}
			
				SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	
				
				boolean duplicate = this.isDuplicate(classreference.getCLASS_NAME());
				if (duplicate) {
					jsondata.put("status","Failed to Add Class Reference. Record with same Class Name already exists.");
					return jsondata;
				}
				
				
				
				boolean success = securityDAO.addClasses(classesForm);
				
				
				if(success){
					String userID = (String) classesForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					StringBuilder str = new StringBuilder(); 
					str.append("New Class Created. Class Name: "+classesForm.get("CLASS_NAME")+"; Class Description: "+classesForm.get("CLASS_DESC")+"; URL: "+classesForm.get("URL"));
					as.addAudit(userID, "I", "CLASSREFERENCE", str.toString());
					
					jsondata.put("status","Add Class Reference Successful ...");
				}else{
					jsondata.put("status","Add Class Reference Failed ... ");
				}
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	public Map updateClasses(Map classesForm){
		
		log.info("--->> updateClassReference SERVICE ...");
		log.debug("map: " + classesForm.values());
		
		Map jsondata = new HashMap();
		
		try{
			ClassReference classreference = ClassReferenceUtility.toObject(classesForm);
			ServiceUtility.viewUserParameters(classesForm);		
			
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");
			
		//	String classname = (String) classesForm.get("CLASS_NAME");
			ClassReference CR = securityDAO.getClassReference(classesForm.get("CLASS_NAME_ORIG").toString());
		//	System.out.println("-----------------> classname : " +classname);
		//	String oldValue = auditCreator.getOldValue(auditCreator.CLASSREFERENCE, classesForm.get("CLASS_NAME_ORIG").toString());
			boolean success = securityDAO.updateClasses(classesForm);
					
			if(success){
				String userID = (String) classesForm.get("C_USERID");
				ClassReference NewCR = ClassReferenceUtility.toObject(classesForm);
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "CLASSREFERENCE", NewCR.toAuditString(CR));
				
				jsondata.put("status","Update Class Reference Successful ...");
			}else{
				jsondata.put("status","Update Class Reference Failed ... ");
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
	
	public boolean isDuplicate(String class_name) {
		List l = this.searchClassesByCode(class_name);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
public Map searchModules(Map modulesForm){
		
		log.info("--->> searchModules SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		try{
			
			ServiceUtility.viewUserParameters(modulesForm);
									
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");				
			totalRecords = securityDAO.getTotalRecordsModules();
			
			modulesForm = ServiceUtility.addPaging(modulesForm,totalRecords);
			
			String orderField = modulesForm.get("orderField") != null ? modulesForm.get("orderField").toString() : "";
			String sortField = modulesForm.get("sortField") != null ? modulesForm.get("sortField").toString() : "";
			if (orderField.trim().equalsIgnoreCase("")) {
				orderField = "asc";
			}
			
			if (sortField.trim().equalsIgnoreCase("")) {
				sortField = "MOD_NAME";
			}
			
			modulesForm.put("sortField", sortField);
			modulesForm.put("orderField", orderField);	
			
			records = securityDAO.searchModules(modulesForm);	
		
			ServiceUtility.viewUserParameters(modulesForm);
						
			log.info("--->> searchModules RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)modulesForm.get("records")),((String)modulesForm.get("page")),((String)modulesForm.get("total")));
			}else{
				jsondata.put("status","Search Modules Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
			
public List searchAvailModule(Map role){
	
	log.info("--->> searchAvailModule SERVICE ...");
	
	Map jsondata = new HashMap();
	List records = new ArrayList();

	try{									
		SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");				
		records = securityDAO.searchAvailModule(role);			
		log.info("--->> searchAvailModule RECORD-SIZE: "+records.size());
	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}	
	return records;
}	

	public List searchModulesByCode(String mod_name){
		log.info("--->> searchModulesByCode SERVICE ...");		
		Map map = new HashMap();
		map.put("MOD_NAME", mod_name);
		
		SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");
				
		return securityDAO.searchModulesByCode(map);		
				
	}
	
	public Map addModules(Map modulesForm){
		
		log.info("--->> addModules SERVICE ...");
		
		Map jsondata = new HashMap();
		Validator validator = new Validator();
		
		try{
			
			ServiceUtility.viewUserParameters(modulesForm);
			
			ModuleReference modulereference = ModuleReferenceUtility.toObject(modulesForm);
			log.info("mr:" + modulereference.toString());
			
			
			if(modulereference.getMOD_NAME()!=null&&(modulereference.getMOD_NAME().isEmpty()||modulereference.getMOD_NAME().length()>10)){
				jsondata.put("status", "Invalid module name");
				return jsondata;
			}
			if(modulereference.getMOD_DESC()!=null&&(modulereference.getMOD_DESC().isEmpty()||modulereference.getMOD_DESC().length()>255)){
				jsondata.put("status", "Invalid module description");
				return jsondata;
			}
			
			if((modulereference.getPARENT_MOD_NAME()!=null||!modulereference.getPARENT_MOD_NAME().isEmpty())&&modulereference.getPARENT_MOD_NAME().length()>10){
				jsondata.put("status", "Invalid Parent Module Name");
				return jsondata;
			}
			
			if(!modulesForm.get("CLASS_ORDER").toString().trim().isEmpty()){
				if(!validator.isNumeric(modulesForm.get("CLASS_ORDER").toString().trim()) || modulesForm.get("CLASS_ORDER").toString().trim().equals("0"))
				{
					jsondata.put("status", "Invalid Number Entry for CLASS_ORDER!");
					return jsondata;
				}
			}	
			if(!modulesForm.get("SUB_ORDER").toString().trim().isEmpty()){
				if(!validator.isNumeric(modulesForm.get("SUB_ORDER").toString().trim()) || modulesForm.get("SUB_ORDER").toString().trim().equals("0"))
				{
					jsondata.put("status", "Invalid Number Entry for SUB_ORDER!");
					return jsondata;
				}
			}
			String operation = (String) modulesForm.get("operation");			
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {
				if(modulesForm.get("MOD_NAME_ORIG")==null||modulesForm.get("MOD_NAME_ORIG").toString().isEmpty()){
					jsondata.put("status", "Invalid module name");
					return jsondata;
				}
				this.updateModules(modulesForm);
			}
			else {
				SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	
				
				boolean duplicate = this.isDuplicateModule(modulereference.getMOD_NAME());
				if (duplicate) {
					jsondata.put("status","Failed to Add Module Reference. Record with same Module Name already exists.");
					return jsondata;
				}		
				
				boolean success = securityDAO.addModules(modulesForm);
				
				
				if(success){
					String userID = (String) modulesForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					StringBuilder str = new StringBuilder();
					str.append("New module added. Module Name: "+modulesForm.get("MOD_NAME").toString()+"; Module Description: "+modulesForm.get("MOD_DESC").toString()+"; Parent Module Name: "+modulesForm.get("PARENT_MOD_NAME").toString()+"; Class Order: "+modulesForm.get("CLASS_ORDER").toString()+"; Sub Order: "+modulesForm.get("SUB_ORDER").toString());

					as.addAudit(userID, "I", "MODULEREFERENCE", str.toString());
					
					jsondata.put("status","Add Module Reference Successful ...");
				}else{
					jsondata.put("status","Add Module Reference Failed ... ");
				}
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	public Map updateModules(Map modulesForm){
		
		log.info("--->> updateModuleReference SERVICE ...");
		log.debug("map: " + modulesForm.values());

		Map jsondata = new HashMap();
		
		try{
			ModuleReference modulereference = ModuleReferenceUtility.toObject(modulesForm);
			ServiceUtility.viewUserParameters(modulesForm);		
			
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");
			ModuleReference MR = securityDAO.getModuleReference(modulesForm.get("MOD_NAME_ORIG").toString());
			boolean success = securityDAO.updateModules(modulesForm);
					
			if(success){
				String userID = (String) modulesForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				ModuleReference newMR = ModuleReferenceUtility.toObject(modulesForm);
				as.addAudit(userID, "U", "MODULEREFERENCE", newMR.toAuditString(MR));
				
				jsondata.put("status","Update Module Reference Successful ...");
			}else{
				jsondata.put("status","Update Module Reference Failed ... ");
			}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
	}
	
	public Map searchAvailClasses(Map classesForm){
		
		log.info("--->> searchAvailClasses SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		try{
			
			ServiceUtility.viewUserParameters(classesForm);
									
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");						
			
			records = securityDAO.searchAvailClasses(classesForm);	
		
			ServiceUtility.viewUserParameters(classesForm);
						
			log.info("--->> searchClasses RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)classesForm.get("records")),((String)classesForm.get("page")),((String)classesForm.get("total")));
			}else{
				jsondata.put("status","Search Classes Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
public Map searchModuleClasses(Map classesForm){
		
		log.info("--->> searchAvailClasses SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		try{
			
			ServiceUtility.viewUserParameters(classesForm);
									
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	
			totalRecords = securityDAO.getTotalRecordsModuleClasses();
			
			classesForm = ServiceUtility.addPaging(classesForm,totalRecords);
									
			String orderField = classesForm.get("orderField") != null ? classesForm.get("orderField").toString() : "";
			String sortField = classesForm.get("sortField") != null ? classesForm.get("sortField").toString() : "";
			
			if (orderField.trim().equalsIgnoreCase("")) {
				orderField = "asc";
			}
			
			if (sortField.trim().equalsIgnoreCase("")) {
				sortField = "cr.CLASS_NAME";
			}
			
			classesForm.put("sortField", sortField);
			classesForm.put("orderField", orderField);					
			
			records = securityDAO.searchModuleClasses(classesForm);	
		
			ServiceUtility.viewUserParameters(classesForm);
						
			log.info("--->> searchModuleClasses RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)classesForm.get("records")),((String)classesForm.get("page")),((String)classesForm.get("total")));
			}else{
				jsondata.put("status","Search Classes Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	

	public List searchModuleList(Map module){
	
		log.info("--->> searchModuleList SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
	
		try{									
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");				
			records = securityDAO.searchModuleList(module);		
			log.info("--->> searchModuleList RECORD-SIZE: "+records.size());
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"MOD_NAME", "MOD_DESC");
			jsondata.put("AUTOCOMPLETE",resultString);

		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		return records;
		//return jsondata;
	}	
	
public Map addModuleClass(Map modulesForm){
		
		log.info("--->> addModuleClass SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			
			ServiceUtility.viewUserParameters(modulesForm);
			
			ModuleClass moduleclass = ModuleClassUtility.toObject(modulesForm);
			log.info("mc:" + moduleclass.toString());
			
				SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	

				boolean success = securityDAO.addModuleClass(modulesForm);
				StringBuilder str = new StringBuilder();
				str.append("New moduleclass created. Module Name: "+modulesForm.get("MOD_NAME").toString()+"; Class Name: "+modulesForm.get("CLASS_NAME").toString());
				 
				
				
				if(success){
					String userID = (String) modulesForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "MODULECLASS", str.toString());
					
					jsondata.put("status","Add Module Class Successful ...");
				}else{
					jsondata.put("status","Add Module Class Failed ... ");
				}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
public Map updateModuleClass(Map modulesForm){
	
	log.info("--->> updateModuleClass SERVICE ...");
	
	Map jsondata = new HashMap();
	
	try{
		
		ServiceUtility.viewUserParameters(modulesForm);
		
		ModuleClass moduleclass = ModuleClassUtility.toObject(modulesForm);
		log.info("mc:" + moduleclass.toString());
		
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	
			//String oldValue = auditCreator.getOldValue(auditCreator.MODULECLASS, modulesForm.get("MOD_NAME_ORIG").toString(), modulesForm.get("CLASS_NAME").toString());
			Map data = new HashMap();
			data.put("MOD_NAME", modulesForm.get("MOD_NAME_ORIG").toString());
			data.put("CLASS_NAME", modulesForm.get("CLASS_NAME").toString());
			ModuleClass MC = securityDAO.getModuleClass(data);
			boolean success = securityDAO.updateModuleClass(modulesForm);
			
			
			if(success){
				String userID = (String) modulesForm.get("C_USERID");
				ModuleClass newMC = ModuleClassUtility.toObject(modulesForm);
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "MODULECLASS", newMC.toAuditString(MC));
				
				jsondata.put("status","Update Module Class Successful ...");
			}else{
				jsondata.put("status","Update Module Class Failed ... ");
			}
		
	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}
	
	return jsondata;
}

	
public Map deleteModuleClass(Map modulesForm){
	
	log.info("--->> deleteModuleClass SERVICE ...");
	
	Map jsondata = new HashMap();
	
	try{
		
		ServiceUtility.viewUserParameters(modulesForm);
		
		ModuleClass moduleclass = ModuleClassUtility.toObject(modulesForm);
		log.info("mc:" + moduleclass.toString());
		//String oldValue = auditCreator.getOldValue(auditCreator.MODULECLASS, modulesForm.get("MOD_NAME_ORIG").toString(), modulesForm.get("CLASS_NAME").toString());
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	

			boolean success = securityDAO.deleteModuleClass(modulesForm);
			
			
			if(success){
				String userID = (String) modulesForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "MODULECLASS", modulesForm.get("CLASS_NAME").toString()+" class linked to "+modulesForm.get("MOD_NAME_ORIG").toString()+" module has been deleted. ");
				
				jsondata.put("status","Delete Module Class Successful ...");
			}else{
				jsondata.put("status","Delete Module Class Failed ... ");
			}
		
	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}
	
	return jsondata;
}
public Map searchRole(Map roleForm){
	
	log.info("--->> searchClasses SERVICE ...");
	
	Map jsondata = new HashMap();
	List records = new ArrayList();
	String totalRecords = "";
	
	try{
		
		ServiceUtility.viewUserParameters(roleForm);
								
		SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");				
		totalRecords = securityDAO.getTotalRecordsRole();
		
		roleForm = ServiceUtility.addPaging(roleForm,totalRecords);
		
		String orderField = roleForm.get("orderField") != null ? roleForm.get("orderField").toString() : "";
		String sortField = roleForm.get("sortField") != null ? roleForm.get("sortField").toString() : "";
		
		if (orderField.trim().equalsIgnoreCase("")) {
			orderField = "asc";
		}
		
		if (sortField.trim().equalsIgnoreCase("")) {
			sortField = "ROLE";
		}
		
		roleForm.put("sortField", sortField);
		roleForm.put("orderField", orderField);	
		
		records = securityDAO.searchRole(roleForm);	
	
		ServiceUtility.viewUserParameters(roleForm);
					
		log.info("--->> searchRole RECORD-SIZE: "+records.size());
		
		if((records!=null) && (records.size()>0)){						
			jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)roleForm.get("records")),((String)roleForm.get("page")),((String)roleForm.get("total")));
		}else{
			jsondata.put("status","Search Role Failed ... ");
		}
	
	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}	
	
	return jsondata;
	
}	
			
public List searchRoleByCode(String role){
	log.info("--->> searchRoleByCode SERVICE ...");		
	Map map = new HashMap();
	map.put("ROLE", role);
	
	SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");
			
	return securityDAO.searchRoleByCode(map);		
			
}

public Map addRole(Map roleForm){
	
	log.info("--->> addRole SERVICE ...");
	
	Map jsondata = new HashMap();
	
	try{
		
		ServiceUtility.viewUserParameters(roleForm);
		
		RoleReference rolereference = RoleReferenceUtility.toObject(roleForm);
		log.info("rr:" + rolereference.toString());
		String operation = (String) roleForm.get("operation");			
		if (operation!= null && operation.trim().equalsIgnoreCase("update")) {				
			this.updateRole(roleForm);
		}
		else {
			if(rolereference.getROLE()==null||rolereference.getROLE().isEmpty()||rolereference.getROLE().length()>10){
				jsondata.put("status","Invalid Role Name");
				return jsondata;
			}
			
			if(rolereference.getROLE_DESC()==null||rolereference.getROLE_DESC().isEmpty()||rolereference.getROLE_DESC().length()>255){
				jsondata.put("status","Invalid Role Description");
				return jsondata;
			}
			
		
		
		
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	
			
			boolean duplicate = this.isDuplicateRole(rolereference.getROLE());
			if (duplicate) {
				jsondata.put("status","Failed to Add Role Reference. Record with same Role already exists.");
				return jsondata;
			}		
			
			boolean success = securityDAO.addRole(roleForm);
			
			
			if(success){
				String userID = (String) roleForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				StringBuilder str = new StringBuilder();
				str.append("New Role Created. Role Name: "+roleForm.get("ROLE").toString()+"; Role Description: "+roleForm.get("ROLE_DESC").toString());
				
				
				
				as.addAudit(userID, "I", "ROLEREFERENCE", str.toString());
				
				jsondata.put("status","Add Role Reference Successful ...");
			}else{
				jsondata.put("status","Add Role Reference Failed ... ");
			}
		}
		
	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}
	
	return jsondata;
}

	public Map updateRole(Map roleForm){
	
	log.info("--->> updateRoleReference SERVICE ...");
	log.debug("map: " + roleForm.values());
	
	Map jsondata = new HashMap();
	
	try{
		RoleReference classreference = RoleReferenceUtility.toObject(roleForm);
		ServiceUtility.viewUserParameters(roleForm);		
		
		SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");
		//String oldValue = auditCreator.getOldValue(auditCreator.ROLEREFERENCE, roleForm.get("ROLE_ORIG").toString());			
		RoleReference RR = securityDAO.getRoleReference(roleForm.get("ROLE_ORIG").toString());
		boolean success = securityDAO.updateRole(roleForm);
				
		if(success){
			String userID = (String) roleForm.get("C_USERID");
			AuditService as = AuditService.getInstance();
			RoleReference newRR = RoleReferenceUtility.toObject(roleForm);
			as.addAudit(userID, "U", "ROLEREFERENCE", newRR.toAuditString(RR));
			
			jsondata.put("status","Update Role Reference Successful ...");
		}else{
			jsondata.put("status","Update Role Reference Failed ... ");
		}
		
	}catch(Throwable x){
		jsondata.put("status",x.getMessage());
		x.printStackTrace();
	}	
	
	return jsondata;
}

public Map searchRoleModule(Map roleForm){
		
		log.info("--->> searchRoleModule SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";
		
		try{
			
			ServiceUtility.viewUserParameters(roleForm);
									
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	
			totalRecords = securityDAO.getTotalRecordsModules();
			
			roleForm = ServiceUtility.addPaging(roleForm,totalRecords);
			String role = (String) roleForm.get("role");	
			roleForm.put("ROLE", role);
			
			String orderField = roleForm.get("orderField") != null ? roleForm.get("orderField").toString() : "";
			String sortField = roleForm.get("sortField") != null ? roleForm.get("sortField").toString() : "";
			if (orderField.trim().equalsIgnoreCase("")) {
				orderField = "asc";
			}
			
			if (sortField.trim().equalsIgnoreCase("")) {
				sortField = "mr.MOD_NAME";
			}
			
			roleForm.put("sortField", sortField);
			roleForm.put("orderField", orderField);	
			
			records = securityDAO.searchRoleModule(roleForm);	
		
			ServiceUtility.viewUserParameters(roleForm);
						
			log.info("--->> searchRoleModule RECORD-SIZE: "+records.size());
			
			if((records!=null) && (records.size()>0)){						
				jsondata = JQGridJSONFormatter.formatDataToJSON(records, ((String)roleForm.get("records")),((String)roleForm.get("page")),((String)roleForm.get("total")));
			}else{
				jsondata.put("status","Search Role Module Definition Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	

	public Map searchRoleList(Map role){
	
		log.info("--->> searchRoleList SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
	
		try{									
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");				
			records = securityDAO.searchRoleList(role);			
			log.info("--->> searchRoleList RECORD-SIZE: "+records.size());
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"ROLE", "ROLE_DESC");
			jsondata.put("AUTOCOMPLETE",resultString);

		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		//return records;
		return jsondata;
	}	
	
	public Map addRoleModule(Map roleForm){
		
		log.info("--->> addRoleModule SERVICE ...");
		
		Map jsondata = new HashMap();
		
		try{
			
			ServiceUtility.viewUserParameters(roleForm);
			
			RoleModule rolemodule = RoleModuleUtility.toObject(roleForm);
			log.info("rm:" + rolemodule.toString());
			
				SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	

				boolean success = securityDAO.addRoleModule(roleForm);
				
				
				if(success){
					String userID = (String) roleForm.get("C_USERID");
					AuditService as = AuditService.getInstance();
					StringBuilder str = new StringBuilder();
					str.append("New Module added to role. Role: "+ roleForm.get("ROLE").toString()+"; Module Name: "+roleForm.get("MOD_NAME").toString());
					
					
					
					
					as.addAudit(userID, "I", "ROLEMODULE", str.toString());
					
					jsondata.put("status","Add Definition to Role Module Successful ...");
				}else{
					jsondata.put("status","Add Definition to Role Module Failed ... ");
				}
			
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}

public Map deleteRoleModule(Map roleForm){
	
	log.info("--->> deleteRoleModule SERVICE ...");
	
	Map jsondata = new HashMap();
	
	try{
		
		ServiceUtility.viewUserParameters(roleForm);
		
		RoleModule rolemodule = RoleModuleUtility.toObject(roleForm);
		log.info("rm:" + rolemodule.toString());
		
			SecurityDAO securityDAO = (SecurityDAO)Persistence.getDAO("SecurityDAO");	
			//String oldValue = auditCreator.getOldValue(auditCreator.ROLEMODULE, roleForm.get("ROLE").toString(), roleForm.get("MOD_NAME").toString());
			boolean success = securityDAO.deleteRoleModule(roleForm);
			
			
			if(success){
				String userID = (String) roleForm.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "ROLEMODULE", roleForm.get("MOD_NAME").toString()+" module removed from "+roleForm.get("ROLE").toString()+". ");
				
				jsondata.put("status","Delete Definition from Role Module Successful ...");
			}else{
				jsondata.put("status","Delete Definition from Role Module Failed ... ");
			}
		
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}
		
		return jsondata;
	}
	
	@SuppressWarnings("unchecked")
	public Map retrieveParameterSettings(Map param) throws IOException
	{	
		// get the value of the property
		param.put("defaultpasswd", defaultpasswd==null ? "factorpass" : defaultpasswd.trim());
		param.put("useridmin",  useridmin==null ? "6" : useridmin.trim());
		param.put("passwdmin", passwdmin==null ? "8" : passwdmin.trim());
		param.put("passwdexpire",  passwdexpire==null ? "30" : passwdexpire.trim());
		param.put("passwdwarning",  passwdwarning==null ? "15" : passwdwarning.trim());
		param.put("deactivate",  deactivate==null ? "30" : deactivate.trim());
		param.put("disable",  disable==null ? "30" : disable.trim());
		param.put("purging",  purging==null ? "120" : purging.trim());
		param.put("n_try",  n_try==null ? "3" : n_try.trim());
		param.put("passwdhistory",  (Integer)passwdhistory==null ? 3 : passwdhistory);
		param.put("sessionTimeout",  (Integer)sessionTimeout==null ? 3 : sessionTimeout);
		
		log.info("--->> retrieveParameterSettings SERVICE ...");
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		List records = new ArrayList();
		try
		{
			newData = ServiceUtility.removeNulls(param);		
			records = new ArrayList();
			records.add(newData);
					
			jsondata.put("returnData", records);		
			log.info("--->> retrieveParameterSettings RECORD-SIZE: " + records.size());
		}
		catch(Throwable x)
		{
			x.printStackTrace();
		}
		return jsondata;
		
	}
	
	public Map updateParameterSetting(Map form)
	{	
		log.info("--->> updateParamSetting SERVICE ...");
		log.debug("map: " +form.values());
		
		Map jsondata = new HashMap();
		
		Validator validator = new Validator();
		Properties p = new Properties();
	
		if(form.get("useridmin")==null||!validator.isNumeric(form.get("useridmin").toString().trim()) || form.get("useridmin").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for User ID Minimum Length!");
			return jsondata;
		}
		if(form.get("passwdmin")==null||!validator.isNumeric(form.get("passwdmin").toString().trim()) || form.get("passwdmin").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for Password Minimum Length!");
			return jsondata;
		}
		if(form.get("passwdexpire")==null||!validator.isNumeric(form.get("passwdexpire").toString().trim()) || form.get("passwdexpire").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for Paswword Expiration!");
			return jsondata;
		}
		if(form.get("passwdwarning")==null||!validator.isNumeric(form.get("passwdwarning").toString().trim()) || form.get("passwdwarning").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for Password Warning!");
			return jsondata;
		}
		if(form.get("deactivate")==null||!validator.isNumeric(form.get("deactivate").toString().trim()) || form.get("deactivate").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for User ID Deactivation!");
			return jsondata;
		}
		if(form.get("disable")==null||!validator.isNumeric(form.get("disable").toString().trim()) || form.get("disable").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for User ID Disabling!");
			return jsondata;
		}
		if(form.get("purging")==null||!validator.isNumeric(form.get("purging").toString().trim()) || form.get("purging").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for User ID Purging!");
			return jsondata;
		}
		if(form.get("n_try")==null||!validator.isNumeric(form.get("n_try").toString().trim()) || form.get("n_try").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for Incorrect Password Try!");
			return jsondata;
		}
		if(form.get("sessionTimeout")==null||!validator.isNumeric(form.get("sessionTimeout").toString().trim()) || form.get("sessionTimeout").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for Session Timeout!");
			return jsondata;
		}
		if(form.get("passwdhistory")==null||!validator.isNumeric(form.get("passwdhistory").toString().trim()) || form.get("passwdhistory").toString().trim().equals("0"))
		{
			jsondata.put("status", "Invalid Number Entry for Password History!");
			return jsondata;
		}
		
		ParameterSettings PM = new ParameterSettings();
		PM.setDefaultpasswd(this.defaultpasswd);
		PM.setUseridmin(Integer.parseInt(this.useridmin));
		PM.setPasswdmin(Integer.parseInt(this.passwdmin));
		PM.setPasswdexpire(Integer.parseInt(this.passwdexpire));
		PM.setPasswdwarning(Integer.parseInt(this.passwdwarning));
		PM.setDeactivate(Integer.parseInt(this.deactivate));
		PM.setDisable(Integer.parseInt(this.disable));
		PM.setPurging(Integer.parseInt(this.purging));
		PM.setN_try(Integer.parseInt(this.n_try));
		PM.setPasswdhistory(this.passwdhistory);
		PM.setSessionTimeout(this.sessionTimeout);
		
		/*StringBuilder auditString = new StringBuilder();
		auditString.append("defaultpasswd="+this.defaultpasswd+";");
		auditString.append("useridmin="+this.useridmin+";");
		auditString.append("passwdmin="+this.passwdmin+";");
		auditString.append("passwdexpire"+this.passwdexpire+";");
		auditString.append("passwdwarning="+this.passwdwarning+";");		
		auditString.append("deactivate="+this.deactivate+";");
		auditString.append("disable="+this.disable+";");
		auditString.append("purging="+this.purging+";");
		auditString.append("n_try="+this.n_try+";");
		auditString.append("passwdhistory="+this.passwdhistory+";");
		auditString.append("sessionTimeout="+this.sessionTimeout+";");*/
		
		p.setProperty("defaultpasswd",form.get("defaultpasswd").toString().trim());
		p.setProperty("useridmin",form.get("useridmin").toString().trim());
		p.setProperty("passwdmin",form.get("passwdmin").toString().trim());
		p.setProperty("passwdexpire",form.get("passwdexpire").toString().trim());
		p.setProperty("passwdwarning",form.get("passwdwarning").toString().trim());
		p.setProperty("deactivate",form.get("deactivate").toString().trim());
		p.setProperty("disable",form.get("disable").toString().trim());
		p.setProperty("purging",form.get("purging").toString().trim());
		p.setProperty("n_try",form.get("n_try").toString().trim());
		p.setProperty("passwdhistory",form.get("passwdhistory").toString().trim());
		p.setProperty("sessionTimeout", form.get("sessionTimeout").toString().trim());
		
		ParameterSettings newPM = new ParameterSettings();
		newPM.setDefaultpasswd(form.get("defaultpasswd").toString().trim());
		newPM.setUseridmin(Integer.parseInt(form.get("useridmin").toString().trim()));
		newPM.setPasswdmin(Integer.parseInt(form.get("passwdmin").toString().trim()));
		newPM.setPasswdexpire(Integer.parseInt(form.get("passwdexpire").toString().trim()));
		newPM.setPasswdwarning(Integer.parseInt(form.get("passwdwarning").toString().trim()));
		newPM.setDeactivate(Integer.parseInt(form.get("deactivate").toString().trim()));
		newPM.setDisable(Integer.parseInt(form.get("disable").toString().trim()));
		newPM.setPurging(Integer.parseInt(form.get("purging").toString().trim()));
		newPM.setN_try(Integer.parseInt(form.get("n_try").toString().trim()));
		newPM.setPasswdhistory(Integer.parseInt(form.get("passwdhistory").toString().trim()));
		newPM.setSessionTimeout(Integer.parseInt(form.get("sessionTimeout").toString().trim()));
		
		/*StringBuilder newValueString = new StringBuilder();
		newValueString.append("defaultpasswd="+form.get("defaultpasswd").toString().trim()+";");
		newValueString.append("useridmin="+form.get("useridmin").toString().trim()+";");
		newValueString.append("passwdmin="+form.get("passwdmin").toString().trim()+";");
		newValueString.append("passwdexpire"+form.get("passwdexpire").toString().trim()+";");
		newValueString.append("passwdwarning="+form.get("passwdwarning").toString().trim()+";");		
		newValueString.append("deactivate="+form.get("deactivate").toString().trim()+";");
		newValueString.append("disable="+form.get("disable").toString().trim()+";");
		newValueString.append("purging="+form.get("purging").toString().trim()+";");
		newValueString.append("n_try="+form.get("n_try").toString().trim()+";");
		newValueString.append("passwdhistory="+form.get("passwdhistory").toString().trim()+";");
		newValueString.append("sessionTimeout="+form.get("sessionTimeout").toString().trim()+";");*/
		
		try {		
			String dpath = URLDecoder.decode(getPath(),"UTF-8");
			p.store(new FileOutputStream(dpath.replace("file:/","")+"/_properties/paramsetting.properties"),null);
			//p.store(new FileOutputStream(dpath.replace("WEB-INF/classes/com/bdo/factor/service/SecurityService.class", "")+"/paramsetting.properties"),null);
		
			
			//Update passwordhistory
			UserDAO US =  (UserDAO)Persistence.getDAO("UserDAO");
			US.updatePasswordHistoryCount(p.getProperty("passwdhistory"));
			//End Update passwordhistory
			
			parameterSetting2();
			
			String userID = (String) form.get("C_USERID");
			AuditService as = AuditService.getInstance();
			//as.addAudit(userID, "U", "PROPERTYFILE",newValueString.toString()+";OLDVALUES: "+auditString.toString());
			as.addAudit(userID, "U", "PROPERTYFILE",newPM.toAuditString(PM));
			jsondata.put("status","Update Parameter Settings Successful ...");
			

		} catch (IOException ioe) {
			jsondata.put("status","Update Parameter Settings Failed ... ");
			System.out.println("error Saving properties file: " + ioe);
		}

		return jsondata;
	}
	
	public  void parameterSetting ()  {
		if((defaultpasswd==null ? "" : defaultpasswd.toString().trim()).equals("")){	
			log.info("--------> Parameters Setting Method Executed!");
			parameterSetting2(); 
		}
		
	}
	
	public boolean isDuplicateModule(String mod_name) {
		List l = this.searchModulesByCode(mod_name);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}
	
	public boolean isDuplicateRole(String role) {
		List l = this.searchRoleByCode(role);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}
	
	public Map getForm() {
		log.info("getForm : " + form);
		return form;
	}
	public void setForm(Map form) {
		String userRole = (String) form.get("ROLE");
		log.info("setForm : " + form);
		log.info("userRole : " + userRole);
		this.setTestMsg(userRole);
		//this.form = form;
	}
	public String getTestMsg() {
		log.info("getTestMsg : " + form);
		return this.testMsg;
	}
	public void setTestMsg(String msg) {
		log.info("setTestMsg : " + msg);
		this.testMsg = msg;
	}
		
	private  void parameterSetting2 ()  {
			Properties properties = new java.util.Properties();
			Properties properties2 = new java.util.Properties();
			String path = "";
			try {
				path = URLDecoder.decode(getClass().getProtectionDomain().getCodeSource().getLocation().toString().substring(6),"UTF-8");
				
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			FileInputStream fis = null;
			FileInputStream fis2 = null;
			try {
				fis2 = new java.io.FileInputStream(new java.io.File( path.replace("WEB-INF/classes/com/bdo/factor/service/SecurityService.class", "") + "/_properties/jdbc.properties")); //removed /WEB-INF/classes 05042017
				fis = new java.io.FileInputStream(new java.io.File( path.replace("WEB-INF/classes/com/bdo/factor/service/SecurityService.class", "") + "/_properties/paramsetting.properties")); //placed file inside /WEB-INF/classes
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				properties2.load(fis2);
				properties.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// get the value of the property  
			
			try {
				
				SystemSettingsDAO systemSettingDao = (SystemSettingsDAO) Persistence.getDAO("systemSettingDao");
				Map mapsys = new HashMap();
				mapsys.put("C_DEFID", ServiceUtility.encypher(properties2.getProperty("jdbc.username").trim()));
				
				String pass = properties2.getProperty("jdbc.password").trim();
				DecryptorUtil decrypt = new DecryptorUtil();
				String decryptedText = null;
				try {
				SecretKey secKey = decrypt.generateSecretKey();
				byte[] cipherd = decrypt.HextoByte(pass);
				 decryptedText = decrypt.decryptText(cipherd, secKey);
				//return decryptedText;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//decrypt password here
				
				
				mapsys.put("C_DEFPASS", ServiceUtility.encypher(decryptedText));
				boolean sysset = systemSettingDao.updateDefPassId(mapsys);
				//log.info("jdbc.username:" + properties2.getProperty("jdbc.username").trim()) ;
				//log.info("jdbc.password" + properties2.getProperty("jdbc.password").trim()) ;
				
				defaultpasswd=properties.getProperty("defaultpasswd").trim();
				useridmin=properties.getProperty("useridmin").trim();
				passwdmin=properties.getProperty("passwdmin").trim();		
				passwdexpire= properties.getProperty("passwdexpire").trim();
				passwdwarning= properties.getProperty("passwdwarning").trim();
				deactivate=properties.getProperty("deactivate").trim();
				disable=properties.getProperty("disable").trim();
				purging= properties.getProperty("purging").trim();
				n_try= properties.getProperty("n_try").trim();
				passwdhistory = Integer.parseInt(properties.getProperty("passwdhistory").trim());
				sessionTimeout = Integer.parseInt(properties.getProperty("sessionTimeout").trim());

			} catch (Exception es) {
				// TODO Auto-generated catch block
				es.printStackTrace();
			} finally {
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}

	}
	
	public Map getIsSecured(Map form) {
		boolean secured = false;
		Map jsondata = new HashMap();
		ServiceUtility.viewUserParameters(form);
		
		if(form.get("CLASS_NAME")==null||form.get("SESSIONID")==null){
			jsondata.put("message", "Invalid Request");
			return jsondata;
		}
		
		String classname = form.get("CLASS_NAME").toString();
		String sessionID = form.get("SESSIONID").toString();
		
		secured = isSecured(classname,sessionID);
		jsondata.put("secured", secured);
		return jsondata;
	}
	
	public String getDefaultPasswd () { 
		if(defaultpasswd==null) parameterSetting2(); 
		return defaultpasswd;
	}
	
	public String getUseridMin () { 
		if(useridmin==null) parameterSetting2(); 
		return useridmin;
		
	}public String getPasswdExpire () { 
		if(passwdexpire==null) parameterSetting2(); 
		return passwdexpire;
	}
	
	public String getPasswdMin () { 
		if(passwdmin==null) parameterSetting2(); 
		return passwdmin;
	}
	
	public String getPasswdParning () { 
		if(passwdwarning==null) parameterSetting2(); 
		return passwdwarning;
	}
	
	public String getDeactivate () { 
		if(deactivate==null) parameterSetting2(); 
		return deactivate;
	}
	
	public String getDisable () { 
		if(disable==null) parameterSetting2(); 
		return disable;
	}
	
	public String getpurging () { 
		if(purging==null) parameterSetting2(); 
		return purging;
	}

	public String getn_try () { 
		if(n_try==null) parameterSetting2(); 
		return n_try;
	}
	
	
	private String getPath()
	{
		Class cls = this.getClass();	
		return cls.getResource("/").toString();		
	}

	public  int getPasswdhistory() {
		return passwdhistory;
	}

	public  void setPasswdhistory(int passwdhistory) {
		SecurityService.passwdhistory = passwdhistory;
	}

	public static int getSessionTimeout() {
		return sessionTimeout;
	}
	
	public Map deleteRole(Map jsondata){
		String role_name = jsondata.get("role").toString();
		String userid = jsondata.get("Userid").toString();
		
		SecurityDAO SD = (SecurityDAO)Persistence.getDAO("SecurityDAO");
		//String oldValue = auditCreator.getOldValue(auditCreator.ROLEREFERENCE, jsondata.get("role").toString());
		try{
			int recordCount = SD.getRoleDependency(role_name);
			if(recordCount>0){
				jsondata.put("message", "Cannot Delete Role With Dependency");
			}
			else{
				SD.deleteRole(role_name);
				AuditService as = AuditService.getInstance();
				as.addAudit(userid, "D", "ROLEREFERENCE",role_name+" role deleted. ");
				jsondata.put("message", "Role Deleted");
			}
		}catch(Exception e){
			jsondata.put("message", "Error Deleting Role. Please Try Again");
		}
		return jsondata;
	}
	
	public Map deleteModule(Map jsondata){
		String module_name = jsondata.get("module").toString();
		String userid = jsondata.get("Userid").toString();
		
		SecurityDAO SD = (SecurityDAO)Persistence.getDAO("SecurityDAO");
		//String oldValue = auditCreator.getOldValue(auditCreator.MODULEREFERENCE, jsondata.get("MOD_NAME_ORIG").toString());
		try{
			int recordCount = SD.getModuleDependency(module_name);
			if(recordCount>0){
				jsondata.put("message", "Cannot Delete Module With Dependency");
			}
			else{
				SD.deleteModule(module_name);
				AuditService as = AuditService.getInstance();
				as.addAudit(userid, "D", "MODULEREFERENCE",module_name+" module deleted. ");
				jsondata.put("message", "Module Deleted");
			}
		}catch(Exception e){
			jsondata.put("message", "Error Deleting Module. Please Try Again");
		}
		return jsondata;
	}
	
	public Map deleteClassReference(Map jsondata){
		String reference_name = jsondata.get("reference").toString();
		String userid = jsondata.get("Userid").toString();
		
		SecurityDAO SD = (SecurityDAO)Persistence.getDAO("SecurityDAO");
		
		
		try{
			int recordCount = SD.getClassReferenceDependency(reference_name);
			if(recordCount>0){
				jsondata.put("message", "Cannot Delete Reference With Dependency");
			}
			else{
				SD.deleteClassReferecene(reference_name);
				AuditService as = AuditService.getInstance();
				as.addAudit(userid, "D", "CLASSREFERENCE",reference_name+" class deleted. ");
				jsondata.put("message", "Reference Deleted");
			}
		}catch(Exception e){
			jsondata.put("message", "Error Deleting Reference. Please Try Again");
		}
		return jsondata;
	}
}
