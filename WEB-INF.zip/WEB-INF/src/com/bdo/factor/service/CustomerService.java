package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.AccountOfficer;
import com.bdo.factor.beans.CreditNote;
import com.bdo.factor.beans.Customer;
import com.bdo.factor.beans.Group;
import com.bdo.factor.dao.AccountOfficerDAO;
import com.bdo.factor.dao.BLRFileDAO;
import com.bdo.factor.dao.BankDAO;
import com.bdo.factor.dao.ClientDAO;
import com.bdo.factor.dao.CustomerDAO;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.util.CustomerUtility;
import com.bdo.factor.util.GroupUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceUtility;

public class CustomerService {
	private static Logger log = Logger.getLogger(CustomerService.class);
	/////////////////////////////////// SINGLETON //////////////////////////////////////////////////

	private static CustomerService CustomerServiceInstance = new CustomerService();

	private CustomerService() {
	}

	public static CustomerService getInstance() {
		log.info("-->> CustomerService getInstance...");
		return CustomerServiceInstance;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchCustomer(Map customerMap) {

		log.info("--->> searchCustomer SERVICE 2...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String totalRecords = "";

		CustomerDAO customerDAO = (CustomerDAO) Persistence
				.getDAO("CustomerDAO");
		totalRecords = customerDAO.getTotalRecordsCustomer(customerMap);
		//records = customerDAO.searchCustomer(customerMap);
		//totalRecords = ""+records.size();
		customerMap = ServiceUtility.addPaging(customerMap, totalRecords);
		records = customerDAO.searchCustomer(customerMap);

		jsondata.put("returnData", records);

		log.info("--->> searchCustomer RECORD SIZE: "
				+ records.size());

		if ((records != null) && (records.size() > 0)) {
			jsondata = JQGridJSONFormatter.formatDataToJSON(records,
					((String) customerMap.get("records")),
					((String) customerMap.get("page")), ((String) customerMap
							.get("total")));
		} else {
			jsondata.put("status", "Search Customer Failed ... ");
		}

		return jsondata;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchCustomerByCode(Map customerMap) {

		log.info("--->> searchCustomerByCode SERVICE ...");

		Map jsondata = new HashMap();
		Map newData = new HashMap();
		List records = new ArrayList();
		String groupDesc = "";
		String industryDesc = "";
		String bankDesc = "";

		try {
			

			ServiceUtility.viewUserParameters(customerMap);
			
			CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
			records = customerDAO.searchCustomerByCode(customerMap);
			
			newData = (HashMap)records.get(0);

			
			newData.put("C_INDCODE",newData.get("C_INDCODE"));
			
			GroupDAO groupDAO = (GroupDAO)Persistence.getDAO("GroupDAO");				
			groupDesc = groupDAO.searchGroupResolveToDesc(newData);
			log.info("-->> newData: "+groupDesc);
			
			IndustryDAO indDAO = (IndustryDAO)Persistence.getDAO("IndustryDAO");
			newData.put("C_INDUSTRYCODE",(String)newData.get("C_INDCODE"));
			industryDesc = indDAO.searchIndustryResolveToDesc(newData);
			log.info("-->> newData: "+industryDesc);
			
			BankDAO bankDAO = (BankDAO)Persistence.getDAO("BankDAO");				
			bankDesc = bankDAO.searchBankResolveToDesc(newData);
			log.info("-->> newData: "+bankDesc);
			
			//newData.put("C_GROUP",groupDesc);
			//newData.put("C_INDCODE",industryDesc);
			//newData.put("C_BANKCODE", bankDesc);
			
			//log.info("-->> newData: "+(String)newData.get("C_GROUP"));
			//log.info("-->> newData: "+(String)newData.get("C_INDCODE"));
			//log.info("-->> newData: "+(String)newData.get("C_BANKCODE"));
			
			
			newData = ServiceUtility.removeNulls(newData);
			
			records = new ArrayList();
			records.add(newData);
			
			jsondata.put("returnData", records);

			log.info("--->> searchCustomerByCode RECORD-SIZE: " + records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;

	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchCustomerServiceList(Map customerMap) {

		log.info("--->> searchCustomerServiceList SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(customerMap);
			
			CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
			records = customerDAO.searchCustomerServiceList(customerMap);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_CUSTCODE","C_CUSTNAME");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchCustomerServiceList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	
	
	public Map searchAllCustomerService(Map customerMap) {

		log.info("--->> searchAllCustomerService SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(customerMap);
			
			CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
			records = (ArrayList)customerDAO.searchAllCustomerService(customerMap);
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"C_CUSTCODE","C_CUSTNAME");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchAllCustomerService RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	
	
	public Map searchCustomerNameByClient(Map customerMap) {
		log.info("--->> searchCustomerServiceNameByClient SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			ServiceUtility.viewUserParameters(customerMap);

			CustomerDAO custDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
			records = (ArrayList) custDAO.searchCustomerNameByClient(customerMap);
			resultString = JQGridJSONFormatter.formatListToString(records);

			jsondata.put("AUTOCOMPLETE", resultString);

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////

	public Map searchCustomerServiceAutoComplete(Map customerMap) {

		log.info("--->> searchCustomerServiceAutoComplete SERVICE ...");

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
		String clientCode = "";

		try {

			ServiceUtility.viewUserParameters(customerMap);

			ClientDAO clientDAO = (ClientDAO)Persistence.getDAO("ClientDAO");
			clientCode = clientDAO.searchClientResolveToCode(customerMap);
			customerMap.put("C_CLNTCODE", clientCode);

			
			CustomerDAO custDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
			records = (ArrayList) custDAO.searchCustomerServiceAutoComplete(customerMap);
			resultString = JQGridJSONFormatter.formatListToString(records);

			jsondata.put("AUTOCOMPLETE", resultString);

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;

	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map addCustomer(Map customer) {
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		Map newData = new HashMap();
		
		ServiceUtility.viewUserParameters(customer);

		try {
			

			if ((customer.get("oper") != null && customer.get("oper").toString().trim().equalsIgnoreCase("add")) || (customer.containsKey("btn_Add"))) {
				CustomerDAO custDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");

				// boolean duplicate = this.isDuplicate(g.getC_BranchCode(),
				// g.getC_GroupCode());
				// if (duplicate) {
				// jsondata.put("status","Failed to add Group. Record with same group and branch code already exists.");
				// return jsondata;
				// }

				records = custDAO.searchCustomerByCode(customer);
				
				if(records.size()!=0){
					jsondata.put("status","Customer Already Exists ...");
					return jsondata;
				}
				
				if(customer.get("C_CUSTNAME")==null || customer.get("C_CUSTNAME").toString().trim().length()==0){
					jsondata.put("status", "The customer name cannot be empty ...");
					return jsondata;
				}
				
				int success = custDAO.addCustomer(customer);								
				jsondata.put("status", "Add Customer Successful ...");

					
					if (success>0) {
						
						try{
							customer.put("C_CUSTCODE",""+success);
							AuditService as = AuditService.getInstance();
							newData = ServiceUtility.removeNulls(customer);
							Customer c = new Customer(newData);
							as.addAudit(newData.get("C_USERID").toString(),"I","CUSTOMER",c.toString());

						}catch(Throwable x){
							x.printStackTrace();
						}
						
						jsondata.put("status", "Add Customer Successful ...");
					} else {
						jsondata.put("status", "Add Customer Failed ... ");
					}
					
				
			} else {
				jsondata = this.updateCustomer(customer);
			}

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		// TODO: uncomment below statment once done with users
		// String userID = group.get("USERID");

		return jsondata;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Map updateCustomer(Map customer) {
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();

		ServiceUtility.viewUserParameters(customer);
		
		CustomerDAO acctOfficerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
		boolean success = acctOfficerDAO.updateCustomer(customer);

		if (success) {
			
			try{
				
				AuditService as = AuditService.getInstance();
				newData = ServiceUtility.removeNulls(customer);
				Customer c = new Customer(newData);
				as.addAudit(newData.get("C_USERID").toString(),"U","CUSTOMER",c.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			
			jsondata.put("status", "Update Customer Successful ...");
		} else {
			jsondata.put("status", "Update Customer Failed ... ");
		}

		return jsondata;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map deleteCustomer(Map customer) {
		
		Map jsondata = new HashMap();
		Map newData = new HashMap();
		
		
		CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
		

		boolean success = customerDAO.deleteCustomer(customer);

		if (success) {
			
			try{
				
				AuditService as = AuditService.getInstance();
				customer.put("C_BRANCHCODE", customer.get("C_BRANCHCODE"));
				newData = ServiceUtility.removeNulls(customer);
				Customer c = new Customer(newData);
				as.addAudit(newData.get("C_USERID").toString(),"D","CUSTOMER",c.toString());

			}catch(Throwable x){
				x.printStackTrace();
			}
			
			jsondata.put("status", "Delete Customer Successful ...");
		} else {
			jsondata.put("status", "Delete Customer Failed ... ");
		}
		return jsondata;
	}
	
	public Map searchCustomerNameByCustomerCode(Map clientForm) {
		log.info("--->> searchCustomerNameByCode SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(clientForm);
			CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");	
			String c_CustCode = clientForm.get("C_CUSTCODE") != null ? clientForm.get("C_CUSTCODE").toString() : "0"; 
			String result = customerDAO.searchCustomerNameByCustomerCode(c_CustCode);
			//resultString = JQGridJSONFormatter.formatListToString(records);
			jsondata.put("result",result);
			log.info("result:" + result);
								
		}catch(Throwable x){
			jsondata.put("result",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;

		
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map checkCustomerExists(Map customer) {
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		
		ServiceUtility.viewUserParameters(customer);

		try {
			
				if(customer.get("C_CUSTNAME")==null || customer.get("C_CUSTNAME").toString().trim().length()==0){
					jsondata.put("status", "The Customer Name Field Cannot Be EMPTY ...");
					return jsondata;
				}
			
				CustomerDAO custDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
				records = custDAO.searchCustomerByCode(customer);
				
				 if(records.size()!=0){
					 
					 jsondata.put("status","1");
					 return jsondata;
					 
				 }else{
					 
					 jsondata.put("status","0");
					 return jsondata;
				 }

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////

	public Map toMap(Customer c) {
		Map map = new HashMap();
		map.put("C_BRANCHCODE", c.getC_BranchCode());
		map.put("C_CUSTCODE", c.getC_CustCode());
		map.put("C_CUSTNAME", c.getC_CustName());
		map.put("C_ADDRESS", c.getC_Address());
		map.put("C_CONTACT", c.getC_Contact());
		map.put("C_TELNO", c.getC_TelNo());
		map.put("C_ROCNO", c.getC_RocNo());
		map.put("C_INDCODE", c.getC_IndCode());
		map.put("C_BANKCODE", c.getC_BankCode());
		map.put("C_BANKACCT", c.getC_BankAcct());
		map.put("C_GROUP", c.getC_Group());
		map.put("N_CULIMIT", c.getN_CuLimit());
		map.put("oper", "add");

		return map;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Customer toObject(Map m) {

		HashMap map = (HashMap) m;
		Customer c = new Customer();

		c.setC_BranchCode(map.get("C_BRANCHCODE").toString());
		c.setC_CustCode(map.get("C_CUSTCODE").toString());
		c.setC_CustName(map.get("C_CUSTNAME").toString());
		c.setC_Address(map.get("C_ADDRESS").toString());
		c.setC_Contact(map.get("C_CONTACT").toString());
		c.setC_TelNo(map.get("C_TELNO").toString());
		c.setC_RocNo(map.get("C_ROCNO").toString());
		c.setC_IndCode(map.get("C_INDCODE").toString());
		c.setC_BankCode(map.get("C_BANKCODE").toString());
		c.setC_BankAcct(map.get("C_BANKACCT").toString());
		c.setC_Group(map.get("C_GROUP").toString());
		c.setN_CuLimit(Integer.parseInt(map.get("N_CULIMIT").toString()));

		return c;
	}

	public static void main(String[] args) {
		CustomerService cust = new CustomerService();
		Map m = new HashMap();
		m.put("C_CUSTCODE", "CUS01");
		m.put("C_BRANCHCODE", "11");
		m.put("C_CUSTCODE", "12");
		m.put("C_CUSTNAME", "name");
		m.put("C_ADDRESS", "add");
		m.put("C_CONTACT", "contact");
		m.put("C_TELNO", "5675458");
		m.put("C_ROCNO", "5458");
		m.put("C_INDCODE", "FDE");
		m.put("C_BANKCODE", "BNK");
		m.put("C_BANKACCT", "ACCT");
		m.put("C_GROUP", "GRP");
		m.put("N_CULIMIT", "19");

		Map result = cust.deleteCustomer(m);
		log.info("result: " + result.values());
		// log.info("map Result: " + m.values());

	}

///////////////////////////////////////////////////////////////////////////////////////////////
	
	public Map getCustomerNameAutoComplete(Map map){
		log.info("--->> getCustomerNameAutoCompleteX SERVICE ...");
		Map jsonData = new HashMap();
		List list = new ArrayList();
		String returnString = "";
		try{

			ServiceUtility.viewUserParameters(map);
			
			CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");		
			list = (ArrayList)customerDAO.getCompleteCustNameByName(map);
			log.info("--->> getCustomerNameAutoCompleteX RECORD-SIZE: "+list.size());
			
			returnString = JQGridJSONFormatter.formatListToString(list);
			
			log.info("--->> returnString : "+returnString);
			
			jsonData.put("AUTOCOMPLETE", returnString);

		}
		catch (Throwable x) {
			jsonData.put("status", x.getMessage());
			x.printStackTrace();
		}
		return jsonData;
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////

	public Map getCustomerCodeByBranchAndName(Map map){
		
		log.info("--->> getCustomerCodeByBranchAndName SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
				
		try{
			
			ServiceUtility.viewUserParameters(map);
			CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");				
			records = (ArrayList)customerDAO.getCustomerCodeByBranchAndName(map);	

		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
			log.info("--->> getCustomerCodeByBranchAndName RECORD-SIZE: "+records.size());
			ServiceUtility.viewDataBaseRecords(records);
			
			jsondata.put("returnData", records);
		
		return jsondata;
		
	}		
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchPaymentSchedule(Map clientForm){

		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";

		try {

			//ServiceUtility.viewUserParameters(clientForm);
			
			CustomerDAO CustomerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
			records = CustomerDAO.searchPaymentSchedule();
			
			resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"N_SCHEDCODE","C_DESCRIPTION");
			jsondata.put("AUTOCOMPLETE",resultString);
			
			log.info("--->> searchGroupList RECORD-SIZE: "+ records.size());

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		return jsondata;
		
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////
public Map searchCustomerPaymentSchedule(Map clientForm){
	Map jsondata = new HashMap();
	List records = new ArrayList();
	String resultString = "";
	ServiceUtility.viewUserParameters(clientForm);
	try {

		//ServiceUtility.viewUserParameters(clientForm);
		
		CustomerDAO CustomerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");
		records = CustomerDAO.searchCustomerPaymentSchedule(clientForm);
		
		resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"N_SCHEDCODE","C_DESCRIPTION");
		jsondata.put("AUTOCOMPLETE",resultString);
		
		log.info("--->> searchGroupList RECORD-SIZE: "+ records.size());

	} catch (Throwable x) {
		jsondata.put("status", x.getMessage());
		x.printStackTrace();
	}
	return jsondata;
	
}
//////////////////////////////////////////////////////////////////////////////////////////////
public Map searchCustomerWithDelinquent(Map CurrencyForm){

log.info("--->> searchClientList SERVICE ...");

Map jsondata = new HashMap();
List records = new ArrayList();
String resultString = "";

try{

ServiceUtility.viewUserParameters(CurrencyForm);
CustomerDAO customerDAO = (CustomerDAO) Persistence.getDAO("CustomerDAO");				
records = (ArrayList)customerDAO.searchCustomerWithDelinquent(CurrencyForm);
resultString = JQGridJSONFormatter.formatListToJSONSelect(records,"c_custcode","c_custname");
jsondata.put("AUTOCOMPLETE",resultString);

}catch(Throwable x){
jsondata.put("status",x.getMessage());
x.printStackTrace();
}	

return jsondata;

}
//////////////////////////////////////////////////////////////////////////////////////////////	
}


