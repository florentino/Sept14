package com.bdo.factor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bdo.factor.beans.Group;
import com.bdo.factor.beans.ServiceOfficer;
import com.bdo.factor.dao.GroupDAO;
import com.bdo.factor.dao.IndustryDAO;
import com.bdo.factor.dao.Persistence;
import com.bdo.factor.dao.ServiceOfficerDAO;
import com.bdo.factor.util.GroupUtility;
import com.bdo.factor.util.JQGridJSONFormatter;
import com.bdo.factor.util.ServiceOfficerUtility;
import com.bdo.factor.util.ServiceUtility;

public class ServiceOfficerService {
	private static Logger log = Logger.getLogger(ServiceOfficerService.class);

	// ///////////////////////////////// SINGLETON	// ////////////////////////////////////////////////

	private static ServiceOfficerService serviceOffInstance = new ServiceOfficerService();

	private ServiceOfficerService() { }

	public static ServiceOfficerService getInstance() {
		return serviceOffInstance; 
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public List searchServiceOfficerByCode(String c_ServiceOfficerCode) {
		log.info("--->> searchServiceByGCode SERVICE ...");

		ServiceOfficerDAO ServiceOfficerDAO = (ServiceOfficerDAO) Persistence.getDAO("ServiceOfficerDAO");
		return ServiceOfficerDAO.searchServiceOfficerByCode(c_ServiceOfficerCode);
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////
	public Map searchServiceOfficer(Map serviceMap) {

		Map jsondata = new HashMap();
		String totalRecords = "";
		String c_BranchCode = "";

		try {
			log.info("--->> searchService SERVICE ...");
			ServiceUtility.viewUserParameters(serviceMap);

			ServiceOfficerDAO serviceOfficerDAO = (ServiceOfficerDAO) Persistence.getDAO("ServiceOfficerDAO");
			c_BranchCode = (String) serviceMap.get("C_BRANCHCODE");
			log.info("c_BranchCode: " + c_BranchCode);
			totalRecords = serviceOfficerDAO.getTotalRecordsServiceOfficer(c_BranchCode);
			serviceMap = ServiceUtility.addPaging(serviceMap, totalRecords);
			List lService = serviceOfficerDAO.searchServiceOfficer(serviceMap);
			

			log.info("--->> searchService RECORDS: " + lService.size());
			if ((lService != null) && (lService.size() > 0)) {
				jsondata = JQGridJSONFormatter
						.formatDataToJSON(lService, ((String) serviceMap
								.get("records")), ((String) serviceMap
								.get("page")), ((String) serviceMap.get("total")));
			} else {
				jsondata.put("status", "Search Service Officer Failed ... ");
			}
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Map addServiceOfficer(Map serviceMap) {

		Map jsondata = new HashMap();
		ServiceOfficer sofficer = ServiceOfficerUtility.getInstance().toObject(serviceMap);		
		
		try {

			ServiceUtility.viewUserParameters(serviceMap);
			
			String operation = (String) serviceMap.get("operation");
			
			if (operation!= null && operation.trim().equalsIgnoreCase("update")) {
				this.updateServiceOfficer(serviceMap);
			}
			else {
				ServiceOfficerDAO ServiceOfficerDAO = (ServiceOfficerDAO) Persistence.getDAO("ServiceOfficerDAO");

				boolean duplicate = this.isDuplicate(sofficer.getC_ServiceOfficerCode());
				if (duplicate) {
					jsondata.put("status", "Failed to add Service Officer. Record with same Service Officer code already exists.");
					return jsondata;
				}

				boolean success = ServiceOfficerDAO.addServiceOfficer(serviceMap);

				if (success) {					
					String userID = (String) serviceMap.get("C_USERID");
					AuditService as = AuditService.getInstance();
					as.addAudit(userID, "I", "Service", sofficer.toString());

					jsondata.put("status","Add Service Officer Successful ...");
				} else {
					jsondata.put("status","Add Service Officer Failed ... ");
				}
				
			}

		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}
		// TODO: uncomment below statment once done with users
		// String userID = Service.get("USERID");

		return jsondata;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Map updateServiceOfficer(Map serviceMap) {
		Map jsondata = new HashMap();		
		serviceMap.put("C_SERVICEOFFICERCODE", serviceMap.get("C_SERVICEOFFICERCODE_ORIG"));
		ServiceOfficer sOfficer = ServiceOfficerUtility.getInstance().toObject(serviceMap);		
		try {
			ServiceOfficerDAO ServiceOfficerDAO = (ServiceOfficerDAO) Persistence.getDAO("ServiceOfficerDAO");
			String c_ServiceCodeOld = (String) serviceMap.get("C_SERVICEOFFICERCODE_ORIG");			
								
			boolean success = ServiceOfficerDAO.updateServiceOfficer(serviceMap);
			ServiceUtility.viewUserParameters(serviceMap);

			if (success) {
				log.info("adding audit log2");
				String userID = (String) serviceMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "U", "Service", sOfficer.toString());

				jsondata.put("status","Update Service Officer Successful ...");
			} else {
				jsondata.put("status","Update Service Officer Failed ... ");
			}
		} catch (Throwable x) {
			jsondata.put("status", "Update Service Failed ... " + x.getMessage());
			x.printStackTrace();
			//return jsondata;
		}

		return jsondata;
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////

	public Map deleteServiceOfficer(Map serviceMap) {
		Map jsondata = new HashMap();
		try {
			ServiceOfficer g = ServiceOfficerUtility.getInstance().toObject(serviceMap);

			ServiceOfficerDAO ServiceOfficerDAO = (ServiceOfficerDAO) Persistence.getDAO("ServiceOfficerDAO");

			boolean success = ServiceOfficerDAO.deleteServiceOfficer(serviceMap);
			ServiceUtility.viewUserParameters(serviceMap);

			if (success) {
				String userID = (String) serviceMap.get("C_USERID");
				AuditService as = AuditService.getInstance();
				as.addAudit(userID, "D", "Service", g.toString());

				jsondata.put("status","Delete Service Officer Successful ...");
			} else {
				jsondata.put("status","Delete Service OFficer Failed ... ");
			}
		} catch (Throwable x) {
			jsondata.put("status", x.getMessage());
			x.printStackTrace();
		}

		return jsondata;
	}

	public boolean isDuplicate(String c_ServiceOfficer) {
		List l = this.searchServiceOfficerByCode(c_ServiceOfficer);
		if (l != null && l.size() > 0) {
			return true;
		}
		return false;
	}

//////////////////////////////////////////////////////////////////////////////////////////////	
	
	public Map searchServiceOfficerServiceAutoComplete(Map serviceMap){
		
		log.info("--->> searchServiceOfficerServiceAutoComplete SERVICE ...");
		
		Map jsondata = new HashMap();
		List records = new ArrayList();
		String resultString = "";
				
		try{
			
			ServiceUtility.viewUserParameters(serviceMap);
			
			ServiceOfficerDAO serviceOfficerDAO = (ServiceOfficerDAO) Persistence.getDAO("ServiceOfficerDAO");				
			records = (ArrayList)serviceOfficerDAO.searchServiceOfficerServiceAutoComplete(serviceMap);
			resultString = JQGridJSONFormatter.formatListToString(records);
			
			jsondata.put("AUTOCOMPLETE",resultString);
								
		}catch(Throwable x){
			jsondata.put("status",x.getMessage());
			x.printStackTrace();
		}	
		
		return jsondata;
		
	}	
	
//////////////////////////////////////////////////////////////////////////////////////////////		
	
	
	
	
/**
	public static void main(String[] args) {
		ServiceOfficerService sos = new ServiceOfficerService();
		Map serviceMap = new HashMap();
		serviceMap.put("SERVICEOFFICERCODE", "1");
		sos.searchServiceOfficer(serviceMap);
	}
*/	
}
