package com.bdo.factor.constant;



public class Status {
	
	public static final int forVerification=1;
	public static final int forReleaseOfAdvances=2;
	public static final int releasedAdvances=3;
	public static final int partiallyPaid=4;
	public static final int fullyPaidOrForRefund=5;
	public static final int closed=6;
	public static final int cancelledOrDisapproved=7;
	
	public static final String successInsert = "SUCCESS";
	public static final String failInsert = "FAILED";
	
	
	
	

}
