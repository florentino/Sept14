package com.bdo.factor.constant;

public abstract class FactorConstant {

	public static String NAME_ATTR = "name";
	
	public static class Action{
		public static final int APPROVE = 1;
		public static final int REJECT = 2;
		public static final int ADD = 3;
		public static final int UPDATE = 4;
		public static final int DELETE = 5;
	}
	
	public static class Transaction{
		public static final int CLIENT = 1;
		public static final int ADVANCE = 2;
		public static final int REFUND = 3;
		public static final int RECEIPTS = 4;
	}
}
