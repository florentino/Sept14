﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace AAFGLInterface
{
    class RemoveTrailingCRLF
    {
        public void removeTrailingCRLF(string source, string output) {
            //From the AAF extracted file with CRLF in the end per line
            //1,"8",110100000050,400," ",2014016,"10","1","10",999,10,0," "," "," ",77899117.36,0,0,"CNV","CNV",001,1742319.78,1.0000000,"Y",0," ",0,10
            //1,"8",110100000050,400," ",2014016,"81","6","81",999,20,0," "," "," ",38949558.68,0,0,"CNV","CNV",001,871159.89,1.0000000,"Y",0," ",0,20
            //1,"8",110100000050,400," ",2014016,"81","6","81",999,30,0," "," ","16319.82",729659.15,0,0,"CNV","CNV",002,1680778.00,102.9899840,"Y",0," ",0,30
            //--------
            //Code Below
            //will remove the CRLF at the end of the line and join all the lines into single line
            using (StreamReader sr = new StreamReader(source))
            {
                int i = 0;
                string text = string.Empty;
               do
                {
                    i++;
                    string line = sr.ReadLine();
                    if (line != string.Empty)
                    {
                        line = line.Replace(@"/r/n", string.Empty);
                        text = text + line.PadRight(250, ' ');// + Environment.NewLine;
                    }
                } while (sr.EndOfStream == false);
                File.WriteAllText(output, text);
            }
        }

    }
}
