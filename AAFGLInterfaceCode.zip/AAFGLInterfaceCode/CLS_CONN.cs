﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;


namespace AAFGLInterface
{
    class CLS_CONN
    {
        /***
        * Programmer: Julius G Tuazon
        * January 8,2016
        * **/
        #region Configuration
        static string dbName = ConfigurationManager.AppSettings["dbName"];
        static string dbServer = ConfigurationManager.AppSettings["dbServer"];
        static string dbDatabase = ConfigurationManager.AppSettings["dbDatabase"];
        static string dbUserID = ConfigurationManager.AppSettings["dbUserID"];
        static string dbPassword = ConfigurationManager.AppSettings["dbPassword"];
        static string dbProviderName = ConfigurationManager.AppSettings["dbProviderName"];
        #endregion

        #region Instance
        SqlConnection sqlconn;
        #endregion
        #region SQL Methods

        public string SQLServerPath()
        {
            return ConfigurationManager.ConnectionStrings["dbFMS"].ConnectionString;
        }
        public SqlConnection SQLConn()
        {
            try
            {
                sqlconn = new SqlConnection(SQLServerPath());
                sqlconn.Open();

            }
            catch (Exception ee)
            {
                Console.WriteLine("No database physical connection! " + ee.Message + "Warning");
                EventLog.WriteEntry("AAFGLInterface", "\nStack Trace:  " + ee.StackTrace + "\nMessage: CLSCONN Module: No database physical connection!" + ee.Message, EventLogEntryType.Error);
            }
            return sqlconn;


        }
        public static string connString() {
            // public static string connString = @"Data Source = bdowldb10v; Initial Catalog = dbAAF; Integrated Security = SSPI";
            return "Server=" + (dbServer) + ";Database=" + (dbDatabase) + ";User ID=" + Enc_Dec.Decrypt.Decryptor(dbUserID) + ";Password=" + Enc_Dec.Decrypt.Decryptor(dbPassword);
           //return @"Data Source = DESKTOP-THFQAN9; Initial Catalog = dbAAF; Persist Security Info = false; Integrated Security = SSPI";
        }

        #endregion

    }
}
