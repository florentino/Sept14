﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AAFGLInterface
{
    class MergeMultipleToSingleFiles
    {
        //--Method to concatenate multiple files into single file-------------------
        public static void Merge(string SourceDir, string OutputFileName)
        {
            string[] inputFiles = Directory.GetFiles(SourceDir, "*FS*.txt");
            int bufSize = 1024 * 64;
            byte[] buf = new byte[bufSize];
            using (FileStream outFile =
            new FileStream(OutputFileName, FileMode.OpenOrCreate,
            FileAccess.Write, FileShare.None, bufSize))
            {
                foreach (string inputFile in inputFiles)
                {
                    using (FileStream inFile =
                    new FileStream(inputFile, FileMode.Open, FileAccess.Read,
                    FileShare.Read, bufSize))
                    {
                        int br = 0;
                        while ((br = inFile.Read(buf, 0, buf.Length)) != 0)
                        {
                            outFile.Write(buf, 0, br);
                        }
                    }
                }
            }
        }
        //----------------------------
    }
}
