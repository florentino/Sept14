﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAFGLInterface
{
    public class JulianDate_fmu
    {
        #region Properties
        private string fullPath = "";
        bool isManual = false;
        private string tmp = "";
        private string destinationPath = "";
        private string extFileName = "";
        public static string connString = CLS_CONN.connString();

        #endregion
        public void Main(string _tmp, string _sourcePath, string _destinationPath, string _extFileName, bool _isManual)
        {
            isManual = _isManual;
            tmp = _tmp;
            fullPath = _sourcePath;
            destinationPath = _destinationPath;
            extFileName = _extFileName;

            #region "Change date to Julian Calendar, before transferring the files to the server" Added By Dong

            #region Server Date
            //var serverdate = Dispatcher.GetServerDate(connString);

            string result = Dispatcher.GetServerDate(connString);
            DateTime dateOfServer;
            //---------------------------------------
            if(result.ToString() != string.Empty)
            {
                dateOfServer = Convert.ToDateTime(result.Trim());
            }
            else
            {
                dateOfServer = Convert.ToDateTime("01-01-1900");
            }
            if(dateOfServer == Convert.ToDateTime("01-01-1900"))
            {
                dateOfServer = DateTime.Today; // Getting the local date and time if date is not available in server
            }
            #endregion

            var dateNow = dateOfServer;//DateTime.Today;

            //Get Holiday using current date
            var Holidate = Dispatcher.GetHolidayThisMonth(dateNow, connString);

            var _tempfiles = isManual == true ? _tmp : @"GLT9093AAF.filepart";

            //Initializer
            JulianDateConverter jdc = new JulianDateConverter(_tempfiles);

            //Get LastDay of the Month
            var lastdayofthemonth = DateTime.DaysInMonth(dateNow.Year, dateNow.Month);

            //Get Last Working Day
            var PrevWorkingday = jdc.GetPrevWorkingDays(dateNow);

            //Get Holiday using current date
            var isYesterdayIsHoliday = jdc.IsHoliday(dateNow.AddDays(-1));

            //Get Date of yesterday
            var yesterdayDate = dateNow.AddDays(-1);

            //Get Next Working Day
            var NextWorkingday = jdc.GetNextWorkingDays(dateNow);

            #region Days Validation
            switch(dateNow.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    if(dateNow.Day == 1)
                    {
                      var dLastDayOfLastMonth = dateNow.AddDays(-1);

                        if(yesterdayDate.Day == dLastDayOfLastMonth.Day)
                        {
                            jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(dateNow.AddDays(-2)));
                        }
                    }
                    else if(dateNow.Day == lastdayofthemonth) //Check if last day of the month is sunday
                    {
                        //Effectivity date should be on next workng days
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(dateNow));  //if sunday falls to end of the month
                    }
                    else if(yesterdayDate.Day == lastdayofthemonth)
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(yesterdayDate));
                    }
                    break;
                case DayOfWeek.Monday:
                    if(dateNow.Day == 2)
                    {
                        var dLastDayOfLastMonth = dateNow.AddDays(-2);

                        if(yesterdayDate.Day-1 == dLastDayOfLastMonth.Day)
                        {
                            jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(dateNow.AddDays(-1)));
                        }
                    }
                    else if(dateNow.Day == lastdayofthemonth) //Check if last day of the month is sunday
                    {
                        //Effectivity date should be on next workng days
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(NextWorkingday));
                    }
                    break;
                case DayOfWeek.Tuesday:
                    if(jdc.IsHoliday(dateNow))
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
                case DayOfWeek.Wednesday:
                    if(jdc.IsHoliday(dateNow))
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
                case DayOfWeek.Thursday:
                    if(jdc.IsHoliday(dateNow))
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
                case DayOfWeek.Friday:
                    //if(dateNow.Day == lastdayofthemonth)
                    //{

                    //}

                    if(jdc.IsHoliday(dateNow))
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
                case DayOfWeek.Saturday:
                    if(dateNow.Day == lastdayofthemonth || isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));


                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
            }

            #endregion

            #endregion
        }
    }
}
