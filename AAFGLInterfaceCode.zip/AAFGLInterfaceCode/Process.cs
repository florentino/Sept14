﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace AAFGLInterface
{
    class Process
    {
        public static string connString = CLS_CONN.connString();
        //-----------------  

        public static void Merge(string SourceDir, string OutputFileName)
        {

            string includeGroup = string.Empty;
            //---------------------------------------
            string _includeBDOLFS = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_includeBDOLFS());
            string _includeBDORIS = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_includeBDORIS());

            if(_includeBDOLFS == "Yes")
            {
                includeGroup = "*BDOLFS*.txt";
            }
            if(_includeBDORIS == "Yes")
            {
                includeGroup = "*BDORIS*.txt";
            }

            string[] inputFiles = Directory.GetFiles(SourceDir, includeGroup.Trim());
            int bufSize = 1024 * 64;
            byte[] buf = new byte[bufSize];

            using(FileStream outFile = new FileStream(OutputFileName, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None, bufSize))
            {
                foreach(string inputFile in inputFiles)
                {
                    using(FileStream inFile =
                    new FileStream(inputFile, FileMode.Open, FileAccess.Read,
                    FileShare.Read, bufSize))
                    {
                        int br = 0;
                        while((br = inFile.Read(buf, 0, buf.Length)) != 0)
                        {
                            outFile.Write(buf, 0, br);
                        }
                    }
                }
            }
        }
        //-------------------------------

        public static void MergeRemoveTrailing(string SourceDir, string OutputFileName)
        {
            var tempFileName = Path.GetTempFileName();
            try
            {
                using(var streamReader = new StreamReader(SourceDir))
                using(var streamWriter = new StreamWriter(tempFileName))
                {
                    string lineOfRow;
                    while((lineOfRow = streamReader.ReadLine()) != null)
                    {
                        if(!string.IsNullOrWhiteSpace(lineOfRow))
                            streamWriter.WriteLine(lineOfRow);
                    }
                }
                File.Copy(tempFileName, OutputFileName, true);
            }
            finally
            {
                File.Delete(tempFileName);
            }
        }
        //-------------------------------

        public static void MergeReArrangeSequentialNumber(string source, string destination)
        {
            //---------------
            int i = 10;
            var tempFileName = Path.GetTempFileName();
            try
            {
                using(var streamReader = new StreamReader(source))
                using(var streamWriter = new StreamWriter(tempFileName))
                {
                    string lineOfRow;
                    while((lineOfRow = streamReader.ReadLine()) != null)
                    {
                        if(lineOfRow != string.Empty)
                        {
                            lineOfRow = lineOfRow.TrimEnd(',');
                            lineOfRow = lineOfRow.Remove(lineOfRow.LastIndexOf(',') + 1); //removing the last part of the line
                            lineOfRow = lineOfRow + i.ToString(); //inserting the sequential number
                            i = i + 10;
                            streamWriter.WriteLine(lineOfRow);
                        }
                    }
                }
                File.Copy(tempFileName, destination, true);
            }
            finally
            {
                File.Delete(tempFileName);
            }
        }
        //---------------------------------

        public static void AddPadding(string source, string output)
        {
            string _skipbytesforcrlf = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_skipbytesforcrlf());

            using(StreamReader sr = new StreamReader(source))
            {
                int i = 0;
                string text = string.Empty;
                do
                {
                    i++;
                    string line = sr.ReadLine();
                    if(line != string.Empty)
                    {
                        line = line.Replace(@"/r/n", string.Empty);
                        text = text + line.PadRight(Convert.ToInt32(_skipbytesforcrlf.Trim()), ' ');// + Environment.NewLine;
                    }
                } while(sr.EndOfStream == false);
                File.WriteAllText(output, text);
            }
        }
        //---------------

        public static void convertToEBCDIC(string source, string destination)
        {
            string _codepage = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_codepage());
            string _convertTo = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_convertto());

            if(_convertTo == "ebcdic")
            {
                ////Convert to EBCDIC                                                                                                                             //Convert to EBCDIC                                                                                                                             //--Convert to EBCDIC- and Move to Auto Upload----------------
                byte[] fileArray = File.ReadAllBytes(source.Trim()); //Source
                fileArray = ConvertAsciiToEbcdic(fileArray, _codepage.Trim());
                using(var fileStream = new FileStream(destination, FileMode.Create, FileAccess.Write)) //Destination
                {
                    fileStream.Write(fileArray, 0, fileArray.Length);
                    fileStream.Close();
                }
            }
        }
        //---------------

        public static byte[] ConvertAsciiToEbcdic(byte[] asciiData, string codepage)
        {
            Encoding ascii = Encoding.ASCII;
            Encoding ebcdic = Encoding.GetEncoding(codepage);
            return Encoding.Convert(ascii, ebcdic, asciiData);
        }
        //----------------

        public static void SendFilesToFolder(string SourceFolder, string SendToFolder, string ExtFileName)
        {  
            string[] filesToTransfer = Directory.GetFiles(SourceFolder, ExtFileName);
            foreach(string inputFile in filesToTransfer)
            {
                FileInfo fi = new FileInfo(inputFile);
                var filename = System.IO.Path.GetFileName(inputFile);
                fi.CopyTo(SendToFolder + filename, true); //Copying all the files to User Folder
            }
        }

        public static void RenameAndSendFilesToFolder(string sourcelocation, string targetsource, string oldname)
        {    
            var fileName = Convert.ToString(DateTime.Now.ToString("MMddyyyymmss")) + ".fin.txt";
               
            File.Copy(sourcelocation + oldname, sourcelocation + fileName);
            File.Move(sourcelocation + oldname, targetsource + fileName);
        }

        public static void cleaningDirectory(string inFile)
        {
            foreach(string f in System.IO.Directory.EnumerateFiles(inFile, @"*.*"))
            {
                System.IO.File.Delete(f);
            }
        }
        //---------------

        public static void ProcessFiles(string sourceFolderPath)
        {
            string _fileToICBS = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_fileToICBS());

            Merge(sourceFolderPath, sourceFolderPath + @"MergedFile.txt");
            MergeRemoveTrailing(sourceFolderPath + @"MergedFile.txt", sourceFolderPath + @"GLT9093AAF.tmp");
            MergeReArrangeSequentialNumber(sourceFolderPath + @"GLT9093AAF.tmp", sourceFolderPath + @"GLT9093AAF.filepart");

            #region "Change date to Julian Calendar, before transferring the files to the server" Added By Dong

            #region Server Date
            //var serverdate = Dispatcher.GetServerDate(connString);

            string result = Dispatcher.GetServerDate(connString);
            DateTime dateOfServer;
            //---------------------------------------
            if(result.ToString() != string.Empty)
            {
                dateOfServer = Convert.ToDateTime(result.Trim());
            }
            else
            {
                dateOfServer = Convert.ToDateTime("01-01-1900");
            }
            if(dateOfServer == Convert.ToDateTime("01-01-1900"))
            {
                dateOfServer = DateTime.Today; // Getting the local date and time if date is not available in server
            }
            #endregion

            var dateNow = dateOfServer;//DateTime.Today;

            //Get Holiday using current date
            var Holidate = Dispatcher.GetHolidayThisMonth(dateNow, connString);

            //Initializer
            JulianDateConverter jdc = new JulianDateConverter(sourceFolderPath + @"GLT9093AAF.filepart");

            //Get LastDay of the Month
            var lastdayofthemonth = DateTime.DaysInMonth(dateNow.Year, dateNow.Month);

            //Get Last Working Day
            var PrevWorkingday = jdc.GetPrevWorkingDays(dateNow);

            //Get Holiday using current date
            var isYesterdayIsHoliday = jdc.IsHoliday(dateNow.AddDays(-1));

            //Get Next Working Day
            var NextWorkingday = jdc.GetNextWorkingDays(dateNow);

            var yesterdayDate = dateNow.AddDays(-1);

            #region Days Validation
            switch(dateNow.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    if(dateNow.Day == lastdayofthemonth) //Check if last day of the month is sunday
                    {
                        //Effectivity date should be on next workng days
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    //else if(isYesterdayIsHoliday)
                    //{
                    //    jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    //}
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(NextWorkingday));
                    }
                    break;
                case DayOfWeek.Monday:
                    //jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(dateNow));
                    if(dateNow.Day == 2)
                    {
                        var dLastDayOfLastMonth = dateNow.AddDays(-2);

                        if(yesterdayDate.Day - 1 == dLastDayOfLastMonth.Day)
                        {
                            jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(dateNow.AddDays(-1)));
                        }
                    }
                    break;
                case DayOfWeek.Tuesday:
                    if(jdc.IsHoliday(dateNow))
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
                case DayOfWeek.Wednesday:
                    if(jdc.IsHoliday(dateNow))
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
                case DayOfWeek.Thursday:
                    if(jdc.IsHoliday(dateNow))
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
                case DayOfWeek.Friday:
                    if(jdc.IsHoliday(dateNow))
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
                case DayOfWeek.Saturday:
                    if(dateNow.Day == lastdayofthemonth)
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    else if(isYesterdayIsHoliday)
                    {
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(PrevWorkingday));
                    }
                    break;
            }

            #endregion

            #endregion

            AddPadding(sourceFolderPath + @"GLT9093AAF.filepart", sourceFolderPath + @"GLT9093AAF.filepart1");

            convertToEBCDIC(sourceFolderPath + @"GLT9093AAF.filepart1", sourceFolderPath + _fileToICBS);

        }
        //---------------

        public static void MergeFiles(string sourceFolderPath)
        {
            string fName = @"BDOLFS" + Convert.ToString(DateTime.Now.ToString("MMddyyyymmss"));
            Merge(sourceFolderPath, sourceFolderPath + fName + @".txt");
            MergeRemoveTrailing(sourceFolderPath + fName + @".txt", sourceFolderPath + fName + @".tmp");
            MergeReArrangeSequentialNumber(sourceFolderPath + fName + @".tmp", sourceFolderPath + fName + @".txt");
            Dispatcher._tmpfile = fName + @".tmp";
        }
        //-----------------
    }
}