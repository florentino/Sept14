﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AAFGLInterface
{
    class CreateLogFiles
    {
        //-----------------------
        private static string sLogFormat;
        private static string sErrorTime;
       public static string CreateLog()
        {
            string sMonth = string.Empty;
            string sDay = string.Empty;
            //sLogFormat used to create log files format :
            // dd/mm/yyyy hh:mm:ss AM/PM ==> Log Message
            sLogFormat = DateTime.Now.ToShortDateString().ToString() + " " + DateTime.Now.ToLongTimeString().ToString() + " ==> ";
            //this variable used to create log filename format "
            //for example filename : ErrorLogYYYYMMDD
            string sYear = DateTime.Now.Year.ToString();
            if (DateTime.Now.Month.ToString().Length == 1)
            {
                sMonth = DateTime.Now.Month.ToString().PadLeft(2,'0');
            }
          
            if (DateTime.Now.Day.ToString().Length == 1) {
                sDay = DateTime.Now.Day.ToString().PadLeft(2,'0');
            }
                sErrorTime = sMonth + sDay + sYear;
            return sErrorTime;
        }
        public static void ErrorLog(string sPathName, string sErrMsg)
        {
            string xLog = CreateLog();
            StreamWriter sw = new StreamWriter(sPathName + sErrorTime, true);
            sw.WriteLine(xLog + " - " + sErrMsg);
            sw.Flush();
            sw.Close();
        }
        //-----------------------
    }
}
