﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using WinSCP;


namespace AAFGLInterface.sendFileToSFTPServer
{
    class sendFileToSFTPServer
    {
        static string connString = CLS_CONN.connString();
        static string sourceFilePath = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_outputfilename());
        static string ftpURL = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_sourcefilenametoSFTP()); //ConfigurationManager.AppSettings["sourcefilenametoSFTP"];
        static string hostname = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_hostname());  //ConfigurationManager.AppSettings["hostname"];
        static string ftpUserName = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_username()); //ConfigurationManager.AppSettings["username"];
        static string ftpPassword = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_password());//ConfigurationManager.AppSettings["password"];
        static string ftpSSHFingerPrint = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_ftpSSHFingerPrint()); //ConfigurationManager.AppSettings["ftpSSHFingerPrint"];  //@"ssh-ed25519 256 56:1c:a7:88:f4:2f:5d:05:08:bb:7a:8f:cd:2c:6a:80"; //
        static string ftpICBSFilePath = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_ftpICBSFilePath()); //ConfigurationManager.AppSettings["ftpICBSFilePath"];
        static string sourceFolder = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_outputfilename()); //ConfigurationManager.AppSettings["outputfilename"];
        static string SFTPlogPath = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_logFileFolder()); // ConfigurationManager.AppSettings["logFileFolder"];

        //---------------------------------------
        public static bool UploadFile(int opt)
        {
            bool success = false;
            try
                {
                string ppkpath = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_ppkpath());  //ConfigurationManager.AppSettings["ppkpath"]; //add here
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = hostname,
                    UserName = ftpUserName,
                    Password = ftpPassword,
                    SshHostKeyFingerprint = ftpSSHFingerPrint,
                    GiveUpSecurityAndAcceptAnySshHostKey =true, //added here 090717
                };
                sessionOptions.SshPrivateKeyPath = ppkpath; //added here
                //string filename = Path.GetFileName(sourceFilePath+ @"\ICBSBLF");
                //string ftpfullpath = @"/etc/ssh";//ftpURL + "/" + filename;
                using (Session session = new Session())
                {
                    //connect
                    session.SessionLogPath = SFTPlogPath + @"\log.sftpLog";
                    //session.AddRawConfiguration("ResumeSupport", "2");
                    session.Open(sessionOptions);
                    //uploadfile
                    TransferOptions transferoptions = new TransferOptions();
                    //transferoptions.TransferMode = TransferMode.Binary; //Original and working
                    transferoptions.TransferMode = TransferMode.Automatic; //added here
                    transferoptions.FilePermissions = null;//added here
                    transferoptions.PreserveTimestamp = false;//added here
                    //Particularly with SFTP protocol, prevent additional .filepartsuffix from being added to uploaded fileslarger than 100KB
                    transferoptions.ResumeSupport.State = TransferResumeSupportState.Off;
                    

              TransferOperationResult transferResult;
                     transferResult = session.PutFiles(sourceFolder + @"\*", ftpICBSFilePath, false, transferoptions);
                     transferResult = opt == 1 ? transferResult = session.PutFiles(sourceFolder + @"\*", ftpICBSFilePath, true, transferoptions): session.GetFiles(ftpICBSFilePath + @"/*.txt", sourceFolder, false, transferoptions);
                    transferResult.Check();
                    if (transferResult.IsSuccess == true)
                        {
                            string listOfTransferredFiles = logHeader();
                            foreach (TransferEventArgs transfer in transferResult.Transfers)
                                {
                                listOfTransferredFiles += transfer.FileName + System.Environment.NewLine;   //added here 090717
                                success = true;
                                }
                            logger("Trasferred: " + listOfTransferredFiles);
                        }


                }
             
            }
            catch (SessionLocalException sle)
            {
                string errorDetail = "WinSCP: There was an error on communication with WINSCP process.  WINSCP cannot be found or executed";
                errorDetail += Environment.NewLine + "Message: " + sle.Message;
                errorDetail += Environment.NewLine + "Target Site: " + sle.TargetSite;
                errorDetail += Environment.NewLine + "Inner Exception: " + sle.InnerException;
                errorDetail += Environment.NewLine + "Stack Trace: " + sle.StackTrace;
                errorDetail += Environment.NewLine + "Stack Trace: " + sle.StackTrace;
                EventLog.WriteEntry("AAFGLInterface", "\nStack Trace:  " + sle.StackTrace + "\nMessage: SendFileToSFTP Module:  Error in inSCP: There was an error on communication with WINSCP process.  WINSCP cannot be found or executed!" + sle.Message, EventLogEntryType.Error);

            }
            catch (SessionRemoteException sre)
            {
                string errorDetail = "WinSCP: There was an error on communication with WINSCP process.  WINSCP cannot be found or executed";
                errorDetail += Environment.NewLine + "Message: " + sre.Message;
                errorDetail += Environment.NewLine + "Target Site: " + sre.TargetSite;
                errorDetail += Environment.NewLine + "Inner Exception: " + sre.InnerException;
                errorDetail += Environment.NewLine + "Stack Trace: " + sre.StackTrace;
                errorDetail += Environment.NewLine + "Stack Trace: " + sre.StackTrace;
                EventLog.WriteEntry("AAFGLInterface", "\nStack Trace:  " + sre.StackTrace + "\nMessage: SendFileToSFTP Module:  Error in inSCP: There was an error on communication with WINSCP process.  WINSCP cannot be found or executed!" + sre.Message, EventLogEntryType.Error);

            }
            catch (Exception ee)
            {
                Console.WriteLine("Error in Uploading file processing");
                EventLog.WriteEntry("AAFGLInterface", "\nStack Trace:  " + ee.StackTrace + "\nMessage: SendFileToSFTP Module:  Error in Uploading file processing!" + ee.Message, EventLogEntryType.Error);

            }
            EventLog.WriteEntry("AAFGLInterface", "\nMessage: SendFileToSFTP Module: Success in WINSCP process.", EventLogEntryType.Information);

            return success;
        }
        //-------------------------
        public static void logger(String lines)
        {
            string TransferredCompletedToICBSLog = SFTPlogPath.Trim();
            //System.IO.StreamWriter file = new System.IO.StreamWriter(TransferredCompletedToICBSLog + @"\TrasferredFilesLog.txt " + DateTime.Now.ToString(), true);
            //file.WriteLine(lines + System.Environment.NewLine);
            //file.Close();

            CreateLogFiles.ErrorLog(TransferredCompletedToICBSLog + @"\FilesLog.txt ", lines.Trim());


        }

        public static string logHeader()
        {
            string header = string.Empty;
            header = "Files Log" + System.Environment.NewLine;
            header = header + "----------" + DateTime.Now.ToString() + "----------" + System.Environment.NewLine;
            return header;
        }
    }
}
