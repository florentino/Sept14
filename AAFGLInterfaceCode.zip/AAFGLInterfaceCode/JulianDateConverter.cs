﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAFGLInterface
{
    public class JulianDateConverter
    {
        #region Properties
        private string fullPath = "";   
        public static string connString = CLS_CONN.connString();

        #endregion

        #region Initialized Value
        public JulianDateConverter(string _fullPath)
        {
            fullPath = _fullPath;
        }
        #endregion

        /// <summary>
        /// Convert Previous Working Date to Julian Date
        /// </summary>
        /// <param name="date"></param>
        /// <returns>Julian Date format</returns>
        public string PrevJDC_BusinessDay(DateTime date)
        {
            #region Get Julian Date  
            return date.Year.ToString() + date.DayOfYear.ToString("000");
            #endregion
        }

        /// <summary>
        /// Convert Next Working Date to Julian Date
        /// </summary>
        /// <param name="date"></param>
        /// <returns>Julian Date format</returns>
        public string NextJDC_BusinessDay(DateTime date)
        {
            #region Get Julian Date  
            return date.Year.ToString() + date.DayOfYear.ToString("000");
            #endregion
        }

        /// <summary>
        /// Replace the value of an array element (6) with the Julian Date
        /// </summary>
        /// <param name="jdc"></param>
        /// <return>return New text files the the converted date time from Gregorian to julian date</return>
        public void ReplaceValue(string jdc)
        {
            StringBuilder newLines = new StringBuilder();

            List<String> lines = new List<String>();

            try
            {
                if(File.Exists(fullPath))
                {
                    using(StreamReader reader = new StreamReader(fullPath))
                    {
                        String line;

                        while((line = reader.ReadLine()) != null)
                        {
                            if(line.Length > 0)
                            {
                                String[] split = line.Split(',');
                                split[5] = jdc;

                                //Change the currency Value.
                                #region Change the currency Value.
                                if ((split[2].Substring(0, 1) == "5") && (split[20] == "1"))
                                {
                                    split[20] = "0";
                                    split[21] = "0.00";
                                    split[22] = "0.0000000";
                                    split[24] = "0";
                                    split[25] = "0";
                                    split[26] = "0";
                                }

                                if (split[2] == "110400210000")
                                {
                                    split[3] = "3080";
                                }

                                #endregion

                                line = String.Join(",", split);
                            }

                            lines.Add(line);
                        }
                    }

                    //Re-write new csv files
                    using(StreamWriter writer = new StreamWriter(fullPath, false))
                    {
                        foreach(String line in lines)
                            writer.WriteLine(line);
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get the Previous Business Day and To check also if the return date is Weekend
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public DateTime GetPrevWorkingDays(DateTime date)
        {
            do
            {
                date = date.AddDays(-1);
            } while(IsHoliday(date) || IsWeekEnd(date));

            return date;
        }

        /// <summary>
        /// Get the Next Business Day and To check also if the return date is Weekend
        /// </summary>
        /// <param name="date"></param>
        /// <returns>DateTime</returns>
        public DateTime GetNextWorkingDays(DateTime date)
        {
            do
            {
                date = date.AddDays(1);
            } while(IsHoliday(date) || IsWeekEnd(date));

            return date;
        }

        /// <summary>
        /// Check if the date is Set as Holiday
        /// </summary>
        /// <param name="date"></param>
        /// <returns>Boolean</returns>
        public bool IsHoliday(DateTime date)
        {
            var Holidate = Dispatcher.GetHolidayThisMonth(date, connString);
            var holiday = new DateTime();

            if(!string.IsNullOrEmpty(Holidate))
            {
                holiday = Convert.ToDateTime(Holidate);
            }
            return holiday == date ? true : false;
        }

        /// <summary>
        /// Check date if Weekend
        /// </summary>
        /// <param name="date"></param>
        /// <returns>Boolean</returns>
        public static bool IsWeekEnd(DateTime date)
        {
            return date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday;
        }
    }
}
