﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace AAFGLInterface
{
    class FileProcessing
    {
        private string sLogFormat;
        private string sErrorTime;
        static string connString = CLS_CONN.connString();
        //---------------------------------------

        //static string _userFile = ConfigurationManager.AppSettings["userFile"]; //"6:00 AM";
        static string _userFile = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_userFile());
        //static string _forManualUpload = ConfigurationManager.AppSettings["forManualUpload"]; //"6:00 AM";
        static string _forManualUpload = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_forManualUpload());

        static string includeBDOLFS = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_includeBDOLFS());
        static string includeBDORIS = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_includeBDORIS());


        public static void Process()
        {
            
            #region banner
            Console.WriteLine("\n=====================================================================");
            Console.WriteLine("BDOLF/BDORI ASCII / EBCDIC Convertor Util");
            Console.WriteLine("=====================================================================\n");
            #endregion
            try
            {
                string inFile, outFile, convertTo, codePage, forManualUpload, logFileFolder,  fileToICBS, userFile;
                bool cRLF;
                int bytesToSkipForCRLF;
                //Getting values in Application Configuration
                GetConfigValues(out inFile, out outFile, out convertTo, out cRLF, out bytesToSkipForCRLF, out codePage, out forManualUpload, out logFileFolder, out fileToICBS, out userFile);
              string result = Dispatcher.GetServerDate(connString);
                DateTime dateOfServer ;
                //---------------------------------------
                if (result.ToString() != string.Empty)
                {
                    dateOfServer =  Convert.ToDateTime( result.Trim() );
                }
                else {
                    dateOfServer = Convert.ToDateTime( "01-01-1900");
                }

                if (dateOfServer == Convert.ToDateTime( "01-01-1900" )) {
                    dateOfServer = DateTime.Today; // Getting the local date and time if date is not available in server
                }

                //Copy all Files to AAF File Folder

                string[] filesToTransfer = Directory.GetFiles(inFile, "*.txt");
                foreach (string inputFile in filesToTransfer)
                {
                    FileInfo fi = new FileInfo(inputFile);
                    var filename = System.IO.Path.GetFileName(inputFile);
                    fi.CopyTo(_userFile + @"\" + filename, true); //Copying all the files to User Folder
                }
                //-----------------------------------------
                //string[] forDeleteFiles = Directory.GetFiles(inFile, "*BDO*.txt");
                //foreach (string inputFile in forDeleteFiles)
                //{
                //    FileInfo fi = new FileInfo(inputFile);
                //    var filename = System.IO.Path.GetFileName(inputFile);
                //    if (filename.Substring(14, 1) != "S")
                //    {
                //        File.Delete(inputFile + @"\" + filename); // Sending to BDOLFFiles folder for merging, convertion to EBCDIC, existing file will be overwritten
                //    }
                //}
                //---------------------------------


                Dispatcher.ToICBSDispatcher(
                     dateOfServer,
                     dateOfServer,
                     inFile,
                     @"ICBSBLFP1.txt",
                     @"ICBSBLFP2.txt",
                     @"\" + fileToICBS,
                     forManualUpload,
                     outFile + @"\",
                     connString,
                     codePage);


                //-----------------------------------------
                //Cleaning Directory
                File.Delete(outFile + @"\ICBSBLFP1");                                       // -----------------------------------------
                File.Delete(outFile + @"\ICBSBLFP2");
                foreach (string f in System.IO.Directory.EnumerateFiles(inFile, @"*.txt"))
                {
                    System.IO.File.Delete(f);
                }
               
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nOops, something broke!");
                Console.WriteLine(ex.Message);
                Console.WriteLine("\n");
                EventLog.WriteEntry("AAFGLInterface", "\nStack Trace:  " + ex.StackTrace + "\nMessage: FileProcessing Module: " + ex.Message, EventLogEntryType.Error);

               // Environment.Exit(-1);
            }
        }
        public static byte[] ConvertAsciiToEbcdic(byte[] asciiData, string codepage)
        {
            Encoding ascii = Encoding.ASCII;
            Encoding ebcdic = Encoding.GetEncoding(codepage);
            return Encoding.Convert(ascii, ebcdic, asciiData);
        }
        private static void GetConfigValues(out string inFile, out string outFile, out string convertTo, out bool cRLF,
            out int bytesToSkipForCRLF, out string codePage, out string forManualUpload,  out string logFileFolder, out string fileToICBS,out string userFile  )
        {
       
            convertTo = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_convertto());
            cRLF = bool.Parse(ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_crlf()));
            bytesToSkipForCRLF = int.Parse(ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_skipbytesforcrlf()));
            codePage = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_codepage());
            inFile = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_sourcefilename());
            outFile = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_outputfilename());
            forManualUpload = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_forManualUpload());
            logFileFolder = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_logFileFolder());
            fileToICBS = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_fileToICBS());
            userFile = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_userFile());

        }

        public static void Run(string SourceDir, string OutputFileName)
        {
            try
            {
                string inFile, outFile, convertTo, codePage, forManualUpload,  logFileFolder,  fileToICBS, userFile;
                bool cRLF;
                int bytesToSkipForCRLF;
                //Getting values in Application Configuration
                //GetConfigValues(out inFile, out outFile, out convertTo, out cRLF, out bytesToSkipForCRLF, out codePage,  out logFileFolder,  out fileToICBS, out userFile);
                GetConfigValues(out inFile, out outFile, out convertTo, out cRLF,
                    out bytesToSkipForCRLF, out codePage, out forManualUpload, out logFileFolder, out fileToICBS, out userFile);




                string[] inputFiles = Directory.GetFiles(SourceDir, "*.txt");
                int bufSize = 1024 * 64;
                byte[] buf = new byte[bufSize];
                foreach (string inputFile in inputFiles)
                {
                    //  DateTime.Today.ToString("MM/dd/yy") = 062517
                    // File should be formatted like AAF062417BDOLFS1209.txt
                    // AAFmmddyyBDOLF#xxxx.txt
                    // # = S - Summary
                    // # = D - Details
                    //look for needed file only and transfer to ProcessFolder
                    FileInfo fi = new FileInfo(inputFile);
                    var filename = System.IO.Path.GetFileName(inputFile);

                    fi.CopyTo(userFile + @"\" + filename, true); //Copying all the files to User Folder

                    // fi.CopyTo(outFile + @"\" + filename, true); // Sending to GL Interface folder, existing file will be overwritten
                    if (filename.Length > 15)
                    {

                        if (includeBDOLFS == "Yes")
                        {
                            if (filename.Substring(9, 6) == "BDOLFS")
                            {
                                //string f = filename.Substring(3, 6).Trim();
                                //string dt = String.Format("{0:MMddyy}", DateTime.Now);
                                //if (f == dt) //trying to get the BDOLF file with the same date eg.090617
                                //{
                                fi.CopyTo(outFile + @"\" + filename, true); // Sending to BDOLFFiles folder for merging, convertion to EBCDIC, existing file will be overwritten
                            }
                        }
                        //-------
                        if (includeBDORIS == "Yes")
                        {
                            if (filename.Substring(9, 6) == "BDORIS")
                            {
                                //string f = filename.Substring(3, 6).Trim();
                                //string dt = String.Format("{0:MMddyy}", DateTime.Now);
                                //if (f == dt) //trying to get the BDOLF file with the same date eg.090617
                                //{
                                fi.CopyTo(outFile + @"\" + filename, true); // Sending to BDOLFFiles folder for merging, convertion to EBCDIC, existing file will be overwritten
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                string inFile, outFile, convertTo, codePage, forManualUpload, logFileFolder, fileToICBS, userFile;
                bool cRLF;
                int bytesToSkipForCRLF;
                //Getting values in Application Configuration
                //GetConfigValues(out inFile, out outFile, out convertTo, out cRLF, out bytesToSkipForCRLF, out codePage,  out logFileFolder,  out fileToICBS, out userFile);
                GetConfigValues(out inFile, out outFile, out convertTo, out cRLF,
                    out bytesToSkipForCRLF, out codePage, out forManualUpload, out logFileFolder, out fileToICBS, out userFile);

                CreateLogFiles Err = new CreateLogFiles();
                Err.ErrorLog(logFileFolder, e.Message);
                EventLog.WriteEntry("AAFGLInterface", "\nStack Trace:  " + e.StackTrace + "\nMessage: FileProcessing Module:  Error Data mergin error" + e.Message, EventLogEntryType.Error);

            }
        }

        //--Method to concatenate multiple files into single file-------------------
        public static void Merge(string SourceDir, string OutputFileName)
        {
            string[] inputFiles = Directory.GetFiles(SourceDir, "*FS*.txt");

            int bufSize = 1024 * 64;

            byte[] buf = new byte[bufSize];

            using (FileStream outFile =
            new FileStream(OutputFileName, FileMode.OpenOrCreate,
            FileAccess.Write, FileShare.None, bufSize))
            {
                foreach (string inputFile in inputFiles)
                {
                    using (FileStream inFile =
                    new FileStream(inputFile, FileMode.Open, FileAccess.Read,
                    FileShare.Read, bufSize))
                    {
                        int br = 0;
                        while ((br = inFile.Read(buf, 0, buf.Length)) != 0)
                        {
                            outFile.Write(buf, 0, br);
                        }
                    }
                }
            }
        }
        //----Method to detect the -----------------    
        
        public string CreateLog()
        {
            //sLogFormat used to create log files format :
            // dd/mm/yyyy hh:mm:ss AM/PM ==> Log Message
            sLogFormat = DateTime.Now.ToShortDateString().ToString() + " " + DateTime.Now.ToLongTimeString().ToString() + " ==> ";

            //this variable used to create log filename format "
            //for example filename : ErrorLogYYYYMMDD
            string sYear = DateTime.Now.Year.ToString();
            string sMonth = DateTime.Now.Month.ToString();
            string sDay = DateTime.Now.Day.ToString();
            sErrorTime = sMonth + sDay + sYear;
            return sErrorTime;
        }


        public void ErrorLog(string sPathName, string sErrMsg)
        {
            string xLog = CreateLog();
            StreamWriter sw = new StreamWriter(sPathName + sErrorTime, true);
            sw.WriteLine(xLog + sErrMsg);
            sw.Flush();
            sw.Close();
        }
        //-----------------------



    }
}
