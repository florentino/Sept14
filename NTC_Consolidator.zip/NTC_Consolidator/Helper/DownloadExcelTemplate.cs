﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.Helper
{
    public class DownloadExcelTemplate
    {
         static bool isFound = false;

        public static int DownloadTemplate(string filename)
        {
            var retval = 0;
            try
            {
                string sourcePath = AppDomain.CurrentDomain.BaseDirectory + "ExcelTemplate\\";

                SearchTemplate(filename, sourcePath);

                if (isFound)
                {
                    SaveFileDialog savefile = new SaveFileDialog();
                    // set a default file name
                    savefile.FileName = filename;
                    // set filters - this can be done in properties as well
                    savefile.Filter = "Excel Files(.xls)|*.xls";

                    if (savefile.ShowDialog() == DialogResult.OK)
                    {
                        File.Copy(sourcePath + filename + " Template.xls", savefile.FileName);
                        retval = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return retval;
        }

        static void SearchTemplate(string filename, string location)
        {
            try
            {
                DirectoryInfo hdDirectoryInWhichToSearch = new DirectoryInfo(location);
                FileInfo[] filesInDir = hdDirectoryInWhichToSearch.GetFiles("*" + filename + "*.xls*");

                foreach (FileInfo foundFile in filesInDir)
                {
                    var tmpFile = Path.GetFileName(foundFile.FullName);

                    if (tmpFile == filename + " Template.xls")
                    {
                        isFound = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
