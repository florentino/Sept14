﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace NTC_Consolidator.Helper
{
    public class ErrorLog
    {
        //Author : Florentino B. Delima
        //Date Written : September 5, 2018

        /// <summary>
        /// Logger is used for creating a customized error log files or an error can be registered as
        /// a log entry in the Windows Event Log on the administrator's machine.
        /// </summary>
        protected static string strLogFilePath = string.Empty;
        private static StreamWriter sw = null;

        /// <summary>
        /// Write Source,method,date,time,computer,error and stack trace information to the text file
        /// </summary>
        /// <param name="strPathName"></param>
        /// <param name="objException"></param>
        /// <returns>false if the problem persists</returns>
        private static bool WriteErrorLog(string retFilePath, Exception objException, string modulaName, string methodName, string errID)
        {
            string strPathName = "NTC_Error_" + errID + "_" + DateTime.Now.ToShortDateString().ToString().Replace("/", "") + "_" + DateTime.Now.ToLongTimeString().ToString().Replace("/","") + ".txt";
            strPathName = retFilePath + strPathName.Replace(":","");
            bool bReturn = false;
            string strException = string.Empty;
            try
            {
                string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

                sw = new StreamWriter(strPathName, true);
                sw.WriteLine("^^------------------------------ START OF LOGS HERE -------------------------------------^^");
                sw.WriteLine("");
                sw.WriteLine("ErrorID		: " + errID);
                sw.WriteLine("Source		: " + objException.Source.ToString().Trim());
                sw.WriteLine("Module Name	: " + modulaName);
                sw.WriteLine("Method Name	: " + methodName);
                sw.WriteLine("Date		    : " + DateTime.Now.ToLongTimeString());
                sw.WriteLine("Time		    : " + DateTime.Now.ToShortDateString());
                sw.WriteLine("Computer	    : " + userName);
                sw.WriteLine("Error		    : " + objException.Message.ToString().Trim());
                sw.WriteLine("Inner Exception Error	: " + objException.InnerException.Message.ToString());
                sw.WriteLine("Stack Trace	: " + objException.StackTrace.ToString().Trim());
                sw.WriteLine("");
                sw.WriteLine("^^------------------------------ E N D O F L O G S -------------------------------------^^");
                sw.Flush();
                sw.Close();
                bReturn = true;
            }
            catch (Exception)
            {
                bReturn = false;
            }
            return bReturn;
        }

        /// <summary>
        /// Check the log file in application directory. If it is not available, create it
        /// </summary>
        /// <returns>Log file path</returns>

        public static string GetLogFilePath(Exception ex, string moduleName, string methodName, string errID)
        {
            try
            {
                // get the base directory
                string baseDir = AppDomain.CurrentDomain.BaseDirectory + AppDomain.CurrentDomain.RelativeSearchPath;
                // search the file below the current directory
                string retFilePath = baseDir + "Modules\\NTC_Consolidator\\NTC_Consolidator_Logs\\";

                // if exists, return the path
                if (File.Exists(retFilePath))
                {
                    return retFilePath;
                }
                else
                {
                    if (!CheckDirectory(retFilePath))
                        return string.Empty;

                    WriteErrorLog(retFilePath, ex, moduleName, methodName, errID);
                   
                }

                return retFilePath;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Create a directory if not exists
        /// </summary>
        /// <param name="strLogPath"></param>
        /// <returns></returns>
        private static bool CheckDirectory(string strLogPath)
        {
            try
            {
                int nFindSlashPos = strLogPath.Trim().LastIndexOf("\\");
                string strDirectoryname = strLogPath.Trim().Substring(0, nFindSlashPos);

                if (!Directory.Exists(strDirectoryname))
                    Directory.CreateDirectory(strDirectoryname);

                return true;
            }
            catch (Exception)
            {
                return false;

            }
        }

    }
}