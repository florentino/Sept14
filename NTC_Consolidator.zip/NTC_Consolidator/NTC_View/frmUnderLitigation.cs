﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using NTC_Consolidator.NTC_Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmUnderLitigation : MetroFramework.Forms.MetroForm
    {
        DataTable dtAaf;
        DataTable dtFams;
        DataTable dtupdated = new DataTable("Updated");
        DataTable dtinserted = new DataTable("Inserted");
        DataRow dru = null;
        DataRow dri = null;
        bool isNoData = false;
        bool _InValidDate = false;
        string ErrorID = "";
        private static frmUnderLitigation litigationform = null;
        private ICorrespondingGLRepository correspondingGLRepository;
        private IUnderLitigation underLitigationRepository;
        private string _underLitigation = "";
        string underLitigationFileName = "";
        private string _underLitigationEXT = "";
        private DateTime _underLitigationDateParameter;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtunderLitigation;
        DataTable dtFromNTCRecords = new DataTable();
        string[] progressArray = new string[5];

        public static frmUnderLitigation Instance()
        {
            if (litigationform == null)
            {
                litigationform = new frmUnderLitigation();
            }
            return litigationform;
        }

        public frmUnderLitigation()
        {
            InitializeComponent();
            this.underLitigationRepository = new UnderLitigationRepository(new NTCConn());
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTCConn());
            lblBusy.Text = "";

            pnlWaitInfo.Location = new Point(
            this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
            this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            pnlSummary.Location = new Point(
           this.ClientSize.Width / 2 - pnlSummary.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlSummary.Size.Height / 2);
            pnlSummary.Visible = false;

            pnlInsertUpdate.Location = new Point(
          this.ClientSize.Width / 2 - pnlInsertUpdate.Size.Width / 2,
          this.ClientSize.Height / 2 - pnlInsertUpdate.Size.Height / 2);
            pnlInsertUpdate.Visible = false;


        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;

                NTCColumnNames();

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        private DataTable FaMSDataTable()
        {
            dtFams = new DataTable("FAMSDATA");

            dtFams.Columns.Add("system");
            dtFams.Columns.Add("recorddate");
            dtFams.Columns.Add("reason");
            dtFams.Columns.Add("rawfiles");
            dtFams.Columns.Add("isdeleted");
            dtFams.Columns.Add("username");
            dtFams.Columns.Add("transdate");
            dtFams.Columns.Add("isconsolidated");
            dtFams.Columns.Add("accountno");
            dtFams.Columns.Add("clientname");
            dtFams.Columns.Add("ao");
            dtFams.Columns.Add("statuspersystem");
            dtFams.Columns.Add("valuedate");
            dtFams.Columns.Add("maturitydate");
            dtFams.Columns.Add("totalloan");
            dtFams.Columns.Add("ob");
            dtFams.Columns.Add("monthlyob");
            dtFams.Columns.Add("clientsequity");
            dtFams.Columns.Add("accruedinterestreceivable");
            dtFams.Columns.Add("originalrate");
            dtFams.Columns.Add("currentrate");
            dtFams.Columns.Add("terminmonths");
            dtFams.Columns.Add("perfamsaaficbsindustrycode");
            dtFams.Columns.Add("industryheader");
            dtFams.Columns.Add("industrydetail");
            dtFams.Columns.Add("perfamsaaficbsassetsizeinwords");
            dtFams.Columns.Add("nextratereviewdateextractedperfamsaaficbs");
            dtFams.Columns.Add("previousmonthsnpltaggingbyrisk");
            dtFams.Columns.Add("specificrequiredprovisions");
            dtFams.Columns.Add("generalrequiredprovisions");

            var startRow = 0;
            DataRow dr = null;
            foreach (DataRow row in dtunderLitigation.Rows)
            {
                dr = dtAaf.NewRow();

                dr["system"] = "FAMS";
                dr["accountno"] = dtunderLitigation.Rows[startRow]["clientcode"].ToString();
                dr["clientname"] = dtunderLitigation.Rows[startRow]["clientname"].ToString();
                dr["ao"] = dtunderLitigation.Rows[startRow]["accountofficer"].ToString();
                dr["statuspersystem"] = dtunderLitigation.Rows[startRow]["status"].ToString();
                dr["valuedate"] = dtunderLitigation.Rows[startRow]["from"].ToString();
                dr["maturitydate"] = dtunderLitigation.Rows[startRow]["to"].ToString();
                dr["totalloan"] = dtunderLitigation.Rows[startRow]["investmentlimit"].ToString();
                dr["ob"] = dtunderLitigation.Rows[startRow]["receivables"].ToString();
                dr["monthlyob"] = dtunderLitigation.Rows[startRow]["receivables"].ToString();
                dr["clientsequity"] = dtunderLitigation.Rows[startRow]["clientsequityOfUnpaidInvoices"].ToString();
                dr["accruedinterestreceivable"] = dtunderLitigation.Rows[startRow]["discountChargeaccrual"].ToString();
                dr["originalrate"] = dtunderLitigation.Rows[startRow]["currentdc"].ToString();
                dr["currentrate"] = dtunderLitigation.Rows[startRow]["currentdc"].ToString();
                dr["terminmonths"] = dtunderLitigation.Rows[startRow]["creditterm"].ToString();
                dr["perfamsaaficbsindustrycode"] = dtunderLitigation.Rows[startRow]["industrycode"].ToString();
                dr["industryheader"] = dtunderLitigation.Rows[startRow]["industrydetailsdescription"].ToString();
                dr["industrydetail"] = dtunderLitigation.Rows[startRow]["industrydetailsdescription"].ToString();
                dr["perfamsaaficbsassetsizeinwords"] = dtunderLitigation.Rows[startRow]["sizeoffirmassetsize"].ToString();
                dr["nextratereviewdateextractedperfamsaaficbs"] = dtunderLitigation.Rows[startRow]["reviewdate"].ToString();
                dr["previousmonthsnpltaggingbyrisk"] = "";
                dr["specificrequiredprovisions"] = "";
                dr["generalrequiredprovisions"] = "";
                dr["recorddate"] = _underLitigationDateParameter;
                //dr["reason"] = "";
                dr["rawfiles"] = txtFilePath.Text;
                //dr["isDeleted"] = false;
                //dr["isConsolidated"] = true;
                dr["UserName"] = frmConsolidator.UserName;
                dr["transdate"] = DateTime.Now.ToShortDateString();

            }
            return dtFams;
        }

        private DataTable AAFDataTable()
        {
            dtAaf = new DataTable("AAFDATA");

            dtAaf.Columns.Add("system");
            dtAaf.Columns.Add("accountno");
            dtAaf.Columns.Add("clientname");
            dtAaf.Columns.Add("ao");
            dtAaf.Columns.Add("facilitycode");
            dtAaf.Columns.Add("statuspersystem");
            dtAaf.Columns.Add("valuedate");
            dtAaf.Columns.Add("firstduedate");
            dtAaf.Columns.Add("maturitydate");
            dtAaf.Columns.Add("totalloan");
            dtAaf.Columns.Add("ob");
            dtAaf.Columns.Add("monthlyob");
            dtAaf.Columns.Add("udibalance");
            dtAaf.Columns.Add("origerv");
            dtAaf.Columns.Add("pvrv");
            dtAaf.Columns.Add("origgd");
            dtAaf.Columns.Add("pvgd");
            dtAaf.Columns.Add("originalrate");
            dtAaf.Columns.Add("currentrate");
            dtAaf.Columns.Add("terminmonths");
            dtAaf.Columns.Add("remainingterminmonths");
            dtAaf.Columns.Add("originalamortizationaaf");
            dtAaf.Columns.Add("paymentscheduleamortizationaaf");
            dtAaf.Columns.Add("repriceddate");
            dtAaf.Columns.Add("aaficbsratetype");
            dtAaf.Columns.Add("repricedamortization");
            dtAaf.Columns.Add("pastduedateitldateextractedperaaficbs");
            dtAaf.Columns.Add("perfamsaaficbsindustrycode");
            dtAaf.Columns.Add("industryheader");
            dtAaf.Columns.Add("industrydetail");
            dtAaf.Columns.Add("collateral");
            dtAaf.Columns.Add("perfamsaaficbsassetsizeinwords");
            dtAaf.Columns.Add("icbsglcode");
            dtAaf.Columns.Add("icbsglname");
            dtAaf.Columns.Add("costcenter");
            dtAaf.Columns.Add("branchnameofcostcenterpersystem");
            dtAaf.Columns.Add("originatingbranchbooked");
            dtAaf.Columns.Add("nationalitypericbs");
            dtAaf.Columns.Add("nextratereviewdateextractedperfamsaaficbs");
            dtAaf.Columns.Add("taxid");
            dtAaf.Columns.Add("customertypedescription");
            dtAaf.Columns.Add("relcode");
            dtAaf.Columns.Add("reecode");
            dtAaf.Columns.Add("reeaddtlinfo");
            dtAaf.Columns.Add("acctref");
            dtAaf.Columns.Add("rpt");
            dtAaf.Columns.Add("assetcost");
            dtAaf.Columns.Add("leasetype");
            dtAaf.Columns.Add("icbscollateralcode");
            dtAaf.Columns.Add("assetvalue");
            dtAaf.Columns.Add("approvedamount");
            dtAaf.Columns.Add("cpnumber");
            dtAaf.Columns.Add("lastprincipalpay");
            dtAaf.Columns.Add("principalpaydate");
            dtAaf.Columns.Add("lastinterestpay");
            dtAaf.Columns.Add("lastinterestpaydate");
            dtAaf.Columns.Add("previousmonthsnpltaggingbyrisk");
            dtAaf.Columns.Add("specificrequiredprovisions");
            dtAaf.Columns.Add("generalrequiredprovisions");

            var startRow = 0;
            DataRow dr = null;
            foreach (DataRow row in dtunderLitigation.Rows)
            {
                dr = dtAaf.NewRow();

                dr["system"] = "AAF";
                dr["accountno"] = dtunderLitigation.Rows[startRow]["accountno"].ToString();
                dr["clientname"] = dtunderLitigation.Rows[startRow]["clientname"].ToString();
                dr["ao"] = dtunderLitigation.Rows[startRow]["ao"].ToString();
                dr["facilitycode"] = dtunderLitigation.Rows[startRow]["facilitycode"].ToString();
                dr["statuspersystem"] = dtunderLitigation.Rows[startRow]["statuspersystem"].ToString();
                dr["valuedate"] = dtunderLitigation.Rows[startRow]["valuedate"].ToString();
                dr["firstduedate"] = dtunderLitigation.Rows[startRow]["firstduedate"].ToString();
                dr["maturitydate"] = dtunderLitigation.Rows[startRow]["maturitydate"].ToString();
                dr["totalloan"] = dtunderLitigation.Rows[startRow]["totalloan"].ToString();
                dr["ob"] = dtunderLitigation.Rows[startRow]["ob"].ToString();
                dr["monthlyob"] = dtunderLitigation.Rows[startRow]["monthlyob"].ToString();
                dr["udibalance"] = dtunderLitigation.Rows[startRow]["udibalance"].ToString();
                dr["origerv"] = dtunderLitigation.Rows[startRow]["origerv"].ToString();
                dr["pvrv"] = dtunderLitigation.Rows[startRow]["pvrv"].ToString();
                dr["origgd"] = dtunderLitigation.Rows[startRow]["origgd"].ToString();
                dr["pvgd"] = dtunderLitigation.Rows[startRow]["pvgd"].ToString();
                dr["originalrate"] = dtunderLitigation.Rows[startRow]["originalrate"].ToString();
                dr["currentrate"] = dtunderLitigation.Rows[startRow]["currentrate"].ToString();
                dr["terminmonths"] = dtunderLitigation.Rows[startRow]["terminmonths"].ToString();
                dr["remainingterminmonths"] = dtunderLitigation.Rows[startRow]["remainingterminmonths"].ToString();
                dr["originalamortizationaaf"] = dtunderLitigation.Rows[startRow]["originalamortizationaaf"].ToString();
                dr["paymentscheduleamortizationaaf"] = dtunderLitigation.Rows[startRow]["paymentscheduleamortizationaaf"].ToString();
                dr["repriceddate"] = dtunderLitigation.Rows[startRow]["repriceddate"].ToString();
                dr["aaficbsratetype"] = dtunderLitigation.Rows[startRow]["aaficbsratetype"].ToString();
                dr["repricedamortization"] = dtunderLitigation.Rows[startRow]["repricedamortization"].ToString();
                dr["pastduedateitldateextractedperaaficbs"] = dtunderLitigation.Rows[startRow]["pastduedateitldateextractedperaaficbs"].ToString();
                dr["perfamsaaficbsindustrycode"] = dtunderLitigation.Rows[startRow]["perfamsaaficbsindustrycode"].ToString();
                dr["industryheader"] = dtunderLitigation.Rows[startRow]["industryheader"].ToString();
                dr["industrydetail"] = dtunderLitigation.Rows[startRow]["industrydetail"].ToString();
                dr["collateral"] = dtunderLitigation.Rows[startRow]["collateral"].ToString();
                dr["perfamsaaficbsassetsizeinwords"] = dtunderLitigation.Rows[startRow]["perfamsaaficbsassetsizeinwords"].ToString();
                dr["icbsglcode"] = dtunderLitigation.Rows[startRow]["icbsglcode"].ToString();
                dr["icbsglname"] = dtunderLitigation.Rows[startRow]["icbsglname"].ToString();
                dr["costcenter"] = dtunderLitigation.Rows[startRow]["costcenter"].ToString();
                dr["branchnameofcostcenterpersystem"] = dtunderLitigation.Rows[startRow]["branchnameofcostcenterpersystem"].ToString();
                dr["originatingbranchbooked"] = dtunderLitigation.Rows[startRow]["originatingbranchbooked"].ToString();
                dr["nationalitypericbs"] = dtunderLitigation.Rows[startRow]["nationalitypericbs"].ToString();
                dr["nextratereviewdateextractedperfamsaaficbs"] = dtunderLitigation.Rows[startRow]["nextratereviewdateextractedperfamsaaficbs"].ToString();
                dr["taxid"] = dtunderLitigation.Rows[startRow]["taxid"].ToString();
                dr["customertypedescription"] = dtunderLitigation.Rows[startRow]["customertypedescription"].ToString();
                dr["relcode"] = dtunderLitigation.Rows[startRow]["relcode"].ToString();
                dr["reecode"] = dtunderLitigation.Rows[startRow]["reecode"].ToString();
                dr["reeaddtlinfo"] = dtunderLitigation.Rows[startRow]["reeaddtlinfo"].ToString();
                dr["acctref"] = dtunderLitigation.Rows[startRow]["acctref"].ToString();
                dr["rpt"] = dtunderLitigation.Rows[startRow]["rpt"].ToString();
                dr["assetcost"] = dtunderLitigation.Rows[startRow]["assetcost"].ToString();
                dr["leasetype"] = dtunderLitigation.Rows[startRow]["leasetype"].ToString();
                dr["icbscollateralcode"] = dtunderLitigation.Rows[startRow]["icbscollateralcode"].ToString();
                dr["assetvalue"] = dtunderLitigation.Rows[startRow]["assetvalue"].ToString();
                dr["approvedamount"] = dtunderLitigation.Rows[startRow]["approvedamount"].ToString();
                dr["cpnumber"] = dtunderLitigation.Rows[startRow]["cpnumber"].ToString();
                dr["lastprincipalpay"] = dtunderLitigation.Rows[startRow]["lastprincipalpay"].ToString();
                dr["principalpaydate"] = dtunderLitigation.Rows[startRow]["principalpaydate"].ToString();
                dr["lastinterestpay"] = dtunderLitigation.Rows[startRow]["lastinterestpay"].ToString();
                dr["lastinterestpaydate"] = dtunderLitigation.Rows[startRow]["lastinterestpaydate"].ToString();
                dr["previousmonthsnpltaggingbyrisk"] = dtunderLitigation.Rows[startRow]["previousmonthsnpltaggingbyrisk"].ToString();
                dr["specificrequiredprovisions"] = dtunderLitigation.Rows[startRow]["specificrequiredprovisions"].ToString();
                dr["generalrequiredprovisions"] = dtunderLitigation.Rows[startRow]["generalrequiredprovisions"].ToString();
                //dr["reason"] = "";
                dr["rawfiles"] = txtFilePath.Text;
                //dr["isDeleted"] = false;
                //dr["isConsolidated"] = true;
                dr["UserName"] = frmConsolidator.UserName;
                dr["transdate"] = DateTime.Now.ToShortDateString();
                dr["recorddate"] = _underLitigationDateParameter;
            }

            return dtAaf;
        }

        private void frmUnderLitigation_Load(object sender, EventArgs e)
        {
            if (txtFilePath.Text == "") btnExecute.Enabled = false;

            btnExecute.Enabled = dtFromNTCRecords.Rows.Count > 0 ? true : false;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
          

            dtupdated = new DataTable("Updated");
            dtinserted = new DataTable("Inserted");

            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Initializing, Please wait...";
            lblWaitStatus.Text = "Status: Initializing...";

            ListItem();

           // var Underdate = underLitigationRepository.GetDate(Program.NTC_DateFrom);

            _underLitigationDateParameter = Program.NTC_DateFrom != "" ? Convert.ToDateTime(Program.NTC_DateFrom) : Convert.ToDateTime("01/01/9001");

            saveWorker = new BackgroundWorker();
            saveWorker.WorkerReportsProgress = true;
            saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
            saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
            saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
            saveWorker.WorkerSupportsCancellation = true;
            saveWorker.RunWorkerAsync();

        }

        #region Load NTC Record 

        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";
            //lblWaitStatus.Text = labelsreports[2];

            lblWaitInfo.Text = labelsreports[1];
            //lblWaitStatus.Text = string.Format("Status: Reading in row {0} at column {1} out of {2} rows", curRow, labelsreports[3], lineCount);
            //lblWaitStatus.Text = string.Format("Status: Reading at row {0} out of {1}", curRow, lineCount);
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                //IsBusy = false;
                if (isNoData)
                {
                    isNoData = false;
                    MetroMessageBox.Show(this, "\r\n\r\nUnder Litigation excel files contains no data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                if (_InValidDate)
                {
                    MetroMessageBox.Show(this, "\r\nInvalid date was detected by the system, Please check all the date format.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else if (e.Error != null)
            {
               // IsBusy = false;
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else if (e.Error.ToString().Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else
                {
                    ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                    var Modulename = this.GetType().FullName;
                    var methodName = MethodBase.GetCurrentMethod().Name;
                    ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID);

                    MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + e.Error.ToString() + "\r\n\r\nError encountered while reading the files, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                pnlWaitInfo.Visible = false;
                return;
            }
            else
            {
                dtFromNTCRecords.DefaultView.RowFilter = "SYSTEM <> 'ICBS'";

                dgvAccountUnderLit.DataSource = dtFromNTCRecords.DefaultView.ToTable();// dtFromNTCRecords;
                dgvAccountUnderLit.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

                //lblInfo.Text = "Total Records: " + dtFromNTCRecords.Rows.Count.ToString();
                lblInfo.Text = "Total Records: " + string.Format("{0:n0}", dtFromNTCRecords.DefaultView.ToTable().Rows.Count);

                FaMSDataTable();
                AAFDataTable();

                pnlWaitInfo.Visible = false;


                btnExecute.Enabled = dtFromNTCRecords.Rows.Count > 0 ? true : false;
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    // connString = string.Format("Provider = Microsoft.ACE.OLEDB.12.0;Data Source={0};" + "Extended Properties='Excel 12.0 Xml;HDR=NO;IMEX=1;'", txtFilePath.Text);

                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                // string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);
                underLitigationFileName = Path.GetFileName(txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                    #region Excel Query
                    //string query = @"SELECT SYSTEM,AccountNo,ClientName,AO,FacilityCode,StatusPerSystem,ValueDate,FirstDueDate,MaturityDate,TotalLoan,OB,MonthlyOB,UDIBalance,ClientsEquity,AccruedInterestReceivable,OrigERV,PVRV,OrigGD,PVGD,TotalLoanPortfolio,NTC,OriginalRate,CurrentRate,TermInMonths,RemainingTermInMonths,OriginalAmortizationAAF,PaymentScheduleAmortizationAAF,RepricedDate,AAFICBSRateType,RepricedAmortization,PastDueDateITLDateExtractedPerAAFICBS,PerFaMSAAFICBSIndustryCode,IndustryHeader,IndustryDetail,Collateral,PerFaMSAAFICBSAssetSize,PerFaMSAAFICBSAssetSizeInWords,ICBSGLCode,ICBSGLName,CostCenter,BranchNameOfCostCenterPerSystem,StatusPerGL,OriginatingBranchBooked,NationalityPerICBS,NextRateReviewDateExtractedPerFaMSAAFICBS,TaxID,LoanPurposeCode,MaturityTypeCode,BankRelationship,SyndicatedLoanInd,CustomerTypeDescription,RELCode,REECode,REEAddtlInfo,AcctRef,RPT,ASSETCOST,LeaseType,Provisioning,Matrix,Remarks,ICBSCollateralCode,AssetValue,ApprovedAmount,CPNumber,LastPrincipalPay,PrincipalPayDate,LastInterestPay,LastInterestPayDate,PreviousMonthsNPLTaggingByRisk,SpecificRequiredProvisions,GeneralRequiredProvisions,Reason FROM [" + worksheetname + "] WHERE [F1] <> ''";
                    #endregion

                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "] WHERE[F1] <> ''", conn);


                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);

                    if (dtold.Rows.Count <= 0)
                    {
                        if (retrieveWorker.IsBusy)
                        {
                            isNoData = true;
                            e.Cancel = true;
                            retrieveWorker.CancelAsync();
                            return;
                        }
                    }
                    else
                    {
                        //var asOfDate = DateTime.Now.ToShortDateString(); // dtold.Rows[0][0].ToString();
                        //asOfDate = asOfDate.Replace("BDO Leasing and Finance Inc.    \n Aging Inventory    \n As of ", "");
                        //asOfDate = asOfDate.Replace("\n");
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);

                        //if (!isValidDate(asOfDate))
                        //{
                        //    if (retrieveWorker.IsBusy)
                        //    {
                        //        _InValidDate = true;
                        //        e.Cancel = true;
                        //        retrieveWorker.CancelAsync();
                        //    }
                        //}

                        //_underLitigationDateParameter = Convert.ToDateTime(asOfDate);// Convert.ToDateTime(dtold.Rows[0][0].ToString().Replace("As Of", "").Trim()); //Get As Of DATE of generated File
                        //dtold.Rows.RemoveAt(0);
                        // dtold.Rows.RemoveAt(0);
                        //Convert Row 3 value as a header of the DataTable
                        foreach (DataColumn dc in dtold.Columns)
                        {
                            if (dtold.Rows[0][dc].ToString().ToUpper() != "")
                            {
                                var hName = dtold.Rows[0][dc].ToString().ToUpper();

                                //Remove unwanted characters(Special Characters and whitespace) and convert into lowercase
                                var NewHeader = Regex.Replace(hName, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToUpper();

                                //dtIcbs.Columns.Add(NewHeader);


                                dc.ColumnName = NewHeader;
                            }
                        }
                        dtold.Rows.RemoveAt(0);

                        dtFromNTCRecords = dtold;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        #endregion

        #region Update NTC Records

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2].ToString();
            lblWaitInfo.Text = labelsreports[1].ToString();
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                lblWaitStatus.Text = "Status: Error Encountered while processing";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                    var Modulename = this.GetType().FullName;
                    var methodName = MethodBase.GetCurrentMethod().Name;
                    ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID);

                    MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + e.Error.ToString() + "\r\n\r\nError encountered while saving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                return;
            }
            else
            {
                pnlSummary.Visible = false;
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";

                dtupdated = new DataTable("Updated");
                dtinserted = new DataTable("Inserted");

                DialogResult responseMsg = MetroMessageBox.Show(this, "\r\nData was successfully added.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (responseMsg.Equals(DialogResult.OK))
                {
                    pnlSummary.Visible = true;

                    dtFromNTCRecords.DefaultView.RowFilter = "SYSTEM <> 'ICBS'";

                    lnkDetailsUpdated.Text = dtupdated.Rows.Count.ToString() + " " + "out of " + dtFromNTCRecords.DefaultView.ToTable().Rows.Count.ToString(); //dtFromNTCRecords.Rows.Count.ToString();
                    lnkDetailsInserted.Text = dtinserted.Rows.Count.ToString() + " " + "out of " + dtFromNTCRecords.DefaultView.ToTable().Rows.Count.ToString(); //dtFromNTCRecords.Rows.Count.ToString();
                }
            }
        }

        protected bool isValidDate(String date)
        {
            try
            {
                DateTime dt = DateTime.Parse(date);
                return true;
            }
            catch
            {
                return false;
            }
        }


        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var iCount = 1;
            try
            {

                foreach (DataRow dritem in dtFromNTCRecords.Rows)
                {
                    BDOLF_Consolidator data = new BDOLF_Consolidator();

                    //if (dritem["ACCOUNTNO"].ToString() == "8500000002")
                    //{

                    //}

                    if (dritem["SYSTEM"].ToString().Trim() != "ICBS")
                    {

                        #region Data
                        progressArray[0] = (iCount * 100 / dtFromNTCRecords.Rows.Count).ToString(); // percent
                        progressArray[1] = "Validating AccountNo, Please wait..."; //header text
                        progressArray[2] = "Status: Updating the record, Please wait...";// for the AccountNo: " + dritem["AccountNo"].ToString(); //Status
                        progressArray[3] = "";// i.ToString(); //column
                        progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column


                        data.RawFiles = underLitigationFileName.ToString();
                        data.isConsolidated = true;
                        data.isDeleted = false;
                        data.UserName = frmConsolidator.UserName;
                        data.TransDate = DateTime.Today;
                        data.RecordDate = _underLitigationDateParameter;
                        data.SYSTEM = dritem["SYSTEM"].ToString() == "" ? "" : dritem["SYSTEM"].ToString();
                        data.AccountNo = dritem["ACCOUNTNO"].ToString() == "" ? "" : dritem["ACCOUNTNO"].ToString();
                        data.ClientName = dritem["CLIENTNAME"].ToString() == "" ? "" : dritem["CLIENTNAME"].ToString();
                        data.AO = dritem["AO"].ToString() == "" ? "" : dritem["AO"].ToString();
                        data.FacilityCode = dritem["FACILITYCODE"].ToString() == "" ? "" : dritem["FACILITYCODE"].ToString();
                        data.StatusPerSystem = dritem["STATUSPERSYSTEM"].ToString() == "" ? "" : dritem["STATUSPERSYSTEM"].ToString();
                        //data.ValueDate = Convert.ToDateTime(dritem["VALUEDATE"].ToString() == "" ? "01/01/1900" : dritem["VALUEDATE"]);
                        if (!isValidDate(dritem["VALUEDATE"].ToString()))
                        {
                            data.ValueDate = Convert.ToDateTime("01/01/1900");
                        }
                        else
                        {
                            data.ValueDate = Convert.ToDateTime(dritem["VALUEDATE"]);
                        }

                        // data.FirstDueDate = Convert.ToDateTime(dritem["FIRSTDUEDATE"].ToString() == "" ? "01/01/1900" : dritem["FIRSTDUEDATE"]);
                        // data.MaturityDate = Convert.ToDateTime(dritem["MATURITYDATE"].ToString() == "" ? "01/01/1900" : dritem["MATURITYDATE"]);

                        if (!isValidDate(dritem["FIRSTDUEDATE"].ToString()))
                        {
                            data.FirstDueDate = Convert.ToDateTime("01/01/1900");
                        }
                        else
                        {
                            data.FirstDueDate = Convert.ToDateTime(dritem["FIRSTDUEDATE"]);
                        }

                        if (!isValidDate(dritem["MATURITYDATE"].ToString()))
                        {
                            data.MaturityDate = Convert.ToDateTime("01/01/1900");
                        }
                        else
                        {
                            data.MaturityDate = Convert.ToDateTime(dritem["MATURITYDATE"]);
                        }

                        data.TotalLoan = Convert.ToDecimal(dritem["TOTALLOAN"].ToString() == "" ? 0.00 : dritem["TOTALLOAN"]);
                        data.OB = Convert.ToDecimal(dritem["OB"].ToString() == "" ? 0.00 : dritem["OB"]);
                        data.MonthlyOB = Convert.ToDecimal(dritem["MONTHLYOB"].ToString() == "" ? 0.00 : dritem["MONTHLYOB"]);
                        data.UDIBalance = Convert.ToDecimal(dritem["UDIBALANCE"].ToString() == "" ? 0.00 : dritem["UDIBALANCE"]);

                        // var valyo = dritem["CLIENTSEQUITY"].ToString() == "" ? 0.0 : dritem["CLIENTSEQUITY"];

                        data.ClientsEquity = Convert.ToDecimal(dritem["CLIENTSEQUITY"].ToString() == "" ? 0.00 : dritem["CLIENTSEQUITY"]);
                        data.AccruedInterestReceivable = Convert.ToDecimal(dritem["ACCRUEDINTERESTRECEIVABLE"].ToString() == "" ? 0.00 : dritem["ACCRUEDINTERESTRECEIVABLE"]);
                        data.OrigERV = Convert.ToDecimal(dritem["ORIGERV"].ToString() == "" ? 0.00 : dritem["ORIGERV"]);
                        data.PVRV = Convert.ToDecimal(dritem["PVRV"].ToString() == "" ? 0.00 : dritem["PVRV"]);
                        data.OrigGD = Convert.ToDecimal(dritem["ORIGGD"].ToString() == "" ? 0.00 : dritem["ORIGGD"]);
                        data.PVGD = Convert.ToDecimal(dritem["PVGD"].ToString() == "" ? 0.00 : dritem["PVGD"]);
                        var sdfsdf = Convert.ToDecimal(dritem["TOTALLOANPORTFOLIO"].ToString() == "" ? 0.00 : dritem["TOTALLOANPORTFOLIO"]);
                        data.TotalLoanPortfolio = Convert.ToDecimal(dritem["TOTALLOANPORTFOLIO"].ToString() == "" ? 0.00 : dritem["TOTALLOANPORTFOLIO"]);
                        data.NTC = dritem["NTC"].ToString() == "" ? "" : dritem["NTC"].ToString();

                        data.OriginalRate = dritem["ORIGINALRATE"].ToString();
                        data.CurrentRate = dritem["CURRENTRATE"].ToString();
                        data.TermInMonths = Convert.ToInt32(dritem["TERMINMONTHS"].ToString() == "" ? "0" : dritem["TERMINMONTHS"]);
                        data.RemainingTermInMonths = Convert.ToInt32(dritem["REMAININGTERMINMONTHS"].ToString() == "" ? 0 : dritem["REMAININGTERMINMONTHS"]);
                        data.OriginalAmortizationAAF = dritem["ORIGINALAMORTIZATIONAAF"].ToString();

                     
                        data.PaymentScheduleAmortizationAAF = Convert.ToDecimal(dritem["PAYMENTSCHEDULEAMORTIZATIONAAF"].ToString() == "" ? 0.00 : dritem["PAYMENTSCHEDULEAMORTIZATIONAAF"]);

                        // data.RepricedDate = Convert.ToDateTime(dritem["REPRICEDDATE"].ToString() == "" ? "01/01/1900" : dritem["REPRICEDDATE"]);

                        if (!isValidDate(dritem["REPRICEDDATE"].ToString()))
                        {
                            data.RepricedDate = Convert.ToDateTime("01/01/1900");
                        }
                        else
                        {
                            data.RepricedDate = Convert.ToDateTime(dritem["REPRICEDDATE"]);
                        }

                        data.AAFICBSRateType = dritem["AAFICBSRATETYPE"].ToString() == "" ? "" : dritem["AAFICBSRATETYPE"].ToString();
                        data.RepricedAmortization = Convert.ToDecimal(dritem["REPRICEDAMORTIZATION"].ToString() == "" ? 0.00 : dritem["REPRICEDAMORTIZATION"]);
                        data.PastDueDateITLDateExtractedPerAAFICBS = dritem["PASTDUEDATEITLDATEEXTRACTEDPERAAFICBS"].ToString();
                        data.PerFaMSAAFICBSIndustryCode = dritem["PERFAMSAAFICBSINDUSTRYCODE"].ToString() == "" ? "" : dritem["PERFAMSAAFICBSINDUSTRYCODE"].ToString();
                        data.IndustryHeader = dritem["INDUSTRYHEADER"].ToString() == "" ? "" : dritem["INDUSTRYHEADER"].ToString();
                        data.IndustryDetail = dritem["INDUSTRYDETAIL"].ToString() == "" ? "" : dritem["INDUSTRYDETAIL"].ToString();
                        data.Collateral = dritem["COLLATERAL"].ToString() == "" ? "" : dritem["COLLATERAL"].ToString();
                        data.PerFaMSAAFICBSAssetSize = dritem["PERFAMSAAFICBSASSETSIZE"].ToString() == "" ? "" : dritem["PERFAMSAAFICBSASSETSIZE"].ToString();
                        data.PerFaMSAAFICBSAssetSizeInWords = dritem["PERFAMSAAFICBSASSETSIZEINWORDS"].ToString() == "" ? "" : dritem["PERFAMSAAFICBSASSETSIZEINWORDS"].ToString();
                        data.ICBSGLCode = dritem["ICBSGLCODE"].ToString() == "" ? "" : dritem["ICBSGLCODE"].ToString();
                        data.ICBSGLName = dritem["ICBSGLNAME"].ToString() == "" ? "" : dritem["ICBSGLNAME"].ToString();
                        data.CostCenter = dritem["COSTCENTER"].ToString() == "" ? "" : dritem["COSTCENTER"].ToString();
                        data.BranchNameOfCostCenterPerSystem = dritem["BRANCHNAMEOFCOSTCENTERPERSYSTEM"].ToString() == "" ? "" : dritem["BRANCHNAMEOFCOSTCENTERPERSYSTEM"].ToString();
                        data.StatusPerGL = dritem["STATUSPERGL"].ToString() == "" ? "" : dritem["STATUSPERGL"].ToString();
                        data.OriginatingBranchBooked = dritem["ORIGINATINGBRANCHBOOKED"].ToString() == "" ? "" : dritem["ORIGINATINGBRANCHBOOKED"].ToString();
                        data.NationalityPerICBS = dritem["NATIONALITYPERICBS"].ToString() == "" ? "" : dritem["NATIONALITYPERICBS"].ToString();
                        // data.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(dritem["NEXTRATEREVIEWDATEEXTRACTEDPERFAMSAAFICBS"].ToString() == "" ? "01/01/1900" : dritem["NEXTRATEREVIEWDATEEXTRACTEDPERFAMSAAFICBS"]);

                        if (!isValidDate(dritem["NEXTRATEREVIEWDATEEXTRACTEDPERFAMSAAFICBS"].ToString()))
                        {
                            data.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime("01/01/1900");
                        }
                        else
                        {
                            data.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(dritem["NEXTRATEREVIEWDATEEXTRACTEDPERFAMSAAFICBS"]);
                        }


                        data.TaxID = dritem["TAXID"].ToString() == "" ? "" : dritem["TAXID"].ToString();
                        data.LoanPurposeCode = dritem["LOANPURPOSECODE"].ToString() == "" ? "" : dritem["LOANPURPOSECODE"].ToString();
                        data.MaturityTypeCode = dritem["MATURITYTYPECODE"].ToString() == "" ? "" : dritem["MATURITYTYPECODE"].ToString();
                        data.BankRelationship = dritem["BANKRELATIONSHIP"].ToString() == "" ? "" : dritem["BANKRELATIONSHIP"].ToString();
                        data.SyndicatedLoanInd = dritem["SYNDICATEDLOANIND"].ToString() == "" ? "" : dritem["SYNDICATEDLOANIND"].ToString();
                        data.CustomerTypeDescription = dritem["CUSTOMERTYPEDESCRIPTION"].ToString() == "" ? "" : dritem["CUSTOMERTYPEDESCRIPTION"].ToString();
                        data.RELCode = dritem["RELCODE"].ToString() == "" ? "" : dritem["RELCODE"].ToString();
                        data.REECode = dritem["REECODE"].ToString() == "" ? "" : dritem["REECODE"].ToString();
                        data.REEAddtlInfo = dritem["REEADDTLINFO"].ToString() == "" ? "" : dritem["REEADDTLINFO"].ToString();
                        data.AcctRef = dritem["ACCTREF"].ToString() == "" ? "" : dritem["ACCTREF"].ToString();
                        data.RPT = dritem["RPT"].ToString() == "" ? "" : dritem["RPT"].ToString();
                        data.ASSETCOST = Convert.ToDecimal(dritem["ASSETCOST"].ToString() == "" ? 0.00 : dritem["ASSETCOST"]);
                        data.LeaseType = dritem["LEASETYPE"].ToString() == "" ? "" : dritem["LEASETYPE"].ToString();
                        data.Provisioning = dritem["PROVISIONING"].ToString() == "" ? "" : dritem["PROVISIONING"].ToString();
                        data.Matrix = dritem["MATRIX"].ToString() == "" ? "" : dritem["MATRIX"].ToString();
                        data.Remarks = dritem["REMARKS"].ToString() == "" ? "" : dritem["REMARKS"].ToString();
                        data.ICBSCollateralCode = dritem["ICBSCOLLATERALCODE"].ToString() == "" ? "" : dritem["ICBSCOLLATERALCODE"].ToString();
                        data.AssetValue = Convert.ToDecimal(dritem["ASSETVALUE"].ToString() == "" ? 0.00 : dritem["ASSETVALUE"]);
                        data.ApprovedAmount = Convert.ToDecimal(dritem["APPROVEDAMOUNT"].ToString() == "" ? 0.00 : dritem["APPROVEDAMOUNT"]);
                        data.CPNumber = dritem["CPNUMBER"].ToString() == "" ? "" : dritem["CPNUMBER"].ToString();
                        data.LastInterestPay = Convert.ToDecimal(dritem["LASTPRINCIPALPAY"].ToString() == "" ? 0.00 : dritem["LASTPRINCIPALPAY"]);
                        //data.PrincipalPayDate = Convert.ToDateTime(dritem["PRINCIPALPAYDATE"].ToString() == "" ? "01/01/1900" : dritem["PRINCIPALPAYDATE"]);

                        if (!isValidDate(dritem["PRINCIPALPAYDATE"].ToString()))
                        {
                            data.PrincipalPayDate = Convert.ToDateTime("01/01/1900");
                        }
                        else
                        {
                            data.PrincipalPayDate = Convert.ToDateTime(dritem["PRINCIPALPAYDATE"]);
                        }

                        data.LastInterestPay = Convert.ToDecimal(dritem["LASTINTERESTPAY"].ToString() == "" ? 0.00 : dritem["LASTINTERESTPAY"]);
                        // data.LastInterestPayDate = Convert.ToDateTime(dritem["LASTINTERESTPAYDATE"].ToString() == "" ? "01/01/1900" : dritem["LASTINTERESTPAYDATE"]);
                        if (!isValidDate(dritem["LASTINTERESTPAYDATE"].ToString()))
                        {
                            data.LastInterestPayDate = Convert.ToDateTime("01/01/1900");
                        }
                        else
                        {
                            data.LastInterestPayDate = Convert.ToDateTime(dritem["LASTINTERESTPAYDATE"]);
                        }


                        data.PreviousMonthsNPLTaggingByRisk = dritem["PREVIOUSMONTHSNPLTAGGINGBYRISK"].ToString() == "" ? "" : dritem["PREVIOUSMONTHSNPLTAGGINGBYRISK"].ToString();
                        data.SpecificRequiredProvisions = dritem["SPECIFICREQUIREDPROVISIONS"].ToString() == "" ? "" : dritem["SPECIFICREQUIREDPROVISIONS"].ToString();
                        data.GeneralRequiredProvisions = dritem["GENERALREQUIREDPROVISIONS"].ToString() == "" ? "" : dritem["GENERALREQUIREDPROVISIONS"].ToString();
                        data.Reason = "";
                        #endregion

                        if (underLitigationRepository.AccountNotExists(data.AccountNo, _underLitigationDateParameter.ToString()))
                        {
                            underLitigationRepository.DeleteConsolidator(data);
                            underLitigationRepository.InsertRecord(data);

                            dru = dtupdated.NewRow();
                            dru["AccountNo"] = data.AccountNo;
                            dru["GL Code"] = data.ICBSGLCode;
                            dru["GL Description"] = data.ICBSGLName;
                            dtupdated.Rows.Add(dru);
                        }
                        else
                        {
                            underLitigationRepository.InsertRecord(data);

                            dri = dtinserted.NewRow();
                            dri["AccountNo"] = data.AccountNo;
                            dri["GL Code"] = data.ICBSGLCode;
                            dri["GL Description"] = data.ICBSGLName;
                            dtinserted.Rows.Add(dri);
                        }

                        saveWorker.ReportProgress(iCount++ * 100 / dtFromNTCRecords.Rows.Count, progressArray); // wla lng
                    }
                }
            }
            catch (Exception ex)
            {
                var asdasd = iCount;
                throw ex;
            }
        }
        #endregion

        private void ListItem()
        {
            dtupdated.Columns.Add("AccountNo");
            dtupdated.Columns.Add("GL Code");
            dtupdated.Columns.Add("GL Description");

            dtinserted.Columns.Add("AccountNo");
            dtinserted.Columns.Add("GL Code");
            dtinserted.Columns.Add("GL Description");
        }

        private DataTable NTCColumnNames()
        {
            dtunderLitigation = new DataTable("dtunderLitigation");
            dtunderLitigation.Columns.Add("TransID", typeof(String));
            dtunderLitigation.Columns.Add("RawFiles", typeof(String));
            dtunderLitigation.Columns.Add("isConsolidated", typeof(String));
            dtunderLitigation.Columns.Add("isDeleted", typeof(String));
            dtunderLitigation.Columns.Add("UserName", typeof(String));
            dtunderLitigation.Columns.Add("TransDate", typeof(String));
            dtunderLitigation.Columns.Add("RecordDate", typeof(String));
            dtunderLitigation.Columns.Add("SYSTEM", typeof(String));
            dtunderLitigation.Columns.Add("AccountNo", typeof(String));
            dtunderLitigation.Columns.Add("ClientName", typeof(String));
            dtunderLitigation.Columns.Add("AO", typeof(String));
            dtunderLitigation.Columns.Add("FacilityCode", typeof(String));
            dtunderLitigation.Columns.Add("StatusPerSystem", typeof(String));
            dtunderLitigation.Columns.Add("ValueDate", typeof(String));
            dtunderLitigation.Columns.Add("FirstDueDate", typeof(String));
            dtunderLitigation.Columns.Add("MaturityDate", typeof(String));
            dtunderLitigation.Columns.Add("TotalLoan", typeof(String));
            dtunderLitigation.Columns.Add("OB", typeof(String));
            dtunderLitigation.Columns.Add("MonthlyOB", typeof(String));
            dtunderLitigation.Columns.Add("UDIBalance", typeof(String));
            dtunderLitigation.Columns.Add("ClientsEquity", typeof(String));
            dtunderLitigation.Columns.Add("AccruedInterestReceivable", typeof(String));
            dtunderLitigation.Columns.Add("OrigERV", typeof(String));
            dtunderLitigation.Columns.Add("PVRV", typeof(String));
            dtunderLitigation.Columns.Add("OrigGD", typeof(String));
            dtunderLitigation.Columns.Add("PVGD", typeof(String));
            dtunderLitigation.Columns.Add("TotalLoanPortfolio", typeof(String));
            dtunderLitigation.Columns.Add("NTC", typeof(String));
            dtunderLitigation.Columns.Add("OriginalRate", typeof(String));
            dtunderLitigation.Columns.Add("CurrentRate", typeof(String));
            dtunderLitigation.Columns.Add("TermInMonths", typeof(String));
            dtunderLitigation.Columns.Add("RemainingTermInMonths", typeof(String));
            dtunderLitigation.Columns.Add("OriginalAmortizationAAF", typeof(String));
            dtunderLitigation.Columns.Add("PaymentScheduleAmortizationAAF", typeof(String));
            dtunderLitigation.Columns.Add("RepricedDate", typeof(String));
            dtunderLitigation.Columns.Add("AAFICBSRateType", typeof(String));
            dtunderLitigation.Columns.Add("RepricedAmortization", typeof(String));
            dtunderLitigation.Columns.Add("PastDueDateITLDateExtractedPerAAFICBS", typeof(String));
            dtunderLitigation.Columns.Add("PerFaMSAAFICBSIndustryCode", typeof(String));
            dtunderLitigation.Columns.Add("IndustryHeader", typeof(String));
            dtunderLitigation.Columns.Add("IndustryDetail", typeof(String));
            dtunderLitigation.Columns.Add("Collateral", typeof(String));
            dtunderLitigation.Columns.Add("PerFaMSAAFICBSAssetSize", typeof(String));
            dtunderLitigation.Columns.Add("PerFaMSAAFICBSAssetSizeInWords", typeof(String));
            dtunderLitigation.Columns.Add("ICBSGLCode", typeof(String));
            dtunderLitigation.Columns.Add("ICBSGLName", typeof(String));
            dtunderLitigation.Columns.Add("CostCenter", typeof(String));
            dtunderLitigation.Columns.Add("BranchNameOfCostCenterPerSystem", typeof(String));
            dtunderLitigation.Columns.Add("StatusPerGL", typeof(String));
            dtunderLitigation.Columns.Add("OriginatingBranchBooked", typeof(String));
            dtunderLitigation.Columns.Add("NationalityPerICBS", typeof(String));
            dtunderLitigation.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS", typeof(String));
            dtunderLitigation.Columns.Add("TaxID", typeof(String));
            dtunderLitigation.Columns.Add("LoanPurposeCode", typeof(String));
            dtunderLitigation.Columns.Add("MaturityTypeCode", typeof(String));
            dtunderLitigation.Columns.Add("BankRelationship", typeof(String));
            dtunderLitigation.Columns.Add("SyndicatedLoanInd", typeof(String));
            dtunderLitigation.Columns.Add("CustomerTypeDescription", typeof(String));
            dtunderLitigation.Columns.Add("RELCode", typeof(String));
            dtunderLitigation.Columns.Add("REECode", typeof(String));
            dtunderLitigation.Columns.Add("REEAddtlInfo", typeof(String));
            dtunderLitigation.Columns.Add("AcctRef", typeof(String));
            dtunderLitigation.Columns.Add("RPT", typeof(String));
            dtunderLitigation.Columns.Add("ASSETCOST", typeof(String));
            dtunderLitigation.Columns.Add("LeaseType", typeof(String));
            dtunderLitigation.Columns.Add("Provisioning", typeof(String));
            dtunderLitigation.Columns.Add("Matrix", typeof(String));
            dtunderLitigation.Columns.Add("Remarks", typeof(String));
            dtunderLitigation.Columns.Add("ICBSCollateralCode", typeof(String));
            dtunderLitigation.Columns.Add("AssetValue", typeof(String));
            dtunderLitigation.Columns.Add("ApprovedAmount", typeof(String));
            dtunderLitigation.Columns.Add("CPNumber", typeof(String));
            dtunderLitigation.Columns.Add("LastPrincipalPay", typeof(String));
            dtunderLitigation.Columns.Add("PrincipalPayDate", typeof(String));
            dtunderLitigation.Columns.Add("LastInterestPay", typeof(String));
            dtunderLitigation.Columns.Add("LastInterestPayDate", typeof(String));
            dtunderLitigation.Columns.Add("PreviousMonthsNPLTaggingByRisk", typeof(String));
            dtunderLitigation.Columns.Add("SpecificRequiredProvisions", typeof(String));
            dtunderLitigation.Columns.Add("GeneralRequiredProvisions", typeof(String));
            dtunderLitigation.Columns.Add("Reason", typeof(String));

            return dtunderLitigation;

        }

        private void frmUnderLitigation_FormClosed(object sender, FormClosedEventArgs e)
        {
            //frmConsolidator frmreload = new frmConsolidator();
            //frmreload.GetConsolidator();

            frmUnderLitigation.litigationform = null;
        }

        private void lblOutOf_Click(object sender, EventArgs e)
        {

        }

        private void lnkDetails_DoubleClick(object sender, EventArgs e)
        {
            pnlInsertUpdate.Visible = true;
        }

        private void btnpnlUpdateInsert_Click(object sender, EventArgs e)
        {
            this.pnlInsertUpdate.Visible = false;
            this.pnlSummary.Visible = true;
        }

        private void ShowHiddenPanel()
        {
            pnlInsertUpdate.Visible = true;
            //loop here
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.pnlSummary.Visible = false;
            //this.pnlInsertUpdate.Visible = true;
        }

        private void lnkDetailsInserted_DoubleClick(object sender, EventArgs e)
        {
            ShowHiddenPanel();
        }

        //protected bool isValidDate(String date)
        //{
        //    try
        //    {
        //        DateTime dt = DateTime.Parse(date);
        //        return true;
        //    }
        //    catch
        //    {
        //        return false;
        //    }
        //}

        private void lnkDetailsUpdated_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            BindData();
            this.pnlSummary.Visible = false;
            this.pnlInsertUpdate.Visible = true;
        }

        private void lnkDetailsInserted_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            BindData();
            this.pnlSummary.Visible = false;
            this.pnlInsertUpdate.Visible = true;
        }

        private void BindData()
        {
            if (dtupdated.Rows.Count > 0)
            {
                dgrViewUpdatedList.DataSource = dtupdated;
            }

            if (dtinserted.Rows.Count > 0)
            {
                dgrViewInserted.DataSource = dtinserted;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate("Accounts Under Litigation");

                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\nAccounts Under Litigation excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
