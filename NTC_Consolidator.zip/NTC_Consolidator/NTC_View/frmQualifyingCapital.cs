﻿//using NTC_Consolidator.Model;
using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using NTC_Consolidator.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmQualifyingCapital : MetroFramework.Forms.MetroForm
    {
        ToolTip tt = new ToolTip();
        private static frmQualifyingCapital qcapitalform = null;
        private IQualifyingCapital qualifyingCapitalRepository;
        string ErrorID = "";
        public static frmQualifyingCapital Instance()
        {
            if (qcapitalform == null)
            {
                qcapitalform = new frmQualifyingCapital();
            }
            return qcapitalform;
        }

        public frmQualifyingCapital()
        {
            InitializeComponent();
            this.qualifyingCapitalRepository = new QualifyingCapitalRepository(new NTCConn());
        }

        private void GetAllCapital()
        {
            dgvQCapital.DataSource = qualifyingCapitalRepository.GetAll();
            dgvQCapital.Columns["QualifyingCapitalID"].Visible = false;
            dgvQCapital.Columns["CreatedDate"].Visible = false;
            dgvQCapital.Columns["CreatedBy"].Visible = false;
            dgvQCapital.Columns["isDeleted"].Visible = false;
            dgvQCapital.Columns["Description"].Visible = false;
            dgvQCapital.Columns["RefDate"].DefaultCellStyle.Format = "MM/dd/yyyy";
            this.dgvQCapital.ClearSelection();
        }

        private void frmQualifyingCapital_Load(object sender, EventArgs e)
        {
            try
            {
                cmbRefDate.MinDate = DateTime.Now;
                GetAllCapital();
                cmbRefDate.Enabled = true;
                txtAmount.Enabled = true;
                btnSubmit.Enabled = true;
                cmbRefDate.Value = DateTime.Now.AddDays(1);
            }
            catch (Exception ex)
            {
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while loading the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            var isPassed = false;
            var description = txtDescription.Text;
            var amount = txtAmount.Text;

            #region QualifyingCapital Validation Using EF DataAnnotation

            QualifyingCapital capital = new QualifyingCapital();

            isPassed = IsValid(isPassed, description, amount, capital); //Check for Valid Input

            if (!isPassed)
            {
                return;
            }
            else
            {
                try
                {
                    //validate first before saving
                    var QCapital = new BDOLF_QualifyingCapital();
                    QCapital.Amount = amount == "" ? 0M : Convert.ToDecimal(amount);
                    QCapital.CreatedBy = frmConsolidator.UserName;
                    QCapital.CreatedDate = DateTime.Now;
                    QCapital.Description = description;
                    QCapital.isDeleted = false;
                    QCapital.RefDate = Convert.ToDateTime(Convert.ToDateTime(cmbRefDate.Text).ToShortDateString());

                    var data = qualifyingCapitalRepository.GetByCode(QCapital.RefDate.ToString());

                    if (data != null)
                    {
                        var parameter = Convert.ToDateTime(QCapital.RefDate);
                        var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                        // var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
                        if (firstDayOfMonth.Year < DateTime.Today.Year)
                        {
                            MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSorry, Amount from previous month or year is not editable", "Qualifying Capital", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        else
                        {
                            if (data.RefDate.Month < DateTime.Today.Month)
                            {
                                MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSorry, Amount from previous month or year is not editable", "Qualifying Capital", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            }
                            else if (data.RefDate.Month >= DateTime.Today.Month)
                            {
                                QCapital.QualifyingCapitalID = data.QualifyingCapitalID;
                                qualifyingCapitalRepository.UpdateQCapital(QCapital);
                                MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSuccessfully updated", "Qualifying Capital", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    else
                    {
                        qualifyingCapitalRepository.InsertQCapital(QCapital);
                        qualifyingCapitalRepository.Save();
                        MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nNew Qualifying Capital Amount for this month was successfully added", "Qualifying Capital", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                   
                    txtDescription.Text = "";
                    txtAmount.Text = "";
                    GetAllCapital();
                }
                catch (Exception ex)
                {
                    ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                    var Modulename = this.GetType().FullName;
                    var methodName = MethodBase.GetCurrentMethod().Name;
                    ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID);

                    MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while saving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
            }

            #endregion
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            Regex regex = new Regex(@"[\d]\.[\d][0-9]{7}");
            var match = regex.Match(txtAmount.Text);
            if (match.Success)
            {
                e.Handled = true;
                // return;
            }

            char ch = e.KeyChar;
            decimal x;
            if (ch == (char)Keys.Back)
            {
                e.Handled = false;
            }
            else if (!char.IsDigit(ch) && ch != '.' || !Decimal.TryParse(txtAmount.Text + ch, out x))
            {
                e.Handled = true;
            }
        }

        private bool IsValid(bool isPassed, string description, string amount, QualifyingCapital capital)
        {
            isPassed = true;

            try
            {
                if (string.IsNullOrEmpty(description))
                {
                    capital.Description = "";
                }
                else
                {
                    lblErrDescription.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrDescription.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(amount) || amount == "0.0000")
                {
                    //if (string.IsNullOrEmpty(amount))
                //{
                    capital.Amount = 0M;
                }
                else
                {
                    lblErrAmount.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrAmount.Text = ex.Message;
                isPassed = false;
            }

            return isPassed;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmQualifyingCapital.qcapitalform = null;
            this.Close();
        }

        private void frmQualifyingCapital_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmQualifyingCapital.qcapitalform = null;
        }

        private void dgvQCapital_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvQCapital.Rows[e.RowIndex];
                cmbRefDate.MinDate = Convert.ToDateTime(row.Cells["RefDate"].Value);

                txtAmount.Text = row.Cells["Amount"].Value.ToString();
                txtDescription.Text = row.Cells["Description"].Value.ToString();
                //cmbRefDate.Value = row.Cells["RefDate"].Value == null ? cmbRefDate.MinDate : Convert.ToDateTime(row.Cells["RefDate"].Value); 
                cmbRefDate.Value = Convert.ToDateTime(row.Cells["RefDate"].Value);
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            var dtData = new DataTable();
            //qualifyingCapitalRepository.GetAll(); 

            dtData = (this.dgvQCapital.DataSource as DataTable).Copy();
            SaveFileDialog diag = new SaveFileDialog();
            diag.Filter = "Excel Files(.xls)";//|*.xls| Excel Files(.xlsx) | *.xlsx";
            diag.FilterIndex = 0;
            diag.RestoreDirectory = true;
            //  diag.CreatePrompt = true;
            diag.Title = "Export Exchange Rate To Excel File";

            if (dtData.Rows.Count > 0)
            {
                if (diag.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        StreamWriter wr = new StreamWriter(diag.FileName);
                        for (int i = 0; i < dtData.Columns.Count; i++)
                        {
                            wr.Write(dtData.Columns[i].ToString().ToUpper() + "\t");
                        }

                        wr.WriteLine();
                        //write rows to excel file
                        for (int i = 0; i < (dtData.Rows.Count); i++)
                        {
                            for (int j = 0; j < dtData.Columns.Count; j++)
                            {
                                if (dtData.Rows[i][j] != null)
                                {
                                    wr.Write("" + Convert.ToString(dtData.Rows[i][j]) + "" + "\t");
                                }
                                else
                                {
                                    wr.Write("\t");
                                }
                            }
                            //go to next line
                            wr.WriteLine();
                        }

                        //close file
                        wr.Close();
                        MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nQualifying Capital was successfully exported", "Qualifying Capital", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                        var Modulename = this.GetType().FullName;
                        var methodName = MethodBase.GetCurrentMethod().Name;
                        ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID);

                        MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while Exporting the files, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                    }
                }

            }
        }

        bool IsInLastMonth(DateTime dt)
        {
            DateTime lastMonth = DateTime.Today.AddMonths(-1);
            return dt.Month == lastMonth.Month && dt.Year == lastMonth.Year;
        }

        bool IsInLastYear(DateTime dt)
        {
            return dt.Year == DateTime.Now.Year - 1;
        }

        private void dgvQCapital_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                int rowSelected = e.RowIndex;
                if (e.RowIndex != -1)
                {
                    this.dgvQCapital.ClearSelection();
                    this.dgvQCapital.Rows[rowSelected].Selected = true;
                    DataGridViewRow row = this.dgvQCapital.Rows[e.RowIndex];
                    cmbRefDate.MinDate = Convert.ToDateTime(row.Cells["RefDate"].Value);

                    txtAmount.Text = row.Cells["Amount"].Value.ToString();
                    txtDescription.Text = row.Cells["Description"].Value.ToString();
                    cmbRefDate.Value = row.Cells["RefDate"].Value == null ? cmbRefDate.MinDate : Convert.ToDateTime(row.Cells["RefDate"].Value);

                }
                // you now have the selected row with the context menu showing for the user to delete etc.
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsInLastYear(Convert.ToDateTime(cmbRefDate.Value)) || IsInLastMonth(Convert.ToDateTime(cmbRefDate.Value)))
            {
                MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSorry, Amount from previous month cannot be editable", "Qualifying Capital", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            //if(Convert.ToDateTime(cmbRefDate.Value).to

            // txtAmount.Text = row.Cells["Amount"].Value.ToString();
            // txtDescription.Text = row.Cells["Description"].Value.ToString();
            // cmbRefDate.Value = row.Cells["RefDate"].Value == null ? cmbRefDate.MinDate : Convert.ToDateTime(row.Cells["RefDate"].Value);


            // btnSubmit.Text = "&Update";
            txtAmount.Enabled = true;
            cmbRefDate.Enabled = true;
            btnSubmit.Enabled = true;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dr = MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nAre you sure you want to delete this item?", "Qualifying Capital", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    var QualifyingCapitalID = Convert.ToInt32(dgvQCapital.CurrentRow.Cells["QualifyingCapitalID"].Value);
                    qualifyingCapitalRepository.DeleteQCapital(QualifyingCapitalID);
                    // exchangeRateRepository.Save();
                    MetroMessageBox.Show(this, "\r\n\r\nSuccessfully deleted", "Qualifying Capital", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cmbRefDate.Value = DateTime.Now;
                    txtAmount.Text = "";
                    GetAllCapital();
                }
            }
            catch (Exception ex)
            {
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while deleting the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }

        private void picInfo_Click(object sender, EventArgs e)
        {
            tt.SetToolTip(this.picInfo, "By default, Amount is set to zero(0.0000)\r\n\r\nClick Gridview to cancel editing.");
        }

        private void picInfo_MouseHover(object sender, EventArgs e)
        {
            tt.SetToolTip(this.picInfo, "By default, Amount is set to zero(0.0000)\r\n\r\nClick Gridview to cancel editing.");
        }
    }
}
