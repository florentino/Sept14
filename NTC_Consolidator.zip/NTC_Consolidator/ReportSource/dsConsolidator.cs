﻿namespace NTC_Consolidator.ReportSource
{
}

namespace NTC_Consolidator.ReportSource {
    
    
    public partial class dsConsolidator {
    }
}
namespace NTC_Consolidator.ReportSource {
    
    
    public partial class dsConsolidator {
    }
}
