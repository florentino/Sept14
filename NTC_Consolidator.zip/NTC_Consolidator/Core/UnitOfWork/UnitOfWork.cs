﻿using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Model;
using System;

namespace ContosoUniversity.DAL
{
    public class UnitOfWork : IDisposable
    {
        private NTCConn context = new NTCConn();
        private GenericRepository<CorrespondingGL> correspondingGLRepository; 
        //private CorrespondingGLRepository correspondingGLRepository;

        public GenericRepository<CorrespondingGL> CorrespondingGLRepository
        {
            get
            {
                if (this.correspondingGLRepository == null)
                {
                    this.correspondingGLRepository = new GenericRepository<CorrespondingGL>(context);
                }
                return correspondingGLRepository;
            }
        }

        public void Save()
        {
            context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
