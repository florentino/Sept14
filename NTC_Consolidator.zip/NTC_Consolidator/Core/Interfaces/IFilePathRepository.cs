﻿using NTC_Consolidator.Data;
using NTC_Consolidator.NTC_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IFilePathRepository : IDisposable
    {
        IEnumerable<BDOLF_PathMaintenance> GetAll();
        BDOLF_PathMaintenance GetByID(int PathID);
        BDOLF_PathMaintenance GetByCode(string PathID);
        void InsertFilePathMaintenace(BDOLF_PathMaintenance gl);
        void DeleteFilePathMaintenace(int PathID);
        void TruncateTable();
        void DeleteFilePathMaintenace(string PathID);
        void UpdateFilePathMaintenace(BDOLF_PathMaintenance gl);
        void BulkInsert(object objdata);
        void BulkDelete(object objdata);
        void BulkUpdete(object objdata);
        void Save();
    }
}
