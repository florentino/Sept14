﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Data;
using NTC_Consolidator.Model;
using System.Data.Entity;

namespace NTC_Consolidator.Core.Repository
{
    public class CorrespondingGLRepository : ICorrespondingGLRepository, IDisposable
    {
        private NTCConn context;
        DbSet<CorrespondingGL> _bjectSet;

        public CorrespondingGLRepository(NTCConn context)
        {
            this.context = context;
            _bjectSet = context.Set<CorrespondingGL>();
        }

        public void DeleteCorrespondingGL(string GLCode)
        {
            BDOLF_CorrepondingGL gl = context.BDOLF_CorrepondingGL.Find(GLCode);
            context.BDOLF_CorrepondingGL.Remove(gl);
        }

        public void DeleteCorrespondingGL(int glCode)
        {
            //BDOLF_CorrepondingGL gl = context.BDOLF_CorrepondingGL.Find(GLCodeID);
            //context.BDOLF_CorrepondingGL.Remove(gl);
            throw new NotImplementedException();
        }

        public BDOLF_CorrepondingGL GetCorrespondingGLByID(string glCode)
        {
            var parameter = DateTime.Today;

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            return context.BDOLF_CorrepondingGL.Where(a => (a.CreatedDate >= firstDayOfMonth && a.CreatedDate <= lastDayOfMonth) && a.GLCode == glCode).FirstOrDefault();//.Any();

           // return context.Set<BDOLF_CorrepondingGL>().Find(glCode);
        }

        public BDOLF_CorrepondingGL GetCorrespondingGLByID(int glCode)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_CorrepondingGL> GetGL()
        {
            //var data = context.BDOLF_CorrepondingGL.Where(a => a.isDeleted == false);
            return context.Set<BDOLF_CorrepondingGL>().ToList();
        }

        public void InsertCorrespondingGL(BDOLF_CorrepondingGL gl)
        {
            context.BDOLF_CorrepondingGL.Add(gl);
            context.Set<BDOLF_CorrepondingGL>().Add(gl);
        }
        
        public void UpdateCorrespondingGL(BDOLF_CorrepondingGL gl)
        {
            context.Entry(gl).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public bool GLCodeNotExists(string AccountNo)
        {
            throw new NotImplementedException();
        }
    }
}
