﻿using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Repository
{
    public class MigratedAccountRepository : IMigratedAccount, IDisposable
    {
        private NCTConn context;
        DbSet<BDOLF_Consolidator> _bjectSet;

        public MigratedAccountRepository(NCTConn context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_Consolidator>();
        }

        public bool AccountNotExists(string AccountNo, string System)
        {
            return context.BDOLF_Consolidator.Where(a => a.AccountNo == AccountNo && a.SYSTEM == System).AsEnumerable().Any();
        }


        public IEnumerable<BDOLF_Consolidator> GetAll()
        {
            throw new NotImplementedException();
        }

        public BDOLF_Consolidator GetByAccountNo(string AccountNo)
        {
            throw new NotImplementedException();
        }

        public BDOLF_Consolidator GetByAccountNo(int AccountNo)
        {
            throw new NotImplementedException();
        }

        public void InsertRecord(BDOLF_Consolidator migratedAcct)
        {
            throw new NotImplementedException();
        }

        public void UpdateConsolidator(BDOLF_Consolidator migratedAcct)
        {
            BDOLF_Consolidator originalData = context.BDOLF_Consolidator.First(a => a.AccountNo == migratedAcct.AccountNo && a.SYSTEM == migratedAcct.SYSTEM);

            originalData.PVGD = migratedAcct.PVGD;
            originalData.PVRV = migratedAcct.PVRV;
            originalData.UDIBalance = migratedAcct.UDIBalance;

            context.Entry<BDOLF_Consolidator>(context.Set<BDOLF_Consolidator>().Find(originalData.TransID)).CurrentValues.SetValues(originalData);
            context.SaveChanges();
        }

        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
