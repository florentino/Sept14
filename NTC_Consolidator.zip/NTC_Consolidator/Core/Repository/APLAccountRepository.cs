﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace NTC_Consolidator.Core.Repository
{
    public class APLAccountRepository : IAPLAccount, IDisposable
    {
        private NCTConn context;
        DbSet<BDOLF_Consolidator> _bjectSet;

        public APLAccountRepository(NCTConn context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_Consolidator>();
        }

        public bool AccountNotExists(string AccountNo, string System)
        {
            var parameter = Convert.ToDateTime(DateTime.Today);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

            var exists = context.BDOLF_Consolidator.Where(a => a.AccountNo == AccountNo && (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth) && (a.SYSTEM == "AAF" || a.SYSTEM == "FAMS")).Any();
            return exists;
        }
        
        public IEnumerable<BDOLF_Consolidator> GetAll()
        {
            throw new NotImplementedException();
        }

        public BDOLF_Consolidator GetByAccountNo(string AccountNo)
        {
            throw new NotImplementedException();
        }

        public BDOLF_Consolidator GetByAccountNo(int AccountNo)
        {
            throw new NotImplementedException();
        }

        public DateTime GetDate()
        {
            throw new NotImplementedException();
        }

        public void InsertRecord(BDOLF_Consolidator aplData)
        {
            throw new NotImplementedException();
        }

        public void UpdateConsolidator(BDOLF_Consolidator aplData)
        {
            var parameter = Convert.ToDateTime(DateTime.Today);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
         
            var original = context.BDOLF_Consolidator.Where(a => a.AccountNo == aplData.AccountNo && (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth) && (a.SYSTEM == "AAF" || a.SYSTEM == "FAMS")).FirstOrDefault();
            original.SpecificRequiredProvisions = aplData.SpecificRequiredProvisions;
            original.PreviousMonthsNPLTaggingByRisk = aplData.PreviousMonthsNPLTaggingByRisk;
            original.GeneralRequiredProvisions = aplData.GeneralRequiredProvisions;
            var transid = original.TransID;

            context.Entry<BDOLF_Consolidator>(context.Set<BDOLF_Consolidator>().Find(transid)).CurrentValues.SetValues(original);
            context.SaveChanges();
        }

        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}
