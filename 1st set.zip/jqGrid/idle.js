var timerID = null;
var delay = 10 * 60000; //999

function setDelay(time){
	delay = time;
}

function setDefaultDelay(){
	delay = 10 * 60000;
}